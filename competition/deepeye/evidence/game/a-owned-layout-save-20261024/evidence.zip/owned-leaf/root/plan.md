# G02 owned Windows file commit implementation plan

> For agentic workers: use subagent-driven-development with an independent specification/code review. Root Gen3 owns selection and acceptance; no additional human approval is needed for this delegated technical choice.

**Goal:** Build and actually test the Windows no-clobber file primitive needed to remove Save As's documented concurrent-writer race.

**Architecture:** A one-shot Python ctypes leaf exclusively creates and retains its own temporary file HANDLE through bounded write, same-HANDLE exact readback, and one no-replace FileRenameInfo publication. Cleanup uses that owned HANDLE, never an unconfirmed path. This phase deliberately leaves the current Godot caller unchanged until the primitive and its deployment boundary are independently accepted.

**Tech stack:** Existing A Windows Python 3 runtime; stdlib only; Kernel32 documented APIs; new isolated filesystem tests, no display/engine/board/service.

## Global constraints

- Active director 01a16988-bdcb-70e1-ae10-1304b5cf7875 / generation3; task DEEPEYE-IMPLEMENTATION-20261014/v1.
- DEEPEYE-HUMAN-LOCK-20261014/revision1, all H01-H15 and full H12 preserved; requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804. G03/R03/all29 remain not_run.
- Baseline product head 5398cd76e5b5e277ad14053e1786ea014b90260e. Existing layout_store.gd SHA256 752b023361b3ae935214dcef8beedc22e3722c66f0bdf1cef5b20939a91696a5 is not modified in this phase. C4/index/cache and all old failed evidence remain intact.
- Author owns only this directory's author/ subtree. Root owns plan.md/root checkpoint; reviewer owns review/. No writer touches product until root selects exact reviewed files.
- Payload is opaque bytes <=1048576, not decoded layout/model/control data. Public leaf API: commit_new(target: str, payload: bytes) -> dict with state, ok, code; committed requires the actual no-replace OS rename success. States: committed, already_exists, failed_before_publish, outcome_unknown. No automatic replay or fallback to ordinary Godot rename/copy/delete.
- Supported phase1 path boundary: existing ordinary local NTFS parent, absolute drive path only. Check actual drive type and filesystem; a drive-letter mapping alone is not local-disk evidence. Reject UNC/device/extended namespace, ADS, NUL, traversal, DOS reserved names, trailing dot/space aliases, invalid characters, unpaired surrogate, excessive path length. Reject reparse ancestry. Initially hold all ordinary ancestor directory handles with share-READ only. Create and retain the owned temp under this strict protection. Then open replacement read-desired ancestor handles with share-READ|WRITE but no share-DELETE while every original strict handle remains held; verify file identity matches before releasing the strict set. The retained temp keeps the last parent nonempty; every earlier ancestor contains the next pinned directory. NTFS's documented nonempty-directory reparse restriction protects this second stage while the handles deny directory deletion/rename. Do not perform new path lookups after owned-temp failure cleanup. If this bounded handover cannot be established, fail closed; do not drop all protection and retry. Missing parent fails; parent creation and Godot distribution are next integration work, not silently assumed present. DOS-device remapping, privileged namespace/filter attacks and arbitrary remote providers are outside this local primitive's guarantee.
- Acquire noninherited temp with CREATE_NEW and GENERIC_READ|GENERIC_WRITE|DELETE; deny sharing write/delete (exclusive is acceptable). Same parent, bounded random names/retries; preexisting temp paths must not be opened/truncated. Full WriteFile count, checked FlushFileBuffers (no power-loss durability claim), SetFilePointerEx/readback and exact EOF/bytes verification.
- Publish via SetFileInformationByHandle(FileRenameInfo, ReplaceIfExists=FALSE), properly aligned ctypes buffer and UTF-16 byte length, NULL RootDirectory and the validated absolute target, only after the protected two-stage ancestry handover. Source remains original HANDLE. No target pre-delete. Classify collisions conservatively. Hold source until known API outcome; close failures/ambiguous exceptions after publication cannot become failed-before-publish. Actual fresh diagnostics must establish this exact form before candidate selection; this is a selected new design, never runtime fallback from a failed rename.
- Known pre-publication failure cleanup is FileDispositionInfo on original owned HANDLE then CloseHandle; report cleanup failures/orphan identity. If rename was attempted without a trustworthy FALSE return, cleanup is close-only: the original HANDLE may already identify the published target. Never mark it for deletion in an unknown outcome. Never delete by stale path. A process crash may leave its own orphan; no startup sweeper/adoption/replay.

## Task 1: Native leaf and actual new Windows tests

Files under author/candidate/:

- `layout_commit_windows.py`: isolated leaf, import must perform no I/O or thread/service work. No CLI/deployment in this phase.
- `test_layout_commit_windows.py`: focused unittest file, stdlib subprocess/multiprocessing for independent competing writers, all temporary test roots under author/runs/.

Steps:

- [ ] Write a minimal failing behavioral test first; retain actual red output before implementing. A deliberate absent-function/stub failure is acceptable; don't replay old suites.
- [ ] Implement the exact retained-HANDLE operation and finite path policy above. Private lower-level stage/publish separation may support deterministic rendezvous tests without mocking the OS rename itself; no public bypass/unsafe hook.
- [ ] Run new tests against actual Windows NTFS: empty and Chinese/non-BMP payload roundtrip; two processes same target (at most one complete winner); external sentinel created after a caller's absent check is preserved in bytes and file identity; preoccupied temp name preserved; held source cannot be externally truncated/deleted; directory target collision; Unicode paths; forbidden path aliases; pre-publish write/readback/rename failure cleanup; ambiguous post-publication response is never replayed.
- [ ] Use actual OS errors for normal race/ownership cases. Fault injection for unreachable short-write/response-loss branches must be explicitly labeled, preserve real successful publication evidence separately, and must not be described as physical OS fault occurrence.
- [ ] Preserve failed first attempts and logs. No tests outside this new file, no board/Godot/GUI, no service/network/model activation, no old tests/solve.
- [ ] Finish own lease, freeze exact candidate/tests/report hashes and concise result. Do not commit/push or wire Godot.

## Task 2: Independent review and root acceptance

- [ ] Reviewer checks actual primary-source ABI/path/sharing/error semantics and all new code, independently verifies output pins and terminal state; own review directory only.
- [ ] Root adjudicates findings, permits scoped fixes under fresh ownership only after confirmed completion, and verifies exact bytes plus actual test logs. Any serious open finding prevents product selection.
- [ ] A separate next scope integrates synchronous `LayoutStore.save_new` with a pinned one-shot helper protocol and actual headless Godot caller tests. That later scope must preserve 1MiB/UTF-8/codec/editor state, missing-parent behavior, unknown-result no-replay, and no unsafe fallback. Primitive success alone does not fix current product Save As or accept G02.

## Root design choice / evidence

Chosen option2 from completed A-G02-SAVE-AS-ATOMICITY-DESIGN-20261024-v1: full owned native helper. Cooperative locks and only replacing final rename do not close source temp ownership. Actual exact Godot source and old rename-existing probe are reused without rerunning them. CPU artifact locator completed separately; original C request and B minimal-PL assignment remain in force.

Primary references: https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew ; https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-setfileinformationbyhandle ; https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_rename_info

## Bounded design revision after actual initial failures

Author reported first new 14-test run with 7 pass/7 fail, followed by two fresh diagnostic source files: aligned parent-HANDLE/relative rename returned FALSE/87, NULL/absolute rename while share-READ-only ancestry remained held returned FALSE/32. Neither is a successful publication, and neither is permission to retry the same source. Root selected the two-stage retained-handle handover above for a new independent diagnostic. The normal Win32 file-rename path needs a destination-directory write open; the official NT rename structure documents IopOpenLinkOrRenameTarget requesting FILE_WRITE_DATA|SYNCHRONIZE (https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntifs/ns-ntifs-_file_rename_information). NTFS reparse directory emptiness is documented at https://learn.microsoft.com/en-us/windows/win32/fileio/reparse-points . All first failures stay in author/runs; actual diagnostic success and independent review remain required. This does not alter H01-H15 or confer G02 acceptance.
