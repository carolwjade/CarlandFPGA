"""Bounded fresh-file diagnostic; never retries a source after a rename attempt."""
import ctypes as C
import json
from pathlib import Path
import sys
import tempfile
from unittest import mock

base = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(base / "candidate"))
import layout_commit_windows as leaf

root = Path(tempfile.mkdtemp(prefix="diag-", dir=base / "runs"))
results = []
for mode in ("parent_relative", "null_absolute"):
    target = root / (mode + ".bin")
    native = {}

    def diagnostic_rename(api, source, parent, name):
        encoded = (name if mode == "parent_relative" else str(target)).encode("utf-16-le")
        size = max(C.sizeof(leaf._RenameInfo), leaf._RenameInfo.FileName.offset + len(encoded) + 2)
        count = (size + C.sizeof(leaf._RenameInfo) - 1) // C.sizeof(leaf._RenameInfo)
        buffer = (leaf._RenameInfo * count)()
        value = buffer[0]
        value.Flags = 0
        value.RootDirectory = parent if mode == "parent_relative" else None
        value.FileNameLength = len(encoded)
        C.memmove(C.addressof(buffer) + leaf._RenameInfo.FileName.offset, encoded, len(encoded))
        native.update(mode=mode, pointer_size=C.sizeof(C.c_void_p),
                      structure_size=C.sizeof(leaf._RenameInfo), buffer_size=size,
                      buffer_alignment=C.addressof(buffer) % C.alignment(leaf._RenameInfo),
                      offsets=[leaf._RenameInfo.RootDirectory.offset,
                               leaf._RenameInfo.FileNameLength.offset,
                               leaf._RenameInfo.FileName.offset],
                      supplied_parent=parent, actual_root_field=value.RootDirectory,
                      supplied_utf16_length=len(encoded), actual_length_field=value.FileNameLength,
                      buffer_hex=C.string_at(C.addressof(buffer), size).hex())
        ok = api.k.SetFileInformationByHandle(source, 3, C.byref(buffer), size)
        native["native_bool"] = bool(ok)
        native["native_error"] = None if ok else C.get_last_error()
        api._check(ok, "rename_failed")

    with mock.patch.object(leaf._Api, "rename", diagnostic_rename):
        result = leaf.commit_new(str(target), b"fresh source exactly once")
    results.append({"native": native, "result": result, "exists": target.exists(),
                    "bytes_hex": target.read_bytes().hex() if target.exists() else None})

out = {"scope": "Each mode uses distinct fresh source/target; no fallback or replay", "results": results}
(root / "diagnostic.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
print(json.dumps(out, indent=2))
