# Isolated Windows file-commit candidate

Task: `DEEPEYE-IMPLEMENTATION-20261014/v1`; work `A-G02-OWNED-WINDOWS-COMMIT-20261024-v1`; author `/root/save_commit_author`; native job `child-6028d1ce7e77489aa76a43160cfb93db`.

The final focused run passed **19 tests, exit 0**, in 0.485 seconds on Windows 11 build 26200, Python 3.12.14 AMD64, actual local NTFS. Evidence is `runs/green-003.txt`. This is an isolated candidate for independent review. Current `layout_store.gd` was not integrated or repaired; G02 acceptance is open. H03/G03/R03/all29 remain `not_run`.

`DEEPEYE-HUMAN-LOCK-20261014/revision1` was read in md/json and the requirements canonical JSON SHA256 was calculated as `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`. All H01–H15, including both H12 routes, remain unchanged. The activation record identifies A Gen3 `01a16988-bdcb-70e1-ae10-1304b5cf7875`; A alone operates the board. No board, display, engine, old suite, service/model activation, CLI/deployment, product write, commit, push, or group publication was performed by this author. External reads were primary documentation and required native-lease tool calls; no project network probe or peer message was initiated.

## Implemented behavior

`candidate/layout_commit_windows.py` exposes `commit_new(target, payload)` with `committed`, `already_exists`, `failed_before_publish`, or `outcome_unknown`. Import does not load a native DLL or initiate work. The leaf accepts opaque bytes at most 1 MiB and rejects unsupported path forms before file creation. It requires an existing ordinary absolute drive path, fixed local NTFS, and a direct `HarddiskVolume` drive mapping; it rejects reparse ancestry.

The source is exclusively acquired with `CREATE_NEW`, read/write/delete access, and a noninherited HANDLE. The same HANDLE performs checked write count, flush, exact readback and EOF verification, publication, and any failure disposition. Occupied temporary names are preserved and retries are finite. There is one no-replace `FileRenameInfo` publication attempt, no target pre-delete and no copy/rename fallback. Unknown publication outcomes only close the original HANDLE; they never disposition or replay it. Cleanup failures retain source identity and report a possible orphan. Close failures after known publication produce `outcome_unknown` while preserving `publication_confirmed=true`.

## Root-selected compatibility change

The first actual implementation used the documented parent-HANDLE/relative-name form. This host returned native FALSE/87. A fresh-file ABI diagnostic independently confirmed correct x64 offsets 8/16/20, UTF-16 byte counts, and aligned buffer bytes; a distinct fresh source using NULL plus an ordinary absolute target returned FALSE/32 because strict write-denying parent handles conflicted with Kernel32's operation. Neither source was retried.

Root explicitly selected a two-phase handover. Every ancestor is first opened read-only with write/delete sharing denied and checked. Under those strict handles, the exclusive owned source is created and verified. Each directory then receives a second read-desired handle that permits read/write sharing while still denying deletion. Every pair's volume/file identity is compared while all strict handles remain retained. Only after every pair matches are strict handles closed. The source keeps its parent nonempty, and pinned child directories keep higher ancestors nonempty. Publication then uses exactly one NULL-root, ordinary absolute drive target call. Failure cleanup performs no later pathname lookup.

The new diagnostic succeeded on a distinct fresh source: 14 exact identity pairs, actual parent and owned ancestor rename denials (32), actual valid junction-setting attempts denied as nonempty (145), then actual successful no-replace publication. All mutation attempts were confined to `runs/handover-cjestuto/holder` and its `parent`; external ancestors were only opened for read/identity verification. Normal tests independently exercise the resulting candidate.

This scope excludes drive remapping, privileged filter/namespace attacks, ACL or handle tampering, and power-loss durability. Existing incompatible directory writers cause an early closed failure. Concurrent callers may encounter transient sharing failures while another caller holds its strict phase; the leaf does not retry publication. No orphan sweeper, adoption, or replay mechanism exists.

## Actual evidence and preserved failures

| Record | Outcome |
|---|---|
| `runs/red-001.txt` | Harness error: missing `importlib.util`; retained. |
| `runs/red-002.txt` | Behavioral red: absent commit module; exit 1. |
| `runs/red-003-full.txt` | Full absent-module red; exit 1, including failed child rendezvous and recorded test-worker termination. |
| `runs/green-attempt-001.txt` | 14 tests, 7 failures; publication native 87. Original sources preserved in `runs/attempt-001-sources/`. |
| `runs/rename-diagnostic-001.txt` | Distinct-source relative/native87 versus absolute/native32; raw ABI buffers retained. |
| `runs/independent-branches-001.txt` | Four ABI, sharing, and uncertain-result branches passed. |
| `runs/handover-diagnostic-001.txt` | Fresh two-phase handover diagnostic succeeded; actual mutation denials and publication recorded. |
| `runs/red-004-handover.txt` | New handover behavioral red: retained strict handles still deny parent writes; exit 1. |
| `runs/green-attempt-002.txt` | 19 tests, one harness assertion failure: CRT reported truncate denial with `winerror=None`. |
| `runs/green-003.txt` | 19/19 passed; truncate probe uses direct Win32 `TRUNCATE_EXISTING` and records native error. |

Coverage includes empty, binary, Chinese/non-BMP payloads and filenames; exact 1 MiB bound; forbidden namespaces/aliases; missing parent; actual junction ancestry; existing directory target; occupied temporary names; held-source truncate/delete denial; ancestor rename denial; two independent spawned processes with one complete winner; and an external sentinel created after the caller's absent check with unchanged bytes and NTFS file identity.

Fault injection is explicitly software evidence. Invalid-handle write and missing-parent rename arguments obtain actual OS errors but are deliberately introduced arguments. Short-count, flush/readback, disposition, call-boundary response-loss, and close-response uncertainty are injected. One response-loss case first obtains a real successful OS publication, then raises in the wrapper; its published bytes remain intact and its result stays unknown without disposition or replay. Other intentionally unknown/cleanup-failed sources remain as preserved orphans. `orphan-inventory.json` inventories diagnostic paths and observed identities; it grants no deletion/adoption authority.

To run only these new tests, set test-only `LAYOUT_COMMIT_TEST_ROOT` to an existing owned filesystem evidence root, then run the sibling test file with the existing A interpreter and `-B -X utf8`. The test code contains no absolute author-directory constant. No old tests were replayed.

## Microsoft primary references

- [CreateFileW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew): exclusive creation, sharing, noninheritance and reparse/directory flags.
- [SetFileInformationByHandle](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-setfileinformationbyhandle): handle-based rename/disposition and checked BOOL/error semantics.
- [FILE_RENAME_INFO](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_rename_info): no-replace union and UTF-16 byte count. The current page's duplicated syntax field was not copied into the ABI.
- [NTFS reparse restrictions](https://learn.microsoft.com/en-us/windows/win32/fileio/reparse-points), [FSCTL_SET_REPARSE_POINT status](https://learn.microsoft.com/en-us/windows-hardware/drivers/ifs/fsctl-set-reparse-point): nonempty-directory restriction used by the root-selected handover.
- [Names and namespaces](https://learn.microsoft.com/en-us/windows/win32/fileio/naming-a-file), [QueryDosDeviceW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-querydosdevicew), [GetVolumeInformationByHandleW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getvolumeinformationbyhandlew), [file identity](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfileinformationbyhandle).

Candidate, tests, report, logs, diagnostic artifacts and preserved failures are frozen in `manifest.json` (excluding private lease material, the manifest itself, and subsequent terminal receipts). Root owns independent review, selection and integration. Native terminal completion/readback is recorded separately in `completion-receipt.json` and `completion-validation.json`.
