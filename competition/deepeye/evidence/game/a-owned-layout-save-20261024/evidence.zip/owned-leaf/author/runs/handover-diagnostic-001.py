"""Root-authorized fresh-source two-phase handover probe; no replay/fallback."""
import ctypes as C
import json
import os
from pathlib import Path
import struct
import sys
import tempfile
from unittest import mock

base = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(base / "candidate"))
import layout_commit_windows as leaf

root = Path(tempfile.mkdtemp(prefix="handover-", dir=base / "runs"))
holder = root / "holder"
parent = holder / "parent"
parent.mkdir(parents=True)
redirect = root / "redirect"
redirect.mkdir()
target = parent / "new.bin"
evidence = {"fresh_source_once": True, "handover": [], "mutation_attempts": []}
original_stage = leaf._Operation._stage


def identity(info):
    return [info.volume, info.index_high, info.index_low]


def stage_and_handover(op):
    original_stage(op)
    paths = [target.drive + "\\"]
    parts = str(parent)[3:].split("\\")
    paths.extend(paths[0] + "\\".join(parts[:i]) for i in range(1, len(parts) + 1))
    strict = op.directories[:]
    relaxed = []
    try:
        for path, old in zip(paths, strict):
            new = op.api.create(path, 0x81, 3, 3, 0x02200000)
            relaxed.append(new)
            old_id = identity(op.api.info(old))
            new_id = identity(op.api.info(new))
            if old_id != new_id:
                raise RuntimeError("parent identity changed during handover")
            evidence["handover"].append({"path": path, "strict_id": old_id,
                                         "second_id": new_id, "match": True})
        op.directories = relaxed
        for old in reversed(strict):
            op.api.close(old)
    except BaseException:
        for new in relaxed:
            op.api.close(new)
        raise
    for path in (parent, holder):
        try:
            os.rename(path, path.with_name(path.name + "-moved"))
            raise RuntimeError("unexpected parent rename success")
        except OSError as exc:
            evidence["mutation_attempts"].append({"operation": "rename", "path": str(path),
                                                   "winerror": exc.winerror})
        handle = op.api.create(str(path), 0x40000000, 3, 3, 0x02200000)
        try:
            substitute = ("\\??\\" + str(redirect)).encode("utf-16-le")
            printed = str(redirect).encode("utf-16-le")
            names = substitute + b"\0\0" + printed + b"\0\0"
            raw = struct.pack("<LHHHHHH", 0xa0000003, 8 + len(names), 0,
                              0, len(substitute), len(substitute) + 2, len(printed)) + names
            buf = C.create_string_buffer(raw)
            returned = leaf.W.DWORD()
            native = op.api.k.DeviceIoControl
            native.argtypes = [leaf.W.HANDLE, leaf.W.DWORD, C.c_void_p, leaf.W.DWORD,
                               C.c_void_p, leaf.W.DWORD, C.POINTER(leaf.W.DWORD), C.c_void_p]
            native.restype = leaf.W.BOOL
            ok = native(handle, 0x900a4, buf, len(raw), None, 0, C.byref(returned), None)
            error = None if ok else C.get_last_error()
            evidence["mutation_attempts"].append({"operation": "FSCTL_SET_REPARSE_POINT",
                "path": str(path), "native_bool": bool(ok), "winerror": error,
                "valid_junction_payload_hex": raw.hex()})
            if ok or error != 145:
                raise RuntimeError("expected actual ERROR_DIR_NOT_EMPTY=145")
        finally:
            op.api.close(handle)


def null_absolute(api, source, parent_handle, name):
    encoded = str(target).encode("utf-16-le")
    size = max(C.sizeof(leaf._RenameInfo), leaf._RenameInfo.FileName.offset + len(encoded) + 2)
    buffer = (leaf._RenameInfo * ((size + 23) // 24))()
    buffer[0].Flags = 0
    buffer[0].RootDirectory = None
    buffer[0].FileNameLength = len(encoded)
    C.memmove(C.addressof(buffer) + leaf._RenameInfo.FileName.offset, encoded, len(encoded))
    ok = api.k.SetFileInformationByHandle(source, 3, C.byref(buffer), size)
    evidence["publish_native_bool"] = bool(ok)
    evidence["publish_native_error"] = None if ok else C.get_last_error()
    api._check(ok, "rename_failed")


with mock.patch.object(leaf._Operation, "_stage", stage_and_handover), \
        mock.patch.object(leaf._Api, "rename", null_absolute):
    result = leaf.commit_new(str(target), b"root-authorized handover fresh source")
evidence["result"] = result
evidence["target_exists"] = target.exists()
evidence["bytes_hex"] = target.read_bytes().hex() if target.exists() else None
(root / "diagnostic.json").write_text(json.dumps(evidence, indent=2), encoding="utf-8")
print(json.dumps(evidence, indent=2))
if not result["ok"]:
    sys.exit(1)
