"""New Windows-only filesystem tests; all retained artifacts live under author/runs."""
import importlib
import importlib.util
import ctypes
import json
import multiprocessing
import os
import pathlib
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


RUNS = pathlib.Path(__file__).resolve().parents[1] / "runs"


def competing_writer(target, payload, channel):
    import layout_commit_windows as leaf

    class Rendezvous(leaf._Operation):
        def _stage(self):
            super()._stage()
            channel.send({"ready": True, "pid": os.getpid(), "source": self.temp_path})
            if not channel.poll(20) or channel.recv() != "publish":
                raise RuntimeError("test rendezvous timed out")

    result = Rendezvous(target, payload).run()
    channel.send({"result": result, "pid": os.getpid()})
    channel.close()


class CommitWindowsTests(unittest.TestCase):
    def setUp(self):
        RUNS.mkdir(exist_ok=True)
        self.root = pathlib.Path(tempfile.mkdtemp(prefix="t-", dir=RUNS))

    def record(self, **evidence):
        (self.root / "evidence.json").write_text(
            json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")

    def leaf(self):
        return importlib.import_module("layout_commit_windows")

    def assert_failed_clean(self, result, target):
        self.assertEqual(result["state"], "failed_before_publish", result)
        self.assertFalse(result["ok"], result)
        self.assertFalse(target.exists())
        self.assertEqual(list(self.root.glob(".lc-*.tmp")), [])
        self.assertFalse(result["cleanup"]["orphan_possible"], result)

    def test_empty_new_file_is_committed_and_existing_file_is_preserved(self):
        # Catches publication that overwrites an existing target or claims success early.
        spec = importlib.util.find_spec("layout_commit_windows")
        self.assertIsNotNone(spec, "the retained-HANDLE commit leaf is absent")
        leaf = importlib.import_module("layout_commit_windows")
        target = self.root / "empty.json"
        result = leaf.commit_new(str(target), b"")
        self.assertEqual(result["state"], "committed", result)
        self.assertTrue(result["ok"], result)
        self.assertEqual(target.read_bytes(), b"")
        before = target.stat().st_ino
        collision = leaf.commit_new(str(target), b"must not replace")
        self.assertEqual(collision["state"], "already_exists", collision)
        self.assertFalse(collision["ok"])
        self.assertEqual(target.read_bytes(), b"")
        self.assertEqual(target.stat().st_ino, before)
        self.record(first=result, collision=collision, inode_before=before,
                    inode_after=target.stat().st_ino)

    def test_unicode_and_binary_payload_roundtrip_and_limit(self):
        # Catches wrong UTF-16 byte lengths, payload decoding, or a missing bound.
        leaf = self.leaf()
        parent = self.root / "中文😀"
        parent.mkdir()
        payload = "水层🛠️\u0000红门".encode("utf-8") + bytes(range(256))
        target = parent / "布局🚀.json"
        result = leaf.commit_new(str(target), payload)
        self.assertEqual(result["state"], "committed", result)
        self.assertEqual(target.read_bytes(), payload)
        full = self.root / "one-mib.bin"
        self.assertTrue(leaf.commit_new(str(full), b"x" * 1048576)["ok"])
        self.assertEqual(full.stat().st_size, 1048576)
        oversized = self.root / "over.bin"
        self.assert_failed_clean(leaf.commit_new(str(oversized), b"x" * 1048577), oversized)
        wrong = self.root / "type.bin"
        self.assert_failed_clean(leaf.commit_new(str(wrong), bytearray(b"x")), wrong)
        self.record(result=result, exact_payload_hex=payload.hex())

    def test_two_real_processes_no_replace_race_has_one_complete_winner(self):
        # Catches check-then-replace, shared source names, or incomplete winners.
        target = self.root / "race.bin"
        ctx = multiprocessing.get_context("spawn")
        payloads = [b"A" * 8193, b"B" * 16387]
        children, channels, ready, results = [], [], [], []
        try:
            for payload in payloads:
                parent, child = ctx.Pipe()
                proc = ctx.Process(target=competing_writer, args=(str(target), payload, child))
                proc.start()
                child.close()
                children.append(proc)
                channels.append(parent)
            for channel in channels:
                self.assertTrue(channel.poll(20), "child failed to rendezvous")
                ready.append(channel.recv())
            self.assertTrue(all(item.get("ready") for item in ready), ready)
            self.assertEqual(len({item["pid"] for item in ready}), 2)
            self.assertFalse(target.exists())
            for channel in channels:
                channel.send("publish")
            for channel in channels:
                self.assertTrue(channel.poll(20), "child failed to finish")
                results.append(channel.recv()["result"])
            for proc in children:
                proc.join(20)
                self.assertEqual(proc.exitcode, 0)
            self.assertEqual(sorted(r["state"] for r in results),
                             ["already_exists", "committed"], results)
            winner = next(i for i, r in enumerate(results) if r["ok"])
            self.assertEqual(target.read_bytes(), payloads[winner])
            self.assertEqual(list(self.root.glob(".lc-*.tmp")), [])
            self.record(ready=ready, results=results, winner=winner,
                        process_exitcodes=[p.exitcode for p in children])
        finally:
            for channel in channels:
                channel.close()
            for proc in children:
                if proc.is_alive():
                    proc.terminate()
                    proc.join(10)
                    self.fail("test worker needed termination; inspect retained evidence")

    def test_external_sentinel_created_after_absent_check_keeps_bytes_and_identity(self):
        # Catches replacing a target created by an uncooperative external writer.
        leaf = self.leaf()
        target = self.root / "sentinel.bin"
        self.assertFalse(target.exists())
        original_stage = leaf._Operation._stage
        before = {}

        def stage_then_external_create(op):
            original_stage(op)
            with target.open("xb") as f:
                f.write(b"external sentinel\x00\xff")
            before["ino"] = target.stat().st_ino

        with mock.patch.object(leaf._Operation, "_stage", stage_then_external_create):
            result = leaf.commit_new(str(target), b"caller losing payload")
        self.assertEqual(result["state"], "already_exists", result)
        self.assertEqual(target.read_bytes(), b"external sentinel\x00\xff")
        self.assertEqual(target.stat().st_ino, before["ino"])
        self.assertFalse(result["cleanup"]["orphan_possible"])
        self.record(result=result, inode_before=before["ino"], inode_after=target.stat().st_ino)

    def test_occupied_temp_name_is_not_opened_and_retry_is_bounded(self):
        # Catches temp adoption/truncation and unbounded CREATE_NEW collisions.
        leaf = self.leaf()
        occupied = self.root / (".lc-" + "a" * 32 + ".tmp")
        occupied.write_bytes(b"not owned")
        before = occupied.stat().st_ino
        target = self.root / "occupied.bin"
        with mock.patch.object(leaf.secrets, "token_hex", return_value="a" * 32):
            result = leaf.commit_new(str(target), b"new")
        self.assertEqual(result["state"], "failed_before_publish", result)
        self.assertEqual(result["code"], "temp_names_exhausted", result)
        self.assertEqual(occupied.read_bytes(), b"not owned")
        self.assertEqual(occupied.stat().st_ino, before)
        self.assertFalse(target.exists())
        with mock.patch.object(leaf.secrets, "token_hex", side_effect=["a" * 32, "b" * 32]):
            retried = leaf.commit_new(str(target), b"new")
        self.assertTrue(retried["ok"], retried)
        self.assertEqual(occupied.read_bytes(), b"not owned")
        self.record(exhausted=result, then_new_name=retried, occupied_inode=before)

    def test_retained_source_denies_external_truncate_delete_and_ancestor_rename(self):
        # Catches closing/reopening the source or releasing ancestry too early.
        leaf = self.leaf()
        parent = self.root / "ordinary"
        parent.mkdir()
        target = parent / "owned.bin"
        original_stage = leaf._Operation._stage
        denied = {}

        def stage_then_external_attempts(op):
            original_stage(op)
            for name, action in [
                ("truncate", lambda: open(op.temp_path, "wb")),
                ("delete", lambda: os.unlink(op.temp_path)),
                ("rename_parent", lambda: os.rename(parent, self.root / "moved")),
            ]:
                try:
                    unexpected = action()
                    if hasattr(unexpected, "close"):
                        unexpected.close()
                    denied[name] = "unexpected_success"
                except OSError as exc:
                    denied[name] = exc.winerror

        with mock.patch.object(leaf._Operation, "_stage", stage_then_external_attempts):
            result = leaf.commit_new(str(target), b"original retained bytes")
        self.assertTrue(result["ok"], result)
        self.assertTrue(all(isinstance(x, int) for x in denied.values()), denied)
        self.assertEqual(len(denied), 3)
        self.assertEqual(target.read_bytes(), b"original retained bytes")
        self.record(result=result, actual_win32_denials=denied)

    def test_directory_target_collision_keeps_directory_and_cleans_source(self):
        leaf = self.leaf()
        target = self.root / "directory"
        target.mkdir()
        marker = target / "keep"
        marker.write_bytes(b"directory contents")
        inode = target.stat().st_ino
        result = leaf.commit_new(str(target), b"cannot replace dir")
        self.assertIn(result["state"], ["already_exists", "failed_before_publish"], result)
        self.assertEqual(target.stat().st_ino, inode)
        self.assertEqual(marker.read_bytes(), b"directory contents")
        self.assertEqual(list(self.root.glob(".lc-*.tmp")), [])
        self.record(result=result, directory_inode=inode)

    def test_rejects_namespace_aliases_and_missing_parent_without_creating_files(self):
        # Catches normalization before validation or accepting unsupported namespaces.
        leaf = self.leaf()
        base = str(self.root)
        bad = ["relative.bin", "C:relative.bin", "\\\\server\\share\\x",
               "\\\\?\\" + base + "\\x", "\\\\.\\C:\\x", "\\??\\C:\\x",
               base + "\\x:stream", base + "\\..\\x", base + "\\.\\x",
               base + "\\x.", base + "\\x ", base + "\\CON.txt", base + "\\NUL",
               base + "\\COM¹.txt", base + "\\LPT9", base + "\\a<b", base + "\\a?b",
               base + "\\a\x00b", base + "\\a\x01b", base + "\\\ud800",
               base + "\\" + "z" * 260, base + "\\\\x", base + "/x"]
        outcomes = []
        for value in bad:
            with self.subTest(path=repr(value)):
                result = leaf.commit_new(value, b"x")
                self.assertEqual(result["state"], "failed_before_publish", result)
                self.assertEqual(result["code"], "invalid_path", result)
                outcomes.append({"path": repr(value), "state": result["state"], "code": result["code"]})
        missing = self.root / "missing" / "x"
        result = leaf.commit_new(str(missing), b"x")
        self.assertEqual(result["state"], "failed_before_publish", result)
        self.assertFalse(missing.parent.exists())
        self.assertEqual(list(self.root.iterdir()), [])
        self.record(rejected=outcomes, missing_parent=result)

    def test_actual_junction_ancestry_is_rejected(self):
        # Catches following a preexisting reparse parent into another location.
        leaf = self.leaf()
        real = self.root / "real"
        link = self.root / "junction"
        real.mkdir()
        # cmd is used only to CREATE this local junction; no cmd deletion/move.
        proc = subprocess.run(["cmd.exe", "/d", "/c", "mklink", "/J", str(link), str(real)],
                              capture_output=True, text=True, encoding="utf-8", errors="replace")
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        result = leaf.commit_new(str(link / "x"), b"never follow")
        self.assertEqual(result["state"], "failed_before_publish", result)
        self.assertEqual(result["code"], "reparse_ancestor", result)
        self.assertEqual(list(real.iterdir()), [])
        self.record(result=result, junction_create_exit=proc.returncode,
                    junction_create_stdout=proc.stdout)

    def test_actual_write_and_rename_api_failure_clean_owned_source(self):
        # Actual OS errors, not synthetic success/error values.
        leaf = self.leaf()
        write = leaf._Api.write
        rename = leaf._Api.rename
        target = self.root / "real-errors.bin"

        def real_bad_write(api, handle, payload):
            return write(api, ctypes.c_void_p(-1).value, payload)

        with mock.patch.object(leaf._Api, "write", real_bad_write):
            write_result = leaf.commit_new(str(target), b"x")
        self.assert_failed_clean(write_result, target)
        self.assertEqual(write_result.get("winerror"), 6, write_result)

        def real_bad_rename(api, handle, parent, name):
            return rename(api, handle, parent, "absent-subdirectory\\x")

        with mock.patch.object(leaf._Api, "rename", real_bad_rename):
            rename_result = leaf.commit_new(str(target), b"x")
        self.assert_failed_clean(rename_result, target)
        self.assertIsInstance(rename_result.get("winerror"), int)
        self.record(actual_os_error_with_injected_invalid_argument={
            "write": write_result, "rename": rename_result})

    def test_injected_short_write_flush_and_readback_fail_before_publish(self):
        # Explicit software fault injection; these are not physical OS faults.
        leaf = self.leaf()
        target = self.root / "injected.bin"
        outcomes = {}

        def short_write(api, handle, payload):
            raise leaf._Failure("short_write")

        def flush_error(api, handle):
            raise leaf._Failure("flush_failed", 1117)

        for name, method, replacement in [
            ("short_write", "write", short_write),
            ("flush_failure", "flush", flush_error),
            ("readback_mismatch", "read", lambda *args: b"wrong"),
            ("readback_extra", "read", lambda *args: b"payloadX"),
        ]:
            with self.subTest(injection=name):
                with mock.patch.object(leaf._Api, method, replacement):
                    result = leaf.commit_new(str(target), b"payload")
                self.assert_failed_clean(result, target)
                outcomes[name] = result
        self.record(software_fault_injections=outcomes)

    def test_injected_lost_response_after_real_publish_is_unknown_and_not_replayed(self):
        # Real successful rename followed by a synthetic lost wrapper response.
        leaf = self.leaf()
        target = self.root / "response.bin"
        real_rename = leaf._Api.rename
        publications = []

        def published_then_response_lost(api, handle, parent, name):
            real_rename(api, handle, parent, name)
            publications.append("actual_SetFileInformationByHandle_success")
            raise RuntimeError("injected response loss after OS success")

        with mock.patch.object(leaf._Api, "rename", published_then_response_lost):
            op = leaf._Operation(str(target), b"actually published")
            result = op.run()
            repeated_private_run = op.run()
        self.assertEqual(result["state"], "outcome_unknown", result)
        self.assertFalse(result["ok"])
        self.assertEqual(target.read_bytes(), b"actually published")
        self.assertEqual(publications, ["actual_SetFileInformationByHandle_success"])
        self.assertEqual(repeated_private_run, result)
        self.assertFalse(result["cleanup"]["attempted"])
        self.record(real_success_then_software_response_loss=result,
                    native_success_evidence=publications,
                    repeated_private_run=repeated_private_run)

    def test_injected_cleanup_failure_reports_retained_orphan_identity(self):
        leaf = self.leaf()
        target = self.root / "cleanup.bin"

        def bad_flush(api, handle):
            raise leaf._Failure("flush_failed", 1117)

        def bad_dispose(api, handle):
            raise leaf._Failure("disposition_failed", 5)

        with mock.patch.object(leaf._Api, "flush", bad_flush), \
                mock.patch.object(leaf._Api, "dispose", bad_dispose):
            result = leaf.commit_new(str(target), b"owned orphan")
        self.assertEqual(result["state"], "failed_before_publish", result)
        self.assertTrue(result["cleanup"]["orphan_possible"], result)
        orphan = pathlib.Path(result["cleanup"]["source_path_at_creation"])
        self.assertEqual(orphan.read_bytes(), b"owned orphan")
        self.assertEqual(orphan.stat().st_ino, result["cleanup"]["identity"]["file_index"])
        self.assertFalse(target.exists())
        # The orphan remains preserved as evidence; tests do not sweep/adopt it.
        self.record(software_cleanup_fault=result, retained_orphan=str(orphan))

    def test_import_has_no_file_or_native_library_io(self):
        # Catches accidental native load, output creation, or service startup at import.
        script = """
import ctypes, sys
def forbidden(*args, **kwargs):
    raise AssertionError('import performed native I/O')
ctypes.WinDLL = forbidden
def audit(event, args):
    if event in ('os.mkdir', 'os.remove', 'os.rename', 'subprocess.Popen', 'socket.connect'):
        raise AssertionError('import side effect: ' + event)
sys.addaudithook(audit)
import layout_commit_windows
print('import_without_native_or_filesystem_mutation')
"""
        proc = subprocess.run([sys.executable, "-B", "-X", "utf8", "-c", script],
                              cwd=pathlib.Path(__file__).parent, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.record(exit_code=proc.returncode, stdout=proc.stdout, stderr=proc.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
