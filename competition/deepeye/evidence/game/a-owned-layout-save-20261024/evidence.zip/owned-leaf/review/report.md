# Independent static review of the owned Windows commit leaf

Work `A-G02-OWNED-COMMIT-CODE-REVIEW-20261024-v1`, agent `/root/save_commit_code_review`, native job `child-e0ab0185d0b54e099ef4e6e76f844ad4`. Only this `review/` subtree was written. Root Gen3 remains the selection and acceptance owner.

No blocking finding was identified in the public `commit_new(target, payload)` path within the revised plan's ordinary-writer, fixed local NTFS boundary. This is a source-and-saved-evidence review, not an independent execution result or product acceptance.

## Identity and scope

- Read AGENTS.md, project A skill/role/protocol, current activation/handoff, revised plan, immutable scope md/json, full candidate and tests, pinned primary documents, author report/result and selected actual diagnostics/logs.
- Canonical UTF-8 requirements JSON (`ensure_ascii=False, sort_keys=True, separators=(",", ":")`) independently hashes to `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`. H01–H15 and both full H12 control routes remain unchanged. Existing node configuration identifies A; activation identifies `01a16988-bdcb-70e1-ae10-1304b5cf7875`, generation 3.
- Independently verified all 33 author manifest members by raw byte size/SHA256, with zero mismatches. Author manifest SHA256: `16a7d2cede5060d73c630073e20038409e8b7a3bbdadd2206699d75a119bae95`.
- Independently verified all 21 preflight manifest members, with zero mismatches. Preflight manifest SHA256: `ae5bd4f25cdfe6320bd4834db069031c40932936b2a940338b17482afb9ce934`.
- No candidate import, test execution, ctypes/native call, engine, board, service activation, network/peer/group operation, product write, commit or push was performed. Standard-library Python was used only for canonical JSON/hash calculation. No variable fixture runstate was read.
- The author's saved native completion receipt records completed/terminal/stale=false. Its later validate receipt correctly rejects the already completed lease. This reviewer validated its own canonical lease before work and after interruption.

## Source findings and reasoning

References below are line numbers in frozen `author/candidate/layout_commit_windows.py`.

| Area | Independent observation |
| --- | --- |
| ABI (41–60, 100–134, 187–207) | BOOLEAN/ULONG union occupies one slot; pointer/length/name offsets are checked as 8/16/20 on x64 and 4/8/12 on x86. The variable buffer is structure-aligned and zero-initialized, its UTF-16 byte length excludes the terminator, and allocation includes terminator space. FileRenameInfo=3, FileDispositionInfo=4 and all HANDLE/BOOL signatures agree with pinned SDK/header/API source. Actual runtime evidence is AMD64; no x86 execution is claimed. |
| Path/volume policy (70–97, 151–163, 231–253) | Validation precedes native creation and rejects unsupported namespaces, relative/traversal/ADS/reserved/alias forms, controls, lone surrogates and excessive UTF-16 lengths. Actual DRIVE_FIXED, direct HarddiskVolume mapping and handle-derived NTFS are checked. Each ancestor is opened without following its final reparse component, verified ordinary and retained. Directory hard links, drive remapping, ACL/privileged/filter manipulation are not silently brought into this guarantee. |
| Retained source (254–277) | CREATE_NEW, share=0 and NULL security attributes establish an exclusive, noninherited read/write/delete HANDLE before later calls. Eight temp-name attempts are finite and occupied names are never opened or truncated. Write count, flush, byte-for-byte readback and EOF verification use that same HANDLE. Payload is opaque bytes up to 1 MiB. |
| Two-stage ancestry (279–307) | All strict handles remain held until every replacement read-desired/share-READ-WRITE/no-share-DELETE handle is acquired, volume/file identity matched, and ordinary-directory status checked. Only then are strict handles released. The retained temp keeps its final parent nonempty; each pinned child keeps higher ancestors nonempty. Thus the documented NTFS nonempty-directory reparse restriction and continuous no-delete sharing close the stated ordinary namespace race. Failure disposes/closes only owned handles and performs no later path lookup. |
| Publication/outcome (309–324) | There is one NULL-root, absolute-target, ReplaceIfExists=FALSE rename in the public path. No target pre-delete, copy/ordinary rename fallback or runtime relative/absolute retry appears. State becomes unknown before the call; trustworthy FALSE becomes a known failure/collision, while other exceptions preserve unknown. |
| Cleanup (326–371) | Known prepublication failure marks only the original owned HANDLE for deletion. Committed/unknown outcomes never disposition it. Cleanup/close failures retain identity and possible-orphan diagnostics; ambiguous CloseHandle is not retried. A close failure after confirmed publication remains unknown with publication_confirmed=true. |

Two questions raised by root are nonblocking for the current public scope:

1. `_publish` catches every `_Failure` (317–321), but the default `_Api.rename` has exactly one `_Failure` origin: `_check` after the native BOOL returned FALSE (136–138, 201–202). Encoding/allocation/ctypes/signal exceptions do not turn into that class. A future wrapper must not raise `_Failure` after successful publication; the current wrapper does not do so. The saved lost-response test deliberately raises RuntimeError after real success and stays unknown without disposition.
2. The private `_publish` docstring promise is not enforced by a guard on that method. However, public `commit_new` (389–395) creates a fresh unexposed operation, and `run` (373–386) invokes publication once and returns its cached result on subsequent sequential calls. Direct/reentrant/concurrent invocation of private methods or same-process monkeypatching is outside this public API. An internal guard would be optional hardening, not a demonstrated public no-replay defect.

## Recorded execution evidence

The reviewed final log `author/runs/green-003.txt` records 19 tests, zero failures/errors, 0.485 seconds, exit_code=0. Raw SHA256 is `30cfda9759acb6ad1290690628a6479e8481e0dcdc4f8ae3106e3a1d340c056f`. This is the author's actual focused Windows NTFS run, independently read and byte-verified here; no new test run was performed.

The 19 tests cover actual competing spawned processes, an external sentinel after an absent check with preserved bytes/file identity, occupied temporary names, retained source truncate/delete and ancestor rename denials, actual existing junction rejection, directory collision, Unicode/binary/empty data, 1 MiB boundary, missing parent, path rejection, ABI/noninheritance, import isolation and labeled failure branches. Recorded race evidence has two distinct PIDs, one committed result, one already_exists/183 result and both child exits 0.

The fresh handover diagnostic records 14 exact ancestor identity pairs, parent/ancestor rename FALSE/32, valid junction-setting FALSE/145, then successful no-replace publication on a distinct source. It supports the revised two-stage design. The diagnostic scripts describe historical four-argument private wrappers; their preserved output is historical evidence, while the final 19-test source exercises the final two-argument implementation. They must not be rerun blindly against the final candidate.

Preserved earlier evidence is consistent with the report: missing-import harness error, absent-module behavioral red, the original 14-test run with 7 failures/native 87, distinct-source relative FALSE/87 versus strict-parent absolute FALSE/32, the new handover red, and the 19-test intermediate run whose sole assertion failure was CRT truncate `winerror=None`. The final test uses direct native TRUNCATE_EXISTING for that denial; the original failure remains retained.

Fault-injection labels are accurate: invalid HANDLE/missing-parent arguments elicit real OS errors but were deliberately injected; short count, flush/readback/disposition and response/close uncertainty are software injections. One lost-response test first performs a real successful OS rename. None establishes a physical OS fault occurrence.

Test setup requires an explicit existing `LAYOUT_COMMIT_TEST_ROOT`, creates each new child directory beneath its resolved value, and has no hard-coded author path. The environment is a harness-owned destination choice, not an ownership sandbox; the inspected retained artifact paths are under the authorized author/runs. Random attempts, path/payload sizes, process rendezvous and joins are bounded. This is no strict deadline guarantee for synchronous OS calls. The normal recorded worker lifecycle closes; failed/interrupted records and intentionally uncertain/cleanup-failed orphans remain preserved without sweep/adoption.

## Limits left with root

The pinned preflight documents are primary-source snapshots, not runtime success. The first relative/native87 and strict-parent NULL/absolute/native32 remain failures, never fallbacks. The current public candidate satisfies the revised source design as reviewed, but selection is solely root's decision.

This primitive does not repair the unchanged GDScript `LayoutStore.save_new` caller. Caller integration must separately preserve codec/UTF-8/editor state, missing-parent behavior and unknown-result no-replay through its own pinned one-shot protocol and new scoped caller evidence. No old suite rerun is requested. G02 acceptance stays open; H03/G03/R03/all29 remain not_run. No physical control or power-loss durability claim follows from these files.
