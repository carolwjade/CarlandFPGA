# G02 Save As 原子性：只读设计

绑定产品 `5398cd76e5b5e277ad14053e1786ea014b90260e`，`layout_store.gd` SHA `752b023361b3ae935214dcef8beedc22e3722c66f0bdf1cef5b20939a91696a5`。Gen3 active；H01–H15 canonical SHA 实算仍为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`。本节点只研究，0 candidate import/tests/Godot/目标 native 调用，无产品修改。

## 已核实的缺口

1. **目标 no-overwrite race 成立。** `save_new` 最后检查目标不存在后，另一个 writer 创建目标；exact Godot Windows `DirAccessWindows::rename` 的普通不同名分支随后检查到该文件，先 `remove(new_path)`，再 `MoveFileW`。故可删除/替换后来者；若后续 move 失败，后来者也可能已丢失。若目标是在内部检查之后才出现，则 MoveFileW 可失败而保留它；不能把所有交错混称为“rename 必然替换”。[Godot 原实现](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/drivers/windows/dir_access_windows.cpp#L306)；[MoveFileW 的目标须不存在](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-movefilew)。
2. **临时文件 ownership 也未闭合。** PID/tick/候选后缀只是名字；check→`FileAccess.WRITE` 不是独占创建，Windows 普通 WRITE 使用 `wb`。同进程并行调用若选到同名，或外部 writer 抢占/改写该路径，可被截断、污染；校验后到发布前仍有窗口，按名字 `_remove_temp` 也可能删他人替换的文件。不同进程 PID 不同，不能声称它们自然产生同一个 temp 名。`FileAccess.create_temp` 在该 exact 版本也先 exists 后普通 WRITE，不是修复；不应切全局 backup-save 模式绕过。[FileAccess Windows](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/drivers/windows/file_access_windows.cpp#L116)；[create_temp](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/core/io/file_access.cpp#L83)。

现有 `_on_file_selected` 是同步无 await 的 handler，普通单主线程一次 Save As 不等于已观察到并发失败。缺口涉及并行调用、第二应用进程及不合作外部 writer。旧文档已明确限制；旧独立 review 的原 rename-probe 确有 `RENAME_EXISTING_ERR=0`、目标变为 `NEW\\n`。这是复用旧平台记录，不是本次新 race 实验。旧顺序保存/重开与 native UI 记录也不证明并发安全。

## 三种最小方案

| 方案 | 单进程 / 多进程 | 外部 writer / 代价 |
|---|---|---|
| 纯 Godot：进程互斥 + `make_dir_absolute` 独占锁目录，失败关闭、不自动清陈旧锁 | 可协调本应用守约调用；需统一路径命名才能跨实例 | 不合作 writer 不遵守锁，原 rename 仍可删目标。只能承诺合作范围，不能作为完整修复。 |
| **推荐供 root 选定：A 本机一次调用的 owned 原生文件提交 helper**，沿现有受控 Python 运行时部署、固定入口/hash；不是新常驻服务 | 每次由新 `CREATE_NEW` 原 HANDLE 拥有 temp；无需靠应用锁竞争最终名 | 同一受支持本地文件系统，以 no-replace HANDLE rename 拒绝先占目标。新增很小的受控进程/结果协议和发行依赖。 |
| Godot 内 GDExtension 暴露同一窄文件提交叶函数 | 同样的原生保证，保留同步 `save_new` 签名，无额外 helper 进程 | 需要新的已 pin 二进制/ABI/build。适合独立 Godot 分发；现有项目未发现已接入此能力，不能声称已有。 |

检查范围内的 `simulation/isolation/win32.py` 是 actor 隔离辅助，`cpu_invocation_transcript.py` 是原始管道调用账本；二者不是现成 Save As broker，不复用旧 job/HANDLE、motion gate 或服务。推荐方案 2 是新受控入口的设计建议，未获实施授权。

## 推荐边界与提交语义

只替换 `LayoutStore.save_new` 的文件提交边界；保留 caller 的显式路径、1 MiB、opaque UTF-8 字节、codec/编辑状态检查、错误时文档不变和普通 JSON 格式。**helper 必须从 temp 创建起拥有整个写入/验证/发布，不能只替换最后 rename。**

在目标同目录/同文件系统用 `CreateFileW(CREATE_NEW, GENERIC_READ|GENERIC_WRITE|DELETE)` 取得不可继承的原 temp HANDLE，拒绝共享写/删除；严格检查写入 count，沿同一 HANDLE 校验完整字节。持有该 HANDLE 调用 `SetFileInformationByHandle(FileRenameInfo)`，`ReplaceIfExists=FALSE`，不先删目标、不 ReplaceFile、不 copy fallback；碰撞应返回 already_exists，其他错误保持失败。清理仅针对确定自己拥有的对象，不能按未确认路径删除；发布后收据丢失/中断返回 outcome_unknown，不自动再写。[创建与共享语义](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew)；[no-replace rename 结构](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_rename_info)；[原 HANDLE API](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-setfileinformationbyhandle)。

拟保证是“本次提交不删除/覆盖提交点已存在的目标，发布的是本次拥有的完整 payload”，不是断电持久化或永远禁止其他有权进程随后改文件。未来需明确支持的本地 filesystem/路径，验证父目录身份与 reparse/别名策略；若父目录被恶意换链、远端 provider 或权限不满足，拒绝或另行设计，不能先声称通用保证。API 文档是设计依据，尚无本机 HANDLE rename 实证；FileAccess cached flush error 也不能升级为 native flush 成功。

## 最少新增验证（本次均未执行）

- 复用旧 probe，新增一条有 barrier 的“旧最终检查后，外部 writer 先创建 sentinel”反例；新提交必须拒绝并保持 sentinel 字节/身份。
- 两个独立进程同时提交不同 payload 到一个新目标：至多一个 committed，另一方不覆盖；目标是完整胜者字节，临时清理互不干扰。
- 抢占 temp 名/尝试在原 HANDLE 持有期改写或删除；不截断已有文件、不发布被换内容。覆盖创建目录占位、Unicode/路径别名和明确不支持的 namespace。
- 短写/校验或 rename 失败不发布；发布后响应丢失是 unknown、无重放，不能伪报成功或删除先占者。校验绑定实际 OS 返回，不做仅镜像实现的测试。
- 小型新 G02 保存/重开 caller 集成检查：保持编辑/取消/失败的文档状态及真实 UI 反馈；不重跑旧618/696/旧套件，也不把文件原语证据当完整 G02。

详细交错与来源在 design.json/source-line-spans.json/source-pins.json。原13个源/记录 pins、C4/index/cache末次逐 byte 对照后封存；root 决定下一实施。H01–H15/full H12 未改，G03/R03/all29=`not_run`。
