$ErrorActionPreference = 'Stop'
$taskRoot = (Get-Location).Path
$ownedRoot = [System.IO.Path]::GetFullPath((Join-Path $taskRoot '.planning/deepeye-resume-20261018/g02-owned-file-commit-20261024/preflight'))
$expectedSuffix = '\g02-owned-file-commit-20261024\preflight'
if (-not $ownedRoot.EndsWith($expectedSuffix)) { throw 'Unexpected owned directory' }
[System.IO.Directory]::CreateDirectory((Join-Path $ownedRoot 'sources')) | Out-Null
[System.IO.Directory]::CreateDirectory((Join-Path $ownedRoot 'inputs')) | Out-Null
$requestHeaders = @{ 'User-Agent' = 'CarlandFPGA-ReadOnly-Preflight'; Accept = 'application/vnd.github+json' }
$sdkCommit = (Invoke-RestMethod -Uri 'https://api.github.com/repos/MicrosoftDocs/sdk-api/commits/docs' -Headers $requestHeaders).sha
$headerCommit = (Invoke-RestMethod -Uri 'https://api.github.com/repos/microsoft/win32metadata/commits/main' -Headers $requestHeaders).sha
$sdkSpecs = @(
  @('rename_info', 'winbase/ns-winbase-file_rename_info.md'),
  @('createfilew', 'fileapi/nf-fileapi-createfilew.md'),
  @('set_information', 'fileapi/nf-fileapi-setfileinformationbyhandle.md'),
  @('disposition_info', 'winbase/ns-winbase-file_disposition_info.md'),
  @('volume_information', 'fileapi/nf-fileapi-getvolumeinformationbyhandlew.md'),
  @('drive_type', 'fileapi/nf-fileapi-getdrivetypew.md'),
  @('attribute_tag', 'winbase/ns-winbase-file_attribute_tag_info.md')
)
$sourceRecords = @()
foreach ($entry in $sdkSpecs) {
  $rel = 'sdk-api-src/content/' + $entry[1]
  $pin = 'https://raw.githubusercontent.com/MicrosoftDocs/sdk-api/' + $sdkCommit + '/' + $rel
  $dst = Join-Path $ownedRoot ('sources/' + $entry[0] + '.md')
  Invoke-WebRequest -Uri $pin -OutFile $dst
  $sourceRecords += [ordered]@{ id = $entry[0]; owner = 'MicrosoftDocs/sdk-api'; revision = $sdkCommit; url = $pin; path = 'sources/' + $entry[0] + '.md'; sha256 = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$headerUrl = 'https://raw.githubusercontent.com/microsoft/win32metadata/' + $headerCommit + '/generation/WinSDK/RecompiledIdlHeaders/um/WinBase.h'
$headerDst = Join-Path $ownedRoot 'sources/WinBase.h'
Invoke-WebRequest -Uri $headerUrl -OutFile $headerDst
$sourceRecords += [ordered]@{ id = 'sdk_header'; owner = 'microsoft/win32metadata'; revision = $headerCommit; url = $headerUrl; path = 'sources/WinBase.h'; sha256 = (Get-FileHash -LiteralPath $headerDst -Algorithm SHA256).Hash.ToLowerInvariant() }
$liveSpecs = @(
  @('naming', 'https://learn.microsoft.com/en-us/windows/win32/fileio/naming-a-file'),
  @('reparse_set', 'https://learn.microsoft.com/en-us/windows-hardware/drivers/ifs/fsctl-set-reparse-point'),
  @('rename_driver', 'https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntifs/ns-ntifs-_file_rename_information')
)
foreach ($entry in $liveSpecs) {
  $dst = Join-Path $ownedRoot ('sources/' + $entry[0] + '.html')
  Invoke-WebRequest -Uri $entry[1] -OutFile $dst
  $sourceRecords += [ordered]@{ id = $entry[0]; owner = 'Microsoft Learn'; revision = 'retrieved content SHA256 only; live page'; url = $entry[1]; path = 'sources/' + $entry[0] + '.html'; sha256 = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$inputSpecs = @(
  @('root-plan.md', '.planning/deepeye-resume-20261018/g02-owned-file-commit-20261024/plan.md'),
  @('completed-design-report.md', '.planning/deepeye-resume-20261018/g02-save-as-atomicity-design-20261024/report.md'),
  @('immutable_scope.md', 'docs/competition/deepeye-2026/immutable_scope.md'),
  @('immutable_scope.json', 'docs/competition/deepeye-2026/immutable_scope.json'),
  @('transfer.json', '.planning/deepeye-desktop-handoff-20261015/transfer.json')
)
$inputRecords = @()
foreach ($entry in $inputSpecs) {
  $src = Join-Path $taskRoot $entry[1]
  $dst = Join-Path $ownedRoot ('inputs/' + $entry[0])
  [System.IO.File]::Copy($src, $dst, $false)
  $inputRecords += [ordered]@{ source_path = $entry[1]; snapshot = 'inputs/' + $entry[0]; sha256 = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$json = [ordered]@{ retrieved_at_utc = [DateTime]::UtcNow.ToString('o'); source_only = $true; target_execution_count = 0; sources = $sourceRecords; inputs = $inputRecords } | ConvertTo-Json -Depth 8
[System.IO.File]::WriteAllText((Join-Path $ownedRoot 'source-pins.json'), $json, [System.Text.UTF8Encoding]::new($false))
[ordered]@{ source_count = $sourceRecords.Count; input_count = $inputRecords.Count; sdk_commit = $sdkCommit; header_commit = $headerCommit; source_pins_sha256 = (Get-FileHash -LiteralPath (Join-Path $ownedRoot 'source-pins.json') -Algorithm SHA256).Hash.ToLowerInvariant() } | ConvertTo-Json -Compress
