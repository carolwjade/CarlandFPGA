# G02 Save As bridge: source-only proposal

Work A-G02-GODOT-COMMIT-BRIDGE-DESIGN-20261024-v1; agent /root/save_as_bridge_design; job child-d339808515284df3825abec3de2813bc. Prepared for A Gen3 root's technical decision. No bridge implementation, execution or acceptance occurred.

Recommend **an awaited Save As with one retained Godot worker and one one-shot Python helper**. Root explicitly authorized migrating the original synchronous preference. A finite main-loop wait ends in visible outcome_unknown; it does not claim publication or the helper was cancelled.

## Exact API limits

Official source commit ed1daf0bf001b61586d9930840f2f1394092c079 identifies itself as 4.7.2 stable. Source bytes/URLs/hashes are frozen in source-pins.json.

- OS.execute_with_pipe(path, arguments, blocking=true) returns stdio, stderr, pid, or an empty Dictionary. [Binding](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/core/core_bind.cpp#L387).
- Windows uses redirected anonymous pipes and CREATE_NO_WINDOW, retaining process handles in its map. get_process_exit_code can return -1; false from is_process_running can mean query failure. kill erases the map entry before TerminateProcess and does not wait: a later false running query cannot prove termination. Completed process handles remain mapped; there is no separate public release method. [Windows implementation](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/platform/windows/os_windows.cpp#L1197).
- Pipe get_length peeks available bytes; get_buffer uses synchronous ReadFile. store_buffer uses synchronous WriteFile but returns only bool, losing any partial count. blocking=false attempts PIPE_NOWAIT without checking either result. close closes both directions without reporting success; flush is empty and eof_reached always false. [Implementation](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/drivers/windows/file_access_windows_pipe.cpp#L36), [header](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/drivers/windows/file_access_windows_pipe.h#L55).

Therefore no unchecked NOWAIT deadline claim, partial-write retransmission, half-close/EOF protocol, main-thread blocking I/O, or kill-based termination proof. [Microsoft](https://learn.microsoft.com/en-us/windows/win32/ipc/anonymous-pipe-operations) documents blocking anonymous-pipe writes; [mode setting](https://learn.microsoft.com/en-us/windows/win32/api/namedpipeapi/nf-namedpipeapi-setnamedpipehandlestate) can fail.

## Minimal proposed change

Root reports selecting the exact leaf (SHA256 521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f) into simulator/native/layout_commit_windows.py, under root ownership. Add only a viewer-private native/layout_commit_cli.py adapter, editor/layout_commit_bridge.gd job owner, explicit trusted runtime input, awaited store/shell call boundary and one new caller test. These are proposed files, not an existing launcher.

LayoutStore.save_new becomes awaited; shell.gd:811 uses await. All other call sites must explicitly migrate before future use. Do not retain the unsafe implementation as synchronous compatibility fallback. Keep the codec and document export/import unchanged.

Main-thread preflight preserves _absolute_path, the normalized returned path, exact UTF-8 bytes and 1,048,576-byte limit. Convert only '/' delimiters to '\' for the leaf. Clearly reject the leaf's unsupported namespace/volume/reparse/length forms without redirection or fallback; this is a narrower supported-path boundary requiring root approval.

After trusted-runtime preflight, the worker preserves existing recursive missing-parent creation and io_error mapping; never remove created parents on failure. Directory creation itself has no retained-HANDLE guarantee. The unchanged leaf subsequently verifies and pins the complete existing ancestry, rejecting incompatible parents.

Snapshot exported bytes once. The worker alone owns both pipes and performs protocol.md, calling commit_new once. It receives immutable bytes/configuration and a mutex-protected result record; it never touches SceneTree/document/control. This helper handles **viewer-private geometry files only**: never register it as AI input, a control provider, broker, mesh actor or service.

Show dedicated pending UI and disable Save/Open and editor mutations while awaiting. The proposed 5,000 ms main-loop deadline is an engineering choice, not a human requirement. On expiry show unknown, restore ordinary editor interaction, retain the worker/operation/path fence, and refuse another helper while unresolved. Do not join a live worker, kill by PID, delete paths, sweep orphans or replay. A late trusted result is separate evidence/notice; it never reapplies the saved snapshot or silently replaces the original unknown result.

Known success preserves {ok:true,path,bytes}; known already_exists retains its existing Chinese UI message. Failures preserve {ok:false,code,reason,errors}. Missing/mismatched trusted configuration before launch is helper_unavailable. Missing/malformed/mismatched/late response, transport error or ambiguous leaf outcome after launch remains outcome_unknown unless a complete trusted terminal response proves a stronger classification. Unknown must say the file may have been saved and needs checking.

Saving changes no document/history/undo/redo/selection/seed/run/control state. Only an explicit subsequent Open applies content via existing UTF-8 reader and codec.

## Runtime and export boundary

Configure an absolute path to the existing A interpreter explicitly; no PATH discovery, shell invocation, guessed-parent walk or hardcoded CarlJade path. Reviewed product pins define allowed source/runtime identities; a user-supplied configuration cannot supply its own trusted hashes.

Read-only observed locators/pins are in source-pins.json. The existing .local/venv redirector depends on an external bundled base runtime. Its executable hash alone is insufficient runtime identity. Before integration acceptance, root must produce/pin the approved dependency manifest covering interpreter, DLLs/extensions and used stdlib, and verify its actual path mapping. No runtime was launched here.

Proposed invocation uses fixed -I -S -B -u flags and a short fixed bootstrap with approved bundle location/hash arguments. It verifies helper and leaf bytes, then compiles those same bytes, avoiding a hash-check followed by mutable-path import. No layout supplies code or module paths. [Python flags](https://docs.python.org/3.12/using/cmdline.html).

In a source project, res://native maps to physical source files. In an export, PCK resources are not Python filesystem executables: require an explicitly configured, reviewed physical sidecar/runtime with equivalent pins. Until installed/verified, Save As reports unavailable. This task creates no export bundle, runtime configuration, daemon, provider or authority.

## One new headless caller test, later scope only

One fresh tests/test_layout_commit_bridge.gd SceneTree invocation under pinned Godot --headless, with its own owned run directory and outer timeout, should cover:

1. Actual helper save/reopen: absent nested parent, Unicode/non-BMP target/payload, exact byte equality, exported layout codec/hash roundtrip, empty/exact-1-MiB acceptance and over-limit pre-launch rejection.
2. Actual existing sentinel file/directory preserved with already_exists. Reuse the leaf's completed 19-test evidence for native races; do not rerun it merely to test this bridge.
3. Missing/mismatched runtime: unavailable, zero launches/target writes, preserved document and error UI.
4. Separately hash-pinned test-only adapter performs one real leaf commit then suppresses response and stalls until its own watchdog exits 124: unknown, published bytes retained, exactly one commit and no replay/delete, actual 124/worker completion before join. Label response loss/stall as injected.
5. Separately pinned adapter stalls before publication beyond a short UI deadline, then self-exits 124: advancing frames, pending UI, unchanged document/history/control snapshot, finite await ending unknown, second request refused while unresolved, target absent, actual 124/worker completion before join. Its absent target is fixture evidence, not a general inference from code 124.

Finish delayed fixtures and join completed workers before normal test exit. Do not run old 618/696 suites, board, display or service tests. Record new operation IDs, actual pins, command/exit, deadline/frame observations and artifacts.

## Root timeout choice and remaining limits

Prefer the worker above. Chunk/credit transport adds state and still does not establish a hard OS deadline; a compiled cancellable transport needs a separate build/deployment scope. Ordinary Godot rename is never fallback.

Root selected an ordinary process-local watchdog: start it before stdin reads/leaf loading, then call only os._exit(124) when the helper budget expires. It never deletes a path, retries, emits competing stdout or kills another PID. Under ordinary scheduling this can release a stalled helper and let the worker observe exact child exit 124, finish, and be joined. Exit 124 remains unknown whether publication happened or not. [Python's exit contract](https://docs.python.org/3.12/library/os.html#os._exit) bypasses Python cleanup; owned native handles are left to process teardown and orphan evidence remains preserved.

There is no blocking source-level gap in that stated boundary. It bounds the **UI wait** and proposes a testable ordinary-scheduler helper timeout, not a kernel/OS hard deadline. Interpreter/bootstrap work before watchdog startup, inability to schedule the watchdog, and extreme OS stalls remain outside its guarantee. A genuinely unresolved worker still occupies the slot: no live join, second helper or claimed termination. Application exit does not prove helper termination. Restart does not automatically recover or replay the old request; root permits a later explicit Save As to a new path, protected by no-replace publication. No persistent same-path reconciliation guarantee is claimed. Godot retains exited process-map handles, so repeated-save resource lifetime still needs explicit assessment rather than a kill cleanup trick.

## Scope evidence

Canonical lease validation allowed execution. Existing config reads node A / project fpga-main; transfer identifies active Gen3 director 01a16988-bdcb-70e1-ae10-1304b5cf7875. Both immutable scope files were read; all 15 IDs and compact sorted-key UTF-8 requirements hash were independently recomputed: c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804. Initial ASCII-escaped serialization was a different representation and was corrected, not a contract mutation.

H01-H15/both H12 routes remain intact. Current layout_store remains SHA256 752b023361b3ae935214dcef8beedc22e3722c66f0bdf1cef5b20939a91696a5. The 19 tests are frozen author evidence, not independently rerun here. No Godot/Python candidate/import/target-native/test/board/service/peer/group/provider/config/product action occurred; writes are only in this owned directory. C4/old failures are untouched; G03/R03/all29 remain not_run.
