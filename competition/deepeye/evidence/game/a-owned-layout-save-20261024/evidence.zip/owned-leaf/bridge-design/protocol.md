# Proposed one-shot protocol: deepeye-layout-commit/1

Source-only contract for root review. One viewer-private helper receives one opaque layout and calls the selected commit_new once. It cannot become an AI input/control provider or service.

## Invocation and request

Use explicit trusted runtime/bundle pins and fixed -I -S -B -u bootstrap. No layout payload or target path in argv. Cap the fixed quoted command at 8,192 UTF-16 units; [CreateProcessW](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessw) allows 32,767 including the terminator.

One worker owns OS.execute_with_pipe(..., true) and both returned FileAccess objects. No stream is shared with the UI.

Request frame:

1. ASCII magic DLC1.
2. Unsigned u32 big-endian metadata length, 1..4,096.
3. Strict UTF-8 JSON object with exactly protocol, operation_id, target, payload_bytes, payload_sha256. Require the fixed protocol, fresh bounded hex operation ID, normalized Windows target, integer 0..1,048,576 bytes, lowercase SHA256.
4. Exactly payload_bytes raw UTF-8 bytes; no appended newline/BOM.

The helper uses exact-length reads, never EOF. Verify frame bounds, path, strict UTF-8 and digest before the single leaf call. Incomplete/malformed frames never call it. Do not accept further commands. A false worker write causes unknown; its unreported partial count must never trigger retransmission. No Godot request staging file is needed.

Bound input/request memory to approximately two payload copies plus metadata. No layout content or traceback containing it goes to stdout/stderr.

## Result and terminal evidence

Response frame: ASCII DLR1, u32 big-endian length 1..16,384, strict UTF-8 JSON. Include matching protocol/operation_id/payload_bytes/payload_sha256 and leaf state/ok/code. Preserve publish_attempted, publication_confirmed, cleanup and close ambiguity. States are committed, already_exists, failed_before_publish, outcome_unknown. No progress/ACK/incidental stdout. Diagnostics are capped at 4,096 stderr bytes and are never success evidence.

Normal protocol completion exits 0, including known rejected saves. Startup/protocol failures exit nonzero; any pre-leaf rejection must explicitly say the leaf was never called. Root selected a process-local watchdog started before stdin/leaf loading: budget expiry calls only os._exit(124), with no cleanup/retry/stdout race. Code 124 is unknown, never proof of failed-before-publish. Observe that exact exit and completed worker before joining; startup before the watchdog and extreme scheduler/kernel stalls remain outside the guarantee.

After sending input, worker polls available lengths and reads only bounded currently available bytes, incrementally parsing the response and draining stderr. Never use EOF, flush, get_line or get_as_text. Require one matching internally consistent result, no trailing stdout and the expected nonnegative exit code. If the helper hangs after reporting, the UI can still expire; its job remains retained.

Missing/invalid response or abnormal/ambiguous exit after launch is unknown unless trusted terminal evidence proves otherwise. False from is_process_running alone is not terminal proof. Close only owned pipes; do not call kill as process-handle cleanup.

## Caller state

Use preflight -> pending -> terminal_known, or pending -> unknown_retained -> late_terminal_recorded. Retain target, operation ID, payload digest/count, timestamps, worker state and diagnostic PID.

The main loop enforces its finite wait independently of blocked worker I/O. On expiry return ok:false/code:outcome_unknown, retain the same job/path fence and single helper slot, show that a file may have been written, and permit ordinary editor interaction. Pending/unknown never mutate document/history/control. A late result is a separate notice/evidence record; never replay or apply its snapshot.

Join only a completed, no-longer-alive worker. The leaf alone owns HANDLE cleanup: never delete its diagnostic source pathname, a target, a created parent or an orphan. No automatic replay, adoption, rename fallback, broad PID stop, provider registration or existing-actor bypass.

A genuinely unresolved job remains retained. Restart performs no automatic recovery/replay; a later explicit Save As may select a new path. Process-map handle lifetime and absent persistent same-path reconciliation are limits described in report.md. This protocol does not claim a strict OS deadline.
