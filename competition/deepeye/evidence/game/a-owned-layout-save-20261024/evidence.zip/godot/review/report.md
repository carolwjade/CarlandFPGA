# Final independent source and saved-evidence review

**Ready for bounded code integration: yes.** No blocking source finding remains after the two-file revision. Root owns final selection/publication and must verify the author's actual terminal state and frozen inputs. This review accepts neither full G02 nor hardware/product acceptance.

Work `A-G02-OWNED-SAVE-INTEGRATION-REVIEW-20261024-v1`; agent `/root/godot_owned_save_review`; director `01a16988-bdcb-70e1-ae10-1304b5cf7875`, generation 3. Only this `review/` directory was written. No candidate import/execution, tests, engine, board, GUI, provider/peer/group/service action, product edit, Git mutation or process termination was performed. The only network read retrieved the exact pinned Godot string source. Canonical immutable requirements SHA was independently recalculated as `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`; H01–H15/full H12 remain mandatory.

## Exact reviewed inputs

- Final production manifest v2: `228fcc3797959b06fee9d4d53fca1eadfb883b4c019ec2f57a0e6b80163a6fdf`. All nine members independently verified by raw size/SHA. Only bridge and shell differ from v1; all nine original v1 byte snapshots were separately verified against the preserved original manifest.
- Final bridge SHA: `280707117068fe19007f314c6127d592bdf69a51bff5b854afc0446f416d6e84`; final shell SHA: `1acf407c0b42687c54efca32ef081d85c2c2bba9db63ff490bb004cb6f9a8fa1`.
- All 32 selected canonical members, nine production and 23 tests/fixtures, independently match the actual run 10 staging bytes. Paths are unique and remain under the intended product subtree. The final source-to-run bindings were independently verified.
- All 123 frozen CLI manifest members were independently verified earlier. The production CLI and exact embedded bootstrap are unchanged. Selected native leaf SHA remains `521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f`. Its prior independent review and 19 actual NTFS tests are reused without rerunning them.
- `input-audit-initial.json` and `input-audit-final.json` preserve the exact input/run/artifact pins, checked conditions and source-version separation. The final audit SHA is `e9fa219e87f128aeff5313fb0aa57cc4c2e91033457067a12235bb1e68106b49`.

The complete first production freeze, CLI/bootstrap and shell's full product diff were reviewed in `initial-review.md`. The final delta was then read in full. Its initial illustrative path correction is retained separately in `path-example-correction.md`; neither the initial report nor original failures were rewritten.

## Findings resolved

1. **Reserved-name/temporary-name precheck.** Final `layout_commit_bridge.gd:101–114` now matches the selected CLI's supported syntax: UTF16 component bound, space-stripped stem, COM/LPT superscript digits, and the parent-plus-41 temporary-name bound. Rejection precedes runtime preflight and worker creation, so these syntax failures cannot create missing parents. The native leaf and accepted non-atomic parent-creation convenience boundary are unchanged.

2. **Actionless late cancellation.** Final `shell.gd:874–887` rejects empty-dialog-action callbacks before the pending/unresolved guard. A no-action event therefore cannot replace an earlier unknown result after worker reap. A genuinely new dialog still has an action and retains normal cancellation behavior. No document/history/run/link/control mutation was introduced.

3. **One normalized path key.** Final `layout_commit_bridge.gd:96`, `:115–117`, `:133`, `:323` and `:331` derives a single lower-case key from the validated, fully slash-normalized Windows request path, records it in the job, and uses it for every unknown-fence lookup/insertion. There is no remaining raw display-path key in those operations. This is a source-reviewed, small normalization change. It does not claim reconciliation of every filesystem alias.

The third finding's original all-backslash example was inaccurate. The [exact selected Godot source](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/core/string/ustring.cpp#L4185) makes its preserved-drive-prefix branch conditional on a later forward slash. All-backslash input is normalized completely; mixed `C:\folder/file` may retain a different display prefix from `C:/folder/file`. Actual 09 and 10 used all-backslash versus all-forward input; both recorded one launch before and after. Neither run reproduced an old mixed-prefix bypass or behaviorally exercised that mixed branch. Root explicitly retained this limit and authorized no run 11. The final key computation covers the branch by inspection; no stronger execution claim is made.

## Actual new evidence reviewed

Run 09 is a real behavioral red for the namespace and cancellation findings: 16 checks, 11 failures, Godot exit 1. Each of the three namespace cases launched one CLI and created its previously absent parent before CLI exit 2; the original before-publication fixture later exited 124. The failures and created parents remain preserved. The source-launcher save/reopen branch did not execute on this red path. Its alias diagnostic recorded `1 -> 1` launches, so it was not an alias red reproduction.

Run 10 used the actual frozen `python -I -B run_viewer.py` source-tree launcher, explicit headless Godot, owned userdata/TEMP and the separately root-reviewed suspended-start JobObject supervisor. It records **21 checks/zero failures** and actual safe save/reopen. The three namespace cases now return `invalid_path` with zero helper launches and zero created parents; actionless initial/post-reap cancellations are ignored while normal new-dialog cancellation works.

Process layers remain distinct: original launcher/redirector PID **3372**, original-handle wait completed with exit **0**; launcher stdout records Godot child PID **2296** and wait exit **0**, matching the GDScript process ID. The supervisor records assignment/resume, no timeout/termination, final JobObject active count **0**, stopped chain, checked cleanup, no error and successful own-handle closes. Its captured stderr is empty. The separate saved Godot log contains the engine header and `REVIEW_CHECKS=21 FAILURES=0`; it is not conflated with the supervisor's stream.

The original before-publication fixture PID **38720** is recorded terminal/reaped at **124** with retained unknown. The real save helper's tracked original child PID **25992** exits **0**; the worker is completed/reaped and one known-exited map cleanup is consumed before the call. Cleanup result **FAILED/1** is preserved separately from prior exit 0; the post-cleanup map query is -1. The audit does not promote that to verified Godot kernel-handle close results.

The actual new Unicode/nonBMP target contains **865 bytes**. Independently hashing the saved file matches the request/evidence digest `62a87394dbcf8c7497f8dacc604abca12de73e0c6fe1432fbb0e25ccaaa133dc`. Its stored `layout_hash` equals the successfully reopened codec hash `668b1b203a62ce06c4895b474e2c2d9b5eadefe907aa89744e280f42fe35261a`. The scene records 966 advancing frames. This is an actual source-launcher/helper/file/codec result, not merely `--validate-only`.

Existing run 05 retains its own 81 checks/zero failures, ten terminal worker records, actual partial-read/trailing-output/watchdog/response-loss coverage and empty stderr. Its pre-guard shell and v1 bridge are **not rebound to the final revision**. Run 07's seven focused checks bind its v1 late-cancel guard only. The earlier run 02 quoting failure, pipe diagnostics, run 06 red, launcher validation failure and run 08 parse failure/containment remain historical failures rather than rewritten successes. No old 81/19/618/696/384 suite or solver/board baseline was rerun by this review.

## Remaining boundaries

The single retained worker/job, bounded framing/drain, one-shot opaque geometry helper, exact original-child exit, completed-thread join and conditional one-shot original-map cleanup remain consistent with root's plan. No unsafe Godot rename/delete fallback or control/provider registration was added. Runtime identity pins continue to rely on the explicitly trusted existing A CPython/stdlib installation; they do not establish whole-runtime anti-tamper closure. Parent creation remains a separate non-atomic convenience step. Watchdog/UI deadlines are ordinary-scheduler observations, and unknown work is never a cancellation/replay authorization.

Source-tree launcher verification does not establish exported/PCK sidecar readiness. Headless regression/source review does not establish real mouse/FileDialog/DPI behavior, game-level rendering, physical collision/full crossing, hidden-layout causal sensing, substantive PC AI or either full H12 chain. **G02 remains open; G03/R03/all29 remain not_run.** No remaining blocking source finding was identified within this bounded code-integration scope.
