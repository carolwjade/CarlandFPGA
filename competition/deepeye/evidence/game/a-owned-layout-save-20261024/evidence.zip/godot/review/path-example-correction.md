# Correction to initial finding 3's illustrative path

The initial review's all-backslash example was too broad. The original report is retained unchanged with its original SHA. This correction supersedes that example, and no run 09 artifact is edited.

The same exact raw Godot source has an additional condition at `ustring.cpp:4185`: the drive marker must occur before the first forward slash. An all-backslash path has no forward slash, so that comparison fails; no drive prefix is extracted, and the subsequent conversion normalizes the entire path. Accordingly `C:\folder\file.json` and `C:/folder/file.json` do **not** demonstrate the initial claimed difference through LayoutStore.

The source branch of concern requires mixed separators: `C:\folder/file.json` has a drive backslash followed later by a forward slash, so the drive prefix is extracted and preserved; `C:/folder/file.json` preserves a forward-slash prefix. This narrower static issue still supports choosing the validated, fully slash-normalized Windows path as the sole unknown-fence key. This review has not executed the old implementation on that mixed case and does not claim an observed red reproduction of it.

Actual new run 09 constructed the all-backslash first spelling with `.replace("/", "\\")` at `review_save_regressions.gd:91` and the all-forward alias at line 103. Its evidence records the normalized job path as all-forward and launch count `1 -> 1`, with one original fixture exit 124. Thus that run did **not** reproduce an alias bypass or start a second helper. The source lookup explains this actual observation; it is not contradictory evidence to be discarded.

Run 09 separately produced the expected behavioral red for the other two findings: 16 checks, 11 failures comprising all three namespace cases' rejection/zero-launch/zero-parent checks plus actionless initial and post-reaped cancellation. Each namespace case actually launched one CLI, created its absent parent, returned unknown after exact exit 2 and reaped/consumed cleanup. The before-publication fixture reached 124 and was reaped. Normal new-dialog cancellation worked. No successful source-launcher save/reopen was executed on this red path.

The new green test should explicitly record both mixed-drive-prefix and all-forward normalized paths and the final canonical key, then show no additional helper launch. Root and author were informed before the new green invocation. No extra engine invocation or replay was requested by this review.
