"""Read and hash frozen inputs only; never imports/executes candidate code."""
import datetime
import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path.cwd()
BASE = ROOT / '.planning/deepeye-resume-20261018/g02-godot-owned-save-20261024'
OUT = BASE / 'review'

def pin(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}

checks = []
for name, wanted, key in [
    ('cli-author/manifest.json', '5703d9c2258b15efe8a4087ad7c1655c2cee66083812872f81e1936b98ad5564', 'members'),
    ('author/candidate-product-manifest.json', '775c49375dcfd7776aaa92d01852b58622a85ed1a534f9b262487d1ebee64bf3', 'production_members'),
]:
    manifest = BASE / name
    assert pin(manifest)['sha256'] == wanted
    members = json.loads(manifest.read_bytes())[key]
    for member in members:
        path = (manifest.parent / member['path']).resolve()
        assert path.is_relative_to(manifest.parent.resolve())
        current = pin(path)
        assert (current['bytes'], current['sha256']) == (member['bytes'], member['sha256'])
    checks.append({'manifest': pin(manifest), 'members_verified': len(members), 'mismatches': []})

bindings = []
for product, member in json.loads((BASE / 'author/source-bindings.json').read_bytes())['production_source_bindings'].items():
    run_copy = pin(BASE / 'author' / member['same_bytes_in'])
    assert run_copy['sha256'] == member['sha256']
    candidate = BASE / 'author/candidate' / product
    if candidate.exists():
        assert pin(candidate)['sha256'] == member['sha256']
    bindings.append({'product': product, 'run_copy': run_copy, 'scope': member['evidence_scope']})

bridge = (BASE / 'author/candidate/simulator/editor/layout_commit_bridge.gd').read_text('utf-8')
hex_bootstrap = re.search(r"const BOOTSTRAP := \"exec\(bytes.fromhex\('([0-9a-f]+)'\)\)\"", bridge).group(1)
assert bytes.fromhex(hex_bootstrap) == (BASE / 'cli-author/bootstrap.py').read_bytes()

runs = []
for name, expected in [('caller-05', 81), ('late-cancel-green-07', 7)]:
    directory = BASE / 'author/runs' / name
    command = json.loads((directory / 'command.json').read_bytes())
    evidence = json.loads((directory / 'targets/bridge-evidence.json').read_bytes())
    assert command['exit_code'] == 0 and command['exact_popen_wait_completed']
    assert evidence['checks'] == expected and not evidence['failures']
    assert command['original_popen_pid'] == evidence['godot_process_id']
    workers = []
    for record in evidence['records']:
        job = record.get('evidence')
        if job is None:
            continue
        assert job['worker_completed'] and job['reaped'] and job['cleanup_prior_exit'] >= 0
        assert job['cleanup_consumed'] and job['cleanup_attempted'] and job['cleanup_after_exit_query'] == -1
        target = pathlib.Path(job['path'])
        assert target.resolve().is_relative_to(directory.resolve())
        workers.append({'label': record['label'], 'exit': job['original_exit'],
                        'cleanup_result': job['cleanup_result'], 'partial_reads': job['partial_reads'],
                        'trailing_bytes': job['stdout_trailing_bytes'], 'target_exists': target.exists(),
                        'target_pin': pin(target) if target.is_file() else None})
    runs.append({'name': name, 'command': pin(directory / 'command.json'),
                 'evidence': pin(directory / 'targets/bridge-evidence.json'),
                 'checks': expected, 'original_popen_pid': command['original_popen_pid'],
                 'exact_popen_exit': command['exit_code'], 'stdout': pin(directory / 'stdout.log'),
                 'stderr': pin(directory / 'stderr.log'), 'workers': workers})

scope = json.loads((ROOT / 'docs/competition/deepeye-2026/immutable_scope.json').read_bytes())
canonical = hashlib.sha256(json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()
assert canonical == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
inputs = [ROOT / name for name in [
    'AGENTS.md', '.agents/skills/fpga-multi-node/SKILL.md', '.agents/skills/fpga-multi-node/skill-role.json',
    '.agents/skills/fpga-multi-node/references/protocol.md', '.agents/skills/pynq-z2-single-node/SKILL.md',
    '.agents/skills/pynq-z2-single-node/skill-role.json', 'docs/competition/deepeye-2026/immutable_scope.md',
    'docs/competition/deepeye-2026/immutable_scope.json', '.planning/deepeye-desktop-handoff-20261015/transfer.json',
    '.planning/deepeye-desktop-handoff-20261023/handoff.md']]
inputs += [BASE / name for name in ['plan.md', 'author/source-bindings.json', 'cli-author/interface.md',
                                  'cli-author/report.md', 'cli-author/native-complete-receipt.json']]
inputs.append(OUT / 'sources/ustring.cpp')
result = {'schema': 1, 'work_id': 'A-G02-OWNED-SAVE-INTEGRATION-REVIEW-20261024-v1',
          'agent': '/root/godot_owned_save_review', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'read_only_review': True, 'candidate_execution': False, 'reused_native_tests_not_rerun': 19,
          'requirements_count': len(scope['requirements']), 'contract_sha256': canonical,
          'verified_manifests': checks, 'source_bindings': bindings, 'bootstrap_hex_exact': True,
          'saved_runs_reviewed': runs, 'input_pins': [pin(path) for path in inputs],
          'source_url': 'https://raw.githubusercontent.com/godotengine/godot/ed1daf0bf001b61586d9930840f2f1394092c079/core/string/ustring.cpp',
          'initial_audit_errors': ['inline script expected files instead of members; no writes',
                                   'inline script expected stderr.bin instead of stderr.log; no writes']}
output = OUT / 'input-audit-initial.json'
with output.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'audit': pin(output), 'members': [item['members_verified'] for item in checks],
                  'runs': [(item['name'], item['checks'], len(item['workers']), item['stderr']['bytes']) for item in runs]}))
