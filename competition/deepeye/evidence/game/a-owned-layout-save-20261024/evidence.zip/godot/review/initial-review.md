# Independent review of the first frozen Godot integration

Work `A-G02-OWNED-SAVE-INTEGRATION-REVIEW-20261024-v1`, agent `/root/godot_owned_save_review`. Desktop/native ownership is recorded by Gen3 root; this review does not require a mesh lease under the existing human exception. Only `review/` is written. This is a source and saved-evidence review: no candidate import, engine, tests, board, GUI, provider, peer, service, Git mutation or cleanup was executed.

**Initial verdict: with fixes.** The complete production implementation was read. Three narrow findings require correction before root selects it. No additional blocking finding was identified in the selected native leaf, protocol/worker/map lifetime, trusted runtime boundary or document/control separation. Final revised-source and new-launcher evidence review remains pending.

## Identity and verified input

Existing config identifies A/fpga-main. Transfer identifies active director `01a16988-bdcb-70e1-ae10-1304b5cf7875`, generation 3. The mandatory A skills, role/protocol, activation/handoff and immutable scope md/json were read. Compact sorted-key UTF8 requirements JSON, `ensure_ascii=False`, independently hashes to `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`; all 15 requirements and both H12 routes remain mandatory.

`input-audit-initial.json` records the independent raw size/SHA verification of all 123 CLI manifest members and all nine initial production manifest members, with zero mismatches. CLI manifest SHA is `5703d9c2258b15efe8a4087ad7c1655c2cee66083812872f81e1936b98ad5564`; initial production manifest SHA is `775c49375dcfd7776aaa92d01852b58622a85ed1a534f9b262487d1ebee64bf3`. The bridge's hex literal decodes exactly to the frozen CLI bootstrap bytes; no bootstrap code was executed by this review. Source-to-run bindings were independently hashed, including the final initial shell's separate run 07 binding.

The existing independently reviewed leaf remains SHA `521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f`. Its original 19 NTFS tests, prior review and source preflight are reused. None was rerun.

## Findings

### Important 1: validate the complete reserved-name and temporary-name limits before mkdir

Initial `candidate/simulator/editor/layout_commit_bridge.gd:103–111` checks component endings and ASCII COM/LPT1–9, but does not strip spaces from the stem preceding the first dot and does not reject the superscript digit forms. The same selected CLI at `layout_commit_cli.py:116–124` rejects those forms and rejects parents whose temporary-name path cannot fit the supported limit. The bridge lacks that latter parent bound too.

For example, `C:\missing-parent\CON .json` and `C:\missing-parent\COM¹.json` pass the bridge filter. The worker can create `missing-parent` at bridge lines 192–197 before the CLI rejects the target. Likewise a target shorter than 260 UTF16 units can have a parent too long for the fixed temporary name. This violates the explicit syntax-before-mkdir decision and both documentation claims, though the strict leaf still prevents unsafe publication/overwrite.

Use the same bounded syntax checks as the selected CLI before `_runtime_preflight`/worker launch: stem `rstrip(" ")`, COM/LPT `[1-9¹²³]`, and the existing parent-plus-41 UTF16 temporary-name bound. Do not weaken or change the reviewed leaf or expand its filesystem scope. Test these cases against absent owned parents and record zero launch/parent effects.

### Important 2: reject canceled callbacks when no file-dialog action exists

Initial `candidate/simulator/ui/shell.gd:874–885` ignores cancellation while pending/unresolved, which run 07 covers. Once that original worker is reaped, `_dialog_action` remains empty but the guard is false. A stale `canceled` callback can therefore overwrite `last_file_result` and the visible hint with `canceled`, even though the original save result was unknown and no current operation was canceled.

The bridge's original visible unknown result and path fence survive, so this does not cause replay or deletion. It does misclassify the UI result. Add an empty-action guard as well as the existing pending/unresolved guard. Cover the post-reaped, no-action callback and verify that a genuinely new dialog can still cancel normally.

### Important 3: use one normalized Windows key for every unknown-path fence operation

Initial `candidate/simulator/editor/layout_commit_bridge.gd:96`, `:317`, and `:325` key the fence by the original `path.to_lower()`. Request metadata separately normalizes all slashes at line 98. `LayoutStore._absolute_path` uses `simplify_path`, but this does not normalize the drive prefix's separator.

The exact pinned Godot source confirms this: [ustring.cpp at the selected commit](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/core/string/ustring.cpp#L4149), raw lines 4186, 4192 and 4232, extracts and preserves the original drive prefix, normalizes only the remaining path and concatenates them. The retained raw source SHA is `fc403ff50652c5258bcf28d4b5ab5ac377301b656763c7ad87d9cf748bbbb903`.

Thus first `C:\folder\file.json` and later `C:/folder/file.json` can produce distinct fence keys while the helper receives the same Windows target. After the unknown worker is reaped the second spelling can launch again, violating the explicit same-path isolation/no-replay boundary. Native no-replace publication continues to protect an existing target; this finding does not claim data loss.

Create a single lower-case, slash-normalized key from the validated Windows path and store it in the immutable job. Use that key for every unknown insertion and lookup. A new regression should observe one unresolved job to terminal and then reject the other slash spelling without another launch or target mutation. This request does not imply canonicalization of hard links, privileged aliases or unsupported namespace mappings.

## Source and evidence assessment

The one-shot CLI validates duplicate-free strict UTF8 metadata, exact keys/types/limits/digest/op ID and fixed bundle/source bytes before one leaf call. Fixed bootstrap/helper watchdogs start before stdin and leaf loading; expiration only self-exits 124. Geometry is opaque input and never becomes a model, control provider, resource or executable. There is no production test switch, retry or path-based cleanup.

The bridge keeps the only outstanding owner alive, isolates blocking pipe work from SceneTree/document/control state, never resends an ambiguous write, accumulates partial frame bytes and rejects trailing stdout. Under the explicitly selected trusted runtime/pinned helper scope it waits for the exact retained original-process exit before bounded terminal drain. `poll` joins only a no-longer-alive completed worker. Cleanup is consumed before the single mapped-original `OS.kill`, after a second nonnegative exact-exit observation. The engine's mapped branch and no-destructor header support root's conditional cleanup decision. FAILED is preserved separately; it is never used as termination proof. CloseHandle returns are not exposed and are not claimed verified.

The source-tree launcher checks the selected engine and helper/runtime identities and creates a child-only allowlisted environment. The small runtime manifest is explicitly an existing trusted CPython installation boundary; this review does not demand or claim full stdlib/loader anti-tamper closure. The isolated helper flags and launcher `-I -B` distinction are documented. Export/PCK sidecar installation remains an explicit separate obligation.

The store's synchronous and asynchronous APIs both use the same safe worker; the old check/write/Godot-rename/delete path is removed. The shell change does not alter codec/document/control logic or apply a saved snapshot. Its pending UI inhibition and later ordinary editing are separate from the unresolved global save slot.

Actual saved run 05 has exit 0, 81 checks/zero failures, stderr zero, original Popen PID/Godot process ID 33400 and ten independently read completed/reaped worker records with exits `0,0,0,0,0,124,124,0,0,0`. The split case records two partial reads and the trailing-output case records one extra stdout byte while keeping the actual published target. The responsive shell records 727 frames over 5060 ms. Both before-publication absent target and after-publication retained target are recorded separately from watchdog 124.

Run 05 is bound to the bridge/store/CLI/bundle/runtime bytes and the pre-late-cancel shell. It is **not** execution evidence for the final initial shell hash. Actual focused run 07 separately has exit 0, seven checks/zero failures, stderr zero, original Popen/Godot PID 24396 and the initial guarded shell SHA `a53e2341803d834eaae6c144be71c477ccc55821386c22fee0454372cc083313`. It covers cancellation while pending/unresolved, not finding 2's terminal window.

Run 08's parse failure and root's separately recorded same-handle containment are preserved. It is not a successful save/reopen or clean launcher result. Root has authorized distinct new targeted red/green and actual launcher work under the reviewed JobObject supervisor; this initial report does not claim those future results. No original 81/19 checks need repeating for these narrow changes.

## Acceptance limits

This review does not close full G02, real mouse/FileDialog/DPI behavior, game-level visuals, hidden-layout/causal sensing, physical board observation, H09, either full H12 chain, or 29-card acceptance. `G03/R03/all29` remain `not_run`. Root decides selection after revised-source and saved-evidence review. The three findings above were sent promptly to root and the author; source was never changed by the reviewer.
