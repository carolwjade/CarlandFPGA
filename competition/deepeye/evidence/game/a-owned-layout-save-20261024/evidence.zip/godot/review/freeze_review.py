"""Freeze this review's own outputs; no candidate execution or other writes."""
import datetime
import hashlib
import json
from pathlib import Path

directory = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_new(name, value):
    with (directory / name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

assert not (directory / 'result.json').exists()
assert not (directory / 'manifest.json').exists()
write_new('result.json', {
    'schema': 1,
    'work_id': 'A-G02-OWNED-SAVE-INTEGRATION-REVIEW-20261024-v1',
    'agent_id': '/root/godot_owned_save_review',
    'director_thread': '01a16988-bdcb-70e1-ae10-1304b5cf7875',
    'director_generation': 3,
    'contract_sha256': 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    'report_sha256': sha(directory / 'report.md'),
    'production_v2_manifest_sha256': '228fcc3797959b06fee9d4d53fca1eadfb883b4c019ec2f57a0e6b80163a6fdf',
    'independent_hash_audit': {'CLI_members': 123, 'production_v2_members': 9,
                              'preserved_v1_members': 9, 'selected_members_matching_actual10': 32},
    'remaining_blocking_source_findings': [],
    'bounded_code_integration': 'approved for root selection within the recorded scope',
    'root_execution_gate': 'Root verifies author actual terminal and frozen bytes before selection/publication',
    'reviewer_candidate_execution': False,
    'reviewer_tests_rerun': False,
    'initial_findings': {'namespace_precheck': 'resolved; actual09 red/10 green',
                         'actionless_cancel': 'resolved; actual09 red/10 green',
                         'normalized_path_key': 'resolved by source review; mixed branch not behaviorally tested'},
    'saved_evidence': {'05': '81 checks / 0 failures on original pre-guard sources',
                       '07': '7 focused checks / 0 failures on v1 shell guard',
                       '09': '16 checks / 11 expected failures; alias1->1 was not a bypass reproduction',
                       '10': '21 checks / 0 failures; actual source-launcher safe save/reopen'},
    'G02': 'open', 'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run',
    'manifest': 'manifest.json',
})
members = [{'path': path.relative_to(directory).as_posix(), 'bytes': path.stat().st_size,
            'sha256': sha(path)}
           for path in sorted(directory.rglob('*')) if path.is_file() and path.name != 'manifest.json']
write_new('manifest.json', {'schema': 1, 'work_id': 'A-G02-OWNED-SAVE-INTEGRATION-REVIEW-20261024-v1',
                            'frozen_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                            'members': members, 'writer_stopped_after_freeze': True})
for member in members:
    path = directory / member['path']
    assert path.stat().st_size == member['bytes'] and sha(path) == member['sha256']
print(json.dumps({'manifest_sha256': sha(directory / 'manifest.json'), 'members': len(members),
                  'report_sha256': sha(directory / 'report.md'),
                  'result_sha256': sha(directory / 'result.json'), 'all_own_members_reverified': True}))
