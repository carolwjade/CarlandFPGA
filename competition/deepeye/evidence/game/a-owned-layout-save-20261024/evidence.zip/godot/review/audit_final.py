"""Independent hashes and saved-evidence inspection; zero candidate execution."""
import datetime
import hashlib
import json
import pathlib

ROOT = pathlib.Path.cwd()
BASE = ROOT / '.planning/deepeye-resume-20261018/g02-godot-owned-save-20261024'
AUTHOR = BASE / 'author'
OUT = BASE / 'review'

def pin(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}

def check_member(base, member, path_key='path'):
    path = (base / member[path_key]).resolve()
    assert path.is_relative_to(base.resolve())
    current = pin(path)
    assert current['sha256'] == member['sha256'], member[path_key]
    if 'bytes' in member:
        assert current['bytes'] == member['bytes']
    return current

manifest = AUTHOR / 'candidate-product-manifest-v2.json'
assert pin(manifest)['sha256'] == '228fcc3797959b06fee9d4d53fca1eadfb883b4c019ec2f57a0e6b80163a6fdf'
production = json.loads(manifest.read_bytes())['production_members']
production_pins = [check_member(AUTHOR, member) for member in production]
assert len(production_pins) == 9

v1 = json.loads((AUTHOR / 'candidate-product-manifest.json').read_bytes())
mapping = json.loads((AUTHOR / 'candidate-v1-pinmapping.json').read_bytes())['preserved_members']
assert len(mapping) == len(v1['production_members']) == 9
by_path = {member['path']: member for member in v1['production_members']}
preserved = []
for member in mapping:
    original = by_path[member['v1_manifest_path']]
    assert member['sha256'] == original['sha256']
    preserved.append(check_member(AUTHOR, {'path': member['preserved_path'], 'sha256': original['sha256'], 'bytes': original['bytes']}))
changed = [member['product_path'] for member in production
           if member['sha256'] != by_path[member['path']]['sha256']]
assert set(changed) == {'competition/deepeye/simulator/editor/layout_commit_bridge.gd',
                        'competition/deepeye/simulator/ui/shell.gd'}

selection = json.loads((AUTHOR / 'selection-mapping.json').read_bytes())['files']
assert len(selection) == 32 and len({item['destination'] for item in selection}) == 32
selected = []
for member in selection:
    source = check_member(AUTHOR, member, 'source')
    assert member['destination'].startswith('competition/deepeye/')
    relative = member['destination'].removeprefix('competition/deepeye/')
    executed_copy = pin(AUTHOR / 'runs/review-green-10' / relative)
    assert (source['bytes'], source['sha256']) == (executed_copy['bytes'], executed_copy['sha256'])
    selected.append({'source': source, 'run10_copy': executed_copy, 'destination': member['destination'], 'role': member['role']})

bindings = json.loads((AUTHOR / 'source-bindings-v2.json').read_bytes())
assert bindings['full81_not_rebound_to_v2'] and bindings['mixed_drive_prefix_not_executed']
for member in bindings['bindings']:
    assert check_member(AUTHOR, member, 'candidate')['sha256'] == pin(AUTHOR / member['same_bytes_in'])['sha256']

saved_runs = []
for name, count, expected_exit, expected_failures in [('review-red-09', 16, 1, 11), ('review-green-10', 21, 0, 0)]:
    directory = AUTHOR / 'runs' / name
    command_file = directory / 'supervisor/command.json'
    command = json.loads(command_file.read_bytes())
    original = command['original_process']
    assert original['wait_completed'] and original['exit_code'] == expected_exit
    assert command['assignment_confirmed'] and command['resume_confirmed']
    assert not command['timed_out'] and not command['termination_consumed']
    assert command['job_active_processes_final'] == 0 and command['chain_stopped']
    assert command['cleanup_checked'] and command['error'] is None
    assert all(item['ok'] for item in command['handle_closes'])
    for key in ['stdout', 'stderr']:
        actual = pin(pathlib.Path(command[key]['path']))
        assert actual['bytes'] == command[key]['bytes'] and actual['sha256'] == command[key]['sha256']
    evidence_file = directory / 'viewer-env/appdata/Godot/app_userdata/矿脉·深瞳/review-evidence.json'
    evidence = json.loads(evidence_file.read_bytes())
    assert evidence['checks'] == count and len(evidence['failures']) == expected_failures
    stdout = (directory / 'supervisor/stdout.bin').read_text('utf-8')
    assert 'DEEPEYE_VIEWER_CHILD_PID=' + str(evidence['godot_process_id']) in stdout
    assert 'DEEPEYE_VIEWER_CHILD_EXIT=' + str(expected_exit) in stdout
    alias = next(item for item in evidence['records'] if item['label'] == 'slash-alias')
    assert alias['launches_before'] == alias['launches_after'] == 1
    namespaces = [item for item in evidence['records'] if item['label'].startswith(('reserved ', 'source temp'))]
    assert len(namespaces) == 3
    if expected_exit == 0:
        assert all(item['helper_launches'] == 0 and not item['parent_created'] and item['result']['code'] == 'invalid_path' for item in namespaces)
        smoke = evidence['actual_launcher_smoke']
        assert smoke['executed'] and smoke['saved']['ok'] and smoke['evidence']['original_exit'] == 0
        target = pathlib.Path(smoke['target'])
        target_pin = pin(target)
        assert target_pin['sha256'] == smoke['evidence']['digest']
        assert json.loads(target.read_bytes())['layout_hash'] == smoke['reopened_layout_hash']
        log = directory / 'viewer-env/appdata/Godot/app_userdata/矿脉·深瞳/logs/godot.log'
        assert 'REVIEW_CHECKS=21 FAILURES=0' in log.read_text('utf-8')
    else:
        assert not evidence['actual_launcher_smoke']['executed']
        assert all(item['helper_launches'] == 1 and item['parent_created'] for item in namespaces)
        target_pin = None
        log = directory / 'viewer-env/appdata/Godot/app_userdata/矿脉·深瞳/logs/godot.log'
    saved_runs.append({'name': name, 'command': pin(command_file), 'evidence': pin(evidence_file),
                       'engine_log': pin(log), 'supervisor_stdout': pin(directory / 'supervisor/stdout.bin'),
                       'supervisor_stderr': pin(directory / 'supervisor/stderr.bin'),
                       'checks': count, 'failures': expected_failures, 'original_process': original,
                       'godot_pid': evidence['godot_process_id'], 'godot_wait_exit': expected_exit,
                       'job_active_final': 0, 'cleanup_checked': True, 'mixed_branch_executed': False,
                       'target_pin': target_pin})

leaf = pin(ROOT / '.local/deepeye-implementation-a/competition/deepeye/simulator/native/layout_commit_windows.py')
assert leaf['sha256'] == '521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f'
result = {'schema': 1, 'work_id': 'A-G02-OWNED-SAVE-INTEGRATION-REVIEW-20261024-v1',
          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'candidate_execution': False, 'tests_rerun': False, 'v2_manifest': pin(manifest),
          'production': production_pins, 'preserved_v1': preserved, 'changed_from_v1': changed,
          'selection_mapping': pin(AUTHOR / 'selection-mapping.json'), 'selection': selected,
          'source_bindings_v2': pin(AUTHOR / 'source-bindings-v2.json'),
          'saved_runs': saved_runs, 'unchanged_selected_leaf': leaf,
          'verdict': 'No remaining blocking source finding within root-selected bounded integration scope',
          'mixed_branch': 'Source-only normalization review; no old-code RED or mixed GREEN claimed',
          'G02': 'open', 'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run'}
output = OUT / 'input-audit-final.json'
with output.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'audit': pin(output), 'v2_members': len(production), 'preserved_v1': len(preserved),
                  'selected_members_same_as_run10': len(selection), 'saved_run_checks': [item['checks'] for item in saved_runs]}))
