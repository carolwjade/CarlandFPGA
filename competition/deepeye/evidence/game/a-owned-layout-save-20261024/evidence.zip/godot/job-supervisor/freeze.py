"""Write one immutable summary/manifest without launching any child."""
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent


def pin(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


records = {}
for name in ("success", "timeout-chain"):
    path = HERE / "runs/green01" / name / "result/command.json"
    record = json.loads(path.read_text(encoding="utf-8"))
    records[name] = {
        "record": str(path.relative_to(HERE)).replace("\\", "/"),
        "record_pin": pin(path),
        **{key: record[key] for key in ("original_process", "assignment_confirmed", "resume_confirmed", "timed_out", "termination_consumed", "job_active_processes_final", "job_peak_active_processes", "chain_stopped", "cleanup_checked", "elapsed_seconds", "error")},
        "accounting_last": record["job_accounting_samples"][-1],
    }
summary = {"work_id": "A-G02-LAUNCHER-JOB-SUPERVISOR-20261024-v1", "owner": "/root/launcher_job_supervisor",
           "main_thread": "01a16988-bdcb-70e1-ae10-1304b5cf7875", "generation": 3,
           "requirements_sha256": "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804",
           "frozen_utc": datetime.now(timezone.utc).isoformat(), "godot_invocations": 0,
           "new_python_tests": {"red01_exit": 1, "red01_failures": 2, "green01_exit": 0, "green01_passed": 2, "green01_seconds": 2.304},
           "records": records,
           "scope": "process supervisor only; no product edits or physical/UI/model acceptance",
           "attempted_parallel_source_review": "collaboration spawn rejected thread limit; root independently read stable source and tests"}
with (HERE / "result.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(summary, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
members = {str(path.relative_to(HERE)).replace("\\", "/"): pin(path)
           for path in sorted(HERE.rglob("*")) if path.is_file() and path.name != "manifest.json"}
manifest = {"schema": 1, "work_id": summary["work_id"], "files": members}
with (HERE / "manifest.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(manifest, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({"files": len(members), "launch_owned.py": members["launch_owned.py"], "test_launch_owned.py": members["test_launch_owned.py"], "result.json": members["result.json"], "manifest.json": pin(HERE / "manifest.json")}, indent=2))
