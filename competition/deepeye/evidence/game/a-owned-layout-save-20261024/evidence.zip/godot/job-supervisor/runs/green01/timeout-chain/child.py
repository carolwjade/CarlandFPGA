import os, subprocess, sys, time
child = subprocess.Popen([sys.executable, '-I', '-B', '-c', "import os,time; print('GRANDCHILD_PID='+str(os.getpid()), flush=True); time.sleep(60)"])
print('CHILD_PID=' + str(os.getpid()) + ' GRANDCHILD_POPEN_PID=' + str(child.pid), flush=True)
time.sleep(60)
