# Owned Windows launcher supervisor

Work `A-G02-LAUNCHER-JOB-SUPERVISOR-20261024-v1`, owner `/root/launcher_job_supervisor`, delegated by A Gen3 main `01a16988-bdcb-70e1-ae10-1304b5cf7875`. Desktop/native task under the existing 2026-10-15 authorization; no mesh lease was requested. Only this directory was written. No Godot, GUI, board, provider, service or product execution was performed.

Read and verified the current A skill/role, collaboration protocol, director transfer/handoff and both immutable-scope files. The canonical requirements SHA-256 is `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`; H01–H15 remain unchanged. This harness establishes process containment evidence only, with no G02 or other card acceptance.

## Invocation

Use the existing project venv Python, absolute paths and a fresh result directory whose parent already exists:

```powershell
& '.local/venv/Scripts/python.exe' -I -B -X utf8 '<absolute>/launch_owned.py' --config '<absolute>/config.json'
```

The JSON object requires exactly `command` (argv list, existing absolute .exe first), `cwd` (existing absolute directory), `env` (explicit mapping), `timeout_seconds` (0 < finite value <= 3600) and `result_dir` (fresh absolute directory). There is no shell and no inherited environment merge. The caller must supply its previously approved environment allowlist, logs/data directories and argv; this is a trusted local harness, not a sandbox for hostile programs. Configuration is effectful once only: the result directory is exclusively created, and reuse fails without replay. Existing logs/results are never replaced or deleted.

The new unnamed JobObject is non-inheritable, sets only `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE` (no breakaway), and exists before `CreateProcessW`. The original executable is created suspended/console-hidden, with a three-entry standard-handle inheritance list; its returned original process HANDLE is assigned to the Job before `ResumeThread`. No PID process lookup, reparenting, adoption or PID-based termination occurs. Ordinary descendant `CreateProcess` calls remain in the Job. On timeout, one consumed `TerminateJobObject(...,125)` is followed by actual Job accounting queries until active processes reach zero or a ten-second stop observation bound expires. This is an ordinary-scheduler bound, not a kernel scheduling guarantee. Closing the Job is a final containment backstop, never substituted for observed zero. A creation/assignment failure never resumes the uncertain process: the original HANDLE is terminated and waited instead.

The raw logs are `stdout.bin` and `stderr.bin`; `command.json` records argv, environment key names/hash (not values), native outcomes, original process/thread IDs and HANDLE values, exact original HANDLE wait/exit, accounting samples, consumed termination and checked handle closes. The attribute-list size query intentionally returns false/error 122 and is labeled as such. `DeleteProcThreadAttributeList` has no status return; only call completion is recorded.

**Supervisor return 0 means the supervision completed successfully; it does not mean the child returned 0.** The actual success test deliberately returns child exit 7 and supervisor exit 0. For an expected-success Godot run, the caller must require all of: confirmed assignment and resume, `original_process.wait_completed == true`, the expected `original_process.exit_code` (normally 0), `job_active_processes_final == 0`, `chain_stopped == true`, `cleanup_checked == true`, `error == null`, and `timed_out == false`. A missing/unknown exit or a close-only backstop cannot establish success. Descendant individual exit codes are not collected; only original HANDLE exit and total Job liveness are claimed.

## Actual new checks

`red01.log` preserves two intended missing-supervisor failures before implementation. `green01.log` preserves both new Python-only checks passing, 2.304 seconds/exit 0. Their complete independent result records and raw streams are retained in `runs/green01`:

- Short actual project-venv redirector -> base Python: original HANDLE exit 7, exact wait complete, Job active 0, no termination, checked closes; actual child stdout and stderr retained.
- Actual project-venv redirector -> Python -> grandchild chain: two-second timeout, one Job termination with exit 125, exact original HANDLE wait complete, active count read back 0, checked closes. Actual PID lines, peak accounting and native outcomes are retained, rather than inferred from timeout.

No old tests were run. A later read-only summary command first omitted UTF-8 when decoding the Chinese path and failed with `UnicodeDecodeError`; it created no process effects, changed no records, and was corrected by explicit `-X utf8`/encoding. It is not a supervisor/test failure.

## Primary API references

[Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects) documents descendant association and breakaway rules. [AssignProcessToJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-assignprocesstojobobject) documents association through the supplied HANDLE. [CreateProcessW](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessw) and [UpdateProcThreadAttribute](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute) support the mutable command line, explicit environment and restricted inherited handles. [TerminateJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-terminatejobobject) describes termination of the associated Job chain; [basic accounting](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_basic_accounting_information) defines the active/total counts. The ctypes limit layout follows [extended limits](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information).
