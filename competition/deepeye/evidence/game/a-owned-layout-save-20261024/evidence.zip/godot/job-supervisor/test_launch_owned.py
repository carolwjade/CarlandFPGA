"""New Python-only behavioral checks; all process effects stay in --run-dir."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

HERE = Path(__file__).resolve().parent
SUPERVISOR = HERE / "launch_owned.py"
RUN_ROOT = None
PROJECT_PYTHON = Path.cwd() / ".local/venv/Scripts/python.exe"


class OwnedJobTests(unittest.TestCase):
    def invoke(self, name, source, timeout):
        self.assertTrue(SUPERVISOR.is_file(), "JobObject supervisor is not implemented")
        run = RUN_ROOT / name
        run.mkdir(parents=True, exist_ok=False)
        script = run / "child.py"
        script.write_text(source, encoding="utf-8")
        temp = run / "temp"
        temp.mkdir()
        env = {key: os.environ[key] for key in ("SystemRoot", "WINDIR", "SystemDrive") if key in os.environ}
        env.update({"TEMP": str(temp), "TMP": str(temp), "PYTHONDONTWRITEBYTECODE": "1"})
        config = {"command": [str(PROJECT_PYTHON), "-I", "-B", str(script)],
                  "cwd": str(run), "env": env, "timeout_seconds": timeout,
                  "result_dir": str(run / "result")}
        config_path = run / "config.json"
        config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
        completed = subprocess.run([str(PROJECT_PYTHON), "-I", "-B", str(SUPERVISOR), "--config", str(config_path)],
                                   cwd=Path.cwd(), capture_output=True, timeout=25)
        (run / "supervisor-stdout.bin").write_bytes(completed.stdout)
        (run / "supervisor-stderr.bin").write_bytes(completed.stderr)
        self.assertEqual(completed.returncode, 0, completed.stderr.decode("utf-8", "replace"))
        result = json.loads((run / "result/command.json").read_text(encoding="utf-8"))
        self.assertTrue(result["chain_stopped"])
        self.assertEqual(result["job_active_processes_final"], 0)
        self.assertTrue(result["original_process"]["wait_completed"])
        self.assertTrue(result["cleanup_checked"])
        self.assertTrue(all(item["ok"] for item in result["handle_closes"]))
        calls = [item["api"] for item in result["native_calls"]]
        self.assertLess(calls.index("SetInformationJobObject"), calls.index("CreateProcessW"))
        self.assertLess(calls.index("AssignProcessToJobObject"), calls.index("ResumeThread"))
        self.assertEqual(result["inherited_handle_count"], 3)
        return run, result

    def test_short_actual_child_success_records_original_handle_exit(self):
        run, result = self.invoke("success", "import os, sys\nprint('ACTUAL_CHILD_PID=' + str(os.getpid()), flush=True)\nprint('raw-error', file=sys.stderr, flush=True)\nsys.exit(7)\n", 5)
        self.assertFalse(result["timed_out"])
        self.assertEqual(result["original_process"]["exit_code"], 7)
        self.assertFalse(result["termination_consumed"])
        self.assertIn(b"ACTUAL_CHILD_PID=", (run / "result/stdout.bin").read_bytes())
        self.assertIn(b"raw-error", (run / "result/stderr.bin").read_bytes())

    def test_actual_grandchild_timeout_job_reaches_active_zero(self):
        source = """import os, subprocess, sys, time
child = subprocess.Popen([sys.executable, '-I', '-B', '-c', "import os,time; print('GRANDCHILD_PID='+str(os.getpid()), flush=True); time.sleep(60)"])
print('CHILD_PID=' + str(os.getpid()) + ' GRANDCHILD_POPEN_PID=' + str(child.pid), flush=True)
time.sleep(60)
"""
        run, result = self.invoke("timeout-chain", source, 2)
        self.assertTrue(result["timed_out"])
        self.assertTrue(result["termination_consumed"])
        self.assertEqual(result["original_process"]["exit_code"], 125)
        self.assertGreaterEqual(result["job_peak_active_processes"], 2)
        self.assertIn(b"GRANDCHILD_PID=", (run / "result/stdout.bin").read_bytes())
        termination = [call for call in result["native_calls"] if call["api"] == "TerminateJobObject"]
        self.assertEqual(len(termination), 1)
        self.assertTrue(termination[0]["ok"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    args = parser.parse_args()
    RUN_ROOT = Path(args.run_dir).resolve()
    RUN_ROOT.mkdir(parents=True, exist_ok=False)
    unittest.main(argv=[sys.argv[0]], verbosity=2)
