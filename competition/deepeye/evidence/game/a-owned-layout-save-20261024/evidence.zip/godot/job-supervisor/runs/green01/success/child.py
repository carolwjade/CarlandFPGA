import os, sys
print('ACTUAL_CHILD_PID=' + str(os.getpid()), flush=True)
print('raw-error', file=sys.stderr, flush=True)
sys.exit(7)
