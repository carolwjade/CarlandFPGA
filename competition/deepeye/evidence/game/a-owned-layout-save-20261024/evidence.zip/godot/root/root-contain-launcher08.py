"""One consumed containment of a positively identified, already orphaned test Godot."""
import ctypes as c
from ctypes import wintypes as w
from datetime import datetime, timezone
import json, os
from pathlib import Path

HERE=Path(__file__).resolve().parent
RESULT=HERE/'root-launcher08-containment.json'
PID=9632
EXPECTED_CREATION_UNIX_US=1792798719370567
EXPECTED_IMAGE=HERE.parents[1]/'deepeye-implementation-a/app-worker-ui/godot/Godot_v4.7.2-stable_win64.exe'
k=c.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE
k.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,c.POINTER(w.DWORD)];k.QueryFullProcessImageNameW.restype=w.BOOL
k.GetProcessTimes.argtypes=[w.HANDLE]+[c.POINTER(w.FILETIME)]*4;k.GetProcessTimes.restype=w.BOOL
k.WaitForSingleObject.argtypes=[w.HANDLE,w.DWORD];k.WaitForSingleObject.restype=w.DWORD
k.TerminateProcess.argtypes=[w.HANDLE,w.UINT];k.TerminateProcess.restype=w.BOOL
k.GetExitCodeProcess.argtypes=[w.HANDLE,c.POINTER(w.DWORD)];k.GetExitCodeProcess.restype=w.BOOL
k.CloseHandle.argtypes=[w.HANDLE];k.CloseHandle.restype=w.BOOL
record={'utc':datetime.now(timezone.utc).isoformat(),'pid_lookup_only':PID,'expected_creation_unix_us':EXPECTED_CREATION_UNIX_US,'expected_image':str(EXPECTED_IMAGE),'authority':'Root-owned headless launcher08 containment; no replay or product effects'}
def save():
    RESULT.write_text(json.dumps(record,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
def check(ok,what):
    if not ok:raise OSError(c.get_last_error(),what)
with (HERE/'root-launcher08-containment-started.json').open('x',encoding='utf-8') as stream:
    json.dump(record,stream)
handle=None
try:
    handle=k.OpenProcess(0x00100000|0x1000|0x0001,False,PID)
    check(handle,'OpenProcess');record['owned_handle_opened']=True
    image=c.create_unicode_buffer(32768);size=w.DWORD(len(image))
    check(k.QueryFullProcessImageNameW(handle,0,image,c.byref(size)),'QueryFullProcessImageNameW')
    created,exited,kernel,user=(w.FILETIME() for _ in range(4))
    check(k.GetProcessTimes(handle,c.byref(created),c.byref(exited),c.byref(kernel),c.byref(user)),'GetProcessTimes')
    ticks=(created.dwHighDateTime<<32)|created.dwLowDateTime
    unix_us=(ticks-116444736000000000)//10
    record.update(actual_image=image.value,actual_creation_filetime=ticks,actual_creation_unix_us=unix_us)
    if os.path.normcase(os.path.abspath(image.value))!=os.path.normcase(os.path.abspath(EXPECTED_IMAGE)) or unix_us!=EXPECTED_CREATION_UNIX_US:
        raise RuntimeError('Image/creation identity mismatch: no termination authorized')
    record['same_handle_identity_verified']=True
    before=k.WaitForSingleObject(handle,0);record['wait_before']=before
    if before==258:
        record['terminate_consumed']=True;save()
        ok=k.TerminateProcess(handle,125);record['terminate_return']=bool(ok)
        if not ok:record['terminate_error']=c.get_last_error()
        save()
        # TerminateProcess success is never treated as exit proof.
        record['wait_after']=k.WaitForSingleObject(handle,10000)
    elif before==0:record['wait_after']=0;record['already_exited']=True
    else:raise RuntimeError('Unexpected initial wait result')
    if record['wait_after']!=0:raise RuntimeError('Exact process exit unresolved')
    code=w.DWORD();check(k.GetExitCodeProcess(handle,c.byref(code)),'GetExitCodeProcess')
    record.update(exact_handle_signaled=True,exact_exit_code=code.value,terminal=True)
except BaseException as exc:
    record['failure']=repr(exc);save();raise
finally:
    if handle:record['close_handle_return']=bool(k.CloseHandle(handle))
    save()
print(json.dumps(record,ensure_ascii=True))
