import importlib.util, os, pathlib, tempfile, unittest

PATH=pathlib.Path(__file__).parent/'candidate/simulator/native/run_viewer.py'
class LauncherTests(unittest.TestCase):
    def test_explicit_headless_command(self):
        spec=importlib.util.spec_from_file_location('private_launcher_command',PATH)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        if not hasattr(module,'viewer_command'):
            self.fail('Launcher has no explicit headless command builder')
        self.assertEqual(module.viewer_command(pathlib.Path('C:/engine.exe'),pathlib.Path('C:/project'),True),['C:\\engine.exe','--headless','--path','C:\\project'])
    def test_child_environment_filters_provider_credentials(self):
        if not PATH.exists():
            self.fail('Source-tree launcher does not yet provide credential-filtered child environment')
        spec=importlib.util.spec_from_file_location('private_launcher',PATH)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        root=pathlib.Path(__file__).parent/'runs/launcher-env'
        source={'SYSTEMROOT':os.environ['SYSTEMROOT'],'OPENAI_API_KEY':'test-sentinel','FPGA_HMAC_KEY':'test-sentinel','PATH':'test-sentinel','PYTHONPATH':'test-sentinel','DEEPEYE_TEST_ROOT':'test-sentinel'}
        env=module.child_environment(root,source)
        self.assertNotIn('OPENAI_API_KEY',env)
        self.assertNotIn('FPGA_HMAC_KEY',env)
        self.assertNotIn('PATH',env)
        self.assertNotIn('PYTHONPATH',env)
        self.assertNotIn('DEEPEYE_TEST_ROOT',env)
        self.assertEqual(env['SYSTEMROOT'],source['SYSTEMROOT'])
        self.assertEqual(pathlib.Path(env['TEMP']).parent,root)
        self.assertIn('executable',env['DEEPEYE_LAYOUT_RUNTIME'])
if __name__=='__main__': unittest.main()
