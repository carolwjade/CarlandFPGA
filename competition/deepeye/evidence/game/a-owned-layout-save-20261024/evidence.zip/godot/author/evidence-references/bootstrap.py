import os, threading
_layout_watchdog = threading.Timer(6.0, lambda: os._exit(124))
_layout_watchdog.daemon = True
_layout_watchdog.start()
import hashlib, json, re, sys
def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate")
        result[key] = value
    return result
try:
    if len(sys.argv) != 5 or sys.argv[1] != "--bundle" or sys.argv[3] != "--bundle-sha256":
        raise ValueError("arguments")
    bundle_path, bundle_sha = sys.argv[2], sys.argv[4]
    if not os.path.isabs(bundle_path) or not re.fullmatch("[0-9a-f]{64}", bundle_sha):
        raise ValueError("binding")
    with open(bundle_path, "rb") as stream:
        raw = stream.read(8193)
    if len(raw) > 8192 or hashlib.sha256(raw).hexdigest() != bundle_sha:
        raise ValueError("bundle_pin")
    bundle = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique)
    if type(bundle) is not dict or set(bundle) != {"schema", "helper", "leaf"} or type(bundle["schema"]) is not int or bundle["schema"] != 1:
        raise ValueError("bundle_schema")
    for name, filename in (("helper", "layout_commit_cli.py"), ("leaf", "layout_commit_windows.py")):
        entry = bundle[name]
        if type(entry) is not dict or set(entry) != {"path", "sha256"} or entry["path"] != filename or type(entry["sha256"]) is not str or not re.fullmatch("[0-9a-f]{64}", entry["sha256"]):
            raise ValueError("bundle_entry")
    helper_path = os.path.join(os.path.dirname(bundle_path), bundle["helper"]["path"])
    with open(helper_path, "rb") as stream:
        helper_raw = stream.read(131073)
    if len(helper_raw) > 131072 or hashlib.sha256(helper_raw).hexdigest() != bundle["helper"]["sha256"]:
        raise ValueError("helper_pin")
except BaseException:
    sys.stderr.write("pre_leaf_rejected:bootstrap_binding; leaf_called=false\n")
    sys.exit(2)
exec(compile(helper_raw, helper_path, "exec"), {"__name__": "__main__", "__file__": helper_path, "_layout_watchdog": _layout_watchdog})
