"""Separate pinned, test-only adapters. No production fault switches."""
import json, pathlib, shutil
from setup import HERE, SIM, dump, sha

TEMPLATE='''# TEST-ONLY %(mode)s adapter; not production helper.
import hashlib, json, os, struct, sys, time, types
def exact(n):
    data=b''
    while len(data)<n:
        chunk=sys.stdin.buffer.read(n-len(data))
        if not chunk: raise ValueError('short')
        data+=chunk
    return data
assert exact(4)==b'DLC1'
n=struct.unpack('>I',exact(4))[0]
assert 0<n<=4096
meta=json.loads(exact(n).decode('utf-8'))
payload=exact(meta['payload_bytes'])
assert hashlib.sha256(payload).hexdigest()==meta['payload_sha256']
root=os.path.dirname(__file__)
with open(os.path.join(root,'layout_commit_windows.py'),'rb') as f: leaf_raw=f.read()
assert hashlib.sha256(leaf_raw).hexdigest()=='521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f'
leaf=types.ModuleType('_test_only_checked_leaf');leaf.__file__=os.path.join(root,'layout_commit_windows.py')
exec(compile(leaf_raw,leaf.__file__,'exec'),leaf.__dict__)
%(body)s
'''
for mode,body in {
 'before':"time.sleep(30) # watchdog124 before leaf call/publication\n",
 'loss':"result=leaf.commit_new(meta['target'],payload)\nassert result['state']=='committed'\ntime.sleep(30) # watchdog124 after real publication; response intentionally lost\n",
 'delay':"time.sleep(5.3)\nresult=leaf.commit_new(meta['target'],payload)\nresult.update(protocol=meta['protocol'],operation_id=meta['operation_id'],payload_bytes=len(payload),payload_sha256=meta['payload_sha256'],leaf_called=True)\nraw=json.dumps(result,separators=(',',':'),ensure_ascii=True).encode('utf-8')\nsys.stdout.buffer.write(b'DLR1'+struct.pack('>I',len(raw))+raw)\nsys.stdout.buffer.flush()\n_layout_watchdog.cancel()\n",
 'trailing':"result=leaf.commit_new(meta['target'],payload)\nresult.update(protocol=meta['protocol'],operation_id=meta['operation_id'],payload_bytes=len(payload),payload_sha256=meta['payload_sha256'],leaf_called=True)\nraw=json.dumps(result,separators=(',',':'),ensure_ascii=True).encode('utf-8')\nsys.stdout.buffer.write(b'DLR1'+struct.pack('>I',len(raw))+raw+b'!')\nsys.stdout.buffer.flush()\n_layout_watchdog.cancel()\n",
 'split':"result=leaf.commit_new(meta['target'],payload)\nresult.update(protocol=meta['protocol'],operation_id=meta['operation_id'],payload_bytes=len(payload),payload_sha256=meta['payload_sha256'],leaf_called=True)\nraw=json.dumps(result,separators=(',',':'),ensure_ascii=True).encode('utf-8')\nframe=b'DLR1'+struct.pack('>I',len(raw))+raw\nfor part in (frame[:3],frame[3:18],frame[18:]):\n    sys.stdout.buffer.write(part)\n    sys.stdout.buffer.flush()\n    time.sleep(0.05)\n_layout_watchdog.cancel()\n",
}.items():
 dest=HERE/'candidate/simulator/tests/fixtures'/mode;dest.mkdir(parents=True,exist_ok=True)
 helper=dest/'layout_commit_cli.py';helper.write_text(TEMPLATE%{'mode':mode,'body':body},encoding='utf-8')
 shutil.copyfile(SIM/'native/layout_commit_windows.py',dest/'layout_commit_windows.py')
 bundle=dest/'layout_commit_bundle.json'
 dump(bundle,{'schema':1,'helper':{'path':helper.name,'sha256':sha(helper)},'leaf':{'path':'layout_commit_windows.py','sha256':sha(dest/'layout_commit_windows.py')}})
 (dest/'bridge.gd').write_text('extends "res://editor/layout_commit_bridge.gd"\n\n# Explicit test-only pinned adapter.\nfunc _bundle_spec() -> Dictionary:\n\treturn {"path": "res://tests/fixtures/'+mode+'/layout_commit_bundle.json", "sha256": "'+sha(bundle)+'"}\n',encoding='utf-8')
dump(HERE/'test-fixture-pins.json',{str(p.relative_to(HERE/'candidate')).replace('\\','/'):sha(p) for p in (HERE/'candidate/simulator/tests/fixtures').rglob('*') if p.is_file()})
print('Pinned five separate test-only adapters: before, loss, delay, trailing, split')
