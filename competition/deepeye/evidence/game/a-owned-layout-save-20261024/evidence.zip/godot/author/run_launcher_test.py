"""Final distinct launcher -> Godot -> real helper smoke, headless only."""
import datetime, json, re, subprocess, sys, time
from setup import HERE, GODOT, dump, stage, sha
assert len(list((HERE/'runs').glob('*/command.json')))==7
base,game,env=stage('launcher-08')
project=game/'project.godot'
project.write_text(project.read_text(encoding='utf-8').replace('run/main_scene="res://viewer/main.tscn"','run/main_scene="res://tests/smoke_layout_launcher.tscn"'),encoding='utf-8')
launcher=game/'native/run_viewer.py'
cmd=[sys.executable,'-I','-B',str(launcher),'--godot',str(GODOT),'--run-dir',str(base/'viewer-env'),'--headless']
record={'ordinal':8,'kind':'actual-source-launcher-smoke','command':cmd,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'launcher_sha256':sha(launcher),'headless':True,'timeout_seconds':40}
dump(base/'command.json',record)
started=time.monotonic()
with (base/'stdout.log').open('wb') as out,(base/'stderr.log').open('wb') as err:
    proc=subprocess.Popen(cmd,cwd=game,env=env,stdout=out,stderr=err)
    record['original_launcher_popen_pid']=proc.pid;dump(base/'command.json',record)
    try:code=proc.wait(timeout=40)
    except subprocess.TimeoutExpired:
        record['outer_timeout']=True
        proc.kill();code=proc.wait(timeout=10)
        record['exact_launcher_popen_kill_then_wait_completed']=True
record.update(exit_code=code,exact_launcher_popen_wait_completed=True,elapsed_seconds=time.monotonic()-started)
stdout=(base/'stdout.log').read_text(encoding='utf-8',errors='replace')
pid=re.search(r'DEEPEYE_VIEWER_CHILD_PID=(\d+)',stdout)
exit_match=re.search(r'DEEPEYE_VIEWER_CHILD_EXIT=(-?\d+)',stdout)
if pid:record['launcher_observed_godot_child_pid']=int(pid[1])
if exit_match:record['launcher_observed_godot_child_wait_exit']=int(exit_match[1])
evidence_paths=list((base/'viewer-env').rglob('launcher-evidence.json'))
record['evidence_paths']=[str(p.relative_to(base)).replace('\\','/') for p in evidence_paths]
if len(evidence_paths)==1:
    evidence=json.loads(evidence_paths[0].read_text(encoding='utf-8'))
    record['gdscript_godot_process_id']=evidence['godot_process_id']
    record['layers_agree']=record.get('launcher_observed_godot_child_pid')==evidence['godot_process_id'] and record.get('launcher_observed_godot_child_wait_exit')==0 and bool(evidence['ok'])
dump(base/'command.json',record)
print(json.dumps(record,ensure_ascii=True));print(stdout);print((base/'stderr.log').read_text(encoding='utf-8',errors='replace'))
assert code==0 and record.get('layers_agree') and not record.get('outer_timeout',False),record
