# G02 owned Save As caller: frozen v2

Work `A-G02-GODOT-OWNED-SAVE-20261024-v1`, author
`/root/godot_owned_save_author`, job child-9277e51745cf4379800704d2438551f9.
The candidate has9 production overlays and23 required test/fixture members,
mapped to canonical product paths in `selection-mapping.json`. Product W was
not edited. Root independent delta review, selection and acceptance remain
separate. No commit/push or ZIP was made.

The final actual source-launcher run10 passed **21 checks/0 failures**: the
reviewed namespace cases returned invalid_path with zero helpers/zero parents;
actionless and post-reap cancellation preserved results, normal new-dialog
cancellation worked; and a real helper saved/reopened a Unicode layout with the
same codec hash.966 frames advanced. Runtime binding and credential filtering
were checked inside that launched Godot. The original launcher HANDLE waited
exit0; launcher-observed and GDScript Godot PID2296 agree, and the launcher waited
that child to exit0. The JobObject was assigned before resume, active count
reached0, cleanup was checked, and neither timeout nor error occurred.

`candidate-product-manifest-v2.json` pins the exact final9 production members.
`source-bindings-v2.json` separates these results from the earlier full81-check
run05 and the7-check guard run07. Those earlier checks are not silently rebound
to v2. The v1 raw9-member snapshot and its original manifest are retained through
`candidate-v1-pinmapping.json`. Only bridge/shell differ in v2: leaf-equivalent
namespace preflight, an actionless-cancel guard, and a single canonical Windows
unknown-path key. The native leaf remains unchanged at
521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f.

## Behavior and safety boundary

The shell awaits `save_new_async`; the safe synchronous `save_new` waits finitely
over the same retained worker. There is one unresolved helper owner across
stores. Pending shows a separate Chinese hint and inhibits Save/Open without
changing geometry/history/selection/run/link/control. UI expiry5000ms returns
unknown: the file may exist, no automatic replay/delete follows, and ordinary
editing may resume. A late trusted result is separate evidence and never
replaces the original unknown or reapplies an old geometry snapshot.

The worker alone owns one blocking framed pipe exchange. Metadata<=4096,
strict UTF8 payload<=1MiB, response<=16384, stderr<=4096. Payload/target never
enter argv. Partial response bytes accumulate, false store_buffer never
retransmits, and trailing/truncated/oversized output remains unknown. After
exact child exit, bounded terminal drain uses no Peek/EOF/flush/get_line/NOWAIT
or log suppression. Current pinned helper/fixtures spawn no extra writer;
production stderr cannot fill its pipe before exit. Godot hides the underlying
Win32 read error: zero before complete frame is unknown; only after exact exit
and those exclusive-writer conditions is zero this scope's drain endpoint.

The helper's6s watchdog starts before stdin/leaf loading and only os._exit(124)
is allowed.124 proves neither publication nor failure. Interpreter startup,
scheduler/kernel stalls remain outside a hard deadline; unresolved work stays
retained and no live thread is joined. Only a completed worker plus nonnegative
original child exit and exclusive unreleased Godot map ownership permits one
cleanup-only OS.kill, consumed before the call. FAILED(1) is not exit evidence
and never causes retry. Tested map queries became-1 afterward; Godot does not
expose CloseHandle returns, so kernel-handle-close verification is not claimed.

The leaf alone owns exclusive-source HANDLE write/flush/readback/no-replace
publication. No old Godot write/rename or path-cleanup fallback remains.
Namespace checks now match reserved-stem trailing-space/superscript rules and
parent UTF16+41<260 before helper/mkdir. Parent creation is still a separate
non-atomic convenience after runtime preflight; a later unsupported-volume or
ancestry rejection can leave created parents. No path is swept/adopted/deleted.
Ordinary fixed local NTFS/direct HarddiskVolume mapping is the accepted scope;
privileged namespace/filter/ACL/drive remapping and power-loss durability are
outside it.

The explicit source-tree launcher pins the actual Godot image, current Python
identity and helper/leaf bytes, then creates an allowlisted child environment.
No global env/config/provider/credential/service changes occur. Launcher-I-B
allows CPython3.12 to establish its venv prefix; helper-I-S-B-u and the fixed
quote-free hex bootstrap execute the same checked source bytes. The existing
CPython/stdlib installation is trusted, not a complete anti-tamper closure.
Export/PCK delivery still needs an explicit reviewed physical sidecar/runtime
installation. The file boundary is viewer-private geometry, not an AI/provider/
control service or proof against other OS processes reading user-selected files.

## Actual checks and retained failures

| Run | Actual result and scope |
| --- | --- |
|01|exit1, intended missing-await-API RED.|
|02|Raw bootstrap quoting failed; later test-only missing-property fault skipped final helper-exit serialization. Original outer Popen kill+wait exit1 after55.016s; individual02 helper exit numbers are not claimed. No request replay.|
|03|exit0,64/0 checks; exact engine broken-pipe Peek logs retained.|
|04|exit0,75/0 checks; same Peek logs retained.|
|05|exit0,81/0 checks,20.079s, empty stderr; full exact-read/drain caller checks.|
|06|exit1,7 checks/1 failure: late cancellation replaced unknown.|
|07|exit0,7/0 checks, empty stderr; first final-guard evidence.|
|08|Actual launcher started Godot, but a new smoke-scene type-inference parse error prevented helper/save. Outer venv redirector40336 waited exit1 after controlled kill. Root separately verified original Godot9632 identity on one HANDLE and terminated/waited exit125. Base Python34244 exit remains unknown; CIM absence is not exit proof.|
|09|Root-authorized targeted RED on frozen v1:16 checks/11 namespace+cancel failures. Original HANDLE waited exit1; Godot28504 IDs/launcher wait1 agree; assigned Job active0/checked cleanup/noerror/nottimedout.|
|10|Root-authorized targeted GREEN on final v2:21/0 checks and actual launcher save/reopen. Original HANDLE pid3372 waited exit0; Godot2296/launcher wait0 agree; assigned Job active0/checked cleanup/noerror/nottimedout.|

The original8-run budget was extended only by root's explicit `revision-budget`
authorization for09/10; total Godot invocations10, no11. Source/records01–09
were never patched. All failed stages, sentinel files, possible effects and
metadata remain locally retained. Only necessary public files are selected in
the final manifest; old duplicated stages/cache/payloads are not repackaged.

Run05 covers actual nested-parent Unicode/nonBMP bytes and codec-hash reopen,
safe synchronous empty save, exact1MiB/overlimit, existing file/directory
sentinels, missing/mismatched runtime zero launches, responsive pending UI and
unchanged document/history/selection/run/link/control.727 frames advanced with
unknown at5060ms. A later explicit edit survived the late notice. Two124
fixtures demonstrate both absent target before publish and retained committed
bytes after lost response. Delayed success stayed separate from unknown;
trailing1 byte rejected success while retaining the commit; split framing
observed2 partial reads without byte loss. All ten run05 helpers have exact
exit/completed-worker/reap/single-cleanup records.

The separately leased CLI child completed19 new cases/45 process observations;
its terminal non-stale receipt is retained. All123 members of its frozen manifest
were rechecked before assembly. The earlier native leaf19 NTFS race tests were
reused unchanged. Launcher environment unit RED/GREEN, the initial-S prefix
failure and corrected-I-B validate-only gates are retained separately.

The alias diagnostic in09 used all-backslash versus all-forward input. Godot
normalized those to one path, so09 did **not** reproduce an alias bypass.10
exercised the same forms and refused a second helper. The true mixed drive
prefix (`C:\folder/file` vs `C:/folder/file`) was **not behaviorally tested**.
Root/reviewer accept the final all-backslash validated `windows_path.to_lower()`
lookup/write/job-key unification as source-reviewed hardening only. No extra run
or broader namespace/alias guarantee is invented.

## Identity, ownership and acceptance

Lease validation bound the actual canonical author before project reads. Active
director remains Gen3 01a16988-bdcb-70e1-ae10-1304b5cf7875. Requirements canonical
SHA256 was recomputed as
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804;
H01-H15/fullH12 are unchanged. Final read-only verification confirms53 product
simulator inputs, all4 C4 files, Git index/head and all6 original cache members
unchanged. The exact verified engine remains ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424.

No product write, commit/push, board action, display/GPU/UI capture, provider/
credential/config/service/listener/peer/group effect, old618/696/384 suite,
solver or old native-test replay occurred. Source-tree headless proof is not
formal mouse/DPI/fullG02, H09, physical board, dual control-chain or all29
acceptance. G02 remains open; G03/R03/all29 remain not_run. Root owns independent
final delta review and selection.
