"""Owned staging and immutable input snapshot; no product mutations."""
import hashlib, json, os, pathlib, shutil, subprocess, sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[3]
W = ROOT / '.local/deepeye-implementation-a'
SIM = W / 'competition/deepeye/simulator'
GODOT = ROOT / '.planning/deepeye-implementation-a/app-worker-ui/godot/Godot_v4.7.2-stable_win64.exe'
PIN = 'ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p, v):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(v, ensure_ascii=True, indent=2)+'\n', encoding='utf-8')
def snapshot():
    scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
    canonical=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    assert canonical=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    assert sha(GODOT)==PIN
    protected=json.loads((ROOT/'.planning/deepeye-resume-20261018/r03-mailbox-stop-main-review-20261020/application.json').read_text())['protected_files']
    files=[p for p in SIM.rglob('*') if p.is_file() and '.godot' not in p.parts and '__pycache__' not in p.parts]
    inputs={str(p.relative_to(W)).replace('\\','/'):sha(p) for p in files}
    c4={s:sha(W/s) for s in protected}
    gitfile=(W/'.git').read_text().strip().split(': ',1)[1]
    gitdir=pathlib.Path(gitfile)
    if not gitdir.is_absolute(): gitdir=W/gitdir
    index=gitdir/'index'
    cache={str(p.relative_to(SIM)).replace('\\','/'):sha(p) for p in (SIM/'.godot').rglob('*') if p.is_file()}
    head=subprocess.run(['git','-C',str(W),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
    v={'canonical_sha256':canonical,'godot':str(GODOT),'godot_sha256':sha(GODOT),'head':head,'inputs':inputs,'protected':c4,'index_sha256':sha(index),'cache':cache,'python':sys.executable}
    dump(HERE/'baseline.json',v)
    return v
def stage(label):
    base=HERE/'runs'/label
    assert not base.exists()
    game=base/'simulator'
    game.mkdir(parents=True)
    # Only live text dependencies of the new caller. No old tests/assets/cache.
    names=['project.godot','editor/scene_document.gd','editor/layout_codec.gd','editor/gate_numeric.gd','editor/gate_json_numbers.gd','editor/layout_store.gd','ui/shell.gd','native/layout_commit_windows.py']
    for name in names:
        dst=game/name; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(SIM/name,dst)
    cand=HERE/'candidate'
    if cand.exists():
        for p in cand.rglob('*'):
            if p.is_file():
                rel=p.relative_to(cand)
                # candidate is rooted at competition/deepeye
                dst=(base/rel) if rel.parts[0]=='simulator' else (base/rel)
                dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,dst)
    envbase=base/'env'
    env={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR','COMSPEC','SYSTEMDRIVE','NUMBER_OF_PROCESSORS','PROCESSOR_ARCHITECTURE')}
    for key in ['TEMP','TMP','APPDATA','LOCALAPPDATA','USERPROFILE','HOME','XDG_DATA_HOME','XDG_CACHE_HOME','XDG_CONFIG_HOME']:
        p=envbase/key.lower();p.mkdir(parents=True);env[key]=str(p)
    env['DEEPEYE_TEST_ROOT']=str(base/'targets')
    (base/'targets').mkdir()
    return base,game,env
if __name__=='__main__':
    snapshot()
    print(json.dumps({'snapshot':'baseline.json','godot_verified':True,'contract_verified':True}))
