# CLI helper evidence

Completed assigned candidate implementation and focused evidence only. No
Godot, board, service, network listener, peer/group message, provider/config,
Git operation or product file write occurred. Every write is under cli-author/.
The parent/root owns integration, independent review and acceptance.

The actual native lease validated execution_allowed:true for job
child-80754f81e86a4ead9619be52a4529a60, agent
/root/godot_owned_save_author/cli_helper and work
A-G02-LAYOUT-CLI-20261024-v1 before project operations. The current A identity,
active Gen3 director, mandatory project role/protocol and immutable md/json were
read. The canonical requirements digest was recalculated as
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
All H01-H15 and fullH12 are preserved; G03/R03/all29 remain not_run.

Candidate layout_commit_cli.py SHA256:
8b0512457b2ef5c176b957a46b3172fb15e4cb053b42514d8affd537aa3eb344.
Fixed bootstrap.py SHA256:
0b2ef958006c47b1b74ff303bf36996769bad3a8616d8a15df6d8e514f606d14.
Selected existing leaf raw hash was checked before tests and afterward:
521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f.
Only that leaf's checked raw bytes are executed. No old19 primitive tests were
rerun. The production helper's complete launch/bundle/error contract is in
interface.md; its production bundle is intentionally left to the parent.

The retained RED command ran the expected Unicode-save behavior before helper
implementation, failed exit1 with one assertion failure because the new helper
was absent, and left target absent. See red-command.json and runs/red1/.
It was not an old suite or a fixture-only assertion.

Three bounded verification commands then ran only new CLI tests. green1-command
ran13 cases/35 process observations, green2-command ran5 added cases/9 process
observations, green3-command ran1 added case/1 observation. All returned exit0,
with19 cases,0 failures/errors and45 actual process observations in total.
The exact commands and complete outputs are saved, with per-process result
records and stdout/stderr bytes under runs/green1, green2 and green3.

Evidence covers actual Unicode/nonBMP NTFS publication and byte readback;
empty and exact1048576-byte payloads; existing-file sentinel bytes and an
existing-directory child's preservation; digest mismatch, malformed/incomplete
framing, metadata bounds/keys/duplicates/numeric types, invalid UTF-8, oversized
declarations, operation/digest/protocol/target constraints; helper/leaf/bundle
hash and schema rejection; checked bootstrap publication and denial of changed
helper code before execution; denial of changed leaf bytes before execution;
and one request completing without EOF while a second queued frame is ignored.

The actual production watchdog exited124 with empty stdout/stderr while stdin
was held open, at6.047s. Separate test-only adapters reached stalled leaf loading
and then exited124 at6.063s, and called the real leaf once to publish
`published once` before stalling its response and exiting124 at6.079s. The latter
target bytes and the leaf's publication_confirmed:true result remain retained.
This directly demonstrates why124 is unknown and does not authorize cleanup or
retry. Test outer processes were bounded and observed terminal; no watchdog
cleanup or competing PID termination happened in production code.

Runtime was the existing A Python3.12.14,64-bit Windows11 build26200. The tests
executed real selected leaf native calls on the ordinary local filesystem;
they do not claim kernel deadlines, crash/power-loss durability, runtime
distribution readiness, Godot caller/UI behavior, fullG02, H09/H12 or final
acceptance. Existing ordinary parents are required by the leaf. The root's
trusted stdlib boundary and caller runtime/environment pins remain necessary.

No production source change followed the passing runs. The manifest freezes
the selected candidate, bootstrap, test sources, fixed test-only adapters,
commands, report, interface and retained new evidence. It excludes the private
lease, itself and the subsequently persisted native-completion receipt.
