"""Bind every retained run's text inputs without repackaging whole stages."""
import json
from setup import HERE, dump, sha
runs=[]
for base in sorted((HERE/'runs').glob('*')):
 if not (base/'command.json').is_file():continue
 pins=[]
 for p in sorted((base/'simulator').rglob('*')):
  if p.is_file() and '.godot' not in p.relative_to(base/'simulator').parts and (p.suffix in ('.gd','.tscn','.py','.json') or p.name=='project.godot'):
   pins.append({'path':str(p.relative_to(HERE)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)})
 runs.append({'run':base.name,'source_inputs_retained_locally':pins,'whole_stage_not_repackaged':True})
dump(HERE/'run-source-pins.json',runs)
manifest=json.loads((HERE/'manifest.json').read_text())
for name in ['run-source-pins.json','final_source_pins.py','runs/caller-05/simulator/ui/shell.gd','runs/caller-05/simulator/tests/test_layout_commit_bridge.gd']:
 p=HERE/name
 assert not any(e['path']==name for e in manifest['members'])
 manifest['members'].append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
manifest['members'].sort(key=lambda e:e['path'])
manifest['public_member_count']=len(manifest['members'])
manifest['public_bytes']=sum(e['bytes'] for e in manifest['members'])
dump(HERE/'manifest.json',manifest)
for e in manifest['members']:assert sha(HERE/e['path'])==e['sha256'],e['path']
print(json.dumps({'manifest_sha256':sha(HERE/'manifest.json'),'members':len(manifest['members']),'public_bytes':manifest['public_bytes'],'all_members_verified':True}))
