"""One bounded, recorded fresh headless invocation per explicit call."""
import datetime, json, pathlib, subprocess, sys, time
from setup import HERE, GODOT, stage, dump

def run(label, extra_env=None, timeout=55):
    prior=list((HERE/'runs').glob('*/command.json'))
    assert len(prior)<8, 'Godot invocation cap'
    base,game,env=stage(label)
    env['DEEPEYE_LAYOUT_RUNTIME']=json.dumps({'executable':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix},ensure_ascii=True,separators=(',',':'))
    if extra_env: env.update(extra_env)
    cmd=[str(GODOT),'--headless','--path',str(game),'--script','res://tests/test_layout_commit_bridge.gd']
    record={'ordinal':len(prior)+1,'command':cmd,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':timeout,'environment_keys':sorted(env),'stage':str(game)}
    dump(base/'command.json',record)
    started=time.monotonic()
    with (base/'stdout.log').open('wb') as out,(base/'stderr.log').open('wb') as err:
        proc=subprocess.Popen(cmd,cwd=game,env=env,stdout=out,stderr=err)
        record['original_popen_pid']=proc.pid
        dump(base/'command.json',record)
        try: code=proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            # Outer test supervisor owns this exact Popen object, no bare PID.
            proc.kill(); code=proc.wait(timeout=10); record['outer_timeout']=True
            record['exact_popen_kill_then_wait_completed']=True
    record.update(exit_code=code,exact_popen_wait_completed=True,elapsed_seconds=time.monotonic()-started)
    dump(base/'command.json',record)
    print(json.dumps(record,ensure_ascii=True))
    print((base/'stdout.log').read_text(encoding='utf-8',errors='replace'))
    print((base/'stderr.log').read_text(encoding='utf-8',errors='replace'))
    return code
if __name__=='__main__':
    extra={'DEEPEYE_TEST_CASE':sys.argv[2]} if len(sys.argv)>2 else None
    raise SystemExit(run(sys.argv[1],extra))
