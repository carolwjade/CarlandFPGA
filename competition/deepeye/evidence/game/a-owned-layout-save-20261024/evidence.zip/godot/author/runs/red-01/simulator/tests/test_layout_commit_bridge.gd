extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var store = load("res://editor/layout_store.gd").new()
	if not store.has_method("save_new_async"):
		printerr("FAIL: Save As has no awaited safe-worker API")
		quit(1)
		return
	print("PASS: awaited save API exists")
	quit(0)
