import _ctypes, hashlib, json, pathlib, sys
from setup import HERE, dump, sha
base=pathlib.Path(sys.base_prefix)
prefix=pathlib.Path(sys.prefix)
entries=[]
for name in ['python.exe','python312.dll','python3.dll']:
    p=base/name
    assert p.is_file(),name
    entries.append({'origin':'base_prefix','path':name,'sha256':sha(p)})
for p in sorted(base.rglob('libffi*.dll'))+sorted(base.glob('vcruntime*.dll'))+[pathlib.Path(_ctypes.__file__)]:
    entries.append({'origin':'base_prefix','path':p.relative_to(base).as_posix(),'sha256':sha(p)})
cfg=prefix/'pyvenv.cfg'
assert cfg.is_file()
entries.append({'origin':'prefix','path':'pyvenv.cfg','sha256':sha(cfg)})
manifest={'schema':1,'executable_sha256':[sha(pathlib.Path(sys.executable))],'dependencies':entries,'trust_boundary':'Existing approved CPython 3.12 installation and standard library. These small identity pins are not a full runtime or standard-library anti-tamper closure.'}
dest=HERE/'candidate/simulator/native/layout_runtime.json'
dump(dest,manifest)
dump(HERE/'runtime-observation.json',{'executable':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix,'manifest_sha256':sha(dest),'stdlib_installation_trusted':True,'full_runtime_closure':False})
print(json.dumps({'runtime_manifest_sha256':sha(dest),'dependency_count':len(entries)}))
