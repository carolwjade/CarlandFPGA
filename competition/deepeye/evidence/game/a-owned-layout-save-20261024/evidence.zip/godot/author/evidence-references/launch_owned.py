"""Windows-only, stdlib, single-use owned JobObject process-chain supervisor.

Usage: project-python -I -B launch_owned.py --config CONFIG.json
This is a local test harness, not a service, shell, provider, or PID-tree killer.
"""
import argparse
import ctypes as C
from ctypes import wintypes as W
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

DWORD = W.DWORD
HANDLE = W.HANDLE
SIZE_T = C.c_size_t
ULONG_PTR = C.c_size_t
LPVOID = C.c_void_p
INVALID_HANDLE_VALUE = C.c_void_p(-1).value
WAIT_OBJECT_0 = 0
WAIT_TIMEOUT = 258
WAIT_FAILED = 0xFFFFFFFF


class SECURITY_ATTRIBUTES(C.Structure):
    _fields_ = [("nLength", DWORD), ("lpSecurityDescriptor", LPVOID), ("bInheritHandle", W.BOOL)]


class STARTUPINFOW(C.Structure):
    _fields_ = [("cb", DWORD), ("lpReserved", W.LPWSTR), ("lpDesktop", W.LPWSTR),
                ("lpTitle", W.LPWSTR), ("dwX", DWORD), ("dwY", DWORD),
                ("dwXSize", DWORD), ("dwYSize", DWORD), ("dwXCountChars", DWORD),
                ("dwYCountChars", DWORD), ("dwFillAttribute", DWORD), ("dwFlags", DWORD),
                ("wShowWindow", W.WORD), ("cbReserved2", W.WORD),
                ("lpReserved2", C.POINTER(C.c_ubyte)), ("hStdInput", HANDLE),
                ("hStdOutput", HANDLE), ("hStdError", HANDLE)]


class STARTUPINFOEXW(C.Structure):
    _fields_ = [("StartupInfo", STARTUPINFOW), ("lpAttributeList", LPVOID)]


class PROCESS_INFORMATION(C.Structure):
    _fields_ = [("hProcess", HANDLE), ("hThread", HANDLE), ("dwProcessId", DWORD), ("dwThreadId", DWORD)]


class JOBOBJECT_BASIC_LIMIT_INFORMATION(C.Structure):
    _fields_ = [("PerProcessUserTimeLimit", C.c_longlong), ("PerJobUserTimeLimit", C.c_longlong),
                ("LimitFlags", DWORD), ("MinimumWorkingSetSize", SIZE_T),
                ("MaximumWorkingSetSize", SIZE_T), ("ActiveProcessLimit", DWORD),
                ("Affinity", ULONG_PTR), ("PriorityClass", DWORD), ("SchedulingClass", DWORD)]


class IO_COUNTERS(C.Structure):
    _fields_ = [(name, C.c_ulonglong) for name in ("ReadOperationCount", "WriteOperationCount",
                "OtherOperationCount", "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]


class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(C.Structure):
    _fields_ = [("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION), ("IoInfo", IO_COUNTERS),
                ("ProcessMemoryLimit", SIZE_T), ("JobMemoryLimit", SIZE_T),
                ("PeakProcessMemoryUsed", SIZE_T), ("PeakJobMemoryUsed", SIZE_T)]


class JOBOBJECT_BASIC_ACCOUNTING_INFORMATION(C.Structure):
    _fields_ = [("TotalUserTime", C.c_longlong), ("TotalKernelTime", C.c_longlong),
                ("ThisPeriodTotalUserTime", C.c_longlong), ("ThisPeriodTotalKernelTime", C.c_longlong),
                ("TotalPageFaultCount", DWORD), ("TotalProcesses", DWORD),
                ("ActiveProcesses", DWORD), ("TotalTerminatedProcesses", DWORD)]


def utc_now():
    return datetime.now(timezone.utc).isoformat()


class NativeFailure(RuntimeError):
    pass


class Native:
    def __init__(self, result):
        self.result = result
        self.k = C.WinDLL("kernel32", use_last_error=True)
        signatures = {
            "CreateJobObjectW": (HANDLE, [LPVOID, W.LPCWSTR]),
            "SetInformationJobObject": (W.BOOL, [HANDLE, C.c_int, LPVOID, DWORD]),
            "QueryInformationJobObject": (W.BOOL, [HANDLE, C.c_int, LPVOID, DWORD, C.POINTER(DWORD)]),
            "AssignProcessToJobObject": (W.BOOL, [HANDLE, HANDLE]),
            "TerminateJobObject": (W.BOOL, [HANDLE, W.UINT]),
            "TerminateProcess": (W.BOOL, [HANDLE, W.UINT]),
            "CloseHandle": (W.BOOL, [HANDLE]),
            "CreateFileW": (HANDLE, [W.LPCWSTR, DWORD, DWORD, C.POINTER(SECURITY_ATTRIBUTES), DWORD, DWORD, HANDLE]),
            "InitializeProcThreadAttributeList": (W.BOOL, [LPVOID, DWORD, DWORD, C.POINTER(SIZE_T)]),
            "UpdateProcThreadAttribute": (W.BOOL, [LPVOID, DWORD, ULONG_PTR, LPVOID, SIZE_T, LPVOID, C.POINTER(SIZE_T)]),
            "DeleteProcThreadAttributeList": (None, [LPVOID]),
            "CreateProcessW": (W.BOOL, [W.LPCWSTR, W.LPWSTR, LPVOID, LPVOID, W.BOOL, DWORD,
                                      LPVOID, W.LPCWSTR, LPVOID, C.POINTER(PROCESS_INFORMATION)]),
            "ResumeThread": (DWORD, [HANDLE]),
            "WaitForSingleObject": (DWORD, [HANDLE, DWORD]),
            "GetExitCodeProcess": (W.BOOL, [HANDLE, C.POINTER(DWORD)]),
        }
        for name, (restype, argtypes) in signatures.items():
            fn = getattr(self.k, name)
            fn.restype = restype
            fn.argtypes = argtypes

    def call(self, name, *args, kind="bool", detail=None, required=True):
        C.set_last_error(0)
        value = getattr(self.k, name)(*args)
        error = C.get_last_error()
        if kind == "handle":
            ok = value not in (None, 0, INVALID_HANDLE_VALUE)
        elif kind == "resume":
            ok = value != 0xFFFFFFFF
        elif kind == "wait":
            ok = value in (WAIT_OBJECT_0, WAIT_TIMEOUT)
        elif kind == "void":
            ok = True  # API supplies no status; records call completion only.
        else:
            ok = bool(value)
        record = {"api": name, "ok": ok, "value": value, "winerror": error if not ok else 0}
        if detail:
            record.update(detail)
        self.result["native_calls"].append(record)
        if required and not ok:
            raise NativeFailure(f"{name} failed, winerror={error}")
        return value

    def close(self, handle, label):
        if handle:
            ok = bool(self.call("CloseHandle", handle, required=False, detail={"handle_role": label}))
            self.result["handle_closes"].append({"role": label, "ok": ok})


def validate_config(config):
    if set(config) != {"command", "cwd", "env", "timeout_seconds", "result_dir"}:
        raise ValueError("config requires exactly command/cwd/env/timeout_seconds/result_dir")
    command = config["command"]
    if not isinstance(command, list) or not command or any(not isinstance(s, str) or "\0" in s for s in command):
        raise ValueError("command must be a nonempty list of NUL-free strings")
    exe = Path(command[0])
    if not exe.is_absolute() or not exe.is_file() or exe.suffix.lower() != ".exe":
        raise ValueError("command[0] must name an existing absolute .exe")
    cwd = Path(config["cwd"])
    out = Path(config["result_dir"])
    if not cwd.is_absolute() or not cwd.is_dir() or not out.is_absolute():
        raise ValueError("cwd must exist and cwd/result_dir must be absolute")
    env = config["env"]
    if not isinstance(env, dict) or not env:
        raise ValueError("env must be an explicit nonempty mapping; no parent environment merge")
    folded = set()
    for key, value in env.items():
        if not isinstance(key, str) or not key or "=" in key or "\0" in key or not isinstance(value, str) or "\0" in value:
            raise ValueError("invalid environment entry")
        if key.upper() in folded:
            raise ValueError("case-insensitive duplicate environment key")
        folded.add(key.upper())
    timeout = config["timeout_seconds"]
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or not 0 < timeout <= 3600:
        raise ValueError("timeout_seconds must be finite, >0 and <=3600")
    line = subprocess.list2cmdline(command)
    if len(line.encode("utf-16-le")) // 2 + 1 > 32767:
        raise ValueError("Windows command line exceeds 32767 UTF-16 units")
    return command, cwd, out, env, float(timeout), line


def supervise(config):
    if os.name != "nt":
        raise ValueError("Windows is required")
    command, cwd, out, env, timeout, line = validate_config(config)
    out.mkdir(parents=False, exist_ok=False)  # one effectful operation per result directory
    result = {"schema": 1, "started_utc": utc_now(), "command": command, "cwd": str(cwd),
              "environment_keys": sorted(env),
              "environment_sha256": hashlib.sha256(json.dumps(env, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest(),
              "timeout_seconds": timeout, "native_calls": [], "handle_closes": [],
              "original_process": {"pid": None, "thread_id": None, "wait_completed": False, "exit_code": None},
              "assignment_confirmed": False, "resume_confirmed": False, "timed_out": False,
              "termination_consumed": False, "unassigned_termination_consumed": False,
              "job_active_processes_final": None, "job_peak_active_processes": 0,
              "job_accounting_samples": [], "chain_stopped": False, "cleanup_checked": False,
              "inherited_handle_count": 3, "error": None}
    api = Native(result)
    started = time.monotonic()
    job = None
    pi = PROCESS_INFORMATION()
    owned_logs = []
    attributes = None
    attribute_initialized = False
    assigned = False
    resumed = False

    def accounting():
        info = JOBOBJECT_BASIC_ACCOUNTING_INFORMATION()
        api.call("QueryInformationJobObject", job, 1, C.byref(info), C.sizeof(info), None)
        sample = {"elapsed_seconds": round(time.monotonic() - started, 6),
                  "active_processes": info.ActiveProcesses, "total_processes": info.TotalProcesses,
                  "terminated_processes": info.TotalTerminatedProcesses}
        result["job_accounting_samples"].append(sample)
        result["job_active_processes_final"] = info.ActiveProcesses
        result["job_peak_active_processes"] = max(result["job_peak_active_processes"], info.ActiveProcesses)
        return info.ActiveProcesses

    def original_exit(wait_ms=0):
        waited = api.call("WaitForSingleObject", pi.hProcess, wait_ms, kind="wait")
        if waited == WAIT_OBJECT_0:
            result["original_process"]["wait_completed"] = True
            code = DWORD()
            api.call("GetExitCodeProcess", pi.hProcess, C.byref(code))
            result["original_process"]["exit_code"] = code.value
        return waited == WAIT_OBJECT_0

    def stop_assigned():
        if not result["termination_consumed"]:
            result["termination_consumed"] = True  # mark before the native effect
            api.call("TerminateJobObject", job, 125, required=False)
        stop_deadline = time.monotonic() + 10.0
        while True:
            active = accounting()
            if active == 0:
                result["chain_stopped"] = True
                break
            if time.monotonic() >= stop_deadline:
                break
            time.sleep(0.02)
        original_exit(1000)

    try:
        job = api.call("CreateJobObjectW", None, None, kind="handle")
        limits = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        limits.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE; no breakaway
        api.call("SetInformationJobObject", job, 9, C.byref(limits), C.sizeof(limits))
        sa = SECURITY_ATTRIBUTES(C.sizeof(SECURITY_ATTRIBUTES), None, True)
        stdin = api.call("CreateFileW", "NUL", 0x80000000, 3, C.byref(sa), 3, 0x80, None, kind="handle")
        owned_logs.append((stdin, "stdin_nul"))
        stdout = api.call("CreateFileW", str(out / "stdout.bin"), 0x40000000, 3, C.byref(sa), 1, 0x80, None, kind="handle")
        owned_logs.append((stdout, "stdout_file"))
        stderr = api.call("CreateFileW", str(out / "stderr.bin"), 0x40000000, 3, C.byref(sa), 1, 0x80, None, kind="handle")
        owned_logs.append((stderr, "stderr_file"))
        attr_size = SIZE_T()
        api.call("InitializeProcThreadAttributeList", None, 1, 0, C.byref(attr_size),
                 required=False, detail={"phase": "size_query", "expected_winerror": 122})
        if C.get_last_error() != 122 or not attr_size.value:
            raise NativeFailure("attribute size query did not return expected size/error122")
        attributes = C.create_string_buffer(attr_size.value)
        api.call("InitializeProcThreadAttributeList", attributes, 1, 0, C.byref(attr_size))
        attribute_initialized = True
        handle_list = (HANDLE * 3)(stdin, stdout, stderr)
        api.call("UpdateProcThreadAttribute", attributes, 0, 0x20002,
                 C.cast(handle_list, LPVOID), C.sizeof(handle_list), None, None)
        si = STARTUPINFOEXW()
        si.StartupInfo.cb = C.sizeof(si)
        si.StartupInfo.dwFlags = 0x100 | 1  # STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW
        si.StartupInfo.wShowWindow = 0
        si.StartupInfo.hStdInput, si.StartupInfo.hStdOutput, si.StartupInfo.hStdError = stdin, stdout, stderr
        si.lpAttributeList = C.cast(attributes, LPVOID)
        env_block = C.create_unicode_buffer("\0".join(f"{k}={v}" for k, v in sorted(env.items(), key=lambda pair: pair[0].upper())) + "\0\0")
        command_line = C.create_unicode_buffer(line)
        flags = 0x00000004 | 0x08000000 | 0x00080000 | 0x00000400
        api.call("CreateProcessW", command[0], command_line, None, None, True, flags,
                 C.cast(env_block, LPVOID), str(cwd), C.byref(si), C.byref(pi),
                 detail={"creation_flags": flags, "suspended": True, "no_window": True})
        result["original_process"].update({"pid": pi.dwProcessId, "thread_id": pi.dwThreadId,
                                            "original_process_handle": pi.hProcess,
                                            "original_thread_handle": pi.hThread})
        api.call("AssignProcessToJobObject", job, pi.hProcess)
        assigned = result["assignment_confirmed"] = True
        # Only this original suspended process HANDLE is assigned; no PID lookups or adoption.
        previous_count = api.call("ResumeThread", pi.hThread, kind="resume")
        if previous_count != 1:
            raise NativeFailure(f"unexpected initial ResumeThread suspend count {previous_count}")
        resumed = result["resume_confirmed"] = True
        deadline = started + timeout
        while True:
            active = accounting()
            original_exit(0)
            if active == 0:
                result["chain_stopped"] = True
                break
            if time.monotonic() >= deadline:
                result["timed_out"] = True
                stop_assigned()
                break
            time.sleep(min(0.02, max(0.0, deadline - time.monotonic())))
    except BaseException as exc:
        result["error"] = {"type": type(exc).__name__, "message": str(exc)}
        if pi.hProcess:
            try:
                if assigned:
                    stop_assigned()
                else:
                    # Never resumed; no user code or descendants can run. Retain original HANDLE.
                    result["unassigned_termination_consumed"] = True
                    api.call("TerminateProcess", pi.hProcess, 125, required=False)
                    if original_exit(10000):
                        result["chain_stopped"] = True
            except BaseException as cleanup_exc:
                result["stop_error"] = {"type": type(cleanup_exc).__name__, "message": str(cleanup_exc)}
        elif not resumed:
            result["chain_stopped"] = True  # no process was created
    finally:
        if attribute_initialized:
            api.call("DeleteProcThreadAttributeList", attributes, kind="void", required=False)
        api.close(pi.hThread, "original_thread")
        api.close(pi.hProcess, "original_process")
        # KILL_ON_JOB_CLOSE is a final containment backstop, not observed exit evidence.
        api.close(job, "owned_job")
        for handle, label in reversed(owned_logs):
            api.close(handle, label)
        result["cleanup_checked"] = bool(result["handle_closes"]) and all(item["ok"] for item in result["handle_closes"])
        result["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result["finished_utc"] = utc_now()
        for label in ("stdout", "stderr"):
            path = out / (label + ".bin")
            if path.is_file():
                raw = path.read_bytes()
                result[label] = {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        with (out / "command.json").open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(result, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8-sig"))
    result = supervise(config)
    print(json.dumps({"result_dir": config["result_dir"], "pid": result["original_process"]["pid"],
                      "exit_code": result["original_process"]["exit_code"], "timed_out": result["timed_out"],
                      "job_active_processes_final": result["job_active_processes_final"],
                      "chain_stopped": result["chain_stopped"], "error": result["error"]}, ensure_ascii=False))
    return 0 if result["chain_stopped"] and result["cleanup_checked"] and not result["error"] else 2


if __name__ == "__main__":
    sys.exit(main())
