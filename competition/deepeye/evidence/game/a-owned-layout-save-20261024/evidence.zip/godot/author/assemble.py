import json, shutil
from setup import HERE, dump, sha
child=HERE.parent/'cli-author'
assert sha(child/'manifest.json')=='5703d9c2258b15efe8a4087ad7c1655c2cee66083812872f81e1936b98ad5564'
manifest=json.loads((child/'manifest.json').read_text())
for entry in manifest['members']:
    p=child/entry['path'];assert sha(p)==entry['sha256'],entry['path']
receipt=json.loads((child/'native-complete-receipt.json').read_text())
terminal=json.loads(receipt['content'][0]['text'])
assert terminal['terminal'] and terminal['status']=='completed' and not terminal['stale']
dest=HERE/'candidate/simulator/native'
shutil.copyfile(child/'candidate/layout_commit_cli.py',dest/'layout_commit_cli.py')
dump(dest/'layout_commit_bundle.json',{'schema':1,'helper':{'path':'layout_commit_cli.py','sha256':sha(dest/'layout_commit_cli.py')},'leaf':{'path':'layout_commit_windows.py','sha256':'521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f'}})
bundle_sha=sha(dest/'layout_commit_bundle.json')
gd=HERE/'candidate/simulator/editor/layout_commit_bridge.gd'
text=gd.read_text(encoding='utf-8').replace('const BUNDLE_SHA256 := "PENDING_ASSEMBLY"','const BUNDLE_SHA256 := "'+bundle_sha+'"').replace('const BOOTSTRAP := "PENDING_ASSEMBLY"','const BOOTSTRAP := '+json.dumps((child/'bootstrap.py').read_text(),ensure_ascii=True))
gd.write_text(text,encoding='utf-8')
launcher=dest/'run_viewer.py'
launcher.write_text(launcher.read_text().replace("BUNDLE_SHA256 = 'PENDING_ASSEMBLY'","BUNDLE_SHA256 = '"+bundle_sha+"'"),encoding='utf-8')
dump(HERE/'cli-assembly.json',{'child_job':terminal['job_id'],'terminal':True,'all_manifest_members_verified':len(manifest['members']),'cli_sha256':sha(dest/'layout_commit_cli.py'),'bootstrap_sha256':manifest['bootstrap_sha256'],'bundle_sha256':bundle_sha,'child_manifest_sha256':sha(child/'manifest.json')})
print(json.dumps({'assembled_terminal_child':True,'verified_members':len(manifest['members']),'bundle_sha256':bundle_sha}))
