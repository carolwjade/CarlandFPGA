extends RefCounted
## Viewer-private one-job owner. Only its worker touches child pipes.
## Unknown is retained evidence; neither timeout nor exit124 permits replay.

const PROTOCOL := "deepeye-layout-commit/1"
const MAX_PAYLOAD := 1048576
const MAX_METADATA := 4096
const MAX_RESPONSE := 16384
const MAX_STDERR := 4096
const UI_WAIT_MSEC := 5000
const GODOT_SHA256 := "ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424"
# Replaced only when the reviewed source-tree bundle is assembled.
const BUNDLE_SHA256 := "9e9c766ec7ad0268810c0b22ad26144fd481ef6984a6295e68608ec30c04f9de"
const RUNTIME_SHA256 := "2572eb57f5771bdb1ea4343e48591ca61650ef5dd828193d08c05d259a17d784"
const BOOTSTRAP := "import os, threading\n_layout_watchdog = threading.Timer(6.0, lambda: os._exit(124))\n_layout_watchdog.daemon = True\n_layout_watchdog.start()\nimport hashlib, json, re, sys\ndef _unique(pairs):\n    result = {}\n    for key, value in pairs:\n        if key in result:\n            raise ValueError(\"duplicate\")\n        result[key] = value\n    return result\ntry:\n    if len(sys.argv) != 5 or sys.argv[1] != \"--bundle\" or sys.argv[3] != \"--bundle-sha256\":\n        raise ValueError(\"arguments\")\n    bundle_path, bundle_sha = sys.argv[2], sys.argv[4]\n    if not os.path.isabs(bundle_path) or not re.fullmatch(\"[0-9a-f]{64}\", bundle_sha):\n        raise ValueError(\"binding\")\n    with open(bundle_path, \"rb\") as stream:\n        raw = stream.read(8193)\n    if len(raw) > 8192 or hashlib.sha256(raw).hexdigest() != bundle_sha:\n        raise ValueError(\"bundle_pin\")\n    bundle = json.loads(raw.decode(\"utf-8\"), object_pairs_hook=_unique)\n    if type(bundle) is not dict or set(bundle) != {\"schema\", \"helper\", \"leaf\"} or type(bundle[\"schema\"]) is not int or bundle[\"schema\"] != 1:\n        raise ValueError(\"bundle_schema\")\n    for name, filename in ((\"helper\", \"layout_commit_cli.py\"), (\"leaf\", \"layout_commit_windows.py\")):\n        entry = bundle[name]\n        if type(entry) is not dict or set(entry) != {\"path\", \"sha256\"} or entry[\"path\"] != filename or type(entry[\"sha256\"]) is not str or not re.fullmatch(\"[0-9a-f]{64}\", entry[\"sha256\"]):\n            raise ValueError(\"bundle_entry\")\n    helper_path = os.path.join(os.path.dirname(bundle_path), bundle[\"helper\"][\"path\"])\n    with open(helper_path, \"rb\") as stream:\n        helper_raw = stream.read(131073)\n    if len(helper_raw) > 131072 or hashlib.sha256(helper_raw).hexdigest() != bundle[\"helper\"][\"sha256\"]:\n        raise ValueError(\"helper_pin\")\nexcept BaseException:\n    sys.stderr.write(\"pre_leaf_rejected:bootstrap_binding; leaf_called=false\\n\")\n    sys.exit(2)\nexec(compile(helper_raw, helper_path, \"exec\"), {\"__name__\": \"__main__\", \"__file__\": helper_path, \"_layout_watchdog\": _layout_watchdog})\n"

var _thread: Thread
var _mutex := Mutex.new()
var _shared: Dictionary = {}
var _job: Dictionary = {}
var _late: Array = []
static var _unknown_paths: Dictionary = {}
var launch_count := 0
static var _active_owner = null
static var _engine_verified := false
static var _engine_mutex := Mutex.new()

func _fail(code: String, reason: String) -> Dictionary:
	return {"ok": false, "code": code, "reason": reason, "errors": [reason]}

func _unknown() -> Dictionary:
	var result := _fail("outcome_unknown", "保存结果未知，文件可能已写入；请检查目标文件，勿自动重试")
	result.merge({"operation_id": _job.get("operation_id", ""), "path": _job.get("path", ""), "bytes": _job.get("bytes", 0)})
	return result

func _bundle_spec() -> Dictionary:
	return {"path": "res://native/layout_commit_bundle.json", "sha256": BUNDLE_SHA256}

func _runtime_preflight() -> Dictionary:
	if OS.get_name() != "Windows" or OS.has_feature("standalone"):
		return _fail("helper_unavailable", "此安装尚未配置安全布局保存，请使用已配置的源项目启动器")
	var runtime_path := ProjectSettings.globalize_path("res://native/layout_runtime.json")
	if not FileAccess.file_exists(runtime_path) or FileAccess.get_sha256(runtime_path) != RUNTIME_SHA256:
		return _fail("helper_unavailable", "安全布局保存运行环境不可用")
	var runtime = JSON.parse_string(FileAccess.get_file_as_string(runtime_path))
	var binding = JSON.parse_string(OS.get_environment("DEEPEYE_LAYOUT_RUNTIME"))
	if not (runtime is Dictionary) or not (binding is Dictionary):
		return _fail("helper_unavailable", "请通过已配置的源项目启动器打开应用")
	var python := String(binding.get("executable", ""))
	if not python.is_absolute_path() or not FileAccess.file_exists(python) or not runtime.get("executable_sha256", []).has(FileAccess.get_sha256(python)):
		return _fail("helper_unavailable", "安全布局保存运行环境不匹配")
	for entry in runtime.get("dependencies", []):
		var origin := String(binding.get(String(entry.get("origin", "")), ""))
		var file_path := origin.path_join(String(entry.get("path", "")))
		if not origin.is_absolute_path() or not FileAccess.file_exists(file_path) or FileAccess.get_sha256(file_path) != String(entry.get("sha256", "")):
			return _fail("helper_unavailable", "安全布局保存运行环境不匹配")
	var spec := _bundle_spec()
	var bundle_path := ProjectSettings.globalize_path(String(spec.path))
	if not bundle_path.is_absolute_path() or not FileAccess.file_exists(bundle_path) or FileAccess.get_sha256(bundle_path) != String(spec.sha256):
		return _fail("helper_unavailable", "安全布局保存组件不可用")
	var bundle = JSON.parse_string(FileAccess.get_file_as_string(bundle_path))
	if not (bundle is Dictionary) or int(bundle.get("schema", 0)) != 1 or bundle.keys().size() != 3:
		return _fail("helper_unavailable", "安全布局保存组件不匹配")
	for key in ["helper", "leaf"]:
		var entry = bundle.get(key, {})
		if not (entry is Dictionary) or entry.keys().size() != 2:
			return _fail("helper_unavailable", "安全布局保存组件不匹配")
		var name := String(entry.get("path", ""))
		if name != name.get_file() or name.is_empty():
			return _fail("helper_unavailable", "安全布局保存组件不匹配")
		var file_path := bundle_path.get_base_dir().path_join(name)
		if not FileAccess.file_exists(file_path) or FileAccess.get_sha256(file_path) != String(entry.get("sha256", "")):
			return _fail("helper_unavailable", "安全布局保存组件不匹配")
	var args := PackedStringArray(["-I", "-S", "-B", "-u", "-c", BOOTSTRAP, "--bundle", bundle_path, "--bundle-sha256", String(spec.sha256)])
	var command_units := python.length() + 3
	for arg in args:
		command_units += arg.to_utf16_buffer().size() / 2 + 3
	if command_units > 8192:
		return _fail("helper_unavailable", "布局保存组件路径过长")
	return {"ok": true, "python": python, "args": args}

func begin(path: String, text: String) -> Dictionary:
	poll()
	if _active_owner != null and _active_owner != self:
		_active_owner.poll()
		if _active_owner.has_unresolved():
			return _fail("save_pending", "上次保存尚未结束，请稍候")
	if has_unresolved():
		return _fail("save_pending", "上次保存尚未结束，请稍候")
	if _unknown_paths.has(path.to_lower()):
		return _fail("outcome_unknown", "此路径已有未知保存结果；请先检查文件并选择新的路径")
	var windows_path := path.replace("/", "\\")
	var drive := RegEx.new()
	drive.compile("^[A-Za-z]:\\\\")
	if drive.search(windows_path) == null or windows_path.to_utf16_buffer().size() / 2 >= 260 or windows_path.to_utf8_buffer().has(0):
		return _fail("invalid_path", "布局文件必须使用受支持的本地绝对路径")
	for segment in windows_path.substr(3).split("\\"):
		if segment.is_empty() or segment in [".", ".."] or segment.ends_with(".") or segment.ends_with(" ") or segment.contains(":"):
			return _fail("invalid_path", "布局文件必须使用受支持的本地绝对路径")
	var payload := text.to_utf8_buffer()
	if payload.size() > MAX_PAYLOAD:
		return _fail("too_large", "布局文件超过 1 MiB 上限")
	var preflight := _runtime_preflight()
	if not bool(preflight.get("ok", false)):
		return preflight
	var operation := Crypto.new().generate_random_bytes(16).hex_encode()
	var digest := _sha(payload)
	var metadata := JSON.stringify({"protocol": PROTOCOL, "operation_id": operation, "target": windows_path, "payload_bytes": payload.size(), "payload_sha256": digest}).to_utf8_buffer()
	if metadata.size() < 1 or metadata.size() > MAX_METADATA:
		return _fail("invalid_path", "布局文件路径过长")
	var frame := "DLC1".to_utf8_buffer()
	_append_u32(frame, metadata.size())
	frame.append_array(metadata)
	frame.append_array(payload)
	_job = {"path": path, "operation_id": operation, "bytes": payload.size(), "digest": digest, "started_msec": Time.get_ticks_msec(), "reaped": false, "unknown_returned": false, "cleanup_attempted": false}
	_shared = {"done": false, "launched": false, "pid": -1}
	_thread = Thread.new()
	_active_owner = self # Retain unresolved worker even if its store/shell is released.
	var error := _thread.start(_worker.bind({"path": path, "frame": frame, "python": preflight.python, "args": preflight.args}))
	if error != OK:
		_job["reaped"] = true
		_thread = null
		return _fail("helper_unavailable", "无法启动安全布局保存")
	return {"ok": true, "pending": true, "operation_id": operation}

func _sha(raw: PackedByteArray) -> String:
	var hashing := HashingContext.new()
	hashing.start(HashingContext.HASH_SHA256)
	hashing.update(raw)
	return hashing.finish().hex_encode()

func _append_u32(raw: PackedByteArray, value: int) -> void:
	for shift in [24, 16, 8, 0]:
		raw.append((value >> shift) & 255)

func _u32(raw: PackedByteArray, offset: int) -> int:
	return (int(raw[offset]) << 24) | (int(raw[offset + 1]) << 16) | (int(raw[offset + 2]) << 8) | int(raw[offset + 3])

func _share(values: Dictionary) -> void:
	_mutex.lock()
	_shared.merge(values, true)
	_mutex.unlock()

func _worker(request: Dictionary) -> void:
	_engine_mutex.lock()
	if not _engine_verified:
		_engine_verified = FileAccess.get_sha256(OS.get_executable_path()) == GODOT_SHA256
	var engine_ok := _engine_verified
	_engine_mutex.unlock()
	if not engine_ok:
		_share({"done": true, "result": _fail("helper_unavailable", "安全布局保存运行环境不匹配")})
		return
	# The parent directory is a separate, non-atomic convenience step. Never remove it.
	var parent := String(request.path).get_base_dir()
	if not DirAccess.dir_exists_absolute(parent):
		var made := DirAccess.make_dir_recursive_absolute(parent)
		if made != OK:
			_share({"done": true, "result": _fail("io_error", "无法创建布局目录")})
			return
	var process := OS.execute_with_pipe(String(request.python), request.args, true)
	if process.is_empty():
		_share({"done": true, "result": _fail("helper_unavailable", "无法启动安全布局保存组件")})
		return
	var pid := int(process.pid)
	_share({"launched": true, "pid": pid})
	var pipe: FileAccess = process.stdio
	var errors: FileAccess = process.stderr
	# A false return has no partial count. Never retransmit any byte.
	var valid: bool = pipe.store_buffer(request.frame)
	var output := PackedByteArray()
	var diagnostic := PackedByteArray()
	var original_exit := -1
	while true:
		var count := int(pipe.get_length())
		if count > 0:
			var chunk := pipe.get_buffer(mini(count, MAX_RESPONSE + 9))
			if output.size() + chunk.size() <= MAX_RESPONSE + 8:
				output.append_array(chunk)
			else:
				valid = false
		var err_count := int(errors.get_length())
		if err_count > 0:
			var chunk := errors.get_buffer(mini(err_count, MAX_STDERR + 1))
			if diagnostic.size() + chunk.size() <= MAX_STDERR:
				diagnostic.append_array(chunk)
			else:
				valid = false
		original_exit = OS.get_process_exit_code(pid)
		if original_exit >= 0 and pipe.get_length() == 0 and errors.get_length() == 0:
			break
		OS.delay_msec(2)
	pipe.close()
	errors.close()
	_share({"done": true, "output": output, "diagnostic_bytes": diagnostic.size(), "transport_valid": valid, "original_exit": original_exit})

func _decode_result(shared: Dictionary) -> Dictionary:
	if shared.has("result"):
		return shared.result
	if not bool(shared.get("transport_valid", false)) or int(shared.get("original_exit", -1)) != 0:
		return _unknown()
	var raw: PackedByteArray = shared.get("output", PackedByteArray())
	if raw.size() < 9 or raw.slice(0, 4).get_string_from_ascii() != "DLR1":
		return _unknown()
	var count := _u32(raw, 4)
	if count < 1 or count > MAX_RESPONSE or raw.size() != count + 8:
		return _unknown()
	var bytes := raw.slice(8)
	var text := bytes.get_string_from_utf8()
	if text.to_utf8_buffer() != bytes:
		return _unknown()
	var result = JSON.parse_string(text)
	if not (result is Dictionary) or String(result.get("protocol", "")) != PROTOCOL or String(result.get("operation_id", "")) != String(_job.operation_id) or String(result.get("payload_sha256", "")) != String(_job.digest) or result.get("payload_bytes", -1) != _job.bytes or result.get("leaf_called") != true:
		return _unknown()
	var state := String(result.get("state", ""))
	if not ["committed", "already_exists", "failed_before_publish", "outcome_unknown"].has(state) or not (result.get("ok") is bool) or not (result.get("publish_attempted") is bool) or not (result.get("publication_confirmed") is bool) or not (result.get("cleanup") is Dictionary) or not (result.get("close_errors") is Array):
		return _unknown()
	if bool(result.ok) != (state == "committed") or (state == "committed" and (not bool(result.publish_attempted) or not bool(result.publication_confirmed) or not result.close_errors.is_empty())) or (state == "already_exists" and (not bool(result.publish_attempted) or bool(result.publication_confirmed))) or (state == "failed_before_publish" and bool(result.publication_confirmed)):
		return _unknown()
	result["path"] = _job.path
	result["bytes"] = _job.bytes
	if state == "outcome_unknown":
		result["code"] = "outcome_unknown"
		result["reason"] = _unknown().reason
	elif state == "already_exists":
		result["code"] = "already_exists"
		result["reason"] = "目标文件已存在；本版本仅支持另存为新文件"
	elif state == "failed_before_publish":
		result["reason"] = "布局保存失败，目标未发布"
	if not bool(result.ok):
		result["errors"] = [result.reason]
	return result

func poll() -> Dictionary:
	if _job.is_empty():
		return {"pending": false, "unresolved": false}
	_mutex.lock()
	var shared := _shared.duplicate(true)
	_mutex.unlock()
	if bool(shared.get("launched", false)) and not bool(_job.get("launch_counted", false)):
		launch_count += 1
		_job["launch_counted"] = true
	if not bool(_job.reaped) and bool(shared.get("done", false)) and _thread != null and not _thread.is_alive():
		_thread.wait_to_finish() # Only this completed owner can be joined.
		_thread = null
		_job["worker_completed"] = true
		_job["reaped"] = true
		_job["original_exit"] = int(shared.get("original_exit", -1))
		var result := _decode_result(shared)
		_job["terminal_result"] = result
		# Exclusive original map entry; never shared/released/killed before this point.
		if bool(shared.get("launched", false)) and int(_job.original_exit) >= 0 and not bool(_job.cleanup_attempted):
			var observed := OS.get_process_exit_code(int(shared.pid))
			if observed >= 0:
				_job["cleanup_prior_exit"] = observed
				_job["cleanup_attempted"] = true # Consume original-map cleanup before the call.
				_job["cleanup_consumed"] = true
				_job["cleanup_result"] = OS.kill(int(shared.pid))
				_job["cleanup_after_exit_query"] = OS.get_process_exit_code(int(shared.pid))
				# FAILED may mean TerminateProcess rejected an exited original object.
				# Source attempts both CloseHandle calls without checking their returns.
				# Map removal is observable; kernel handle-close success is not verified.
		if bool(_job.unknown_returned):
			_late.append({"operation_id": _job.operation_id, "result": result.duplicate(true), "original_exit": _job.original_exit, "worker_completed": true, "cleanup_attempted": _job.cleanup_attempted})
		elif String(result.get("code", "")) == "outcome_unknown":
			_unknown_paths[String(_job.path).to_lower()] = true
	return {"pending": not bool(_job.reaped) and not bool(_job.unknown_returned), "unresolved": not bool(_job.reaped), "result": _job.get("visible_result", _job.get("terminal_result", {}))}

func has_unresolved() -> bool:
	return not _job.is_empty() and not bool(_job.get("reaped", false))

func _expire() -> Dictionary:
	_job["unknown_returned"] = true
	_unknown_paths[String(_job.path).to_lower()] = true
	var result := _unknown()
	_job["visible_result"] = result
	return result.duplicate(true)

func wait_sync() -> Dictionary:
	var deadline := Time.get_ticks_msec() + UI_WAIT_MSEC
	while true:
		var state := poll()
		if not bool(state.unresolved):
			return state.result
		if Time.get_ticks_msec() >= deadline:
			return _expire()
		OS.delay_msec(2)
	return _unknown()

func wait_async(tree: SceneTree) -> Dictionary:
	var deadline := Time.get_ticks_msec() + UI_WAIT_MSEC
	while true:
		var state := poll()
		if not bool(state.unresolved):
			return state.result
		if Time.get_ticks_msec() >= deadline:
			return _expire()
		await tree.process_frame
	return _unknown()

func take_late_results() -> Array:
	poll()
	var results := _late.duplicate(true)
	_late.clear()
	return results

func evidence() -> Dictionary:
	poll()
	return _job.duplicate(true)
