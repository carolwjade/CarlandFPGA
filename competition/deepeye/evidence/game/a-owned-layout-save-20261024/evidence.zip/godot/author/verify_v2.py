"""Read-only final product/protected-byte binding; no process/test launch."""
import datetime, hashlib, json, pathlib, subprocess
from setup import HERE, ROOT, W, SIM, GODOT, dump, sha
baseline=json.loads((HERE/'baseline.json').read_text())
for name,want in baseline['inputs'].items():assert sha(W/name)==want,name
for name,want in baseline['protected'].items():assert sha(W/name)==want,name
gitdir=pathlib.Path((W/'.git').read_text().strip().split(': ',1)[1])
if not gitdir.is_absolute():gitdir=W/gitdir
assert sha(gitdir/'index')==baseline['index_sha256']
cache={str(p.relative_to(SIM)).replace('\\','/'):sha(p) for p in (SIM/'.godot').rglob('*') if p.is_file()}
assert cache==baseline['cache']
head=subprocess.run(['git','-C',str(W),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
assert head==baseline['head']
scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
canonical=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert canonical==baseline['canonical_sha256']
v1=json.loads((HERE/'candidate-v1-pinmapping.json').read_text())
for e in v1['preserved_members']:assert sha(HERE/e['preserved_path'])==e['sha256']
v1_manifest=json.loads((HERE/'candidate-product-manifest.json').read_text())
v2_members=[];changed=[];bindings=[];selection=[]
stage10=HERE/'runs/review-green-10'
for e in v1_manifest['production_members']:
 p=HERE/e['path'];rel=p.relative_to(HERE/'candidate')
 assert sha(p)==sha(stage10/rel),str(rel)
 entry={'path':e['path'],'product_path':e['product_path'],'bytes':p.stat().st_size,'sha256':sha(p)}
 v2_members.append(entry)
 if sha(p)!=e['sha256']:changed.append(e['product_path'])
 selection.append({'source':entry['path'],'destination':entry['product_path'],'bytes':entry['bytes'],'sha256':entry['sha256'],'role':'product'})
 bindings.append({'candidate':e['path'],'sha256':sha(p),'same_bytes_in':'runs/review-green-10/'+str(rel).replace('\\','/'),'execution_scope':'actual targeted21 checks plus source-launcher save/reopen; docs read only','previous_full81_scope':'v1 pre-guard source, not silently rebound to v2'})
assert changed==['competition/deepeye/simulator/editor/layout_commit_bridge.gd','competition/deepeye/simulator/ui/shell.gd'],changed
for p in sorted((HERE/'candidate/simulator/tests').rglob('*')):
 if not p.is_file() or p.name in ('smoke_layout_launcher.gd','smoke_layout_launcher.tscn'):continue
 rel=p.relative_to(HERE/'candidate');assert sha(p)==sha(stage10/rel),str(rel)
 selection.append({'source':str(p.relative_to(HERE)).replace('\\','/'),'destination':'competition/deepeye/'+str(rel).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p),'role':'test'})
receipt_summaries=[]
for label,expected in [('review-red-09',1),('review-green-10',0)]:
 r=json.loads((HERE/'runs'/label/'supervisor/command.json').read_text(encoding='utf-8'))
 assert r['assignment_confirmed'] and r['resume_confirmed'] and r['original_process']['wait_completed'] and r['original_process']['exit_code']==expected and r['job_active_processes_final']==0 and r['chain_stopped'] and r['cleanup_checked'] and r['error'] is None and not r['timed_out']
 outer=json.loads((HERE/'runs'/label/'command.json').read_text())
 assert outer['layers_agree'] and outer['supervision_gate']
 receipt_summaries.append({'label':label,'original_process':r['original_process'],'godot_pid':outer['gdscript_godot_process_id'],'godot_wait_exit':outer['launcher_observed_godot_child_wait_exit'],'job_active':0,'cleanup_checked':True,'timed_out':False,'error':None,'checks':outer['checks'],'failures':outer['failures']})
runs=[json.loads(p.read_text())['ordinal'] for p in (HERE/'runs').glob('*/command.json')]
assert sorted(runs)==list(range(1,11)),runs
assert sha(SIM/'native/layout_commit_windows.py')=='521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f'
dump(HERE/'candidate-product-manifest-v2.json',{'schema':1,'version':2,'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'production_members':v2_members,'changed_product_paths_from_v1':changed,'v1_raw_snapshot':'candidate-v1-pinmapping.json','v1_manifest_sha256':sha(HERE/'candidate-product-manifest.json'),'root_selected_leaf_unchanged_sha256':sha(SIM/'native/layout_commit_windows.py'),'targeted_green_checks':21,'targeted_green_failures':0,'mixed_drive_prefix_branch':'source-reviewed hardening; not behaviorally exercised in09/10','G02':'open','G03':'not_run','R03':'not_run','all29':'not_run'})
dump(HERE/'source-bindings-v2.json',{'version':2,'bindings':bindings,'actual_green_evidence':receipt_summaries[1],'actual_red_evidence':receipt_summaries[0],'full81_not_rebound_to_v2':True,'full81_reference':'runs/caller-05/targets/bridge-evidence.json','final_v1_cancel_reference':'runs/late-cancel-green-07/targets/bridge-evidence.json','mixed_drive_prefix_not_executed':True,'mixed_normalization_review_boundary':'Root/reviewer verify validated windows_path.to_lower key in every lookup/write/job.path_key;09 alias used all-backslash so did not reproduce bypass.'})
dump(HERE/'selection-mapping.json',{'schema':1,'candidate_base':'author/','files':selection,'root_already_selected_leaf':{'destination':'competition/deepeye/simulator/native/layout_commit_windows.py','sha256':sha(SIM/'native/layout_commit_windows.py')},'unused_old_smoke_not_selected':True})
dump(HERE/'verification-final.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'product_head_unchanged':head,'product_simulator_inputs_unchanged':len(baseline['inputs']),'C4_unchanged':4,'index_unchanged':True,'original_cache_unchanged':len(cache),'godot_sha256':sha(GODOT),'canonical_sha256':canonical,'plan_sha256':sha(HERE.parent/'plan.md'),'godot_invocations':10,'root_revision_budget':'revision-budget.json','v1_snapshot_members_verified':len(v1['preserved_members']),'production_v2_members':len(v2_members),'canonical_selection_members':len(selection),'new_supervised_records':receipt_summaries,'original08_base_python_exit':'unknown; not inferred from CIM absence or new Jobactive0','all_required_author_work_frozen':True,'G02':'open','G03':'not_run','R03':'not_run','all29':'not_run'})
print(json.dumps({'protected_unchanged':True,'v1_members':len(v1['preserved_members']),'v2_members':len(v2_members),'selection_members':len(selection),'changed_product_paths':changed,'prod_v2_manifest_sha256':sha(HERE/'candidate-product-manifest-v2.json'),'supervised_green_checks':21,'mixed_branch_not_executed':True}))
