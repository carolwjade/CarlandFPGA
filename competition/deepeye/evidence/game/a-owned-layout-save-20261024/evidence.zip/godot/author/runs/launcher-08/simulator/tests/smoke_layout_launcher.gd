extends Node
const Store = preload("res://editor/layout_store.gd")
const Document = preload("res://editor/scene_document.gd")

func _ready() -> void:
	var frames := 0
	for unused in range(3):
		await get_tree().process_frame
		frames += 1
	var store = Store.new()
	var document = Document.new()
	document.add_obstacle("water", Vector3(1, 2, 3))
	var exported: Dictionary = document.export_layout_text()
	var target := OS.get_user_data_dir().path_join("launcher-smoke/新布局😀.json")
	var saved: Dictionary = await store.save_new_async(target, String(exported.get("text", "")))
	var read: Dictionary = store.read_text(target)
	var reopened = Document.new()
	var decoded: Dictionary = reopened.apply_layout_text(String(read.get("text", "")))
	var evidence: Dictionary = store.save_evidence()
	var ok := bool(saved.get("ok", false)) and bool(read.get("ok", false)) and bool(decoded.get("ok", false)) and decoded.get("layout_hash") == exported.get("layout_hash") and int(evidence.get("original_exit", -1)) == 0 and bool(evidence.get("worker_completed", false)) and bool(evidence.get("cleanup_consumed", false)) and not store.has_unresolved_save()
	var record := {"ok": ok, "godot_process_id": OS.get_process_id(), "frames": frames, "runtime_binding_present": not OS.get_environment("DEEPEYE_LAYOUT_RUNTIME").is_empty(), "provider_credential_present": OS.has_environment("OPENAI_API_KEY") or OS.has_environment("FPGA_HMAC_KEY"), "user_data_dir": OS.get_user_data_dir(), "target": target, "saved": saved, "layout_hash_reopened": decoded.get("layout_hash", ""), "evidence": evidence}
	var output := FileAccess.open(OS.get_user_data_dir().path_join("launcher-evidence.json"), FileAccess.WRITE)
	output.store_string(JSON.stringify(record, "\t"))
	output.close()
	print("LAUNCHER_SMOKE_OK=" + str(ok))
	get_tree().quit(0 if ok else 1)
