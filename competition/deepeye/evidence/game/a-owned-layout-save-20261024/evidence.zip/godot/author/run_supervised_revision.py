"""Only Root-authorized fresh09 RED or10 GREEN via immutable Job supervisor."""
import datetime, json, pathlib, re, shutil, subprocess, sys, time
from setup import HERE, GODOT, dump, sha, stage
ordinal=int(sys.argv[1]);assert ordinal in (9,10)
label='review-red-09' if ordinal==9 else 'review-green-10'
expected=1 if ordinal==9 else 0
prior=list((HERE/'runs').glob('*/command.json'))
assert len(prior)==ordinal-1,(len(prior),ordinal)
supervisor=HERE.parent/'job-supervisor/launch_owned.py'
assert sha(supervisor)=='b1945ae48cf6f16c11ac80992ae7feec58cd3c927cffdc0ebe1797cd8df1c58e'
if ordinal==9:
    manifest=json.loads((HERE/'candidate-product-manifest.json').read_text())
    mapping=[]
    for entry in manifest['production_members']:
        source=HERE/entry['path'];assert sha(source)==entry['sha256']
        dest=HERE/'candidate-v1'/source.relative_to(HERE/'candidate')
        assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
        mapping.append({'v1_manifest_path':entry['path'],'preserved_path':str(dest.relative_to(HERE)).replace('\\','/'),'sha256':sha(dest)})
    dump(HERE/'candidate-v1-pinmapping.json',{'original_manifest_sha256':sha(HERE/'candidate-product-manifest.json'),'preserved_members':mapping})
base,game,env=stage(label)
project=game/'project.godot'
project.write_text(project.read_text(encoding='utf-8').replace('run/main_scene="res://viewer/main.tscn"','run/main_scene="res://tests/review_save_regressions.tscn"'),encoding='utf-8')
launcher=game/'native/run_viewer.py'
command=[sys.executable,'-I','-B',str(launcher),'--godot',str(GODOT),'--run-dir',str(base/'viewer-env'),'--headless']
# Known fake sentinels only: prove the launcher filters credential-shaped names.
env['OPENAI_API_KEY']='test-only-sentinel-not-a-credential'
env['FPGA_HMAC_KEY']='test-only-sentinel-not-a-credential'
config={'command':command,'cwd':str(game),'env':env,'timeout_seconds':45,'result_dir':str(base/'supervisor')}
dump(base/'supervisor-config.json',config)
invocation=[sys.executable,'-I','-B',str(supervisor),'--config',str(base/'supervisor-config.json')]
record={'ordinal':ordinal,'kind':'root-authorized-targeted-review-'+('RED' if ordinal==9 else 'GREEN'),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'supervisor_invocation':invocation,'supervisor_sha256':sha(supervisor),'expected_original_exit':expected,'no_outer_redirector_timeout_or_kill':True,'launcher_sha256':sha(launcher),'stage':str(game)}
dump(base/'command.json',record)
r=subprocess.run(invocation,capture_output=True)
(base/'supervisor-stdout.log').write_bytes(r.stdout)
(base/'supervisor-stderr.log').write_bytes(r.stderr)
receipt=json.loads((base/'supervisor/command.json').read_text(encoding='utf-8'))
gate=bool(receipt['assignment_confirmed'] and receipt['resume_confirmed'] and receipt['original_process']['wait_completed'] and receipt['original_process']['exit_code']==expected and receipt['job_active_processes_final']==0 and receipt['chain_stopped'] and receipt['cleanup_checked'] and receipt['error'] is None and not receipt['timed_out'])
stdout=(base/'supervisor/stdout.bin').read_text(encoding='utf-8',errors='replace')
pid=re.search(r'DEEPEYE_VIEWER_CHILD_PID=(\d+)',stdout)
childexit=re.search(r'DEEPEYE_VIEWER_CHILD_EXIT=(-?\d+)',stdout)
evidence_paths=list((base/'viewer-env').rglob('review-evidence.json'))
record.update(supervisor_returncode=r.returncode,exact_original_process=receipt['original_process'],exit_code=receipt['original_process']['exit_code'],supervision_gate=gate,job_active_processes_final=receipt['job_active_processes_final'],chain_stopped=receipt['chain_stopped'],cleanup_checked=receipt['cleanup_checked'],error=receipt['error'],timed_out=receipt['timed_out'],evidence_paths=[str(p.relative_to(base)).replace('\\','/') for p in evidence_paths])
if pid:record['launcher_observed_godot_child_pid']=int(pid[1])
if childexit:record['launcher_observed_godot_child_wait_exit']=int(childexit[1])
if len(evidence_paths)==1:
    evidence=json.loads(evidence_paths[0].read_text(encoding='utf-8'))
    record.update(gdscript_godot_process_id=evidence['godot_process_id'],checks=evidence['checks'],failures=evidence['failures'],actual_launcher_smoke_executed=evidence['actual_launcher_smoke']['executed'])
    record['layers_agree']=record.get('launcher_observed_godot_child_pid')==evidence['godot_process_id'] and record.get('launcher_observed_godot_child_wait_exit')==expected
dump(base/'command.json',record)
print(json.dumps(record,ensure_ascii=True));print(stdout)
print((base/'supervisor/stderr.bin').read_text(encoding='utf-8',errors='replace'))
assert gate and r.returncode==0 and record.get('layers_agree'),record
assert (bool(record['failures']) if ordinal==9 else not record['failures'] and record['actual_launcher_smoke_executed']),record
