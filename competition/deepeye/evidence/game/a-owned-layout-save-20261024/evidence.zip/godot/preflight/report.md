# Source-only lifecycle preflight

Work `A-G02-GODOT-LIFETIME-PREFLIGHT-20261024-v1`; agent `/root/godot_save_lifecycle_preflight`; job `child-1bf85884661d443580ce6bf8a253b986`. This report supplies source evidence to Gen3 root. It does not accept an implementation or claim runtime cleanup.

The exact pinned source supports root's conditional one-shot cleanup of an already-exited, exclusively owned mapped child. The newly captured header closes the previously missing destructor question. No candidate/CLI source was inspected or executed; later complete code review and new caller evidence remain necessary.

## Source evidence

- [Pinned header, raw lines 160–167](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/platform/windows/os_windows.h#L160): ProcessInfo contains STARTUPINFOEX, PROCESS_INFORMATION, bool and int. It has no custom destructor or handle-owning RAII member. Destroying this map value therefore does not close the copied raw Win32 handles. The saved raw header is 11,202 bytes, SHA256 54a90fb73025fe45c680f13f1f26f84002cd594b19b67c3736c73955b5ad70bd.
- [Pinned Windows implementation](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/platform/windows/os_windows.cpp#L1383): successful pipe launch stores the original ProcessInfo at 1393–1396. get_process_exit_code 1655–1679 queries that retained handle, returns -1 for missing/query-failed/STILL_ACTIVE, and caches an observed exit without erasing the entry. is_process_running(false) alone is weaker.
- [kill 1602–1622](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/platform/windows/os_windows.cpp#L1602): while holding its mutex, the mapped branch copies PROCESS_INFORMATION by value, erases the entry, calls TerminateProcess on that original handle, then attempts both CloseHandle calls. The absent-map branch instead opens by numeric PID. Return status reflects TerminateProcess only; CloseHandle results are ignored.
- [Microsoft PROCESS_INFORMATION](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/ns-processthreadsapi-process_information) confirms the raw handle members, explicit closing duty, and that PID reuse follows closure of the process handles and destruction of the process object. [Raymond Chen, 2011-01-07](https://devblogs.microsoft.com/oldnewthing/20110107-00/?p=11803%2F) explains the same process-object lifetime. The normal unescaped article URL returned 403; official search supplied its full article text.
- [Microsoft TerminateProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-terminateprocess) explicitly documents ERROR_ACCESS_DENIED when an open handle refers to a terminated process. Thus FAILED on this already-exited cleanup is expected, not evidence of live termination, failed handle release, or permission to retry.

## Conditions that carry the argument

These are obligations for the later implementation/reviewer, not verified candidate behavior:

1. Bind the real running engine image to the exact root-approved hash and commit. Environment declarations alone are insufficient. A cached actual check may be scoped to that engine instance.
2. Retain one job's original PID/operation and exclusive, unreleased map ownership from successful launch. Do not expose its PID to another cleanup consumer. Exit observation and kill are separate APIs; their mutexes do not make the pair atomic.
3. Before cleanup, record a nonnegative exact original-child exit, finish bounded stdout/stderr draining and full frame/trailing-data validation, and observe the sole worker no longer alive. Child exit alone does not mean buffered pipe data has been consumed. Join only that completed worker.
4. Set cleanup-consumed before the one call. Preserve prior exit and attempted cleanup status separately. Once called, never reuse that PID for get-exit/kill/retry: the map was erased even if FAILED. Source establishes unconditional close attempts, not runtime proof that both closes succeeded.
5. If engine identity, ownership, prior consumption, exact exit or worker completion is uncertain, keep the unresolved job. No bare-PID kill, live join, path cleanup, replay or second unresolved helper is authorized.

## Remaining boundaries and test evidence

The main-loop deadline bounds the awaited UI operation under normal engine scheduling. The watchdog must start before stdin and leaf loading and only self-exit 124. Interpreter/bootstrap startup, unscheduled watchdog threads and kernel stalls remain outside that guarantee. A stuck worker can therefore retain the one slot indefinitely. Exit 124 preserves outcome_unknown whether publication occurred or not; application exit is not child-exit proof.

Root clarified the runtime boundary and incorporated it in plan.md: trust the existing A Python installation, record a small actual interpreter/DLL/required-extension identity manifest, use -I -S fixed stdlib imports and helper/leaf raw pins. This is not whole-runtime anti-tamper closure; no runtime reconstruction or complete Lib/wheel inventory is required here. Same-verified-byte loading and current loader provenance still need honest implementation descriptions.

The frozen bridge-design protocol's blanket no-kill cleanup sentence is superseded only by the narrow root condition above. Its bounded framing, one commit, no retransmission after an ambiguous write, unknown retention, no automatic replay and viewer-private geometry boundary continue to apply. This preflight does not expand helper authority to AI/control/service inputs.

New caller evidence should record operation IDs, exact engine/helper/leaf pins, actual exit codes, frame progress, full bounded drain/trailing rejection, worker-finished observation, cleanup-consumed/attempted status and refusal of a second unresolved launch. Before/after-publication124 fixtures must separately show preserved absent/published targets; target state cannot be inferred from 124. Late trusted terminal notices must not apply old geometry or overwrite the earlier unknown outcome. Existing primitive 19 evidence may be reused without rerunning its native tests.

## Scope and record integrity

Canonical compact sorted-key UTF8 requirements SHA256 was independently recomputed as `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`, with 15 requirements. Both immutable scope files were read. H01–H15 and both full H12 routes remain unchanged. Existing node config identifies A/fpga-main; transfer identifies active director `01a16988-bdcb-70e1-ae10-1304b5cf7875`, generation 3.

source-pins.json binds the read project guidance, current plan, frozen design records and source files. Only this owned preflight directory was written. No candidate import, ctypes/native/engine/test execution, process probe/termination, board/service/provider probe, peer/group action, product/configuration change or path deletion occurred. Official source/document retrieval was the only network activity. The initial private lease filename lookup failed; the parent's corrected filename was read privately, then canonical validation returned execution_allowed=true before project inspection.

This source preflight cannot establish actual cleanup, a caller pass, real mouse/DPI behavior, full G02/H09/H12 acceptance, or G03/R03/all29. Root decides subsequent implementation acceptance.

