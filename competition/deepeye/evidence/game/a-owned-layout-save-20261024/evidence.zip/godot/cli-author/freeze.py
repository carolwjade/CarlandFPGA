"""Freeze this owned directory, excluding private lease and completion receipt."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parents[3]
digest = lambda raw: hashlib.sha256(raw).hexdigest()
candidate_sha = "8b0512457b2ef5c176b957a46b3172fb15e4cb053b42514d8affd537aa3eb344"
bootstrap_sha = "0b2ef958006c47b1b74ff303bf36996769bad3a8616d8a15df6d8e514f606d14"
assert digest((here / "candidate/layout_commit_cli.py").read_bytes()) == candidate_sha
assert digest((here / "bootstrap.py").read_bytes()) == bootstrap_sha
assert digest((here / "runs/green1/test_real_unicode_save/layout_commit_cli.py").read_bytes()) == candidate_sha
assert digest((here / "runs/green2/test_watchdog_after_real_publication_is_unknown/layout_commit_cli.py").read_bytes()) == candidate_sha
reports = [json.loads((here / "runs" / name / "results.json").read_bytes()) for name in ("green1", "green2", "green3")]
assert sum(item["tests_run"] for item in reports) == 19
assert sum(item["failures"] + item["errors"] for item in reports) == 0
scope = json.loads((root / "docs/competition/deepeye-2026/immutable_scope.json").read_bytes())
contract_sha = digest(json.dumps(scope["requirements"], sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode())
assert contract_sha == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
leaf = root / ".local/deepeye-implementation-a/competition/deepeye/simulator/native/layout_commit_windows.py"
leaf_sha = digest(leaf.read_bytes())
assert leaf_sha == "521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f"
members = []
for path in sorted(here.rglob("*")):
    if (not path.is_file() or path.name in {"lease.private.json", "manifest.json"}
            or path.name.startswith("native-complete") or "__pycache__" in path.parts):
        continue
    raw = path.read_bytes()
    members.append({"path": path.relative_to(here).as_posix(), "bytes": len(raw), "sha256": digest(raw)})
manifest = {"schema": 1, "work_id": "A-G02-LAYOUT-CLI-20261024-v1", "job_id": "child-80754f81e86a4ead9619be52a4529a60",
            "agent_id": "/root/godot_owned_save_author/cli_helper", "frozen_utc": datetime.now(timezone.utc).isoformat(),
            "contract_sha256": contract_sha, "director_generation": 3, "director_thread": "01a16988-bdcb-70e1-ae10-1304b5cf7875",
            "candidate_sha256": candidate_sha, "bootstrap_sha256": bootstrap_sha, "selected_leaf_sha256": leaf_sha,
            "new_cli_tests": 19, "process_observations": sum(len(item["results"]) for item in reports),
            "acceptance": {"G03": "not_run", "R03": "not_run", "all29": "not_run"}, "members": members}
raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()
(here / "manifest.json").write_bytes(raw)
print(json.dumps({"manifest_path": str(here / "manifest.json"), "manifest_sha256": digest(raw), "members": len(members),
                  "candidate_sha256": candidate_sha, "bootstrap_sha256": bootstrap_sha,
                  "new_cli_tests": 19, "process_observations": manifest["process_observations"]}, ensure_ascii=False))
