"""Test-only adapter: stall the leaf-load boundary without production flags."""
import hashlib
import json
from pathlib import Path
import sys
import time

bundle_path = Path(sys.argv[2])
bundle = json.loads(bundle_path.read_bytes())
helper_path = bundle_path.parent / bundle["helper"]["path"]
raw = helper_path.read_bytes()
assert hashlib.sha256(raw).hexdigest() == bundle["helper"]["sha256"]
namespace = {"__name__": "_test_layout_commit_cli", "__file__": str(helper_path)}
exec(compile(raw, str(helper_path), "exec"), namespace)


def blocked_load(path):
    (bundle_path.parent / "leaf-loading.marker").write_bytes(b"entered")
    time.sleep(20)
    raise AssertionError("watchdog should already have self-exited")


namespace["_load_leaf"] = blocked_load
sys.exit(namespace["main"]())
