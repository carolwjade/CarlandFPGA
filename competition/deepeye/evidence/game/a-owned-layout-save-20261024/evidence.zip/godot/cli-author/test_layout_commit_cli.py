"""Fresh CLI boundary tests; no old leaf suite or Godot execution.

Breaks caught: losing atomic no-replace at the CLI, permitting malformed input
to reach publication, executing unchecked code, or waiting forever on input.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
LEAF = ROOT / ".local/deepeye-implementation-a/competition/deepeye/simulator/native/layout_commit_windows.py"
LEAF_SHA = "521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f"
PROTOCOL = "deepeye-layout-commit/1"
RUN = None
RESULTS = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def frame(meta, payload=b"", raw=None):
    data = raw if raw is not None else json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return b"DLC1" + struct.pack(">I", len(data)) + data + payload


class CliTests(unittest.TestCase):
    def setUp(self):
        self.directory = RUN / self._testMethodName
        self.directory.mkdir(parents=True)
        self.target = self.directory / "layout.json"
        self.bundle = self.directory / "layout_commit_bundle.json"
        self.helper = self.directory / "layout_commit_cli.py"
        source = HERE / "candidate/layout_commit_cli.py"
        if source.exists():
            shutil.copyfile(source, self.helper)
        leaf_bytes = LEAF.read_bytes()
        self.assertEqual(sha(leaf_bytes), LEAF_SHA)
        (self.directory / "layout_commit_windows.py").write_bytes(leaf_bytes)
        self.pin = {"schema": 1, "helper": {"path": "layout_commit_cli.py", "sha256": sha(self.helper.read_bytes()) if self.helper.exists() else "0" * 64},
                    "leaf": {"path": "layout_commit_windows.py", "sha256": LEAF_SHA}}
        self.update_bundle()

    def update_bundle(self):
        self.bundle.write_bytes(json.dumps(self.pin, separators=(",", ":")).encode())

    def metadata(self, payload=b"", **updates):
        result = {"protocol": PROTOCOL, "operation_id": "1234567890abcdef1234567890abcdef", "target": str(self.target),
                  "payload_bytes": len(payload), "payload_sha256": sha(payload)}
        result.update(updates)
        return result

    def command(self, bootstrap=False):
        if bootstrap:
            source = (HERE / "bootstrap.py").read_text(encoding="utf-8")
            return [sys.executable, "-I", "-S", "-B", "-u", "-c", source,
                    "--bundle", str(self.bundle), "--bundle-sha256", sha(self.bundle.read_bytes())]
        return [sys.executable, "-I", "-S", "-B", "-u", str(self.helper),
                "--bundle", str(self.bundle), "--bundle-sha256", sha(self.bundle.read_bytes())]

    def invoke(self, request, bootstrap=False, command=None):
        started = time.monotonic()
        result = subprocess.run(command or self.command(bootstrap), input=request, capture_output=True, timeout=10,
                                env={k: v for k, v in os.environ.items() if k.upper() in {"SYSTEMROOT", "WINDIR", "TEMP", "TMP"}})
        RESULTS.append({"test": self._testMethodName, "exit": result.returncode,
                        "duration_s": time.monotonic() - started, "stdout_bytes": len(result.stdout),
                        "stderr": result.stderr.decode("utf-8", "replace")})
        (self.directory / "stdout.bin").write_bytes(result.stdout)
        (self.directory / "stderr.bin").write_bytes(result.stderr)
        return result

    def response(self, result):
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, b"")
        self.assertEqual(result.stdout[:4], b"DLR1")
        count = struct.unpack(">I", result.stdout[4:8])[0]
        self.assertGreater(count, 0)
        self.assertLessEqual(count, 16384)
        self.assertEqual(len(result.stdout), 8 + count)
        return json.loads(result.stdout[8:].decode("utf-8"))

    def rejected(self, request):
        result = self.invoke(request)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, b"")
        self.assertIn(b"leaf_called=false", result.stderr)
        self.assertLessEqual(len(result.stderr), 4096)
        self.assertFalse(self.target.exists())

    def test_real_unicode_save(self):
        self.target = self.directory / "水层😀.json"
        payload = '{"title":"水层😀","opaque":"no execution"}'.encode()
        meta = self.metadata(payload)
        value = self.response(self.invoke(frame(meta, payload)))
        self.assertEqual((value["state"], value["ok"], value["code"]), ("committed", True, "committed"))
        self.assertEqual({key: value[key] for key in ("protocol", "operation_id", "payload_bytes", "payload_sha256")},
                         {key: meta[key] for key in ("protocol", "operation_id", "payload_bytes", "payload_sha256")})
        self.assertIs(value["leaf_called"], True)
        self.assertTrue(value["publication_confirmed"])
        self.assertEqual(self.target.read_bytes(), payload)

    def test_empty_and_one_mib_exact(self):
        for count in (0, 1048576):
            self.target = self.directory / (str(count) + ".json")
            payload = b" " * count
            value = self.response(self.invoke(frame(self.metadata(payload), payload)))
            self.assertEqual(value["state"], "committed")
            self.assertEqual(self.target.read_bytes(), payload)

    def test_existing_file_sentinel(self):
        self.target.write_bytes(b"SENTINEL original bytes")
        value = self.response(self.invoke(frame(self.metadata(b"new"), b"new")))
        self.assertEqual((value["state"], value["ok"]), ("already_exists", False))
        self.assertEqual(self.target.read_bytes(), b"SENTINEL original bytes")
        self.assertTrue(value["cleanup"]["attempted"])

    def test_existing_directory_sentinel(self):
        self.target.mkdir()
        sentinel = self.target / "sentinel.bin"
        sentinel.write_bytes(b"preserve directory")
        value = self.response(self.invoke(frame(self.metadata(b"new"), b"new")))
        self.assertNotEqual(value["state"], "committed")
        self.assertEqual(sentinel.read_bytes(), b"preserve directory")

    def test_digest_mismatch_rejected(self):
        self.rejected(frame(self.metadata(b"payload", payload_sha256="0" * 64), b"payload"))

    def test_invalid_utf8_payload_rejected(self):
        self.rejected(frame(self.metadata(b"\xff"), b"\xff"))

    def test_oversize_declared_rejected(self):
        self.rejected(frame(self.metadata(payload_bytes=1048577)))

    def test_exact_metadata_fields_duplicate_and_number_types(self):
        variants = [{**self.metadata(), "extra": True}, {key: value for key, value in self.metadata().items() if key != "target"},
                    self.metadata(payload_bytes=True), self.metadata(payload_bytes=0.0), self.metadata(operation_id="../invalid"),
                    self.metadata(payload_sha256="A" * 64), self.metadata(protocol="other")]
        for meta in variants:
            self.rejected(frame(meta))
        raw = json.dumps(self.metadata(), separators=(",", ":")).encode()
        self.rejected(frame(None, raw=raw[:-1] + b',"payload_bytes":0}'))
        self.rejected(frame(None, raw=raw.replace(b'"payload_bytes":0', b'"payload_bytes":NaN')))

    def test_path_bounds_and_normalization_rejected(self):
        for target in ("relative.json", "C:/bad.json", "C:\\a\\..\\b.json", "C:\\NUL.txt", "C:\\bad.\\a.json", "C:\\" + "a" * 260):
            self.rejected(frame(self.metadata(target=target)))

    def test_bad_or_incomplete_framing_rejected(self):
        for request in (b"NOPE" + struct.pack(">I", 1) + b"0", b"DLC1" + struct.pack(">I", 0),
                        b"DLC1" + struct.pack(">I", 4097), b"DLC1\x00", frame(self.metadata(b"missing")),
                        frame(None, raw=b"\xff"), frame(None, raw=b"[]")):
            self.rejected(request)

    def test_helper_leaf_and_bundle_pins_rejected(self):
        for change in ("helper", "leaf"):
            path = self.directory / self.pin[change]["path"]
            original = path.read_bytes()
            path.write_bytes(original + b"\n# changed\n")
            result = self.invoke(frame(self.metadata()))
            self.assertEqual(result.returncode, 2)
            self.assertEqual(result.stdout, b"")
            self.assertIn(b"leaf_called=false", result.stderr)
            self.assertFalse(self.target.exists())
            path.write_bytes(original)
        self.pin["leaf"]["path"] = "../layout_commit_windows.py"
        self.update_bundle()
        self.rejected(frame(self.metadata()))

    def test_checked_bootstrap_real_commit(self):
        value = self.response(self.invoke(frame(self.metadata(b"bootstrap"), b"bootstrap"), bootstrap=True))
        self.assertEqual(value["state"], "committed")
        self.assertEqual(self.target.read_bytes(), b"bootstrap")

    def test_bootstrap_rejects_changed_code_without_execution(self):
        marker = self.directory / "untrusted-executed"
        self.helper.write_text("open(" + repr(str(marker)) + ", 'wb').write(b'wrong')", encoding="utf-8")
        result = self.invoke(frame(self.metadata()), bootstrap=True)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, b"")
        self.assertIn(b"leaf_called=false", result.stderr)
        self.assertFalse(marker.exists())
        self.assertFalse(self.target.exists())

    def test_leaf_raw_pin_checked_before_execution(self):
        marker = self.directory / "untrusted-executed"
        leaf = self.directory / "layout_commit_windows.py"
        leaf.write_bytes(leaf.read_bytes() + ("\nopen(" + repr(str(marker)) + ", 'wb').write(b'wrong')\n").encode())
        self.rejected(frame(self.metadata()))
        self.assertFalse(marker.exists())

    def test_bundle_hash_version_and_duplicate_rejected(self):
        original = self.bundle.read_bytes()
        command = self.command(bootstrap=True)
        self.bundle.write_bytes(original + b" ")
        result = self.invoke(frame(self.metadata()), command=command)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, b"")
        self.assertIn(b"leaf_called=false", result.stderr)
        self.assertFalse(self.target.exists())
        for value in (True, 1.0, 2):
            self.pin["schema"] = value
            self.update_bundle()
            self.rejected(frame(self.metadata()))
        self.bundle.write_bytes(original[:-1] + b',"schema":1}')
        self.rejected(frame(self.metadata()))

    def test_watchdog_before_stalled_leaf_loading(self):
        command = self.command()
        command[5] = str(HERE / "fixtures/watchdog_leaf_loading.py")
        result = self.invoke(frame(self.metadata()), command=command)
        self.assertEqual(result.returncode, 124)
        self.assertEqual(result.stdout, b"")
        self.assertEqual(result.stderr, b"")
        self.assertEqual((self.directory / "leaf-loading.marker").read_bytes(), b"entered")
        self.assertFalse(self.target.exists())

    def test_watchdog_after_real_publication_is_unknown(self):
        command = self.command()
        command[5] = str(HERE / "fixtures/watchdog_after_publish.py")
        result = self.invoke(frame(self.metadata(b"published once"), b"published once"), command=command)
        self.assertEqual(result.returncode, 124)
        self.assertEqual(result.stdout, b"")
        self.assertEqual(result.stderr, b"")
        self.assertEqual(self.target.read_bytes(), b"published once")
        record = json.loads((self.directory / "after-publication.json").read_bytes())
        self.assertTrue(record["publication_confirmed"])
        self.assertEqual(record["state"], "committed")

    def test_watchdog_before_blocked_stdin(self):
        started = time.monotonic()
        process = subprocess.Popen(self.command(), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            self.assertEqual(process.wait(timeout=9), 124)
            self.assertLess(time.monotonic() - started, 9)
            self.assertEqual(process.stdout.read(), b"")
            self.assertEqual(process.stderr.read(), b"")
            self.assertFalse(self.target.exists())
            RESULTS.append({"test": self._testMethodName, "exit": process.returncode, "duration_s": time.monotonic() - started})
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            process.stdin.close()
            process.stdout.close()
            process.stderr.close()

    def test_one_request_without_eof_or_second_command(self):
        second = self.directory / "second.json"
        first_frame = frame(self.metadata(b"first"), b"first")
        second_frame = frame(self.metadata(b"second", target=str(second), operation_id="a" * 32), b"second")
        started = time.monotonic()
        process = subprocess.Popen(self.command(), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            process.stdin.write(first_frame + second_frame)
            process.stdin.flush()
            self.assertEqual(process.wait(timeout=9), 0)
            result = subprocess.CompletedProcess(self.command(), process.returncode, process.stdout.read(), process.stderr.read())
            value = self.response(result)
            self.assertEqual(value["state"], "committed")
            self.assertEqual(self.target.read_bytes(), b"first")
            self.assertFalse(second.exists())
            (self.directory / "stdout.bin").write_bytes(result.stdout)
            (self.directory / "stderr.bin").write_bytes(result.stderr)
            RESULTS.append({"test": self._testMethodName, "exit": process.returncode,
                            "duration_s": time.monotonic() - started, "stdin_remained_open_through_exit": True,
                            "second_target_absent": True})
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            process.stdin.close()
            process.stdout.close()
            process.stderr.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--only")
    args = parser.parse_args()
    RUN = Path(args.run_dir).resolve()
    RUN.mkdir(parents=True, exist_ok=False)
    suite = unittest.defaultTestLoader.loadTestsFromNames(["CliTests." + name for name in args.only.split(",")], sys.modules[__name__]) if args.only else unittest.defaultTestLoader.loadTestsFromTestCase(CliTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    (RUN / "results.json").write_text(json.dumps({"tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "results": RESULTS}, indent=2), encoding="utf-8")
    sys.exit(0 if result.wasSuccessful() else 1)
