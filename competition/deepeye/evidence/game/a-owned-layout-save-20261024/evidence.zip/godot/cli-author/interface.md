# Viewer-private helper interface

Task DEEPEYE-IMPLEMENTATION-20261014/v1, work A-G02-LAYOUT-CLI-20261024-v1.
Director01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3. Preserve the complete
DEEPEYE-HUMAN-LOCK-20261014/revision1 contract, H01-H15/fullH12, canonical
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.

Fixed argv is `[python_absolute, "-I", "-S", "-B", "-u", "-c", bootstrap_text,
"--bundle", bundle_absolute, "--bundle-sha256", bundle_raw_sha256]`.
`bootstrap_text` is the exact UTF-8 text of bootstrap.py here. It is intended to
be embedded literally by the bridge. Quote each Windows argv element using the
normal Windows argument quoting algorithm; the complete fixed command is capped
at8192 UTF-16 units by the caller. Target/layout bytes never enter argv.

The bundle is raw-hash pinned and at most8192 bytes, strict UTF-8 JSON, with this
exact duplicate-free shape:

```json
{"schema":1,"helper":{"path":"layout_commit_cli.py","sha256":"<helper raw SHA256>"},"leaf":{"path":"layout_commit_windows.py","sha256":"521cfcea011d462b4b69641f33fbb6f3f7baca16eac7bb4e0b9ee8f1d932ed1f"}}
```

Both path entries are those exact sibling basenames. The root/parent owns the
production bundle. The helper rechecks bundle/helper bindings, requires the
fixed leaf digest, hashes leaf raw bytes, and executes those checked bytes in an
explicit namespace. It never adds the script directory to sys.path. A trusted
existing stdlib/runtime installation remains a prerequisite; runtime trust and
environment allowlisting are caller responsibilities.

DLC1/DLR1 use the frozen sibling bridge-design/protocol.md contract. The request
metadata exact keys are protocol, operation_id, target, payload_bytes and
payload_sha256. Protocol is `deepeye-layout-commit/1`; operation_id is32 lowercase
hex characters generated fresh by the caller; digest is64 lowercase hex.
payload_bytes is a JSON integer excluding bool/float, from0 through1048576.
Metadata is1..4096 bytes. All strings must decode as strict UTF-8; payload has no
BOM. Target must be a supported normalized absolute Windows drive path bounded
by the selected leaf's260-unit target and temporary-name limits. The leaf alone
checks actual local NTFS/ancestry/HANDLE properties and requires existing parents.
The CLI creates no parent directories.

One helper consumes one exact-length frame and makes at most one commit_new
call. It does not await EOF and never processes another queued frame. It does
not inspect/execute layout JSON or register a provider/control/service.

Normal completion is exit0 and one DLR1 frame, containing1..16384 strict UTF-8
JSON bytes. All selected leaf fields remain intact, including cleanup and close
ambiguity; protocol, operation_id, payload_bytes, payload_sha256 and
leaf_called:true are added. There is no progress or incidental stdout.
Pre-leaf failure is exit2, empty stdout, and one fixed stderr line
`pre_leaf_rejected:<code>; leaf_called=false`. An unexpected post-leaf error is
exit3 with `outcome_unknown:<code>; leaf_called=true`. Diagnostic lines contain
no target/layout/exception text/traceback and are below4096 bytes.

The6.0-second process-local watchdog starts before bundle/leaf loading and stdin
reads. The fixed bootstrap starts it before loading helper bytes; the helper
reuses that timer, or starts its own when launched directly. Expiry only calls
os._exit(124), with no stdout, cleanup, retries or other-PID action. It is an
ordinary-scheduler observation, with interpreter startup/scheduler/kernel stalls
outside the guarantee. Exit124 and all abnormal/malformed postlaunch outcomes
remain unknown to the bridge. Parent directories/targets/orphans are never
deleted by this helper. No test fault switches exist in production.

The two fixtures under fixtures/ are separate test-only adapters. They exercise
the actual helper timer while stalling leaf loading or stalling after a real
checked leaf publication. They must never be used in production bundles.
