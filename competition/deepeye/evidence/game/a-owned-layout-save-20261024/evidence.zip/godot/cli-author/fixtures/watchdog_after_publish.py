"""Test-only adapter: preserve actual leaf publication, lose its response."""
import hashlib
import json
from pathlib import Path
import sys
import time

bundle_path = Path(sys.argv[2])
bundle = json.loads(bundle_path.read_bytes())
helper_path = bundle_path.parent / bundle["helper"]["path"]
raw = helper_path.read_bytes()
assert hashlib.sha256(raw).hexdigest() == bundle["helper"]["sha256"]
namespace = {"__name__": "_test_layout_commit_cli", "__file__": str(helper_path)}
exec(compile(raw, str(helper_path), "exec"), namespace)
original_load = namespace["_load_leaf"]


def delayed_response(path):
    original_commit = original_load(path)

    def commit_then_stall(target, payload):
        result = original_commit(target, payload)
        (bundle_path.parent / "after-publication.json").write_text(json.dumps(result), encoding="utf-8")
        time.sleep(20)
        raise AssertionError("watchdog should already have self-exited")

    return commit_then_stall


namespace["_load_leaf"] = delayed_response
sys.exit(namespace["main"]())
