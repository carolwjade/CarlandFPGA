"""Root byte and literal readback only; no producer/test/engine execution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

P = Path(__file__).resolve().parent
O = P.parent
R = P.parents[2]
W = R / '.local/deepeye-implementation-a'
read = lambda p: json.loads(p.read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()
E = O / 'game3d-edit-roundtrip-independent-20261024'
L = R / '.local/deepeye-game3d-edit-roundtrip-independent-20261024'
m = read(E / 'artifact-manifest.json')
assert m['member_count'] == len(m['files']) == 80
for name, row in m['files'].items():
    prefix, rel = name.split('/', 1)
    base = {'evidence': E, 'work': L}[prefix]
    path = (base / rel).resolve()
    path.relative_to(base.resolve())
    raw = path.read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], name
result = read(E / 'attempt1-result.json')
assert result['check_count'] == len(result['checks']) == 112
assert not result['failures'] and all(row['ok'] is True for row in result['checks'])
stdout = (E / 'attempt1-stdout.bin').read_text(encoding='utf-8')
assert len([line for line in stdout.splitlines() if line.startswith('INDEPENDENT_CHECK ')]) == 112
assert not (E / 'attempt1-stderr.bin').read_bytes()
execution = read(E / 'attempt1-execution.json')
assert execution['exit_code'] == 0 and execution['terminal'] and not execution['timed_out']
assert execution['pid'] == 35424
oracle = read(E / 'oracle-executable.json')
saved = read(E / 'attempt1-saved-layout.json')
assert set(saved) == {'contract', 'layout', 'layout_hash', 'requirements_sha256', 'schema', 'units'}
layout = saved['layout']
assert len(layout['obstacles']) == len(oracle['entities']) == 5
for actual, expected in zip(layout['obstacles'], oracle['entities']):
    assert actual['kind'] == expected['kind']
    for field in ['position', 'rotation_deg', 'size']:
        assert [actual[field][axis] for axis in ['x', 'y', 'z']] == expected[field]
assert layout['gates'] == oracle['gates']
assert layout == result['layout_before_save'] == result['layout_reopened']
assert saved['layout_hash'] == result['hash_before_save'] == result['final_hash']
pins = read(E / 'source-pins.json')
assert len(pins['files']) == 52
for row in pins['files']:
    raw = (W / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
api = dict(accepted_scope='new complete-original-scene dummy-headless data/API only',
    actual_checks=112, actual_engine_invocations=1, actual_pid=35424,
    five_literal_entities_and_saved_JSON_independently_read=True,
    manifest_members_verified=80, original_sources_verified=52,
    casing_axis_oracle_delta='only [1,8,1] to [1,1,8] authorized; original freeze retained',
    runtime_new_run_cleanup='unavailable/not_proven; high-level obligation OPEN',
    visual_native_input_DPI_physics_H12_or_formal_acceptance=False)
B = O / 'b-minimal-pl-readiness-20261024'
bm = read(B / 'EVIDENCE_MANIFEST.json')
assert len(bm['files']) == 123
for row in bm['files']:
    path = (R / row['path']).resolve()
    path.relative_to(R.resolve())
    raw = path.read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
bp = read(B / 'SOURCE_HASH_MANIFEST.json')
assert bp['selected_blob_count'] == len(bp['files']) == 24
for row in bp['files']:
    raw = (R / '.local/deepeye-b-minimal-pl-readiness-20261024/snapshot' / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest() == row['git_blob']
br = read(B / 'result.json')
assert br['tested_head'] == '8ca3dd05cac4aea49c0afe53a6d9a12124aa12d2'
ready = dict(disposition='minimum_same_build_PL_package_not_delivered_at_exact_read_head',
    tested_head=br['tested_head'], selected_exact_blobs_verified=24, manifest_members_verified=123,
    missing=['same actual implemented bit/HWH/build identity',
        'original source4/topology2 stopped BOOT and trigger-to-new-sample causal integration',
        'matching A-only bounded collect/stop script and actual parameters'],
    producer_OOC33_and_fixture34_independently_accepted=False,
    unpublished_B_work_not_inferred_absent=True, original_B_task_preserved=True,
    final_ADC_CNN_three_PWM_not_added_as_earliest_diagnostic_prerequisites=True)
record = dict(schema=1, utc=datetime.now(timezone.utc).isoformat(),
    product_head=pins['head'], API_review=api, B_readiness=ready,
    H01_H15='preserved', G03='not_run', R03='not_run', all29='not_run')
with (P / 'game-api-and-PL-readiness-root-decision.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump(record,f,ensure_ascii=False,indent=2)
    f.write('\n')
print(json.dumps(record,ensure_ascii=False))
