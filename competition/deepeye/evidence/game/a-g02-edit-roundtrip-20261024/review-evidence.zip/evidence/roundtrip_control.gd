extends SceneTree

var checks: Array = []
var record: Dictionary = {"schema": 1, "checks": checks, "scene": "res://viewer/main.tscn", "render_claim": "none; dummy headless API only"}
var scene
var doc
var shell
var plan: Dictionary

func _initialize() -> void:
	call_deferred("exercise")

func check(id: String, ok: bool, detail: Variant = null) -> void:
	checks.append({"id": id, "ok": ok, "detail": detail})
	print("INDEPENDENT_CHECK ", id, " ", "PASS" if ok else "FAIL")

func vec(a: Array) -> Vector3:
	return Vector3(float(a[0]), float(a[1]), float(a[2]))

func arr(v: Vector3) -> Array:
	return [v.x, v.y, v.z]

func data_layout() -> Dictionary:
	var exported: Dictionary = doc.export_layout_text()
	check("export_ok", exported.ok, exported)
	if not exported.ok:
		return {}
	return JSON.parse_string(exported.text).layout

func match_literals(layout: Dictionary, tag: String) -> void:
	check(tag + "_count", layout.obstacles.size() == 5, layout.obstacles.size())
	var ids: Array = []
	for i in mini(layout.obstacles.size(), plan.entities.size()):
		var actual: Dictionary = layout.obstacles[i]
		var wanted: Dictionary = plan.entities[i]
		check(tag + "_kind_" + str(i), actual.kind == wanted.kind, actual.kind)
		check(tag + "_positive_unique_id_" + str(i), actual.object_id > 0 and not ids.has(actual.object_id), actual.object_id)
		ids.append(actual.object_id)
		for field in ["position", "rotation_deg", "size"]:
			var packed: Dictionary = actual[field]
			var value := Vector3(float(packed.x), float(packed.y), float(packed.z))
			check(tag + "_" + wanted.kind + "_" + field, value.distance_to(vec(wanted[field])) <= 0.000001, arr(value))
	check(tag + "_gates", layout.gates == plan.gates, layout.gates)

func state() -> Dictionary:
	return {"run_state":doc.run_state,"control_bridge_connected":doc.control_bridge_connected,"links":doc.link_state.duplicate(true),"motion":doc.is_motion_active()}

func gate_data() -> Dictionary:
	var result: Dictionary = {}
	for which in ["entry", "exit"]:
		var node: Node3D = scene.get_node("World/Gates/Gate_" + which)
		var disc: MeshInstance3D = node.get_child(1)
		var material: StandardMaterial3D = disc.material_override
		var mesh: CylinderMesh = disc.mesh
		result[which] = {"position":arr(node.position),"normal":arr(node.basis.y),"diameter":mesh.top_radius*2.0,"color":[material.albedo_color.r,material.albedo_color.g,material.albedo_color.b]}
	return result

func file_action(action: String, path: String) -> void:
	check("prepare_" + action, shell._prepare_file_dialog(action))
	shell._on_file_selected(path)
	check("file_" + action, shell.last_file_result.ok, shell.last_file_result.duplicate(true))

func exercise() -> void:
	plan = JSON.parse_string(FileAccess.get_file_as_string("res://independent-oracle.json"))
	record["user_dir"] = OS.get_user_data_dir()
	record["pid"] = OS.get_process_id()
	var own := OS.get_environment("DEEPEYE_REVIEW_OWNED_ROOT").replace("\\", "/").to_lower()
	if not OS.get_user_data_dir().replace("\\", "/").to_lower().begins_with(own + "/"):
		check("owned_user_dir", false, OS.get_user_data_dir())
		print(JSON.stringify(record))
		quit(2)
		return
	check("owned_user_dir", true, OS.get_user_data_dir())
	var packed = load("res://viewer/main.tscn")
	check("R01_packed_original_scene", packed is PackedScene)
	if not packed is PackedScene:
		finish()
		return
	scene = packed.instantiate()
	root.add_child(scene)
	await process_frame
	doc = scene.document
	shell = scene.shell
	check("R01_full_original_ready", doc != null and shell != null and scene.get_node_or_null("World/DrillPresentation") != null)
	check("R01_run_disabled", shell._run_button.disabled and not doc.control_bridge_connected and not doc.is_motion_active(), state())
	record["startup_state"] = state()
	record["presentation_before"] = scene._asset_presenter.report()
	check("R02_clear_initial", doc.reset_layout().ok)
	for target in plan.entities:
		var created: Dictionary = doc.add_obstacle(target.kind)
		check("R02_add_" + target.kind, created.ok, created)
		if created.ok:
			var edited: Dictionary = doc.update_obstacle(created.id, {"position":vec(target.position),"rotation_deg":vec(target.rotation_deg),"size":vec(target.size)})
			check("R02_edit_" + target.kind, edited.ok, edited)
	for which in ["entry", "exit"]:
		var g: Dictionary = plan.gates[which]
		check("R03_set_" + which, doc.set_gate(which,g.face,g.u,g.v).ok)
	var before: Dictionary = data_layout()
	record["layout_before_save"] = before
	match_literals(before, "R02_before")
	var before_hash: String = doc.commitment_hash()
	record["hash_before_save"] = before_hash
	var gates_before: Dictionary = gate_data()
	record["gates_before"] = gates_before
	check("R03_equal_diameter", absf(gates_before.entry.diameter-0.30) <= 0.000001 and absf(gates_before.exit.diameter-0.30) <= 0.000001)
	check("R03_gate_face_positions", vec(gates_before.entry.position).distance_to(Vector3(2,-3,15)) <= 0.000001 and vec(gates_before.exit.position).distance_to(Vector3(-4,5,-15)) <= 0.000001, gates_before)
	check("R03_gate_normals", vec(gates_before.entry.normal).distance_to(Vector3(0,0,1)) <= 0.000001 and vec(gates_before.exit.normal).distance_to(Vector3(0,0,-1)) <= 0.000001)
	check("R03_blue_red", gates_before.entry.color[2] > gates_before.entry.color[0] and gates_before.exit.color[0] > gates_before.exit.color[2])
	var path := OS.get_user_data_dir().path_join("roundtrip-layout.json")
	record["layout_file"] = path
	file_action("save", path)
	var envelope: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
	record["saved_envelope"] = envelope
	var keys: Array = envelope.keys()
	keys.sort()
	check("R03_geometry_only_envelope", keys == ["contract","layout","layout_hash","requirements_sha256","schema","units"], keys)
	check("R03_saved_hash", envelope.layout_hash == before_hash)
	shell._on_clear_pressed()
	check("R03_clear_effect", doc.obstacle_count() == 0 and doc.commitment_hash() != before_hash)
	file_action("open",path)
	var reopened: Dictionary = data_layout()
	record["layout_reopened"] = reopened
	match_literals(reopened,"R03_reopened")
	check("R03_canonical_roundtrip", reopened == before, reopened)
	check("R03_hash_roundtrip", doc.commitment_hash() == before_hash, doc.commitment_hash())
	check("R03_gate_scene_roundtrip", gate_data() == gates_before, gate_data())
	check("R03_scene_entities", scene._asset_presenter.report().state == "ready" and scene._asset_presenter._nodes.size() == 5, scene._asset_presenter.report())
	doc.select_object(int(doc.obstacles[0].object_id))
	check("R04_mutate", doc.update_obstacle(doc.selected_id,{"position":Vector3(-7,2,-4)}).ok)
	check("R04_hash_changes", doc.commitment_hash() != before_hash)
	record["edited_origin"] = doc.layout_origin
	check("R04_origin_invalidates", doc.layout_origin == "文件布局（已编辑）" and not doc.seed_known)
	file_action("open",path)
	check("R04_restore", data_layout() == before and doc.commitment_hash() == before_hash)
	check("R04_reset_transients", doc.selected_id == -1 and doc.undo_depth() == 0 and doc.redo_depth() == 0 and not doc.seed_known)
	var camera_before_state: Dictionary = state()
	var camera_before_hash: String = doc.commitment_hash()
	var poses: Dictionary = {}
	for view in ["top","bottom","front","back","left","right","iso"]:
		scene.set_camera_view(view)
		poses[view] = arr(scene.get_node("Camera3D").position)
		check("R05_" + view + "_world_unchanged", state() == camera_before_state and doc.commitment_hash() == camera_before_hash)
	check("R05_distinct_views", poses.top != poses.bottom and poses.front != poses.back and poses.left != poses.right and poses.iso != poses.front, poses)
	scene.focus_drill()
	poses["focus_drill"] = arr(scene.get_node("Camera3D").position)
	check("R05_focus_moves_camera", poses.focus_drill != poses.iso, poses.focus_drill)
	check("R05_focus_world_unchanged", state() == camera_before_state and doc.commitment_hash() == camera_before_hash)
	record["camera_poses"] = poses
	check("R06_lock", doc.lock_layout().ok)
	var locked_hash: String = doc.commitment_hash()
	check("R06_locked_reject", not doc.update_obstacle(int(doc.obstacles[0].object_id),{"position":Vector3(-6,2,-4)}).ok and doc.commitment_hash() == locked_hash)
	check("R06_unlock", doc.unlock_layout().ok)
	check("R06_unlocked_edit", doc.update_obstacle(int(doc.obstacles[0].object_id),{"position":Vector3(-6,2,-4)}).ok and doc.commitment_hash() != locked_hash)
	record["R06_missing"] = {"run_id":"unavailable/not_proven","planning_command_observation_cleanup":"unavailable/not_proven","runtime_stop_transition":"not_exercised; no Run/actor/authority"}
	file_action("open",path)
	record["final_state"] = state()
	record["final_hash"] = doc.commitment_hash()
	record["final_events"] = doc.events.duplicate(true)
	record["presentation_after"] = scene._asset_presenter.report()
	finish()

func finish() -> void:
	var failures: Array = []
	for c in checks:
		if not c.ok: failures.append(c.id)
	record["failures"] = failures
	record["check_count"] = checks.size()
	record["run_never_called"] = true
	var out := FileAccess.open(OS.get_user_data_dir().path_join("independent-result.json"),FileAccess.WRITE)
	if out != null:
		out.store_string(JSON.stringify(record,"  "))
		out.close()
	print("INDEPENDENT_TERMINAL ",JSON.stringify({"checks":checks.size(),"failures":failures,"user_dir":OS.get_user_data_dir()}))
	if is_instance_valid(scene): scene.free()
	quit(0 if failures.is_empty() else 1)
