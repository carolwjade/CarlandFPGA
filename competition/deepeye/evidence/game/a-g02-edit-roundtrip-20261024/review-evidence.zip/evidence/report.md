# Game3D edit/save/clear/open independent API evidence

At current head `496e96aa276083df209dbc67da28d8d68b928aea`, one fresh dummy headless Godot invocation loaded and instantiated the **complete original** `res://viewer/main.tscn`. PID 35424 terminated with exit 0 in 0.75s; stderr was empty. All 112 executed assertions passed. No second Godot invocation was made.

This is data/API evidence only. R01–R05 passed; R06's lock/reject/unlock/edit subset passed. The viewer exposes no run_id, planning state, command lease or observation map. Stop/new-run/old-state invalidation is therefore **unavailable/not_proven**, not a passing item. The high-level end-to-end obligation remains OPEN. G01/G02/G03/R03/all29 remain `not_run`; H01–H15 are unchanged and are not accepted by this review.

## What was exercised

- Original `main.tscn` / main `_ready` / Shell binding / SceneDocument / AssetPresenter / procedural factory ran in an unchanged 52-file snapshot. It reached the original full scene; presenter diagnostics were empty, frame/drill creation each occurred once, and five material nodes existed after reopening.
- Original `add_obstacle` then `update_obstacle` edited hard_rock, water, fault, void and casing. Literal positions, Euler orientation and dimensions are in `oracle-executable.json`. The saved six canonical fields (including positive unique IDs and original fixed priorities) matched the literal data on independent Python readback.
- Original `set_gate` placed entry at front `(2,-3,15)` and exit at back `(-4,5,-15)`. Original scene node data preserved their opposing face normals, blue/red colors and equal 0.300m disc diameters across opening. This does not establish rendered appearance, authority initialization clearance or full drill crossing.
- Shell `_prepare_file_dialog` plus `_on_file_selected` invoked original save/open logic without showing or interacting with a dialog. Shell clear invoked original reset. Save → clear → open restored all five entities, their fields and both gates. The original document/export/file/open/final commitment hash was `fcef4d870857137ef708c563b4a946342655a24dcd87e60911ee35c579643f8e`. The hash was compared across these stages; this is not an independent proof of the hash implementation. Saved raw JSON contains only the six allowed envelope fields and no runtime/control/source authority.
- A post-save entity edit changed the hash and marked file origin edited. Opening restored the saved geometry/hash, unknown seed, empty undo/redo and no selection. These checks establish document provenance/history invalidation only.
- Seven original camera view APIs and focus_drill changed camera poses while preserving document hash and original run/link/control state. Lock rejected edits without geometry change; unlock allowed them. Run was never called; no test state injection was used.

## Oracle timing, correction and exposure

`oracle-plan.json` was frozen before first implementation-body reads: SHA `5f129076a7b02b54b85c5c34de64cdb9c1277446518a115a995412ee47946aee`. Public persistence/resource/interface docs and taskbook were read first. Previous review reports had already disclosed API names, paths/hashes and claims; memory supplied earlier G02 evidence-boundary reminders. This was not a blind review. No old harness body was read or imported, and no old suite was run.

The initial fixture incorrectly encoded casing diameter1/length8 as `[1,8,1]`. After source inspection, root independently checked public local+Z and physical diameter/length contracts and authorized only `[1,1,8]`. The original freeze is retained. Root also authorized recording absent R06 runtime state as unavailable/not_proven rather than fabricating fields or enabling Run. `oracle-authorized-delta.json` records this; executable oracle SHA is `8e6927035bee23414a2df2e9f4a6fb95b2e2d66e1535333f704edf80ffe7c830`. No other oracle was changed. Neither the invalid original casing fixture nor an imagined runtime field was executed and relabeled successful.

## Isolation and preservation

Static startup scan found no autoload, external-process execution, networking or listener primitives in non-test scene sources. Fixed scene/preload/factory paths were reviewed. Snapshot files matched committed current head before and after; the original project, scene, Run gate, geometry, materials and APIs were not edited. The fresh owned work tree, APPDATA/LOCALAPPDATA/TEMP/TMP and actual Godot user directory were independent of original and earlier task caches. Only the new harness and literal oracle were added to the snapshot. The harness loaded the original complete scene, not a substitute.

Original index, six original cache files, three protected C4 files, dirty gitattributes bytes and git status are unchanged. `post-readback-verification.json` binds independent JSON readback, current/snapshot pins and integrity checks. Actual process argv/PID/start/end/exit/terminal and binary stdout/stderr are preserved. A/root alone retains board authority; this review used no display/UI input, board, serial, actor, service, listener, network message, credentials, install or delegation.

## Limits

Dummy headless does not prove images, native mouse/keyboard or dialogs, visual quality, DPI/resolution fit, 200-action UI interaction, complete G01/G02, physics collision/full crossing, causal sensor observations, AI, BOOT, physical clocks, control authority or either H12 online chain. Existing unavailable new-run/cleanup integration is not repaired or accepted by this leaf review. Root retains formal acceptance and publication decisions.
