import hashlib,json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
PRODUCT=ROOT/'.local/deepeye-implementation-a'
WORK=ROOT/'.local/deepeye-game3d-edit-roundtrip-independent-20261024'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((OUT/n).read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def git(*a):return subprocess.check_output([GIT,'-C',str(PRODUCT),*a])
def inventory(base):
 return [{'path':str(p.relative_to(PRODUCT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(base.rglob('*')) if p.is_file()] if base.exists() else []
baseline=read('integrity-before.json')
index=pathlib.Path(baseline['index_path'])
c4=[]
for rel in ['competition/deepeye/ai_pc','competition/deepeye/evidence/ai','competition/deepeye/tests/ai']:c4.extend(inventory(PRODUCT/rel))
after={'index_path':str(index),'index_sha256':sha(index),'original_cache':inventory(PRODUCT/'competition/deepeye/simulator/.godot'),'c4_files':c4,'dirty_gitattributes_sha256':sha(PRODUCT/'docs/competition/deepeye-2026/.gitattributes'),'status':git('status','--short').decode()}
write('integrity-after.json',after)
assert baseline==after,'Protected original metadata changed'
pins=read('source-pins.json')
assert git('rev-parse','HEAD').decode().strip()==pins['head']
for pin in pins['files']:
 assert sha(PRODUCT/pin['path'])==pin['sha256'],pin
 assert sha(WORK/'snapshot'/pin['path'])==pin['sha256'],pin
plan=read('oracle-executable.json')
saved=read('attempt1-saved-layout.json')
result=read('attempt1-result.json')
execution=read('attempt1-execution.json')
assert execution['exit_code']==0 and execution['terminal'] and not execution['timed_out'] and execution['duration_seconds']<60
assert len(list(OUT.glob('attempt*-execution.json')))==1
assert not result['failures'] and result['check_count']==112 and len(result['checks'])==112
assert all(x['ok'] is True for x in result['checks'])
assert saved['layout']==result['layout_before_save']==result['layout_reopened']
assert saved['layout_hash']==result['hash_before_save']==result['final_hash']
assert saved['layout']['gates']==plan['gates']
priorities={'hard_rock':1,'water':2,'fault':4,'void':3,'casing':5}
for actual,wanted in zip(saved['layout']['obstacles'],plan['entities'],strict=True):
 assert set(actual)=={'object_id','kind','position','rotation_deg','size','priority'}
 assert actual['kind']==wanted['kind'] and actual['priority']==priorities[wanted['kind']]
 for field in ['position','rotation_deg','size']:
  assert [actual[field][axis] for axis in ['x','y','z']]==wanted[field],(field,actual)
assert len(saved['layout']['obstacles'])==5
assert set(saved)=={'schema','contract','requirements_sha256','units','layout','layout_hash'}
assert saved['schema']==1 and saved['units']=='m'
assert saved['contract']=='DEEPEYE-HUMAN-LOCK-20261014/revision1'
scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
req=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert req==plan['requirements_sha256_computed']==saved['requirements_sha256']
assert result['startup_state']==result['final_state']
assert not result['final_state']['control_bridge_connected'] and not result['final_state']['motion']
assert all(v=='未连接' for v in result['final_state']['links'].values())
write('post-readback-verification.json',{'saved_json_literal_check':True,'five_kinds':list(priorities),'material_priorities':priorities,'pre_save_reopen_final_hash':saved['layout_hash'],'saved_json_sha256':sha(OUT/'attempt1-saved-layout.json'),'112_actual_checks_verified':True,'original_source_and_snapshot_52_pins_unchanged':True,'original_index_cache_c4_dirty_bytes_unchanged':True,'requirements_sha256_computed':req,'head_unchanged':pins['head'],'godot_new_invocations':1,'no_old_suite_or_engine_second_invocation':True,'snapshot_godot_cache_files':len(list((WORK/'snapshot/competition/deepeye/simulator/.godot').rglob('*'))) if (WORK/'snapshot/competition/deepeye/simulator/.godot').exists() else 0})
final={'schema':1,'job_id':'child-4f778e1797c54018976036980fce8cf7','work_id':'A-GAME3D-EDIT-ROUNDTRIP-INDEPENDENT-20261024-v1','outcome':'scoped_complete_original_scene_API_controls_passed; high_level_runtime_invalidation_unavailable_not_proven','head':pins['head'],'sourcepins_sha256':sha(OUT/'source-pins.json'),'godot_invocations':1,'pid':execution['pid'],'exit_code':execution['exit_code'],'terminal':execution['terminal'],'seconds':execution['duration_seconds'],'checks_executed':112,'checks_passed':112,'checks_failed':0,'groups':{'R01':'pass','R02':'pass','R03':'pass','R04':'pass','R05':'pass','R06':'lock/unlock subset pass; new_run/planning/command/observation cleanup unavailable/not_proven'},'layout_hash':saved['layout_hash'],'protected_integrity':'52 current/snapshot pins, original index, 6 original cache files, 3 C4 files and dirty gitattributes unchanged','oracle_original_sha256':sha(OUT/'oracle-plan.json'),'oracle_executable_sha256':sha(OUT/'oracle-executable.json'),'authorized_delta':'casing XY diameter1/Z length8; R06 missing fields unavailable. Original freeze retained. No other oracle changes.','prior_source_exposure_disclosed':True,'H01_H15':'preserved; not accepted','G01_G02_G03_R03_all29':'not_run','boundary':'dummy headless data/API only; no native input, image, DPI, authority physics/collision/full crossing, sensor/model, board, online control or formal acceptance proof','product_writes':False,'run_requested':False}
write('result.json',final)
report=f'''# Game3D edit/save/clear/open independent API evidence

At current head `{pins['head']}`, one fresh dummy headless Godot invocation loaded and instantiated the **complete original** `res://viewer/main.tscn`. PID {execution['pid']} terminated with exit 0 in {execution['duration_seconds']:.2f}s; stderr was empty. All 112 executed assertions passed. No second Godot invocation was made.

This is data/API evidence only. R01–R05 passed; R06's lock/reject/unlock/edit subset passed. The viewer exposes no run_id, planning state, command lease or observation map. Stop/new-run/old-state invalidation is therefore **unavailable/not_proven**, not a passing item. The high-level end-to-end obligation remains OPEN. G01/G02/G03/R03/all29 remain `not_run`; H01–H15 are unchanged and are not accepted by this review.

## What was exercised

- Original `main.tscn` / main `_ready` / Shell binding / SceneDocument / AssetPresenter / procedural factory ran in an unchanged 52-file snapshot. It reached the original full scene; presenter diagnostics were empty, frame/drill creation each occurred once, and five material nodes existed after reopening.
- Original `add_obstacle` then `update_obstacle` edited hard_rock, water, fault, void and casing. Literal positions, Euler orientation and dimensions are in `oracle-executable.json`. The saved six canonical fields (including positive unique IDs and original fixed priorities) matched the literal data on independent Python readback.
- Original `set_gate` placed entry at front `(2,-3,15)` and exit at back `(-4,5,-15)`. Original scene node data preserved their opposing face normals, blue/red colors and equal 0.300m disc diameters across opening. This does not establish rendered appearance, authority initialization clearance or full drill crossing.
- Shell `_prepare_file_dialog` plus `_on_file_selected` invoked original save/open logic without showing or interacting with a dialog. Shell clear invoked original reset. Save → clear → open restored all five entities, their fields and both gates. The original document/export/file/open/final commitment hash was `{saved['layout_hash']}`. The hash was compared across these stages; this is not an independent proof of the hash implementation. Saved raw JSON contains only the six allowed envelope fields and no runtime/control/source authority.
- A post-save entity edit changed the hash and marked file origin edited. Opening restored the saved geometry/hash, unknown seed, empty undo/redo and no selection. These checks establish document provenance/history invalidation only.
- Seven original camera view APIs and focus_drill changed camera poses while preserving document hash and original run/link/control state. Lock rejected edits without geometry change; unlock allowed them. Run was never called; no test state injection was used.

## Oracle timing, correction and exposure

`oracle-plan.json` was frozen before first implementation-body reads: SHA `{sha(OUT/'oracle-plan.json')}`. Public persistence/resource/interface docs and taskbook were read first. Previous review reports had already disclosed API names, paths/hashes and claims; memory supplied earlier G02 evidence-boundary reminders. This was not a blind review. No old harness body was read or imported, and no old suite was run.

The initial fixture incorrectly encoded casing diameter1/length8 as `[1,8,1]`. After source inspection, root independently checked public local+Z and physical diameter/length contracts and authorized only `[1,1,8]`. The original freeze is retained. Root also authorized recording absent R06 runtime state as unavailable/not_proven rather than fabricating fields or enabling Run. `oracle-authorized-delta.json` records this; executable oracle SHA is `{sha(OUT/'oracle-executable.json')}`. No other oracle was changed. Neither the invalid original casing fixture nor an imagined runtime field was executed and relabeled successful.

## Isolation and preservation

Static startup scan found no autoload, external-process execution, networking or listener primitives in non-test scene sources. Fixed scene/preload/factory paths were reviewed. Snapshot files matched committed current head before and after; the original project, scene, Run gate, geometry, materials and APIs were not edited. The fresh owned work tree, APPDATA/LOCALAPPDATA/TEMP/TMP and actual Godot user directory were independent of original and earlier task caches. Only the new harness and literal oracle were added to the snapshot. The harness loaded the original complete scene, not a substitute.

Original index, six original cache files, three protected C4 files, dirty gitattributes bytes and git status are unchanged. `post-readback-verification.json` binds independent JSON readback, current/snapshot pins and integrity checks. Actual process argv/PID/start/end/exit/terminal and binary stdout/stderr are preserved. A/root alone retains board authority; this review used no display/UI input, board, serial, actor, service, listener, network message, credentials, install or delegation.

## Limits

Dummy headless does not prove images, native mouse/keyboard or dialogs, visual quality, DPI/resolution fit, 200-action UI interaction, complete G01/G02, physics collision/full crossing, causal sensor observations, AI, BOOT, physical clocks, control authority or either H12 online chain. Existing unavailable new-run/cleanup integration is not repaired or accepted by this leaf review. Root retains formal acceptance and publication decisions.
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
excluded={'lease.private.json','artifact-manifest.json','freeze-verification.json','native-complete-request.json','native-complete-response.json'}
members={}
for base,label in [(OUT,'evidence'),(WORK,'work')]:
 for p in sorted(base.rglob('*')):
  if p.is_file() and not (base==OUT and p.name in excluded):
   rel=label+'/'+str(p.relative_to(base)).replace('\\','/')
   members[rel]={'bytes':p.stat().st_size,'sha256':sha(p)}
manifest={'schema':1,'files':members,'member_count':len(members),'excluded_private_and_postfreeze_receipts':sorted(excluded),'coverage':'All current files under owned evidence/work roots except listed exclusions. Manifest self is not a member.'}
write('artifact-manifest.json',manifest)
for rel,pin in members.items():
 label,name=rel.split('/',1);p=(OUT if label=='evidence' else WORK)/name
 assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256']
write('freeze-verification.json',{'all_members_verified':True,'member_count':len(members),'manifest_sha256':sha(OUT/'artifact-manifest.json'),'manifest_itself_member':False,'report_sha256':sha(OUT/'report.md'),'result_sha256':sha(OUT/'result.json'),'sourcepins_sha256':sha(OUT/'source-pins.json')})
print(json.dumps(read('freeze-verification.json')))
