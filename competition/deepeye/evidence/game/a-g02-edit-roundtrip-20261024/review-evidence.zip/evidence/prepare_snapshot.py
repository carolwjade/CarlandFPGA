import datetime, hashlib, json, pathlib, re, shutil, subprocess
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
PRODUCT=ROOT/'.local/deepeye-implementation-a'
WORK=ROOT/'.local/deepeye-game3d-edit-roundtrip-independent-20261024'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(b): return hashlib.sha256(b).hexdigest()
def run(*args): return subprocess.check_output([GIT,'-C',str(PRODUCT),*args])
def write(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert not WORK.exists(), 'Fresh owned work root required'
WORK.mkdir()
SNAP=WORK/'snapshot'
SNAP.mkdir()
paths=run('ls-files','competition/deepeye/simulator').decode().splitlines()+['competition/deepeye/docs/resource_contract.json','competition/deepeye/docs/interface.json']
pins=[]
for rel in paths:
 p=PRODUCT/rel
 data=p.read_bytes()
 blob=run('show','HEAD:'+rel)
 assert data==blob,rel
 target=SNAP/rel
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(data)
 pins.append({'path':rel,'bytes':len(data),'sha256':sha(data),'committed_equal':True})
write('source-pins.json',{'head':run('rev-parse','HEAD').decode().strip(),'files':pins,'snapshot':str(SNAP),'count':len(pins)})
cache=PRODUCT/'competition/deepeye/simulator/.godot'
def inventory(base):
 return [{'path':str(p.relative_to(PRODUCT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(base.rglob('*')) if p.is_file()] if base.exists() else []
index=pathlib.Path(run('rev-parse','--git-path','index').decode().strip())
if not index.is_absolute(): index=PRODUCT/index
c4=[]
for rel in ['competition/deepeye/ai_pc','competition/deepeye/evidence/ai','competition/deepeye/tests/ai']:
 c4.extend(inventory(PRODUCT/rel))
write('integrity-before.json',{'index_path':str(index.resolve()),'index_sha256':sha(index.read_bytes()),'original_cache':inventory(cache),'c4_files':c4,'dirty_gitattributes_sha256':sha((PRODUCT/'docs/competition/deepeye-2026/.gitattributes').read_bytes()),'status':run('status','--short').decode()})
for d in ['user','appdata','localappdata','temp']:(WORK/d).mkdir()
plan=json.loads((OUT/'oracle-plan.json').read_text(encoding='utf-8'))
original=sha((OUT/'oracle-plan.json').read_bytes())
plan['entities'][4]['size']=[1,1,8]
plan['controls'][5]['expected']='Original lock rejects mutation unchanged, unlock permits edit. No run_id/planning/command/observation state is exposed in this viewer baseline; those original high-level obligations are unavailable/not_proven, never passed.'
write('oracle-executable.json',plan)
write('oracle-authorized-delta.json',{'original_oracle_sha256':original,'executable_oracle_sha256':sha((OUT/'oracle-executable.json').read_bytes()),'parent_authorized':True,'casing_fixture_size_before':[1,8,1],'casing_fixture_size_after':[1,1,8],'why':'Public resource contract forward_local +Z; taskbook casing diameter1 length8 maps to XY1 Z8. Original fixture Y8 was invalid. Preserve original freeze.','R06':'Parent authorized only lock/unlock executable subset. Missing run_id/old state cleanup remain unavailable/not_proven, not a passing claim.','other_oracles_unchanged':True,'godot_started':False})
project=SNAP/'competition/deepeye/simulator'
patterns=[r'OS\.(execute|create_process|shell_open)',r'(TCPServer|TCPServer3D|UDPServer|HTTPClient|HTTPRequest|WebSocketPeer|WebSocketMultiplayerPeer|ENetMultiplayerPeer|StreamPeerTCP|PacketPeerUDP)',r'\[autoload\]',r'EditorPlugin',r'(start_server|create_server|listen)\s*\(']
hits=[]
for p in sorted(project.rglob('*')):
 if p.is_file() and p.suffix in ['.gd','.godot','.tscn'] and 'tests' not in p.parts:
  txt=p.read_text(encoding='utf-8')
  for pat in patterns:
   for m in re.finditer(pat,txt):hits.append({'path':str(p.relative_to(project)),'pattern':pat,'line':txt.count('\n',0,m.start())+1,'match':m.group(0)})
classes=[]
for p in sorted(project.rglob('*.gd')):
 if 'tests' not in p.parts:
  txt=p.read_text(encoding='utf-8')
  m=re.search(r'^class_name\s+(\w+)',txt,re.M)
  if m:classes.append({'class':m.group(1),'path':str(p.relative_to(project)).replace('\\','/')})
engine=ROOT/'.planning/deepeye-implementation-a/app-worker-ui/godot/Godot_v4.7.2-stable_win64.exe'
write('startup-static-audit.json',{'entry_scene':'res://viewer/main.tscn','project_godot_unmodified':True,'no_autoload': '[autoload]' not in (project/'project.godot').read_text(encoding='utf-8'),'external_control_patterns':hits,'non_test_global_classes':classes,'engine_path':str(engine),'engine_sha256':sha(engine.read_bytes()),'no_old_cache_copied':not(project/'.godot').exists(),'no_engine_invocation':True})
shutil.copyfile(OUT/'oracle-executable.json',project/'independent-oracle.json')
print(json.dumps({'snapshot_files':len(pins),'original_cache_files':len(inventory(cache)),'c4_files':len(c4),'startup_external_hits':hits,'classes':classes},ensure_ascii=False))
