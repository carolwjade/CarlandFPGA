import datetime, hashlib, json, os, pathlib, shutil, subprocess, sys, time
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
WORK=ROOT/'.local/deepeye-game3d-edit-roundtrip-independent-20261024'
PROJECT=WORK/'snapshot/competition/deepeye/simulator'
ENGINE=ROOT/'.planning/deepeye-implementation-a/app-worker-ui/godot/Godot_v4.7.2-stable_win64.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
attempt=int(sys.argv[1])
assert attempt in [1,2]
prior=list(OUT.glob('attempt*-execution.json'))
assert len(prior)==attempt-1 and not (OUT/f'attempt{attempt}-execution.json').exists()
if attempt==1:
 assert not (PROJECT/'.godot').exists(),'Old/shared cache prohibited'
shutil.copyfile(OUT/'roundtrip_control.gd',PROJECT/'independent-roundtrip-control.gd')
env=os.environ.copy()
for key,sub in [('APPDATA','appdata'),('LOCALAPPDATA','localappdata'),('TEMP','temp'),('TMP','temp')]:env[key]=str(WORK/sub)
env['DEEPEYE_REVIEW_OWNED_ROOT']=str(WORK)
argv=[str(ENGINE),'--headless','--path',str(PROJECT),'--script','res://independent-roundtrip-control.gd','--log-file',str(OUT/f'attempt{attempt}-godot.log')]
receipt={'schema':1,'attempt':attempt,'argv':argv,'cwd':str(WORK),'timeout_seconds':55,'engine_sha256':sha(ENGINE),'harness_sha256':sha(OUT/'roundtrip_control.gd'),'oracle_sha256':sha(OUT/'oracle-executable.json'),'sourcepins_sha256':sha(OUT/'source-pins.json'),'cache_reused_from_old_task':False,'isolated_environment':{k:env[k] for k in ['APPDATA','LOCALAPPDATA','TEMP','TMP','DEEPEYE_REVIEW_OWNED_ROOT']},'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
start=time.monotonic()
stdout=OUT/f'attempt{attempt}-stdout.bin';stderr=OUT/f'attempt{attempt}-stderr.bin'
with stdout.open('wb') as out,stderr.open('wb') as err:
 p=subprocess.Popen(argv,cwd=WORK,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 receipt['pid']=p.pid
 (OUT/f'attempt{attempt}-started.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 try:
  receipt['exit_code']=p.wait(timeout=55)
  receipt['timed_out']=False
 except subprocess.TimeoutExpired:
  receipt['timed_out']=True
  p.kill()
  receipt['exit_code']=p.wait(timeout=3)
 receipt['terminal']=p.poll() is not None
receipt['duration_seconds']=time.monotonic()-start
receipt['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt['stdout_sha256']=sha(stdout);receipt['stderr_sha256']=sha(stderr)
results=list((WORK/'appdata').rglob('independent-result.json'))
receipt['result_paths']=[str(p) for p in results]
for source in results:
 shutil.copyfile(source,OUT/f'attempt{attempt}-result.json')
 sibling=source.with_name('roundtrip-layout.json')
 if sibling.exists():shutil.copyfile(sibling,OUT/f'attempt{attempt}-saved-layout.json')
(OUT/f'attempt{attempt}-execution.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
print('STDOUT:',stdout.read_text(encoding='utf-8',errors='replace'))
print('STDERR:',stderr.read_text(encoding='utf-8',errors='replace'))
sys.exit(0 if receipt['exit_code']==0 and receipt['terminal'] and results else 1)
