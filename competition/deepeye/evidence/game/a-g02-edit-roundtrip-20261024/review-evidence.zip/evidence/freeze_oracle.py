import hashlib, json, pathlib, subprocess

ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = pathlib.Path(__file__).resolve().parent
PRODUCT = ROOT / '.local/deepeye-implementation-a'
GIT = pathlib.Path('C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
scope = json.loads((ROOT / 'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
computed = hashlib.sha256(json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
assert computed == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
head = subprocess.check_output([str(GIT), '-C', str(PRODUCT), 'rev-parse', 'HEAD'], text=True).strip()
assert head == '496e96aa276083df209dbc67da28d8d68b928aea'
obstacles = [
 {'kind':'hard_rock','position':[-8,2,-4],'rotation_deg':[0,90,0],'size':[2,3,4]},
 {'kind':'water','position':[6,-3,4],'rotation_deg':[0,0,90],'size':[6,4,2]},
 {'kind':'fault','position':[-4,-5,6],'rotation_deg':[90,0,0],'size':[8,1,6]},
 {'kind':'void','position':[4,5,-6],'rotation_deg':[0,180,0],'size':[4,3,2]},
 {'kind':'casing','position':[0,0,0],'rotation_deg':[0,0,180],'size':[1,8,1]},
]
plan = {
 'schema':1,'work_id':'A-GAME3D-EDIT-ROUNDTRIP-INDEPENDENT-20261024-v1','head':head,
 'requirements_sha256_computed':computed,
 'entities':obstacles,'gates':{'entry':{'face':'front','u':2,'v':-3},'exit':{'face':'back','u':-4,'v':5}},
 'controls':[
  {'id':'R01','expected':'Complete original main.tscn reaches ready in dummy headless. Original startup has no external control/autoload/listener. Run is disabled and never requested.'},
  {'id':'R02','expected':'Original edit APIs create exactly five entities, one of every kind; apply literal position/rotation_deg/size. IDs are positive unique; fixed material priorities and IDs are preserved, without inventing unpromised attributes.'},
  {'id':'R03','expected':'Set two legal front/back gates. Save new file, clear original document, reopen through original APIs. Canonical six obstacle fields and gate fields equal pre-save and literal target; commitment hashes equal. Gate geometry remains 0.300m equal diameter, correct face position and colors in original scene data.'},
  {'id':'R04','expected':'Mutate one entity after save. Hash must change, then open saved file restores exactly saved canonical layout/hash, clears selection and undo/redo as documented. Saved envelope contains only allowed fields and no run/control/source authority.'},
  {'id':'R05','expected':'Call six axis views, isometric and focus-drill original camera APIs. At least distinct views change camera pose; all preserve document layout hash and world/run/control state. No real mouse, rendering or input claim.'},
  {'id':'R06','expected':'Check original lock/stop/edit APIs without Run. Locked edit is rejected with geometry unchanged; stopped world edit creates a new run identity and clears original planning/command/observation state to the extent exposed by existing document APIs. Do not inject fabricated authority or call actor/model.'}
 ],
 'comparison':'Numerical canonical document JSON fields tolerance 1e-6 for representation only. No geometry shrink. Entity order stable across save/open. No byte equality requirement for transient UI selection/logs. Priority values come from original material definitions and must persist; not an invented new literal requirement.',
 'adapter_boundary':'Only original complete scene and original editor/document/shell/camera APIs. New harness may read actual document/node fields, never fabricate missing fields or import old harness/TestCase. If an API/contract mismatch arises, preserve failure for root; no product modification or weakened oracle.',
 'execution_limits':{'max_new_godot_invocations':2,'max_seconds_each':60,'headless_dummy_only':True,'fresh_snapshot_cache_user':True,'no_run':True},
 'prior_exposure':[
  'Read public resource_contract.json/interface.json/layout_persistence.md and taskbook 8.2/8.3/G01/G02 before this freeze.',
  'Read game3d-ui-local-next-audit report and game3d-full-scene-offscreen report/source-pins/CLI metadata. They exposed API names set_camera_view/focus_drill, source paths/hashes and earlier review claims. This is not a blind review.',
  'Memory registry old G02 evidence boundary reminders read; no old game harness body read or imported, no prior test rerun. No main/editor implementation body read in this new task before this freeze.'
 ],
 'public_sources':{},'formal_acceptance':'G01/G02/G03/R03/all29 not_run; H01-H15 unchanged; no image/native-input/physical/model/control-authority proof'
}
for rel in ['docs/competition/deepeye-2026/immutable_scope.md','docs/competition/deepeye-2026/immutable_scope.json','docs/competition/deepeye-2026/taskbook_final.md']:
 plan['public_sources'][rel]=digest(ROOT/rel)
for rel in ['competition/deepeye/docs/resource_contract.json','competition/deepeye/docs/interface.json','competition/deepeye/docs/layout_persistence.md']:
 plan['public_sources']['product/'+rel]=digest(PRODUCT/rel)
(OUT/'oracle-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'oracle-freeze.json').write_text(json.dumps({'oracle_sha256':digest(OUT/'oracle-plan.json'),'freeze_script_sha256':digest(pathlib.Path(__file__)),'implementation_read_after_freeze_only':True},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'head':head,'requirements_sha256':computed,'oracle_sha256':digest(OUT/'oracle-plan.json'),'controls':6}))
