"""Source-only synthesis/seal; never import/run capture, launcher, engine or native APIs."""
import hashlib,json,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'.planning/deepeye-resume-20261018/game3d-enum-association-capture-20261024'
G=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024'
COMMIT='ed1daf0bf001b61586d9930840f2f1394092c079'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
inputs=read(OUT/'actual-input-pins.json')
for name,pin in inputs['files'].items():
 assert sha(OUT/'actual-inputs'/name)==pin['sha256'] and sha(AUTHOR/name)==pin['sha256'],name
root_actual=G/'enum-capture-root-actual-readback.json'
assert root_actual.exists()
shutil.copyfile(root_actual,OUT/'actual-inputs/enum-capture-root-actual-readback.json')
events=[json.loads(line) for line in (OUT/'actual-inputs/attempt-01/events.jsonl').read_text(encoding='utf-8').splitlines()]
receipt=read(OUT/'actual-inputs/attempt-01/receipt.json')
capture_report=read(OUT/'actual-inputs/attempt-01/frames/capture-report.json')
cores=[x for x in events if x.get('event')=='enum_association_core']
admitted=[x for x in events if x.get('event')=='native_association_sample' and x['admitted']]
diagnostics=[d for x in events if x.get('event')=='optional_thread_desktop_diagnostics' for d in x['diagnostics']]
assert len(cores)==51 and len(admitted)==46 and len(diagnostics)==46
assert all(x['status']=='unavailable' for x in diagnostics)
assert admitted[0]['sequence']==5 and admitted[-1]['sequence']==50
first=admitted[0]['rows'][0]
assert first['hwnd']==1836712 and first['thread_query']['pid_output']==12208 and first['thread_query']['tid_return']==40996 and first['class_query']['text']=='Engine'
assert cores[-1]['sequence']==51 and cores[-1]['raw_bool']==1
assert not [row for row in cores[-1]['rows'] if row['thread_query']['pid_output']==12208 and row['class_query']['text']=='Engine']
assert receipt['child_terminal'] and receipt['creator_terminal'] and receipt['owned_handles_closed']
assert 'exit_code' not in receipt
assert capture_report=={'frames':[],'reason':'actual backend does not equal windows/vulkan/forward_plus','status':'failed'}
source=(OUT/'actual-inputs/capture.gd').read_text(encoding='utf-8')
gate_line=next(i for i,l in enumerate(source.splitlines(),1) if 'if DisplayServer.get_name()' in l)
load_line=next(i for i,l in enumerate(source.splitlines(),1) if 'var packed := load(' in l)
assert gate_line==45 and load_line==48
assert source.splitlines()[46].strip()=='return'
primary=read(OUT/'primary-source-pins.json');follow=read(OUT/'primary-followup-pins.json')
all_sources=[x for x in primary['sources']+follow['sources'] if x.get('official_blob_sha1_equal')]
by_path={x['path']:x for x in all_sources}
assert all(p in by_path for p in ['platform/windows/display_server_windows.cpp','servers/rendering/rendering_server.cpp','core/os/os.h','doc/classes/DisplayServer.xml','doc/classes/RenderingServer.xml'])
write('source-and-runtime-facts.json',{
 'exact_source_commit':COMMIT,'capture_sha256':sha(OUT/'actual-inputs/capture.gd'),'engine_sha256':inputs['engine_sha256_read_only'],
 'actual':{'Godot_pid':12208,'Godot_initial_tid':40996,'launcher_owner_pid_in_core':cores[0]['owner_pid'],'core_observations':51,'admitted_samples':46,'first_sequence':5,'last_admitted_sequence':50,'first_HWND':1836712,'optional_diagnostics':46,'optional_diagnostics_unavailable':46,'last_core_sequence':51,'last_core_native_BOOL':1,'last_core_Engine_row_count':0,'launcher_failure':receipt['failure'],'child_terminal':True,'creator_terminal':True,'owned_handles_closed':True,'Godot_exit_code':None,'actual_API_tuple':None,'PNG_count':0,'capture_report':capture_report,'raw_stdout':'Vulkan1.4.303 / Forward+ / NVIDIA GeForce RTX4070 Laptop GPU startup text; not an API tuple','input_before':receipt['input_desktop_before'],'input_after':receipt['input_desktop_after']},
 'source_inferences':{'get_name_on_Windows_branch':'Windows','CLI_display_selector':'windows','intended_current_driver_API_value':'vulkan','intended_current_method_API_value':'forward_plus','original_gate_display_literal':'windows','source_API_oracle_mismatch':True,'complete_main_scene_load_after_gate_line':load_line,'gate_line':gate_line,'load_not_reached_claim_kind':'source-control-flow inference from saved failure branch; not a new execution probe'},
 'unknown':{'which_actual_tuple_fields_differed':'not recorded; do not fill','ordering_or_cause_between_backend_failure_and_lost_window_failure':'not established','Godot_actual_exit_code':'not observed in candidate receipt','GPU_frame_readback_scene_UI_no_flash':'not proven'},
 'root_actual_readback_sha256':sha(root_actual),'new_native_or_engine_calls':0,'no_old_result_reclassification':True
})
mapping=[{'CLI':'--display-driver windows','API':'DisplayServer.get_name()','exact_expected_API_value':'Windows','semantics':'instance display-server name; distinct from lowercase registered CLI selector','source':'platform/windows/display_server_windows.cpp:208-210,8459-8461; DisplayServer.xml:879-884'},
 {'CLI':'--rendering-driver vulkan','API':'RenderingServer.get_current_rendering_driver_name()','exact_expected_API_value':'vulkan','semantics':'forwards OS current selected driver string, which can be updated by engine selection/fallback; neither GPU API version nor stdout label','source':'servers/rendering/rendering_server.cpp:2085-2088;core/os/os.h:150-161;RenderingServer.xml:1635-1642'},
 {'CLI':'--rendering-method forward_plus','API':'RenderingServer.get_current_rendering_method()','exact_expected_API_value':'forward_plus','semantics':'forwards OS current method string; Forward+ is a display label rather than this API literal','source':'servers/rendering/rendering_server.cpp:2090-2093;core/os/os.h:154-161;RenderingServer.xml:1644-1649'}]
write('backend-name-mapping.json',{'commit':COMMIT,'strict_intended_API_tuple':['Windows','vulkan','forward_plus'],'actual_attempt_tuple':None,'mapping':mapping,'comparison_not_to_be_generalized':'No lowercase normalization, alias set,driver expansion or fallback is proposed.'})
write('future-minimal-proposal.json',{'proposed_only':True,'root_decision_required':True,'implementation_or_native_execution_authorized':False,'old_attempt_budget_remaining':0,'steps':['Use a new bounded job with exact source pins and independent review; leave old capture/launcher/product/failures unchanged.','Before the compound predicate or scene load, read all three APIs once into separate raw fields, avoiding short-circuit loss of unqueried values.','Write a uniquely bound raw backend observation before predicate evaluation: job/run/engine/script pins/PID, exact unnormalized API strings, expected canonical strings, per-field comparison, record write/error facts and clearly labelled clock domain. If raw recording fails, fail closed rather than proceed.','Strictly compare exact API canonical Windows/vulkan/forward_plus for this exact engine source, while CLI windows/vulkan/forward_plus stays unchanged. No accepted renderer alternatives, normalization, fallback or production gate change.','Preserve original noninput/birth/stdio/native association/15s/monitor/stop/keeper/final close/source/full main scene/Run disablement. Raw backend match is only a prerequisite, not a render/UI/formal result.','Any future run requires root new explicit budget/authorization/fresh validation and must retain raw startup/tuple/guard/scene-load/frame/native facts independently. Do not infer a tuple,exit code or cross-channel ordering from existing logs.']})
write('read-only-fetch-disposition.json',{'official_GET_only':True,'web_open_wrong_legacy_path':'servers/rendering_server.cpp returned404 and is not source evidence','initial_contents_read':'servers/rendering/rendering_server.cpp initial API GET was IncompleteRead; saved as source_not_pinned in primary-source-pins.json','followup_contents_read':'complete decoded bytes verified to GitHub git blob d2b235f8e34fa23a6bb165afcc05d12d7f5327d8; failure not overwritten','primary_files_pinned_unique':len(by_path),'large_upstream_sources_archived':False,'archived_material':'small focused excerpts and full-file hash/blob/link records only'})
write('result.json',{'schema':1,'work_id':'A-GAME3D-BACKEND-GATE-RESEARCH-20261024-v1','job_id':'child-bfcc2416de5a4593a031a15c0a617385','outcome':'source_only_research_complete; definite_DisplayServer_API_literal_mismatch; actual_tuple_unrecorded','exact_commit':COMMIT,'engine_sha256':inputs['engine_sha256_read_only'],'source_expected_API_tuple':['Windows','vulkan','forward_plus'],'old_actual_API_tuple':None,'old_result':'failed/0PNG/terminal/handlesclosed; unchanged','Godot_exit_code_observed':None,'two_error_causality':'not established','main_scene_load_not_reached':'source inference only','new_engine_Win32_desktop_window_process_probe_tests':0,'product_launcher_capture_policy_index_cache_writes':False,'future_proposal':'Raw all-three tuple before strict canonical comparison; new root bounded job/exactpins/review only; nofallback or renderer expansion','requirements_sha256':inputs['requirements_canonical_sha256'],'H01_H15_full_H12':'preserved/open/unaccepted','G03_R03_all29':'not_run'})
report=f'''# Backend gate source research — exact Godot4.7.2

The old gate contains a definite **source-level API oracle mismatch**: the CLI display selector is `windows`, while this commit's Windows DisplayServer instance returns **`Windows`**. The driver/method API spellings for the intended configuration are `vulkan` and `forward_plus`. Correcting this literal would preserve the intended Windows/Vulkan/Forward+ selection; it would not add another renderer. This job changes no code or result and authorizes no new invocation.

## Exact source and names

Scope is official commit `{COMMIT}`, matching the supplied4.7.2.stable.official.ed1daf0bf identity; existing engine bytes were read-only hashed to `{inputs['engine_sha256_read_only']}` without running version/help or the engine.

| CLI input | API | Intended exact API spelling |
|---|---|---|
| `--display-driver windows` | `DisplayServer.get_name()` | `Windows` |
| `--rendering-driver vulkan` | `RenderingServer.get_current_rendering_driver_name()` | `vulkan` |
| `--rendering-method forward_plus` | `RenderingServer.get_current_rendering_method()` | `forward_plus` |

`DisplayServerWindows::get_name` directly returns `Windows` at lines208–210; registration at8460 uses lowercase `windows` for the CLI factory selector. These are distinct interfaces in the same exact source. [Windows implementation](https://github.com/godotengine/godot/blob/{COMMIT}/platform/windows/display_server_windows.cpp#L208). The same-commit class documentation also lists `Windows` for this API. [DisplayServer.xml](https://github.com/godotengine/godot/blob/{COMMIT}/doc/classes/DisplayServer.xml#L879).

The two RenderingServer getters forward the OS current driver/method strings without converting them. OS stores and returns those selected values. [RenderingServer getters](https://github.com/godotengine/godot/blob/{COMMIT}/servers/rendering/rendering_server.cpp#L2085), [OS storage/getters](https://github.com/godotengine/godot/blob/{COMMIT}/core/os/os.h#L150). The class docs specify `vulkan` among driver identifiers and `forward_plus` among method identifiers, with CLI/project selection and possible engine fallback as sources. This supports strict observed-value checks; CLI arguments alone do not prove final selection. [RenderingServer.xml](https://github.com/godotengine/godot/blob/{COMMIT}/doc/classes/RenderingServer.xml#L1635).

The old capture line45 compares `DisplayServer.get_name()` against lowercase `windows`. A conforming Windows implementation in this source therefore fails that literal comparison. This establishes the gate's source-level mismatch. It does **not** fill the old runtime's missing tuple or establish which actual comparison evaluated false in that observation. The compound predicate may short-circuit; the failure report did not record individual API results.

## Original actual facts, kept separate

Nine original source/attempt inputs were copied read-only and hash-bound; the receipt SHA is `{inputs['files']['attempt-01/receipt.json']['sha256']}` and events SHA `{inputs['files']['attempt-01/events.jsonl']['sha256']}`. Root's actual readback was additionally copied/pinned. No new probe was run.

The raw events contain51 core enumerations,46 admitted samples (sequence5 through50) and46 optional diagnostic items, all unavailable. First admitted native row is HWND1836712/PID12208/TID40996/classEngine with original live HANDLE facts. Sequence51 is successful Enum with no Engine row and the receipt records `successful enumeration lost prior owned Engine association`. Child+creator terminal and owned_handles_closed are true; no Godot exit_code is recorded. PID layers are retained as recorded; no exit code is guessed.

Separately, stdout contains the startup text `Vulkan 1.4.303 - Forward+` and the NVIDIA GeForce RTX4070 Laptop GPU device line. Stderr and capture-report say `actual backend does not equal windows/vulkan/forward_plus`; report status is failed and frames is empty. These logs are not the three API values. Actual API tuple remains **null/unrecorded**. No causal order or explanation linking the backend message and lost-window message is established.

Capture SHA remains6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5. Its line45 gate invokes failure then returns before line48 loads original main.tscn. Thus “complete scene load was not reached” is a **source-control-flow inference from this saved branch**, not an independent runtime scene probe. There are0 PNGs and no scene/UI/no-flash/formal result to accept. The original sole invocation budget is exhausted and the failed result remains failed.

## Primary identity and fetch boundaries

Official source bytes were checked against exact GitHub git-blob SHA1 and SHA256; primary-source-pins.json and primary-followup-pins.json retain paths, sizes, blob links and hashes. Existing pinned Windows/main sources were rehashed against their prior official blob records. Key identities:

- Windows implementation: SHA256 d8acf9b5888dd897daa507505382d5589f5ccc020c8ab91128b1432d738f5de4; blob e8217861662c37e076e033b99bb882ec56c8595f.
- RenderingServer implementation: SHA256 b108f62d9d6113061dd1261e7bef51515fbdba9080b4393245e84cecc67ad7ca; blob d2b235f8e34fa23a6bb165afcc05d12d7f5327d8.
- OS header: SHA256 b0664bf945179714e59907127d7751111153b903dd8b5eb8bdce47e97a7a7ccd; blob fd7b0c896a969ed2a2a59bd78a08f4bf8f1e0938.

A mistaken legacy path returned404 and an initial correct-path contents GET was IncompleteRead. Neither was accepted as source. The bounded follow-up completed and passed blob/hash verification; original failure records remain. Only small relevant excerpts are archived, not large upstream source trees or third-party code archives.

## Minimal future proposal for root only

A new source-pinned, independently reviewed bounded job could read **all three raw API strings once before the predicate**, write the exact tuple plus expected values/per-field results and job/engine/script/PID provenance, and fail closed if recording fails. It should then compare exactly against `Windows`, `vulkan`, `forward_plus`, keeping CLI `windows`, `vulkan`, `forward_plus` unchanged. No lowercase normalization, alias set, fallback or renderer expansion is needed. If a getter is unavailable/fails, retain that missing/error fact rather than fabricate a string. Observation clock domains must be labelled; no native-per-frame timestamp is inferred.

All original noninput desktop/birth/stdio/native association/time/keeper/final-close/full-scene/root Window/Run-disablement obligations remain. Any corrected prerequisite match would still require actual original-scene/GPU/PNG results and root visual review; it would not accept UI interaction or H12. No capture, launcher, product, cache, index, policy or old evidence was changed here. Root legal evidence publication may advance HEAD/index independently; no old execution is transferred to a new head. H01–H15 canonical hash was recomputed `{inputs['requirements_canonical_sha256']}`; fullH12 preserved/open, G03/R03/all29 not_run.
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
excluded={'lease.private.json','artifact-manifest.json','freeze-verification.json','native-complete-request.json','native-complete-response.json'}
files={}
for p in sorted(OUT.rglob('*')):
 if p.is_file() and p.name not in excluded:files[str(p.relative_to(OUT)).replace('\\','/')]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('artifact-manifest.json',{'schema':1,'files':files,'member_count':len(files),'manifest_self_member':False,'excluded':sorted(excluded),'upstream_full_sources_archived':False})
for name,pin in files.items():assert sha(OUT/name)==pin['sha256'] and (OUT/name).stat().st_size==pin['bytes']
write('freeze-verification.json',{'all_members_verified':True,'member_count':len(files),'manifest_sha256':sha(OUT/'artifact-manifest.json'),'report_sha256':sha(OUT/'report.md'),'result_sha256':sha(OUT/'result.json'),'mapping_sha256':sha(OUT/'backend-name-mapping.json'),'new_engine_or_native_calls':0})
print(json.dumps(read(OUT/'freeze-verification.json')))
