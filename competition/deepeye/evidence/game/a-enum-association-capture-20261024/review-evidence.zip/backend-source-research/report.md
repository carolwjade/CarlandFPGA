# Backend gate source research — exact Godot4.7.2

The old gate contains a definite **source-level API oracle mismatch**: the CLI display selector is `windows`, while this commit's Windows DisplayServer instance returns **`Windows`**. The driver/method API spellings for the intended configuration are `vulkan` and `forward_plus`. Correcting this literal would preserve the intended Windows/Vulkan/Forward+ selection; it would not add another renderer. This job changes no code or result and authorizes no new invocation.

## Exact source and names

Scope is official commit `ed1daf0bf001b61586d9930840f2f1394092c079`, matching the supplied4.7.2.stable.official.ed1daf0bf identity; existing engine bytes were read-only hashed to `ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424` without running version/help or the engine.

| CLI input | API | Intended exact API spelling |
|---|---|---|
| `--display-driver windows` | `DisplayServer.get_name()` | `Windows` |
| `--rendering-driver vulkan` | `RenderingServer.get_current_rendering_driver_name()` | `vulkan` |
| `--rendering-method forward_plus` | `RenderingServer.get_current_rendering_method()` | `forward_plus` |

`DisplayServerWindows::get_name` directly returns `Windows` at lines208–210; registration at8460 uses lowercase `windows` for the CLI factory selector. These are distinct interfaces in the same exact source. [Windows implementation](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/platform/windows/display_server_windows.cpp#L208). The same-commit class documentation also lists `Windows` for this API. [DisplayServer.xml](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/doc/classes/DisplayServer.xml#L879).

The two RenderingServer getters forward the OS current driver/method strings without converting them. OS stores and returns those selected values. [RenderingServer getters](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/servers/rendering/rendering_server.cpp#L2085), [OS storage/getters](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/core/os/os.h#L150). The class docs specify `vulkan` among driver identifiers and `forward_plus` among method identifiers, with CLI/project selection and possible engine fallback as sources. This supports strict observed-value checks; CLI arguments alone do not prove final selection. [RenderingServer.xml](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/doc/classes/RenderingServer.xml#L1635).

The old capture line45 compares `DisplayServer.get_name()` against lowercase `windows`. A conforming Windows implementation in this source therefore fails that literal comparison. This establishes the gate's source-level mismatch. It does **not** fill the old runtime's missing tuple or establish which actual comparison evaluated false in that observation. The compound predicate may short-circuit; the failure report did not record individual API results.

## Original actual facts, kept separate

Nine original source/attempt inputs were copied read-only and hash-bound; the receipt SHA is `82fee521dcd31e46eade92a411419b19c0f226b38590d07bc900f3043ce05c92` and events SHA `7b53ea25ce850d0153518984625bd2c87f25b838ed9764f0c18e716a2ca499cb`. Root's actual readback was additionally copied/pinned. No new probe was run.

The raw events contain51 core enumerations,46 admitted samples (sequence5 through50) and46 optional diagnostic items, all unavailable. First admitted native row is HWND1836712/PID12208/TID40996/classEngine with original live HANDLE facts. Sequence51 is successful Enum with no Engine row and the receipt records `successful enumeration lost prior owned Engine association`. Child+creator terminal and owned_handles_closed are true; no Godot exit_code is recorded. PID layers are retained as recorded; no exit code is guessed.

Separately, stdout contains the startup text `Vulkan 1.4.303 - Forward+` and the NVIDIA GeForce RTX4070 Laptop GPU device line. Stderr and capture-report say `actual backend does not equal windows/vulkan/forward_plus`; report status is failed and frames is empty. These logs are not the three API values. Actual API tuple remains **null/unrecorded**. No causal order or explanation linking the backend message and lost-window message is established.

Capture SHA remains6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5. Its line45 gate invokes failure then returns before line48 loads original main.tscn. Thus “complete scene load was not reached” is a **source-control-flow inference from this saved branch**, not an independent runtime scene probe. There are0 PNGs and no scene/UI/no-flash/formal result to accept. The original sole invocation budget is exhausted and the failed result remains failed.

## Primary identity and fetch boundaries

Official source bytes were checked against exact GitHub git-blob SHA1 and SHA256; primary-source-pins.json and primary-followup-pins.json retain paths, sizes, blob links and hashes. Existing pinned Windows/main sources were rehashed against their prior official blob records. Key identities:

- Windows implementation: SHA256 d8acf9b5888dd897daa507505382d5589f5ccc020c8ab91128b1432d738f5de4; blob e8217861662c37e076e033b99bb882ec56c8595f.
- RenderingServer implementation: SHA256 b108f62d9d6113061dd1261e7bef51515fbdba9080b4393245e84cecc67ad7ca; blob d2b235f8e34fa23a6bb165afcc05d12d7f5327d8.
- OS header: SHA256 b0664bf945179714e59907127d7751111153b903dd8b5eb8bdce47e97a7a7ccd; blob fd7b0c896a969ed2a2a59bd78a08f4bf8f1e0938.

A mistaken legacy path returned404 and an initial correct-path contents GET was IncompleteRead. Neither was accepted as source. The bounded follow-up completed and passed blob/hash verification; original failure records remain. Only small relevant excerpts are archived, not large upstream source trees or third-party code archives.

## Minimal future proposal for root only

A new source-pinned, independently reviewed bounded job could read **all three raw API strings once before the predicate**, write the exact tuple plus expected values/per-field results and job/engine/script/PID provenance, and fail closed if recording fails. It should then compare exactly against `Windows`, `vulkan`, `forward_plus`, keeping CLI `windows`, `vulkan`, `forward_plus` unchanged. No lowercase normalization, alias set, fallback or renderer expansion is needed. If a getter is unavailable/fails, retain that missing/error fact rather than fabricate a string. Observation clock domains must be labelled; no native-per-frame timestamp is inferred.

All original noninput desktop/birth/stdio/native association/time/keeper/final-close/full-scene/root Window/Run-disablement obligations remain. Any corrected prerequisite match would still require actual original-scene/GPU/PNG results and root visual review; it would not accept UI interaction or H12. No capture, launcher, product, cache, index, policy or old evidence was changed here. Root legal evidence publication may advance HEAD/index independently; no old execution is transferred to a new head. H01–H15 canonical hash was recomputed `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`; fullH12 preserved/open, G03/R03/all29 not_run.
