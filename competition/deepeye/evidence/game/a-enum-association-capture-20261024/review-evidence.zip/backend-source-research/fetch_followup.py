import base64,hashlib,json,pathlib,re,urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
OLD=ROOT/'.planning/deepeye-resume-20261018/game3d-hidden-entry-research-20261024'
COMMIT='ed1daf0bf001b61586d9930840f2f1394092c079'
records=[]
def excerpt(path,data,patterns,margin=3,after=8):
 lines=data.decode('utf-8').splitlines();ranges=[]
 for i,line in enumerate(lines):
  if any(re.search(p,line) for p in patterns):
   low=max(0,i-margin);high=min(len(lines),i+after)
   if ranges and low<=ranges[-1][1]:ranges[-1][1]=max(ranges[-1][1],high)
   else:ranges.append([low,high])
 name=path.replace('/','__')+'.focused.txt'
 text='\n'.join('--- L%d-L%d ---\n%s'%(lo+1,hi,'\n'.join('%d: %s'%(j+1,lines[j]) for j in range(lo,hi))) for lo,hi in ranges)+'\n'
 (OUT/name).write_text(text,encoding='utf-8');return name,ranges,text
oldpins=json.loads((OLD/'primary-source-pins.json').read_text(encoding='utf-8'))['sources']
blobpins=json.loads((OLD/'upstream-git-blob-verification.json').read_text(encoding='utf-8'))
for path,patterns in [('platform/windows/display_server_windows.cpp',[r'^String DisplayServerWindows::get_name',r'register_create_function\("windows"',r'drivers.push_back\("vulkan"']),('main/main.cpp',[r'display-driver"',r'rendering_driver = N',r'rendering_method = N'])]:
 pin=next(p for p in oldpins if p['upstream_path']==path)
 data=(OLD/pin['file']).read_bytes();digest=hashlib.sha256(data).hexdigest()
 assert digest==pin['sha256'] and len(data)==pin['bytes']
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 expected=next(p for p in blobpins if p['path']==path)
 assert blob==expected['official_git_blob_sha1'] and expected['equal']
 name,ranges,text=excerpt(path,data,patterns)
 record={'path':path,'reused_pinned_source':pin['file'],'prior_primary_manifest_sha256':hashlib.sha256((OLD/'primary-source-pins.json').read_bytes()).hexdigest(),'official_commit':COMMIT,'bytes':len(data),'sha256':digest,'git_blob_sha1':blob,'official_blob_sha1_equal':True,'html_url':'https://github.com/godotengine/godot/blob/'+COMMIT+'/'+path,'excerpt_file':name,'excerpt_ranges':ranges,'full_source_not_archived':True}
 records.append(record);print(json.dumps(record));print(text)
for path in ['servers/rendering/rendering_server.cpp','core/os/os.h','core/os/os.cpp']:
 url='https://api.github.com/repos/godotengine/godot/contents/'+path+'?ref='+COMMIT
 try:
  request=urllib.request.Request(url,headers={'User-Agent':'CarlandFPGA-read-only-source-research','Accept':'application/vnd.github+json'})
  with urllib.request.urlopen(request,timeout=30) as response:raw=response.read();status=response.status
  meta=json.loads(raw);assert meta['encoding']=='base64'
  data=base64.b64decode(meta['content']);blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  assert len(data)==meta['size'] and blob==meta['sha']
  name,ranges,text=excerpt(path,data,[r'get_current_rendering_driver_name',r'get_current_rendering_method',r'set_current_rendering_driver_name',r'set_current_rendering_method'])
  record={'path':path,'api_url':url,'official_commit':COMMIT,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob_sha1':blob,'official_blob_sha1_equal':True,'html_url':meta['html_url'],'blob_url':meta['git_url'],'http_status':status,'excerpt_file':name,'excerpt_ranges':ranges,'full_source_not_archived':True}
  records.append(record);print(json.dumps(record));print(text)
 except Exception as e:
  record={'path':path,'api_url':url,'failure':repr(e),'source_not_pinned':True};records.append(record);print(json.dumps(record))
(OUT/'primary-followup-pins.json').write_text(json.dumps({'commit':COMMIT,'sources':records,'initial_incomplete_download_record_retained':'primary-source-pins.json'},indent=2)+'\n',encoding='utf-8')
