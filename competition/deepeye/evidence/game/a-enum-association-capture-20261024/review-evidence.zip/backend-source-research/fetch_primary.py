"""Official exact-commit read-only GETs; keep small excerpts and full-file hashes only."""
import base64,hashlib,json,pathlib,re,urllib.request,urllib.error
OUT=pathlib.Path(__file__).resolve().parent
COMMIT='ed1daf0bf001b61586d9930840f2f1394092c079'
PATHS=['platform/windows/display_server_windows.h','servers/rendering/rendering_server.cpp','servers/rendering/rendering_server.h','servers/rendering/rendering_server_default.cpp','doc/classes/RenderingServer.xml','doc/classes/DisplayServer.xml']
records=[]
for path in PATHS:
 url='https://api.github.com/repos/godotengine/godot/contents/'+path+'?ref='+COMMIT
 try:
  request=urllib.request.Request(url,headers={'User-Agent':'CarlandFPGA-read-only-source-research','Accept':'application/vnd.github+json'})
  with urllib.request.urlopen(request,timeout=30) as response:
   raw=response.read();http_status=response.status
  metadata=json.loads(raw)
  assert metadata['encoding']=='base64' and metadata['type']=='file'
  data=base64.b64decode(metadata['content'])
  blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  assert blob==metadata['sha'] and len(data)==metadata['size']
  text=data.decode('utf-8');lines=text.splitlines()
  hits=[i for i,line in enumerate(lines) if re.search(r'get_current_rendering_(driver_name|method)|get_name\(.*override|method name="get_name"',line)]
  ranges=[]
  for i in hits:
   lo=max(0,i-3);hi=min(len(lines),i+8)
   if ranges and lo<=ranges[-1][1]:ranges[-1][1]=max(ranges[-1][1],hi)
   else:ranges.append([lo,hi])
  excerpt='\n'.join('--- L%d-L%d ---\n%s'%(lo+1,hi,'\n'.join('%d: %s'%(j+1,lines[j]) for j in range(lo,hi))) for lo,hi in ranges)+'\n'
  name=path.replace('/','__')+'.excerpt.txt'
  (OUT/name).write_text(excerpt,encoding='utf-8')
  record={'path':path,'official_commit':COMMIT,'api_url':url,'blob_url':metadata['git_url'],'html_url':metadata['html_url'],'raw_url':metadata['download_url'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob_sha1':blob,'official_blob_sha1_equal':True,'http_status':http_status,'excerpt_file':name,'excerpt_lines':ranges,'full_source_not_archived':True}
  records.append(record)
  print(json.dumps(record));print(excerpt)
 except Exception as error:
  records.append({'path':path,'api_url':url,'failure':repr(error),'source_not_pinned':True})
  print(json.dumps(records[-1]))
(OUT/'primary-source-pins.json').write_text(json.dumps({'commit':COMMIT,'sources':records,'method':'Official GitHub contents GET; decoded bytes checked against returned git blob SHA1; only small relevant excerpts archived'},indent=2)+'\n',encoding='utf-8')
