import hashlib,json,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'.planning/deepeye-resume-20261018/game3d-enum-association-capture-20261024'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
copy=OUT/'actual-inputs';copy.mkdir(exist_ok=False)
names=['capture.gd','launcher_v2.py','execution-plan-v2.json','source-pins-v2.json','attempt-01/receipt.json','attempt-01/events.jsonl','attempt-01/engine.stdout.bin','attempt-01/engine.stderr.bin','attempt-01/frames/capture-report.json']
pins={}
for name in names:
 source=AUTHOR/name;before=sha(source);target=copy/name;target.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(source,target)
 assert before==sha(source)==sha(target)
 pins[name]={'bytes':source.stat().st_size,'sha256':before}
assert pins['capture.gd']['sha256']=='6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5'
scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
req=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert req=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=json.loads((ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json').read_text(encoding='utf-8'))
assert transfer['status']=='active' and transfer['director_generation']==3
engine=pathlib.Path(json.loads((copy/'execution-plan-v2.json').read_text(encoding='utf-8'))['engine'])
engine_hash=sha(engine)
assert engine_hash=='ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424'
(OUT/'actual-input-pins.json').write_text(json.dumps({'files':pins,'requirements_canonical_sha256':req,'transfer_sha256':sha(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json'),'immutable_md_sha256':sha(ROOT/'docs/competition/deepeye-2026/immutable_scope.md'),'immutable_json_sha256':sha(ROOT/'docs/competition/deepeye-2026/immutable_scope.json'),'engine_sha256_read_only':engine_hash,'engine_invocations':0,'no_product_or_index_writes':True},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'files':len(pins),'receipt':pins['attempt-01/receipt.json'],'events':pins['attempt-01/events.jsonl'],'requirements_sha256':req,'engine_file_hash':engine_hash}))
