"""New wrapper failure-path controls with fake Popen; zero native/engine calls."""
from pathlib import Path
import hashlib, importlib.util, json, shutil, subprocess, tempfile

P = Path(__file__).resolve().parent
source = P / 'run_enum_association_capture_once.py'
sha = lambda b: hashlib.sha256(b).hexdigest()
spec = importlib.util.spec_from_file_location('new_wrapper_control_only', source)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)  # guarded main; imports stdlib only
assert m.JOB == 'child-ff673689f0da408998a3a64ed82abd10'
checks = []
real_popen = subprocess.Popen
try:
    for ordinal, (receipt_error, first_wait_interrupt, exit_code) in enumerate([
            (True, True, 0), (False, False, 2)], 1):
        with tempfile.TemporaryDirectory(prefix='enum-wrapper-control-', dir=P) as tmp:
            base = Path(tmp)
            evidence = base / '.planning/deepeye-resume-20261018/game3d-enum-association-capture-20261024'
            evidence.mkdir(parents=True)
            candidate = evidence / 'candidate.py'
            candidate.write_text('raise AssertionError("fixture must never execute")\n', encoding='utf-8')
            wrapper_rel = '.planning/deepeye-resume-20261018/gen3-live-integration-20261024/run_enum_association_capture_once.py'
            wrapper_copy = base / wrapper_rel
            wrapper_copy.parent.mkdir(parents=True)
            shutil.copyfile(source, wrapper_copy)
            candidate_rel = candidate.relative_to(base).as_posix()
            config = dict(job_id=m.JOB, actual_Godot_create_budget=1,
                independent_static_review_accepted=True, fresh_native_validate_execution_allowed=True,
                execution_authorized=True, no_replay_or_fallback=True,
                candidate=candidate_rel, attempt_directory=candidate_rel + '.never-created',
                exact_source_sha256={candidate_rel: sha(candidate.read_bytes()), wrapper_rel: sha(source.read_bytes())})
            (base / 'enum-association-capture-phase2-authorization.json').write_text(json.dumps(config), encoding='utf-8')
            calls = dict(popen=0, wait=0, original_owner_retained=True)
            class FakePopen:
                def __init__(self, argv, **kwargs):
                    calls['popen'] += 1
                    assert kwargs['creationflags'] == 0x08000000
                    assert argv[-3:] == ['--execute-reviewed', '--attempt', '1']
                    self.out, self.err = kwargs['stdout'], kwargs['stderr']
                    self.pid = 10000 + ordinal
                def wait(self):
                    calls['wait'] += 1
                    assert not self.out.closed and not self.err.closed
                    if first_wait_interrupt and calls['wait'] == 1:
                        raise KeyboardInterrupt('injected; fake process remains owned/live')
                    return exit_code
            def controlled_write(suffix, data):
                if receipt_error and suffix == 'child':
                    raise OSError('injected child-receipt write failure after fake Popen')
                real_write(suffix, data)
            m.P, m.R = base, base
            real_write = m.write_once
            m.write_once = controlled_write
            subprocess.Popen = FakePopen
            try:
                result = m.main()
            finally:
                m.write_once = real_write
            record = json.loads((base / (m.PREFIX + '-exit.json')).read_bytes())
            assert calls['popen'] == 1
            assert calls['wait'] == (2 if first_wait_interrupt else 1)
            assert record['original_Popen_wait_terminal'] is True
            assert record['actual_launcher_Python_exit'] == exit_code
            assert result == (0 if exit_code == 0 else 1)
            assert len(record['persistence_or_wait_errors_before_terminal']) == (2 if receipt_error else 0)
            # The exclusive started marker must reject replay before another fake Popen.
            try:
                m.main()
            except FileExistsError:
                pass
            else:
                raise AssertionError('exclusive wrapper start allowed replay')
            assert calls['popen'] == 1
            checks.append(dict(case=ordinal, **calls, Python_exit=exit_code, replay_rejected=True))
finally:
    subprocess.Popen = real_popen
report = dict(kind='new_root_wrapper_controls_only', native_process_engine_calls=0,
              wrapper_sha256=sha(source.read_bytes()), checks=checks,
              outcome='pass; fake Popen only, no candidate execution or native acceptance')
with (P / 'enum-wrapper-owner-controls.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(report, f, indent=2)
print(json.dumps(report, indent=2))
