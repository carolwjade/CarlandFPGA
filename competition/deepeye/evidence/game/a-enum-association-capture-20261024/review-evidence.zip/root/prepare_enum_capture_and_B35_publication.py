"""Root terminal readback, immutable archive and evidence-only canonical copy."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile

P = Path(__file__).resolve().parent
O, R = P.parent, P.parents[2]
A = O / 'game3d-enum-association-capture-20261024'
V = O / 'game3d-enum-association-review-20261024'
C = O / 'game3d-backend-gate-research-20261024'
W = R / '.local/deepeye-implementation-a'
read = lambda p: json.loads(p.read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()
def save(path, data):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')
def verify(path, row):
    raw = path.read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes'], str(path)
    return raw

terminal = read(P / 'enum-capture-and-backend-terminal-readback.json')
jobs = json.loads(terminal['result']['content'][0]['text'])
assert len(jobs) == 2 and all(x['status'] == 'completed' and x['terminal'] and x['stale'] is False for x in jobs)
assert sha((A / 'final-manifest.json').read_bytes()) == '98eacd75ad0cecb12895cb4fe76849cdcba789b4a8f30f5a4acb212f342f46d2'
am = read(A / 'final-manifest.json')
assert len(am['members']) == 155
for row in am['members']:
    verify(A / row['path'], row)
for folder, expected, count in [
        (V, '03be4c1f62dc4b7c196077810040c4fb93c58b3e62e387d9b04ce8daefaf79c3', 46),
        (C, '39409634bf985521b21764cb6bc5e8f60f032d61353a13a5020921f897b78d8e', 34)]:
    assert sha((folder / 'artifact-manifest.json').read_bytes()) == expected
    m = read(folder / 'artifact-manifest.json')
    assert len(m['files']) == count
    for name, row in m['files'].items():
        verify(folder / name, row)
baseline = read(A / 'source-baseline.json')
assert sha(Path(baseline['git_index']['path']).read_bytes()) == baseline['git_index']['sha256']
for name, expected in baseline['C4'].items():
    assert sha((W / name).read_bytes()) == expected
for row in baseline['files']:
    verify(W / row['path'], row)
    verify(Path(baseline['snapshot']) / row['path'], row)
actual = read(P / 'enum-capture-root-actual-readback.json')
assert actual['frame_count'] == 0 and actual['core_observations'] == 51 and actual['admitted_sample_count'] == 46
assert actual['actual_three_backend_API_tuple'] is None
decision = {
    'schema': 1, 'utc': datetime.now(timezone.utc).isoformat(),
    'actual_source_product_head': 'e08310afbb8624be356473b02634764990ac00f0',
    'outcome': 'one_actual_Godot_create_failed_closed;zeroPNG;main_scene_load_not_reached',
    'native_association': '51 core observations,46 admitted seq5-50, first HWND1836712/PID12208/TID40996/classEngine/original liveHANDLE',
    'native_association_limit': 'sampled only; global start not independently persisted; no new independent15s/per-frame/atomic/no-flash measurement',
    'last_sequence51': 'successful Enum no Engine; original loss gate failed',
    'startup_log': 'Vulkan1.4.303/Forward+/RTX4070 Laptop; startup report only, not scene/frame proof',
    'actual_backend_API_tuple_and_failed_field': None,
    'source_oracle_mismatch': 'exact official Godot commit API Windows differs from CLI windows; original lowercase literal rejects a compliant Windows implementation',
    'intended_strict_future_API_tuple': ['Windows', 'vulkan', 'forward_plus'],
    'research_scope': '34 source-only members rehashed, no new engine/native/probe calls; source inference does not repair missing actualtuple',
    'failure_order_causality_Godot_exit': 'unobserved/not established',
    'PID_layers': 'original Popen executable41992/exit2; native core owner26500 independently unqueried; do not merge identities',
    'child_creator_terminal_owned_handles_closed': True, 'keeper_or_tool_session': False,
    'runtime_cache': '69 isolated appdata cache files preserved/hash-inventoried in place, payload excluded; original product cache unchanged',
    'original_F05_and_v1_v2_raw_failures': 'preserved; exactv2 source fix independently reviewed',
    'root_verified_members': {'author': 155, 'independent_static': 46, 'backend_research': 34},
    'old71958': 'failed/two creates/0PNG/exhausted unchanged', 'current_ff6736_budget_remaining': 0,
    'next': 'new separately bounded reviewed source correction may be considered; no execution authority is conferred by this publication',
    'H01_H15_full_H12': 'preserved/open', 'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run'}
save(P / 'enum-capture-final-root-decision.json', decision)

tokens = []
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key == 'lease_token' and isinstance(item, str) and item:
                tokens.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)
    elif isinstance(value, str) and value.lstrip().startswith(('{', '[')):
        try:
            collect(json.loads(value))
        except ValueError:
            pass
for path in O.glob('*/lease.private.json'):
    collect(read(path))
tokens = list(set(tokens))
assert len(tokens) >= 9
members = {}
def add(name, path):
    assert name not in members and '\\' not in name and not name.startswith('/') and '..' not in name.split('/')
    raw = path.read_bytes()
    assert not any(token in raw for token in tokens), name
    members[name] = raw
include = read(A / 'final-archive-include.json')
assert len(include['member_paths']) == len(set(include['member_paths'])) == 155
assert sha((A / 'final-archive-include.json').read_bytes()) == 'd8c5b702d3ef0f630fe7920a78285a425f176c591a9a16e337652990f2307dda'
assert set(include['member_paths']) == {row['path'] for row in am['members']}
for name in include['member_paths']:
    add('author/' + name, A / name)
for name in ['final-manifest.json', 'final-archive-include.json', 'native-complete-response.json']:
    add('author/' + name, A / name)
for prefix, folder in [('independent-static', V), ('backend-source-research', C)]:
    for name in read(folder / 'artifact-manifest.json')['files']:
        add(prefix + '/' + name, folder / name)
    add(prefix + '/artifact-manifest.json', folder / 'artifact-manifest.json')
for name in ['enum-capture-final-root-decision.json', 'enum-capture-and-backend-terminal-readback.json',
             'enum-capture-root-actual-readback.json', 'summarize_enum_capture_actual.py',
             'prepare_enum_capture_and_B35_publication.py', 'enum-wrapper-owner-controls.json',
             'check_enum_wrapper_owner.py']:
    add('root/' + name, P / name)
stage = P / 'staged-enum-association-capture'
stage.mkdir(exist_ok=False)
archive = stage / 'review-evidence.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(members.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.infolist()) == len(members)
    assert all(z.read(name) == raw for name, raw in members.items())
save(stage / 'manifest.json', {'schema': 1, 'archive_sha256': sha(archive.read_bytes()), 'member_count': len(members),
    'members': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())}})
save(stage / 'decision.json', decision)
with (stage / 'README.md').open('x', encoding='utf-8', newline='\n') as f:
    f.write('One actual Godot create produced51 native core observations and46 sampled Engine associations, then failed closed with zeroPNG. '
            'The unchanged adapter backend predicate failed before original main.tscn load; the last successful Enum lost Engine. '
            'Startup Vulkan/Forward+/RTX4070 text is not scene proof. Actual backend API tuple, failed field, Godot exit and cross-stream causality remain unknown. '
            'Separate exact-commit source research proves API Windows versus CLI windows spelling mismatch; no old result is repaired. '
            'Original Popen PID41992/exit2 and native core owner26500 are distinct recorded layers. Child/creator terminal and owned handles closed; no keeper/tool session. '
            'All original failures, F05 correction, raw data/static/research limits are retained. Both old71958 and this job are exhausted; no further execution is authorized here. '
            'H01-H15/fullH12 preserved/open; no scene/UI/continuous no-flash/formal acceptance; G03/R03/all29 not_run.\n')
packages = {
    'enum-capture': {'target': 'competition/deepeye/evidence/game/a-enum-association-capture-20261024',
        'member_count': len(members), 'archive_sha256': sha(archive.read_bytes()),
        'files': {p.name: sha(p.read_bytes()) for p in sorted(stage.iterdir())}},
    'B35-37': read(P / 'b-op35-37-readiness-archive-preparation-result.json')}
files = {}
for short, pkg in packages.items():
    src = stage if short == 'enum-capture' else P / 'staged-b-op35-37-readiness'
    dst = W / pkg['target']
    assert not dst.exists() and len(pkg['files']) == 4
    for name, expected in pkg['files'].items():
        assert sha((src / name).read_bytes()) == expected
    with zipfile.ZipFile(src / 'review-evidence.zip') as z:
        manifest = read(src / 'manifest.json')
        assert z.testzip() is None and len(z.infolist()) == pkg['member_count']
        assert all(len(z.read(n)) == row['bytes'] and sha(z.read(n)) == row['sha256']
                   for n, row in manifest['members'].items())
    dst.mkdir(parents=True, exist_ok=False)
    for name, expected in pkg['files'].items():
        shutil.copyfile(src / name, dst / name)
        assert sha((dst / name).read_bytes()) == expected
        files[pkg['target'] + '/' + name] = expected
save(P / 'enum-capture-and-b35-37-publication.json', {
    'expected_head': 'e08310afbb8624be356473b02634764990ac00f0',
    'message': 'docs(deepeye): preserve native association failure and B35-37 readiness evidence', 'files': files})
save(P / 'enum-capture-and-b35-37-preparation-result.json', {'packages': packages,
    'canonical_files': len(files), 'source_changes': 0, 'target_engine_native_calls': 0, 'lease_tokens_scanned': len(tokens)})
print(json.dumps({'canonical_files': len(files), 'source_changes': 0,
    'packages': {k: {'members': v['member_count'], 'sha256': v['archive_sha256']} for k, v in packages.items()}}, indent=2))
