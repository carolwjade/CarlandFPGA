"""Interpret preserved raw files only; no extra native/backend probe or attempt."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, json

P = Path(__file__).resolve().parent
A = P.parent / 'game3d-enum-association-capture-20261024'
T = A / 'attempt-01'
read = lambda p: json.loads(p.read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()
receipt = read(T / 'receipt.json')
events = [json.loads(line) for line in (T / 'events.jsonl').read_bytes().splitlines()]
cores = [row for row in events if row['event'] == 'enum_association_core']
samples = [row for row in events if row['event'] == 'native_association_sample']
diagnostics = [item for row in events if row['event'] == 'optional_thread_desktop_diagnostics' for item in row['diagnostics']]
assert len(cores) == 51 and receipt['child_terminal'] and receipt['creator_terminal'] and receipt['owned_handles_closed']
assert receipt['first_native_association_sample']['sequence'] == 5
assert receipt['last_native_association_sample']['sequence'] == 50
assert cores[-1]['raw_bool'] == 1 and not any(row['class_query']['text'] == 'Engine' for row in cores[-1]['rows'])
reports = list(T.rglob('capture-report.json'))
assert len(reports) == 1
report = read(reports[0])
assert report['status'] == 'failed' and report['reason'] == 'actual backend does not equal windows/vulkan/forward_plus'
assert report['frames'] == []
assert not list(T.rglob('*.png'))
wrapper = read(P / 'enum-association-capture-wrapper-exit.json')
out = (T / 'engine.stdout.bin').read_bytes()
err = (T / 'engine.stderr.bin').read_bytes()
result = {
    'utc': datetime.now(timezone.utc).isoformat(), 'job_id': 'child-ff673689f0da408998a3a64ed82abd10',
    'outcome': 'one_actual_Godot_create_failed_zeroPNG; collection must close without retry',
    'actual_Godot_pid_tid': [receipt['pid'], receipt['tid']],
    'original_Popen_executable_pid_exit': [wrapper['pid'], wrapper['actual_launcher_Python_exit']],
    'native_core_recorded_owner_pid': cores[0]['owner_pid'],
    'PID_layer_limit': 'recorded Popen executable PID and native core owner PID differ; do not merge identities or invent cause',
    'Godot_exit_code': None, 'tool_shared_shell_exit': 1,
    'first_native_association': receipt['first_native_association_sample'],
    'core_observations': len(cores), 'admitted_sample_count': sum(x['admitted'] is True for x in samples),
    'last_successful_sample_sequence': 50, 'final_core_sequence': 51,
    'final_core': 'native Enum TRUE/error0 and live original hProcess but no Engine row; original gate rejected',
    'optional_diagnostic_status_counts': dict(Counter(x['status'] for x in diagnostics)),
    'launcher_failure': receipt['failure'], 'adapter_failure': report['reason'],
    'failure_order_or_causality': 'not independently established by a common raw timestamp/exit observation',
    'stdout_reported_startup': out.decode('utf-8', errors='strict'),
    'actual_three_backend_API_tuple': None,
    'main_scene_load': 'not reached in reviewed capture.gd control flow after this adapter failure',
    'frame_count': 0, 'native_frame_timestamps': None,
    'input_desktop_before': receipt['input_desktop_before'],
    'input_desktop_during_sample_count': len(receipt['input_desktop_observations']),
    'input_desktop_during_values': sorted(set(receipt['input_desktop_observations'])),
    'input_desktop_after': receipt['input_desktop_after'],
    'continuous_no_flash_or_nonoccupation_proven': False,
    'child_creator_terminal_and_owned_handles_closed': True, 'keeper_or_session': False,
    'budget_remaining': 0, 'no_new_source_or_target_probe_authorized': True,
    'raw_sha256': {str(path.relative_to(A)).replace('\\', '/'): sha(path.read_bytes()) for path in
                   [T / 'receipt.json', T / 'events.jsonl', T / 'engine.stdout.bin', T / 'engine.stderr.bin', reports[0]]},
    'H01_H15_full_H12': 'preserved/open', 'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run'}
with (P / 'enum-capture-root-actual-readback.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({k: result[k] for k in ['outcome', 'actual_Godot_pid_tid', 'core_observations',
    'admitted_sample_count', 'optional_diagnostic_status_counts', 'frame_count', 'budget_remaining']}, indent=2))
