"""Root's explicit one-time phase2 decision after actual static and lease readback."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

P = Path(__file__).resolve().parent
R = P.parents[2]
A = P.parent / 'game3d-enum-association-capture-20261024'
V = P.parent / 'game3d-enum-association-review-20261024'
read = lambda p: json.loads(p.read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()
gate = read(P / 'enum-static-terminal-and-author-validation.json')
review = json.loads(gate['independent_static_terminal']['content'][0]['text'])[0]
fresh = json.loads(gate['fresh_author_validation']['content'][0]['text'])
assert review['job_id'] == 'child-f10d8e28d3734bb28f9b8f474421c089'
assert review['status'] == 'completed' and review['terminal'] and review['stale'] is False
assert fresh['job_id'] == 'child-ff673689f0da408998a3a64ed82abd10'
assert fresh['native_agent_id'] == '/root/pc_direct_window' and fresh['execution_allowed'] is True
assert read(V / 'result.json')['outcome'] == 'exact_v2_static_review_complete;F05_resolved;no_additional_static_blocker'
assert read(P / 'enum-capture-v2-root-preflight.json')['engine_bytes_verified'] is True
baseline = read(A / 'source-baseline.json')
exact = {}
def add(path, expected):
    path = path.resolve()
    name = path.relative_to(R.resolve()).as_posix()
    assert sha(path.read_bytes()) == expected, name
    assert name not in exact
    exact[name] = expected
for row in baseline['files']:
    for base in [Path(baseline['product']), Path(baseline['snapshot'])]:
        add(base / row['path'], row['sha256'])
for name, expected in baseline['C4'].items():
    add(Path(baseline['product']) / name, expected)
for name, expected in read(V / 'result.json')['exactpins'].items():
    if name == 'run_enum_association_capture_once.py':
        add(P / name, expected)
    elif name == 'original37_manifest':
        add(A / 'frozen-manifest.json', expected)
    elif name == 'journal_delta27_manifest':
        add(A / 'journal-v2-frozen-manifest.json', expected)
    else:
        add(A / name, expected)
for name, expected in [('artifact-manifest.json', '03be4c1f62dc4b7c196077810040c4fb93c58b3e62e387d9b04ce8daefaf79c3'),
                       ('report.md', 'ed8c243bc52b42db430c62b82491a0602a4cae15f6e2eda9e87d46f621ecc203')]:
    add(V / name, expected)
plan = read(A / 'execution-plan-v2.json')
add(Path(plan['engine']), plan['engine_sha256'])
for name in ['enum-capture-v2-root-preflight.json', 'enum-static-terminal-and-author-validation.json',
             'enum-association-capture-root-design-decision.json']:
    add(P / name, sha((P / name).read_bytes()))
assert not (A / 'attempt-01').exists()
assert not (P / 'enum-association-capture-wrapper-started.json').exists()
decision = {
    'schema': 1, 'utc': datetime.now(timezone.utc).isoformat(),
    'director': '01a16988-bdcb-70e1-ae10-1304b5cf7875', 'generation': 3,
    'job_id': fresh['job_id'], 'actual_Godot_create_budget': 1,
    'candidate': (A / 'launcher_v2.py').relative_to(R).as_posix(),
    'attempt_directory': (A / 'attempt-01').relative_to(R).as_posix(),
    'independent_static_review_accepted': True, 'fresh_native_validate_execution_allowed': True,
    'execution_authorized': True, 'no_replay_or_fallback': True,
    'exact_source_sha256': exact,
    'reason': 'One new full-original-scene diagnostic using the explicit enum callback association method after independent F05 resolution; original71958 remains failed and exhausted',
    'constraints': 'Original owned noninput desktop/birth/monitor/HANDLE/keeper/stop/terminal fences and unchanged full scene/backend; no switch, foreground, board, service, policy or product edits',
    'unknown_owner': 'retain original Popen/native owner and live exec session; do not timeout-kill, replay or adopt by PID',
    'limits': 'Sampled native association and actual PNG only if observed; no per-frame atomic/no-flash/UI/physics/H12/formal acceptance',
    'H01_H15_full_H12': 'preserved', 'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run'}
with (P / 'enum-association-capture-phase2-authorization.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(decision, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({'authorized': True, 'job_id': fresh['job_id'], 'maximum_actual_Godot_creates': 1,
                  'exact_byte_pins': len(exact), 'actual_calls_so_far': 0}))
