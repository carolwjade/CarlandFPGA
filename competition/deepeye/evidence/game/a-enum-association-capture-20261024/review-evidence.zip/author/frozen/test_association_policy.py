"""New-method synthetic controls only; no Win32(), processes, or real clock use.

Catches accepting a NULL/substituted desktop, incomplete/foreign-only identity,
dead original process, FALSE/0 rows, unpersisted core, changed HWND identity,
late first proof, or invented/conflicting optional diagnostic metadata.
"""
import copy
import importlib.util
from pathlib import Path
import sys
import unittest

target = Path(sys.argv.pop(1)) if len(sys.argv) > 1 else Path(__file__).with_name("launcher.py")
spec = importlib.util.spec_from_file_location("association_candidate", target)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def fixture():
    reference = dict(job_id="synthetic-job", run_id="synthetic-run", desktop_handle=101,
                     desktop_name="PrivateSynthetic", station_name="WinSta0",
                     process_handle=202, pid=44, initial_tid=45,
                     desktop_creation_event="desktop_created_creator_terminal")
    row = dict(ordinal=1, hwnd=303, thread_query=dict(tid_return=46, pid_output=44,
               fresh_error=0), class_query=dict(return_count=6, text="Engine",
               fresh_error=0, buffer_capacity=256), exception=None)
    core = dict(sequence=1, reference=copy.deepcopy(reference), desktop_handle=101,
                desktop_name="PrivateSynthetic", station_name="WinSta0",
                sampled_input_desktop="Default", process_live_before=True,
                process_live_after=True, raw_bool=1, fresh_last_error=0,
                callback_count=1, rows=[row], exception=None)
    return reference, core


class NewAssociationControls(unittest.TestCase):
    def classify(self, core, reference, durable=1, seen=None):
        self.assertTrue(callable(getattr(module, "association_rows", None)),
                        "new enum callback association method is absent")
        return module.association_rows(core, reference, durable, {} if seen is None else seen)

    def test_valid_core_and_foreign_rows_are_distinct(self):
        reference, core = fixture()
        foreign = copy.deepcopy(core["rows"][0]); foreign.update(ordinal=2, hwnd=304)
        foreign["thread_query"]["pid_output"] = 55
        core["rows"].append(foreign); core["callback_count"] = 2
        rows = self.classify(core, reference)
        self.assertEqual([r["hwnd"] for r in rows], [303])
        self.assertEqual(len(core["rows"]), 2)
        core["rows"] = [foreign]; core["callback_count"] = 1
        foreign["ordinal"] = 1
        self.assertEqual(self.classify(core, reference), [])
        foreign["thread_query"]["pid_output"] = reference["pid"]
        foreign["class_query"]["text"] = "Helper"
        self.assertEqual(self.classify(core, reference), [])

    def test_null_substitution_partial_core_and_dead_handle_reject(self):
        for mutation in ("null", "name", "reference", "tid", "pid", "class", "partial", "exception", "dead", "enum_missing"):
            with self.subTest(mutation=mutation):
                reference, core = fixture()
                if mutation == "null": core["desktop_handle"] = 0
                if mutation == "name": core["desktop_name"] = "Default"
                if mutation == "reference": core["reference"]["process_handle"] = 999
                if mutation == "tid": core["rows"][0]["thread_query"]["tid_return"] = 0
                if mutation == "pid": core["rows"][0]["thread_query"]["pid_output"] = 0
                if mutation == "class": core["rows"][0]["class_query"]["return_count"] = 0
                if mutation == "partial": core["rows"][0]["class_query"] = None
                if mutation == "exception": core["rows"][0]["exception"] = "synthetic partial failure"
                if mutation == "dead": core["process_live_after"] = False
                if mutation == "enum_missing": core["raw_bool"] = None
                with self.assertRaises(module.CaptureBlocked): self.classify(core, reference)

    def test_false_zero_is_pending_not_rows_and_errors_fail(self):
        reference, core = fixture(); core["raw_bool"] = 0
        self.assertIsNone(self.classify(core, reference))
        self.assertEqual(len(core["rows"]), 1)
        core["fresh_last_error"] = 5
        with self.assertRaises(OSError): self.classify(core, reference)
        core["raw_bool"] = 1; core["fresh_last_error"] = 122
        self.assertEqual(len(self.classify(core, reference)), 1)

    def test_persistence_first_deadline_and_identity_instability(self):
        reference, core = fixture()
        with self.assertRaises(module.CaptureBlocked): self.classify(core, reference, durable=0)
        seen = {}; rows = self.classify(core, reference, seen=seen)
        self.assertTrue(module.first_window_admissible(rows, 100, 114.999))
        with self.assertRaises(module.CaptureBlocked): module.first_window_admissible(rows, 100, 115)
        core["sequence"] = 2; core["rows"][0]["thread_query"]["tid_return"] = 99
        with self.assertRaises(module.CaptureBlocked): self.classify(core, reference, durable=2, seen=seen)

    def test_optional_diagnostic_missing_is_unknown_conflict_rejects(self):
        self.assertTrue(callable(getattr(module, "require_no_diagnostic_conflict", None)),
                        "new separable diagnostic method is absent")
        raw = [dict(status="unavailable", observed_name=None, thread_handle=0, fresh_error=5)]
        module.require_no_diagnostic_conflict(raw, "PrivateSynthetic")
        self.assertIsNone(raw[0]["observed_name"])
        module.require_no_diagnostic_conflict([dict(status="available", observed_name="privatesynthetic")], "PrivateSynthetic")
        with self.assertRaises(module.CaptureBlocked):
            module.require_no_diagnostic_conflict([dict(status="available", observed_name="Default")], "PrivateSynthetic")


if __name__ == "__main__":
    unittest.main(verbosity=2)
