# Enum callback association implementation plan

Approved root design: `inputs/root-decision.json`; all P01–P11 in `inputs/design.json` apply. Inline implementation only, in this owned evidence directory and its fresh source snapshot. No product edits, commits, old-test runs or target native calls.

- [x] Revalidate the new lease, verify current Gen3/H01–H15 canonical hash, pin old v3/capture/029d and current 52 sources, prepare the exclusive snapshot.
- [x] Write only new-method synthetic counterexamples in `test_association_policy.py`; run them against the immutable v3 input for RED. No Win32 object may be constructed during import.
- [x] Derive `launcher.py` with new job/run/paths and one future invocation. Capture raw callback rows before lookups; save native returns/errors and original HANDLE liveness. Persist each sequenced core observation before optional diagnostics. Classify via `association_rows(core, reference, durable_sequence, seen)`; use `require_no_diagnostic_conflict(diagnostics, expected)` after raw diagnostics are persisted. Keep original first-window deadline, keeper and terminal/close functions.
- [x] GREEN only the new pure controls; AST-check native-call recording/persistence order, unchanged lifecycle functions and the main guard. Pin exact engine/argv/plan and unchanged `capture.gd`; declare native/frame observations non-atomic and frame timestamps unavailable in the immutable adapter.
- [x] Rehash 52×2/C4/index/cache, all old71958 bytes and 029d sources. Write report/result/source pins/full diff, freeze and verify every member. Stop for independent root review, leaving the new job active and all target native/engine counters zero.
