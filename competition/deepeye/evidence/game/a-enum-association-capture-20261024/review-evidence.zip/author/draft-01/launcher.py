"""Private reviewed capture launcher. Import/plan never loads Win32 or an engine.

Execution requires an explicit later root authorization plus --execute-reviewed.
Suspended absence is pending, never verified; post-Resume owned HWND must verify.
Only this new evidence/snapshot pair may be written. No fallback or replay.
"""
import argparse
import ctypes as C
from ctypes import wintypes as W
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time

WORK_ID = "A-GAME3D-ENUM-ASSOCIATION-CAPTURE-20261024-v1"
JOB_ID = "child-ff673689f0da408998a3a64ed82abd10"
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
SPACE = ROOT / ".local/deepeye-game3d-enum-association-capture-20261024"
PLAN = OUT / "execution-plan.json"
ASSOCIATION_METHOD = "enum_desktop_windows_callback_v1"
CONTRACT = "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"


class CaptureBlocked(RuntimeError):
    pass


def require_private_binding(observed, expected):
    if not observed or observed.casefold() != expected.casefold():
        raise CaptureBlocked("suspended_thread_desktop_unbound_or_foreign: %r" % observed)


def suspended_observation(observed, expected, error):
    if observed is None:
        return dict(status="pending", observed=None, error=error,
                    resume_basis="reviewed lpDesktop plus non-inherited desktop and stdio-only allowlist")
    require_private_binding(observed, expected)
    return dict(status="verified", observed=observed, error=error)


def require_same_input(before, current):
    if not before or current != before:
        raise CaptureBlocked("input_desktop_changed_or_unreadable: %r -> %r" % (before, current))


def cleanup_decision(*, child_terminal, creator_terminal):
    return "close_owned" if child_terminal and creator_terminal else "retain"


def keeper_required(child_terminal, creator_terminal):
    return child_terminal is not True or creator_terminal is not True


def keeper_transition(state, child_observation, creator_observation):
    """Pure lifecycle gate: positive terminal facts latch; unknown never releases."""
    if state.get("keeper_entry_durable") is not True:
        raise CaptureBlocked("keeper entry must be durable before observing/releasing")
    if child_observation is True:
        state["child_terminal"] = True
    if creator_observation is True:
        state["creator_terminal"] = True
    return "wait_owned" if keeper_required(state["child_terminal"], state["creator_terminal"]) else "cleanup_eligible"


def first_window_admissible(windows, started_at, observation_completed_at):
    if observation_completed_at - started_at >= 15:
        raise CaptureBlocked("first actual owned Engine HWND observation completed at/after original 15s deadline")
    return bool(windows)


def association_rows(core, reference, durable_sequence, seen):
    """Pure new-method classification; only caller's completed fsync enables it.

    Valid foreign/non-Engine rows are retained, never owned evidence. A missing
    optional diagnostic is not an invented name. No HWND is forever/current.
    """
    if durable_sequence != core["sequence"] or not durable_sequence:
        raise CaptureBlocked("core not durably persisted for this enumeration")
    if not reference["desktop_handle"] or not reference["process_handle"]:
        raise CaptureBlocked("missing original native owner handle")
    if core["reference"] != reference or core["desktop_handle"] != reference["desktop_handle"]:
        raise CaptureBlocked("original desktop/process creation reference changed")
    if (not core["desktop_name"] or not core["station_name"] or not core["sampled_input_desktop"]
            or core["desktop_name"].casefold() != reference["desktop_name"].casefold()
            or core["station_name"].casefold() != "winsta0"
            or core["station_name"].casefold() != reference["station_name"].casefold()
            or core["desktop_name"].casefold() == core["sampled_input_desktop"].casefold()):
        raise CaptureBlocked("original desktop identity/station/noninput conflict")
    if core["exception"] or core["process_live_before"] is not True or core["process_live_after"] is not True:
        raise CaptureBlocked("core exception or original process no longer live")
    if core["callback_count"] != len(core["rows"]):
        raise CaptureBlocked("partial callback accounting")
    owned, identities = [], {}
    for ordinal, row in enumerate(core["rows"], 1):
        thread, label = row["thread_query"], row["class_query"]
        if (row["exception"] or not row["hwnd"] or row["ordinal"] != ordinal or not thread or not label
                or not thread["tid_return"] or not thread["pid_output"]
                or not label["return_count"] or label["return_count"] != len(label["text"])
                or label["return_count"] >= label["buffer_capacity"] - 1):
            raise CaptureBlocked("partial/failed native callback core identity/class")
        identity = (thread["pid_output"], thread["tid_return"], label["text"])
        if row["hwnd"] in identities or (row["hwnd"] in seen and seen[row["hwnd"]] != identity):
            raise CaptureBlocked("duplicate or changed native HWND identity")
        identities[row["hwnd"]] = identity
        if thread["pid_output"] == reference["pid"] and label["text"] == "Engine":
            owned.append(row)
    if not core["raw_bool"]:
        if core["fresh_last_error"]:
            raise OSError(core["fresh_last_error"], "EnumDesktopWindows original HDESK")
        return None  # unavailable/pending, not successful empty enumeration
    seen.update(identities)
    return owned


def require_no_diagnostic_conflict(diagnostics, expected):
    for diagnostic in diagnostics:
        if diagnostic["status"] == "available":
            observed = diagnostic["observed_name"]
            if not observed or observed.casefold() != expected.casefold():
                raise CaptureBlocked("successful optional thread-desktop diagnostic conflicts with core association")
        elif diagnostic["status"] != "unavailable":
            raise CaptureBlocked("unrecognized optional diagnostic status")


def remember_owned_facts(api, state):
    state["desktop_handle"] = api.desktop
    if api.child:
        state.update(pid=api.child.dwProcessId, tid=api.child.dwThreadId,
                     process_handle=api.child.hProcess, thread_handle=api.child.hThread)


def persist_keeper_snapshot(events, attempt, event, state):
    """Append/fsync facts and a new exclusive receipt; preserve partial failures."""
    serial = state.get("keeper_receipt_serial", 0) + 1
    state["keeper_receipt_serial"] = serial
    journal(events, event, **state)
    file = attempt / ("keeper-%06d.json" % serial)
    with file.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(state, stream, ensure_ascii=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def keep_owner_until_terminal(api, creator, creator_errors, state, events, attempt):
    """Retain this exact API/HANDLE/thread owner. Never terminate, reopen or replay.

    The external exec session MUST remain alive; never give this owner a killing
    wrapper timeout. Interrupts/errors here cannot unwind unknown ownership.
    No native wait/observation follows admission until unknown facts are durable.
    """
    state["phase"] = "keeper_unknown_owner_retained"
    state["keeper_owner_pid"] = os.getpid()  # Identity only, never used to reopen/adopt.
    state["keeper_entry_durable"] = False
    state["outer_timeout_must_not_kill_owner"] = True
    state["failure"] = state["failure"] or "terminal unknown; original owner retained"
    while True:
        try:
            remember_owned_facts(api, state)
            if state["keeper_entry_durable"] is not True:
                persist_keeper_snapshot(events, attempt, "keeper_unknown_entry", state)
                state["keeper_entry_durable"] = True
                print("PRIVATE_CAPTURE_KEEPER " + json.dumps(dict(
                    owner_pid=state["keeper_owner_pid"], phase=state["phase"],
                    receipt=str(attempt / ("keeper-%06d.json" % state["keeper_receipt_serial"])),
                    outer_timeout_must_not_kill_owner=True)), flush=True)
            before = {key: state.get(key) for key in ("child_terminal", "creator_terminal", "desktop_handle", "pid", "tid", "process_handle", "thread_handle", "keeper_observation_error", "creator_errors_late")}
            child_observed = state["child_terminal"]
            if child_observed is not True:
                try:
                    child_observed = api.terminal()  # Only the original HANDLE.
                except BaseException as exc:
                    child_observed = None
                    state["keeper_observation_error"] = repr(exc)
            creator_observed = creator is None or not creator.is_alive()
            state["creator_errors_late"] = list(creator_errors)
            remember_owned_facts(api, state)
            action = keeper_transition(state, child_observed, creator_observed)
            changed = any(state.get(key) != value for key, value in before.items())
            if changed or action == "cleanup_eligible":
                persist_keeper_snapshot(events, attempt, "keeper_observation", state)
            if action == "cleanup_eligible":
                state["phase"] = "keeper_later_positive_terminal_recorded"
                return  # Both positives are durable; caller may try cleanup once.
        except BaseException as exc:
            # Keep original owner even on persistence/console/native-query errors.
            state["keeper_internal_error"] = repr(exc)
        try:
            time.sleep(1)  # Ordinary retained-process supervision, no model polling.
        except BaseException as exc:
            state["keeper_wait_interrupted"] = repr(exc)


def render_argv(plan):
    return [plan["engine"], "--path", plan["project"], "--display-driver", "windows",
            "--rendering-driver", "vulkan", "--rendering-method", "forward_plus",
            "--audio-driver", "Dummy", "--windowed", "--resolution", "1920x1080",
            "--accessibility", "disabled", "--disable-render-loop", "--script",
            plan["adapter"], "--", plan["frames"]]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def contained(path, base):
    path = Path(path).resolve()
    if not path.is_relative_to(Path(base).resolve()):
        raise CaptureBlocked("path escapes owned directory")
    return path


def journal(path, event, **facts):
    """Append/fsync before any next native operation. Never overwrite old facts."""
    data = json.dumps(dict(event=event, **facts), ensure_ascii=True).encode() + b"\n"
    with Path(path).open("ab", buffering=0) as stream:
        stream.write(data)
        os.fsync(stream.fileno())


def verify_sources(plan):
    if sha(__file__) != plan["launcher_sha256"] or sha(plan["source_pins"]) != plan["source_pins_sha256"]:
        raise CaptureBlocked("reviewed launcher/source manifest changed")
    source_map = json.loads(Path(plan["source_pins"]).read_text(encoding="utf-8"))
    for item in source_map["files"]:
        for base in (Path(source_map["product"]), SPACE / "product"):
            if sha(base / item["path"]) != item["sha256"]:
                raise CaptureBlocked("source changed: " + item["path"])
    if sha(plan["engine"]) != plan["engine_sha256"]:
        raise CaptureBlocked("engine changed")
    if sha(plan["adapter"]) != plan["adapter_sha256"]:
        raise CaptureBlocked("adapter changed")


def validate_capture_outputs(attempt):
    frames = attempt / "frames"
    report = json.loads((frames / "capture-report.json").read_text(encoding="utf-8"))
    if report.get("status") != "frames_written_await_root_visual_review" or report.get("stopped") is not True:
        raise CaptureBlocked("capture report incomplete or unstopped")
    if (report.get("display_driver"), report.get("rendering_driver"), report.get("rendering_method")) != ("windows", "vulkan", "forward_plus"):
        raise CaptureBlocked("capture backend mismatch")
    expected = {"%dx%d-%s.png" % (w,h,v):(w,h) for w,h in ((1920,1080),(2560,1440)) for v in ("top","bottom","front","back","left","right","iso","drill")}
    rows = report.get("frames", [])
    if len(rows) != 16 or {v.get("path") for v in rows} != set(expected):
        raise CaptureBlocked("sixteen required frame paths not present")
    import struct
    pins = []
    for name, size in expected.items():
        file = contained(frames / name, frames)
        data = file.read_bytes()
        if data[:8] != b"\x89PNG\r\n\x1a\n" or len(data) < 24 or struct.unpack(">II", data[16:24]) != size:
            raise CaptureBlocked("invalid PNG header/dimensions: " + name)
        pins.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    return pins  # Structure only; root must actually inspect all real images.


class STARTUPINFOW(C.Structure):
    _fields_ = [("cb", W.DWORD), ("lpReserved", W.LPWSTR), ("lpDesktop", W.LPWSTR),
                ("lpTitle", W.LPWSTR), ("dwX", W.DWORD), ("dwY", W.DWORD),
                ("dwXSize", W.DWORD), ("dwYSize", W.DWORD), ("dwXCountChars", W.DWORD),
                ("dwYCountChars", W.DWORD), ("dwFillAttribute", W.DWORD),
                ("dwFlags", W.DWORD), ("wShowWindow", W.WORD), ("cbReserved2", W.WORD),
                ("lpReserved2", C.POINTER(C.c_ubyte)), ("hStdInput", W.HANDLE),
                ("hStdOutput", W.HANDLE), ("hStdError", W.HANDLE)]


class STARTUPINFOEXW(C.Structure):
    _fields_ = [("StartupInfo", STARTUPINFOW), ("lpAttributeList", C.c_void_p)]


class PROCESS_INFORMATION(C.Structure):
    _fields_ = [("hProcess", W.HANDLE), ("hThread", W.HANDLE),
                ("dwProcessId", W.DWORD), ("dwThreadId", W.DWORD)]


class Win32:
    """Only instantiated inside execute(), in its own launcher process."""
    def __init__(self):
        self.u = C.WinDLL("user32", use_last_error=True)
        self.k = C.WinDLL("kernel32", use_last_error=True)
        self.desktop = None
        self.child = None
        self.files = []
        specs = [
            (self.u, "GetProcessWindowStation", [], W.HANDLE),
            (self.u, "GetUserObjectInformationW", [W.HANDLE, C.c_int, C.c_void_p, W.DWORD, C.POINTER(W.DWORD)], W.BOOL),
            (self.u, "OpenInputDesktop", [W.DWORD, W.BOOL, W.DWORD], W.HANDLE),
            (self.u, "OpenDesktopW", [W.LPCWSTR, W.DWORD, W.BOOL, W.DWORD], W.HANDLE),
            (self.u, "CreateDesktopW", [W.LPCWSTR, C.c_void_p, C.c_void_p, W.DWORD, W.DWORD, C.c_void_p], W.HANDLE),
            (self.u, "CloseDesktop", [W.HANDLE], W.BOOL),
            (self.u, "GetThreadDesktop", [W.DWORD], W.HANDLE),
            (self.u, "EnumDesktopWindows", [W.HANDLE, C.c_void_p, W.LPARAM], W.BOOL),
            (self.u, "GetWindowThreadProcessId", [W.HWND, C.POINTER(W.DWORD)], W.DWORD),
            (self.u, "GetClassNameW", [W.HWND, W.LPWSTR, C.c_int], C.c_int),
            (self.k, "GetCurrentThreadId", [], W.DWORD),
            (self.k, "InitializeProcThreadAttributeList", [C.c_void_p, W.DWORD, W.DWORD, C.POINTER(C.c_size_t)], W.BOOL),
            (self.k, "UpdateProcThreadAttribute", [C.c_void_p, W.DWORD, C.c_size_t, C.c_void_p, C.c_size_t, C.c_void_p, C.c_void_p], W.BOOL),
            (self.k, "DeleteProcThreadAttributeList", [C.c_void_p], None),
            (self.k, "CreateProcessW", [W.LPCWSTR, W.LPWSTR, C.c_void_p, C.c_void_p, W.BOOL, W.DWORD, C.c_void_p, W.LPCWSTR, C.POINTER(STARTUPINFOEXW), C.POINTER(PROCESS_INFORMATION)], W.BOOL),
            (self.k, "ResumeThread", [W.HANDLE], W.DWORD),
            (self.k, "WaitForSingleObject", [W.HANDLE, W.DWORD], W.DWORD),
            (self.k, "GetExitCodeProcess", [W.HANDLE, C.POINTER(W.DWORD)], W.BOOL),
            (self.k, "TerminateProcess", [W.HANDLE, W.UINT], W.BOOL),
            (self.k, "CloseHandle", [W.HANDLE], W.BOOL),
        ]
        for dll, name, args, result in specs:
            fun = getattr(dll, name)
            fun.argtypes, fun.restype = args, result

    @staticmethod
    def check(ok, operation):
        if not ok:
            raise OSError(C.get_last_error(), operation)

    def name(self, handle):
        if not handle:
            raise OSError(C.get_last_error(), "missing object handle")
        required = W.DWORD()
        self.u.GetUserObjectInformationW(handle, 2, None, 0, C.byref(required))
        if not required.value or required.value > 65536:
            raise CaptureBlocked("invalid user object name size")
        buf = C.create_unicode_buffer(required.value // C.sizeof(C.c_wchar) + 1)
        self.check(self.u.GetUserObjectInformationW(handle, 2, buf, C.sizeof(buf), C.byref(required)), "GetUserObjectInformationW")
        return buf.value

    def input_name(self):
        # Opened query reference is owned; never close GetThreadDesktop's borrowed handle.
        handle = self.u.OpenInputDesktop(0, False, 0x0001)
        self.check(handle, "OpenInputDesktop")
        try:
            return self.name(handle)
        finally:
            self.check(self.u.CloseDesktop(handle), "close owned input query reference")

    def create_desktop(self, name):
        if self.name(self.u.GetProcessWindowStation()).casefold() != "winsta0":
            raise CaptureBlocked("launcher station is not WinSta0")
        C.set_last_error(0)
        existing = self.u.OpenDesktopW(name, 0, False, 0x0001)
        if existing:
            self.check(self.u.CloseDesktop(existing), "close collision query reference")
            raise CaptureBlocked("desktop name already exists")
        if C.get_last_error() != 2:
            raise OSError(C.get_last_error(), "OpenDesktopW absence not established")
        # lpsa=None makes HDESK non-inheritable. Never request SWITCHDESKTOP rights.
        C.set_last_error(0)
        handle = self.u.CreateDesktopW(name, None, None, 0, 0x0002 | 0x0001 | 0x0080 | 0x0040, None)
        creation_error = C.get_last_error()
        self.desktop = handle  # Save native fact before any following operation.
        self.check(handle, "CreateDesktopW")
        if creation_error == 183:
            raise CaptureBlocked("desktop collision reported by CreateDesktopW")
        if self.name(handle).casefold() != name.casefold():
            raise CaptureBlocked("created desktop name mismatch")

    def spawn_suspended(self, argv, plan, attempt):
        import msvcrt
        empty = attempt / "stdin-empty.bin"
        empty.write_bytes(b"")
        self.files = [empty.open("rb", buffering=0), (attempt/"engine.stdout.bin").open("xb", buffering=0), (attempt/"engine.stderr.bin").open("xb", buffering=0)]
        handles = [msvcrt.get_osfhandle(f.fileno()) for f in self.files]
        for handle in handles:
            os.set_handle_inheritable(handle, True)
        size = C.c_size_t()
        self.k.InitializeProcThreadAttributeList(None, 1, 0, C.byref(size))
        if not size.value:
            raise CaptureBlocked("attribute list sizing failed")
        attributes = C.create_string_buffer(size.value)
        self.check(self.k.InitializeProcThreadAttributeList(attributes, 1, 0, C.byref(size)), "InitializeProcThreadAttributeList")
        try:
            allowed = (W.HANDLE * 3)(*handles)
            self.check(self.k.UpdateProcThreadAttribute(attributes, 0, 0x00020002, C.cast(allowed, C.c_void_p), C.sizeof(allowed), None, None), "stdio handle allowlist")
            si = STARTUPINFOEXW()
            si.StartupInfo.cb = C.sizeof(si)
            si.StartupInfo.lpDesktop = "WinSta0\\" + plan["desktop_name"]
            si.StartupInfo.dwFlags = 0x00000100
            si.StartupInfo.hStdInput, si.StartupInfo.hStdOutput, si.StartupInfo.hStdError = handles
            si.lpAttributeList = C.cast(attributes, C.c_void_p)
            command = C.create_unicode_buffer(subprocess.list2cmdline(argv))
            env = os.environ.copy()
            for key, rel in (("APPDATA","appdata"),("LOCALAPPDATA","localappdata"),("TEMP","temp"),("TMP","temp")):
                directory = attempt / rel
                directory.mkdir(exist_ok=True)
                env[key] = str(directory)
            environment = C.create_unicode_buffer("\0".join(k+"="+v for k,v in sorted(env.items(),key=lambda kv:kv[0].upper()))+"\0")
            pi = PROCESS_INFORMATION()
            ok = self.k.CreateProcessW(plan["engine"], command, None, None, True,
                0x00000004 | 0x00080000 | 0x00000400 | 0x08000000,
                C.cast(environment, C.c_void_p), plan["project"], C.byref(si), C.byref(pi))
            if ok:
                self.child = pi  # Native handles retained before any validation/logging.
            self.check(ok, "CreateProcessW suspended")
            return pi
        finally:
            self.k.DeleteProcThreadAttributeList(attributes)
            for handle in handles:
                os.set_handle_inheritable(handle, False)

    def thread_desktop_name(self):
        C.set_last_error(0)
        handle = self.u.GetThreadDesktop(self.child.dwThreadId)
        error = C.get_last_error()
        if not handle:
            return None, "GetThreadDesktop returned NULL; last_error=%d" % error
        return self.name(handle), None  # borrowed, NEVER closed

    def monitor_desktop_name(self):
        return self.name(self.u.GetThreadDesktop(self.k.GetCurrentThreadId()))

    def owned_windows(self, reference, sequence, sampled_input):
        # Raw core only. This function NEVER calls optional GetThreadDesktop/name.
        core = dict(method=ASSOCIATION_METHOD, sequence=sequence, reference=dict(reference),
                    owner_pid=os.getpid(), clock_domain="time.perf_counter original launcher process",
                    desktop_handle=self.desktop, desktop_name=None, station_name=None,
                    sampled_input_desktop=sampled_input, started_at=time.perf_counter(),
                    completed_at=None, process_live_before=None, process_live_after=None,
                    raw_bool=None, fresh_last_error=None, callback_count=0, rows=[], exception=None)
        try:
            if not self.desktop or self.desktop != reference["desktop_handle"]:
                raise CaptureBlocked("original non-null HDESK not held")
            if (not self.child or self.child.hProcess != reference["process_handle"]
                    or self.child.dwProcessId != reference["pid"] or self.child.dwThreadId != reference["initial_tid"]):
                raise CaptureBlocked("original PROCESS_INFORMATION changed")
            core["desktop_name"] = self.name(self.desktop)
            core["station_name"] = self.name(self.u.GetProcessWindowStation())
            core["process_live_before"] = not self.terminal()
            if not core["process_live_before"]:
                raise CaptureBlocked("original hProcess not live before enumeration")
            callback_type = C.WINFUNCTYPE(W.BOOL, W.HWND, W.LPARAM)
            def visit(hwnd, parameter):
                # Save callback occurrence/HWND before any lookup or metadata.
                row = dict(ordinal=len(core["rows"])+1, hwnd=hwnd,
                           thread_query=None, class_query=None, exception=None)
                core["rows"].append(row)
                core["callback_count"] += 1
                try:
                    pid = W.DWORD(0)
                    C.set_last_error(0)
                    tid = self.u.GetWindowThreadProcessId(hwnd, C.byref(pid))
                    thread_error = C.get_last_error()
                    row["thread_query"] = dict(tid_return=tid, pid_output=pid.value, fresh_error=thread_error)
                    label = C.create_unicode_buffer(256)
                    C.set_last_error(0)
                    count = self.u.GetClassNameW(hwnd, label, len(label))
                    class_error = C.get_last_error()
                    row["class_query"] = dict(return_count=count, text=label.value,
                                              fresh_error=class_error, buffer_capacity=len(label))
                except BaseException as exc:
                    row["exception"] = repr(exc)
                return True
            callback = callback_type(visit)
            pointer = C.cast(callback, C.c_void_p)
            C.set_last_error(0)
            raw_bool = self.u.EnumDesktopWindows(self.desktop, pointer, 0)
            enum_error = C.get_last_error()
            core["raw_bool"], core["fresh_last_error"] = int(raw_bool), enum_error
            core["process_live_after"] = not self.terminal()
        except BaseException as exc:
            core["exception"] = repr(exc)
        core["completed_at"] = time.perf_counter()
        return core  # Caller must fsync this complete/partial core before diagnostics.

    def thread_desktop_diagnostics(self, rows):
        diagnostics = []
        for row in rows:
            item = dict(hwnd=row["hwnd"], tid=row["thread_query"]["tid_return"],
                        status="unavailable", thread_handle=None, fresh_error=None,
                        name_probe=None, name_query=None, observed_name=None, exception=None)
            diagnostics.append(item)
            try:
                C.set_last_error(0)
                handle = self.u.GetThreadDesktop(item["tid"])
                error = C.get_last_error()
                item["thread_handle"], item["fresh_error"] = handle, error
                if handle:
                    required = W.DWORD(0)
                    C.set_last_error(0)
                    probe = self.u.GetUserObjectInformationW(handle, 2, None, 0, C.byref(required))
                    probe_error = C.get_last_error()
                    item["name_probe"] = dict(raw_bool=int(probe), fresh_error=probe_error, required_bytes=required.value)
                    if not required.value or required.value > 65536:
                        raise CaptureBlocked("optional diagnostic name size unavailable")
                    buf = C.create_unicode_buffer(required.value // C.sizeof(C.c_wchar) + 1)
                    C.set_last_error(0)
                    result = self.u.GetUserObjectInformationW(handle, 2, buf, C.sizeof(buf), C.byref(required))
                    name_error = C.get_last_error()
                    item["name_query"] = dict(raw_bool=int(result), fresh_error=name_error,
                                              required_bytes=required.value, text=buf.value)
                    if result and buf.value:
                        item["observed_name"], item["status"] = buf.value, "available"
            except BaseException as exc:
                item["exception"] = repr(exc)
            item["completed_at"] = time.perf_counter()
            # GetThreadDesktop's borrowed handle is NEVER closed.
        return diagnostics

    def terminal(self):
        if not self.child:
            return True
        state = self.k.WaitForSingleObject(self.child.hProcess, 0)
        if state not in (0, 0x102):
            raise OSError(C.get_last_error(), "WaitForSingleObject")
        return state == 0

    def terminate_owned(self):
        if self.child and not self.terminal():
            self.check(self.k.TerminateProcess(self.child.hProcess, 0xE001), "TerminateProcess owned child")
            if self.k.WaitForSingleObject(self.child.hProcess, 5000) != 0:
                raise CaptureBlocked("owned child termination unconfirmed")

    def close_owned(self, *, child_terminal, creator_terminal):
        if cleanup_decision(child_terminal=child_terminal, creator_terminal=creator_terminal) != "close_owned":
            raise CaptureBlocked("retain handles: child or creator terminal unconfirmed")
        if self.child:
            for handle in (self.child.hThread, self.child.hProcess):
                self.check(self.k.CloseHandle(handle), "CloseHandle owned process/thread")
        for stream in self.files:
            stream.close()
        if self.desktop:
            self.check(self.u.CloseDesktop(self.desktop), "CloseDesktop self-created only")


def execute(plan, ordinal):
    """No automatic import, fallback, second attempt, or reuse of an old attempt."""
    verify_sources(plan)
    if ordinal != 1:
        raise CaptureBlocked("new job budget is exactly one possible future invocation")
    attempt = OUT / ("attempt-%02d" % ordinal)
    attempt.mkdir()  # Exclusive: unknown/previous attempts are never replayed.
    plan = dict(plan)
    plan["desktop_name"] += "_%02d" % ordinal
    plan["frames"] = str(attempt / "frames")
    (attempt/"frames").mkdir()
    events = attempt / "events.jsonl"
    journal(events, "reserved_before_native_effects", work_id=WORK_ID, argv=render_argv(plan), desktop=plan["desktop_name"], attempt_budget_seconds=60, stop_request_seconds=55, forced_terminal_guarantee=False)
    api = Win32()
    state = {"work_id":WORK_ID,"ordinal":ordinal,"child_terminal":False,"creator_terminal":False,"phase":"native_started_unknown","failure":None,"input_desktop_observations":[]}
    creator = None
    creator_error = []
    baseline = None
    try:
        baseline = api.input_name()
        state["input_desktop_before"] = baseline
        state["monitor_thread_desktop"] = api.monitor_desktop_name()
        require_same_input(baseline, state["monitor_thread_desktop"])
        journal(events, "input_before", name=baseline)
        if baseline.casefold() == plan["desktop_name"].casefold():
            raise CaptureBlocked("new desktop unexpectedly input")
        def make_desktop():
            try:
                api.create_desktop(plan["desktop_name"])
            except BaseException as exc:
                creator_error.append(repr(exc))
        journal(events, "desktop_create_started_unknown")
        creator = threading.Thread(target=make_desktop, name="owned-desktop-creator")
        creator.start()
        creator.join(5)
        state["creator_terminal"] = not creator.is_alive()
        if not state["creator_terminal"]:
            raise CaptureBlocked("creator thread terminal not confirmed; retain desktop")
        if creator_error:
            raise CaptureBlocked("creator failed: " + creator_error[0])
        journal(events, "desktop_created_creator_terminal", handle=api.desktop, name=plan["desktop_name"])
        require_same_input(baseline, api.input_name())
        journal(events, "process_create_started_unknown")
        start = time.perf_counter()  # Attempt budget only; no promise a driver can be forcibly stopped in 60s.
        pi = api.spawn_suspended(render_argv(plan), plan, attempt)
        state.update(pid=pi.dwProcessId, tid=pi.dwThreadId, process_handle=pi.hProcess, thread_handle=pi.hThread)
        observed, observation_error = api.thread_desktop_name()
        observation = suspended_observation(observed, plan["desktop_name"], observation_error)
        state["suspended_thread_desktop"] = observation
        journal(events, "suspended_thread_desktop_observed", observation=observation, pid=pi.dwProcessId, tid=pi.dwThreadId)
        require_same_input(baseline, api.input_name())
        journal(events, "resume_started_unknown")
        resumed = api.k.ResumeThread(pi.hThread)
        if resumed != 1:
            raise CaptureBlocked("unexpected ResumeThread previous count: %d" % resumed)
        state["phase"] = "resumed"
        state["input_desktop_sampling_seconds"] = .05
        state["association_method"] = ASSOCIATION_METHOD
        state["first_native_association_rows"] = []
        state["native_observations_are_not_per_frame_current_proof"] = True
        state["frame_capture_timestamps"] = None  # Immutable adapter supplies no native clock stamps.
        reference = dict(job_id=JOB_ID, run_id=plan["run_id"], desktop_handle=api.desktop,
                         desktop_name=api.name(api.desktop), station_name=api.name(api.u.GetProcessWindowStation()),
                         process_handle=pi.hProcess, pid=pi.dwProcessId, initial_tid=pi.dwThreadId,
                         desktop_creation_event="desktop_created_creator_terminal")
        state["original_native_reference"] = reference
        journal(events, "original_native_reference", **reference)
        sequence, seen = 0, {}
        while not api.terminal():
            current = api.input_name()
            state["input_desktop_observations"].append(current)
            require_same_input(baseline, current)
            require_same_input(state["monitor_thread_desktop"], api.monitor_desktop_name())
            sequence += 1
            core = api.owned_windows(reference, sequence, current)
            state["last_core_observation"] = core
            journal(events, "enum_association_core", **core)  # Append + fsync before any diagnostic.
            persisted_at = time.perf_counter()
            state["core_durable_sequence"] = sequence
            state["core_persistence_completed_at"] = persisted_at
            windows = association_rows(core, reference, sequence, seen)
            if not state["first_native_association_rows"]:
                first_window_admissible(windows, start, persisted_at)
            diagnostics = api.thread_desktop_diagnostics(windows or [])
            state["last_thread_desktop_diagnostics"] = diagnostics
            journal(events, "optional_thread_desktop_diagnostics", sequence=sequence,
                    diagnostics=diagnostics, core_persistence_completed_at=persisted_at)
            require_no_diagnostic_conflict(diagnostics, reference["desktop_name"])
            process_live = not api.terminal()  # Same held hProcess, never PID adoption.
            if not process_live:
                raise CaptureBlocked("original hProcess not live at native association admission")
            admission_at = time.perf_counter()
            if not state["first_native_association_rows"]:
                admissible = first_window_admissible(windows, start, admission_at)
            else:
                admissible = bool(windows)
                if core["raw_bool"] and not windows:
                    raise CaptureBlocked("successful enumeration lost prior owned Engine association")
            sample = dict(method=ASSOCIATION_METHOD, sequence=sequence, rows=windows,
                          core_persistence_completed_at=persisted_at, admission_checked_at=admission_at,
                          process_live_at_admission=process_live, admitted=admissible,
                          claim="sampled native association only; no atomic per-frame/no-flash proof")
            if admissible and not state["first_native_association_rows"]:
                state["first_native_association_rows"] = windows
                state["first_native_association_sample"] = sample
            state["last_native_association_sample"] = sample
            journal(events, "native_association_sample", **sample)
            if time.perf_counter() - start >= 55:
                raise CaptureBlocked("attempt stop threshold reached; actual terminal must be observed")
            time.sleep(.05)
        state["child_terminal"] = True
        code = W.DWORD()
        api.check(api.k.GetExitCodeProcess(pi.hProcess, C.byref(code)), "GetExitCodeProcess")
        state["exit_code"] = code.value
        state["phase"] = "process_terminal"
        if code.value != 0:
            raise CaptureBlocked("engine nonzero exit")
        if not state["first_native_association_rows"]:
            raise CaptureBlocked("engine exited without new-method native association proof")
        state["real_frame_structure_pins"] = validate_capture_outputs(attempt)
        if b"SCRIPT ERROR:" in (attempt/"engine.stderr.bin").read_bytes():
            raise CaptureBlocked("engine reported script error")
    except BaseException as exc:
        state["failure"] = repr(exc)
        try:
            api.terminate_owned()
        except BaseException as stop_error:
            state["termination_error"] = repr(stop_error)
    finally:
        if api.child:
            state.update(pid=api.child.dwProcessId, tid=api.child.dwThreadId,
                         process_handle=api.child.hProcess, thread_handle=api.child.hThread)
        try:
            state["child_terminal"] = api.terminal()
        except BaseException as exc:
            state["child_terminal"] = False
            state["terminal_observation_error"] = repr(exc)
            state["failure"] = state["failure"] or repr(exc)
        state["creator_terminal"] = creator is None or not creator.is_alive()
        try:
            current = api.input_name()
            state["input_desktop_after"] = current
            if baseline is not None:
                require_same_input(baseline, current)
        except BaseException as exc:
            state["after_observation_error"] = repr(exc)
            state["failure"] = state["failure"] or repr(exc)
        if keeper_required(state["child_terminal"], state["creator_terminal"]):
            keep_owner_until_terminal(api, creator, creator_error, state, events, attempt)
        try:
            api.close_owned(child_terminal=state["child_terminal"], creator_terminal=state["creator_terminal"])
            state["owned_handles_closed"] = True
        except BaseException as exc:
            state["cleanup_error"] = repr(exc)
            state["failure"] = state["failure"] or "owned close failed: " + repr(exc)
        try:
            verify_sources(plan)
            state["all_52_sources_unchanged_after"] = True
        except BaseException as exc:
            state["source_error"] = repr(exc)
            state["failure"] = state["failure"] or repr(exc)
        journal(events, "terminal_or_unconfirmed_receipt", **state)
        with (attempt/"receipt.json").open("x",encoding="utf-8",newline="\n") as stream:
            json.dump(state,stream,ensure_ascii=True,indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
    return 0 if state["failure"] is None and state.get("owned_handles_closed") else 2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute-reviewed", action="store_true")
    parser.add_argument("--attempt", type=int, choices=(1,))
    args = parser.parse_args()
    if not args.execute_reviewed or args.attempt is None:
        raise CaptureBlocked("phase 1 is frozen only; explicit root phase-2 authorization required")
    plan = json.loads(PLAN.read_text(encoding="utf-8"))
    if plan["work_id"] != WORK_ID or plan["job_id"] != JOB_ID:
        raise CaptureBlocked("foreign plan")
    # This CLI is called only by the later authorized independent launcher process.
    return execute(plan, args.attempt)


if __name__ == "__main__":
    raise SystemExit(main())
