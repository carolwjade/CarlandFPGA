"""Source-only derivation from pinned failed-job v3. Never calls Win32/engine."""
from pathlib import Path
import difflib
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
source = (OUT / "inputs/launcher_v3.py").read_text(encoding="utf-8")
assert hashlib.sha256(source.encode()).hexdigest() == "34b91a6bf4f3d3f1ce03949c0755e13395f4b014363fc20f1753bf7ad6b19516"
original = source


def replace(before, after):
    global source
    assert source.count(before) == 1, before[:100]
    source = source.replace(before, after)


replace('WORK_ID = "A-GAME3D-PRIVATE-DESKTOP-CAPTURE-20261024-v1"', 'WORK_ID = "A-GAME3D-ENUM-ASSOCIATION-CAPTURE-20261024-v1"')
replace('JOB_ID = "child-71958a7341174c76a4132dcb9a364a46"', 'JOB_ID = "child-ff673689f0da408998a3a64ed82abd10"')
replace('SPACE = ROOT / ".local/deepeye-game3d-private-desktop-capture-20261024"', 'SPACE = ROOT / ".local/deepeye-game3d-enum-association-capture-20261024"')
replace('PLAN = OUT / "execution-plan-v3.json"', 'PLAN = OUT / "execution-plan.json"\nASSOCIATION_METHOD = "enum_desktop_windows_callback_v1"')
lo = source.index('def enum_rows_from_observation(')
hi = source.index('def remember_owned_facts(', lo)
source = source[:lo] + '''def association_rows(core, reference, durable_sequence, seen):
    """Pure new-method classification; only caller's completed fsync enables it.

    Valid foreign/non-Engine rows are retained, never owned evidence. A missing
    optional diagnostic is not an invented name. No HWND is forever/current.
    """
    if durable_sequence != core["sequence"] or not durable_sequence:
        raise CaptureBlocked("core not durably persisted for this enumeration")
    if type(core["raw_bool"]) is not int or type(core["fresh_last_error"]) is not int:
        raise CaptureBlocked("missing raw enumeration return/error")
    if not reference["desktop_handle"] or not reference["process_handle"]:
        raise CaptureBlocked("missing original native owner handle")
    if core["reference"] != reference or core["desktop_handle"] != reference["desktop_handle"]:
        raise CaptureBlocked("original desktop/process creation reference changed")
    if (not core["desktop_name"] or not core["station_name"] or not core["sampled_input_desktop"]
            or core["desktop_name"].casefold() != reference["desktop_name"].casefold()
            or core["station_name"].casefold() != "winsta0"
            or core["station_name"].casefold() != reference["station_name"].casefold()
            or core["desktop_name"].casefold() == core["sampled_input_desktop"].casefold()):
        raise CaptureBlocked("original desktop identity/station/noninput conflict")
    if core["exception"] or core["process_live_before"] is not True or core["process_live_after"] is not True:
        raise CaptureBlocked("core exception or original process no longer live")
    if core["callback_count"] != len(core["rows"]):
        raise CaptureBlocked("partial callback accounting")
    owned, identities = [], {}
    for ordinal, row in enumerate(core["rows"], 1):
        thread, label = row["thread_query"], row["class_query"]
        if (row["exception"] or not row["hwnd"] or row["ordinal"] != ordinal or not thread or not label
                or not thread["tid_return"] or not thread["pid_output"]
                or not label["return_count"] or label["return_count"] != len(label["text"])
                or label["return_count"] >= label["buffer_capacity"] - 1):
            raise CaptureBlocked("partial/failed native callback core identity/class")
        identity = (thread["pid_output"], thread["tid_return"], label["text"])
        if row["hwnd"] in identities or (row["hwnd"] in seen and seen[row["hwnd"]] != identity):
            raise CaptureBlocked("duplicate or changed native HWND identity")
        identities[row["hwnd"]] = identity
        if thread["pid_output"] == reference["pid"] and label["text"] == "Engine":
            owned.append(row)
    if not core["raw_bool"]:
        if core["fresh_last_error"]:
            raise OSError(core["fresh_last_error"], "EnumDesktopWindows original HDESK")
        return None  # unavailable/pending, not successful empty enumeration
    seen.update(identities)
    return owned


def require_no_diagnostic_conflict(diagnostics, expected):
    for diagnostic in diagnostics:
        if diagnostic["status"] == "available":
            observed = diagnostic["observed_name"]
            if not observed or observed.casefold() != expected.casefold():
                raise CaptureBlocked("successful optional thread-desktop diagnostic conflicts with core association")
        elif diagnostic["status"] != "unavailable":
            raise CaptureBlocked("unrecognized optional diagnostic status")


''' + source[hi:]
lo = source.index('    def owned_windows(self):')
hi = source.index('    def terminal(self):', lo)
source = source[:lo] + '''    def owned_windows(self, reference, sequence, sampled_input):
        # Raw core only. This function NEVER calls optional GetThreadDesktop/name.
        core = dict(method=ASSOCIATION_METHOD, sequence=sequence, reference=dict(reference),
                    owner_pid=os.getpid(), clock_domain="time.perf_counter original launcher process",
                    desktop_handle=self.desktop, desktop_name=None, station_name=None,
                    sampled_input_desktop=sampled_input, started_at=time.perf_counter(),
                    completed_at=None, process_live_before=None, process_live_after=None,
                    raw_bool=None, fresh_last_error=None, callback_count=0, rows=[], exception=None)
        try:
            if not self.desktop or self.desktop != reference["desktop_handle"]:
                raise CaptureBlocked("original non-null HDESK not held")
            if (not self.child or self.child.hProcess != reference["process_handle"]
                    or self.child.dwProcessId != reference["pid"] or self.child.dwThreadId != reference["initial_tid"]):
                raise CaptureBlocked("original PROCESS_INFORMATION changed")
            core["desktop_name"] = self.name(self.desktop)
            core["station_name"] = self.name(self.u.GetProcessWindowStation())
            core["process_live_before"] = not self.terminal()
            if not core["process_live_before"]:
                raise CaptureBlocked("original hProcess not live before enumeration")
            callback_type = C.WINFUNCTYPE(W.BOOL, W.HWND, W.LPARAM)
            def visit(hwnd, parameter):
                # Save callback occurrence/HWND before any lookup or metadata.
                row = dict(ordinal=len(core["rows"])+1, hwnd=hwnd,
                           thread_query=None, class_query=None, exception=None)
                core["rows"].append(row)
                core["callback_count"] += 1
                try:
                    pid = W.DWORD(0)
                    C.set_last_error(0)
                    tid = self.u.GetWindowThreadProcessId(hwnd, C.byref(pid))
                    thread_error = C.get_last_error()
                    row["thread_query"] = dict(tid_return=tid, pid_output=pid.value, fresh_error=thread_error)
                    label = C.create_unicode_buffer(256)
                    C.set_last_error(0)
                    count = self.u.GetClassNameW(hwnd, label, len(label))
                    class_error = C.get_last_error()
                    row["class_query"] = dict(return_count=count, text=label.value,
                                              fresh_error=class_error, buffer_capacity=len(label))
                except BaseException as exc:
                    row["exception"] = repr(exc)
                return True
            callback = callback_type(visit)
            pointer = C.cast(callback, C.c_void_p)
            C.set_last_error(0)
            raw_bool = self.u.EnumDesktopWindows(self.desktop, pointer, 0)
            enum_error = C.get_last_error()
            core["raw_bool"], core["fresh_last_error"] = int(raw_bool), enum_error
            core["process_live_after"] = not self.terminal()
        except BaseException as exc:
            core["exception"] = repr(exc)
        core["completed_at"] = time.perf_counter()
        return core  # Caller must fsync this complete/partial core before diagnostics.

    def thread_desktop_diagnostics(self, rows):
        diagnostics = []
        for row in rows:
            item = dict(hwnd=row["hwnd"], tid=row["thread_query"]["tid_return"],
                        status="unavailable", thread_handle=None, fresh_error=None,
                        name_probe=None, name_query=None, observed_name=None, exception=None)
            diagnostics.append(item)
            try:
                C.set_last_error(0)
                handle = self.u.GetThreadDesktop(item["tid"])
                error = C.get_last_error()
                item["thread_handle"], item["fresh_error"] = handle, error
                if handle:
                    required = W.DWORD(0)
                    C.set_last_error(0)
                    probe = self.u.GetUserObjectInformationW(handle, 2, None, 0, C.byref(required))
                    probe_error = C.get_last_error()
                    item["name_probe"] = dict(raw_bool=int(probe), fresh_error=probe_error, required_bytes=required.value)
                    if not required.value or required.value > 65536:
                        raise CaptureBlocked("optional diagnostic name size unavailable")
                    buf = C.create_unicode_buffer(required.value // C.sizeof(C.c_wchar) + 1)
                    C.set_last_error(0)
                    result = self.u.GetUserObjectInformationW(handle, 2, buf, C.sizeof(buf), C.byref(required))
                    name_error = C.get_last_error()
                    item["name_query"] = dict(raw_bool=int(result), fresh_error=name_error,
                                              required_bytes=required.value, text=buf.value)
                    if result and buf.value:
                        item["observed_name"], item["status"] = buf.value, "available"
            except BaseException as exc:
                item["exception"] = repr(exc)
            item["completed_at"] = time.perf_counter()
            # GetThreadDesktop's borrowed handle is NEVER closed.
        return diagnostics

''' + source[hi:]
replace('''    if ordinal not in (1, 2):
        raise CaptureBlocked("render budget is at most two")
    if ordinal == 2:
        previous = json.loads((OUT/"attempt-01"/"receipt.json").read_text(encoding="utf-8"))
        if previous.get("child_terminal") is not True or previous.get("creator_terminal") is not True:
            raise CaptureBlocked("previous attempt terminal not established")''', '''    if ordinal != 1:
        raise CaptureBlocked("new job budget is exactly one possible future invocation")''')
replace('parser.add_argument("--attempt", type=int, choices=(1,2))', 'parser.add_argument("--attempt", type=int, choices=(1,))')
replace('''        state["owned_engine_window_observations"] = []
        while not api.terminal():''', '''        state["association_method"] = ASSOCIATION_METHOD
        state["first_native_association_rows"] = []
        state["native_observations_are_not_per_frame_current_proof"] = True
        state["frame_capture_timestamps"] = None  # Immutable adapter supplies no native clock stamps.
        reference = dict(job_id=JOB_ID, run_id=plan["run_id"], desktop_handle=api.desktop,
                         desktop_name=api.name(api.desktop), station_name=api.name(api.u.GetProcessWindowStation()),
                         process_handle=pi.hProcess, pid=pi.dwProcessId, initial_tid=pi.dwThreadId,
                         desktop_creation_event="desktop_created_creator_terminal")
        state["original_native_reference"] = reference
        journal(events, "original_native_reference", **reference)
        sequence, seen = 0, {}
        while not api.terminal():''')
lo = source.index('            enumeration = api.owned_windows()')
hi = source.index('            if time.perf_counter() - start >= 55:', lo)
source = source[:lo] + '''            sequence += 1
            core = api.owned_windows(reference, sequence, current)
            state["last_core_observation"] = core
            journal(events, "enum_association_core", **core)  # Append + fsync before any diagnostic.
            persisted_at = time.perf_counter()
            state["core_durable_sequence"] = sequence
            state["core_persistence_completed_at"] = persisted_at
            windows = association_rows(core, reference, sequence, seen)
            if not state["first_native_association_rows"]:
                first_window_admissible(windows, start, persisted_at)
            diagnostics = api.thread_desktop_diagnostics(windows or [])
            state["last_thread_desktop_diagnostics"] = diagnostics
            journal(events, "optional_thread_desktop_diagnostics", sequence=sequence,
                    diagnostics=diagnostics, core_persistence_completed_at=persisted_at)
            require_no_diagnostic_conflict(diagnostics, reference["desktop_name"])
            process_live = not api.terminal()  # Same held hProcess, never PID adoption.
            if not process_live:
                raise CaptureBlocked("original hProcess not live at native association admission")
            admission_at = time.perf_counter()
            if not state["first_native_association_rows"]:
                admissible = first_window_admissible(windows, start, admission_at)
            else:
                admissible = bool(windows)
                if core["raw_bool"] and not windows:
                    raise CaptureBlocked("successful enumeration lost prior owned Engine association")
            sample = dict(method=ASSOCIATION_METHOD, sequence=sequence, rows=windows,
                          core_persistence_completed_at=persisted_at, admission_checked_at=admission_at,
                          process_live_at_admission=process_live, admitted=admissible,
                          claim="sampled native association only; no atomic per-frame/no-flash proof")
            if admissible and not state["first_native_association_rows"]:
                state["first_native_association_rows"] = windows
                state["first_native_association_sample"] = sample
            state["last_native_association_sample"] = sample
            journal(events, "native_association_sample", **sample)
''' + source[hi:]
replace('''        if not state["owned_engine_window_observations"]:
            raise CaptureBlocked("engine exited without actual private Engine HWND proof")''', '''        if not state["first_native_association_rows"]:
            raise CaptureBlocked("engine exited without new-method native association proof")''')


def write(name, value):
    with (OUT / name).open("x", encoding="utf-8", newline="\n") as f:
        f.write(value.rstrip("\n") + "\n")


def sha(name):
    return hashlib.sha256((OUT / name).read_bytes()).hexdigest()


write("launcher.py", source)
write("launcher.diff", "".join(difflib.unified_diff(original.splitlines(keepends=True),
      source.splitlines(keepends=True), fromfile="old71958/launcher_v3.py", tofile="new/launcher.py")))
baseline = json.loads((OUT / "source-baseline.json").read_text(encoding="utf-8"))
pins = dict(schema=1, product=baseline["product"], snapshot=baseline["snapshot"],
            files=baseline["files"], published_game_head=baseline["published_game_head"],
            product_head=baseline["product_head"], requirements_sha256=baseline["requirements_sha256"],
            new_method="enum_desktop_windows_callback_v1",
            old_launcher_sha256=sha("inputs/launcher_v3.py"), launcher_sha256=sha("launcher.py"),
            capture_sha256=sha("capture.gd"), root_decision_sha256=sha("inputs/root-decision.json"),
            design_sha256=sha("inputs/design.json"))
write("source-pins.json", json.dumps(pins, ensure_ascii=True, indent=2))
oldplan = json.loads((ROOT / ".planning/deepeye-resume-20261018/game3d-private-desktop-capture-20261024/execution-plan-v3.json").read_text(encoding="utf-8"))
plan = {key: oldplan[key] for key in ["engine", "engine_sha256", "process_budget_seconds", "terminate_threshold_seconds", "first_owned_Engine_HWND_seconds", "allow_fallback", "outer_wrapper_timeout_kill_owner_forbidden", "attempt_budget_is_not_hard_driver_stop_guarantee", "keeper_unknown_owner_must_keep_exec_session"]}
plan.update(schema=1, work_id="A-GAME3D-ENUM-ASSOCIATION-CAPTURE-20261024-v1",
            job_id="child-ff673689f0da408998a3a64ed82abd10", run_id="ff673689-first-and-only-native-run",
            phase="phase1_source_only_await_exact_independent_review_and_root_phase2_authorization",
            association_method="enum_desktop_windows_callback_v1", project=str(ROOT / ".local/deepeye-game3d-enum-association-capture-20261024/product/competition/deepeye/simulator"),
            adapter=str(OUT / "capture.gd"), adapter_sha256=sha("capture.gd"), launcher_sha256=sha("launcher.py"),
            source_pins=str(OUT / "source-pins.json"), source_pins_sha256=sha("source-pins.json"),
            desktop_name="DeepEye_ff673689_1948cb7d7dd742b2bd00d55c76365fb9",
            frames="REPLACED_BY_EXCLUSIVE_ATTEMPT_DIRECTORY", maximum_render_attempts=1,
            optional_import="not authorized", target_native_calls_phase1=0,
            frame_capture_clock="not instrumented in unchanged adapter; unknown; no filesystem-time substitution",
            per_frame_native_freshness_claim=False, no_flash_claim=False)
write("execution-plan.json", json.dumps(plan, ensure_ascii=True, indent=2))
print(json.dumps({n:sha(n) for n in ["launcher.py", "launcher.diff", "capture.gd", "execution-plan.json", "source-pins.json"]}, indent=2))
