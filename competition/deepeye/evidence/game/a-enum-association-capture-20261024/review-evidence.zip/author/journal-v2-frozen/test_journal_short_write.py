"""One new journal-completeness control, with private FileIO short-count seams.

Real partial bytes are retained under shortwrite-<label>/; no target native API,
old controls, diagnostic API, or engine is called. Fsync is a recording seam.
"""
import importlib.util
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

target, label = Path(sys.argv.pop(1)), sys.argv.pop(1)
assert label in ("red", "green")
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("shortwrite_candidate", target)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
directory = OUT / ("shortwrite-" + label)
directory.mkdir()


class Writer:
    def __init__(self, file, mode, trace):
        self.file, self.mode, self.trace = file, mode, trace

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.file.close()

    def write(self, data):
        count = {"none": 5, "zero": 0, "short": len(data)-1, "full": len(data)}[self.mode]
        actual = self.file.write(data[:count])
        assert actual == count, "test artifact write itself was short"
        returned = None if self.mode == "none" else count
        self.trace.update(requested_bytes=len(data), partial_bytes=count, returned_count=returned)
        return returned

    def fileno(self):
        return self.file.fileno()


class WriterPath:
    def __init__(self, writer):
        self.writer = writer

    def open(self, mode, buffering):
        assert mode == "ab" and buffering == 0
        return self.writer


class JournalCompletenessControl(unittest.TestCase):
    def test_short_none_zero_never_reaches_fsync_or_durable_return(self):
        observations = []
        for mode in ("none", "zero", "short", "full"):
            trace = dict(mode=mode, fsync_calls=0, journal_returned=False, error=None)
            file = directory / (mode + ".partial.bin")
            writer = Writer(file.open("xb", buffering=0), mode, trace)

            def fsync(fd):
                trace["fsync_calls"] += 1

            with patch.object(module, "Path", lambda path: WriterPath(writer)), patch.object(module.os, "fsync", fsync):
                try:
                    module.journal("private-test-seam", "core", sequence=1)
                    trace["journal_returned"] = True
                except BaseException as exc:
                    trace["error"] = repr(exc)
            trace["partial_artifact"] = str(file.relative_to(OUT)).replace("\\", "/")
            trace["saved_bytes"] = file.stat().st_size
            observations.append(trace)
        with (OUT / ("shortwrite-"+label+"-observations.json")).open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(observations, stream, ensure_ascii=True, indent=2)
            stream.write("\n")
        for trace in observations:
            with self.subTest(mode=trace["mode"]):
                self.assertEqual(trace["saved_bytes"], trace["partial_bytes"])
                if trace["mode"] == "full":
                    self.assertTrue(trace["journal_returned"])
                    self.assertEqual(trace["fsync_calls"], 1)
                    self.assertIsNone(trace["error"])
                else:
                    self.assertFalse(trace["journal_returned"], "incomplete write incorrectly returned durable success")
                    self.assertEqual(trace["fsync_calls"], 0)
                    self.assertIn("CaptureBlocked", trace["error"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
