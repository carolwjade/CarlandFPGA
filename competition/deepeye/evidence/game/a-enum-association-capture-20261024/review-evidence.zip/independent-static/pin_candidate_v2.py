import hashlib,json,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'.planning/deepeye-resume-20261018/game3d-enum-association-capture-20261024'
G=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024'
PINS={'launcher_v2.py':'61c6de6b82a7c43ee2c8222703fd76fe0b829f6ec9dacfee760f0529a99c910b','launcher-v2.diff':'83eb6751eb8e39e58804002d0e4c36b447a64f00d0838f73a7b4f228e042caf7','execution-plan-v2.json':'bc3bf034f6c62f00808cd82f55fa10fd7603f514be55a67550dd4b68842cb43a','source-pins-v2.json':'45157c72f2be40b50830d506805fb5d94d9093611410e8bab65a81d7cb03a9b1','argv-review-v2.json':'da013a9669c65bb42a344fa76ab693d390d3721683e7d970bf42ac8c3785e589','journal-v2-frozen-manifest.json':'ea4752d21e2ac1332a1139d5f9ec9e60083a7aaa62f00455075d96aa84287db1'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in PINS.items():assert sha(AUTHOR/name)==digest,(name,sha(AUTHOR/name))
wrapper=G/'run_enum_association_capture_once.py'
assert sha(wrapper)=='adf26e5b62c5e246ae94ba993e23d04cd1f1b34ea4cb58424588bbe44d71f1c6'
assert sha(AUTHOR/'capture.gd')=='6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5'
snapshot=OUT/'candidate-v2'
assert not snapshot.exists()
snapshot.mkdir()
for name in PINS:shutil.copyfile(AUTHOR/name,snapshot/name)
shutil.copyfile(wrapper,snapshot/wrapper.name)
(OUT/'candidate-v2-pin-verification.json').write_text(json.dumps({'all_parent_pins_match':True,'files':PINS,'wrapper_sha256':sha(wrapper),'capture_unchanged':True,'candidate_imports_or_execution':0},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_pins_verified':True,'v2_files':len(PINS),'wrapper_unchanged':True,'capture_unchanged':True}))
