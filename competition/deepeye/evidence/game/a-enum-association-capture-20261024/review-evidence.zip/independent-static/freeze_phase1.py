"""Freeze independent static obligations from public inputs only; no new author reads."""
import hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
PUBLIC=ROOT/'.planning/deepeye-resume-20261018/game3d-desktop-association-design-20261024'
DECISION=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024/enum-association-capture-root-design-decision.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
req=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert req=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
assert [r['id'] for r in scope['requirements']]==['H%02d'%i for i in range(1,16)]
transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
assert transfer['status']=='active' and transfer['director_generation']==3
assert transfer['new_director_thread_id']=='01a16988-bdcb-70e1-ae10-1304b5cf7875'
decision=read(DECISION)
assert decision['design_manifest_sha256']==sha(PUBLIC/'artifact-manifest.json')
manifest=read(PUBLIC/'artifact-manifest.json')
assert manifest['member_count']==len(manifest['files'])==23
for rel,pin in manifest['files'].items():
 p=PUBLIC/rel;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],rel
assert decision['later_maximum_actual_Godot_creates']==1 and decision['phase1_actual_Godot_creates']==0
checks=[
 {'id':'P01','oracle':'New ff6736 job/method/config identity and one-create maximum; source-only until later root exact review/phase2 authorization. All old71958 failed bytes/0PNG/budget0 remain immutable; no replay or new-head inheritance.','evidence':'Exact frozen candidate/plan/source/engine pins, invocation/attempt ownership, explicit method name and no import/top-level execution.'},
 {'id':'P02','oracle':'Enum uses the exact non-null original owned HDESK, checked creation/name/WinSta0/noninput identity and live owner. No NULL/current/reopened-by-name substitution; no handle-value-only object identity proof.','evidence':'Creation→held object→Enum argument dataflow, checked Win32 types, unique-name errors and no premature close.'},
 {'id':'P03','oracle':'Independent launcher, creator and original-desktop monitor. Preserve birth lpDesktop, noninherit HDESK, stdio-only allowlist; no switch/station/foreground/display/active fallback.','evidence':'CreateProcess STARTUPINFOEX/flags/types/list lifetime, creator/control separation and before/during/after monitor observations.'},
 {'id':'P04','oracle':'Each actual Enum has its own sequence, original HDESK evidence, raw BOOL/fresh error/callback count/core completion. TRUE alone or count alone never passes; TRUE last-error alone is not failure. FALSEfresh0 is pending, never fabricated successful emptiness; other core errors fail closed.','evidence':'Callback is bound to one native call; all branches retain original status and partial rows, no default success fields.'},
 {'id':'P05','oracle':'Raw HWND/ordinal saved first; then initialized native PID output/TID return/errors and checked Engine class. Owned row requires nonzero TID/PID match plus original hProcess still live. No class-only/PID-only/stale output acceptance.','evidence':'Order of row construction vs fallible calls, PROCESS_INFORMATION/original HANDLE dataflow, checked native returns and failed partial row retention.'},
 {'id':'P06','oracle':'Core/partial/native rows are durable before optional GetThreadDesktop/name diagnostic. Serialization/fsync failure prevents diagnostic/admission; absent diagnostic is unavailable, never expected-name substitution.','evidence':'Actual exception-safe callback/Enum→core journal/fsync→diagnostic control flow; separate raw/core/diagnostic fields and no lost row on later error.'},
 {'id':'P07','oracle':'Core enumeration/ownership/class errors reject; optional diagnostic missing/error is unavailable; successful contradictory name rejects. Error5 cause stays unknown, no unsupported-cross-process/privilege guess.','evidence':'Independent statuses and conflict branch, no broad exception-to-pass conversion or fabricated observed name.'},
 {'id':'P08','oracle':'Same start/clock-domain and15s first proof deadline. Fresh completed core time after required persistence checked before admission; >=15 rejects nonempty rows, diagnostics cannot renew cutoff. A stored first row is historical, not current per-frame evidence.','evidence':'Timestamp/persistence/admission order. Any intervening blocking work before admission needs fresh cutoff check, not a carried-old time. Each poll is recorded independently.'},
 {'id':'P09','oracle':'50ms monitor sampling while process remains live; detect reported identity conflicts and retain unavailable polls. Frames/native rows have distinct timestamps, no atomic per-frame or continuous no-flash claim; no cached first row presented as fresh.','evidence':'Loop/current record sequence, timestamps and report provenance. Do not invent a new per-frame TTL; root expressly permits only separate sampled evidence.'},
 {'id':'P10','oracle':'Original hProcess stop55s/actual wait5s, keeper on unknown, same live exec owner; both child and creator terminal before CloseDesktop. No borrowed close/PID adoption/retry/outer killing timeout. Early creator end alone is allowed while control holds HDESK. No universal hard driver deadline claim.','evidence':'All exception/finally/return paths, positive terminal persistence and close fence; unchanged native layouts/handles or exact reviewed delta.'},
 {'id':'P11','oracle':'Original capture.gd SHA6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5 and52 game sources/full main.tscn/root Window/current camera/Shell CanvasLayer/Run disabled/real windows-vulkan-forward_plus retained.','evidence':'Exact bytes/source pins and argv/backend checks. Association/PNG structure is not actual graphics/native-input/visual/G01G02/H12 acceptance.'}
]
cases=[
 {'id':'O01','facts':'BOOL1,count2,no checked owned raw row','expected':'reject; no association proof'},
 {'id':'O02','facts':'BOOL0,fresh error0,no owned row','expected':'pending only; unchanged15s deadline eventually rejects'},
 {'id':'O03','facts':'nonzero native TID,selfPID,Engine class,original hProcess signaled','expected':'reject as live-owner association; retain raw row'},
 {'id':'O04','facts':'HWND appended then PID/class call fails','expected':'partial raw row durably preserved; core rejects'},
 {'id':'O05','facts':'valid durable core; optional thread desktop NULL/Error5','expected':'diagnostic unavailable; core evaluated by explicit enum method, no invented desktop name/cause'},
 {'id':'O06','facts':'valid core; optional diagnostic returns different valid name','expected':'conflict reject'},
 {'id':'O07','facts':'nonempty owned core completion exactly15s or later','expected':'reject before first admission'},
 {'id':'O08','facts':'core fsync fails; optional diagnostic is available','expected':'do not run/admit diagnostic path as replacement for durable core'},
 {'id':'O09','facts':'first valid row then later unavailable/empty poll; a PNG has separate timestamp','expected':'record current unavailability and historical first-proof separately; never label cached row current/atomic per-frame'},
 {'id':'O10','facts':'terminate/wait unknown or creator still live','expected':'retain same owner/HANDLEs; no exit/replay/close until both positive terminal facts'},
 {'id':'O11','facts':'success enum/PNG but dummy/GL backend or changed capture/game source','expected':'reject source/backend obligations; no formal acceptance'}
]
plan={'schema':1,'work_id':'A-GAME3D-ENUM-ASSOCIATION-REVIEW-20261024-v1','job_id':'child-f10d8e28d3734bb28f9b8f474421c089','phase':1,'requirements_sha256_computed':req,'root_decision_sha256':sha(DECISION),'public_design_sha256':sha(PUBLIC/'design.json'),'public_design_manifest_sha256':sha(PUBLIC/'artifact-manifest.json'),'checks':checks,'static_evidence_oracles':cases,'oracle_cases_are_not_executed_tests':True,'allowed_method':'Static file/hash/AST/diff review only; no candidate imports/tests or target API/runtime calls. Preserve failures before reporting root.','new_author_directory_read':False,'exposure':['This agent authored029d independent design and read Microsoft primary docs. This is not blind review.','This agent read/reviewed old71958 launcher/v2/v3 and oldfailed native receipts, and earlier original game scene/editor sources/API trial under separate completed jobs. Old evidence cannot pass new candidate.','New ff6736 author directory has not been read or listed before this freeze. No current candidate behavior is assumed from the prior design.'],'phase2_requires':'Root exact candidate pins; only then read candidates, compare to this frozen oracle and record actual findings. No native_complete during phase1.','HEAD_index_boundary':'Root public evidence commits may advance HEAD/index legitimately. Only actual52 source bytes and exact execution/candidate pins bind evidence; reviewer does not write product/index.','status':{'H01_H15_full_H12':'preserved/open/unaccepted','G03':'not_run','R03':'not_run','all29':'not_run'},'waiting_for_exact_pins':True}
write('phase1-plan.json',plan)
input_files=[ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json',ROOT/'docs/competition/deepeye-2026/immutable_scope.md',ROOT/'docs/competition/deepeye-2026/immutable_scope.json',DECISION,PUBLIC/'design.json',PUBLIC/'report.md',PUBLIC/'result.json',PUBLIC/'artifact-manifest.json']
write('phase1-input-pins.json',{'inputs':[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)} for p in input_files],'public_design_23_members_reverified':True,'requirements_canonical_sha256':req,'Gen3_active_verified':True,'new_author_read':False})
(OUT/'phase1-report.md').write_text('''# Enum association independent review — phase1 freeze

Fresh native validation allowed this review job. Transfer confirms active Gen3; H01–H15 canonical UTF-8/sorted/compact requirements hash was recomputed and matched. Public029d design23 members were byte/hash reverified, and the root adoption decision was read. The new author directory was not read or listed.

Eleven independent P01–P11 static obligations and eleven adversarial evidence oracles are frozen in phase1-plan.json. The cases are written expectations, not executed tests. They cover exact original HDESK/noninput/birth/live owner, per-call callback raw/partial/error evidence, durable core before optional diagnostics, unavailable/conflict distinction, false-fresh0 pending, original15s fresh admission,50ms sampled-not-atomic evidence, keeper/final close fence and unchanged original capture/52-scene/backend.

This agent authored029d and saw oldv3/failed receipts and original scene APIs, so this is not blind review. Prior design inference and native failures do not establish a new candidate pass. Old71958 remains failed/terminal/0PNG/exhausted. Error5 cause remains unknown. Root's later legal evidence-only HEAD/index publication is not attributed to this review and cannot inherit an earlier execution result to a new head.

No candidate import/test or target Win32/desktop/window/engine/process/board/policy/service/UI invocation occurred. Only this review directory is writable. Phase1 leaves the lease running and awaits root exact pins before any new candidate read. No native_complete yet. H01–H15/fullH12 remain preserved/open; G03/R03/all29 remain not_run.
''',encoding='utf-8')
members={}
for p in sorted(OUT.iterdir()):
 if p.is_file() and p.name not in ['lease.private.json','phase1-manifest.json','phase1-freeze.json']:
  members[p.name]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('phase1-manifest.json',{'schema':1,'files':members,'member_count':len(members),'manifest_self_member':False})
for name,pin in members.items():assert sha(OUT/name)==pin['sha256']
write('phase1-freeze.json',{'all_members_verified':True,'member_count':len(members),'plan_sha256':sha(OUT/'phase1-plan.json'),'input_pins_sha256':sha(OUT/'phase1-input-pins.json'),'manifest_sha256':sha(OUT/'phase1-manifest.json'),'requirements_sha256':req,'new_author_read':False,'candidate_imports_or_tests':0,'target_runtime_invocations':0,'lease_kept_running':True,'waiting_for_exact_pins':True})
print(json.dumps(read(OUT/'phase1-freeze.json')))
