"""Independent source/hash/AST analysis only; never execute candidate functions."""
import ast,difflib,hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'.planning/deepeye-resume-20261018/game3d-enum-association-capture-20261024'
SNAP=OUT/'candidate-original'
OLD=ROOT/'.planning/deepeye-resume-20261018/game3d-desktop-association-design-20261024/inputs/launcher_v3.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
manifest=read(SNAP/'frozen-manifest.json')
assert len(manifest['members'])==manifest['member_count']==37
for m in manifest['members']:
 p=AUTHOR/m['path'];assert p.stat().st_size==m['bytes'] and sha(p)==m['sha256'],m['path']
pins=read(SNAP/'source-pins.json')
assert len(pins['files'])==52
for m in pins['files']:
 for base in [pathlib.Path(pins['product']),pathlib.Path(pins['snapshot'])]:
  p=base/m['path'];assert sha(p)==m['sha256'] and p.stat().st_size==m['bytes'],p
assert sha(OLD)=='34b91a6bf4f3d3f1ce03949c0755e13395f4b014363fc20f1753bf7ad6b19516'
old=OLD.read_text(encoding='utf-8');new=(SNAP/'launcher.py').read_text(encoding='utf-8')
expected=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='old71958/launcher_v3.py',tofile='new/launcher.py'))
assert expected==(SNAP/'launcher.diff').read_text(encoding='utf-8')
(OUT/'reviewer-computed-original.diff').write_text(expected,encoding='utf-8')
def function_map(text):
 result={}
 def visit(node,prefix=''):
  for n in ast.iter_child_nodes(node):
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
    name=prefix+n.name;result[name]={'AST':ast.dump(n,include_attributes=False),'line':n.lineno,'end':n.end_lineno};visit(n,name+'.')
   elif isinstance(n,ast.ClassDef):visit(n,prefix+n.name+'.')
   else:visit(n,prefix)
 visit(ast.parse(text));return result
before=function_map(old);after=function_map(new)
unchanged=[name for name,v in before.items() if name in after and v['AST']==after[name]['AST']]
changed=[name for name,v in before.items() if name in after and v['AST']!=after[name]['AST']]
added=[name for name in after if name not in before];removed=[name for name in before if name not in after]
wrapper_text=(SNAP/'run_enum_association_capture_once.py').read_text(encoding='utf-8')
wrapper=ast.parse(wrapper_text)
wrapper_calls=[{'line':n.lineno,'call':ast.unparse(n.func)} for n in ast.walk(wrapper) if isinstance(n,ast.Call)]
assert len([c for c in wrapper_calls if c['call']=='subprocess.Popen'])==1
assert not [c for c in wrapper_calls if any(c['call'].endswith(x) for x in ['kill','terminate','taskkill','CreateDesktopW','CreateProcessW'])]
journal_line=after['journal']['line'];execute_line=after['execute']['line']
finding={'id':'F05','status':'reported_root_await_resolution','severity':'blocking_P06_durability_gap','launcher_sha256':sha(SNAP/'launcher.py'),'function_line':journal_line,'flow':'journal opens raw FileIO(ab,buffering=0), ignores stream.write(data) return, fsyncs and returns; execute then marks core durable and invokes optional diagnostic','counterexample_is_static_not_executed':'If raw write returns n where0<=n<len(data) without raising, only a prefix is durable but downstream marks the whole core durable. No runtime failure or target API call is claimed.','required_boundary':'Complete all bytes or fail closed before any durable sequence/admission/diagnostic; preserve prefix and original error. No oracle relaxation/product write.'}
write('original-static-analysis.json',{'all_parent_pins_matched':True,'author_frozen_37_members_verified':True,'original_and_new_snapshot_52_sources_verified':True,'reviewer_diff_equal':True,'function_AST_comparison':{'unchanged_count':len(unchanged),'unchanged':unchanged,'changed':changed,'added':added,'removed':removed},'original_finding':finding,'wrapper_static':{'sha256':sha(SNAP/'run_enum_association_capture_once.py'),'Popen_call_count':1,'no_timeout_kill_reopen_retry_of_spawn_found':True,'after_Popen_receipt_error_caught':True,'wait_interrupt_keeps_original_object':True,'exclusive_started_and_output_files_prevent_replay':True,'waited_python_exit_separate_from_Godot_evidence':True,'controls_run_by_reviewer':0},'candidate_imports_tests_and_target_runtime_calls':0,'HEAD_index_boundary':'No product/index write; source bytes only rechecked. Root legal evidence publication is independent.'})
write('original-review-obligation-matrix.json',{'P01':'static conforms: new job, explicit method,ordinal1 only, exclusive attempt; no phase2 execution authorization yet','P02':'static conforms: original non-null HDESK/reference/name/station/noninput checks','P03':'static preserved: native birth/stdio/init and monitor unchanged','P04':'static conforms: native per-sequence BOOL/error/rows accounting, FALSEfresh0 pending, missing raw return rejected','P05':'static conforms: raw HWND first, initialized native DWORD PID/TID and class data, live original hProcess before/after/after diagnostics','P06':'BLOCKED F05: byte-complete persistence not established by unchecked raw write return','P07':'static conforms: unavailable diagnostics separated; successful conflicting name rejects','P08':'static conforms except persistence gap: refreshed after core journal then after diagnostic/live before15s admission','P09':'static conforms: individual sequence records,50ms sleep, historical first association/current sample separated; frame native timestamps null/no atomic claim','P10':'static preserved: keeper/original owner/terminalclose; creator may end early; hard driver deadline not claimed; journal gap also affects durability assumptions in keeper','P11':'static conforms: unchanged capture SHA621046...,52 sources, original fullscene/root/Run disabled/windows-vulkan-forward_plus','all_static_pass':False,'native_runtime_pass':False})
(OUT/'findings-original.md').write_text('''# Original candidate static review — blocking persistence gap

All authorized candidate/wrapper pins matched before source reads. The37 frozen members and original/new snapshot52 source pins were rehashed. Reviewer diff matches the actual oldv3→new source change; no candidate was imported or executed.

F05 (P06): journal uses raw FileIO with buffering=0, ignores the return count of stream.write(data), then fsyncs and returns. A short returned write can leave only a prefix durable while execute marks this sequence complete and runs optional diagnostics. This is a static control-flow counterexample, not an executed short-write test or a claim that the current filesystem failed. The durable-core contract needs full-byte completion or fail-closed propagation before sequence/admission/diagnostic, preserving partial bytes/errors.

The remaining source and root wrapper review found no additional blocker: core/partial rows and native DWORD TID handling, live original HANDLE before/after/afterdiagnostic, unavailable/conflict split,15s fresh checks, independent samples/frame timestamps null, original birth/stdio/creator/control/keeper/close fences, original capture/backend/full52 sources, and one-original-Popen retained through receipt/wait errors are represented correctly at source level. None of these are native/OS/GPU success evidence. Root software controls were not rerun.

Retain original candidate SHA69eaaa76f2a590dcff8d7f41f12c53166e6a20612c47e62b48773e4244c26243 and root wrapper SHAadf26e5b62c5e246ae94ba993e23d04cd1f1b34ea4cb58424588bbe44d71f1c6. Await root exact delta if authorized; do not complete or run this candidate.
''',encoding='utf-8')
print(json.dumps({'verified_members':37,'verified_source_count':52,'unchanged_original_function_ASTs':len(unchanged),'changed_functions':changed,'added_functions':added,'removed_functions':removed,'blocking_findings':['F05'],'reviewer_runtime_calls':0}))
