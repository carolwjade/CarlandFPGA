"""Finalize exact-byte/static review without candidate imports, tests or native calls."""
import ast,difflib,hashlib,json,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'.planning/deepeye-resume-20261018/game3d-enum-association-capture-20261024'
G=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024'
V1=OUT/'candidate-original';V2=OUT/'candidate-v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
manifests={}
for base,name,count in [(V1,'frozen-manifest.json',37),(V2,'journal-v2-frozen-manifest.json',27)]:
 m=read(base/name)
 assert m['member_count']==len(m['members'])==count
 for member in m['members']:
  p=AUTHOR/member['path'];assert p.stat().st_size==member['bytes'] and sha(p)==member['sha256'],member
 manifests[name]={'members':count,'sha256':sha(base/name),'all_actual_members_verified':True}
for name in ['journal-v2-report.md','journal-v2-green-result.json','journal-v2-red-result.json','shortwrite-green-observations.json','shortwrite-red-observations.json']:
 shutil.copyfile(AUTHOR/'journal-v2-frozen'/name,V2/name)
old=(V1/'launcher.py').read_text(encoding='utf-8');new=(V2/'launcher_v2.py').read_text(encoding='utf-8')
diff=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='launcher.py',tofile='launcher_v2.py'))
assert diff==(V2/'launcher-v2.diff').read_text(encoding='utf-8')
(OUT/'reviewer-computed-v2.diff').write_text(diff,encoding='utf-8')
old_tree=ast.parse(old);new_tree=ast.parse(new)
def module_functions(tree):return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
of=module_functions(old_tree);nf=module_functions(new_tree)
assert list(n for n in of if of[n]!=nf.get(n))==['journal']
assert set(of)==set(nf)
new_normalized=ast.parse(new)
old_journal=next(n for n in old_tree.body if isinstance(n,ast.FunctionDef) and n.name=='journal')
old_plan=next(n for n in old_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PLAN' for t in n.targets))
for i,n in enumerate(new_normalized.body):
 if isinstance(n,ast.FunctionDef) and n.name=='journal':new_normalized.body[i]=old_journal
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PLAN' for t in n.targets):new_normalized.body[i]=old_plan
assert ast.dump(new_normalized,include_attributes=False)==ast.dump(old_tree,include_attributes=False)
new_journal=next(n for n in new_tree.body if isinstance(n,ast.FunctionDef) and n.name=='journal')
with_node=next(n for n in new_journal.body if isinstance(n,ast.With))
assert len(with_node.body)==3
assert isinstance(with_node.body[0],ast.Assign) and ast.unparse(with_node.body[0].value)=='stream.write(data)'
guard=with_node.body[1]
assert isinstance(guard,ast.If) and ast.unparse(guard.test)=='written != len(data)' and len(guard.body)==1 and isinstance(guard.body[0],ast.Raise)
assert ast.unparse(with_node.body[2])=='os.fsync(stream.fileno())'
sourcepins=read(V2/'source-pins-v2.json')
assert sourcepins['files']==read(V1/'source-pins.json')['files'] and len(sourcepins['files'])==52
for item in sourcepins['files']:
 for base in [pathlib.Path(sourcepins['product']),pathlib.Path(sourcepins['snapshot'])]:
  p=base/item['path'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],p
capture=AUTHOR/'capture.gd'
assert sha(capture)==sha(V1/'capture.gd')=='6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5'
wrapper=G/'run_enum_association_capture_once.py'
assert sha(wrapper)==sha(V1/wrapper.name)==sha(V2/wrapper.name)=='adf26e5b62c5e246ae94ba993e23d04cd1f1b34ea4cb58424588bbe44d71f1c6'
plan=read(V2/'execution-plan-v2.json')
assert plan['maximum_render_attempts']==1 and plan['association_method']=='enum_desktop_windows_callback_v1'
assert sha(AUTHOR/'launcher_v2.py')==plan['launcher_sha256']
assert sha(AUTHOR/'source-pins-v2.json')==plan['source_pins_sha256']
assert sha(pathlib.Path(plan['engine']))==plan['engine_sha256']
assert sha(pathlib.Path(plan['adapter']))==plan['adapter_sha256']
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
req=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert req=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
write('final-delta-verification.json',{'candidate_imports_or_tests':0,'target_native_calls':0,'author_manifests':manifests,'reviewer_diff_equals_exact_v1_v2_diff':True,'normalized_module_AST_equal_except_PLAN_and_journal':True,'changed_existing_module_function':['journal'],'all_other_function_class_ASTs_equal':True,'no_added_native_calls':True,'partial_count_guard_before_fsync_and_return':True,'shortwrite_behavior_by_static_reading':'None/0/32 against33 bytes raise before fsync;33 continues to fsync. No execution by reviewer.','original52_and_author_snapshot52_hashes_rechecked':True,'unchanged_capture':sha(capture),'unchanged_wrapper':sha(wrapper),'engine_hash_verified':True,'old_F05_original_finding_and_bytes_retained':True,'author_control_records_read_only':'RED/GREEN and8 partial raw byte files hash-verified as27 frozen members; none rerun','HEAD_index':'No product/index write or assumption that legal evidence commits bind earlier native execution.','requirements_sha256':req})
matrix=read(OUT/'original-review-obligation-matrix.json')
matrix['P06']='static conforms in v2: byte-complete count required before fsync/return; failure propagates before durable sequence, diagnostics or admission; partial bytes remain'
matrix['P08']='static conforms: fresh time after complete journal/fsync, first15s check, optional diagnostic/persistence then same-hProcess live and fresh15s check immediately before admission'
matrix['P10']='static conforms: preserved original keeper/native owner/both-terminal-before-close, with journal completeness now guarded; no hard driver-stop guarantee'
matrix['all_static_pass']=True
matrix['native_runtime_pass']=False
matrix['scope']='Source-level satisfaction only, not independently executed API/native tests or formal acceptance.'
write('final-review-obligation-matrix.json',matrix)
finalpins={'launcher_v2.py':sha(V2/'launcher_v2.py'),'execution-plan-v2.json':sha(V2/'execution-plan-v2.json'),'source-pins-v2.json':sha(V2/'source-pins-v2.json'),'argv-review-v2.json':sha(V2/'argv-review-v2.json'),'launcher-v2.diff':sha(V2/'launcher-v2.diff'),'capture.gd':sha(capture),'run_enum_association_capture_once.py':sha(wrapper),'original37_manifest':sha(V1/'frozen-manifest.json'),'journal_delta27_manifest':sha(V2/'journal-v2-frozen-manifest.json')}
write('final-sourcehashes.json',finalpins)
write('result.json',{'schema':1,'work_id':'A-GAME3D-ENUM-ASSOCIATION-REVIEW-20261024-v1','job_id':'child-f10d8e28d3734bb28f9b8f474421c089','outcome':'exact_v2_static_review_complete;F05_resolved;no_additional_static_blocker','P01_P11':'static obligations reviewed; no runtime pass implied','F05':'original short-write gap preserved; v2 requires returned byte count==payload length before fsync/return, without retry/truncation','exactpins':finalpins,'author_manifests_verified_members':[37,27],'game_source_pins_verified':52,'wrapper_static_review_complete':True,'candidate_imports_or_tests':0,'target_native_engine_desktop_window_process_calls':0,'actual_execution_authorized_by_review':False,'later_root_choice':'At most1 Godot create only after root exact authorization and author freshvalidate; review does not run it','old71958':'failed/terminal/0PNG/budget0 retained; Error5 cause unknown','evidence_limits':'Sampled native row method is source-only inference now. Frame native timestamps remain null; no cached per-frame/atomic/no-flash/OS/GPU/PNG/UI/formal acceptance proof.','product_C4_index_cache_policy_author_source_writes':False,'HEAD_index_boundary':'Legal root evidence-only publication is independent; exact source/candidate/runtime pins remain authoritative','requirements_sha256':req,'H01_H15_full_H12':'preserved/open/unaccepted','G03_R03_all29':'not_run'})
report=f'''# Enum desktop association — final independent static review

Exact v2 launcher `{finalpins['launcher_v2.py']}` resolves the confirmed F05/P06 persistence gap. All frozen P01–P11 obligations have been reviewed at source level, with no further static blocker found. This is static completion only: candidate imports/tests and target Win32/desktop/window/engine/process calls by this reviewer were **zero**. Root retains the decision to authorize any later one-time native invocation and acceptance.

## Identity and preserved failures

Fresh native validation allowed this same f10d review before candidate reads and again before v2 review. The original phase1 freeze (11 obligations and11 written evidence oracles) remains intact. This agent authored029d and saw prior original scene/v3 sources and failed receipts; it is not a blind review. No inference or prior result substitutes for a new candidate/runtime record.

All parent original pins, the37 immutable original author members, the new27-member journal delta, original/current52 source bytes and all52 author snapshot bytes were independently rehashed. Full reviewer-generated v3→v1 and v1→v2 diffs matched the supplied diffs. Original v1 SHA69eaaa76f2a590dcff8d7f41f12c53166e6a20612c47e62b48773e4244c26243, the F05 finding, author RED/GREEN traces and raw partial files remain preserved; no old failure was relabeled pass. Old71958 remains failed/terminal/two actual creates/0PNG/budget0; Error5 cause remains unknown.

## F05 correction

Original journal called unbuffered write, ignored its count, then fsynced and returned. A short returned write could therefore be marked durable before optional diagnostics. Root accepted the finding. V2 assigns written, compares it exactly to len(data), and raises CaptureBlocked for any mismatch **before fsync or return**. It makes no retry, overwrite or truncation; existing partial bytes remain. Full writes alone reach fsync; fsync errors still propagate. The caller cannot set its durable sequence or enter optional diagnostics/admission after a rejected write.

The independent normalized module AST comparison shows only PLAN selection and journal changed. Every other function/class AST equals the reviewed v1, including native FFI, core recording/classification, diagnostics, timing/admission, original HANDLE lifecycle/keeper/close, backend and PNG structure checks. No native call was added. Static branch reading gives rejection before fsync for None/0/32 returned against33 bytes, and the existing fsync path for33. The author's new short-write software controls/8 partial byte files were read/hash-bound only; this reviewer did not rerun them or any prior group.

## Frozen obligations and source findings

- **P01–P03:** new ff6736 job, explicit enum_desktop_windows_callback_v1, one future invocation/attempt1 only and exclusive output paths; original non-null held HDESK/reference/name/WinSta0/noninput identity; independent creator/control monitor, exact lpDesktop birth, noninherited desktop and stdio-only whitelist. No switch/station/foreground/display/active fallback path was found. Early creator end is valid while the control owner holds HDESK; both terminals remain required before close.
- **P04–P05:** every real enumeration has its own sequence/raw BOOL/error/rows. Callback ordinal/HWND is appended before fallible native lookups. Freshly initialized PID output, native **DWORD TID return**, checked class text/count/errors and partial exceptions are retained. TRUE/count alone never passes; valid foreign/nonEngine rows remain raw. Missing raw return/type, partial/core error, duplicate/changed HWND identity and nonlive original HANDLE reject. FALSEfresh0 remains unavailable/pending under the original deadline; a successful Enum's error value alone is not failure.
- **P06–P07:** now byte-complete core journal/fsync must finish before optional diagnostic. Missing diagnostic is unavailable with no fabricated observed name; successful conflicting name rejects. Partial raw core remains preserved even when later metadata fails.
- **P08–P09:** same original perf_counter start/15s deadline. Fresh core-persistence time is checked before diagnostics, then diagnostics are recorded and original hProcess checked live, then a refreshed admission time is checked before first accepted state. At/after15s cannot admit nonempty rows. Current polls have independent records; detected identity change or successful loss of a prior Engine rejects.50ms sleep is sampled monitoring, not a guaranteed50ms interval. First association remains historical; unchanged adapter's native frame timestamps are explicitly null, with no filesystem-time/cached-row/per-frame/atomic/no-flash substitution.
- **P10:** original hProcess wait/55s stop/5s actual wait, unknown-owner keeper, same live exec session, no PID adoption/replay and child+creator terminal-before-close are preserved. Borrowed thread-desktop handles are not closed. Unknown native termination can outlive the attempt budget; no hard driver-stop guarantee is claimed.
- **P11:** capture.gd remains `{finalpins['capture.gd']}`. Full original main.tscn/root Window/current camera/WorldEnvironment/lights/World/Shell CanvasLayer and Run/Pause/Continue disablement remain, with30 five-kind instances,16 root viewport PNG paths and actual windows/vulkan/forward_plus checks. Association/PNG structure cannot establish actual rendering, device compatibility or image quality; no runtime images exist for this new job yet.

## Root wrapper

Wrapper `{finalpins['run_enum_association_capture_once.py']}` was read and rehashed unchanged. It checks later exact authorization/job/config/source bindings, reserves exclusive started/stdout/stderr paths and contains one Popen call with CREATE_NO_WINDOW and attempt1. It executes no PS1 or policy change. Receipt-write failure and wait interruption retain the original Popen object and continue waiting; there is no timeout/kill/reopen/adoption/repeated spawn. Terminal Python exit is recorded separately from Godot's native HANDLE evidence. Root's two fake-Popen controls were not rerun or promoted to independent/native evidence.

## Final pins and limits

Plan `{finalpins['execution-plan-v2.json']}`, sourcepins `{finalpins['source-pins-v2.json']}`, argv `{finalpins['argv-review-v2.json']}`, v2 diff `{finalpins['launcher-v2.diff']}`. Original37 manifest `{finalpins['original37_manifest']}`; journal27 manifest `{finalpins['journal_delta27_manifest']}`. Exact details are in final-sourcehashes.json and final-review-obligation-matrix.json.

Only this review directory was written. No product/C4/index/cache/policy/author source was edited. Legal root evidence-only commits may advance HEAD/index independently and cannot inherit an old execution to a new head. The52 byte pins, exact candidate pins and actual future operation record are the identity boundaries.

Root must separately authorize any later native execution after author freshvalidate. Native ABI/binding/keeper behavior, no-flash, GPU/PNG/visual inspection, native input/DPI/200-action UI, full G01/G02, collision/full crossing, sensors/AI/BOOT/clocks and both H12 online chains remain unproven. H01–H15 canonical hash reverified `{req}`; fullH12 preserved/open; G03/R03/all29 remain not_run.
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
excluded={'lease.private.json','artifact-manifest.json','freeze-verification.json','native-complete-request.json','native-complete-response.json'}
files={}
for p in sorted(OUT.rglob('*')):
 if p.is_file() and p.name not in excluded:files[str(p.relative_to(OUT)).replace('\\','/')]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('artifact-manifest.json',{'schema':1,'files':files,'member_count':len(files),'manifest_self_member':False,'excluded_private_and_postfreeze_receipts':sorted(excluded)})
for name,pin in files.items():assert sha(OUT/name)==pin['sha256'] and (OUT/name).stat().st_size==pin['bytes']
write('freeze-verification.json',{'all_members_verified':True,'member_count':len(files),'manifest_sha256':sha(OUT/'artifact-manifest.json'),'report_sha256':sha(OUT/'report.md'),'result_sha256':sha(OUT/'result.json'),'final_sourcehashes_sha256':sha(OUT/'final-sourcehashes.json'),'reviewer_target_runtime_calls':0})
print(json.dumps(read(OUT/'freeze-verification.json')))
