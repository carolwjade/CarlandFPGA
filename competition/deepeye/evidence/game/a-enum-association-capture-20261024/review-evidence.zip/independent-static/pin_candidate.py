"""Verify exact authorized candidate bytes before any source-body reads."""
import hashlib,json,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'.planning/deepeye-resume-20261018/game3d-enum-association-capture-20261024'
G=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024'
PINS={'launcher.py':'69eaaa76f2a590dcff8d7f41f12c53166e6a20612c47e62b48773e4244c26243','launcher.diff':'58b52be646b6a1a03b7baf488a966d5fc4b7133b563b53ea69242c8f2f489f19','execution-plan.json':'67e749221a7c95af8332be1e52fc9d776304040effe17c4077a2d2ea8815d944','source-pins.json':'1716e8fc38a5f683a2e0b3808be4cec4b73dd286ff5597139fc756f128cdb3b8','argv-review.json':'b2d0bdfd5e7c60ed1ff128ee79e1e69dc80af60611fdd39909d87507676c049b','capture.gd':'6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5','frozen-manifest.json':'8ddab9a09fd9f6f1043acbacef351fed906277806497ab08d0ef3a7932b85e8f','phase1-report.md':'fa3364c0353d8130a5155ec9541c278c0452fd44efb7e6926f21de7ef940ccdc'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in PINS.items():assert sha(AUTHOR/name)==digest,(name,sha(AUTHOR/name))
wrapper=G/'run_enum_association_capture_once.py'
assert sha(wrapper)=='adf26e5b62c5e246ae94ba993e23d04cd1f1b34ea4cb58424588bbe44d71f1c6'
snapshot=OUT/'candidate-original'
assert not snapshot.exists()
snapshot.mkdir()
for name in PINS:shutil.copyfile(AUTHOR/name,snapshot/name)
shutil.copyfile(wrapper,snapshot/wrapper.name)
manifest=json.loads((snapshot/'frozen-manifest.json').read_text(encoding='utf-8'))
print(json.dumps({'parent_pins_match':True,'files':{name:{'bytes':(AUTHOR/name).stat().st_size,'sha256':digest} for name,digest in PINS.items()},'wrapper_sha256':sha(wrapper),'manifest_keys':list(manifest),'candidate_imports_or_execution':0}))
(OUT/'candidate-pin-verification.json').write_text(json.dumps({'all_parent_pins_match':True,'files':PINS,'wrapper_sha256':sha(wrapper),'candidate_imports_or_execution':0},indent=2)+'\n',encoding='utf-8')
