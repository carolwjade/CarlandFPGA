# Frozen source only; requires a new explicit root attempt-2 authorization.
$ErrorActionPreference = 'Stop'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PYTHONIOENCODING = 'utf-8'
Set-Location -LiteralPath 'C:\Users\CarlJade\Documents\ChatGPT\FPGA多机协作开发\.local\deepeye-game3d-private-desktop-capture-20261024'
if (Test-Path -LiteralPath 'C:\Users\CarlJade\Documents\ChatGPT\FPGA多机协作开发\.planning\deepeye-resume-20261018\game3d-private-desktop-capture-20261024\attempt2-wrapper-exit.json') { throw 'exclusive wrapper exit receipt already exists; refuse replay' }
& 'C:\Users\CarlJade\Documents\ChatGPT\FPGA多机协作开发\.local\venv\Scripts\python.exe' -B -X utf8 'C:\Users\CarlJade\Documents\ChatGPT\FPGA多机协作开发\.planning\deepeye-resume-20261018\game3d-private-desktop-capture-20261024\launcher_v3.py' --execute-reviewed --attempt 2
$pythonExitCode = $LASTEXITCODE
try {
    $receipt = [ordered]@{schema=1; attempt=2; observed_python_exit_code=$pythonExitCode; killing_timeout_wrapper=$false; interpretation='direct Python returned; no Godot exit or cleanup inference'}
    $bytes = [System.Text.UTF8Encoding]::new($false).GetBytes(($receipt | ConvertTo-Json) + "`n")
    $stream = [System.IO.FileStream]::new('C:\Users\CarlJade\Documents\ChatGPT\FPGA多机协作开发\.planning\deepeye-resume-20261018\game3d-private-desktop-capture-20261024\attempt2-wrapper-exit.json', [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
    try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
} catch {
    [Console]::Error.WriteLine('wrapper exit receipt persistence failed: ' + $_.Exception.Message)
}
exit $pythonExitCode
