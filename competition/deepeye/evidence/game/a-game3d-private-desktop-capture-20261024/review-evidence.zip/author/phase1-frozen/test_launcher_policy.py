"""New private controls: fake native boundary only, no Win32 or engine calls."""
import importlib.util
import sys
import unittest
from pathlib import Path

FILE = Path(__file__).with_name("launcher.py")


class Bootstrap(unittest.TestCase):
    def test_launcher_exists(self):
        self.assertTrue(FILE.exists(), "new launcher module has not been implemented")


@unittest.skipUnless(FILE.exists(), "new launcher absent during initial RED")
class Policy(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location("private_capture_launcher", FILE)
        cls.module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = cls.module
        spec.loader.exec_module(cls.module)

    def test_actual_window_thread_requires_positive_exact_binding(self):
        for observed in (None, "", "Default", "other"):
            with self.subTest(observed=observed):
                with self.assertRaises(self.module.CaptureBlocked):
                    self.module.require_private_binding(observed, "DeepEye_private")
        self.module.require_private_binding("DeepEye_private", "DeepEye_private")

    def test_suspended_absence_remains_pending_with_actual_error(self):
        self.assertTrue(hasattr(self.module, "suspended_observation"), "pending pre-Resume observation policy absent")
        value = self.module.suspended_observation(None, "DeepEye_private", "GetThreadDesktop returned NULL; last_error=0")
        self.assertEqual(value["status"], "pending")
        self.assertEqual(value["observed"], None)
        self.assertEqual(value["error"], "GetThreadDesktop returned NULL; last_error=0")
        self.assertNotEqual(value["status"], "verified")
        with self.assertRaises(self.module.CaptureBlocked):
            self.module.suspended_observation("Default", "DeepEye_private", None)

    def test_changed_input_desktop_is_a_permanent_stop_reason(self):
        self.module.require_same_input("Default", "Default")
        with self.assertRaises(self.module.CaptureBlocked):
            self.module.require_same_input("Default", "Winlogon")

    def test_argv_never_silently_falls_back_or_imports(self):
        plan = {"engine":"engine.exe", "project":"project", "adapter":"capture.gd", "frames":"frames"}
        argv = self.module.render_argv(plan)
        self.assertNotIn("--headless", argv)
        self.assertNotIn("--editor", argv)
        self.assertNotIn("--import", argv)
        self.assertEqual(argv[argv.index("--rendering-driver")+1], "vulkan")
        self.assertEqual(argv[argv.index("--rendering-method")+1], "forward_plus")
        self.assertIn("--disable-render-loop", argv)

    def test_cleanup_never_closes_desktop_with_live_creator_or_child(self):
        self.assertEqual(self.module.cleanup_decision(child_terminal=False, creator_terminal=True), "retain")
        self.assertEqual(self.module.cleanup_decision(child_terminal=True, creator_terminal=False), "retain")
        self.assertEqual(self.module.cleanup_decision(child_terminal=True, creator_terminal=True), "close_owned")


if __name__ == "__main__":
    unittest.main(verbosity=2)
