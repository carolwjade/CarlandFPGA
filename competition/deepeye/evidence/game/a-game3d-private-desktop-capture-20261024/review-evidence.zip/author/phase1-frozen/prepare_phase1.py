"""Phase 1 source copy/pins/argv only. No native API or engine execution."""
import hashlib
import json
from pathlib import Path
import subprocess
import uuid

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCT = ROOT / ".local/deepeye-implementation-a"
SPACE = ROOT / ".local/deepeye-game3d-private-desktop-capture-20261024"
BASE = "360b102b299849a24a0b8cb2b6592f64f475e611"
ENGINE = ROOT / ".planning/deepeye-implementation-a/app-worker-ui/godot/Godot_v4.7.2-stable_win64.exe"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.run(["git","-C",str(PRODUCT),*args],check=True,capture_output=True).stdout


def save(name, value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")


scope = json.loads((ROOT/"docs/competition/deepeye-2026/immutable_scope.json").read_text(encoding="utf-8"))
contract = digest(json.dumps(scope["requirements"],ensure_ascii=False,sort_keys=True,separators=(",",":")).encode())
assert contract == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
transfer = json.loads((ROOT/".planning/deepeye-desktop-handoff-20261015/transfer.json").read_text(encoding="utf-8"))
assert transfer["director_generation"]==3 and transfer["status"]=="active"
assert not SPACE.exists(), "No old directory adoption or replacement"
SPACE.mkdir()
files = [v for v in git("ls-files","-z","--","competition/deepeye/simulator").decode().split("\0") if v]
assert len(files)==50
files += ["competition/deepeye/docs/resource_contract.json","competition/deepeye/docs/interface.json"]
pins = []
for relative in files:
    source = PRODUCT/relative
    assert not source.is_symlink() and source.resolve().is_relative_to(PRODUCT.resolve())
    data = source.read_bytes()
    assert data == git("show",BASE+":"+relative), relative
    target = SPACE/"product"/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open("xb") as stream:
        stream.write(data)
    assert target.read_bytes()==data
    pins.append(dict(path=relative,bytes=len(data),sha256=digest(data)))
save("source-pins.json",dict(schema=1,product=str(PRODUCT),snapshot=str(SPACE/"product"),published_game_head=BASE,actual_product_head=git("rev-parse","HEAD").decode().strip(),requirements_sha256=contract,files=pins))
engine_hash = digest(ENGINE.read_bytes())
assert engine_hash == "ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424"
plan = dict(schema=1,work_id="A-GAME3D-PRIVATE-DESKTOP-CAPTURE-20261024-v1",job_id="child-71958a7341174c76a4132dcb9a364a46",phase="phase1_frozen_await_root_review_not_execution_authorization",engine=str(ENGINE),engine_sha256=engine_hash,project=str(SPACE/"product/competition/deepeye/simulator"),adapter=str(OUT/"capture.gd"),adapter_sha256=digest((OUT/"capture.gd").read_bytes()),launcher_sha256=digest((OUT/"launcher.py").read_bytes()),source_pins=str(OUT/"source-pins.json"),source_pins_sha256=digest((OUT/"source-pins.json").read_bytes()),desktop_name="DeepEye_71958a734117_"+uuid.uuid4().hex,frames="REPLACED_BY_EXCLUSIVE_ATTEMPT_DIRECTORY",maximum_render_attempts=2,process_budget_seconds=60,terminate_threshold_seconds=55,first_owned_Engine_HWND_seconds=15,optional_import="not_run; only after actual dependency failure and separate explicit root instruction",allow_fallback=False)
save("execution-plan.json",plan)
import importlib.util
spec=importlib.util.spec_from_file_location("private_capture_plan_launcher",OUT/"launcher.py")
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)  # Definitions only; no Win32 instance or executable invoked.
save("argv-review.json",dict(render_template=module.render_argv(plan),launcher_invocation_after_later_root_authorization=["PYTHON","-B",str(OUT/"launcher.py"),"--execute-reviewed","--attempt","1"],phase1_native_calls=0,phase1_engine_invocations=0,root_window_only=True,subviewport=False))
print(json.dumps(dict(snapshot_files=len(pins),contract=contract,engine_sha256=engine_hash,phase1_native_calls=0)))
