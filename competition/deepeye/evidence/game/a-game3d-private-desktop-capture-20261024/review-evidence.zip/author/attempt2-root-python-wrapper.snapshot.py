"""Run the exact reviewed Python program directly; do not execute a PS1 file.

No killing timeout. The original native keeper must retain its live exec session.
This wrapper grants no additional Godot invocation or fallback.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import os

P = Path(__file__).resolve().parent
R = P.parents[2]
A = P.parent/'game3d-private-desktop-capture-20261024'
S = R/'.local/deepeye-game3d-private-desktop-capture-20261024'
pins = {
    'launcher_v3.py':'34b91a6bf4f3d3f1ce03949c0755e13395f4b014363fc20f1753bf7ad6b19516',
    'capture.gd':'6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5',
    'execution-plan-v3.json':'4806bc2e92cd9a8dc7fbfe3feffc1f65aa978e3300aab5fb808f6262576e798f',
    'source-pins-v3.json':'9e9aa25e1931a78121c11af56bc18e1bd89949d4412ab06eebe7a29b4849374d'}
for name,wanted in pins.items():
    assert hashlib.sha256((A/name).read_bytes()).hexdigest()==wanted,name
first=json.loads((A/'attempt-01/receipt.json').read_bytes())
assert all(first[key] is True for key in ('child_terminal','creator_terminal','owned_handles_closed'))
assert not (A/'attempt-02').exists()
assert not (P/'attempt2-python-wrapper-started.json').exists()

def record(name,value):
    with (P/name).open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2)
        f.write('\n');f.flush();os.fsync(f.fileno())

argv=[str(R/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(A/'launcher_v3.py'),'--execute-reviewed','--attempt','2']
record('attempt2-python-wrapper-started.json',dict(utc=datetime.now(timezone.utc).isoformat(),
    job_id='child-71958a7341174c76a4132dcb9a364a46',argv=argv,cwd=str(S),
    creationflags=subprocess.CREATE_NO_WINDOW,killing_timeout=False,
    PowerShell_script_execution=False,source_pins=pins))
child=subprocess.Popen(argv,cwd=S,creationflags=subprocess.CREATE_NO_WINDOW)
try:
    record('attempt2-python-wrapper-child.json',dict(pid=child.pid,
        meaning='original Popen child; PID is descriptive and is never reopened/adopted'))
except Exception as error:
    print('WRAPPER_CHILD_RECEIPT_ERROR '+repr(error),flush=True)
code=child.wait()  # Original Popen native HANDLE; no timeout/kill/reopen/retry.
try:
    record('attempt2-python-wrapper-exit.json',dict(pid=child.pid,
        actual_python_exit_code=code,utc=datetime.now(timezone.utc).isoformat(),
        killing_timeout=False,Godot_exit_code='read separately from original launcher receipt'))
except Exception as error:
    print('WRAPPER_EXIT_RECEIPT_ERROR '+repr(error),flush=True)
print('CAPTURE_PYTHON_RETURN '+str(code),flush=True)
sys.exit(code)
