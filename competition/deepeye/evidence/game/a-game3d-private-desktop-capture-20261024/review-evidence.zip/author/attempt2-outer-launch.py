"""Root-authorized final invocation wrapper; no timeout, retries, or kill.

The only child command is the already-frozen PowerShell script. Inherited tool
pipes carry keeper output immediately; an unknown owner keeps this session alive.
"""
import json
import os
from pathlib import Path
import subprocess
import sys


OUT = Path(__file__).resolve().parent
argv = [str(Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"),
        "-NoProfile", "-NonInteractive", "-File", str(OUT / "attempt2-wrapper-v3.ps1")]
flags = subprocess.CREATE_NO_WINDOW


def persist(name, facts):
    with (OUT / name).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(facts, stream, ensure_ascii=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


persist("attempt2-outer-started.json", dict(phase="powershell_create_started_unknown",
    argv=argv, creationflags=flags, creationflags_name="CREATE_NO_WINDOW",
    outer_python_pid=os.getpid(), timeout=None, stdout="inherited tool pipe",
    stderr="inherited tool pipe", stdin="DEVNULL", additional_engine_attempts=0))
child = subprocess.Popen(argv, creationflags=flags, stdin=subprocess.DEVNULL)
try:
    persist("attempt2-outer-child.json", dict(phase="powershell_created",
        powershell_pid=child.pid, owner_python_pid=os.getpid()))
except BaseException as exc:
    print("OUTER_RECEIPT_ERROR " + repr(exc), file=sys.stderr, flush=True)
while True:
    try:
        code = child.wait()  # No timeout and no terminate/kill, including keeper.
        break
    except BaseException as exc:
        print("OUTER_WAIT_CONTINUES " + repr(exc), file=sys.stderr, flush=True)
try:
    persist("attempt2-outer-exit.json", dict(phase="powershell_returned",
        powershell_pid=child.pid, observed_powershell_exit_code=code,
        interpretation="PowerShell wrapper exit only; inspect its Python receipt and Godot receipt separately"))
except BaseException as exc:
    print("OUTER_EXIT_RECEIPT_ERROR " + repr(exc), file=sys.stderr, flush=True)
raise SystemExit(code)
