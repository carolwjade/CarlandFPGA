"""F04 pure classification only: no Win32 object, engine, sleep, or old controls.

Mutations caught: treating FALSE/0 as empty/success; ignoring native FALSE/error
or callback exceptions; rejecting TRUE due to undefined last-error residue; or
admitting first-window evidence at the original 15-second equality boundary.
The rows below are synthetic policy input, never native-window evidence.
"""
import importlib.util
from pathlib import Path
import sys
import unittest


target = Path(sys.argv.pop(1)) if len(sys.argv) > 1 else Path(__file__).with_name("launcher_v3.py")
spec = importlib.util.spec_from_file_location("f04_policy_target", target)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)  # Import defines ctypes structures; no Win32().


def raw(result, error=0, rows=None, exceptions=None):
    return dict(raw_bool=result, fresh_last_error=error, callback_count=1,
                owned_rows=[] if rows is None else rows,
                callback_exceptions=[] if exceptions is None else exceptions)


class F04PureControls(unittest.TestCase):
    def policy(self, observation):
        self.assertTrue(callable(getattr(module, "enum_rows_from_observation", None)),
                        "F04 raw enum classification is absent")
        return module.enum_rows_from_observation(observation)

    def test_false_zero_is_pending_and_never_admits_raw_rows(self):
        observation = raw(0, rows=[{"hwnd": "synthetic-not-evidence"}])
        self.assertIsNone(self.policy(observation))
        self.assertEqual(observation["owned_rows"], [{"hwnd": "synthetic-not-evidence"}])
        self.assertFalse(module.first_window_admissible(None, 100, 114.999))
        with self.assertRaises(module.CaptureBlocked):
            module.first_window_admissible(None, 100, 115)

    def test_false_nonzero_and_callback_exception_fail(self):
        self.assertTrue(callable(getattr(module, "enum_rows_from_observation", None)),
                        "F04 raw enum classification is absent")
        with self.assertRaises(OSError) as raised:
            self.policy(raw(0, error=5))
        self.assertEqual(raised.exception.errno, 5)
        for result, error in ((0, 0), (1, 0), (1, 122)):
            with self.subTest(result=result, error=error):
                with self.assertRaises(module.CaptureBlocked):
                    self.policy(raw(result, error, exceptions=["synthetic callback failure"]))

    def test_true_preserves_rows_and_undefined_error_then_original_deadline(self):
        rows = [{"desktop": "synthetic-private"}]
        observation = raw(1, error=122, rows=rows)
        accepted = self.policy(observation)
        self.assertEqual(accepted, rows)
        self.assertEqual(observation["fresh_last_error"], 122)
        self.assertTrue(module.first_window_admissible(accepted, 100, 114.999))
        with self.assertRaises(module.CaptureBlocked):
            module.first_window_admissible(accepted, 100, 115)
        with self.assertRaises(module.CaptureBlocked):
            module.require_private_binding("foreign", "synthetic-private")


if __name__ == "__main__":
    unittest.main(verbosity=2)
