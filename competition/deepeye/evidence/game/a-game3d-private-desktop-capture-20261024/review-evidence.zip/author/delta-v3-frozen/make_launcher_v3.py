"""Source-only F04 delta generation; never instantiates Win32 or runs an engine."""
import difflib
import hashlib
import json
from pathlib import Path


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
source = (OUT / "launcher_v2.py").read_text(encoding="utf-8")
assert hashlib.sha256(source.encode()).hexdigest() == "ecc927b019ffd7145e7177b71248c9ed8776009cdb9875ad372fbc2f25f493ff"
original = source


def replace(before, after):
    global source
    assert source.count(before) == 1, before
    source = source.replace(before, after)


replace('PLAN = OUT / "execution-plan-v2.json"', 'PLAN = OUT / "execution-plan-v3.json"')
replace('def remember_owned_facts(api, state):\n', '''def enum_rows_from_observation(observation):
    """Pure F04 gate. None is unavailable/pending, never an empty enumeration.

    TRUE's last-error has no failure meaning; preserve it in the raw record only.
    FALSE plus a fresh nonzero error, or any callback exception, always fails.
    """
    if observation["callback_exceptions"]:
        raise CaptureBlocked("private window identity observation failed: " + observation["callback_exceptions"][0])
    if not observation["raw_bool"]:
        if observation["fresh_last_error"]:
            raise OSError(observation["fresh_last_error"], "EnumDesktopWindows owned desktop only")
        return None
    return observation["owned_rows"]


def remember_owned_facts(api, state):
''')
replace('''    def owned_windows(self):
        rows = []
        errors = []
        callback_type = C.WINFUNCTYPE(W.BOOL, W.HWND, W.LPARAM)
        def visit(hwnd, parameter):
            try:''', '''    def owned_windows(self):
        rows = []
        errors = []
        callback_count = 0
        callback_type = C.WINFUNCTYPE(W.BOOL, W.HWND, W.LPARAM)
        def visit(hwnd, parameter):
            nonlocal callback_count
            callback_count += 1
            try:''')
replace('''        callback = callback_type(visit)
        self.check(self.u.EnumDesktopWindows(self.desktop, C.cast(callback,C.c_void_p), 0), "EnumDesktopWindows owned desktop only")
        if errors:
            raise CaptureBlocked("private window identity observation failed: " + errors[0])
        return rows''', '''        callback = callback_type(visit)
        callback_pointer = C.cast(callback, C.c_void_p)
        C.set_last_error(0)
        raw_bool = self.u.EnumDesktopWindows(self.desktop, callback_pointer, 0)
        fresh_last_error = C.get_last_error()
        return dict(raw_bool=int(raw_bool), fresh_last_error=fresh_last_error,
                    callback_count=callback_count, owned_rows=rows,
                    callback_exceptions=errors)''')
replace('''            windows = api.owned_windows()
            for window in windows:''', '''            enumeration = api.owned_windows()
            state["last_owned_desktop_enumeration"] = enumeration
            journal(events, "owned_desktop_enum_raw", **enumeration)
            windows = enum_rows_from_observation(enumeration)
            for window in windows or ():''')


def write_new(name, value):
    with (OUT / name).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(value.rstrip("\n") + "\n")


def sha(name):
    return hashlib.sha256((OUT / name).read_bytes()).hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=True, indent=2) + "\n"


write_new("launcher_v3.py", source)
write_new("launcher-v3.diff", "".join(difflib.unified_diff(
    original.splitlines(keepends=True), source.splitlines(keepends=True),
    fromfile="launcher_v2.py", tofile="launcher_v3.py")))

# This script is frozen for later review only. It is NOT invoked by this maker.
# No outer timeout or child-process wrapper may kill an unknown keeper owner.
wrapper = '''# Frozen source only; requires a new explicit root attempt-2 authorization.
$ErrorActionPreference = 'Stop'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PYTHONIOENCODING = 'utf-8'
Set-Location -LiteralPath '__SPACE__'
if (Test-Path -LiteralPath '__EXIT__') { throw 'exclusive wrapper exit receipt already exists; refuse replay' }
& '__PYTHON__' -B -X utf8 '__LAUNCHER__' --execute-reviewed --attempt 2
$pythonExitCode = $LASTEXITCODE
try {
    $receipt = [ordered]@{schema=1; attempt=2; observed_python_exit_code=$pythonExitCode; killing_timeout_wrapper=$false; interpretation='direct Python returned; no Godot exit or cleanup inference'}
    $bytes = [System.Text.UTF8Encoding]::new($false).GetBytes(($receipt | ConvertTo-Json) + "`n")
    $stream = [System.IO.FileStream]::new('__EXIT__', [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
    try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
} catch {
    [Console]::Error.WriteLine('wrapper exit receipt persistence failed: ' + $_.Exception.Message)
}
exit $pythonExitCode
'''
for marker, path in {
    "__SPACE__": ROOT / ".local/deepeye-game3d-private-desktop-capture-20261024",
    "__PYTHON__": ROOT / ".local/venv/Scripts/python.exe",
    "__LAUNCHER__": OUT / "launcher_v3.py",
    "__EXIT__": OUT / "attempt2-wrapper-exit.json",
}.items():
    assert "'" not in str(path)
    wrapper = wrapper.replace(marker, str(path))
write_new("attempt2-wrapper-v3.ps1", wrapper)

pins = json.loads((OUT / "source-pins-v2.json").read_text(encoding="utf-8"))
pins["delta_v3"] = {
    "scope": "F04 EnumDesktopWindows immediate raw return/error and pending classification only",
    "old_launcher_v2_sha256": sha("launcher_v2.py"),
    "launcher_v3_sha256": sha("launcher_v3.py"),
    "capture_unchanged_sha256": sha("capture.gd"),
    "attempt2_wrapper_sha256": sha("attempt2-wrapper-v3.ps1"),
    "attempt1_receipt_preserved_sha256": sha("attempt-01/receipt.json"),
    "attempt1_error_122_native_attribution": "unproven: preceding normal name-size probe could leave stale last-error",
    "attempt1_tool_exit_1_attribution": "shell/tool result only; actual Python and Godot exit codes unobserved",
}
write_new("source-pins-v3.json", encoded(pins))

plan = json.loads((OUT / "execution-plan-v2.json").read_text(encoding="utf-8"))
plan.update(phase="source_only_v3_frozen_await_root_delta_review_no_attempt2_authorization",
            launcher_sha256=sha("launcher_v3.py"), source_pins=str(OUT / "source-pins-v3.json"),
            source_pins_sha256=sha("source-pins-v3.json"),
            reviewed_attempt2_wrapper=str(OUT / "attempt2-wrapper-v3.ps1"),
            reviewed_attempt2_wrapper_sha256=sha("attempt2-wrapper-v3.ps1"),
            enum_false_zero="unavailable_pending; raw rows never admitted; original 15s deadline unchanged",
            enum_false_nonzero="fail", enum_callback_exception="fail",
            enum_true_last_error="raw diagnostic only; successful rows still require original binding/deadline")
write_new("execution-plan-v3.json", encoded(plan))
write_new("argv-review-v3.json", encoded({
    "not_executed": True, "requires_new_explicit_root_authorization": True,
    "wrapper": str(OUT / "attempt2-wrapper-v3.ps1"),
    "wrapper_sha256": sha("attempt2-wrapper-v3.ps1"),
    "python_argv": [str(ROOT / ".local/venv/Scripts/python.exe"), "-B", "-X", "utf8",
                    str(OUT / "launcher_v3.py"), "--execute-reviewed", "--attempt", "2"],
    "cwd": str(ROOT / ".local/deepeye-game3d-private-desktop-capture-20261024"),
    "outer_killing_timeout": False, "unknown_keeper_session_must_remain_alive": True,
    "remaining_render_invocations": 1, "optional_import_authorized": False,
}))
print(json.dumps({n: sha(n) for n in ["launcher_v3.py", "execution-plan-v3.json",
    "source-pins-v3.json", "launcher-v3.diff", "attempt2-wrapper-v3.ps1", "capture.gd"]}, indent=2))
