"""Build only the authorized F02/F03 delta; never execute native code."""
import hashlib
from pathlib import Path

OUT = Path(__file__).resolve().parent
old = (OUT / "launcher.py").read_bytes()
assert hashlib.sha256(old).hexdigest() == "4d9c0746912047c9b932b83a986343f20cc910e5f365c31d8d22c7fbc0516287"
source = old.decode("utf-8")


def replace(before, after):
    global source
    assert source.count(before) == 1, before
    source = source.replace(before, after)


replace('PLAN = OUT / "execution-plan.json"', 'PLAN = OUT / "execution-plan-v2.json"')
helpers = '''def keeper_required(child_terminal, creator_terminal):
    return child_terminal is not True or creator_terminal is not True


def keeper_transition(state, child_observation, creator_observation):
    """Pure lifecycle gate: positive terminal facts latch; unknown never releases."""
    if state.get("keeper_entry_durable") is not True:
        raise CaptureBlocked("keeper entry must be durable before observing/releasing")
    if child_observation is True:
        state["child_terminal"] = True
    if creator_observation is True:
        state["creator_terminal"] = True
    return "wait_owned" if keeper_required(state["child_terminal"], state["creator_terminal"]) else "cleanup_eligible"


def first_window_admissible(windows, started_at, observation_completed_at):
    if observation_completed_at - started_at >= 15:
        raise CaptureBlocked("first actual owned Engine HWND observation completed at/after original 15s deadline")
    return bool(windows)


def remember_owned_facts(api, state):
    state["desktop_handle"] = api.desktop
    if api.child:
        state.update(pid=api.child.dwProcessId, tid=api.child.dwThreadId,
                     process_handle=api.child.hProcess, thread_handle=api.child.hThread)


def persist_keeper_snapshot(events, attempt, event, state):
    """Append/fsync facts and a new exclusive receipt; preserve partial failures."""
    serial = state.get("keeper_receipt_serial", 0) + 1
    state["keeper_receipt_serial"] = serial
    journal(events, event, **state)
    file = attempt / ("keeper-%06d.json" % serial)
    with file.open("x", encoding="utf-8", newline="\\n") as stream:
        json.dump(state, stream, ensure_ascii=True, indent=2)
        stream.write("\\n")
        stream.flush()
        os.fsync(stream.fileno())


def keep_owner_until_terminal(api, creator, creator_errors, state, events, attempt):
    """Retain this exact API/HANDLE/thread owner. Never terminate, reopen or replay.

    The external exec session MUST remain alive; never give this owner a killing
    wrapper timeout. Interrupts/errors here cannot unwind unknown ownership.
    No native wait/observation follows admission until unknown facts are durable.
    """
    state["phase"] = "keeper_unknown_owner_retained"
    state["keeper_owner_pid"] = os.getpid()  # Identity only, never used to reopen/adopt.
    state["keeper_entry_durable"] = False
    state["outer_timeout_must_not_kill_owner"] = True
    state["failure"] = state["failure"] or "terminal unknown; original owner retained"
    while True:
        try:
            remember_owned_facts(api, state)
            if state["keeper_entry_durable"] is not True:
                persist_keeper_snapshot(events, attempt, "keeper_unknown_entry", state)
                state["keeper_entry_durable"] = True
                print("PRIVATE_CAPTURE_KEEPER " + json.dumps(dict(
                    owner_pid=state["keeper_owner_pid"], phase=state["phase"],
                    receipt=str(attempt / ("keeper-%06d.json" % state["keeper_receipt_serial"])),
                    outer_timeout_must_not_kill_owner=True)), flush=True)
            before = {key: state.get(key) for key in ("child_terminal", "creator_terminal", "desktop_handle", "pid", "tid", "process_handle", "thread_handle", "keeper_observation_error", "creator_errors_late")}
            child_observed = state["child_terminal"]
            if child_observed is not True:
                try:
                    child_observed = api.terminal()  # Only the original HANDLE.
                except BaseException as exc:
                    child_observed = None
                    state["keeper_observation_error"] = repr(exc)
            creator_observed = creator is None or not creator.is_alive()
            state["creator_errors_late"] = list(creator_errors)
            remember_owned_facts(api, state)
            action = keeper_transition(state, child_observed, creator_observed)
            changed = any(state.get(key) != value for key, value in before.items())
            if changed or action == "cleanup_eligible":
                persist_keeper_snapshot(events, attempt, "keeper_observation", state)
            if action == "cleanup_eligible":
                state["phase"] = "keeper_later_positive_terminal_recorded"
                return  # Both positives are durable; caller may try cleanup once.
        except BaseException as exc:
            # Keep original owner even on persistence/console/native-query errors.
            state["keeper_internal_error"] = repr(exc)
        try:
            time.sleep(1)  # Ordinary retained-process supervision, no model polling.
        except BaseException as exc:
            state["keeper_wait_interrupted"] = repr(exc)


'''
replace('def render_argv(plan):\n', helpers + 'def render_argv(plan):\n')
replace('journal(events, "reserved_before_native_effects", work_id=WORK_ID, argv=render_argv(plan), desktop=plan["desktop_name"], timeout_seconds=60)',
        'journal(events, "reserved_before_native_effects", work_id=WORK_ID, argv=render_argv(plan), desktop=plan["desktop_name"], attempt_budget_seconds=60, stop_request_seconds=55, forced_terminal_guarantee=False)')
replace('start = time.perf_counter()  # Includes suspended precheck; reserve 5s for owned stop.',
        'start = time.perf_counter()  # Attempt budget only; no promise a driver can be forcibly stopped in 60s.')
replace('''            if windows and not state["owned_engine_window_observations"]:
                state["owned_engine_window_observations"] = windows
                journal(events, "first_owned_engine_windows_verified", windows=windows)
            if not state["owned_engine_window_observations"] and time.perf_counter()-start >= 15:
                raise CaptureBlocked("first actual owned Engine HWND not verified within 15s")''',
'''            observation_completed_at = time.perf_counter()
            if not state["owned_engine_window_observations"]:
                state["last_first_window_raw_observation"] = dict(
                    windows=windows, completed_at=observation_completed_at,
                    elapsed_seconds=observation_completed_at-start, admitted=False)
                if first_window_admissible(windows, start, observation_completed_at):
                    state["owned_engine_window_observations"] = windows
                    state["last_first_window_raw_observation"]["admitted"] = True
                    journal(events, "first_owned_engine_windows_verified", windows=windows,
                            observation_completed_at=observation_completed_at,
                            elapsed_seconds=observation_completed_at-start)''')
replace('raise CaptureBlocked("render invocation timeout")', 'raise CaptureBlocked("attempt stop threshold reached; actual terminal must be observed")')
replace('''        try:
            api.close_owned(child_terminal=state["child_terminal"], creator_terminal=state["creator_terminal"])
            state["owned_handles_closed"] = True
        except BaseException as exc:
            state["cleanup_error"] = repr(exc)''',
'''        if keeper_required(state["child_terminal"], state["creator_terminal"]):
            keep_owner_until_terminal(api, creator, creator_error, state, events, attempt)
        try:
            api.close_owned(child_terminal=state["child_terminal"], creator_terminal=state["creator_terminal"])
            state["owned_handles_closed"] = True
        except BaseException as exc:
            state["cleanup_error"] = repr(exc)
            state["failure"] = state["failure"] or "owned close failed: " + repr(exc)''')
with (OUT / "launcher_v2.py").open("x", encoding="utf-8", newline="\n") as stream:
    stream.write(source)
print(hashlib.sha256(source.encode()).hexdigest())
