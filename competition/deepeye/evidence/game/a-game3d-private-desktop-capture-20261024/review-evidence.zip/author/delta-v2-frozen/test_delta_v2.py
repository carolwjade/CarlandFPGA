"""Only new F02 keeper lifecycle/F03 first-window pure controls. No native seam."""
import importlib.util
import sys
import unittest
from pathlib import Path

FILE = Path(__file__).with_name("launcher_v2.py")


class Bootstrap(unittest.TestCase):
    def test_delta_module_exists(self):
        self.assertTrue(FILE.exists(), "limited F02/F03 delta not implemented")


@unittest.skipUnless(FILE.exists(), "v2 absent for initial RED")
class Delta(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location("private_capture_v2", FILE)
        cls.m = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = cls.m
        spec.loader.exec_module(cls.m)

    def test_unknown_admits_keeper_and_known_terminal_does_not(self):
        for child, creator in ((False,False),(False,True),(True,False)):
            with self.subTest(child=child, creator=creator):
                self.assertTrue(self.m.keeper_required(child,creator))
        self.assertFalse(self.m.keeper_required(True,True))

    def test_keeper_cannot_observe_or_release_before_durable_entry(self):
        state = dict(child_terminal=False,creator_terminal=False,keeper_entry_durable=False)
        with self.assertRaises(self.m.CaptureBlocked):
            self.m.keeper_transition(state,True,True)
        self.assertFalse(state['child_terminal'])
        self.assertFalse(state['creator_terminal'])

    def test_later_real_terminal_is_recordable_but_unknown_cannot_release(self):
        state = dict(child_terminal=False,creator_terminal=False,keeper_entry_durable=True)
        self.assertEqual(self.m.keeper_transition(state,None,False),'wait_owned')
        self.assertEqual(self.m.keeper_transition(state,True,False),'wait_owned')
        self.assertTrue(state['child_terminal'])
        self.assertFalse(state['creator_terminal'])
        self.assertEqual(self.m.keeper_transition(state,None,True),'cleanup_eligible')
        self.assertTrue(state['child_terminal'])
        self.assertTrue(state['creator_terminal'])

    def test_first_window_completion_obeys_original_deadline_before_admission(self):
        self.assertTrue(self.m.first_window_admissible([{'hwnd':7}],100.0,114.999))
        self.assertFalse(self.m.first_window_admissible([],100.0,114.999))
        for elapsed, windows in ((15.0,[{'hwnd':7}]),(15.001,[{'hwnd':7}]),(15.0,[])):
            with self.subTest(elapsed=elapsed, windows=windows):
                with self.assertRaises(self.m.CaptureBlocked):
                    self.m.first_window_admissible(windows,100.0,100.0+elapsed)


if __name__ == '__main__':
    unittest.main(verbosity=2)
