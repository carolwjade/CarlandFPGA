# Final failure seal — private desktop full-scene capture

Job `child-71958a7341174c76a4132dcb9a364a46`, canonical `/root/pc_direct_window`, is closed for collection by root after **two actual Godot creates, zero accepted Engine HWNDs and zero PNGs**. No further engine/desktop execution, import, fallback or source correction is authorized in this job. This seal records failure, not GPU/render availability or image quality.

| Recorded operation | Actual inner launcher / Godot calls | Result |
|---|---:|---|
| attempt 1, reviewed v2 | 1 / 1 | Enum false-return check raised stored `OSError(122, ...)`; terminal/closed |
| PowerShell final-attempt packaging | 0 / 0 | ExecutionPolicy prevented PS1 content; PowerShell PID 460 returned 1 |
| attempt 2, reviewed v3 via root direct-Python wrapper | 1 / 1 | Callback identity failure; terminal/closed |

Attempt 1's BOOL=0 is inferable from the reviewed v2 BOOL return and false-check branch; the exact raw BOOL was not independently journaled. Stored last-error 122 was not cleared before Enum and could remain from an earlier normal name-size probe. Its attribution to Enum's native failure/root cause is **unproven**. The old records remain unchanged; this is their interpretive limit.

F04 attempt 2 durably recorded twelve `FALSE / fresh_error=0 / callback_count=0` observations as unavailable/pending, without accepting rows. The thirteenth record was `TRUE / fresh_error=0 / callback_count=2`, owned rows empty, callback exception `OSError(5, 'missing object handle')`. The reviewed callback passes GetThreadDesktop's result to name; no handle reached name. The callback-exception gate failed closed. No accepted HWND/thread binding was obtained, and no extra native diagnosis was run. Godot stdout contains only its 4.7.2 banner; stderr is empty. Actual backend, device and Godot exit remain unknown.

Both attempts' original HANDLE wait/close receipts positively record child_terminal, creator_terminal and owned_handles_closed. Attempt-1 Godot PID/TID = 25240/13564; attempt-2 = 27252/41332. Neither entered keeper; no live exec session remains. Attempt-2 launcher Python PID 23800 was observed returning **2** by root wrapper's original Popen wait. The shared tool/shell returned **1**, which is a separate layer. Attempt-1 Python exit and both Godot exit codes were not observed. Root outer-wrapper Python exit was not independently observed. The PowerShell policy block is separately counted, never promoted to an inner invocation or unknown native replay.

Input desktop was sampled as Default before, during and after both attempts (one during sample in attempt 1; thirteen in attempt 2). This does **not** prove continuously unchanged input desktop, no flash, or continuous display nonoccupation. Original private desktop creation/configuration records are preserved, but do not substitute for the missing accepted window/render proof.

Fresh final integrity hashing confirms 52 original and 52 snapshot source files, C4, Git index, original six cache files and the empty snapshot cache are unchanged. Original 19-member, v2 17-member and v3 21-member freezes (57 members total), every failed/unknown/raw record and both attempt trees are retained. Root authorizations, reviewed direct wrapper and three Popen receipts have explicit byte-for-byte snapshots listed in `final-source-pins.json`; root originals were not edited. Source bytes correspond to published game head 360b102b; current product HEAD is recorded separately. The engine binary is pinned, not copied.

`final-result.json` and schema-1 `final-manifest.json` bind this failure outcome and all small local evidence. `final-archive-include.json` provides an optional root archive list, excluding lease secrets, engine and product/cache copies; no archive was built. The terminal service receipt is separate from the immutable seal. H01–H15/full H12 and requirements SHA `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` remain preserved. No GPU, image-quality, full G01/G02, H12, UI input/DPI/physics/collision or all29 acceptance follows; G03/R03/all29 remain not_run. A different proof method requires root design/review and a new job.
