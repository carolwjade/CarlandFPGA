"""Static text/AST/hash analysis only. Never import or execute the candidate."""
import ast,hashlib,json,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'.planning/deepeye-resume-20261018/game3d-private-desktop-capture-20261024'
COPY=OUT/'candidate-original'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
manifest=json.loads((COPY/'phase1-frozen-manifest.json').read_text(encoding='utf-8'))
verified=[]
for m in manifest['members']:
 p=AUTHOR/m['path']
 assert p.stat().st_size==m['bytes'] and sha(p)==m['sha256'],m['path']
 verified.append(m)
assert len(verified)==manifest['member_count']==19
for name in ['phase1-report.md','argv-review.json']:
 shutil.copyfile(AUTHOR/'phase1-frozen'/name,COPY/name)
sourcepins=json.loads((COPY/'source-pins.json').read_text(encoding='utf-8'))
assert len(sourcepins['files'])==52
for item in sourcepins['files']:
 for base in [pathlib.Path(sourcepins['product']),ROOT/'.local/deepeye-game3d-private-desktop-capture-20261024/product']:
  assert sha(base/item['path'])==item['sha256'],str(base/item['path'])
text=(COPY/'launcher.py').read_text(encoding='utf-8')
tree=ast.parse(text,filename='candidate-original/launcher.py')
calls=[]
for n in ast.walk(tree):
 if isinstance(n,ast.Call):calls.append({'line':n.lineno,'call':ast.unparse(n.func)})
forbidden=['SwitchDesktop','SetThreadDesktop','SetProcessWindowStation','SetForegroundWindow','BringWindowToTop','SetActiveWindow','ChangeDisplaySettings','CreateWindow','DestroyWindow']
matches=[c for c in calls if any(c['call'].endswith(v) for v in forbidden)]
assert not matches
findings=[
 {'id':'F01','classification':'extra_frozen_oracle_order_not_met; root_declares_no_lifecycle_defect','lines':[346,366],'facts':'Creator joins and terminates before Godot spawn; original frozen S07 placed Godot terminal before creator end. Launcher control retains the created HDESK until both are terminal; creator ending does not destroy the desktop.','parent_resolution':'Root explicitly narrows S06/S07 to Godot and creator both terminal before CloseDesktop; no unnecessary creator residency required. Preserve original freeze mismatch.','requires_product_or_author_fix':False},
 {'id':'F02','classification':'confirmed_lifecycle_defect; root_accepted','lines':[300,304,306,308,409,450,468],'condition':'TerminateProcess fails or 5s Wait does not establish terminal; final terminal() remains false.','trace':['terminate_owned raises and termination_error is recorded','close_owned rejects child_terminal=False, records cleanup_error','receipt preserves unknown but execute returns 2','main raises SystemExit; launcher process exits and loses its native HANDLE owner'],'impact':'The local variables do not retain native handles after owner process exit. Unknown side effects are recorded but live ownership is not preserved. Original candidate should not execute.','requires_product_or_author_fix':True},
 {'id':'F03','classification':'concrete_static_deadline_order_counterexample; root_decision_pending','lines':[385,392],'condition':'First observed owned Engine window appears in a monitoring iteration whose elapsed time is >=15s, e.g. 15.01s.','trace':['windows is nonempty','code first assigns owned_engine_window_observations','subsequent deadline condition checks not observations and is false'],'impact':'Late first-window evidence bypasses the stated 15s first-window deadline. No candidate/probe was executed.','requires_product_or_author_fix':'root_decides'}
]
write('static-review-original.json',{'candidate_launcher_sha256':sha(COPY/'launcher.py'),'candidate_capture_sha256':sha(COPY/'capture.gd'),'phase1_frozen_19_members_verified':True,'original_and_author_snapshot_52_source_pins_verified':True,'candidate_AST_parsed':True,'candidate_imported':False,'candidate_executed':False,'target_runtime_invocations':0,'forbidden_native_calls_found':matches,'findings':findings,'static_assessments':{'S01':'exact original pins and 19 immutable members verified','S02':'independent CLI guarded Win32 instantiation; creator/control threads separate','S03':'WinSta0/fresh name precheck/noninherit HDESK/no switch; precheck race cannot be excluded by static source','S04':'STARTUPINFOEX cb/types, explicit lpDesktop, suspended/extended/unicode/no-console flags and three stdio handle allowlist; no HDESK in list','S05':'pre-Resume NULL pending kept raw; post-Resume only owned desktop Engine HWND with PID/tid/actual thread desktop checked; F03 deadline gap','S06':'F02 blocks final static disposition; original F01 extra-order mismatch retained','S07':'CloseDesktop guarded by child+creator terminal; F02 owner-exit exception path defeats retention','S08':'complete original PackedScene into root Window; original camera and Shell; Run disabled','S09':'16 original root texture captures; actual windows/vulkan/forward_plus checks; finite draws/readback; no fallback; runtime/visual success unproven','S10':'immutable attempts, journal/raw stdio receipts and image metadata planned; raw errors preserved; no actual outputs yet'}})
write('author-frozen-and-source-verification.json',{'immutable_members':verified,'member_count':len(verified),'manifest_sha256':sha(COPY/'phase1-frozen-manifest.json'),'sourcepins_sha256':sha(COPY/'source-pins.json'),'source_count':52,'all_original_and_snapshot_bytes_match':True})
write('parent-order-clarification.json',{'base_plan_sha256':'8b85409cc1c2d66b0613e8d8a2bee79fbcb246ef6b6fcd01975dd88ff434d748','original_frozen_order_not_met':True,'root_resolution':'Creator may end before spawn while launcher control retains HDESK. Required close fence is both Godot and creator terminal before CloseDesktop. Early creator end is not a defect by itself.','do_not_claim_original_10_groups_all_pass':True,'F02_independent_owner_loss_still_valid':True})
(OUT/'findings-original.md').write_text('''# Original candidate static findings

Exact original launcher 4d9c0746912047c9b932b83a986343f20cc910e5f365c31d8d22c7fbc0516287 is preserved. No candidate import, policy test, Win32 call or target runtime was executed by this reviewer.

F02 is a confirmed lifecycle defect accepted by root: failed/unconfirmed termination leads to close_owned refusing closure, but execute returns and main exits, discarding the supposedly retained HANDLE owner. Merely leaving Python fields populated cannot retain handles after process exit. This candidate should not execute.

F03 is a static first-window deadline counterexample pending root decision: code stores first nonempty window observations before checking `not observations and elapsed>=15`; an initial window observation at15.01s therefore avoids failure. It is a control-flow finding, not an executed probe.

F01 records an extra frozen oracle order mismatch, not a confirmed native lifecycle defect. Root clarified that the creator may end before spawn while the control thread retains HDESK, and requires both Godot and creator terminal before CloseDesktop. The original freeze is retained; no claim that all ten original groups passed is made.

The remaining original code uses explicit WinSta0 birth binding, three stdio-only inherited handles, owned-desktop first Engine HWND/tid checks, original root Window/main.tscn, preserved Run disablement and16 expected root viewport PNG paths. No active/dummy/GL fallback was found. These are static observations; ABI, actual binding, GPU/PNG/no-flash and formal G01/G02/H12 remain unproven. Await root exact correction pins before final delta review and native_complete.
''',encoding='utf-8')
print(json.dumps({'original_findings':[(v['id'],v['classification']) for v in findings],'immutable_author_members':19,'source_pins':52,'target_runtime_invocations':0}))
