"""Static-only final checks and evidence freeze; no candidate imports or execution."""
import ast,difflib,hashlib,json,pathlib,shutil,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'.planning/deepeye-resume-20261018/game3d-private-desktop-capture-20261024'
PRODUCT=ROOT/'.local/deepeye-implementation-a'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def git(*a):return subprocess.check_output([GIT,'-C',str(PRODUCT),*a])
old=OUT/'candidate-original';new=OUT/'candidate-v2'
verified_manifests={}
for name,count in [('phase1-frozen-manifest.json',19),('delta-v2-frozen-manifest.json',17)]:
 manifest=read(AUTHOR/name)
 assert manifest['member_count']==len(manifest['members'])==count
 for pin in manifest['members']:
  p=AUTHOR/pin['path'];assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],pin
 verified_manifests[name]={'sha256':sha(AUTHOR/name),'members':count,'all_verified':True}
for n in ['delta-v2-report.md','delta-final-result.json','argv-review-v2.json']:
 shutil.copyfile(AUTHOR/'delta-v2-frozen'/n,new/n)
orig=(old/'launcher.py').read_text(encoding='utf-8');v2=(new/'launcher_v2.py').read_text(encoding='utf-8')
old_tree=ast.parse(orig);v2_tree=ast.parse(v2)
def functions(tree):return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
of=functions(old_tree);nf=functions(v2_tree)
changed=[n for n in of if of[n]!=nf.get(n)]
added=[n for n in nf if n not in of]
assert changed==['execute'],changed
assert set(added)=={'keeper_required','keeper_transition','first_window_admissible','remember_owned_facts','persist_keeper_snapshot','keep_owner_until_terminal'}
assert of['Win32']==nf['Win32'],'Native bindings/birth/close methods must be unchanged'
assert sha(new/'capture.gd')==sha(old/'capture.gd')=='6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5'
computed=''.join(difflib.unified_diff(orig.splitlines(keepends=True),v2.splitlines(keepends=True),fromfile='launcher.py@4d9c0746',tofile='launcher_v2.py'))
assert computed==(new/'launcher-v2.diff').read_text(encoding='utf-8'),'Saved diff must describe exact bytes after newline normalization'
(OUT/'reviewer-computed-v2.diff').write_text(computed,encoding='utf-8')
oldpins=read(old/'source-pins.json');pins=read(new/'source-pins-v2.json')
assert pins['files']==oldpins['files'] and len(pins['files'])==52
for item in pins['files']:
 for base in [PRODUCT,pathlib.Path(pins['snapshot'])]:
  p=base/item['path'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
plan=read(new/'execution-plan-v2.json')
for field in ['engine','engine_sha256','project','adapter','adapter_sha256','desktop_name','maximum_render_attempts','first_owned_Engine_HWND_seconds','allow_fallback']:
 assert plan[field]==read(old/'execution-plan.json')[field],field
assert sha(pathlib.Path(plan['engine']))==plan['engine_sha256']
assert sha(pathlib.Path(plan['adapter']))==plan['adapter_sha256']
assert sha(AUTHOR/'launcher_v2.py')==plan['launcher_sha256']
assert sha(AUTHOR/'source-pins-v2.json')==plan['source_pins_sha256']
base=read(OUT/'product-phase1-pins.json')
def inventory(basepath):
 return [{'path':str(p.relative_to(PRODUCT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(basepath.rglob('*')) if p.is_file()] if basepath.exists() else []
c4=[]
for rel in ['competition/deepeye/ai_pc','competition/deepeye/evidence/ai','competition/deepeye/tests/ai']:c4.extend(inventory(PRODUCT/rel))
integrity={'head':git('rev-parse','HEAD').decode().strip(),'index_sha256':sha(pathlib.Path(base['index_path'])),'C4':c4,'original_cache':inventory(PRODUCT/'competition/deepeye/simulator/.godot'),'dirty_gitattributes_sha256':sha(PRODUCT/'docs/competition/deepeye-2026/.gitattributes'),'status':git('status','--short').decode()}
for key in integrity:assert integrity[key]==base[key],key
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
req=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert req=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
native_calls=[]
for n in ast.walk(v2_tree):
 if isinstance(n,ast.Call):
  name=ast.unparse(n.func)
  if any(name.endswith(x) for x in ['SwitchDesktop','SetThreadDesktop','SetProcessWindowStation','SetForegroundWindow','BringWindowToTop','SetActiveWindow','ChangeDisplaySettings']):native_calls.append({'line':n.lineno,'call':name})
assert not native_calls
write('final-static-verification.json',{'candidate_AST_only':True,'candidate_imports':0,'candidate_tests_run':0,'target_runtime_invocations':0,'author_test_result_read_only':read(new/'delta-final-result.json'),'manifests':verified_manifests,'changed_existing_function_or_class':changed,'added_functions':added,'Win32_native_binding_and_process_close_class_AST_unchanged':True,'capture_original_bytes_unchanged':True,'reviewer_diff_equals_author_diff':True,'original_and_snapshot_source_count':52,'all_52_pins_rechecked':True,'protected_integrity':integrity,'requirements_canonical_sha256':req,'no_forbidden_native_calls_found':True,'author_attempt_directories_present':[p.name for p in AUTHOR.glob('attempt-*') if p.is_dir()]})
result={'schema':1,'job_id':'child-17df76fcdbbc4e12b1f98fe30a70d89a','work_id':'A-GAME3D-PRIVATE-DESKTOP-CAPTURE-REVIEW-20261024-v1','outcome':'scoped_static_review_finished; F02/F03 corrected_in_v2; runtime_not_proven','final_launcher_sha256':sha(new/'launcher_v2.py'),'capture_sha256':sha(new/'capture.gd'),'plan_sha256':sha(new/'execution-plan-v2.json'),'sourcepins_sha256':sha(new/'source-pins-v2.json'),'author_original_manifest_sha256':sha(old/'phase1-frozen-manifest.json'),'author_delta_manifest_sha256':sha(new/'delta-v2-frozen-manifest.json'),'F01':'original extra creator-order oracle mismatch retained; explicit root clarification requires both terminals before close, not creator residency','F02':'static resolved: unknown child/creator enters retained-owner keeper before cleanup/return; original objects/HANDLEs held; durable admission and positive terminal recording precede cleanup eligibility; exceptions/interrupts remain in keeper','F03':'static resolved: original15s deadline compared with fresh completed-observation time before any accepted first-window evidence; >=15s rejects and raw admitted=false retained','limits':'No candidate imports/tests/Win32/desktop/window/GPU/engine invocation by reviewer. Static checks do not prove ABI, actual desktop binding/no flash, hard kernel/driver stop deadline, keeper behavior, rendering, PNGs or UI. Root must retain exec owner on unknown and decide any actual execution.','no_original_10_groups_all_pass_claim':True,'native_or_engine_execution_authorized_by_review':False,'reviewer_runtime_invocations':0,'author_pure_controls':'Read saved five-control exit0 result only; not rerun and not native proof','protected_source_integrity':'Original and independent snapshot52 pins, product head/index/C4/cache/dirty bytes unchanged','H01_H15_full_H12':'preserved/open/unaccepted','G03_R03_all29':'not_run'}
write('result.json',result)
report=f'''# Private desktop capture — final independent static review

The exact v2 launcher `{sha(new/'launcher_v2.py')}` resolves the two confirmed source-level findings F02 and F03 in the reviewed control flow. No further static blocker was found in this limited delta. This is **static completion only**, not authorization or proof of native execution. Windows desktop binding/no-flash, native ABI, keeper operation, GPU, real images and formal acceptance remain unverified.

## Exact evidence and review method

Phase1 froze ten obligations before reading author code. Parent-supplied original pins were checked before source reads, and the original candidate is preserved under candidate-original. Its19-member immutable manifest was verified. V2 pins were checked before reads and preserved under candidate-v2; the17-member delta manifest was also fully verified. Reviewer-generated diff equals the author's frozen diff. AST comparison finds only existing execute changed, six new keeper/deadline helper functions, and the PLAN selector change. The entire Win32 class (ctypes layouts/bindings, birth setup, wait/termination/close methods) is AST-identical. capture.gd remains original SHA `{sha(new/'capture.gd')}`.

No candidate was imported or executed, no author pure controls were rerun, and no target Win32, desktop, window, engine, GPU or UI invocation occurred. Hash/AST/text work is the review method. The author's saved five-control exit0 result is a read-only software claim; it is not independent native evidence.

## Findings and resolutions

**F02, confirmed original lifecycle defect:** the original candidate could record unknown child terminal, refuse close, then return and SystemExit, losing its native HANDLE owner. In v2, either unknown child or creator terminal enters keep_owner_until_terminal before close/return. The same API object, HANDLEs and creator reference remain held by the same launcher. Entry facts are append/fsynced plus an exclusive receipt before further observation. Only positive terminal observations latch, and changed/cleanup-eligible facts are persisted before return to the close fence. Persistence/console/query/interrupt errors remain inside the keeper; it does not spawn/reopen/adopt/reterminate/retry. Both positive terminals are required before close. Close failure remains a failure. This fixes the identified control-flow loss; it does not prove actual native behavior. The external exec session must remain alive on a keeper receipt, without a killing wrapper timeout. The60s setting is attempt/stop-request accounting, not a guaranteed bound on a blocked kernel/driver or failed termination.

**F03, confirmed original first-window deadline bug:** the original stored the first window list before checking whether observations were empty and late. V2 records the raw completed observation with admitted=false, refreshes perf_counter after enumeration/binding checks, and compares against the original15s deadline **before admission**. A completion at or after15s raises even for a nonempty HWND list. Earlier positive evidence is not renewed by later samples. The code was read, not executed with fake/native clocks.

**F01, extra original oracle order mismatch:** the original frozen S06/S07 placed Godot terminal before creator end. Actual architecture ends the creator first while the control thread retains HDESK. Root explicitly clarified that early creator end does not destroy the held desktop and is not itself a lifecycle defect; Windows/task close safety requires Godot and creator both terminal before CloseDesktop. Original freeze and mismatch remain preserved. This report does not claim all ten original oracle groups passed unchanged.

## Preserved static obligations

- Dedicated launcher process, separate creator/control threads; creator's desktop association does not alter Codex/root. Control stays on its original desktop and monitors input identity. Before/after samples do not prove absence of changes between samples.
- WinSta0 name is checked, unique name precheck rejects existing/unexpected-error cases, HDESK is non-inheritable, and no desktop switching/station/foreground/display mutation call was found. A name precheck is not an atomic freshness guarantee against an external race.
- CreateProcessW uses explicit WinSta0/name lpDesktop, suspended/extended/unicode/no-console flags, correctly typed STARTUPINFOEX and a stable whitelist containing only the three owned stdio handles. No HDESK is inherited. Missing pre-Resume thread association is raw pending; it is not a fabricated success. The first actual self-PID Engine HWND/tid is checked inside the owned desktop after Resume.
- Process HANDLE waits and a55s stop threshold are preserved, with actual terminal required before closure. Borrowed GetThreadDesktop and initial desktop handles are not closed. The keeper prevents this identified unknown-result return path; root must preserve its live owner if invoked.
- Original main.tscn is fully instantiated in the original root Window/Viewport, preserving WorldEnvironment/lights/current Camera3D/World/Shell CanvasLayer and original Run/Pause/Continue disablement. API placement/camera calls construct30 five-kind instances. No toy/SubViewport substitute or product geometry/material/gate edit was found.
- Static render arguments/checks require real windows/vulkan/forward_plus, with no fallback. capture plans16 root texture PNGs (1080p/1440p × six axes/iso/drill), finite force_draw/readback and actual dimensions/backend/device/UI/camera facts. Launcher validates structure/dimensions only; actual images still require root inspection. There are currently no runtime frames or native observations to accept.

Original/current and author snapshot52 source pins rechecked equal, and product head/index/three C4 files/six original cache files/dirty gitattributes/git status remain unchanged. H01–H15 canonical requirements rehash is `{req}`. Original source exposure, public-primary research exposure and historical G02 context are disclosed in the phase1 freeze; no historical result is used as current runtime proof.

## Scope left open

Root owns any subsequent fresh validate and one-time native execution decision. This review neither starts that operation nor certifies no-flash, actual binding/cleanup, real Vulkan device compatibility, PNG quality, native mouse/keyboard/DPI,200-action UI, authority collision/full crossing, sensors/AI/BOOT/physical clocks, either H12 online chain or full G01/G02. Full H12 and H01–H15 remain preserved/open; G03/R03/all29 remain not_run.
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
write('final-sourcehashes.json',{'launcher_v2.py':sha(new/'launcher_v2.py'),'capture.gd':sha(new/'capture.gd'),'execution-plan-v2.json':sha(new/'execution-plan-v2.json'),'source-pins-v2.json':sha(new/'source-pins-v2.json'),'launcher-v2.diff':sha(new/'launcher-v2.diff'),'original_19_manifest':sha(old/'phase1-frozen-manifest.json'),'delta_17_manifest':sha(new/'delta-v2-frozen-manifest.json'),'product_head':integrity['head'],'original52':pins['files']})
excluded={'lease.private.json','artifact-manifest.json','freeze-verification.json','native-complete-request.json','native-complete-response.json'}
members={}
for p in sorted(OUT.rglob('*')):
 if p.is_file() and p.name not in excluded:
  members[str(p.relative_to(OUT)).replace('\\','/')]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('artifact-manifest.json',{'schema':1,'files':members,'member_count':len(members),'manifest_self_member':False,'excluded_private_and_postfreeze_files':sorted(excluded)})
for rel,pin in members.items():
 p=OUT/rel;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256']
write('freeze-verification.json',{'all_members_verified':True,'member_count':len(members),'manifest_sha256':sha(OUT/'artifact-manifest.json'),'report_sha256':sha(OUT/'report.md'),'result_sha256':sha(OUT/'result.json'),'final_sourcehashes_sha256':sha(OUT/'final-sourcehashes.json'),'runtime_invocations':0})
print(json.dumps(read(OUT/'freeze-verification.json')))
