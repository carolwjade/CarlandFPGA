import hashlib,json,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'.planning/deepeye-resume-20261018/game3d-private-desktop-capture-20261024'
EXPECTED={'launcher_v2.py':'ecc927b019ffd7145e7177b71248c9ed8776009cdb9875ad372fbc2f25f493ff','execution-plan-v2.json':'c9e0f4f6068b72fb3771af028d653a88657595328f2002fdd5a5762a38c1e967','source-pins-v2.json':'cf5a9cec9b117797769fbb4ab014226b1c76b39812ed5553218722698209d675','launcher-v2.diff':'487f92f1d1db18461e0e72212974a2abdbf6d986276d28ccadb965824b63f141','delta-v2-frozen-manifest.json':'411a0ff8e0bf7ebfab8c93e081853faacf1b43d0a759f64758a5f7b1d9307912','capture.gd':'6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins={}
for name,digest in EXPECTED.items():
 p=AUTHOR/name
 assert sha(p)==digest,(name,sha(p))
 pins[name]={'sha256':digest,'bytes':p.stat().st_size}
snapshot=OUT/'candidate-v2'
assert not snapshot.exists(),'Do not overwrite candidate'
snapshot.mkdir()
for name in EXPECTED:shutil.copyfile(AUTHOR/name,snapshot/name)
data={'all_parent_pins_equal':True,'files':pins,'candidate_imported_or_executed':False,'target_runtime_invocations':0}
(OUT/'candidate-v2-verification.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data))
