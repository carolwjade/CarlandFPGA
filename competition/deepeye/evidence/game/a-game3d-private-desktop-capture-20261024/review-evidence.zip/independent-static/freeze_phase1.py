"""Read and pin public inputs; no author import, Win32 calls or target launch."""
import hashlib,json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
RESEARCH=ROOT/'.planning/deepeye-resume-20261018/game3d-hidden-entry-research-20261024'
PRODUCT=ROOT/'.local/deepeye-implementation-a'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def git(*args):return subprocess.check_output([GIT,'-C',str(PRODUCT),*args])
scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
req=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert req=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
assert [r['id'] for r in scope['requirements']]==['H%02d'%i for i in range(1,16)]
primary=[]
for manifest in ['primary-source-pins.json','additional-primary-source-pins.json']:
 data=json.loads((RESEARCH/manifest).read_text(encoding='utf-8'))
 for pin in data['sources']:
  p=RESEARCH/pin['file']
  assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256']
  primary.append({'path':str(p.relative_to(ROOT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p),'url':pin['url']})
current=[]
paths=git('ls-files','competition/deepeye/simulator').decode().splitlines()+['competition/deepeye/docs/resource_contract.json','competition/deepeye/docs/interface.json']
assert len(paths)==52
for rel in paths:
 p=PRODUCT/rel
 assert p.read_bytes()==git('show','HEAD:'+rel),rel
 current.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p),'HEAD_equal':True})
index=pathlib.Path(git('rev-parse','--git-path','index').decode().strip())
if not index.is_absolute():index=PRODUCT/index
def inventory(base):
 return [{'path':str(p.relative_to(PRODUCT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(base.rglob('*')) if p.is_file()] if base.exists() else []
c4=[]
for rel in ['competition/deepeye/ai_pc','competition/deepeye/evidence/ai','competition/deepeye/tests/ai']:c4.extend(inventory(PRODUCT/rel))
write('product-phase1-pins.json',{'head':git('rev-parse','HEAD').decode().strip(),'files':current,'index_path':str(index.resolve()),'index_sha256':sha(index),'C4':c4,'original_cache':inventory(PRODUCT/'competition/deepeye/simulator/.godot'),'dirty_gitattributes_sha256':sha(PRODUCT/'docs/competition/deepeye-2026/.gitattributes'),'status':git('status','--short').decode()})
inputs=[]
for rel in ['AGENTS.md','.agents/skills/fpga-multi-node/SKILL.md','.agents/skills/fpga-multi-node/skill-role.json','.agents/skills/fpga-multi-node/references/protocol.md','.agents/skills/pynq-z2-single-node/SKILL.md','.agents/skills/pynq-z2-single-node/skill-role.json','.planning/deepeye-desktop-handoff-20261015/transfer.json','docs/competition/deepeye-2026/immutable_scope.md','docs/competition/deepeye-2026/immutable_scope.json']:
 p=ROOT/rel;inputs.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
for name in ['report.md','primary-source-pins.json','additional-primary-source-pins.json','input-source-pins.json','official-documents-readback.json']:
 p=RESEARCH/name;inputs.append({'path':str(p.relative_to(ROOT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)})
write('public-input-pins.json',{'requirements_canonical_sha256':req,'inputs':inputs,'eight_primary_bytes_verified':primary,'network_fetches':0})
checks=[
 {'id':'S01','subject':'Identity and read-only scope','accept':'Exact candidate pins must match all launcher/capture sources reviewed, with original 52 game files bound to committed bytes. Main.tscn/project/root Window and Run gate preserved. Reviewer never imports or executes candidate code, tests, engine or Win32 desktop APIs.','reject':'Missing/stale pin, runtime side effects on import, product edits or broadened ownership.'},
 {'id':'S02','subject':'Independent creator ownership','accept':'Actual desktop creation belongs to a dedicated launcher process and owned creator thread; creating it cannot rebind Codex/root threads. Top-level guards and process boundaries are explicit; borrowed initial thread desktop/windowstation handles are identified as borrowed.','reject':'Creating a desktop in the root process/thread; assuming the initial desktop is disposable; closing GetThreadDesktop handles.'},
 {'id':'S03','subject':'Fresh noninput desktop','accept':'Verify WinSta0 without changing the process station, unique one-attempt desktop name, precheck refuses an existing object and unexpected query errors; created HDESK non-inheritable. Record actual input desktop identity before/after and created desktop name. Fresh-name precheck is a check, not a proof against an external creation race.','reject':'Reuse existing desktop, DEFAULT/active fallback, broad error-to-not-found handling, SwitchDesktop or root station/desktop/foreground/focus/display changes.'},
 {'id':'S04','subject':'Process birth and inherited handle whitelist','accept':'CreateProcessW binds explicit WinSta0/name via STARTUPINFOEX.lpDesktop at birth, CREATE_SUSPENDED plus EXTENDED_STARTUPINFO_PRESENT. Proper structure sizes/types, mutable command line, stable handle-list lifetime and checked WinAPI returns. Only explicitly owned stdio handles are inheritable/whitelisted; HDESK and unrelated handles excluded.','reject':'Generic inherit-all, missing PROC_THREAD_ATTRIBUTE_HANDLE_LIST, inheriting a desktop handle, script hide/SW_HIDE treated as persistent protection, active-desktop relaunch.'},
 {'id':'S05','subject':'Suspended and actual thread verification','accept':'Check and log process/thread IDs and binding setup before resume; actual primary and relevant GUI thread desktop identities are checked reasonably after initialization and compared to the unique target. No claim that a suspended thread already initialized USER32 solely from an unavailable GetThreadDesktop value. Failure must prevent progression to capture and trigger bounded owned cleanup.','reject':'lpDesktop string or successful CreateProcess alone relabeled actual desktop verification, accepting wrong/unavailable names as success, ignoring verification failure or resuming twice.'},
 {'id':'S06','subject':'Bounded HANDLE lifecycle','accept':'At most allowed invocations, each bounded to <=60s by absolute own-process deadline, explicit process HANDLE waits and checked exit status. Timeout/failure terminates only owned process then confirms terminal. If termination is unknown, preserve unknown status/ownership and do not release desktop or allow another invocation.','reject':'PID-only termination susceptible to reuse, unbounded wait or sync pipe deadlock, retry-to-pass, terminal inferred from closed handle/log completion, creator ends while Godot may remain.'},
 {'id':'S07','subject':'Cleanup order and failures','accept':'On every path: actual Godot terminal precedes owned creator-thread end; thread end/join precedes CloseDesktop from a thread never associated with it. CloseDesktop only for created/opened owned handles; check results. Keep initial/borrowed handles unclosed. Preserve primary and cleanup errors, raw logs, counts and unknown side effects.','reject':'Premature finally-close, CloseDesktop while creator/engine thread using it, closing borrowed/initial desktop, cleanup exception erases primary evidence, cleanup silently marks success.'},
 {'id':'S08','subject':'Complete original root capture','accept':'Load/instantiate full original main.tscn into original root Window/Viewport; keep original WorldEnvironment/lights/World/current Camera3D/Shell CanvasLayer and viewport/content-scale relation. No toy/SubViewport substitute, hidden main, source/geometry/material changes, Run or motion. API placement/camera only.','reject':'Detached scene, missing CanvasLayer/UI or camera, changing Run gate, replacing game with screenshot/toy, claiming real input from API calls.'},
 {'id':'S09','subject':'Renderer and frame facts','accept':'Explicit real windows backend + Vulkan + forward_plus, no automatic fallback. Capture root viewport actual texture/image dimensions and nonempty PNG after actual completed draw; force_draw ordering reasonable if render loop disabled. Record device/backend/method, root/window/viewport sizes and API camera/layout state.','reject':'Headless/dummy/GL/active fallback, waiting forever for disabled frame event, fabricated renderer evidence, PNG save alone claimed visual correctness or GPU timing success.'},
 {'id':'S10','subject':'Evidence and bounded conclusion','accept':'Retain invocation IDs/PIDs/HANDLE lifecycle, raw stdout/stderr/WinAPI errors, desktop before/after/actual binding observations, source/engine/script pins, PNGs and per-frame metadata, exit/terminal/timeouts; failed/unknown attempt immutable and no retry-to-pass. Reviewer reports static limits and unresolved runtime evidence explicitly.','reject':'Discarded failure, current implementation rebound to old output, static review asserted no-flash/GPU/native input/DPI/G01/G02/full crossing/H12 acceptance.'}
]
plan={'schema':1,'work_id':'A-GAME3D-PRIVATE-DESKTOP-CAPTURE-REVIEW-20261024-v1','job_id':'child-17df76fcdbbc4e12b1f98fe30a70d89a','phase':1,'canonical_agent':'/root/pc_direct_window_review','requirements_sha256':req,'checks':checks,'scope':'Independent static review only. No target process/desktop/window/GPU/engine/test/UI/board/serial/service/network operation. File reads/hash/AST/text analysis allowed; no candidate imports.','candidate_author_code_read_before_freeze':False,'prior_exposure':['Original product main.tscn/main.gd/shell/SceneDocument/AssetPresenter and public contracts were read in preceding roundtrip job; original full-scene dummy API invocation was separate completed job.','This phase read the hidden-entry research report, saved primary pins and official-documents readback; reviewed root-window/show/CanvasLayer primary excerpts. Author71958a live source has not been read.','Previous memory G02 boundary reminder is historical context only; no new memory read for this static phase and no current capability inferred from it.'],'phase2_trigger':'Parent exact frozen candidate pins only; then static source/evidence review, no execution. Preserve counterexamples and report root; no product/author changes.','formal_status':{'H01_H15':'unchanged/unaccepted','full_H12':'preserved/open','G03':'not_run','R03':'not_run','all29':'not_run'},'waiting_after_phase1':True,'native_complete_before_final_phase2':False}
write('phase1-plan.json',plan)
report='''# Private desktop capture review — phase 1

The new lease validated execution_allowed=true for canonical /root/pc_direct_window_review. This phase is a static review preparation, with no author implementation read and no target process, engine, desktop, window, GPU or test invocation.

Ten independent obligations S01–S10 are frozen in phase1-plan.json: exact source/scope; independent creator; fresh noninput desktop; birth binding and stdio-only inheritance; suspended/actual thread checks; bounded owned HANDLE lifecycle; cleanup order/error preservation; complete original root scene; real renderer/frame facts; immutable logs and narrow claims.

Official Microsoft readback distinguishes the unique noninput desktop from the currently visible input desktop and identifies inherited-desktop precedence, CreateDesktop thread association, and CloseDesktop initial/borrowed/thread restrictions. Pinned Godot primary excerpts show early main window display, main visibility restrictions and CanvasLayer viewport binding. These are source/design constraints, not current GPU/no-flash measurements. The candidate's exact WinAPI call and exception paths will be reviewed only after root provides frozen pins.

Current original 52 game resource pins were verified against committed bytes; primary eight saved source files were byte/hash verified. Public input pins and canonical H01–H15 requirements hash are recorded separately. Prior original product-source exposure and preceding API-only trial are disclosed; no previous pass is promoted to this task. No live author code has been read.

G03/R03/all29 remain not_run. Full H12 and H01–H15 remain preserved and unaccepted. No new execution is authorized by this checklist. Await parent exact-pins phase2 followup; lease remains running and native_complete is deferred.
'''
(OUT/'phase1-report.md').write_text(report,encoding='utf-8')
members={}
for p in sorted(OUT.iterdir()):
 if p.is_file() and p.name not in ['lease.private.json','phase1-manifest.json','phase1-freeze.json']:
  members[p.name]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('phase1-manifest.json',{'files':members,'member_count':len(members),'manifest_self_member':False})
write('phase1-freeze.json',{'plan_sha256':sha(OUT/'phase1-plan.json'),'public_inputs_sha256':sha(OUT/'public-input-pins.json'),'product_pins_sha256':sha(OUT/'product-phase1-pins.json'),'phase1_manifest_sha256':sha(OUT/'phase1-manifest.json'),'requirements_computed':req,'author_code_read':False,'target_runtime_invocations':0,'waiting_for_exact_pins':True})
print(json.dumps(json.loads((OUT/'phase1-freeze.json').read_text(encoding='utf-8'))))
