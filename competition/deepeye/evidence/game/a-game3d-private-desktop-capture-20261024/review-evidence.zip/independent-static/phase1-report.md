# Private desktop capture review — phase 1

The new lease validated execution_allowed=true for canonical /root/pc_direct_window_review. This phase is a static review preparation, with no author implementation read and no target process, engine, desktop, window, GPU or test invocation.

Ten independent obligations S01–S10 are frozen in phase1-plan.json: exact source/scope; independent creator; fresh noninput desktop; birth binding and stdio-only inheritance; suspended/actual thread checks; bounded owned HANDLE lifecycle; cleanup order/error preservation; complete original root scene; real renderer/frame facts; immutable logs and narrow claims.

Official Microsoft readback distinguishes the unique noninput desktop from the currently visible input desktop and identifies inherited-desktop precedence, CreateDesktop thread association, and CloseDesktop initial/borrowed/thread restrictions. Pinned Godot primary excerpts show early main window display, main visibility restrictions and CanvasLayer viewport binding. These are source/design constraints, not current GPU/no-flash measurements. The candidate's exact WinAPI call and exception paths will be reviewed only after root provides frozen pins.

Current original 52 game resource pins were verified against committed bytes; primary eight saved source files were byte/hash verified. Public input pins and canonical H01–H15 requirements hash are recorded separately. Prior original product-source exposure and preceding API-only trial are disclosed; no previous pass is promoted to this task. No live author code has been read.

G03/R03/all29 remain not_run. Full H12 and H01–H15 remain preserved and unaccepted. No new execution is authorized by this checklist. Await parent exact-pins phase2 followup; lease remains running and native_complete is deferred.
