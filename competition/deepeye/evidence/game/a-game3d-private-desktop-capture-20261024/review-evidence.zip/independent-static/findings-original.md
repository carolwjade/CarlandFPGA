# Original candidate static findings

Exact original launcher 4d9c0746912047c9b932b83a986343f20cc910e5f365c31d8d22c7fbc0516287 is preserved. No candidate import, policy test, Win32 call or target runtime was executed by this reviewer.

F02 is a confirmed lifecycle defect accepted by root: failed/unconfirmed termination leads to close_owned refusing closure, but execute returns and main exits, discarding the supposedly retained HANDLE owner. Merely leaving Python fields populated cannot retain handles after process exit. This candidate should not execute.

F03 is a static first-window deadline counterexample pending root decision: code stores first nonempty window observations before checking `not observations and elapsed>=15`; an initial window observation at15.01s therefore avoids failure. It is a control-flow finding, not an executed probe.

F01 records an extra frozen oracle order mismatch, not a confirmed native lifecycle defect. Root clarified that the creator may end before spawn while the control thread retains HDESK, and requires both Godot and creator terminal before CloseDesktop. The original freeze is retained; no claim that all ten original groups passed is made.

The remaining original code uses explicit WinSta0 birth binding, three stdio-only inherited handles, owned-desktop first Engine HWND/tid checks, original root Window/main.tscn, preserved Run disablement and16 expected root viewport PNG paths. No active/dummy/GL fallback was found. These are static observations; ABI, actual binding, GPU/PNG/no-flash and formal G01/G02/H12 remain unproven. Await root exact correction pins before final delta review and native_complete.
