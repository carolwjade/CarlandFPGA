import hashlib,json,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=ROOT/'.planning/deepeye-resume-20261018/game3d-private-desktop-capture-20261024'
EXPECTED={'launcher.py':'4d9c0746912047c9b932b83a986343f20cc910e5f365c31d8d22c7fbc0516287','capture.gd':'6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5','execution-plan.json':'e82e6df28767a1a8e6cb87eb639f731b1975ed0febd0f4f2add9cafaf9fda892','source-pins.json':'548b2dc87f7ebb7c6385d6254cdc594037d4c9e8e21c1c12bd254a1d930616da','phase1-frozen-manifest.json':'46c02b196c4d5f73103750ecddff5ede55172f71e3aa1a1a5c1305142ea54b21'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins={}
for name,digest in EXPECTED.items():
 p=AUTHOR/name
 assert sha(p)==digest,(name,sha(p))
 pins[name]={'sha256':digest,'bytes':p.stat().st_size}
snapshot=OUT/'candidate-original'
assert not snapshot.exists(),'Do not overwrite original candidate'
snapshot.mkdir()
for name in EXPECTED:shutil.copyfile(AUTHOR/name,snapshot/name)
data={'author_directory':str(AUTHOR),'all_parent_pins_equal':True,'files':pins,'candidate_imported_or_executed':False,'target_runtime_invocations':0}
(OUT/'candidate-original-verification.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data))
