"""Root readback and evidence-only staging. Never executes a candidate or engine."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, subprocess, zipfile

P = Path(__file__).resolve().parent
O, R = P.parent, P.parents[2]
W = R / '.local/deepeye-implementation-a'
A = O / 'game3d-private-desktop-capture-20261024'
V = O / 'game3d-private-desktop-capture-review-20261024'
GIT = r'C:\Users\CarlJade\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe'
HEAD = '496e96aa276083df209dbc67da28d8d68b928aea'
REQ = 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(p.read_bytes())
def save(p, data):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')
def git(*args):
    return subprocess.check_output([GIT, '--no-optional-locks', '-C', str(W), *args])
def checked(path, row):
    raw = path.read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes'], str(path)
    return raw

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('diff', '--cached', '--name-only').strip()
contract = read(R / 'docs/competition/deepeye-2026/immutable_scope.json')
assert sha(json.dumps(contract['requirements'], ensure_ascii=False, sort_keys=True,
                      separators=(',', ':')).encode()) == REQ
assert [r['id'] for r in contract['requirements']] == ['H%02d' % i for i in range(1, 16)]
transfer = read(R / '.planning/deepeye-desktop-handoff-20261015/transfer.json')
assert transfer['director_generation'] == 3 and transfer['status'] == 'active'
assert transfer['new_director_thread_id'] == '01a16988-bdcb-70e1-ae10-1304b5cf7875'
protected = read(O / 'r03-mailbox-stop-main-review-20261020/application.json')['protected_files']
assert all(sha((W / name).read_bytes()) == expected for name, expected in protected.items())

pins = read(A / 'final-source-pins.json')
snapshot = R / '.local/deepeye-game3d-private-desktop-capture-20261024/product'
assert len(pins['original_52_and_snapshot_52']) == 52
for row in pins['original_52_and_snapshot_52']:
    checked(W / row['path'], row)
    checked(snapshot / row['path'], row)
for name, expected in pins['job_sources'].items():
    assert sha((A / name).read_bytes()) == expected, name
assert sha((A / 'final-manifest.json').read_bytes()) == '6ff5aee57fd4d75d6408b5be5e3a9d6a574a2259c1bfd121d162bb0126fead55'
am = read(A / 'final-manifest.json')
assert am['member_count'] == len(am['members']) == 159
for row in am['members']:
    checked(A / row['path'], row)
assert sha((V / 'artifact-manifest.json').read_bytes()) == '946d1ef82d8a90178b61046934c4f50c549bc5acd2a94104d9688524e72054f3'
vm = read(V / 'artifact-manifest.json')
assert vm['member_count'] == len(vm['files']) == 42
for name, row in vm['files'].items():
    checked(V / name, row)

fresh = read(P / 'capture-terminal-and-goal-readback-20261024.json')
terminal = json.loads(fresh['capture_terminal']['content'][0]['text'])[0]
assert terminal['job_id'] == 'child-71958a7341174c76a4132dcb9a364a46'
assert terminal['status'] == 'completed' and terminal['terminal'] and terminal['stale'] is False
assert fresh['goal']['goal']['status'] == 'active'
result = read(A / 'final-result.json')
assert result['total_actual_Godot_creates'] == 2 and result['PNG_count'] == 0
assert result['remaining_Godot_invocations'] == 0 and result['collection_closed']
assert all(x['child_terminal'] and x['creator_terminal'] and x['owned_handles_closed'] for x in result['attempts'])
assert result['actual_backend'] is None and result['actual_device'] is None
assert result['attempt2_enum']['final_raw']['raw_bool'] == 1
assert result['attempt2_enum']['final_raw']['callback_count'] == 2
assert result['attempt2_enum']['final_raw']['owned_rows'] == []

decision = {
    'schema': 1, 'utc': datetime.now(timezone.utc).isoformat(), 'product_head': HEAD,
    'outcome': 'failed_closed_two_actual_Godot_creates_zero_accepted_HWND_zero_PNG',
    'native_job': terminal['job_id'], 'native_status': 'completed/terminal/stale=false',
    'meaning_of_completed': 'collection/lifecycle closed, not rendering or acceptance success',
    'actual_launcher_Python_exit_attempt2': 2, 'Godot_exit_backend_device': 'not_observed',
    'attempt1_error122_attribution': 'unproven; last error not cleared; false return inferred only',
    'attempt2_error5_attribution': 'missing handle in callback; exact native cause not established',
    'original_failed_receipts_kept': True, 'keeper_or_live_session': False,
    'input_desktop': 'Default samples only; no continuous no-flash or nonoccupation proof',
    'author_manifest_members_independently_rehashed': 159,
    'static_review_members_independently_rehashed': 42,
    'static_review_scope': 'v2 only; F02/F03 source control flow resolved, no native proof',
    'static_F01': 'original extra ordering oracle clarified by root; not all original oracles passed unchanged',
    'F04_v3': 'small root delta review retained; attempt2 remains failed',
    'original_and_snapshot_sources_rehashed': '52+52; unchanged', 'C4_unchanged': True,
    'remaining_job_execution_budget': 0,
    'next_method': 'read-only separate design029d; no new execution authorized by this archive',
    'real_board_operations': 0, 'formal_acceptance': False,
    'requirements_sha256': REQ, 'H01_H15_full_H12': 'preserved',
    'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run',
}
save(P / 'capture-failure-root-decision.json', decision)

secrets = []
for folder in ['game3d-edit-roundtrip-independent-20261024', 'b-minimal-pl-readiness-20261024',
               'game3d-hidden-entry-research-20261024', 'game3d-private-desktop-capture-20261024',
               'game3d-private-desktop-capture-review-20261024', 'game3d-desktop-association-design-20261024']:
    secrets.append(read(O / folder / 'lease.private.json')['lease_token'].encode())
members = {}
def add(name, path):
    assert name not in members and '\\' not in name and not name.startswith('/')
    assert '..' not in name.split('/')
    raw = path.read_bytes()
    assert not any(secret in raw for secret in secrets), name
    members[name] = raw
include = read(A / 'final-archive-include.json')
assert sha((A / 'final-archive-include.json').read_bytes()) == '00ddeaf9dc880484749d0b2406199d4bf25b2de468a190bdb7a1aa483ec86d9f'
assert len(include['member_paths']) == 160
for name in include['member_paths']:
    path = (A / name).resolve()
    path.relative_to(A.resolve())
    add('author/' + name, path)
add('author/final-archive-include.json', A / 'final-archive-include.json')
add('author/native-complete-response.json', A / 'native-complete-response.json')
for name in vm['files']:
    add('independent-static/' + name, V / name)
add('independent-static/artifact-manifest.json', V / 'artifact-manifest.json')
for name in ['capture-failure-root-decision.json', 'capture-terminal-and-goal-readback-20261024.json',
             'seal_capture_failure_and_stage.py']:
    add('root/' + name, P / name)
assert len(members) == 208

stage = P / 'staged-private-desktop-capture-failure'
stage.mkdir(exist_ok=False)
archive = stage / 'review-evidence.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(members.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.infolist()) == len(members)
    assert all(z.read(name) == raw for name, raw in members.items())
save(stage / 'manifest.json', {
    'schema': 1, 'archive_sha256': sha(archive.read_bytes()), 'member_count': len(members),
    'members': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())}})
save(stage / 'decision.json', decision)
with (stage / 'README.md').open('x', encoding='utf-8', newline='\n') as f:
    f.write('Two actual original-full-scene Godot creates failed closed, with zero accepted HWNDs and zero PNGs. '
            'Both original process/creator owners are terminal and their owned handles closed; collection completed does not mean render success. '
            'Attempt1 stored error122 attribution is unproven; attempt2 callback had a missing desktop handle and exact native cause is unproven. '
            'The policy-blocked PowerShell wrapper made zero inner calls; actual attempt2 Python exit2 is separate from Godot exit/backend/device, which remain unobserved. '
            'Default input-desktop samples do not prove continuous nonoccupation. All original raw/failure/frozen records and v2 independent static limits are retained. '
            'No third attempt in the exhausted job. Read-only separate design has no execution authority. '
            'H01-H15/full H12 preserved; G03/R03/all29 not_run.\n')

packages = read(P / 'staged-game-API-and-PL-readiness/preparation-result.json')
packages['capture-failure'] = {
    'target': 'competition/deepeye/evidence/game/a-game3d-private-desktop-capture-20261024',
    'member_count': len(members), 'archive_sha256': sha(archive.read_bytes()),
    'files': {p.name: sha(p.read_bytes()) for p in sorted(stage.iterdir())}}
files = {}
for short, pkg in packages.items():
    src = stage if short == 'capture-failure' else P / 'staged-game-API-and-PL-readiness' / short
    dst = W / pkg['target']
    assert not dst.exists(), str(dst)
    assert len(pkg['files']) == 4
    for name, expected in pkg['files'].items():
        assert sha((src / name).read_bytes()) == expected
    with zipfile.ZipFile(src / 'review-evidence.zip') as z:
        manifest = read(src / 'manifest.json')
        assert z.testzip() is None and len(z.infolist()) == pkg['member_count']
        assert all(sha(z.read(n)) == row['sha256'] and len(z.read(n)) == row['bytes']
                   for n, row in manifest['members'].items())
    dst.mkdir(parents=True, exist_ok=False)
    for name, expected in pkg['files'].items():
        shutil.copyfile(src / name, dst / name)
        assert sha((dst / name).read_bytes()) == expected
        files[pkg['target'] + '/' + name] = expected
assert len(files) == 12
save(P / 'game-api-PL-capture-evidence-publication.json', {
    'expected_head': HEAD, 'message': 'docs(deepeye): preserve bounded game API and failed private render evidence', 'files': files})
save(P / 'game-api-PL-capture-preparation-result.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'packages': packages,
    'canonical_files_copied': 12, 'source_changes': 0, 'candidates_executed': 0,
    'C4_unchanged': True, 'contract_verified': REQ, 'secret_tokens_scanned': len(secrets)})
print(json.dumps({'prepared': True, 'packages': {k: {'members': v['member_count'],
    'sha256': v['archive_sha256']} for k, v in packages.items()}, 'canonical_files': 12}, indent=2))
