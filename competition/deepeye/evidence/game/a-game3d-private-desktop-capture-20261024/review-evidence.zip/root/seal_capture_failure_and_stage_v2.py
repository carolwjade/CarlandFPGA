"""Correct one root packaging duplicate; preserve the original failed script."""
from pathlib import Path

path = Path(__file__).with_name('seal_capture_failure_and_stage.py')
source = path.read_text(encoding='utf-8')
old = "save(P / 'capture-failure-root-decision.json', decision)"
new = """prior_decision = read(P / 'capture-failure-root-decision.json')
assert {k: v for k, v in prior_decision.items() if k != 'utc'} == {k: v for k, v in decision.items() if k != 'utc'}
decision = prior_decision"""
assert source.count(old) == 1
source = source.replace(old, new)
old = "add('author/final-archive-include.json', A / 'final-archive-include.json')"
assert source.count(old) == 1
source = source.replace(old, "assert 'author/final-archive-include.json' in members")
old = "'seal_capture_failure_and_stage.py']:"
new = "'seal_capture_failure_and_stage.py', 'seal_capture_failure_and_stage_v2.py', 'capture-archive-packaging-correction.json']:"
assert source.count(old) == 1
source = source.replace(old, new)
assert source.count('assert len(members) == 208') == 1
source = source.replace('assert len(members) == 208', 'assert len(members) == 209')
exec(compile(source, str(path), 'exec'))
