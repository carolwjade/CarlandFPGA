# PC_DIRECT idle expiry implementation plan

> For agentic workers: use subagent-driven-development and fresh focused TDD, then independent source/evidence review. A Gen3 root owns technical selection under existing human20261015 authorization. No per-step human confirmation is needed for this bounded correction.

**Goal:** An actual owner-thread composition poll must observe original command/heartbeat expiry and stop the activation without preparing or committing a new motion step.

**Architecture:** Add a small diagnostic runtime expiry probe over the existing clock/watchdog/command state. The composed owner polls its original actor, then probes runtime expiry with a fresh clock read. Active expired runs retire through the existing stop/revoke/cleanup transaction; initial unbound and never-commanded waiting remain possible. No background timer, new provider or activation bypass.

**Tech stack:** Existing Python3.12 stdlib, real current runtime/mailbox/numerical executor in new focused offline controls. Existing native/channel fixture helpers may be imported as support but no historical test methods are executed. No board, Godot, visible UI, service, peer, model or provider action.

## Identity, baseline and scope

- Director01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3, DEEPEYE-IMPLEMENTATION-20261014/v1. Product W=.local/deepeye-implementation-a, exact head5f147d5003dc0b2f4eb88d4cb3d9e79afb5a55d8.
- Preserve DEEPEYE-HUMAN-LOCK-20261014/revision1, everyH01-H15 and canonical requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804. G02open; G03/R03/all29not_run. No old384 board/software/failedsolver/nativecapture/10-runSaveAs replay.
- Source evidence: actor_composition.poll currently only channel/progress health + actor.poll; runtime._advance owns original heartbeat/command expiration but no public non-motion poll. Calling step as an expiry probe can commit a not-yet-expired command. The new API must not do so.
- Runtime _last_command survives normal command expiry and is reset by fresh verified BOOT. Use that retained history to distinguish never-bound waiting from expiry even if another earlier event already cleared _command. Keep normal runtime command-expiry non-latching semantics; the composition retires expired admission consistently with its existing noncommitting-step policy.
- Author owns only this node's author/ candidate, newtests, runs, report and manifest. No W/source publication writes. Root later selects exact reviewed bytes. Independent reviewer owns only review/. Existing readiness/path auditors retain their own separate output directories.
- C4 protected paths/hashes are in ../r03-mailbox-stop-main-review-20261020/application.json. Preserve all raw bytes, dirty state, index and existing simulator cache. Capture source/input pins before work.

## Design selection

1. Selected: explicit owner-thread, non-motion expiry probe + composed idle poll retirement. Reuses original clocks/deadlines and serialization.
2. Rejected: using step to observe stopping. That can create a new pose commit and gives the wrong observation method.
3. Deferred: asynchronous watchdog/owner-death supervisor. It changes ownership and does not establish a hard OS scheduling guarantee; that separate product obligation remains open.

## Runtime API

- Add frozen ExpiryStatus(stop_required: bool, reason: str) and @runtime_entry check_expiry(). This is trusted-owner diagnostic output, never motion permission or authenticated evidence.
- Enforce existing owner, non-reentry and stepping exclusion. Sample the original actual clock via _advance; retain clock-regression/invalid/reentrant/foreign-thread STOP behavior. Any exceptional check must veto further motion and preserve the original exception rather than turn failure into healthy status.
- A retained latch returns stop_required with its original reason. An original command that has reached its original deadline returns command_deadline even if _command was already cleared by another event; equality is expired. A currently live command and initial never-commanded wait return no expiry requirement without claiming readiness/health/motion authority.
- No prepare_step, commit_step, ai_lease, input verifier, parsing, callback provider, deadline renewal, new epoch/session or BOOT occurs. Fresh verified BOOT retains its existing history reset; no recovery/replay branch is added.

## Composition integration

- Preserve poll's initial _channel_health and original actor.poll. If still ACTIVE, call runtime.check_expiry afterward so actual time advanced during the actor poll is observed.
- On stop_required retire through existing _retire, revoke original executor/runtime and candidates/progress, then return existing _STOPPED sentinel. This prevents the outer entry wrapper's post-checkpoint from turning an intentional poll retirement into a second exception path.
- RUNNING_UNBOUND may continue polling before BOOT; ACTIVE with no command yet may wait under existing progress/lifetime policy. Heartbeat lapse after an actual heartbeat is a stop. No new command/event may resurrect a retired activation; duplicates/ACK/heartbeat/progress do not extend an original command deadline.
- Preserve prior positive CAS facts. Executor revocation legitimately increments root/revoke revision; assert unchanged committed pose/pose_revision/frame and zero additional commit calls rather than claiming every internal revision is unchanged.
- The commit-step final fence, v2 consumption-window policy, BOOT wire/schema, production factory refusal before registry acquisition, actor acquisition/cleanup semantics and C-owned code stay unchanged.

## Files

- Modify candidate/competition/deepeye/simulation/authority/pc_direct_runtime.py.
- Modify candidate/competition/deepeye/simulation/authority/actor_composition.py.
- Create candidate/competition/deepeye/tests/simulation/test_pc_direct_idle_expiry.py containing only new cases. Do not edit/run old test classes.
- Create candidate/competition/deepeye/docs/pc_direct_idle_expiry.md describing actual API/caller behavior, original expiry semantics and remaining scheduling/provider limits.

## Implementation and evidence

- [ ] Pin current head, exact inputs/C4/index/cache and contract; keep copied dependencies separate from selected overlay. Verify author scope and use a fresh run directory for each new command.
- [ ] Write meaningful new RED demonstrating that a short command TTL/heartbeat can expire before long progress/actor limits while an idle poll leaves admission active; record exact command, exit and assertions before implementation.
- [ ] Implement only the chosen API and poll call; keep final CAS code/policy/provider gate identical.
- [ ] Run only new targeted controls: deadline-1 versus equality; original deadline despite duplicate/heartbeat; heartbeat expiry earlier than progress; initial unbound/never-commanded wait; event already cleared command; freshBOOT history reset; invalid/regressing/reentrant/foreign checks; time advancement during actor.poll; positive real executor CAS followed by poll stop with zero new prepare/CAS; late completion/command/heartbeat cannot revive retired composition.
- [ ] Tests may import established fixture classes for setup, but construct an explicit unittest suite of only the new class/methods; no discovery of inherited old methods or execution of old groups. No sleeps/model/board/engine calls; synthetic time/native/channel evidence remains explicitly labeled while runtime/executor logic is real software.
- [ ] At most4 new test command attempts (RED + GREEN/repairs). Preserve all failures; no broad regression suite. If another attempt is needed report identified failure and wait for root's concrete new budget. Do not repeat passing runs without a new defect/change.
- [ ] Freeze a small exact selected source/test/docs + necessary raw command/output/result manifest, report boundaries and stopwrites. Root verifies actual terminal/bytes and delegates independent review. This recorded Desktop/native route does not require a mesh lease.
- [ ] Independent review checks state/expiry/exception/initial-wait and no-CAS behavior, source pins, actual test coverage and unchanged final fence/production gate. Root adjudicates, selects exact overlay, commits/pushes once and records PR readback. Formal29-card acceptance remains unproven.
