# PC_DIRECT idle expiry independent review

Work `A-PCDIRECT-IDLE-EXPIRY-REVIEW-20261024-v1`, reviewer
`/root/pcdirect_idle_expiry_review`, recorded Desktop/native route under A Gen3.
Only this review directory was written. Product/candidate code was neither
imported nor executed; no tests were rerun, and no engine, actor, board, provider,
service, network or peer action occurred.

**Verdict: no blocking issue in the selected four-file change at author manifest
`4dc0f59aad6c424aa2f746082c48942f11bf83c09d735c6f2034c320ef3d8d9b`.**
This is source and saved-evidence review, not live integration acceptance.

## Identity and exact evidence

Read project multi-node skill, installed A role, collaboration protocol, current
handoff, immutable scope md/json, transfer and selected plan/readiness report.
Readonly node configuration identifies A / fpga-main. The authoritative transfer
is active, generation 3, director `01a16988-bdcb-70e1-ae10-1304b5cf7875`.
Independently computed all 15 requirements' canonical UTF-8 JSON SHA256 as
`c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`.

The readonly audit ran with the existing project Python:
`.local/venv/Scripts/python.exe -B -X utf8
.planning/deepeye-resume-20261018/pcdirect-idle-expiry-20261024/review/audit_sources.py`.
Actual exit was 0. It recomputed every one of 21 frozen member pins and all four
selected-file pins, verified current head
`5f147d5003dc0b2f4eb88d4cb3d9e79afb5a55d8`, 140 product input pins, original
baseline/staging binding, all four protected dirty files, index/status and six
existing Godot cache files. No product state changed. `audit-result.json`
contains the independently observed hashes and command-record comparison.

## State and motion review

The runtime's new frozen `ExpiryStatus` is a diagnostic only. `check_expiry`
enters the existing single-owner/busy/step boundary, reads the existing actual
clock through `_advance`, returns original latched reasons, and recognizes an
original command's deadline at equality through retained `_last_command` even
when an earlier event already cleared `_command`. Fresh BOOT's unchanged history
reset avoids carrying expired command history into a new verified session.
There are no input-verifier, AI-lease, geometry-prepare, commit or deadline-renewal
calls in this method.

`RUNNING_UNBOUND` poll does not call the probe. A booted, never-commanded runtime
does not become expired merely for lacking a command or first heartbeat. This
false stop requirement remains explicitly weaker than readiness. An actual
heartbeat timeout still latches through the existing watchdog. Exceptional,
invalid, regressing, foreign-thread and reentrant checks veto motion. A nested
check caught by a clock callback leaves a latch observed by the outer probe.
Exceptional checks re-raise, subject to the pre-existing `_runtime_entry`
TypeError-to-ValueError conversion with the original cause, as documented.

Composition preserves its existing channel/progress checks and original actor
poll, then samples runtime time freshly only while ACTIVE. Expiry retires through
the original transaction and returns `_STOPPED`; the entry wrapper's existing
early sentinel return reaches finally/cleanup without a false second
post-checkpoint rejection. Existing retirement revokes future admission before
callbacks. Late completion, command or heartbeat cannot restore that activation.
Earlier positive CAS pose, pose_revision and frame facts are preserved; ordinary
stop bookkeeping can advance root revision/revoke generation.

Independent source comparison confirmed all 64 pre-existing functions/methods
in the two changed source files are identical except `ActorComposition.poll`.
This includes `_advance`, BOOT/event entries, `_ready`, runtime final step,
composition `_entry`, retirement/cleanup, dependency prepare/commit, production
factory and the still-refusing production channel gate. All other pinned staging
sources, including v2 mailbox/window and numerical executor, remain unchanged.
The only new executable method is `PcDirectRuntime.check_expiry`; the other new
runtime item is the frozen diagnostic record/export.

## Actual saved test results

Read original command records, raw stderr, exact candidate bindings, test source
and fixture setup. No test methods were executed by the reviewer.

| Attempt | Actual saved process and result | Meaning |
|---|---|---|
| red-01 | PID 42620; wait completed; exit 1 | jsonschema import failure before all test methods; not behavioral RED |
| red-02 | PID 35832; wait completed; exit 1; 2 new failures, 0.191 s unittest | Original TTL/heartbeat idle polls remained ACTIVE; TTL case had already completed one real numerical CAS |
| green-03 | PID 35284; wait completed; exit 0; 14 new tests, 0.604 s unittest | Exact selected three Python source/test hashes match frozen manifest |

The new test's explicit suite builds names from each new class's `__dict__`,
not inherited method discovery. The module main executes that suite, and
`load_tests` selects the same new methods. Actual green raw output lists exactly
the 14 newly defined names. Imported old classes are fixture setup helpers;
their historical test methods were not selected. Three of four authorized test
commands were consumed, preserving first failure and behavioral RED.

Coverage directly observes original TTL minus one/equality without motion,
retained original TTL across ACK/heartbeat/exact duplicate, earlier heartbeat
expiry, fresh time after actor poll, an event already clearing the current
command, unbound/uncommanded wait, retained latch/fresh BOOT reset, exceptional
and invalid/regressing clocks, caught reentry, step exclusion, foreign calls and
malformed arguments. The positive composition case uses the real numerical
executor first, then proves zero additional prepare/CAS while poll stops and
preserves the earlier pose/pose_revision/frame. Late inputs and step are rejected
without another motion commit. Existing source also confirms completion/progress
events cannot rewrite the retained runtime command deadline.

These controls use synthetic upstream channel/native/clock boundaries. They do
not authenticate FPGA observations, native actor identity, useful CPU AI or
physical actuation. A finite actual owner loop and original providers remain
required; the method supplies no independent owner-death or OS scheduling
guarantee. Both complete H12 paths and original 29-card acceptance remain open.
G02 remains open; G03/R03/all29 remain `not_run`; H01-H15 are unchanged.

Review writes stopped after final artifact manifest. Root retains selection,
publication, runtime integration and formal acceptance decisions.
