"""Readonly source/data audit; never imports or executes product/candidate code."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import re
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[3]
AUTHOR = OWN.parent / 'author'
W = ROOT / '.local/deepeye-implementation-a'
GIT = Path('C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe')
EXPECTED_MANIFEST = '4dc0f59aad6c424aa2f746082c48942f11bf83c09d735c6f2034c320ef3d8d9b'
EXPECTED_HEAD = '5f147d5003dc0b2f4eb88d4cb3d9e79afb5a55d8'
EXPECTED_SCOPE = 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'

def pin(path):
    raw = path.read_bytes()
    return dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))

def git(*args):
    return subprocess.check_output([str(GIT), '-C', str(W), *args])

def methods(path):
    text = path.read_text(encoding='utf-8')
    lines = text.splitlines(keepends=True)
    result = {}
    def visit(body, parent=''):
        for node in body:
            if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                key = parent + node.name
                if not isinstance(node, ast.ClassDef):
                    start = min([node.lineno] + [d.lineno for d in node.decorator_list])
                    result[key] = ''.join(lines[start-1:node.end_lineno])
                if isinstance(node, ast.ClassDef):
                    visit(node.body, key + '.')
    visit(ast.parse(text).body)
    return result

manifest_pin = pin(AUTHOR / 'manifest.json')
assert manifest_pin['sha256'] == EXPECTED_MANIFEST
manifest = json.loads((AUTHOR / 'manifest.json').read_bytes())
assert len(manifest['files']) == 21 and len(manifest['selected_files']) == 4
checked_members = {}
for relative, expected in manifest['files'].items():
    path = AUTHOR / relative
    assert path.resolve().is_relative_to(AUTHOR.resolve())
    actual = pin(path)
    assert actual == expected, relative
    checked_members[relative] = actual
for relative, expected in manifest['selected_files'].items():
    assert pin(AUTHOR / 'candidate' / relative) == expected, relative

baseline = json.loads((AUTHOR / 'baseline-pins.json').read_bytes())
assert git('rev-parse', 'HEAD').decode().strip() == EXPECTED_HEAD
for relative, expected in baseline['input_pins'].items():
    assert pin(W / relative) == expected, relative
    assert pin(AUTHOR / 'baseline' / relative) == expected, relative
    if relative not in manifest['selected_files']:
        assert pin(AUTHOR / 'staging' / relative) == expected, relative
for relative, expected in manifest['selected_files'].items():
    if relative.endswith('.py'):
        assert pin(AUTHOR / 'staging' / relative) == expected, relative
for relative, expected in baseline['protected'].items():
    assert pin(W / relative) == expected, relative
assert pin(Path(baseline['index_path'])) == baseline['index']
assert git('status', '--porcelain=v1', '-z') == (AUTHOR / 'baseline-status.bin').read_bytes()
cache_root = W / 'competition/deepeye/simulator/.godot'
actual_cache = {p.relative_to(W).as_posix(): pin(p) for p in sorted(cache_root.rglob('*')) if p.is_file()}
assert actual_cache == baseline['cache']

scope_path = ROOT / 'docs/competition/deepeye-2026/immutable_scope.json'
scope = json.loads(scope_path.read_bytes())
scope_sha = hashlib.sha256(json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':')).encode('utf-8')).hexdigest()
assert scope_sha == EXPECTED_SCOPE and len(scope['requirements']) == 15
transfer_path = ROOT / '.planning/deepeye-desktop-handoff-20261015/transfer.json'
transfer = json.loads(transfer_path.read_bytes())
assert (transfer['director_generation'], transfer['status'], transfer['new_director_thread_id']) == (
    3, 'active', '01a16988-bdcb-70e1-ae10-1304b5cf7875')

unchanged = {}
for filename in ('pc_direct_runtime.py', 'actor_composition.py'):
    relative = Path('competition/deepeye/simulation/authority') / filename
    old, new = methods(W / relative), methods(AUTHOR / 'candidate' / relative)
    for name, old_source in old.items():
        if name == 'ActorComposition.poll':
            continue
        assert new[name] == old_source, name
        unchanged[name] = hashlib.sha256(old_source.encode()).hexdigest()
    expected_new = {'PcDirectRuntime.check_expiry'} if filename == 'pc_direct_runtime.py' else set()
    assert set(new) - set(old) == expected_new

test_rel = 'competition/deepeye/tests/simulation/test_pc_direct_idle_expiry.py'
test_ast = ast.parse((AUTHOR / 'candidate' / test_rel).read_text(encoding='utf-8'))
new_names = sorted(node.name for cls in test_ast.body if isinstance(cls, ast.ClassDef)
                   for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith('test_idle_'))
assert len(new_names) == 14
command_records = {}
for attempt, code in (('red-01', 1), ('red-02', 1), ('green-03', 0)):
    path = AUTHOR / 'runs' / attempt
    record = json.loads((path / 'command.json').read_bytes())
    assert record['exit_code'] == code and record['wait_completed'] is True and record['pid'] > 0
    text = (path / 'stderr.bin').read_text(encoding='utf-8')
    names = re.findall(r'^(test_idle_[^ ]+) \(', text, re.MULTILINE)
    if attempt == 'red-01':
        assert not names and "No module named 'jsonschema'" in text
    elif attempt == 'red-02':
        assert len(names) == 2 and "'ACTIVE' == 'ACTIVE'" in text and 'FAILED (failures=2)' in text
        for relative in ('competition/deepeye/simulation/authority/actor_composition.py',
                         'competition/deepeye/simulation/authority/pc_direct_runtime.py'):
            assert record['candidate_pins'][relative] == baseline['input_pins'][relative]['sha256']
    else:
        assert sorted(names) == new_names and 'Ran 14 tests in 0.604s' in text and text.rstrip().endswith('OK')
        for relative, digest in record['candidate_pins'].items():
            assert manifest['selected_files'][relative]['sha256'] == digest
    command_records[attempt] = dict(pid=record['pid'], exit_code=code, wait_completed=True,
                                    methods_observed=names, elapsed_seconds=record['elapsed_seconds'])

result = dict(schema=1, work_id='A-PCDIRECT-IDLE-EXPIRY-REVIEW-20261024-v1',
              utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              review_route='recorded Desktop/native; no mesh lease required',
              no_product_execution=True, no_test_rerun=True, no_network_board_or_engine=True,
              product_head=EXPECTED_HEAD, requirements_sha256=scope_sha, generation=3,
              author_manifest=manifest_pin, verified_author_members=checked_members,
              selected_files=manifest['selected_files'], W_source_inputs_verified=len(baseline['input_pins']),
              C4_unchanged=True, index_and_status_unchanged=True, cache_files_unchanged=len(actual_cache),
              all_preexisting_methods_except_poll_identical=unchanged,
              original_provider_factory_final_CAS_v2_mailbox_executor_unchanged=True,
              actual_author_command_records=command_records, new_test_names=new_names,
              findings=[], verdict='no blocking issue in bounded source and saved-evidence review',
              product_acceptance=dict(G02='open', G03='not_run', R03='not_run', all29='not_run'))
(OWN / 'audit-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(verdict=result['verdict'], author_members=len(checked_members),
                     W_inputs=len(baseline['input_pins']), unchanged_methods=len(unchanged),
                     new_names=len(new_names), author_pids={k:v['pid'] for k,v in command_records.items()}), ensure_ascii=False))
