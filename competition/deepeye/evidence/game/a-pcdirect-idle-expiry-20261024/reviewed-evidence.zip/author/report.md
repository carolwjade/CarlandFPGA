# A-PCDIRECT-IDLE-EXPIRY-20261024-v1 author report

Candidate only; no product worktree or external action. Director Gen3 and the
published H01-H15 contract c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804
were verified against exact product head 5f147d5003dc0b2f4eb88d4cb3d9e79afb5a55d8.

## Result

Added frozen ExpiryStatus and owner/no-reentry check_expiry using the existing
actual clock/watchdog. It retains normal non-latching command expiry and uses
_last_command to detect an expiry already cleared by an earlier event. Existing
BOOT resets history. Composition polls its original actor, then probes only
ACTIVE runtime and retires through existing revoke/cleanup with _STOPPED.

No new movement, verifier/AI lease call, preparation or CAS occurs in the probe.
One focused test performs a real numerical executor CAS first, then at original
TTL polls stop and preserves pose/revision/frame with no additional prepare/CAS.
It also rejects late completion/command/board and a later step without revival.
General stop/revoke revisions may advance; they are not motion revisions.

## Actual new commands

1. red-01: exit1/PID42620/wait completed; harness ModuleNotFoundError jsonschema,
   before all test methods and before implementation. Preserved, not behavioral RED.
2. red-02: exit1/PID35832/wait completed; 2 explicit new behavioral tests, 2 FAIL
   because original command/heartbeat expiry polls left ACTIVE admission. The
   command-TTL case had already observed one real numerical motion CAS.
3. green-03: exit0/PID35284/wait completed; all14 explicitly selected new tests
   passed, unittest0.604s, outer1.091s. Exact source/test SHA binding is audit.json.
   One command budget remains unused; no passing repetition or old suite run.

The existing project interpreter plus existing .local/deepeye-host-deps were used,
with child-only PYTHONPATH/TEMP/TMP and -B. Nothing was installed. A separate
bundled-Python import probe also lacked jsonschema; no test body ran there.
runtime-metadata.json records actual executable/version/jsonschema provenance.
stderr contains unittest's normal verbose result stream, not engine diagnostics.

New14 controls cover deadline-minus-one/equality, original deadline despite ACK,
heartbeat and duplicate, earlier heartbeat timeout, time crossing during actor
poll, command already cleared by board event, initial unbound and uncommanded
wait, runtime wait before heartbeat, retained latch, fresh BOOT history reset,
invalid/regressing/exception clocks, caught probe reentry, step exclusion,
foreign-thread refusal, malformed call, positive CAS then idle stop, and no
resurrection. Explicit suite/load_tests exclude every inherited historical method.

## Scope and verification

Only four candidate files are selectable. audit.json proves W source inputs,
C4, status/index and all6 existing .godot cache files unchanged. AST source
segments of runtime boot/advance/events/ready/final step and composition entry,
factory/provider gate, dependencies prepare/commit and retirement are unchanged.
All other staging sources match baseline pins, including v2/mailbox/executor.

Synthetic clocks/channel events/native API boundaries are offline fixtures.
The runtime, candidate/mailbox and numerical geometry executor logic are real
software, but there is no real native actor, provider, model, board, Godot, GUI,
service, network, peer message, or physical observation. This is no proof of an
OS scheduling deadline, owner-death protection or complete PC_DIRECT/H12. The
production refusal remains closed. G03/R03/all29 remain not_run; H01-H15 unchanged.

All author writes stop after manifest freeze. Root owns independent review and
selection/publication. No mesh lease was required on this recorded Desktop/native
route; no native completion endpoint was called.
