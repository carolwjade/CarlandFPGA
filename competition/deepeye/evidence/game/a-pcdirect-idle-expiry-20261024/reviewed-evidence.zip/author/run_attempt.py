from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys, time

OWN = Path(__file__).resolve().parent
attempt = sys.argv[1]
run = OWN/'runs'/attempt
run.mkdir()
(run/'tmp').mkdir()
candidate = OWN/'candidate'
for path in candidate.rglob('*'):
    if path.is_file():
        destination = OWN/'staging'/path.relative_to(candidate)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
test = 'competition/deepeye/tests/simulation/test_pc_direct_idle_expiry.py'
command = [sys.executable, '-B', '-X', 'utf8', '-m',
           'competition.deepeye.tests.simulation.test_pc_direct_idle_expiry']
if attempt.startswith('red'): command.append('--red-only')
dependency_root = OWN.parents[3]/'.local/deepeye-host-deps'
assert (dependency_root/'jsonschema/__init__.py').is_file()
env = dict(os.environ, TEMP=str(run/'tmp'), TMP=str(run/'tmp'), PYTHONDONTWRITEBYTECODE='1',
           PYTHONPATH=str(dependency_root))
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
before = time.perf_counter()
with (run/'stdout.bin').open('xb') as out, (run/'stderr.bin').open('xb') as err:
    proc = subprocess.Popen(command, cwd=OWN/'staging', env=env, stdout=out, stderr=err)
    code = proc.wait(timeout=90)
record = dict(command=command, cwd=str(OWN/'staging'), started_utc=started,
              finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              exit_code=code, pid=proc.pid, wait_completed=True,
              elapsed_seconds=time.perf_counter()-before,
              candidate_pins={p.relative_to(candidate).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in candidate.rglob('*') if p.is_file()},
              temp_directory=str(run/'tmp'), dependency_root=str(dependency_root),
              environment_overrides=['TEMP', 'TMP', 'PYTHONDONTWRITEBYTECODE', 'PYTHONPATH'])
(run/'command.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(record, ensure_ascii=False))
print((run/'stderr.bin').read_text(encoding='utf-8'))
raise SystemExit(code)
