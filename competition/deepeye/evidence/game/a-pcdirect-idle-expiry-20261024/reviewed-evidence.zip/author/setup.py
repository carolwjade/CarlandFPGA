from pathlib import Path
import datetime, hashlib, json, shutil, subprocess

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[3]
W = ROOT / '.local/deepeye-implementation-a'
GIT = Path('C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe')
HEAD = '5f147d5003dc0b2f4eb88d4cb3d9e79afb5a55d8'
EXPECTED = 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output([str(GIT), '-C', str(W), *args])
def pin(path):
    data = path.read_bytes()
    return {'sha256': sha(data), 'bytes': len(data)}
def cache():
    base = W/'competition/deepeye/simulator/.godot'
    return {p.relative_to(W).as_posix(): pin(p) for p in sorted(base.rglob('*')) if p.is_file()}

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
scope_path = ROOT/'docs/competition/deepeye-2026/immutable_scope.json'
scope = json.loads(scope_path.read_bytes())
actual = sha(json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
assert actual == EXPECTED and len(scope['requirements']) == 15
transfer = json.loads((ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json').read_bytes())
assert transfer['director_generation'] == 3 and transfer['status'] == 'active'
assert transfer['new_director_thread_id'] == '01a16988-bdcb-70e1-ae10-1304b5cf7875'
protection = json.loads((OWN.parent.parent/'r03-mailbox-stop-main-review-20261020/application.json').read_bytes())['protected_files']
protected = {name: pin(W/name) for name in protection}
assert all(protected[name]['sha256'] == expected for name, expected in protection.items())
index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
if not index_path.is_absolute(): index_path = W/index_path
files = git('ls-files', '-z', 'competition/deepeye').decode().split('\0')
selected = [name for name in files if name and '/evidence/' not in name and Path(name).suffix in ('.py','.json','.csv')]
inputs = {}
for name in selected:
    src = W/name
    if not src.is_file(): continue
    inputs[name] = pin(src)
    for directory in ('baseline', 'staging'):
        target = OWN/directory/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, target)
for name in ('pc_direct_runtime.py', 'actor_composition.py'):
    relative = Path('competition/deepeye/simulation/authority')/name
    target = OWN/'candidate'/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(W/relative, target)
(OWN/'runs').mkdir()
(OWN/'baseline-status.bin').write_bytes(git('status', '--porcelain=v1', '-z'))
record = dict(schema=1, work_id='A-PCDIRECT-IDLE-EXPIRY-20261024-v1', agent='/root/pcdirect_idle_expiry_author',
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), scope='only author directory',
    product_head=HEAD, requirements_sha256=actual, director_generation=3,
    task_route='recorded Desktop/native; mesh lease optional, not acquired',
    input_pins=inputs, protected=protected, index=pin(index_path), index_path=str(index_path),
    cache=cache(), scope_json=pin(scope_path), transfer=pin(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json'))
(OWN/'baseline-pins.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(product_head=HEAD, requirements_sha256=actual, copied_inputs=len(inputs), protected=len(protected), cache_files=len(record['cache'])), ensure_ascii=False))
