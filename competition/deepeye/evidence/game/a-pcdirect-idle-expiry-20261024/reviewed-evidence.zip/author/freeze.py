from pathlib import Path
import ast, datetime, hashlib, importlib.metadata, json, os, subprocess, sys

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[3]
W = ROOT/'.local/deepeye-implementation-a'
GIT = Path('C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe')
def sha(data): return hashlib.sha256(data).hexdigest()
def pin(path):
    data = path.read_bytes()
    return dict(sha256=sha(data), bytes=len(data))
def git(*args): return subprocess.check_output([str(GIT), '-C', str(W), *args])
def ast_method(path, cls, method):
    text = path.read_text(encoding='utf-8')
    nodes = ast.parse(text).body
    if cls is not None:
        nodes = next(node for node in nodes if isinstance(node, ast.ClassDef) and node.name == cls).body
    node = next(node for node in nodes if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == method)
    return ast.get_source_segment(text, node)

before = json.loads((OWN/'baseline-pins.json').read_bytes())
assert git('rev-parse', 'HEAD').decode().strip() == before['product_head']
assert pin(Path(before['index_path'])) == before['index']
assert git('status', '--porcelain=v1', '-z') == (OWN/'baseline-status.bin').read_bytes()
assert all(pin(W/name) == expected for name, expected in before['protected'].items())
cache = {p.relative_to(W).as_posix(): pin(p) for p in sorted((W/'competition/deepeye/simulator/.godot').rglob('*')) if p.is_file()}
assert cache == before['cache']
assert all(pin(W/name) == expected for name, expected in before['input_pins'].items())
scope = json.loads(git('show', before['product_head']+':docs/competition/deepeye-2026/immutable_scope.json'))
published_contract = sha(json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
assert published_contract == before['requirements_sha256']
candidate = OWN/'candidate'
runtime = 'competition/deepeye/simulation/authority/pc_direct_runtime.py'
composition = 'competition/deepeye/simulation/authority/actor_composition.py'
unchanged = {}
for name, cls, methods in ((runtime, 'PcDirectRuntime', ('boot','board','observe','command','stop','_advance','_ready','step')),
                           (composition, 'ActorComposition', ('_dispatch_stop','_retire','_cleanup','accept_boot','accept_board','accept_observation','accept_completion','accept_command','step')),
                           (composition, None, ('_entry','create_authority','_production_channels'))):
    for method in methods:
        left = ast_method(OWN/'baseline'/name, cls, method)
        right = ast_method(candidate/name, cls, method)
        assert left == right, (name, cls, method)
        unchanged[(cls+'.' if cls else '')+method] = sha(left.encode())
for method in ('prepare_step','commit_step'):
    path = OWN/'baseline'/composition
    assert ast_method(path, '_Dependencies', method) == ast_method(candidate/composition, '_Dependencies', method)
    unchanged['_Dependencies.'+method] = sha(ast_method(path, '_Dependencies', method).encode())

dep_root = ROOT/'.local/deepeye-host-deps'
sys.path.insert(0, str(dep_root))
import jsonschema
dependency = dict(executable=sys.executable, executable_pin=pin(Path(sys.executable)),
    python_version=sys.version, jsonschema_version=importlib.metadata.version('jsonschema'),
    jsonschema_module=str(Path(jsonschema.__file__).resolve()), jsonschema_module_pin=pin(Path(jsonschema.__file__)),
    dependency_root=str(dep_root), no_install=True)
(OWN/'runtime-metadata.json').write_text(json.dumps(dependency, indent=2)+'\n', encoding='utf-8')
selected = {p.relative_to(candidate).as_posix(): pin(p) for p in sorted(candidate.rglob('*')) if p.is_file()}
assert len(selected) == 4
test = 'competition/deepeye/tests/simulation/test_pc_direct_idle_expiry.py'
log = (OWN/'runs/green-03/stderr.bin').read_text(encoding='utf-8')
assert 'Ran 14 tests' in log and log.rstrip().endswith('OK')
executed_names = [line.split(' (',1)[0] for line in log.splitlines() if line.startswith('test_idle_')]
assert len(executed_names) == 14 and len(set(executed_names)) == 14
green = json.loads((OWN/'runs/green-03/command.json').read_bytes())
assert green['exit_code'] == 0 and green['wait_completed']
for name in (runtime, composition, test):
    assert green['candidate_pins'][name] == selected[name]['sha256']
red = (OWN/'runs/red-02/stderr.bin').read_text(encoding='utf-8')
assert "AssertionError: 'ACTIVE' == 'ACTIVE'" in red and 'FAILED (failures=2)' in red
audit = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), product_head=before['product_head'],
    requirements_sha256=published_contract, W_all_input_pins_unchanged=True,
    C4_unchanged=True, index_unchanged=True, status_unchanged=True, cache_unchanged=True,
    unchanged_methods=unchanged, all_unselected_staging_sources_same_as_baseline=all(
        pin(OWN/'staging'/name)==expected for name, expected in before['input_pins'].items()
        if name not in (runtime, composition)),
    tests=dict(attempts=3, budget=4, behavioral_red='red-02, 2 failures: ACTIVE remained ACTIVE',
               green='green-03, 14 new methods pass', executed_names=executed_names,
               first_attempt='red-01 import failed before test methods: project venv missing jsonschema',
               dependency_resolution='existing .local/deepeye-host-deps, child-only PYTHONPATH'),
    selected_files=selected, writes_stopped_after_freeze=True,
    product_acceptance=dict(G03='not_run',R03='not_run',all29='not_run'))
assert audit['all_unselected_staging_sources_same_as_baseline']
(OWN/'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
report = '''# A-PCDIRECT-IDLE-EXPIRY-20261024-v1 author report

Candidate only; no product worktree or external action. Director Gen3 and the
published H01-H15 contract c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804
were verified against exact product head 5f147d5003dc0b2f4eb88d4cb3d9e79afb5a55d8.

## Result

Added frozen ExpiryStatus and owner/no-reentry check_expiry using the existing
actual clock/watchdog. It retains normal non-latching command expiry and uses
_last_command to detect an expiry already cleared by an earlier event. Existing
BOOT resets history. Composition polls its original actor, then probes only
ACTIVE runtime and retires through existing revoke/cleanup with _STOPPED.

No new movement, verifier/AI lease call, preparation or CAS occurs in the probe.
One focused test performs a real numerical executor CAS first, then at original
TTL polls stop and preserves pose/revision/frame with no additional prepare/CAS.
It also rejects late completion/command/board and a later step without revival.
General stop/revoke revisions may advance; they are not motion revisions.

## Actual new commands

1. red-01: exit1/PID42620/wait completed; harness ModuleNotFoundError jsonschema,
   before all test methods and before implementation. Preserved, not behavioral RED.
2. red-02: exit1/PID35832/wait completed; 2 explicit new behavioral tests, 2 FAIL
   because original command/heartbeat expiry polls left ACTIVE admission. The
   command-TTL case had already observed one real numerical motion CAS.
3. green-03: exit0/PID35284/wait completed; all14 explicitly selected new tests
   passed, unittest0.604s, outer1.091s. Exact source/test SHA binding is audit.json.
   One command budget remains unused; no passing repetition or old suite run.

The existing project interpreter plus existing .local/deepeye-host-deps were used,
with child-only PYTHONPATH/TEMP/TMP and -B. Nothing was installed. A separate
bundled-Python import probe also lacked jsonschema; no test body ran there.
runtime-metadata.json records actual executable/version/jsonschema provenance.
stderr contains unittest's normal verbose result stream, not engine diagnostics.

New14 controls cover deadline-minus-one/equality, original deadline despite ACK,
heartbeat and duplicate, earlier heartbeat timeout, time crossing during actor
poll, command already cleared by board event, initial unbound and uncommanded
wait, runtime wait before heartbeat, retained latch, fresh BOOT history reset,
invalid/regressing/exception clocks, caught probe reentry, step exclusion,
foreign-thread refusal, malformed call, positive CAS then idle stop, and no
resurrection. Explicit suite/load_tests exclude every inherited historical method.

## Scope and verification

Only four candidate files are selectable. audit.json proves W source inputs,
C4, status/index and all6 existing .godot cache files unchanged. AST source
segments of runtime boot/advance/events/ready/final step and composition entry,
factory/provider gate, dependencies prepare/commit and retirement are unchanged.
All other staging sources match baseline pins, including v2/mailbox/executor.

Synthetic clocks/channel events/native API boundaries are offline fixtures.
The runtime, candidate/mailbox and numerical geometry executor logic are real
software, but there is no real native actor, provider, model, board, Godot, GUI,
service, network, peer message, or physical observation. This is no proof of an
OS scheduling deadline, owner-death protection or complete PC_DIRECT/H12. The
production refusal remains closed. G03/R03/all29 remain not_run; H01-H15 unchanged.

All author writes stop after manifest freeze. Root owns independent review and
selection/publication. No mesh lease was required on this recorded Desktop/native
route; no native completion endpoint was called.
'''
(OWN/'report.md').write_text(report, encoding='utf-8')
members = ['baseline-pins.json','baseline-status.bin','runtime-metadata.json','audit.json','report.md',
           'setup.py','run_attempt.py','freeze.py']
members += ['candidate/'+name for name in selected]
members += ['runs/'+attempt+'/'+name for attempt in ('red-01','red-02','green-03')
            for name in ('command.json','stdout.bin','stderr.bin')]
manifest = dict(schema=1, work_id='A-PCDIRECT-IDLE-EXPIRY-20261024-v1',
    selected_files=selected, files={name: pin(OWN/name) for name in members})
(OWN/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(manifest=pin(OWN/'manifest.json'), selected=selected,
                      tests=14, attempts=3, writes_stopped=True), ensure_ascii=False))
