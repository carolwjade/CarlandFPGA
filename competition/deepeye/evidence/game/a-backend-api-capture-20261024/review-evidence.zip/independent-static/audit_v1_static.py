"""Reviewer hash/AST/text analysis only; candidate bytes are never imported/run."""
import ast,difflib,hashlib,json,re,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
S=OUT/'candidate-snapshot'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,value):
 p=OUT/name;assert not p.exists(),name
 p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

old=(S/'inputs/launcher_v2.py').read_text(encoding='utf-8')
new=(S/'launcher.py').read_text(encoding='utf-8')
launcher_pairs={
 'A-GAME3D-ENUM-ASSOCIATION-CAPTURE-20261024-v1':'A-GAME3D-BACKEND-API-CAPTURE-20261024-v1',
 'child-ff673689f0da408998a3a64ed82abd10':'child-9418116675a744ad9b39a7c4fe7f220a',
 '.local/deepeye-game3d-enum-association-capture-20261024':'.local/deepeye-game3d-backend-api-capture-20261024',
 'execution-plan-v2.json':'execution-plan.json',
}
derived=old
for before,after in launcher_pairs.items():
 assert derived.count(before)==1,before
 derived=derived.replace(before,after)
before='!= ("windows", "vulkan", "forward_plus"):'
after='!= ("Windows", "vulkan", "forward_plus"):'
assert derived.count(before)==1
derived=derived.replace(before,after)
assert derived==new,'Unauthorized launcher text delta'
delta=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='immutable-61c6de6/launcher_v2.py',tofile='9418/launcher.py'))
assert delta==(S/'launcher.diff').read_text(encoding='utf-8')
oldtree=ast.parse(old);newtree=ast.parse(new)
def functions(tree):
 result={}
 def walk(node,prefix=''):
  for child in ast.iter_child_nodes(node):
   if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
    name=prefix+child.name
    if not isinstance(child,ast.ClassDef):result[name]=ast.dump(child,include_attributes=False)
    walk(child,name+'.')
   else:walk(child,prefix)
 walk(tree)
 return result
of=functions(oldtree);nf=functions(newtree)
assert set(of)==set(nf)
changed=[name for name in of if of[name]!=nf[name]]
assert changed==['validate_capture_outputs'],changed
mapped=new
for before,after in launcher_pairs.items():mapped=mapped.replace(after,before)
mapped=mapped.replace('!= ("Windows", "vulkan", "forward_plus"):','!= ("windows", "vulkan", "forward_plus"):')
assert ast.dump(oldtree,include_attributes=False)==ast.dump(ast.parse(mapped),include_attributes=False)

oldgd=(S/'inputs/capture_621.gd').read_text(encoding='utf-8')
newgd=(S/'capture.gd').read_text(encoding='utf-8')
def gd_functions(text):
 matches=list(re.finditer(r'^func ([A-Za-z_][A-Za-z_0-9]*)\(',text,re.M));result={}
 for i,m in enumerate(matches):result[m.group(1)]=text[m.start():matches[i+1].start() if i+1<len(matches) else len(text)]
 return result
og=gd_functions(oldgd);ng=gd_functions(newgd)
assert set(ng)-set(og)=={'_record_backend_observation'}
assert all(og[name]==ng[name] for name in og if name!='_run')
suffix='\tvar packed := load("res://viewer/main.tscn") as PackedScene'
old_suffix=oldgd[oldgd.index(suffix):]
new_suffix=newgd[newgd.index(suffix):]
report_old='\t\t"display_driver":DisplayServer.get_name(), "rendering_driver":RenderingServer.get_current_rendering_driver_name(),\n\t\t"rendering_method":RenderingServer.get_current_rendering_method(),'
report_new='\t\t"display_driver":raw_display, "rendering_driver":raw_driver, "rendering_method":raw_method,\n\t\t"backend_values_provenance":{"phase":"pre_backend_admission_before_scene_load",\n\t\t\t"reference":"backend-observation.json", "process_clock":process_clock,\n\t\t\t"fresh_final_or_per_frame_observation":false},'
assert new_suffix.count(report_new)==1
assert new_suffix.replace(report_new,report_old)==old_suffix
for getter in ['DisplayServer.get_name()','RenderingServer.get_current_rendering_driver_name()','RenderingServer.get_current_rendering_method()']:
 assert newgd.count(getter)==1,getter
record_at=newgd.index('\tif not _record_backend_observation(observation):')
gate_at=newgd.index('\tif not matches["display_driver"]')
load_at=newgd.index(suffix)
assert record_at<gate_at<load_at
diff=''.join(difflib.unified_diff(oldgd.splitlines(True),newgd.splitlines(True),fromfile='immutable-6210469/capture.gd',tofile='9418/capture.gd'))
assert diff==(S/'capture.diff').read_text(encoding='utf-8')
dump('v1-static-diff-AST-result.json',{
 'schema':1,'launcher_sha256':sha(new.encode()),'capture_sha256':sha(newgd.encode()),
 'launcher_exact_text_after_authorized_four_identity_replacements_and_validator_literal':True,
 'launcher_function_count':len(of),'launcher_functions_changed':changed,'unchanged_function_count':len(of)-len(changed),
 'per_function':{name:{'old_AST_sha256':sha(of[name].encode()),'new_AST_sha256':sha(nf[name].encode()),'unchanged':of[name]==nf[name]} for name in of},
 'whole_launcher_AST_equal_after_authorized_literals':True,'supplied_launcher_diff_independently_equal':True,
 'adapter_original_helpers_byte_equal':True,'adapter_suffix_equal_after_explicit_final_snapshot_report_exception':True,
 'new_adapter_helper':'_record_backend_observation','getter_call_counts':[1,1,1],
 'record_call_precedes_strict_gate_precedes_original_scene_load':True,'supplied_capture_diff_independently_equal':True,
 'P05':'blocked by retained F01; not a claimed IO/native pass','GDScript_parse_or_execution':False,
})

pins=json.loads((S/'source-pins.json').read_bytes())
baseline=json.loads((S/'source-baseline.json').read_bytes())
product=Path(pins['product']);snapshot=Path(pins['snapshot'])
GIT=Path('C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe')
published=pins['published_game_head']
assert len(pins['files'])==52
requests=''.join(published+':'+item['path']+'\n' for item in pins['files']).encode('utf-8')
cp=subprocess.run([str(GIT),'-C',str(product),'cat-file','--batch'],input=requests,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
assert cp.returncode==0,cp.stderr
raw=cp.stdout;cursor=0;files=[]
for item in pins['files']:
 line_end=raw.index(b'\n',cursor);header=raw[cursor:line_end].decode();parts=header.split();assert parts[1]=='blob',header
 size=int(parts[2]);start=line_end+1;blob=raw[start:start+size];cursor=start+size+1;assert raw[cursor-1:cursor]==b'\n'
 actual=(product/item['path']).read_bytes();fresh=(snapshot/item['path']).read_bytes()
 assert len(actual)==len(fresh)==len(blob)==item['bytes']
 assert sha(actual)==sha(fresh)==sha(blob)==item['sha256'],item['path']
 files.append(dict(path=item['path'],bytes=len(actual),sha256=sha(actual),current_product_equals_fresh_snapshot_equals_published_blob=True))
assert cursor==len(raw)
head=subprocess.run([str(GIT),'-C',str(product),'rev-parse','HEAD'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
assert head.returncode==0
c4=[]
for name,want in baseline['C4'].items():
 b=(product/name).read_bytes();assert sha(b)==want,name
 c4.append({'path':name,'sha256':sha(b),'matches_author_baseline':True})
cache=product/'competition/deepeye/simulator/.godot';cache_pins=[]
for item in baseline['original_cache']:
 b=(cache/item['path']).read_bytes();assert len(b)==item['bytes'] and sha(b)==item['sha256'],item['path']
 cache_pins.append({'path':item['path'],'sha256':sha(b),'matches_author_baseline':True})
index=Path(baseline['git_index']['path']);index_now=sha(index.read_bytes())
plan=json.loads((S/'execution-plan.json').read_bytes());engine=Path(plan['engine']);engine_sha=sha(engine.read_bytes());assert engine_sha==plan['engine_sha256']
assert not (snapshot/'competition/deepeye/simulator/.godot').exists()
wrapper=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024/run_backend_api_capture_once.py'
assert sha(wrapper.read_bytes())=='845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5'
dump('v1-52source-engine-preservation.json',{
 'schema':1,'published_source_only_commit':published,'observed_product_HEAD':head.stdout.decode().strip(),
 'HEAD_scope':'Read-only identity; legal root evidence publication may advance HEAD/index. No old execution is inherited to this head.',
 'source_count':len(files),'source_pins':files,'C4':c4,'original_cache_existing_members':cache_pins,
 'cache_inventory_scope':'Only six author-baseline existing members rehashed; no cache mutation or runtime invocation.',
 'index_current_sha256':index_now,'index_matches_author_baseline':index_now==baseline['git_index']['sha256'],'index_not_written_by_reviewer':True,
 'fresh_snapshot_dot_godot_exists':False,'engine_sha256':engine_sha,'engine_invocations':0,
 'root_wrapper_sha256':sha(wrapper.read_bytes()),'metadata_git_source_read_processes':2,
 'candidate_or_wrapper_imports_tests':0,'target_native_engine_process_calls':0,
})
print(json.dumps({'function_count':len(of),'unchanged_functions':len(of)-1,'only_changed_function':'validate_capture_outputs','52_product_snapshot_published_bytes_match':True,'C4_baseline_match':True,'engine_hash_match':True,'P05':'blocked F01 retained','candidate_imports_tests_native':0}))
