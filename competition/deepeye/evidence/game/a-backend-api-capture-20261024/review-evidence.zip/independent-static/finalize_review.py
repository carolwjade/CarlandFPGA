"""Freeze reviewer artifacts after completed static analysis; no target execution."""
import hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,value):
 p=OUT/name;assert not p.exists(),name
 p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old_manifests={
 'phase1-frozen-manifest.json':'85b7402fe3e47d45dbcf7a61ccec19fee005e0561d6007e6e75941b693ea4b7a',
 'phase1-addendum-manifest.json':'b2893778a37c5722da11a90ac45b0b5b1b66c46d45c5605f5965f02e356b613c',
 'root-wrapper-review-manifest.json':'a3e699744ab192914f435f9b734cb5dab2239e7cd545bdf50ce0e199b70d3bd7',
 'F01-delta-frozen-manifest.json':'7d0c95969321dc8ccec734259612b650d05eecdc1ae1356bc0e0045033df3d64',
 'v1-interim-review-manifest.json':'2a7675d7e42a56c360afd3853cf5a3c647b5727672b32999f4a952b143a4be1a',
}
prior_counts={}
for name,want in old_manifests.items():
 b=(OUT/name).read_bytes();assert sha(b)==want,name
 m=json.loads(b);assert m['member_count']==len(m['files'])
 for path,pin in m['files'].items():
  raw=(OUT/path).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],name+':'+path
 prior_counts[name]=len(m['files'])
source_pins=json.loads((OUT/'final-source-pins.json').read_bytes())
delta=json.loads((OUT/'v2-static-delta-result.json').read_bytes())
result={
 'schema':1,'job_id':'child-018eab8f8562451ea3ca05a73ba80e23',
 'work_id':'A-GAME3D-BACKEND-API-CAPTURE-REVIEW-20261024-v1','canonical_agent_id':'/root/pc_direct_window_review',
 'result':'independent static review done; no remaining static blocker in exact v2; root decides later execution/acceptance',
 'F01':{'original_v1':'source-level blocked, original35 preserved','v2':'source-level resolved by fresh same-process complete byte readback gate','runtime_proof':False},
 'frozen_groups':{f'P{x:02d}':'reviewed; no remaining static blocker; runtime unproven' for x in range(1,12)},
 'frozen_delta':delta['D01_D07'],'v1_original_members_verified':35,'v2_members_verified':34,
 'v1_review_snapshot_files_including_manifest':36,'v2_review_snapshot_files_including_manifest':35,
 'report_sha256':sha((OUT/'report.md').read_bytes()),'final_source_pins_sha256':sha((OUT/'final-source-pins.json').read_bytes()),
 'launcher_v2_sha256':source_pins['launcher_v2.py'],'capture_v2_sha256':source_pins['capture_v2.gd'],
 'source_pins_v2_sha256':source_pins['source-pins-v2.json'],'execution_plan_v2_sha256':source_pins['execution-plan-v2.json'],
 'root_wrapper_sha256':source_pins['root_wrapper'],'engine_sha256':source_pins['engine'],
 'raw_source_line_references_corrected_separately':True,'prior_freezes_verified_members':prior_counts,
 'prior_exposure_disclosed_not_blind':True,
 'retained_raw_metadata_limit':'source_pins.json and adapter_variant v1 are retained declarations only. Actual future v2 must be bound by external exact v2 sourcepins/plan/candidate hashes and original Popen/actual Godot PID evidence. Parent explicitly accepted this limitation; no _run change authorized.',
 'candidate_imports':0,'wrapper_imports_or_execution':0,'producer_tests_executed':0,'old_tests_executed':0,
 'GDScript_parse_or_run':0,'target_Win32_desktop_window_engine_probe_process_calls':0,
 'reviewer_own_metadata_source_hash_AST_scripts_executed':True,'metadata_Git_source_read_processes':2,
 'product_index_cache_policy_board_UI_service_peer_group_writes_or_calls':0,
 'root_future_phase2_execution_authorized_by_this_review':False,'old_failures_and_budget0_unchanged':True,
 'H01_H15_full_H12':'preserved/open','requirements_sha256':source_pins['requirements_sha256'],
 'G03':'not_run','R03':'not_run','all29':'not_run',
}
dump('result.json',result)
excluded={'lease.private.json','artifact-manifest.json','final-freeze-verification.json','native-complete-request.json','native-complete-response.json','native-terminal-readback.json'}
members={}
for p in sorted(OUT.rglob('*')):
 if p.is_file() and p.relative_to(OUT).as_posix() not in excluded:
  b=p.read_bytes();members[p.relative_to(OUT).as_posix()]={'bytes':len(b),'sha256':sha(b)}
dump('artifact-manifest.json',{'schema':1,'files':members,'member_count':len(members),'manifest_self_member':False,'excluded':sorted(excluded),'scope':'exact independent static source review, no target execution'})
for name,pin in members.items():
 b=(OUT/name).read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],name
manifest_sha=sha((OUT/'artifact-manifest.json').read_bytes())
dump('final-freeze-verification.json',{'schema':1,'member_count_verified':len(members),'manifest_sha256':manifest_sha,'report_sha256':result['report_sha256'],'result_sha256':sha((OUT/'result.json').read_bytes()),'final_source_pins_sha256':result['final_source_pins_sha256'],'prior_freezes_member_counts':prior_counts,'native_complete_to_follow_only_after_this_freeze':True})
print(json.dumps({'members':len(members),'manifest_sha256':manifest_sha,'report_sha256':result['report_sha256'],'result_sha256':sha((OUT/'result.json').read_bytes()),'final_source_pins_sha256':result['final_source_pins_sha256'],'F01':'source-level resolved/no runtimeproof','target_calls':0}))
