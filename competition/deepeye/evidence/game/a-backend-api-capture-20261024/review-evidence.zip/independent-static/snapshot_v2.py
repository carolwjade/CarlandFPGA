import hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
SRC=ROOT/'.planning/deepeye-resume-20261018/game3d-backend-api-capture-20261024'
DEST=OUT/'v2-snapshot';DEST.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
b=(SRC/'v2-manifest.json').read_bytes()
assert sha(b)=='7e1de6096c9ffc64d1c77b84c6cf2bf3e78f064064cb51e62c452432518dd006'
m=json.loads(b);assert m['job_id']=='child-9418116675a744ad9b39a7c4fe7f220a' and m['count']==len(m['members'])==34
(DEST/'v2-manifest.json').write_bytes(b)
verified=[]
for item in m['members']:
 name=item['path'];p=Path(name);assert not p.is_absolute() and '..' not in p.parts
 raw=(SRC/name).read_bytes();frozen=(SRC/item['frozen_path']).read_bytes()
 assert len(raw)==item['bytes'] and sha(raw)==item['sha256'] and raw==frozen,name
 target=DEST/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);assert target.read_bytes()==raw
 verified.append({'path':name,'bytes':len(raw),'sha256':sha(raw),'live_equals_frozen_equals_review_snapshot':True})
assert sum(x['bytes'] for x in verified)==m['total_bytes']
old=(SRC/'phase1-manifest.json').read_bytes()
assert sha(old)=='51b9fbb301326c7b9c96aea9a3469f3f03da1de766c03c025ea7fd115ad156ed'
old_m=json.loads(old)
for item in old_m['members']:
 raw=(SRC/item['path']).read_bytes()
 assert len(raw)==item['bytes'] and sha(raw)==item['sha256'],item['path']
 assert raw==(SRC/item['frozen_path']).read_bytes()==(OUT/'candidate-snapshot'/item['path']).read_bytes(),item['path']
r={'schema':1,'v2_manifest_sha256':sha(b),'v2_member_count':len(verified),'v2_snapshot_files_including_manifest':35,'total_member_bytes':sum(x['bytes'] for x in verified),'verified':verified,'original35_active_frozen_review_bytes_reverified_unchanged':True,'candidate_imports_tests_native_calls':0}
p=OUT/'v2-snapshot-verification.json';assert not p.exists();p.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in r.items() if k!='verified'}))
