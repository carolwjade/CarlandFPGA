"""Reviewer-only source/AST/diff checks; never import/execute candidate."""
import ast,difflib,hashlib,json,re
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
V1=OUT/'candidate-snapshot';V2=OUT/'v2-snapshot'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,value):
 p=OUT/name;assert not p.exists(),name
 p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old=(V1/'launcher.py').read_text(encoding='utf-8');new=(V2/'launcher_v2.py').read_text(encoding='utf-8')
assert old.count('PLAN = OUT / "execution-plan.json"')==1
assert old.replace('PLAN = OUT / "execution-plan.json"','PLAN = OUT / "execution-plan-v2.json"')==new
delta=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='frozen-phase1/launcher.py',tofile='F01/launcher_v2.py'))
assert delta==(V2/'launcher-v2.diff').read_text(encoding='utf-8')
def defs(tree):
 result={}
 def visit(node,prefix=''):
  for child in ast.iter_child_nodes(node):
   if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
    name=prefix+child.name
    result[name]=ast.dump(child,include_attributes=False)
    visit(child,name+'.')
   else:visit(child,prefix)
 visit(tree);return result
a=defs(ast.parse(old));b=defs(ast.parse(new));assert a==b
normalized=new.replace('PLAN = OUT / "execution-plan-v2.json"','PLAN = OUT / "execution-plan.json"')
assert ast.dump(ast.parse(old),include_attributes=False)==ast.dump(ast.parse(normalized),include_attributes=False)
oldgd=(V1/'capture.gd').read_text(encoding='utf-8');newgd=(V2/'capture_v2.gd').read_text(encoding='utf-8')
def gdfunc(text):
 matches=list(re.finditer(r'^func ([a-zA-Z_][a-zA-Z_0-9]*)\(',text,re.M));r={}
 for i,m in enumerate(matches):r[m.group(1)]=text[m.start():matches[i+1].start() if i+1<len(matches) else len(text)]
 return r
oa=gdfunc(oldgd);na=gdfunc(newgd);assert set(oa)==set(na)
assert [n for n in oa if oa[n]!=na[n]]==['_record_backend_observation']
assert oldgd[:oldgd.index('func _record_backend_observation')]==newgd[:newgd.index('func _record_backend_observation')]
assert oa['_run']==na['_run']
delta=''.join(difflib.unified_diff(oldgd.splitlines(True),newgd.splitlines(True),fromfile='frozen-phase1/capture.gd',tofile='F01/capture_v2.gd'))
assert delta==(V2/'capture-v2.diff').read_text(encoding='utf-8')
helper=na['_record_backend_observation']
assert helper.count('FileAccess.open(path, FileAccess.READ)')==1
assert helper.count('read_file.get_buffer(payload.size())')==1
assert helper.count('read_file.close()')==3
assert helper.count('file.store_buffer(payload)')==1
assert helper.index('file.close()\n\tio["close_returned"] = true')<helper.index('var read_file := FileAccess.open(path, FileAccess.READ)')
guards=[
 'if read_file == null or read_open_error != OK:',
 'if read_length != payload.size() or read_start_position != 0 or read_length_error != OK:',
 'var read_payload := read_file.get_buffer(payload.size())\n\tvar read_error := read_file.get_error()\n\tvar read_end_position := read_file.get_position()',
 'var read_ok := read_payload.size() == payload.size() and read_payload == payload and read_error == OK and read_end_position == payload.size()',
 '\treturn read_ok',
]
assert all(x in helper for x in guards)
assert all(x.strip() in ['return false','return read_ok'] for x in helper.splitlines() if x.lstrip().startswith('return '))
assert helper.rindex('read_file.close()')<helper.index('var read_ok :=')<helper.index('\treturn read_ok')
v1p=json.loads((V1/'execution-plan.json').read_bytes());v2p=json.loads((V2/'execution-plan-v2.json').read_bytes())
plan_changed=[k for k in set(v1p)|set(v2p) if v1p.get(k)!=v2p.get(k)]
assert set(plan_changed)=={'phase','adapter','adapter_sha256','launcher_sha256','source_pins','source_pins_sha256','backend_observation','F01_root_source_decision_sha256'}
v1s=json.loads((V1/'source-pins.json').read_bytes());v2s=json.loads((V2/'source-pins-v2.json').read_bytes())
assert v2s['files']==v1s['files']
assert v2p['adapter_sha256']==sha(newgd.encode())==v2s['capture_sha256']
assert v2p['launcher_sha256']==sha(new.encode())==v2s['launcher_sha256']
assert v2p['source_pins_sha256']==sha((V2/'source-pins-v2.json').read_bytes())
v1args=json.loads((V1/'argv.json').read_bytes());v2args=json.loads((V2/'argv-v2.json').read_bytes())
expected_engine=[x.replace('capture.gd','capture_v2.gd') if x==v1p['adapter'] else x for x in v1args['engine_argv']]
assert v2args['engine_argv']==expected_engine
expected_launcher=[x.replace('launcher.py','launcher_v2.py') if x.endswith('/launcher.py') or x.endswith('\\launcher.py') else x for x in v1args['launcher_argv']]
assert v2args['launcher_argv']==expected_launcher
assert v2args['plan_sha256']==sha((V2/'execution-plan-v2.json').read_bytes())
core=(V2/'f01-research/primary/core/io/file_access.cpp').read_text(encoding='utf-8').splitlines()
assert 'Vector<uint8_t> FileAccess::get_buffer(int64_t p_length) const {'==core[547]
assert 'data.resize(len);' in '\n'.join(core[547:568])
packed=(V2/'f01-research/primary/doc/classes/PackedByteArray.xml').read_text(encoding='utf-8').splitlines()
assert 'all equal bytes at the corresponding indices' in packed[580]
windows_raw=(V2/'f01-research/primary/drivers/windows/file_access_windows.cpp').read_bytes()
assert sha(windows_raw)=='edf1a55501f5b55e6e7ccc2e07e271f3016c557e973fb182c2a40cbb7f9f7139'
assert hashlib.sha1(b'blob '+str(len(windows_raw)).encode()+b'\0'+windows_raw).hexdigest()=='6f9f466abd4062c6b37e7a2c29332398aa66afbe'
lines=windows_raw.decode('utf-8').splitlines()
spans=json.loads((V2/'f01-research/raw-source-line-spans.json').read_bytes())
for entry in spans['spans']:
 raw=(V2/'f01-research/primary'/entry['source']).read_text(encoding='utf-8').splitlines()
 assert raw[entry['first_line']-1].startswith(entry['prefix'])
 assert raw[entry['last_line']-1]=='}'
corrected=''
for first,last in [(53,67),(237,244),(311,330),(336,355),(375,400)]:
 corrected+='--- raw L%d-L%d ---\n'%(first,last)+'\n'.join('%d: %s'%(n,lines[n-1]) for n in range(first,last+1))+'\n'
(OUT/'drivers__windows__file_access_windows.raw-corrected.focused.txt').write_text(corrected,encoding='utf-8')
dump('primary-raw-line-correction.json',{
 'schema':1,'original_records_retained':True,'reason':'Earlier F01 function line references used web-displayed text positions, which omit blank lines. Earlier raw focused ranges are literal ranges but do not all bracket the named functions. Exact source hash is unchanged; this correction supersedes those location references only.',
 'source_sha256':sha(windows_raw),'source_blob_sha1':'6f9f466abd4062c6b37e7a2c29332398aa66afbe',
 'correct_raw_lines':{'check_errors':[53,67],'_close':[237,279],'fclose_call':242,'get_position':[311,319],'get_length':[321,330],'get_buffer':[336,351],'get_error':[353,355],'flush':[375,382],'fflush_call':378,'store_buffer':[384,400],'FileAccess_core_get_buffer':[548,568]},
 'author_raw_source_spans_independently_verified':True,'F01_root_cause_and_static_resolution_not_changed':True,
})
checks={
 'D01':'original35 and original freezes preserved; exact34 new members matched',
 'D02':'writer conditions/calls retained; actual flush/close unknown and cached error labelled',
 'D03':'writer close before distinct READ same path; non-null failed-open object closes',
 'D04':'exact length/error and cursor0 after get_length before read; failure closes',
 'D05':'one bounded read; immediate error; exact returned size/content/end cursor; unconditional post-read close',
 'D06':'only read_ok can return success; no independent/fsync/flush-success claim; runtime not executed',
 'D07':'only helper changes; _run byte-identical; all launcher defs AST identical; PLAN-only routing; native and fullscene controls preserved',
}
dump('v2-static-delta-result.json',{
 'schema':1,'status':'F01 source-level resolved in exact v2; no remaining static blocker; no runtime proof',
 'D01_D07':checks,'launcher_PLAN_only_exact_text_change':True,'launcher_all_functions_and_classes_AST_equal':True,
 'launcher_definitions_including_classes_methods_nested':len(a),'launcher_normalized_whole_AST_equal':True,
 'GDScript_only_changed_function':'_record_backend_observation','GDScript_run_byte_equal_v1':True,'GDScript_prefix_byte_equal_v1':True,
 'read_file_close_source_occurrences':3,'read_file_get_buffer_source_occurrences':1,'plan_changed_keys':sorted(plan_changed),
 'external_v2_identity':'source-pins-v2.json/execution-plan-v2.json exact hashes and candidate bytes; future root Popen and actual Godot PID are runtime evidence only when observed',
 'retained_declaration_limitation':'_run byte equality preserves declared source_pins.json pointing at v1 and adapter_variant v1. These are retained declarations, not v2 self-hashed source binding. Root explicitly accepted this limitation.',
 'candidate_wrapper_imports_tests':0,'GDScript_parse_run':False,'target_native_engine_process_calls':0,
})
# Final read-only preservation recheck; no new Git or runtime invocation required.
source_files=[]
for item in v2s['files']:
 for base in [Path(v2s['product']),Path(v2s['snapshot'])]:
  raw=(base/item['path']).read_bytes();assert len(raw)==item['bytes'] and sha(raw)==item['sha256'],str(base/item['path'])
 source_files.append(item)
baseline=json.loads((V1/'source-baseline.json').read_bytes());product=Path(v2s['product'])
for name,want in baseline['C4'].items():assert sha((product/name).read_bytes())==want,name
for item in baseline['original_cache']:
 raw=(product/'competition/deepeye/simulator/.godot'/item['path']).read_bytes();assert len(raw)==item['bytes'] and sha(raw)==item['sha256'],item['path']
assert sha(Path(v2p['engine']).read_bytes())==v2p['engine_sha256']
wrapper=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024/run_backend_api_capture_once.py'
assert sha(wrapper.read_bytes())=='845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5'
scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_bytes())
scope_sha=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8'))
assert scope_sha=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
dump('final-source-pins.json',{
 'schema':1,'job_id':'child-018eab8f8562451ea3ca05a73ba80e23',
 'author_v1_manifest_sha256':'51b9fbb301326c7b9c96aea9a3469f3f03da1de766c03c025ea7fd115ad156ed','author_v2_manifest_sha256':'7e1de6096c9ffc64d1c77b84c6cf2bf3e78f064064cb51e62c452432518dd006',
 'launcher_v2.py':sha((V2/'launcher_v2.py').read_bytes()),'capture_v2.gd':sha((V2/'capture_v2.gd').read_bytes()),
 'source-pins-v2.json':sha((V2/'source-pins-v2.json').read_bytes()),'execution-plan-v2.json':sha((V2/'execution-plan-v2.json').read_bytes()),
 'root_wrapper':sha(wrapper.read_bytes()),'engine':v2p['engine_sha256'],'requirements_sha256':scope_sha,
 'current_product_and_snapshot_files':source_files,'C4_matches_author_baseline':True,'six_existing_original_cache_members_match':True,
 'product_sources_match_published360b_blobs_by_previous_independent_v1_read_and_unchanged_file_map':True,
 'index_not_written_by_reviewer':True,'index_current_sha256':sha(Path(baseline['git_index']['path']).read_bytes()),
 'legal_root_HEAD_index_publication_allowed':True,'runtime_inherited_to_new_head':False,
})
print(json.dumps({'status':'no remaining static blocker; F01 source-level resolved/no runtime proof','all_launcher_defs_AST_equal':True,'only_helper_changed':True,'source52_C4_cache_engine_wrapper_hashes_match':True,'candidate_import_tests_target_calls':0}))
