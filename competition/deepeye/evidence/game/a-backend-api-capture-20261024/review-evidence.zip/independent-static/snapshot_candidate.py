import hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
SRC=ROOT/'.planning/deepeye-resume-20261018/game3d-backend-api-capture-20261024'
DEST=OUT/'candidate-snapshot'
DEST.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
b=(SRC/'phase1-manifest.json').read_bytes()
assert sha(b)=='51b9fbb301326c7b9c96aea9a3469f3f03da1de766c03c025ea7fd115ad156ed'
manifest=json.loads(b)
assert manifest['job_id']=='child-9418116675a744ad9b39a7c4fe7f220a'
assert manifest['count']==len(manifest['members'])==35
(DEST/'phase1-manifest.json').write_bytes(b)
verified=[]
for member in manifest['members']:
 name=member['path'];p=Path(name)
 assert not p.is_absolute() and '..' not in p.parts
 raw=(SRC/name).read_bytes();frozen=(SRC/member['frozen_path']).read_bytes()
 assert len(raw)==member['bytes'] and sha(raw)==member['sha256'],name
 assert raw==frozen,name
 target=DEST/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 assert target.read_bytes()==raw
 verified.append({'path':name,'bytes':len(raw),'sha256':sha(raw),'live_equals_frozen_equals_review_snapshot':True})
assert sum(x['bytes'] for x in verified)==manifest['total_bytes']
result={'schema':1,'author_manifest_sha256':sha(b),'author_manifest_members':35,'author_manifest_self_excluded':True,'author_live_frozen_snapshot_verified':verified,'snapshot_file_count_including_manifest':36,'total_member_bytes':sum(x['bytes'] for x in verified),'candidate_import_tests_native_calls':0}
(OUT/'candidate-snapshot-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='author_live_frozen_snapshot_verified'}))
