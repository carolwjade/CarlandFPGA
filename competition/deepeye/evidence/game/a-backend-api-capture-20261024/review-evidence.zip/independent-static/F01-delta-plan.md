# F01 readback delta review freeze

The exact Windows implementation does not propagate fflush/fclose failure into cached get_error. Original v1 is blocked under P05/O05; its35 members and source-only counterexample stay preserved.

D01-D07 and D-O01-D-O08 are frozen before any future v2 access. A distinct READ object opened after writer close, exact file length, initial cursor0, one precise get_buffer result with exact size/bytes/error/end cursor and close on each path can establish that the complete serialized payload was filesystem-visible to this process before scene load. The chosen strict read checks fail closed if any relevant observation is missing or mismatched.

This is a bounded source-logic assessment. It does not demonstrate that the lower-level fflush/fclose returned success, the physical media is durable, another process independently read the bytes, or the path cannot change later. No fsync requirement, new native API or fallback is added. Root still independently inspects later actual bytes. There is no current GDScript parse/execution or IO experiment.

Only root-unlocked exact new pins may be read next. Current source/candidate/native operations remain zero and the review lease stays active, without completion or polling.
