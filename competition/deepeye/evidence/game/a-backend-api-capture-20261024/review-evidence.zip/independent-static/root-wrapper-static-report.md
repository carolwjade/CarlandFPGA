# Root wrapper static review checkpoint

The pinned new wrapper845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5 has no static blocker within the frozen P10 scope. The author candidate remains unread and this lease remains active.

The reviewer independently hashed both exact wrapper bytes, regenerated the textual diff in memory, and compared normalized ASTs without importing or executing either file. The entire delta consists of eight single-occurrence string replacements: author job, output prefix, authorization filename, self-pin filename, author directory whitelist, and three accurate Popen executable exit/PID labels. Two function bodies preserve their control flow after those approved literals are normalized.

Lines19-36 check declared authorization, pinned paths/hashes, absent attempt output, candidate path and interpreter before launch. Lines38-43 create an exclusive started record and exclusive stdout/stderr then contain exactly one Popen call with CREATE_NO_WINDOW. Lines45-56 keep that same child object through child-receipt persistence errors and wait interruptions. The only child.wait call has no timeout. Repeating wait retains the original owner and does not repeat process creation. Lines57-63 are reachable after wait returns terminal; the saved executable code is expressly separate from Godot HANDLE evidence.

No new timeout/kill/terminate/reopen/replay path was introduced. The future root-owned configuration was not executed or treated as self-authenticating live validation; root still owns separate fresh author validation and runtime authorization. The existing consumed wrapper and its markers were not modified.

This is source/AST/dataflow evidence only. Zero wrapper/candidate imports or tests and zero target process, engine, Win32, desktop, window or probe calls occurred. No new author directory was read or listed. P01-P09/P11 candidate-dependent conclusions remain pending exact candidate pins. Old failed attempts, unknowns and budgets remain unchanged; H01-H15/full H12 stay open, G03/R03/all29 not_run.
