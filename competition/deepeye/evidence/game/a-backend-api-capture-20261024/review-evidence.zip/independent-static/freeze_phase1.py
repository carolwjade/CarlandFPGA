"""Reviewer metadata only; never reads/lists the new author directory."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
RESEARCH = ROOT / '.planning/deepeye-resume-20261018/game3d-backend-gate-research-20261024'
EXPECTED = 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write(name, value):
    target = OUT / name
    assert target.parent == OUT
    if target.exists():
        raise RuntimeError('Phase1 output already exists: ' + name)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def pin(path):
    b = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)).replace('\\', '/'), 'bytes': len(b), 'sha256': digest(b)}

scope = json.loads((ROOT / 'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
canonical = json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
assert digest(canonical) == EXPECTED
assert [x['id'] for x in scope['requirements']] == ['H%02d' % x for x in range(1, 16)]
transfer = json.loads((ROOT / '.planning/deepeye-desktop-handoff-20261015/transfer.json').read_text(encoding='utf-8'))
assert transfer['status'] == 'active' and transfer['director_generation'] == 3
assert transfer['new_director_thread_id'] == '01a16988-bdcb-70e1-ae10-1304b5cf7875'
assert transfer['physical_board_operator'] == 'A only'

old_manifest_path = RESEARCH / 'artifact-manifest.json'
old_manifest_bytes = old_manifest_path.read_bytes()
assert digest(old_manifest_bytes) == '39409634bf985521b21764cb6bc5e8f60f032d61353a13a5020921f897b78d8e'
old_manifest = json.loads(old_manifest_bytes)
assert len(old_manifest['files']) == old_manifest['member_count'] == 34
verified = []
for name, entry in old_manifest['files'].items():
    p = RESEARCH / name
    b = p.read_bytes()
    assert len(b) == entry['bytes'] and digest(b) == entry['sha256'], name
    verified.append(name)

fixed_paths = [
    'AGENTS.md',
    '.agents/skills/fpga-multi-node/SKILL.md',
    '.agents/skills/fpga-multi-node/skill-role.json',
    '.agents/skills/fpga-multi-node/references/protocol.md',
    '.agents/skills/pynq-z2-single-node/SKILL.md',
    '.agents/skills/pynq-z2-single-node/skill-role.json',
    '.planning/deepeye-desktop-handoff-20261015/transfer.json',
    '.planning/deepeye-desktop-handoff-20261023/handoff.md',
    'docs/competition/deepeye-2026/immutable_scope.md',
    'docs/competition/deepeye-2026/immutable_scope.json',
    '.planning/deepeye-resume-20261018/gen3-live-integration-20261024/backend-api-capture-root-design-decision.json',
]
research_inputs = [
    'artifact-manifest.json', 'backend-name-mapping.json', 'future-minimal-proposal.json', 'result.json',
    'primary-source-pins.json', 'primary-followup-pins.json',
    'platform__windows__display_server_windows.cpp.focused.txt',
    'servers__rendering__rendering_server.cpp.focused.txt', 'core__os__os.h.focused.txt',
    'doc__classes__DisplayServer.xml.excerpt.txt', 'doc__classes__RenderingServer.xml.excerpt.txt',
    'actual-inputs/capture.gd', 'actual-inputs/launcher_v2.py',
]
pins = [pin(ROOT / name) for name in fixed_paths] + [pin(RESEARCH / name) for name in research_inputs]
write('phase1-input-pins.json', {'schema': 1, 'files': pins, 'new_author_directory_read_or_listed': False})
write('contract-verification.json', {
    'schema': 1, 'contract': 'DEEPEYE-HUMAN-LOCK-20261014/revision1',
    'canonical_json': 'requirements only, UTF-8, ensure_ascii=False, sort_keys=True, compact separators',
    'canonical_requirements_bytes': len(canonical), 'requirements_sha256': digest(canonical),
    'H01_H15_ids_verified': True, 'full_H12': 'unchanged/open', 'director_generation': 3,
    'director_thread': transfer['new_director_thread_id'], 'board_operator': 'A only',
    'research_manifest_sha256': digest(old_manifest_bytes), 'research_members_verified': len(verified),
    'research_verified_member_names': verified, 'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run',
})

obligations = [
    ('P01', 'Identity, scope, and budget', 'Exact candidate/plan/wrapper/engine/source pins must bind the new author job/run and declared ownership. Recheck frozen research inputs; distinguish parent evidence-only HEAD movement from the unchanged 52 game files. Old failures, bytes, unknowns and exhausted budgets remain immutable. This review authorizes zero target calls.'),
    ('P02', 'Exact backend names', 'CLI remains windows/vulkan/forward_plus. API comparison is case-sensitive Windows/vulkan/forward_plus as supported by exact official commit ed1daf0bf001b61586d9930840f2f1394092c079. Reject aliases, case normalization, fallback, or enlarged backend sets.'),
    ('P03', 'One sample of each getter', 'Read DisplayServer.get_name(), RenderingServer.get_current_rendering_driver_name(), and RenderingServer.get_current_rendering_method() once each. Preserve all three actual raw values before the predicate, avoid compound short-circuit loss, and derive per-field comparisons and the gate from those same sampled values. No expected-value substitution or fabricated unavailable raw values.'),
    ('P04', 'Raw record identity and clocks', 'A new owned backend record must contain actual Godot PID, explicitly declared job/run/source identity, expected values and per-field matches, and a labelled process clock. Distinguish declared metadata from independent verification. Preserve native frame times as unknown where absent; no inferred epoch alignment or cross-clock cause.'),
    ('P05', 'Record before gate and scene load', 'Trace open/write/flush/close/error handling and checked logical recording completion. Available recording errors must prevent original scene load and capture. Raw backend data must be in the new owned record before strict predicate evaluation. Do not treat FileAccess.flush as OS fsync or infer physical durability; later root byte readback is separate evidence.'),
    ('P06', 'Minimal adapter and complete scene', 'Diff against capture.gd SHA6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5. Changes are backend observation/recording, new identity/output routing, and exact Windows literal. Original complete main.tscn/root Window, Camera3D, CanvasLayer, Run/Pause/Continue disabled, 30 objects, 16 views, resolutions, geometry and rendering requirement stay unchanged.'),
    ('P07', 'Original journal and enum proof', 'Compare launcher with reviewed61c6de6b82a7c43ee2c8222703fd76fe0b829f6ec9dacfee760f0529a99c910b. Only authorized job/work/path/pin identity routing changes are allowed. Preserve F05 exact write count before fsync, core raw/partial/error persistence before optional diagnostics, original owned HDESK enumeration, DWORD TID/PID/class/window association and diagnostic unavailable-versus-conflict treatment.'),
    ('P08', 'No display occupation and birth binding', 'Preserve unique never-input WinSta0 desktop, no SwitchDesktop/foreground/root-desktop changes or active fallback, explicit lpDesktop at process birth, noninherited HDESK and STARTUPINFOEX stdio-only whitelist. Monitor remains on original desktop. Early creator thread termination is not itself a defect while the control owner retains HDESK.'),
    ('P09', 'Live owner, freshness, stop, and cleanup', 'Preserve original live hProcess checks, fresh completed sample within15s before admission, unchanged lost-prior-Engine rejection, 50ms sample boundaries, no cached row as per-frame proof, 55s stop, actual HANDLE waits, own-process termination bounds, unknown-outcome keeper, and both Godot/creator terminal before CloseDesktop. No normal-exit loss exemption or unconditional launcher exit that drops live ownership.'),
    ('P10', 'Root wrapper and one possible future attempt', 'Review only the exact new root-owned wrapper when pinned. Trace single exclusive invocation, one original process owner, wait terminal on receipt-write or wait interruption, no reopen/retry/replay/owner loss. One possible later Godot create still requires completed review, exact pins, fresh author validation and separate root execution authorization.'),
    ('P11', 'Evidence and acceptance boundaries', 'Static inference is not native pass. Preserve old0PNG, unrecorded old API tuple/exit/cross-stream causality, and source-inference labels. Do not claim per-frame native timestamp, continuous no-flash, image quality, real UI input, full H12, production readiness, or formal G01/G02 acceptance. H01-H15 and G03/R03/all29 not_run remain unchanged.'),
]
write('review-obligations.json', {'schema': 1, 'frozen_before_new_author_access': True, 'groups': [dict(id=i, title=t, obligation=o) for i,t,o in obligations], 'group_count': len(obligations), 'method': 'source/hash/AST/diff/dataflow only; no candidate imports or tests'})

oracles = [
    ('O01', 'Raw tuple Windows/vulkan/forward_plus; checked record precedes gate', 'Source path may continue to original scene. This is conditional source eligibility, never an executed/native success.'),
    ('O02', 'Raw display windows, WINDOWS, headless, empty, or other nonexact value', 'Keep exact raw value and mismatch; reject before scene/capture. No normalization or alias.'),
    ('O03', 'Driver or method differs from vulkan/forward_plus', 'Keep all sampled raw values and individual comparisons, then reject. No permitted backend expansion.'),
    ('O04', 'Getter result unavailable/error or second getter sampling introduced', 'No expected-filled raw value and no scene/capture after failure. Reject repeated sampling or a predicate using a different sample.'),
    ('O05', 'Backend record open/write/flush/close/available error check fails', 'No original scene load or PNG. Retain available failure/partial evidence; do not report completed recording merely because a write was attempted.'),
    ('O06', 'FileAccess.flush succeeds without OS fsync evidence', 'Only checked application-level recording may be claimed. Reject an OS-fsync/physical-durability claim; do not require an unapproved native fsync route.'),
    ('O07', 'Actual PID or declared job/run/source labels missing, replaced by expected identity, or wrong source clock implied', 'Record identity/clock obligation fails; no native/process provenance or cross-clock causal claim can be inferred.'),
    ('O08', 'Backend tuple fix accompanied by renderer/scene/rootWindow/UI/object/view/size/geometry changes', 'Scope/preservation obligation fails even if backend gate text is correct.'),
    ('O09', 'Launcher short journal write reaches fsync/durable return, core row deferred after diagnostics, or enum association widened', 'Reject regression against original F05/native association proof.'),
    ('O10', 'Late sample, lost Engine, normal teardown exception, live-owner exit, early CloseDesktop, retry or wrapper replay', 'Reject the corresponding gate/ownership/budget regression. Early creator termination alone remains permissible if retained HDESK and terminal-before-close obligations hold.'),
    ('O11', 'Frame time synthesized from mtime/cached first association or old actual tuple/exit/cause inferred from stdout', 'Reject the evidence claim; keep these facts unknown/unproven. A source-only review never upgrades old failures or formal acceptance.'),
]
write('written-oracles.json', {'schema': 1, 'kind': 'written static counterexample expectations, not executable controls', 'cases': [dict(id=i, condition=c, expected=e) for i,c,e in oracles], 'case_count': len(oracles), 'target_calls': 0, 'candidate_tests_executed': 0})
write('exposure-and-boundaries.json', {
    'schema': 1, 'blind_review': False,
    'prior_exposure': ['Reviewer authored sealed bfcc backend-name research and029d desktop-association design.', 'Reviewer saw old capture/launcher sources and failed native receipts under previous completed jobs.', 'Reviewer reviewed61c6 launcher and earlier original-scene API evidence in separate completed jobs.'],
    'current_phase_new_author_directory_read': False, 'current_phase_new_author_directory_listed': False,
    'prior_exposure_is_not_current_pass': True,
    'memory': 'memory supplied earlier G02 evidence-boundary reminders only; no current capability inferred; actual prior read MEMORY.md539-545, rollout01a13d8d-dc77-7760-92a2-392e499b5d0c; no rescan in this job',
    'old_results': '71958 two failures0PNG budget0; ff6736 one failure0PNG budget0; actual API tuple/Godot exit/cross-stream causality remain unknown',
    'target_operations': 0, 'product_index_cache_policy_writes': 0,
    'review_authority': 'Evidence only. Root owns design decisions, acceptance, next-stage author execution and possible one-create budget.',
})
write('phase1-state.json', {
    'schema': 1, 'job_id': 'child-018eab8f8562451ea3ca05a73ba80e23',
    'work_id': 'A-GAME3D-BACKEND-API-CAPTURE-REVIEW-20261024-v1',
    'canonical_agent_id': '/root/pc_direct_window_review', 'status': 'phase1_frozen_waiting_exact_candidate_and_wrapper_pins',
    'execution_allowed_validation_observed': True, 'native_complete_called': False,
    'new_author_read_or_listed': False, 'candidate_imports_or_tests': 0, 'target_native_or_engine_calls': 0,
    'metadata_preliminary_error': 'A read-only metadata command mistakenly included a Python str where Path was expected and stopped with AttributeError. Corrected read-only command succeeded; no target invocation or source mutation occurred.',
})

plan = '''# Backend API capture independent review: phase1 freeze

This is an exposed independent static review, not a blind review. The reviewer wrote the sealed backend-name research and saw earlier sources and failures. No new author directory has been read or listed before this freeze.

P01-P11 and O01-O11 freeze the review obligations and written counterexample expectations. The API tuple is exactly `Windows/vulkan/forward_plus`; the CLI tuple remains `windows/vulkan/forward_plus`. Recording precedes strict comparison and scene load. Recording errors prevent capture. FileAccess flush is not represented as OS fsync.

Only after root supplies exact candidate and new wrapper pins will the reviewer preserve read-only snapshots and inspect hashes, AST/diffs and control/data flow. No candidate import, candidate or old test, engine, target process, Win32/desktop/window/probe, UI, board or policy call is authorized by this review.

The launcher baseline is the sealed61c6de6 version with F05 full-count journaling and all native association, deadline, lost-Engine, keeper and terminal-close gates preserved. Complete original scene/root Window/UI/camera, disabled Run controls,30 objects,16 views, resolutions and geometry must remain unchanged.

Previous failed attempts remain failed,0PNG and budget0; old API tuple, Godot exit and cross-stream causality remain unknown. Frame-native timing and continuous no-flash are not inferred. H01-H15/full H12 remain open and unchanged; G03/R03/all29 remain not_run.

Phase1 ends with this immutable freeze. Keep the current lease active, await root exact pins without polling, and do not call native_complete yet. Root alone decides any later one-create bounded execution.
'''
(OUT / 'phase1-plan.md').write_text(plan, encoding='utf-8')
excluded = {'lease.private.json', 'phase1-frozen-manifest.json', 'phase1-freeze-verification.json'}
members = {}
for p in sorted(OUT.iterdir()):
    if p.is_file() and p.name not in excluded:
        b = p.read_bytes(); members[p.name] = {'bytes': len(b), 'sha256': digest(b)}
manifest = {'schema': 1, 'files': members, 'member_count': len(members), 'manifest_self_member': False, 'excluded': sorted(excluded), 'phase1_only': True}
write('phase1-frozen-manifest.json', manifest)
for name, entry in members.items():
    b = (OUT / name).read_bytes()
    assert len(b) == entry['bytes'] and digest(b) == entry['sha256']
mb = (OUT / 'phase1-frozen-manifest.json').read_bytes()
verification = {'schema': 1, 'member_count_verified': len(members), 'manifest_sha256': digest(mb), 'requirements_sha256': digest(canonical), 'new_author_read_or_listed': False, 'native_complete_called': False}
write('phase1-freeze-verification.json', verification)
print(json.dumps(verification))
