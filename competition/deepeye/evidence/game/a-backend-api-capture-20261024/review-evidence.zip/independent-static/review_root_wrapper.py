"""Static metadata review only. Does not import or run either wrapper."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
G = ROOT / '.planning/deepeye-resume-20261018/gen3-live-integration-20261024'
SNAP = OUT / 'root-wrapper-snapshot'
SNAP.mkdir(exist_ok=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(name, value):
    p=OUT/name
    assert p.parent==OUT and not p.exists(),name
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')

expected={
 'run_enum_association_capture_once.py':'adf26e5b62c5e246ae94ba993e23d04cd1f1b34ea4cb58424588bbe44d71f1c6',
 'run_backend_api_capture_once.py':'845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5',
 'backend-api-root-wrapper.diff':'5ad3bc35cafb2a8be0c720e80cfa59b151e139f8e7c879b03e79c207b52eeeec',
 'backend-api-root-wrapper-derivation.json':'2fbb26e43b817742e530c159054671063bcff22e102237280f7f6d50e8d620bf',
 'derive_backend_api_root_wrapper.py':'3d63c0a21803d3b4b945fc141351e3e73ba769a48c76677abc6b1e7176825be5',
}
sources={}
pins={}
for name,want in expected.items():
    b=(G/name).read_bytes()
    assert sha(b)==want,name
    sources[name]=b
    (SNAP/name).write_bytes(b)
    pins[name]={'bytes':len(b),'sha256':sha(b),'source':str((G/name).relative_to(ROOT)).replace('\\','/')}

old=sources['run_enum_association_capture_once.py'].decode('utf-8')
new=sources['run_backend_api_capture_once.py'].decode('utf-8')
pairs={
 'child-ff673689f0da408998a3a64ed82abd10':'child-9418116675a744ad9b39a7c4fe7f220a',
 'enum-association-capture-wrapper':'backend-api-capture-wrapper',
 'enum-association-capture-phase2-authorization.json':'backend-api-capture-phase2-authorization.json',
 'run_enum_association_capture_once.py':'run_backend_api_capture_once.py',
 'game3d-enum-association-capture-20261024':'game3d-backend-api-capture-20261024',
 'actual_launcher_Python_exit':'original_Popen_executable_exit',
 'launcher_pid':'Popen_executable_pid',
 'launcher_exit':'Popen_executable_exit',
}
derived=old
counts={}
for before,after in pairs.items():
    counts[before]=derived.count(before)
    assert counts[before]==1,(before,counts[before])
    derived=derived.replace(before,after)
assert derived==new,'Additional source delta beyond eight declared literal replacements'
diff=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='run_enum_association_capture_once.py',tofile='run_backend_api_capture_once.py'))
assert diff.encode('utf-8')==sources['backend-api-root-wrapper.diff']
old_tree=ast.parse(old)
new_tree=ast.parse(new)
reverse={v:k for k,v in pairs.items()}
class Normalize(ast.NodeTransformer):
    def visit_Constant(self,node):
        if isinstance(node.value,str):
            for after,before in reverse.items():
                node.value=node.value.replace(after,before)
        return node
normalized=Normalize().visit(ast.parse(new))
assert ast.dump(old_tree,include_attributes=False)==ast.dump(normalized,include_attributes=False)
def call_name(node):
    if isinstance(node,ast.Name):return node.id
    if isinstance(node,ast.Attribute):return call_name(node.value)+'.'+node.attr
    return '<expression>'
calls=[{'line':n.lineno,'call':call_name(n.func)} for n in ast.walk(new_tree) if isinstance(n,ast.Call)]
popen=[n for n in ast.walk(new_tree) if isinstance(n,ast.Call) and call_name(n.func)=='subprocess.Popen']
waits=[n for n in ast.walk(new_tree) if isinstance(n,ast.Call) and call_name(n.func)=='child.wait']
assert len(popen)==len(waits)==1
assert not waits[0].args and not waits[0].keywords
assert {k.arg:ast.literal_eval(k.value) for k in popen[0].keywords if k.arg=='creationflags'}=={'creationflags':0x08000000}
assert not any(x['call'] in {'child.kill','child.terminate','subprocess.run','subprocess.call','subprocess.check_call','subprocess.check_output'} for x in calls)
derivation=json.loads(sources['backend-api-root-wrapper-derivation.json'])
assert derivation['base_sha256']==expected['run_enum_association_capture_once.py']
assert derivation['new_sha256']==expected['run_backend_api_capture_once.py']
dump('root-wrapper-static-result.json',{
 'schema':1,'status':'no_static_blocker_within_P10_wrapper_scope; candidate review pending',
 'pins':pins,'eight_literal_replacement_counts':counts,'independent_diff_equals_supplied':True,
 'normalized_AST_equal_after_declared_literals':True,'function_names':[n.name for n in new_tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))],
 'Popen_call_sites':len(popen),'Popen_line':popen[0].lineno,'creationflags':0x08000000,
 'original_child_wait_call_sites':len(waits),'wait_line':waits[0].lineno,'wait_timeout_parameter':False,
 'owner_dataflow':[
  'Authorization and hash/path checks precede exclusive started record and stdout/stderr creation.',
  'One Popen assignment retains child in main local scope; child receipt is guarded by except BaseException.',
  'Receipt failure appends a diagnostic then continues to same child.wait().',
  'Interrupted/error wait is caught and repeats wait on that same original object, never reopens or respawns.',
  'Exit receipt is after successful wait return. Its own persistence failure occurs after child terminal.',
  'Exit code/PID explicitly describe original Popen executable, not Godot; candidate HANDLE evidence is separate.'
 ],
 'replay_fences':'Exclusive x/xb started/stdout/stderr names and absence of attempt directory before Popen; no replay/fallback launch path',
 'authorization_limits':'Root-owned configuration is a future input and not a lease validator. Static booleans in it are declared authorization only; root must still separately freshvalidate and authorize exact author execution.',
 'reviewer_candidate_imports_tests':0,'reviewer_wrapper_imports_or_execution':0,'target_native_engine_process_calls':0,
 'new_author_directory_read_or_listed':False,'product_index_cache_policy_writes':0,
 'root_prior_fake_controls_reexecuted':False,'review_job_active':True,'native_complete_called':False,
})
report='''# Root wrapper static review checkpoint

The pinned new wrapper845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5 has no static blocker within the frozen P10 scope. The author candidate remains unread and this lease remains active.

The reviewer independently hashed both exact wrapper bytes, regenerated the textual diff in memory, and compared normalized ASTs without importing or executing either file. The entire delta consists of eight single-occurrence string replacements: author job, output prefix, authorization filename, self-pin filename, author directory whitelist, and three accurate Popen executable exit/PID labels. Two function bodies preserve their control flow after those approved literals are normalized.

Lines19-36 check declared authorization, pinned paths/hashes, absent attempt output, candidate path and interpreter before launch. Lines38-43 create an exclusive started record and exclusive stdout/stderr then contain exactly one Popen call with CREATE_NO_WINDOW. Lines45-56 keep that same child object through child-receipt persistence errors and wait interruptions. The only child.wait call has no timeout. Repeating wait retains the original owner and does not repeat process creation. Lines57-63 are reachable after wait returns terminal; the saved executable code is expressly separate from Godot HANDLE evidence.

No new timeout/kill/terminate/reopen/replay path was introduced. The future root-owned configuration was not executed or treated as self-authenticating live validation; root still owns separate fresh author validation and runtime authorization. The existing consumed wrapper and its markers were not modified.

This is source/AST/dataflow evidence only. Zero wrapper/candidate imports or tests and zero target process, engine, Win32, desktop, window or probe calls occurred. No new author directory was read or listed. P01-P09/P11 candidate-dependent conclusions remain pending exact candidate pins. Old failed attempts, unknowns and budgets remain unchanged; H01-H15/full H12 stay open, G03/R03/all29 not_run.
'''
(OUT/'root-wrapper-static-report.md').write_text(report,encoding='utf-8')
members={}
names=['review_root_wrapper.py','root-wrapper-fresh-validate-response.json','root-wrapper-static-result.json','root-wrapper-static-report.md']
names+=['root-wrapper-snapshot/'+n for n in expected]
for name in names:
    b=(OUT/name).read_bytes();members[name]={'bytes':len(b),'sha256':sha(b)}
dump('root-wrapper-review-manifest.json',{'schema':1,'files':members,'member_count':len(members),'manifest_self_member':False,'phase1_manifest_sha256':'85b7402fe3e47d45dbcf7a61ccec19fee005e0561d6007e6e75941b693ea4b7a','phase1_addendum_manifest_sha256':'b2893778a37c5722da11a90ac45b0b5b1b66c46d45c5605f5965f02e356b613c'})
for name,pin in members.items():
    b=(OUT/name).read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256']
print(json.dumps({'status':'static wrapper checkpoint; no blocker','members':len(members),'manifest_sha256':sha((OUT/'root-wrapper-review-manifest.json').read_bytes()),'new_author_read_or_listed':False,'native_complete_called':False}))
