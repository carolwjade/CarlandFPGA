"""Separate read-only official source GET; does not run candidate/engine APIs."""
import base64,hashlib,json,urllib.request
from pathlib import Path
OUT=Path(__file__).resolve().parent
COMMIT='ed1daf0bf001b61586d9930840f2f1394092c079'
items=[('drivers/windows/file_access_windows.cpp',[(50,64),(223,230),(291,299),(315,377)]),('doc/classes/FileAccess.xml',None),('doc/classes/Time.xml',[(107,120)])]
pins=[]
for path,ranges in items:
 url='https://api.github.com/repos/godotengine/godot/contents/'+path+'?ref='+COMMIT
 req=urllib.request.Request(url,headers={'Accept':'application/vnd.github+json','Accept-Encoding':'identity','User-Agent':'DeepEye-source-only-review'})
 with urllib.request.urlopen(req,timeout=30) as response:
  status=response.status;advertised=response.headers.get('Content-Length');chunks=[]
  while True:
   chunk=response.read(8192)
   if not chunk:break
   chunks.append(chunk)
  body=b''.join(chunks)
 data=json.loads(body)
 raw=base64.b64decode(data['content'])
 blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 assert blob==data['sha']
 lines=raw.decode('utf-8').splitlines()
 if ranges is None:
  ranges=[]
  for i,line in enumerate(lines):
   if any('name="'+name+'"' in line for name in ['store_buffer','flush','close','get_error','get_position','get_buffer','get_length']):
    end=next(j for j in range(i,len(lines)) if '</method>' in lines[j])
    ranges.append((i+1,end+1))
 name=path.replace('/','__')+'.focused.txt'
 p=OUT/name;assert not p.exists()
 text=''
 for first,last in ranges:
  text+='--- L%d-L%d ---\n'%(first,last)
  text+='\n'.join('%d: %s'%(n,lines[n-1]) for n in range(first,last+1))+'\n'
 p.write_text(text,encoding='utf-8')
 pins.append({'path':path,'commit':COMMIT,'api_url':url,'html_url':data['html_url'],'blob_sha1':blob,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'HTTP_status':status,'HTTP_body_bytes':len(body),'HTTP_content_length_header':advertised,'excerpt':name,'excerpt_lines':ranges,'full_source_not_archived':True})
p=OUT/'fileaccess-primary-pins.json';assert not p.exists()
p.write_text(json.dumps({'schema':1,'method':'official GitHub contents GET in chunks, decoded bytes verified against official git blob; small excerpts saved','failed_initial_fetch_retained':'primary-fetch-attempt1-failure.json','sources':pins},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(pins))
