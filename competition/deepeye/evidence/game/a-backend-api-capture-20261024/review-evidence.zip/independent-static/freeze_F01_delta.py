import hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,value):
 p=OUT/name;assert not p.exists(),name
 p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
src=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024/backend-api-F01-root-source-decision.json'
raw=src.read_bytes()
assert sha(raw)=='ab994b7396f758d624949ab2886cd6b5c2d63e1ff83d46b19ba5b4944b82155b'
(OUT/'F01-root-source-decision.snapshot.json').write_bytes(raw)
write('F01-v1-static-counterexample.json',{
 'schema':1,'finding':'F01','status':'source-level blocker retained; no candidate/fault execution',
 'original_author_manifest_sha256':'51b9fbb301326c7b9c96aea9a3469f3f03da1de766c03c025ea7fd115ad156ed',
 'capture_sha256':'8e1410c2b41d0ace0bbb499457e02c38d0c83b3faeb9daef90949f8397f68e6a',
 'candidate_lines':{'writer_store_checks':[58,68],'cached_flush_error_then_return':[69,75],'gate_and_scene_load':[116,122]},
 'primary':{'commit':'ed1daf0bf001b61586d9930840f2f1394092c079','path':'drivers/windows/file_access_windows.cpp','blob_sha1':'6f9f466abd4062c6b37e7a2c29332398aa66afbe','sha256':'edf1a55501f5b55e6e7ccc2e07e271f3016c557e973fb182c2a40cbb7f9f7139','get_error_lines':[333,335],'flush_lines':[354,361],'close_lines':[224,230]},
 'written_counterexample':[
  'Conditional buffered IO state: store_buffer accepts all logical bytes, check_errors caches OK, and get_position equals payload length.',
  'Later fflush fails while draining buffered bytes. This implementation ignores fflush return and never refreshes last_error.',
  'get_error returns stale OK; flush_error captures OK. fclose may also fail and its result is discarded.',
  'The helper returns true although the record can be incomplete in filesystem-visible bytes. The admission gate then permits load when raw backend matches.'
 ],
 'observed_runtime_failure':False,'claim_limits':'This is a source-level conditional counterexample, not executed fault injection and not an old-run root cause. It requires no fsync requirement.',
 'disposition':'Keep original35 immutable; wait for explicit new delta pins; current lease not complete',
})
obligations=[
 ('D01','Retain original source and finding','Original35 manifest/current/frozen bytes, original reviewer9+3 freeze and F01 remain unchanged. New v2 files/pins/diffs must be separate. Verify exact root decision and new candidate pins only after root unlock.'),
 ('D02','Writer checks retained without false flush certification','Keep original open/store boolean/error/UTF-8 position and flush/close calls. Cached post-flush get_error is labelled only as cached API state. Actual fflush/fclose results, fsync and crash durability remain unknown.'),
 ('D03','New read object and exact same path','After writer close returned, reopen identical owned backend-observation.json path with a distinct FileAccess.READ object. Successful open and open_error==OK are required. Non-null objects on error paths still close. No truncation/rewrite/fallback/retry.'),
 ('D04','Exact length and initial cursor','Use the exact serialized payload PackedByteArray as oracle. Require fresh reader length equals payload.size and cursor equals zero before get_buffer; this also guards get_length seek/restore side effects. A failed condition closes reader and returns false.'),
 ('D05','Exact read outcome','Request precisely payload.size bytes once. Capture read error immediately after get_buffer; require returned size and every byte equal payload, error OK and end cursor exactly payload.size. No accepting EOF, short reads, correct-prefix-only or expected-value reconstruction. Every reachable reader path closes.'),
 ('D06','Order and claim boundary','Only after successful same-process filesystem-visible byte readback may helper return true to the strict backend gate and original scene load. Do not label it independent root readback, successful fflush/fclose, OS fsync or physical durability. Later filesystem mutation is outside the sampled fact, not silently denied.'),
 ('D07','Unrelated gates and full scene','Getters remain once/raw/no normalization; final report remains pre-predicate snapshot. API Windows/vulkan/forward_plus, CLI windows/vulkan/forward_plus, exact52 sources, original complete scene suffix and original native journal/enum/HDESK/HANDLE/fresh15/loss/55/keeper/terminal controls and rootwrapper845 remain unchanged except disclosed v2 plan/path/pin routing.'),
]
oracles=[
 ('D-O01','Reader open null or non-OK error','Fail before gate/scene; close any non-null new reader.'),
 ('D-O02','Wrong length, including correct payload with extra trailing byte','Fail and close; no prefix-only admission.'),
 ('D-O03','Length correct but initial position nonzero, including failed seek restoration','Fail and close before get_buffer.'),
 ('D-O04','Full byte count but one changed byte, empty/short result, non-OK read error, or wrong final cursor','Fail and close; no gate/scene.'),
 ('D-O05','Full identical bytes, exact length, initial0/endN, successful read state','Conditionally allow helper success as same-process filesystem-visible byte observation only; not runtime success or durability.'),
 ('D-O06','Flush error cached OK but readback missing/mismatching/fails','Reject despite cached OK, retaining original partial bytes and F01 evidence.'),
 ('D-O07','Only cached error or flush-returned used as success; reader reused writer; get_file_as_bytes hides untested state; independent/fsync claim','Reject the corresponding source/provenance claim.'),
 ('D-O08','New v2 changes native gates/full scene or repeats getter/actual native invocation','Reject scope and preserve evidence; do not repair product or old failed outcomes.'),
]
write('F01-delta-obligations.json',{'schema':1,'frozen_before_future_v2_access':True,'groups':[dict(id=i,title=t,obligation=o) for i,t,o in obligations],'written_oracles':[dict(id=i,condition=c,expected=e) for i,c,e in oracles],'candidate_tests_or_target_calls':0,'future_v2_read':False,'native_complete_called':False})
plan='''# F01 readback delta review freeze

The exact Windows implementation does not propagate fflush/fclose failure into cached get_error. Original v1 is blocked under P05/O05; its35 members and source-only counterexample stay preserved.

D01-D07 and D-O01-D-O08 are frozen before any future v2 access. A distinct READ object opened after writer close, exact file length, initial cursor0, one precise get_buffer result with exact size/bytes/error/end cursor and close on each path can establish that the complete serialized payload was filesystem-visible to this process before scene load. The chosen strict read checks fail closed if any relevant observation is missing or mismatched.

This is a bounded source-logic assessment. It does not demonstrate that the lower-level fflush/fclose returned success, the physical media is durable, another process independently read the bytes, or the path cannot change later. No fsync requirement, new native API or fallback is added. Root still independently inspects later actual bytes. There is no current GDScript parse/execution or IO experiment.

Only root-unlocked exact new pins may be read next. Current source/candidate/native operations remain zero and the review lease stays active, without completion or polling.
'''
(OUT/'F01-delta-plan.md').write_text(plan,encoding='utf-8')
names=['freeze_F01_delta.py','F01-root-source-decision.snapshot.json','F01-v1-static-counterexample.json','F01-delta-obligations.json','F01-delta-plan.md','pin_fileaccess_primary.py','primary-fetch-attempt1-failure.json','pin_fileaccess_primary_followup.py','fileaccess-primary-pins.json','drivers__windows__file_access_windows.cpp.focused.txt','doc__classes__FileAccess.xml.focused.txt','doc__classes__Time.xml.focused.txt']
files={}
for name in names:
 b=(OUT/name).read_bytes();files[name]={'bytes':len(b),'sha256':sha(b)}
write('F01-delta-frozen-manifest.json',{'schema':1,'files':files,'member_count':len(files),'manifest_self_member':False,'original_v1_author_manifest_sha256':'51b9fbb301326c7b9c96aea9a3469f3f03da1de766c03c025ea7fd115ad156ed'})
for name,pin in files.items():
 b=(OUT/name).read_bytes();assert sha(b)==pin['sha256'] and len(b)==pin['bytes']
print(json.dumps({'members':len(files),'delta_manifest_sha256':sha((OUT/'F01-delta-frozen-manifest.json').read_bytes()),'future_v2_read':False,'native_complete_called':False}))
