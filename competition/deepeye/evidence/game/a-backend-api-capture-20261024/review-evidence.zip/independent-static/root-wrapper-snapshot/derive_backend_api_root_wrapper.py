"""Derive a fresh wrapper identity; never mutate/reuse the consumed old wrapper."""
from pathlib import Path
import ast, difflib, hashlib, json

P = Path(__file__).resolve().parent
old = P / 'run_enum_association_capture_once.py'
new = P / 'run_backend_api_capture_once.py'
raw = old.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'adf26e5b62c5e246ae94ba993e23d04cd1f1b34ea4cb58424588bbe44d71f1c6'
source = raw.decode()
replacements = {
    'child-ff673689f0da408998a3a64ed82abd10': 'child-9418116675a744ad9b39a7c4fe7f220a',
    'enum-association-capture-wrapper': 'backend-api-capture-wrapper',
    'enum-association-capture-phase2-authorization.json': 'backend-api-capture-phase2-authorization.json',
    'run_enum_association_capture_once.py': 'run_backend_api_capture_once.py',
    'game3d-enum-association-capture-20261024': 'game3d-backend-api-capture-20261024',
    'actual_launcher_Python_exit': 'original_Popen_executable_exit',
    '"launcher_pid"': '"Popen_executable_pid"',
    "'launcher_pid'": "'Popen_executable_pid'",
    "'launcher_exit'": "'Popen_executable_exit'",
}
counts = {}
for before, after in replacements.items():
    counts[before] = source.count(before)
    if before == '"launcher_pid"':
        assert counts[before] == 0
        continue
    assert counts[before] > 0, before
    source = source.replace(before, after)
ast.parse(source)
with new.open('x', encoding='utf-8', newline='\n') as f:
    f.write(source)
delta = ''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True), source.splitlines(keepends=True),
                                     fromfile=old.name, tofile=new.name))
with (P / 'backend-api-root-wrapper.diff').open('x', encoding='utf-8', newline='\n') as f:
    f.write(delta)
result = {'base_sha256': hashlib.sha256(raw).hexdigest(),
    'new_sha256': hashlib.sha256(new.read_bytes()).hexdigest(),
    'replacement_counts': counts, 'changes': 'job/path/authorization/output identities and accurate Popen exit labels only',
    'Popen_count_wait_owner_timeout_kill_logic_changed': False,
    'source_only_parse': 'pass', 'wrapper_or_candidate_execution': 0, 'phase2_authorized': False,
    'old_wrapper_and_started_receipts_preserved': True}
with (P / 'backend-api-root-wrapper-derivation.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
