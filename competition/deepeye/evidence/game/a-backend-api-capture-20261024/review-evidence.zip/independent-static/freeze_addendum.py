import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
def sha(b): return hashlib.sha256(b).hexdigest()
def write(name, d):
    p=OUT/name
    assert p.parent==OUT and not p.exists(), name
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')

old=(OUT/'phase1-frozen-manifest.json').read_bytes()
assert sha(old)=='85b7402fe3e47d45dbcf7a61ccec19fee005e0561d6007e6e75941b693ea4b7a'
for n,pin in json.loads(old)['files'].items():
    b=(OUT/n).read_bytes(); assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],n
source=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024/backend-api-capture-root-design-addendum.json'
b=source.read_bytes(); addendum=json.loads(b)
assert addendum['review_job']=='child-018eab8f8562451ea3ca05a73ba80e23'
assert addendum['strict_API_tuple']==['Windows','vulkan','forward_plus']
copy=OUT/'root-design-addendum.snapshot.json'
assert not copy.exists()
copy.write_bytes(b)
write('phase1-addendum-delta.json',{
 'schema':1,'kind':'explicit parent-authorized scope/oracle delta after original phase1 freeze',
 'original_manifest_sha256':sha(old),'original_member_count':9,'original_freeze_retained_unmodified':True,
 'source_path':str(source.relative_to(ROOT)).replace('\\','/'),'source_sha256':sha(b),'source_bytes':len(b),
 'new_author_directory_read_or_listed':False,'candidate_imports_tests_or_target_calls':0,
 'narrow_exceptions':[
  {'affected_group':'P07','change':'New launcher validate_capture_outputs expected API display literal windows -> Windows only. Original P07 identity/path/pin-only rule is qualified by this explicit semantic exception. Observed report values must not be normalized; driver and method remain exact vulkan/forward_plus.'},
  {'affected_groups':['P03','P04','P06','P11'],'change':'Final adapter report reuses the exact three pre-predicate raw strings instead of rereading getters; report explicitly identifies the backend observation as that snapshot, references backend-observation.json and its declared clock. This is not a fresh-final or per-frame observation.'}],
 'additional_written_oracles':[
  {'id':'O12','condition':'Report raw display Windows; parent saved-output validator expects lowercase windows or rewrites actual display to lowercase','expected':'Reject validator oracle mismatch/normalization. The newly authorized validator expects exact Windows without changing actual value.'},
  {'id':'O13','condition':'Final report backend fields are copied from saved pre-predicate tuple and labelled/referenced as snapshot','expected':'Accept source provenance method conditionally; do not count it as a second native observation or per-frame/final backend check.'},
  {'id':'O14','condition':'Final report calls any getter again, claims fresh-final values, or aliases CLI/API spellings','expected':'Reject once-only/provenance/exact-name obligation.'}],
 'still_unchanged':'Original geometry/scene/rootWindow/UI/Run/resolution/16views and all native F05/HDESK/HANDLE/deadline/loss/keeper/stop/terminal controls; strict CLI windows/vulkan/forward_plus; old failures/budgets0; H01-H15/fullH12 open; G03/R03/all29 not_run',
 'phase2_authorized':False,'native_complete_called':False,
})
members={}
for n in ['freeze_addendum.py','root-design-addendum.snapshot.json','phase1-addendum-delta.json']:
    raw=(OUT/n).read_bytes(); members[n]={'bytes':len(raw),'sha256':sha(raw)}
write('phase1-addendum-manifest.json',{'schema':1,'files':members,'member_count':len(members),'manifest_self_member':False,'original_phase1_manifest_sha256':sha(old)})
mb=(OUT/'phase1-addendum-manifest.json').read_bytes()
for n,pin in members.items():
    raw=(OUT/n).read_bytes(); assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
print(json.dumps({'original_manifest_verified_members':9,'addendum_members':len(members),'addendum_source_sha256':sha(b),'addendum_manifest_sha256':sha(mb),'new_author_read_or_listed':False,'native_complete_called':False}))
