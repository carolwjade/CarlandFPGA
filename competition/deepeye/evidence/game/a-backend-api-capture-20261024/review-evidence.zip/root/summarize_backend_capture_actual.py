"""Read only the new run: root byte/pixel readback, never a native replay."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json
from PIL import Image

P = Path(__file__).resolve().parent
A = P.parent / 'game3d-backend-api-capture-20261024'
T = A / 'attempt-01'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipt = read(T / 'receipt.json')
report = read(T / 'frames/capture-report.json')
observation_path = T / 'frames/backend-observation.json'
observation = read(observation_path)
events = [json.loads(line) for line in (T / 'events.jsonl').read_text(encoding='utf-8').splitlines()]
stdout = (T / 'engine.stdout.bin').read_text(encoding='utf-8')
io_rows = [json.loads(line[len('PRIVATE_BACKEND_RECORD_IO '):]) for line in stdout.splitlines()
           if line.startswith('PRIVATE_BACKEND_RECORD_IO ')]
assert len(io_rows) == 1
io = io_rows[0]
assert receipt['failure'] == "CaptureBlocked('successful enumeration lost prior owned Engine association')"
assert receipt['child_terminal'] and receipt['creator_terminal'] and receipt['owned_handles_closed']
assert receipt['pid'] == observation['godot_pid'] == report['pid'] == 33496
assert observation['raw'] == observation['expected'] == {
    'display_driver': 'Windows', 'rendering_driver': 'vulkan', 'rendering_method': 'forward_plus'}
assert all(observation['matches'].values())
assert observation_path.stat().st_size == io['payload_bytes'] == io['read_bytes'] == 1553
assert io['same_process_filesystem_visible_readback'] and io['read_bytes_equal']
assert io['read_open_error'] == io['read_error'] == 0
assert io['read_start_position'] == 0 and io['read_end_position'] == 1553
assert io['flush_actual_result'] is None and io['independent_root_readback'] is None
assert report['scene'] == 'res://viewer/main.tscn' and report['root_window'] and not report['subviewport']
assert report['status'] == 'frames_written_await_root_visual_review' and report['stopped']
assert report['presentation'] == {'diagnostics': [], 'factory_calls': {'drill': 1, 'frame': 1, 'obstacle': 30}, 'state': 'ready'}
expected = {f'{w}x{h}-{v}.png': [w, h] for w, h in [(1920, 1080), (2560, 1440)]
            for v in ['top', 'bottom', 'front', 'back', 'left', 'right', 'iso', 'drill']}
assert {row['path'] for row in report['frames']} == set(expected)
assert {p.name for p in (T / 'frames').glob('*.png')} == set(expected)
images = []
for row in report['frames']:
    path = T / 'frames' / row['path']
    with Image.open(path) as image:
        image.load()
        pixel_hash = hashlib.sha256(image.tobytes()).hexdigest()
        assert list(image.size) == expected[row['path']] == row['image_size'] == row['requested_size']
        assert image.mode == 'RGB' and pixel_hash == row['pixel_sha256']
        images.append({'path': row['path'], 'bytes': path.stat().st_size, 'sha256': sha(path),
                       'mode': image.mode, 'size': list(image.size), 'pixel_sha256': pixel_hash,
                       'producer_pixel_hash_match': True})
assert len(images) == 16
cores = [row for row in events if row['event'] == 'enum_association_core']
samples = [row for row in events if row['event'] == 'native_association_sample']
admitted = [row for row in samples if row.get('admitted') is True]
result = {
    'utc': datetime.now(timezone.utc).isoformat(), 'job_id': 'child-9418116675a744ad9b39a7c4fe7f220a',
    'composite_outcome': 'failed; original native Engine-loss gate retained',
    'actual_Godot_creates': 1, 'remaining_budget': 0, 'replay': False,
    'original_Popen_executable': read(P / 'backend-api-capture-wrapper-exit.json'),
    'reported_native_core_owner_pid': cores[-1]['owner_pid'],
    'core_owner_terminal_independently_queried': False,
    'Godot_pid_tid': [receipt['pid'], receipt['tid']], 'Godot_exit_code': None,
    'receipt_original_child_creator_terminal_and_handles_closed': True, 'live_keeper_or_exec_session': False,
    'backend_root_independent_after_terminal_byte_readback': {
        'path': str(observation_path), 'bytes': observation_path.stat().st_size, 'sha256': sha(observation_path),
        'raw': observation['raw'], 'matches': observation['matches'], 'godot_pid_matches_receipt': True,
        'scope': 'Root read the complete emitted file after terminal; no independent pre-load write, fsync, physical media or future immutability claim'},
    'actual_child_IO_record': io,
    'external_v2_binding': {'launcher_sha256': sha(A / 'launcher_v2.py'),
        'adapter_sha256': sha(A / 'capture_v2.gd'), 'source_pins_sha256': sha(A / 'source-pins-v2.json'),
        'plan_sha256': sha(A / 'execution-plan-v2.json'),
        'executed_adapter': events[0]['argv'][events[0]['argv'].index('--script') + 1]},
    'retained_raw_metadata_limit': 'source_pins.json/adapter_variant v1 are declared legacy metadata, not v2 self-binding',
    'backend_clock': observation['process_clock'], 'frame_native_timestamps': None,
    'event_counts': dict(Counter(row['event'] for row in events)), 'core_count': len(cores),
    'admitted_samples': len(admitted), 'admitted_sequences': [row['sequence'] for row in admitted],
    'last_core': cores[-1], 'sampled_input_desktops': sorted(set(receipt['input_desktop_observations'])),
    'continuous_no_flash_per_frame_or_atomic_proof': False,
    'stderr_bytes': (T / 'engine.stderr.bin').stat().st_size,
    'full_original_scene_report': {'scene': report['scene'], 'stopped': report['stopped'],
        'obstacles': report['obstacle_count'], 'presentation': report['presentation'],
        'image_count': len(images), 'all16_RGB_decoded_pixel_hashes_match': True,
        'reported_logical_shell_sizes': sorted(set(row['shell_size'] for row in report['frames'])),
        'reported_logical_viewport_rects': sorted(set(row['viewport_rect'] for row in report['frames'])),
        'limit': '2560x1440 PNG/window values coexist with 1920x1080 logical shell/viewport; no new logical-DPI/layout proof'},
    'images': images,
    'root_decoder_dependency_note': {'initial_project_venv': "ModuleNotFoundError: No module named 'PIL'",
        'initial_tool_chunk_id': '8348cd', 'resolution': 'Used existing bundled Python/Pillow; no installation or environment change'},
    'visual_review': 'All16 original images inspected with view_image; separate root visual findings apply, not formal acceptance',
    'physical_board_calls': 0, 'H01_H15_full_H12': 'preserved/open',
    'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run',
}
with (P / 'backend-capture-root-actual-readback.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({'outcome': result['composite_outcome'], 'backend': observation['raw'],
                  'PNG_decoded_verified': len(images), 'core_count': len(cores),
                  'admitted_samples': len(admitted), 'remaining_budget': 0}))
