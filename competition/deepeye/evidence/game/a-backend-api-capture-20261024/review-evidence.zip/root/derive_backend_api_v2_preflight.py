"""Keep original root preflight immutable; derive a separate v2 byte audit."""
from pathlib import Path
import ast, hashlib, json

P = Path(__file__).resolve().parent
original = (P / 'preflight_backend_api_capture.py').read_bytes()
text = original.decode('utf-8')
replacements = {
    "'launcher.py': '0551ecbcdbeb0358ab565c5d60ad17661cde6c31b11e335c5339af82982e931c'": "'launcher_v2.py': '566300f09b060673201c1d230082401cc6dcc3ce9aec0f2464f9f95bdf28e2ac'",
    "'capture.gd': '8e1410c2b41d0ace0bbb499457e02c38d0c83b3faeb9daef90949f8397f68e6a'": "'capture_v2.gd': '1db06193cf6191dd348eea89ecf1714a7622eb6871908a34436b173a567b6656'",
    "'source-pins.json': '87bbf22eb2542a004ab0370f97e0ebc325dceb4a0e04e691a8b937fa25773124'": "'source-pins-v2.json': 'cf5a7b970bedf857413c0db445f1d4ea3daf60e8c90425ace28d3a42e33feb72'",
    "'execution-plan.json': '4e5f13a3bafd6cf037e1878e7f536bf2f40a0c6b29a43619f4b0920be5406744'": "'execution-plan-v2.json': '9aede7afc30554baaa847deb5139671d5dd3a14134d3919c3f9a1877170968de'",
    "'argv.json': '905872c7f7a4b4fc9caaf50a8d9e60483921755ecc0e473db82e1017037885bb'": "'argv-v2.json': '6707fa4b588006403cb46ec68fe6f94510d09b53ea58c3610823d3c7f7a669bd'",
    "plan, argv = read(A / 'execution-plan.json'), read(A / 'argv.json')": "plan, argv = read(A / 'execution-plan-v2.json'), read(A / 'argv-v2.json')",
    "pins['execution-plan.json']": "pins['execution-plan-v2.json']",
    "ast.parse((A / 'launcher.py').read_bytes(), filename=str(A / 'launcher.py'))": "ast.parse((A / 'launcher_v2.py').read_bytes(), filename=str(A / 'launcher_v2.py'))",
    "'frozen_and_active_member_checks': 70": "'frozen_and_active_member_checks': 138",
    "'backend-api-capture-root-preflight.json'": "'backend-api-capture-v2-root-preflight.json'",
}
for old, new in replacements.items():
    assert text.count(old) == 1, old
    text = text.replace(old, new)
anchor = "baseline = read(A / 'source-baseline.json')"
assert text.count(anchor) == 1
delta = """assert sha(A / 'v2-manifest.json') == '7e1de6096c9ffc64d1c77b84c6cf2bf3e78f064064cb51e62c452432518dd006'
delta_manifest = read(A / 'v2-manifest.json')
assert delta_manifest['count'] == len(delta_manifest['members']) == 34
for row in delta_manifest['members']:
    for field in ['path', 'frozen_path']:
        path = (A / row[field]).resolve()
        assert path.is_relative_to(A.resolve())
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row[field]
"""
text = text.replace(anchor, delta + '\n' + anchor)
ast.parse(text)
target = P / 'preflight_backend_api_capture_v2.py'
with target.open('xb') as f:
    f.write(text.encode('utf-8'))
record = {'source': 'preflight_backend_api_capture.py', 'source_sha256': hashlib.sha256(original).hexdigest(),
          'target': target.name, 'target_sha256': hashlib.sha256(text.encode()).hexdigest(),
          'literal_replacements': len(replacements), 'added': '34-member v2 active/frozen byte audit',
          'candidate_import_tests_engine_native_calls': 0, 'source_preflight_executed_again': False}
with (P / 'backend-v2-root-preflight-derivation.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps(record))
