"""Root verifies the sealed failed run and builds one evidence-only package."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile

P = Path(__file__).resolve().parent
O, R = P.parent, P.parents[2]
A = O / 'game3d-backend-api-capture-20261024'
V = O / 'game3d-backend-api-capture-review-20261024'
D = P / 'config2-independent-review'
W = R / '.local/deepeye-implementation-a'
read = lambda p: json.loads(p.read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()

def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

def verify(path, pin):
    raw = path.read_bytes()
    assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256'], str(path)
    return raw

terminal = json.loads(read(P / 'backend-capture-author-terminal-readback.json')['result']['content'][0]['text'])[0]
assert terminal['job_id'] == 'child-9418116675a744ad9b39a7c4fe7f220a'
assert terminal['status'] == 'completed' and terminal['terminal'] and terminal['stale'] is False
assert sha((A / 'final-manifest.json').read_bytes()) == '8780144fcde76fa84cd6625b8c2aa5b3e8b036b8a5697521fb71bffe6815e811'
am = read(A / 'final-manifest.json')
assert len(am['members']) == 115
for row in am['members']:
    for key in ['path', 'frozen_path']:
        path = (A / row[key]).resolve()
        assert path.is_relative_to(A.resolve())
        verify(path, row)
assert sha((A / 'archive-include.json').read_bytes()) == 'c2a646be94664b3dd76e638a9392099a7bd6868a6cfaf9f4a5382e3b638d6f92'
include = read(A / 'archive-include.json')['payload_members']
assert len(include) == len(set(include)) == 115
assert set(include) == {row['path'] for row in am['members']}
assert sha((V / 'artifact-manifest.json').read_bytes()) == '5c7418726694ce1139dcadd8e5a79f2a6dd9d7451a3ce4e8ddd84ec0f068315a'
vm = read(V / 'artifact-manifest.json')
assert len(vm['files']) == vm['member_count'] == 129
for name, row in vm['files'].items():
    verify(V / name, row)
for name, expected in {
    'result.json': 'dfd1eff38a2676e76fcc283cae6db89a88dd144e5b9672283361626720242d57',
    'short-report.md': '2a05b366ab6d71d2f62a240da0583a4e9fff9bdaf7b6ca77ca8303ce4f074983',
    'manifest.json': '6fbb6afb0929c18454ab119c8aee3ece68facd742336493e884b1c5d3ef75769',
}.items():
    assert sha((D / name).read_bytes()) == expected, name
baseline = read(A / 'source-baseline.json')
assert sha(Path(baseline['git_index']['path']).read_bytes()) == baseline['git_index']['sha256']
for name, expected in baseline['C4'].items():
    assert sha((W / name).read_bytes()) == expected, name
for row in baseline['files']:
    verify(W / row['path'], row)
    verify(Path(baseline['snapshot']) / row['path'], row)

def inventory(root):
    return [dict(path=p.relative_to(root).as_posix(), bytes=p.stat().st_size, sha256=sha(p.read_bytes()))
            for p in sorted(root.rglob('*')) if p.is_file()]

assert inventory(W / 'competition/deepeye/simulator/.godot') == baseline['original_cache']
for root, expected in baseline['old_readonly_directory_inventories'].items():
    assert inventory(Path(root)) == expected, root
actual = read(P / 'backend-capture-root-actual-readback.json')
assert actual['actual_Godot_creates'] == 1 and actual['remaining_budget'] == 0
assert actual['core_count'] == 73 and actual['admitted_samples'] == 68
assert actual['full_original_scene_report']['all16_RGB_decoded_pixel_hashes_match']
assert len(actual['images']) == 16
for row in actual['images']:
    verify(A / 'attempt-01/frames' / row['path'], row)
decision = {
    'schema': 1, 'utc': datetime.now(timezone.utc).isoformat(),
    'actual_source_product_head': '5d7a943094b3309254639aaace68f157246d2e89',
    'outcome': 'FAILED_COMPOSITE_NATIVE_LOSS_GATE_WITH_16_REAL_PNG_ARTIFACTS',
    'actual_Godot_creates': 1, 'remaining_budget': 0,
    'backend': ['Windows', 'vulkan', 'forward_plus'],
    'backend_record_bytes': 1553,
    'byte_readback': 'New same-process fresh READ returned complete identical bytes; root independently read emitted file after terminal. No native fflush/fclose result, fsync or physical-media guarantee.',
    'raw_v1_metadata_limit': 'Legacy source_pins.json/variant declarations retained; actual v2 externally bound by exact candidate/plan/source hashes plus actual PID/owner records.',
    'full_original_scene': 'main.tscn/root Window; reported frame1/drill1/obstacle30, stopped=true;16 actual PNGs, all RGB pixel hashes independently decoded and matched, all16 visually inspected',
    'visual_quality': 'Development graybox with low-contrast objects and tiny/overlapping overview labels; no final quality approval',
    'resolution_limit': 'Actual 1080p/1440p PNGs; report logical shell/viewport remains1920x1080. No arbitrary DPI/logical viewport/input/physics proof.',
    'native_association': '73 cores;68 admitted seq5-72;seq73 TRUE/live process but no prior Engine => original loss gate failed',
    'PID_layers': 'Popen executable29036/exit2;native core owner10684 independently unqueried;Godot33496/TID28284/exit unobserved',
    'failure_cause_or_normal_teardown_inference': 'not established; no retroactive pass',
    'child_creator_terminal_owned_handles_closed': True, 'keeper_or_tool_session': False,
    'native_per_frame_atomic_continuous_no_flash': 'not_proven',
    'prestart_configuration_rejection': 'Zero target effects. Original388pairs preserved; config2 reorders actual wrapper first and adds3 evidence pins. Independent0361 review completed; no wrapper/candidate code change.',
    'source_correction': 'Strict API spelling plus raw-before-gate observation; original F01 cached-flush blocker retained, new fresh READ byte gate independently reviewed. Producer checks remain source-only.',
    'verified_members': {'author_canonical_and_frozen': 230, 'independent_static': 129, 'config_review_files': 3, 'product_and_snapshot_source_files': 104},
    'runtime_cache': '78 files/8037942 bytes retained in place, hash inventory only; payload excluded; original6 product cache and old69 unchanged',
    'old_failed_jobs': '71958 andff6736 sealed/exhausted/unchanged; no old tests/384 baseline/solve replay',
    'physical_board_calls': 0, 'source_changes_in_product': 0,
    'H01_H15_full_H12': 'preserved/open', 'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run',
    'next': 'Existing B minimalPL/C fixedCPU tasks via resident; earliest narrow realPL fixture diagnostic then PC_DIRECT submit/expiry stop when exact producers exist. No new execution authority from this publication.'}
save(P / 'backend-capture-final-root-decision.json', decision)

tokens = []
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key == 'lease_token' and isinstance(item, str) and item:
                tokens.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)
    elif isinstance(value, str) and value.lstrip().startswith(('{', '[')):
        try:
            collect(json.loads(value))
        except ValueError:
            pass
for path in set(O.glob('*/lease.private.json')) | set(P.glob('*/lease.private.json')):
    collect(read(path))
tokens = list(set(tokens))
assert len(tokens) >= 9
members = {}
def add(name, path):
    assert name not in members and not name.startswith('/') and '\\' not in name and '..' not in name.split('/')
    assert 'lease.private' not in name
    raw = path.read_bytes()
    assert not any(token in raw for token in tokens), name
    members[name] = raw
for name in include:
    add('author/' + name, A / name)
for name in ['final-manifest.json', 'archive-include.json', 'lifecycle-final/native-complete-result.json']:
    add('author/' + name, A / name)
for name in vm['files']:
    add('independent-static/' + name, V / name)
for name in ['artifact-manifest.json', 'native-complete-response.json']:
    add('independent-static/' + name, V / name)
for name in ['result.json', 'short-report.md', 'manifest.json']:
    add('independent-config/' + name, D / name)
root_names = [
    'backend-capture-final-root-decision.json', 'backend-capture-author-terminal-readback.json',
    'backend-capture-root-actual-readback.json', 'summarize_backend_capture_actual.py',
    'backend-capture-root-visual-review.md', 'backend-api-capture-actual-exec-tool-result.json',
    'backend-api-capture-wrapper-started.json', 'backend-api-capture-wrapper-child.json',
    'backend-api-capture-wrapper-exit.json', 'backend-api-capture-wrapper-stdout.bin',
    'backend-api-capture-wrapper-stderr.bin', 'run_backend_api_capture_once.py',
    'backend-api-capture-phase2-authorization.json', 'backend-api-capture-phase2-authorization-rejected-prestart.json',
    'correct_backend_api_prestart_config.py', 'backend-api-capture-prestart-rejection-tool-result.json',
    'backend-api-static-terminal-and-author-validation.json', 'backend-api-config2-terminal-and-fresh-validation.json',
    'backend-api-config2-fresh-author-validation.json', 'backend-api-config2-review-ownership.json',
    'backend-api-F01-root-source-decision.json', 'backend-api-capture-root-design-decision.json',
    'backend-api-capture-root-design-addendum.json', 'backend-api-capture-v2-root-preflight.json',
    'preflight_backend_api_capture_v2.py', 'derive_backend_api_v2_preflight.py',
    'backend-v2-root-preflight-derivation.json', 'preflight_backend_api_capture.py',
    'backend-api-capture-root-preflight.json', 'backend-api-root-wrapper.diff',
    'backend-api-root-wrapper-derivation.json', 'derive_backend_api_root_wrapper.py',
    'authorize_backend_api_capture_phase2.py', 'prepare_backend_capture_publication.py',
]
for name in root_names:
    add('root/' + name, P / name)
stage = P / 'staged-backend-api-capture'
stage.mkdir(exist_ok=False)
archive = stage / 'review-evidence.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(members.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.infolist()) == len(members)
    assert all(z.read(name) == raw for name, raw in members.items())
save(stage / 'manifest.json', {'schema': 1, 'archive_sha256': sha(archive.read_bytes()), 'member_count': len(members),
    'members': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())}})
save(stage / 'decision.json', decision)
with (stage / 'README.md').open('x', encoding='utf-8', newline='\n') as f:
    f.write('One new Godot create emitted16 original main-scene PNGs and a1553-byte raw Windows/vulkan/forward_plus backend record with fresh same-process complete READ. Root decoded all16 RGB hashes and inspected all images. The composite remains FAILED: sequence73 lost prior Engine association while the original process was sampled live. Godot exit/cause/per-frame/no-flash proof remain unknown; child/creator terminal and handles closed, no keeper/session, budget0. Development graybox/low contrast/tiny overview labels remain;1440p image/window coexists with1920x1080 logical shell/viewport, so no final quality/DPI/input/physics/H12 acceptance. Original cached-flush blocker/source corrections and prestart root-config rejection/correction are retained. Legacy v1 raw declarations do not replace external exact v2 binding. Author payload has115 canonical members; duplicate frozen/cache/vendor/engine/product-source bytes are excluded after root verification, with manifests/hash inventories retained. No old baseline/tests/solve/native replay. H01-H15/fullH12 preserved/open; G03/R03/all29 not_run.\n')
target = 'competition/deepeye/evidence/game/a-backend-api-capture-20261024'
dst = W / target
assert not dst.exists()
dst.mkdir(parents=True, exist_ok=False)
files = {}
for path in sorted(stage.iterdir()):
    assert path.is_file()
    shutil.copyfile(path, dst / path.name)
    expected = sha(path.read_bytes())
    assert sha((dst / path.name).read_bytes()) == expected
    files[target + '/' + path.name] = expected
assert len(files) == 4
save(P / 'backend-capture-publication.json', {'expected_head': '5d7a943094b3309254639aaace68f157246d2e89',
    'message': 'docs(deepeye): preserve real scene frames and failed native loss gate', 'files': files})
result = {'canonical_files': len(files), 'archive_members': len(members), 'archive_sha256': sha(archive.read_bytes()),
          'source_changes': 0, 'target_native_engine_calls': 0, 'lease_tokens_scanned': len(tokens)}
save(P / 'backend-capture-publication-preparation.json', result)
print(json.dumps(result))
