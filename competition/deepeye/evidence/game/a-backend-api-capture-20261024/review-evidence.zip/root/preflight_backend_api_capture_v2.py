"""Root read-only byte preflight. No candidate import, tests or execution authority."""
from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, subprocess

P = Path(__file__).resolve().parent
R = P.parents[2]
A = P.parent / 'game3d-backend-api-capture-20261024'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pins = {
    'phase1-manifest.json': '51b9fbb301326c7b9c96aea9a3469f3f03da1de766c03c025ea7fd115ad156ed',
    'launcher_v2.py': '566300f09b060673201c1d230082401cc6dcc3ce9aec0f2464f9f95bdf28e2ac',
    'capture_v2.gd': '1db06193cf6191dd348eea89ecf1714a7622eb6871908a34436b173a567b6656',
    'source-pins-v2.json': 'cf5a7b970bedf857413c0db445f1d4ea3daf60e8c90425ace28d3a42e33feb72',
    'execution-plan-v2.json': '9aede7afc30554baaa847deb5139671d5dd3a14134d3919c3f9a1877170968de',
    'argv-v2.json': '6707fa4b588006403cb46ec68fe6f94510d09b53ea58c3610823d3c7f7a669bd',
    'source-baseline.json': '860dccd93ab1150647c01914478b27594240495f54942afac4179c4e57403ca8',
}
for name, expected in pins.items():
    assert sha(A / name) == expected, name
manifest = read(A / 'phase1-manifest.json')
assert manifest['count'] == len(manifest['members']) == 35
for row in manifest['members']:
    for field in ['path', 'frozen_path']:
        path = (A / row[field]).resolve()
        assert path.is_relative_to(A.resolve())
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row[field]

assert sha(A / 'v2-manifest.json') == '7e1de6096c9ffc64d1c77b84c6cf2bf3e78f064064cb51e62c452432518dd006'
delta_manifest = read(A / 'v2-manifest.json')
assert delta_manifest['count'] == len(delta_manifest['members']) == 34
for row in delta_manifest['members']:
    for field in ['path', 'frozen_path']:
        path = (A / row[field]).resolve()
        assert path.is_relative_to(A.resolve())
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row[field]

baseline = read(A / 'source-baseline.json')
W, S = Path(baseline['product']), Path(baseline['snapshot'])
GIT = r'C:\Users\CarlJade\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe'
assert subprocess.check_output([GIT, '--no-optional-locks', '-C', str(W), 'rev-parse', 'HEAD']).decode().strip() == baseline['product_head'] == '5d7a943094b3309254639aaace68f157246d2e89'
assert not subprocess.check_output([GIT, '--no-optional-locks', '-C', str(W), 'diff', '--cached', '--name-only']).strip()
assert sha(Path(baseline['git_index']['path'])) == baseline['git_index']['sha256']
assert len(baseline['files']) == 52
for row in baseline['files']:
    for base in [W, S]:
        path = base / row['path']
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], str(path)
assert sorted(p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file()) == sorted(x['path'] for x in baseline['files'])
for name, expected in baseline['C4'].items():
    assert sha(W / name) == expected, name

def inventory(root):
    return [dict(path=p.relative_to(root).as_posix(), bytes=p.stat().st_size, sha256=sha(p))
            for p in sorted(root.rglob('*')) if p.is_file()]

assert inventory(W / 'competition/deepeye/simulator/.godot') == baseline['original_cache']
old_counts = {}
for name, expected in baseline['old_readonly_directory_inventories'].items():
    assert inventory(Path(name)) == expected, name
    old_counts[Path(name).name] = len(expected)
scope = read(R / 'docs/competition/deepeye-2026/immutable_scope.json')
canonical = json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
assert hashlib.sha256(canonical).hexdigest() == scope['requirements_sha256'] == baseline['requirements_sha256'] == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
plan, argv = read(A / 'execution-plan-v2.json'), read(A / 'argv-v2.json')
assert plan['job_id'] == 'child-9418116675a744ad9b39a7c4fe7f220a'
assert plan['strict_API_tuple'] == ['Windows', 'vulkan', 'forward_plus']
assert plan['strict_CLI_tuple'] == ['windows', 'vulkan', 'forward_plus']
assert argv['plan_sha256'] == pins['execution-plan-v2.json']
assert plan['phase2_execution_authorized'] is False
assert sha(Path(plan['engine'])) == plan['engine_sha256'] == 'ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424'
assert sha(P / 'run_backend_api_capture_once.py') == '845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5'
ast.parse((A / 'launcher_v2.py').read_bytes(), filename=str(A / 'launcher_v2.py'))
assert not (A / 'attempt-01').exists()
assert not (P / 'backend-api-capture-phase2-authorization.json').exists()
assert not (P / 'backend-api-capture-wrapper-started.json').exists()
result = {
    'utc': datetime.now(timezone.utc).isoformat(), 'job_id': plan['job_id'],
    'product_head': baseline['product_head'], 'exact_candidate_pins': pins,
    'frozen_and_active_member_checks': 138, 'original_and_snapshot_source_checks': 104,
    'old_directory_members': old_counts, 'C4_index_original_cache_unchanged': True,
    'engine_bytes_verified': True, 'launcher_python_AST_parse_only': True,
    'candidate_import_tests_GDScript_parse_engine_native_calls': 0,
    'attempt_absent': True, 'execution_authority': False,
    'next': 'Independent final exact static review, fresh canonical lease validation, then explicit root phase2 decision',
}
with (P / 'backend-api-capture-v2-root-preflight.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps(result, ensure_ascii=False))
