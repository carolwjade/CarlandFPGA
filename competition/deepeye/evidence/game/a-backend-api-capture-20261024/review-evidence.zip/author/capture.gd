extends SceneTree
## Full original stopped scene only. No actor/control/Run or alternate viewport.

var _scene
var _output := ""
var _frames: Array[Dictionary] = []
const KINDS := ["water", "hard_rock", "fault", "void", "casing"]
const SIZES := [Vector3(3,2,1), Vector3(1,1,1), Vector3(4,.5,3), Vector3(2,2,2), Vector3(.5,.5,3)]
const VIEWS := ["top", "bottom", "front", "back", "left", "right", "iso", "drill"]

func _initialize() -> void:
	_run.call_deferred()

func _fail(reason: String) -> void:
	push_error("PRIVATE_CAPTURE_FAILED: " + reason)
	_write_report({"status":"failed", "reason":reason, "frames":_frames})
	quit(2)

func _write_report(value: Dictionary) -> void:
	if _output.is_empty():
		return
	var file := FileAccess.open(_output.path_join("capture-report.json"), FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify(value, "\t") + "\n")
		file.flush()
		file.close()

func _safe_stopped() -> bool:
	return (_scene != null and _scene.document != null
		and _scene.document.control_bridge_connected == false
		and _scene.document.is_motion_active() == false
		and _scene.document.run_state == "editing"
		and _scene.shell._run_button.disabled and _scene.shell._pause_button.disabled
		and _scene.shell._continue_button.disabled)

func _record_backend_observation(value: Dictionary) -> bool:
	# This API flush is not OS fsync; root must independently read the bytes.
	var path := _output.path_join("backend-observation.json")
	var io := {"path":path, "open_error":null, "store_return":null,
		"store_error":null, "position_after_store":null, "payload_bytes":null,
		"flush_error":null, "flush_return_type":"void", "close_return_type":"void",
		"close_returned":false, "os_fsync":null, "independent_readback":null}
	if FileAccess.file_exists(path):
		io["failure"] = "owned backend observation already exists"
		printerr("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
		return false
	var payload := (JSON.stringify(value, "\t") + "\n").to_utf8_buffer()
	io["payload_bytes"] = payload.size()
	var file := FileAccess.open(path, FileAccess.WRITE)
	var open_error := FileAccess.get_open_error()
	io["open_error"] = open_error
	if file == null or open_error != OK:
		if file != null:
			file.close()
			io["close_returned"] = true
		printerr("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
		return false
	var stored := file.store_buffer(payload)
	var store_error := file.get_error()
	var position := file.get_position()
	io["store_return"] = stored
	io["store_error"] = store_error
	io["position_after_store"] = position
	if not stored or store_error != OK or position != payload.size():
		file.close()
		io["close_returned"] = true
		printerr("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
		return false
	file.flush()
	var flush_error := file.get_error()
	io["flush_error"] = flush_error
	file.close()
	io["close_returned"] = true
	print("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
	return flush_error == OK

func _run() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() != 1:
		_fail("exactly one owned output directory required")
		return
	_output = args[0]
	if not DirAccess.dir_exists_absolute(_output):
		_fail("output directory must already exist")
		return
	var sample_begin_usec := Time.get_ticks_usec()
	var raw_display: String = DisplayServer.get_name()
	var raw_driver: String = RenderingServer.get_current_rendering_driver_name()
	var raw_method: String = RenderingServer.get_current_rendering_method()
	var sample_end_usec := Time.get_ticks_usec()
	var observed_pid := OS.get_process_id()
	var process_clock := {"api":"Time.get_ticks_usec", "unit":"microseconds",
		"epoch":"this Godot process engine start", "pid":observed_pid,
		"sample_begin_usec":sample_begin_usec, "sample_end_usec":sample_end_usec,
		"cross_process_mapping":null, "timestamp_uncertainty_usec":null,
		"certified_interval":null}
	var raw := {"display_driver":raw_display, "rendering_driver":raw_driver, "rendering_method":raw_method}
	var expected := {"display_driver":"Windows", "rendering_driver":"vulkan", "rendering_method":"forward_plus"}
	var matches := {"display_driver":raw_display == expected["display_driver"],
		"rendering_driver":raw_driver == expected["rendering_driver"],
		"rendering_method":raw_method == expected["rendering_method"]}
	var observation := {"schema":1, "raw":raw, "expected":expected, "matches":matches,
		"godot_pid":observed_pid, "process_clock":process_clock,
		"declared_identity":{"job_id":"child-9418116675a744ad9b39a7c4fe7f220a",
			"work_id":"A-GAME3D-BACKEND-API-CAPTURE-20261024-v1",
			"run_id":"94181166-first-and-only-native-run", "attempt":1,
			"adapter_variant":"backend-api-observation-v1",
			"parent_capture_sha256":"6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5",
			"primary_commit":"ed1daf0bf001b61586d9930840f2f1394092c079",
			"expected_engine_sha256":"ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424",
			"source_pins":"source-pins.json", "identity_is_declaration_not_runtime_source_hash":true},
		"observation_phase":"pre_backend_admission_before_scene_load",
		"storage":{"API":"FileAccess.store_buffer/flush/close", "os_fsync":null,
			"independent_byte_readback":null}, "frame_native_time":null,
		"fresh_final_or_per_frame_backend_observation":false}
	if not _record_backend_observation(observation):
		_fail("backend observation recording failed")
		return
	if not matches["display_driver"] or not matches["rendering_driver"] or not matches["rendering_method"]:
		_fail("actual backend does not equal Windows/vulkan/forward_plus")
		return
	var packed := load("res://viewer/main.tscn") as PackedScene
	if packed == null:
		_fail("original main.tscn could not load")
		return
	_scene = packed.instantiate() as Node3D
	root.add_child(_scene)
	await process_frame
	if not _safe_stopped():
		_fail("original stopped/disabled state not preserved")
		return
	for z in range(2):
		for y in range(3):
			for x in range(5):
				var position := Vector3(-10 + 5*x, -7 + 7*y, -7 + 14*z)
				var added: Dictionary = _scene.document.add_obstacle(KINDS[x], position, Vector3.ZERO, SIZES[x])
				if not added.get("ok", false):
					_fail("original editor refused object: " + str(added))
					return
	if _scene.document.obstacle_count() != 30:
		_fail("30 original editor instances not present")
		return
	var presentation: Dictionary = _scene._asset_presenter.report()
	if presentation.get("state", "") != "ready":
		_fail("presentation degraded: " + str(presentation))
		return
	for target in [Vector2i(1920,1080), Vector2i(2560,1440)]:
		root.size = target
		await process_frame
		await process_frame
		for view in VIEWS:
			_scene.document.select_object(-1)
			_scene.focus_selected()
			_scene.set_camera_view("iso" if view == "drill" else view)
			if view == "drill":
				_scene.focus_drill()
			if not _safe_stopped():
				_fail("state changed while selecting camera")
				return
			# Explicit finite draws; never await a disabled auto-render signal first.
			for warmup in range(3):
				RenderingServer.force_draw(false)
				await process_frame
			RenderingServer.force_sync()
			var texture := root.get_texture()
			var frame := texture.get_image() if texture != null else null
			if frame == null or frame.is_empty() or frame.get_size() != target:
				_fail("empty or wrong-sized real root viewport image")
				return
			var name := "%dx%d-%s.png" % [target.x, target.y, view]
			var result := frame.save_png(_output.path_join(name))
			if result != OK:
				_fail("PNG write failed: " + error_string(result))
				return
			var digest := HashingContext.new()
			digest.start(HashingContext.HASH_SHA256)
			digest.update(frame.get_data())
			_frames.append({"path":name, "pixel_sha256":digest.finish().hex_encode(),
				"requested_size":[target.x,target.y], "window_size":[root.size.x,root.size.y],
				"image_size":[frame.get_width(),frame.get_height()],
				"viewport_rect":str(root.get_visible_rect()),
				"shell_size":str(_scene.shell._root.size),
				"central_ui_rect":str(_scene.shell._central_viewport.get_global_rect()),
				"camera_viewport_same_root":_scene._camera.get_viewport() == root,
				"camera_transform":str(_scene._camera.global_transform), "view":view,
				"stopped":_safe_stopped(), "layout_hash":_scene.document.layout_hash()})
	var report := {"status":"frames_written_await_root_visual_review", "formal_acceptance":false,
		"scene":"res://viewer/main.tscn", "root_window":true, "subviewport":false,
		"display_driver":raw_display, "rendering_driver":raw_driver, "rendering_method":raw_method,
		"backend_values_provenance":{"phase":"pre_backend_admission_before_scene_load",
			"reference":"backend-observation.json", "process_clock":process_clock,
			"fresh_final_or_per_frame_observation":false},
		"device":RenderingServer.get_video_adapter_name(), "vendor":RenderingServer.get_video_adapter_vendor(),
		"api_version":RenderingServer.get_video_adapter_api_version(), "pid":OS.get_process_id(),
		"obstacle_count":_scene.document.obstacle_count(), "presentation":presentation,
		"frames":_frames, "stopped":_safe_stopped(), "G03":"not_run", "R03":"not_run", "all29":"not_run"}
	_write_report(report)
	print("PRIVATE_CAPTURE_REPORT " + JSON.stringify(report))
	quit(0)
