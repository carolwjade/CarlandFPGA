"""New F01 plan/pins/argv only; no candidate import or target call."""
from pathlib import Path
import ast
import hashlib
import json

OUT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(name, value):
    p = OUT / name
    assert not p.exists(), str(p)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")


pins = json.loads((OUT / "source-pins.json").read_bytes())
pins.update(phase1_v1_source_pins_sha256=sha(OUT / "source-pins.json"),
            phase1_v1_launcher_sha256=sha(OUT / "launcher.py"),
            phase1_v1_capture_sha256=sha(OUT / "capture.gd"),
            launcher_sha256=sha(OUT / "launcher_v2.py"), capture_sha256=sha(OUT / "capture_v2.gd"),
            F01_root_source_decision_sha256=sha(OUT / "f01-research/root-source-decision.json"),
            F01_primary_source_pins_sha256=sha(OUT / "f01-research/primary-source-pins.json"),
            preserved_v1_manifest_sha256=sha(OUT / "phase1-manifest.json"),
            v2_scope="IO helper fresh READ single full-payload readback; launcher PLAN filename only",
            readback_claim="same-process filesystem-visible byte readback before scene load only when observed",
            actual_fflush_result=None, actual_fclose_result=None, OS_fsync=None, independent_root_readback=None)
put("source-pins-v2.json", pins)
old = json.loads((OUT / "execution-plan.json").read_bytes())
plan = dict(old)
plan.update(phase="phase1_F01_filesystem_visible_readback_v2_await_independent_review_and_root_phase2",
            adapter=str(OUT / "capture_v2.gd"), adapter_sha256=sha(OUT / "capture_v2.gd"),
            launcher_sha256=sha(OUT / "launcher_v2.py"), source_pins=str(OUT / "source-pins-v2.json"),
            source_pins_sha256=sha(OUT / "source-pins-v2.json"),
            F01_root_source_decision_sha256=pins["F01_root_source_decision_sha256"],
            backend_observation="frames/backend-observation.json; raw getters once; fresh READ exact full-payload check before load; same-process filesystem-visible only; fflush/fclose returns/root readback/fsync unknown")
put("execution-plan-v2.json", plan)
tree = ast.parse((OUT / "launcher_v2.py").read_text(encoding="utf-8"))
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "render_argv")
render_plan = dict(plan, frames=str(OUT / "attempt-01/frames"))
argv = []
for node in fn.body[0].value.elts:
    if isinstance(node, ast.Constant):
        argv.append(node.value)
    else:
        assert isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name) and node.value.id == "plan"
        argv.append(render_plan[ast.literal_eval(node.slice)])
old_argv = json.loads((OUT / "argv.json").read_bytes())
new_argv = dict(old_argv)
new_argv.update(engine_argv=argv,
                launcher_argv=[*old_argv["launcher_argv"][:5], str(OUT / "launcher_v2.py"), "--execute-reviewed", "--attempt", "1"],
                plan_sha256=sha(OUT / "execution-plan-v2.json"))
# Original prefix: python,-B,-X,utf8 followed by candidate; do not duplicate it.
new_argv["launcher_argv"] = [*old_argv["launcher_argv"][:4], str(OUT / "launcher_v2.py"), "--execute-reviewed", "--attempt", "1"]
put("argv-v2.json", new_argv)
old_tree = ast.parse((OUT / "launcher.py").read_text(encoding="utf-8"))
old_functions = {n.name:n for n in old_tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
new_functions = {n.name:n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
assert old_functions.keys() == new_functions.keys()
assert all(ast.dump(old_functions[k], include_attributes=False) == ast.dump(new_functions[k], include_attributes=False) for k in old_functions)
put("v2-delta-boundaries.json", dict(schema=1,
    adapter_delta="only _record_backend_observation IO helper; full remaining source byte-equal",
    launcher_delta="only PLAN filename; every function/class normalized AST equal",
    identical_Python_function_and_class_count=len(old_functions),
    all_functions_and_classes_AST_equal=True,
    plan_changed={k:dict(old=old.get(k),new=plan[k]) for k in plan if old.get(k)!=plan[k]},
    old_adapter_sha256=sha(OUT / "capture.gd"), new_adapter_sha256=sha(OUT / "capture_v2.gd"),
    old_launcher_sha256=sha(OUT / "launcher.py"), new_launcher_sha256=sha(OUT / "launcher_v2.py"),
    root_decision_sha256=pins["F01_root_source_decision_sha256"],
    target_native_calls=0, actual_Godot_creates=0, candidate_import_or_GDScript_parse=False))
print(json.dumps({name:sha(OUT / name) for name in ("launcher_v2.py", "capture_v2.gd", "source-pins-v2.json", "execution-plan-v2.json", "argv-v2.json")}, indent=2))
