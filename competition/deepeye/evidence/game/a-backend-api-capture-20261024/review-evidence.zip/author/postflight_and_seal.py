"""Final failure evidence only. No target APIs, candidate import, tests or engine."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import re
import struct

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
G = OUT.parent / "gen3-live-integration-20261024"
ATTEMPT = OUT / "attempt-01"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(name, value):
    p = OUT / name
    assert not p.exists(), str(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")


def inventory(root):
    return [dict(path=p.relative_to(root).as_posix(), bytes=p.stat().st_size, sha256=sha(p))
            for p in sorted(root.rglob("*")) if p.is_file()]


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def read_head(product):
    marker = product / ".git"
    gitdir = (product / marker.read_text(encoding="utf-8").strip().split(": ", 1)[1]).resolve() if marker.is_file() else marker
    head = (gitdir / "HEAD").read_text(encoding="utf-8").strip()
    if not head.startswith("ref: "):
        return head
    ref = head[5:]
    common = (gitdir / (gitdir / "commondir").read_text().strip()).resolve() if (gitdir / "commondir").exists() else gitdir
    for base in (gitdir, common):
        if (base / ref).exists():
            return (base / ref).read_text().strip()
        packed = base / "packed-refs"
        if packed.exists():
            for line in packed.read_text().splitlines():
                if line.endswith(" " + ref):
                    return line.split()[0]
    raise AssertionError("Cannot resolve product HEAD")


baseline = json.loads((OUT / "source-baseline.json").read_bytes())
product, snapshot = Path(baseline["product"]), Path(baseline["snapshot"])
sealed_names = []
for name, expected, count in (
    ("phase1-manifest.json", "51b9fbb301326c7b9c96aea9a3469f3f03da1de766c03c025ea7fd115ad156ed", 35),
    ("v2-manifest.json", "7e1de6096c9ffc64d1c77b84c6cf2bf3e78f064064cb51e62c452432518dd006", 34),
):
    assert sha(OUT / name) == expected
    manifest = json.loads((OUT / name).read_bytes())
    assert len(manifest["members"]) == count
    for row in manifest["members"]:
        assert sha(OUT / row["path"]) == row["sha256"] == sha(OUT / row["frozen_path"])
        sealed_names.append(row["path"])
for row in baseline["files"]:
    for base in (product, snapshot):
        assert (base / row["path"]).stat().st_size == row["bytes"] and sha(base / row["path"]) == row["sha256"]
for name, expected in baseline["C4"].items():
    assert sha(product / name) == expected
assert sha(Path(baseline["git_index"]["path"])) == baseline["git_index"]["sha256"]
assert inventory(product / "competition/deepeye/simulator/.godot") == baseline["original_cache"]
old_roots = []
for rootname, before in baseline["old_readonly_directory_inventories"].items():
    assert inventory(Path(rootname)) == before
    old_roots.append(dict(path=rootname, members=len(before), inventory_sha256=canonical_hash(before), unchanged=True))
scope = json.loads((ROOT / "docs/competition/deepeye-2026/immutable_scope.json").read_bytes())
contract = canonical_hash(scope["requirements"])
assert contract == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
transfer = json.loads((ROOT / ".planning/deepeye-desktop-handoff-20261015/transfer.json").read_bytes())
assert transfer["director_generation"] == 3 and transfer["new_director_thread_id"] == "01a16988-bdcb-70e1-ae10-1304b5cf7875" and transfer["status"] == "active"
plan = json.loads((OUT / "execution-plan-v2.json").read_bytes())
assert sha(OUT / "launcher_v2.py") == plan["launcher_sha256"]
assert sha(OUT / "capture_v2.gd") == plan["adapter_sha256"]
assert sha(OUT / "source-pins-v2.json") == plan["source_pins_sha256"]
assert sha(Path(plan["engine"])) == plan["engine_sha256"]
root_names = [
    "run_backend_api_capture_once.py", "authorize_backend_api_capture_phase2.py",
    "backend-api-capture-actual-exec-tool-result.json", "backend-api-capture-prestart-rejection-tool-result.json",
    "backend-api-capture-phase2-authorization-rejected-prestart.json", "backend-api-capture-phase2-authorization.json",
    "correct_backend_api_prestart_config.py", "backend-api-static-terminal-and-author-validation.json",
    "backend-api-config2-terminal-and-fresh-validation.json", "backend-api-capture-v2-root-preflight.json",
    "backend-api-capture-wrapper-started.json", "backend-api-capture-wrapper-child.json",
    "backend-api-capture-wrapper-exit.json", "backend-api-capture-wrapper-stdout.bin", "backend-api-capture-wrapper-stderr.bin",
]
root_pins = []
for name in root_names:
    source = G / name
    target = OUT / "final-root-inputs" / name
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
    assert sha(source) == sha(target)
    root_pins.append(dict(source=str(source), snapshot=target.relative_to(OUT).as_posix(), bytes=source.stat().st_size, sha256=sha(source)))
assert sha(G / "run_backend_api_capture_once.py") == "845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5"
config = json.loads((G / "backend-api-capture-phase2-authorization.json").read_bytes())
rejected = json.loads((G / "backend-api-capture-phase2-authorization-rejected-prestart.json").read_bytes())
assert sha(G / "backend-api-capture-phase2-authorization.json") == "965de32552b9a2b946b64b836c9e0ad6190d62fb82b950fe001327390658fcfd"
assert len(rejected["exact_source_sha256"]) == 388 and len(config["exact_source_sha256"]) == 391
assert all(config["exact_source_sha256"][k] == v for k,v in rejected["exact_source_sha256"].items())
assert config["candidate"].endswith("/launcher_v2.py") and config["configuration_revision"] == 2
assert config["exact_source_sha256"][config["candidate"]] == sha(OUT / "launcher_v2.py")
receipt = json.loads((ATTEMPT / "receipt.json").read_bytes())
events = [json.loads(line) for line in (ATTEMPT / "events.jsonl").read_text(encoding="utf-8").splitlines()]
core = [e for e in events if e["event"] == "enum_association_core"]
samples = [e for e in events if e["event"] == "native_association_sample"]
admitted = [e for e in samples if e["admitted"] is True]
diagnostics = [d for e in events if e["event"] == "optional_thread_desktop_diagnostics" for d in e["diagnostics"]]
assert receipt["failure"] == "CaptureBlocked('successful enumeration lost prior owned Engine association')"
assert receipt["child_terminal"] is True and receipt["creator_terminal"] is True and receipt["owned_handles_closed"] is True
assert len(core) == 73 and len(admitted) == 68
assert [e["sequence"] for e in admitted] == list(range(5, 73))
assert core[-1]["raw_bool"] == 1 and core[-1]["fresh_last_error"] == 0 and core[-1]["sequence"] == 73
assert not [r for r in core[-1]["rows"] if r["thread_query"]["pid_output"] == receipt["pid"] and r["class_query"]["text"] == "Engine"]
assert not list(ATTEMPT.glob("keeper-*.json"))
observed = json.loads((ATTEMPT / "frames/backend-observation.json").read_bytes())
report = json.loads((ATTEMPT / "frames/capture-report.json").read_bytes())
stdout = (ATTEMPT / "engine.stdout.bin").read_text(encoding="utf-8")
io_lines = [line[len("PRIVATE_BACKEND_RECORD_IO "):] for line in stdout.splitlines() if line.startswith("PRIVATE_BACKEND_RECORD_IO ")]
assert len(io_lines) == 1
io = json.loads(io_lines[0])
assert observed["raw"] == {"display_driver":"Windows", "rendering_driver":"vulkan", "rendering_method":"forward_plus"}
assert all(v is True for v in observed["matches"].values())
assert io["same_process_filesystem_visible_readback"] is True and io["read_bytes_equal"] is True and io["read_error"] == 0
assert io["payload_bytes"] == io["read_length"] == io["read_bytes"] == io["read_end_position"] == (ATTEMPT / "frames/backend-observation.json").stat().st_size == 1553
assert observed["godot_pid"] == report["pid"] == receipt["pid"] == 33496
assert report["scene"] == "res://viewer/main.tscn" and report["root_window"] is True and report["subviewport"] is False
assert report["status"] == "frames_written_await_root_visual_review" and report["formal_acceptance"] is False
assert report["presentation"]["factory_calls"] == dict(drill=1,frame=1,obstacle=30) and report["obstacle_count"] == 30
frames = []
expected_names = {"%dx%d-%s.png" % (w,h,v):(w,h) for w,h in ((1920,1080),(2560,1440)) for v in ("top","bottom","front","back","left","right","iso","drill")}
assert {p.name for p in (ATTEMPT / "frames").glob("*.png")} == set(expected_names)
for row in report["frames"]:
    p = ATTEMPT / "frames" / row["path"]
    data = p.read_bytes()
    assert data[:8] == b"\x89PNG\r\n\x1a\n" and struct.unpack(">II", data[16:24]) == expected_names[p.name]
    frames.append(dict(path=p.relative_to(OUT).as_posix(), bytes=len(data), sha256=sha(p),
                       PNG_IHDR_size=list(struct.unpack(">II", data[16:24])),
                       engine_declared_pixel_sha256=row["pixel_sha256"],
                       pixel_hash_independently_recomputed=False, engine_metadata=row))
assert len(frames) == 16
tool = json.loads((G / "backend-api-capture-actual-exec-tool-result.json").read_bytes())
wrapper_exit = json.loads((G / "backend-api-capture-wrapper-exit.json").read_bytes())
assert tool["exit_code"] == 1 and wrapper_exit["original_Popen_executable_exit"] == 2 and wrapper_exit["original_Popen_wait_terminal"] is True
# Inventory new runtime cache only: no cache payload enters the freeze/archive.
cache_roots = []
for name in ("appdata", "localappdata", "temp"):
    path = ATTEMPT / name
    rows = inventory(path)
    cache_roots.append(dict(root=path.relative_to(OUT).as_posix(), members=len(rows), bytes=sum(r["bytes"] for r in rows), files=rows))
original_source_paths = {r["path"] for r in baseline["files"]}
snapshot_extra = [r for r in inventory(snapshot) if r["path"] not in original_source_paths]
put("new-runtime-cache-inventory.json", dict(schema=1, claim="post-run byte inventory only; not a preflight cache modification",
                                           roots=cache_roots, snapshot_extra_files=snapshot_extra,
                                           payload_included_in_archive=False, no_cache_cleanup_or_mutation=True))
runtime = dict(schema=1, composite_outcome="FAILED_NATIVE_ENGINE_ASSOCIATION_LOSS", failure=receipt["failure"],
               Godot_creates=1, remaining_budget=0, root_prestart_rejection_Godot_creates=0,
               root_tool_exit=tool["exit_code"], root_tool_wall_seconds=tool["wall_time_seconds"], tool_session=None,
               original_Popen_executable_pid=wrapper_exit["pid"], original_Popen_executable_exit=wrapper_exit["original_Popen_executable_exit"],
               original_Popen_wait_terminal=True, core_owner_pid=core[0]["owner_pid"],
               Godot_pid=receipt["pid"], Godot_initial_tid=receipt["tid"], Godot_exit_code=None,
               identity_difference_explanation=None, native_reference=receipt["original_native_reference"],
               child_terminal=True, creator_terminal=True, owned_handles_closed=True, keeper_present=False,
               raw_backend=observed["raw"], backend_matches=observed["matches"], backend_IO=io,
               backend_file_author_postflight_sha256=sha(ATTEMPT / "frames/backend-observation.json"),
               raw_declared_v1_metadata=observed["declared_identity"],
               actual_external_v2_binding=dict(launcher_sha256=sha(OUT / "launcher_v2.py"), capture_sha256=sha(OUT / "capture_v2.gd"),
                                               plan_sha256=sha(OUT / "execution-plan-v2.json"), source_pins_sha256=sha(OUT / "source-pins-v2.json"),
                                               authorization_revision2_sha256=sha(G / "backend-api-capture-phase2-authorization.json")),
               backend_observation_clock=observed["process_clock"], frame_native_times=None, clock_domain_mapping=None,
               frame_count=len(frames), frame_file_bytes=sum(r["bytes"] for r in frames), frame_pins=frames,
               capture_report_status=report["status"], scene=report["scene"], root_window=report["root_window"],
               device=report["device"], vendor=report["vendor"], api_version=report["api_version"],
               stopped=report["stopped"], factory_calls=report["presentation"]["factory_calls"],
               event_count=len(events), event_kind_counts=dict(Counter(e["event"] for e in events)),
               core_count=len(core), raw_enum_pairs=[dict(raw_bool=b,fresh_last_error=e,count=n) for (b,e),n in Counter((x["raw_bool"],x["fresh_last_error"]) for x in core).items()],
               core_rows=sum(len(e["rows"]) for e in core), core_exception_count=sum(e["exception"] is not None for e in core),
               row_exception_count=sum(r["exception"] is not None for e in core for r in e["rows"]),
               admitted_count=len(admitted), first_admitted_sequence=admitted[0]["sequence"], last_admitted_sequence=admitted[-1]["sequence"],
               first_admitted_sample=admitted[0], last_admitted_sample=admitted[-1], final_core=core[-1],
               optional_diagnostic_items=len(diagnostics), optional_diagnostic_status_error_counts=[dict(status=s,error=e,count=n) for (s,e),n in Counter((d["status"],d["fresh_error"]) for d in diagnostics).items()],
               sampled_input_desktop_counts=dict(Counter(receipt["input_desktop_observations"])),
               input_before=receipt["input_desktop_before"], input_after=receipt["input_desktop_after"],
               no_flash_proof=None, per_frame_native_association=None, frame_engine_exit_causality=None,
               author_visual_review=False, independent_root_visual_review="separate root work; not incorporated without a pinned receipt",
               known_1440p_metadata_limit="PNG/window 2560x1440; reported logical shell/viewport remains 1920x1080",
               H01_H15_full_H12="preserved/open", G03="not_run", R03="not_run", all29="not_run")
put("final-runtime-summary.json", runtime)
put("final-integrity.json", dict(schema=1, product_head=read_head(product), expected_preflight_head=baseline["product_head"],
                                product_and_snapshot_52_each_unchanged=True, source_file_checks=104,
                                original35_and_v2_34_active_and_frozen_unchanged=True,
                                original_manifest_sha256=sha(OUT / "phase1-manifest.json"), v2_manifest_sha256=sha(OUT / "v2-manifest.json"),
                                C4_index_original_cache_unchanged=True, original_cache_members=len(baseline["original_cache"]),
                                old_readonly_roots=old_roots, old69GPUcache_unchanged_by_full_inventory=True,
                                runtime_cache_inventory_sha256=sha(OUT / "new-runtime-cache-inventory.json"),
                                snapshot_extra_runtime_file_count=len(snapshot_extra), new_cache_is_separate_runtime_artifact=True,
                                root_sources_and_receipts=root_pins, engine_binary_hashed_only=True,
                                requirements_canonical_sha256=contract, author_postflight_target_native_engine_calls=0,
                                actual_budget_consumed_by_root_Godot_creates=1, remaining_budget=0))
put("final-source-pins.json", dict(schema=1, job_id=baseline["job_id"], work_id=baseline["work_id"],
                                  product=baseline["product"], snapshot=baseline["snapshot"], files=baseline["files"],
                                  product_head=read_head(product), requirements_sha256=contract,
                                  final_variant="F01 v2 externally bound; immutable raw JSON still declares v1 metadata only",
                                  source_pins_v2_sha256=sha(OUT / "source-pins-v2.json"), execution_plan_v2_sha256=sha(OUT / "execution-plan-v2.json"),
                                  launcher_v2_sha256=sha(OUT / "launcher_v2.py"), capture_v2_sha256=sha(OUT / "capture_v2.gd"),
                                  argv_v2_sha256=sha(OUT / "argv-v2.json"), engine_sha256=plan["engine_sha256"],
                                  root_inputs=root_pins, runtime_summary_sha256=sha(OUT / "final-runtime-summary.json"),
                                  cache_payload_included=False, external_product_snapshot_payload_included=False))
result = dict(schema=1, job_id=baseline["job_id"], work_id=baseline["work_id"],
              outcome="FAILED_COMPOSITE_NATIVE_LOSS_GATE_WITH_16_REAL_PNG_ARTIFACTS", composite_pass=False,
              failure=receipt["failure"], Godot_creates=1, remaining_budget=0, PNG_count=16,
              backend_tuple=["Windows", "vulkan", "forward_plus"], same_process_1553byte_readback=True,
              complete_scene_report_present=True, factory_calls=report["presentation"]["factory_calls"],
              native_admitted_samples=68, final_sequence73_lost_Engine=True,
              child_terminal=True, creator_terminal=True, handles_closed=True, keeper=False, session=None,
              root_tool_exit=1, original_Popen_executable_exit=2, Godot_exit_code=None,
              root_prestart_failure="selfcheck before Popen; zero target creates; original config preserved",
              configuration2_static_review_job="child-0361392d03f845e1a2dc6cce579032ea",
              independent_static_review_018_manifest_sha256="5c7418726694ce1139dcadd8e5a79f2a6dd9d7451a3ce4e8ddd84ec0f068315a",
              configuration2_review_manifest_sha256="6fbb6afb0929c18454ab119c8aee3ece68facd742336493e884b1c5d3ef75769",
              actual_config2_sha256=sha(G / "backend-api-capture-phase2-authorization.json"),
              frame_native_timestamps=None, no_flash=None, per_frame_native_association=None, formal_acceptance=False,
              visual_review="root independent work, outside this failure seal", old_failures_unchanged=True,
              postflight_native_engine_calls=0, no_retry_or_source_fix=True,
              requirements_sha256=contract, H01_H15_full_H12="preserved/open", G03="not_run", R03="not_run", all29="not_run")
put("final-result.json", result)
report_text = """# Job9418 final failure seal

**Composite result: FAILED. One actual Godot create, 16 PNG artifacts, remaining budget 0.** The unchanged native-loss gate raised `successful enumeration lost prior owned Engine association`. The new backend/readback and images are retained facts; they do not make the composite pass. No retry, fallback, import, source correction, engine/native call, old test or product change occurred during this postflight.

Root's first wrapper invocation was rejected by its selfcheck before Popen: the configuration listed a reviewer's same-named wrapper snapshot first. The original tool error and 388-pair configuration are preserved. Revision2 only reorders/binds the actual wrapper first, retains all original388 pairs (391 total), and has completed independent config-only review child0361. The original wrapper845 and candidate source are unchanged. That prestart rejection made zero Godot creates. Root then executed the single authorized native attempt after completed129-member018 review and fresh lease validation. Revision2 SHA965de32552b9a2b946b64b836c9e0ad6190d62fb82b950fe001327390658fcfd and the raw review/authorization records are snapshotted, without reinterpreting source review as runtime proof.

The actual backend-observation.json contains raw `Windows/vulkan/forward_plus`, all three comparisons true, actual Godot PID33496. Its 1553 bytes have a stable postflight file hash. Engine stdout reports the new reader returned all1553 identical bytes, error0, initial cursor0/end1553. This is only same-process filesystem-visible readback; native fflush/fclose results, fsync and the raw record's independent root-readback field remain null. Its process tick bracket is1344221–1344223 microseconds since that engine start, with unknown uncertainty/cross-process mapping. It does not timestamp frames. The raw JSON intentionally retains declared adapter_variant v1/source_pins.json; these declarations are not v2 self-hashes. Actual v2 binding comes from the externally reviewed launcher566300f0/capture1db06193/sourcepinscf5a7b97/plan9aede7af/config2 hashes and the separate runtime PID/HANDLE evidence.

The complete original `res://viewer/main.tscn` in its root Window produced a stopped capture-report, factory counts frame1/drill1/obstacle30, and the16 expected PNG files: 1080p/1440p × top/bottom/front/back/left/right/iso/drill. PNG file hashes and IHDR dimensions are pinned; engine pixel hashes are retained as engine declarations and are not independently recomputed here. Actual device getters report NVIDIA GeForce RTX4070 Laptop GPU, vendor NVIDIA, API1.4.303; raw stdout labels Vulkan/Forward+. Final backend fields explicitly reuse the earlier pre-predicate snapshot, not a fresh final/per-frame read. The1440p image/window metadata is2560×1440 while reported shell/visible-viewport logical dimensions remain1920×1080; no layout/DPI/visual-quality pass is inferred. Root owns separate image inspection and bytes review.

Raw events contain227 entries:73 enum cores,4 FALSE/fresh0 pending and69 TRUE/fresh0,582 complete rows, no core/row exceptions.68 native samples were admitted at sequences5–72 for Engine HWND7670332/PID33496/TID28284 while the original hProcess was sampled live. Sequence73 is a successful enumeration of4 non-Engine rows with the original process sampled live before/after; it has no owned Engine row, triggering the preserved loss gate.68 optional thread-desktop diagnostics were unavailable/Error5, with no invented desktop name. Native sampling and PNG capture are not atomic; no per-frame current-association/no-flash proof or cause/order of frame completion versus window loss/engine exit is established.

Keep the identities/exit layers separate: root tool exit1 in4.9625089s/no session; original Popen executable PID29036 exit2/wait terminal; core owner PID10684; Godot PID33496/initial TID28284. Their identity difference is not explained or merged. Godot exit code was not observed. Original HANDLE receipt positively records child terminal, creator terminal and owned handles closed. No keeper exists. WinSta0 private desktop468 is named DeepEye_94181166_729c0c33922d42868f24ee21eaad0690_01; before/during/after input-desktop samples are Default, which does not prove uninterrupted invisibility/no flash.

Original35 and v2 34 active/frozen members/manifests, 52 product plus52 snapshot sources, C4, index, original6 cache files, old ff/71958/029d/bfcc directories and old69 GPUcache match their saved bytes. New runtime cache is inventoried by hash only and excluded from payload; it is not an alteration of the original cache. Root wrapper/auth/receipts are byte snapshots with an explicit source manifest. No cache cleanup or old-evidence rewriting occurred. The final manifest contains canonical small evidence/PNG payload only, excluding itself, its include-list companion, private leases, this author's mesh lifecycle records, duplicate frozen trees, engine/vendor/cache and external product/snapshot payload. No ZIP is created.

This is a failure-result archive with finite real backend/readback/image evidence, not GPU timing, visual quality, active UI input, collision/physics/DPI, full G01/G02 or H12 acceptance. H01-H15/full H12 and canonical c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 remain preserved/open; G03/R03/all29=not_run. Source GREEN/RED and all old failures remain unchanged. Root must choose any different future method under a new job/budget.
"""
p = OUT / "final-report.md"
assert not p.exists()
p.write_text(report_text, encoding="utf-8", newline="\n")
canonical_names = set(sealed_names) | {"phase1-manifest.json", "v2-manifest.json", "postflight_and_seal.py", "final-report.md", "final-result.json", "final-source-pins.json", "final-integrity.json", "final-runtime-summary.json", "new-runtime-cache-inventory.json"}
canonical_names |= {p.relative_to(OUT).as_posix() for p in (OUT / "final-root-inputs").iterdir() if p.is_file()}
canonical_names |= {p.relative_to(OUT).as_posix() for p in ATTEMPT.iterdir() if p.is_file()}
canonical_names |= {p.relative_to(OUT).as_posix() for p in (ATTEMPT / "frames").iterdir() if p.is_file()}
# Mesh lifecycle records are intentionally outside the sealed payload. Root review
# terminal references explicitly requested above remain source snapshots.
canonical_names = {n for n in canonical_names if not n.endswith("native-validation-tokenfree.json") and "lease.private" not in n}
whitespace = []
for n in ("postflight_and_seal.py", "final-report.md", "final-result.json", "final-source-pins.json", "final-integrity.json", "final-runtime-summary.json", "new-runtime-cache-inventory.json"):
    data = (OUT / n).read_bytes()
    assert data.endswith(b"\n") and not data.endswith(b"\n\n"), n
    assert not any(re.search(rb"[\t ]+$", line) for line in data.splitlines()), n
    whitespace.append(n)
put("final-whitespace.json", dict(schema=1, new_authored_files=whitespace, exactly_one_final_LF=True, no_trailing_whitespace=True, raw_old_and_runtime_bytes_not_normalized=True))
canonical_names.add("final-whitespace.json")
payload = sorted(canonical_names)
exclusions = ["final-manifest.json/self", "archive-include.json/self", "lease.private.json/private requests", "lifecycle-final/* and author validation receipts", "frozen-phase1/* frozen-v2/* frozen-final/* duplicates", "attempt-01/appdata/* localappdata/* temp/* cache payload", "engine/vendor binary payload", "external product/snapshot payload"]
put("archive-include.json", dict(schema=1, root=str(OUT), purpose="optional small payload list; no ZIP created", payload_members=payload, exclusions=exclusions,
                                 companion_manifests="final-manifest.json and archive-include.json are separately supplied companions, never self-members"))
frozen = OUT / "frozen-final"
assert not frozen.exists()
frozen.mkdir()
rows = []
for n in payload:
    source = OUT / n
    target = frozen / n
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
    assert sha(source) == sha(target)
    rows.append(dict(path=n, bytes=source.stat().st_size, sha256=sha(source), frozen_path=target.relative_to(OUT).as_posix()))
put("final-manifest.json", dict(schema=1, root=str(OUT), frozen_root=str(frozen), job_id=baseline["job_id"],
                               outcome="FAILED_COMPOSITE_NATIVE_LOSS_GATE_WITH_16_REAL_PNG_ARTIFACTS", members=rows, count=len(rows),
                               total_bytes=sum(r["bytes"] for r in rows), archive_include_sha256=sha(OUT / "archive-include.json"),
                               exclusions=exclusions, cache_is_inventory_only=True, actual_Godot_creates=1, remaining_budget=0,
                               native_complete_record="post-freeze lifecycle-final, excluded to avoid self-reference"))
for row in rows:
    assert sha(OUT / row["path"]) == row["sha256"] == sha(OUT / row["frozen_path"])
for item in root_pins:
    assert sha(Path(item["source"])) == item["sha256"]
print(json.dumps(dict(outcome=result["outcome"], count=len(rows), bytes=sum(r["bytes"] for r in rows),
                      new_runtime_cache_members=sum(r["members"] for r in cache_roots),
                      new_runtime_cache_bytes=sum(r["bytes"] for r in cache_roots),
                      exactpins={n:sha(OUT / n) for n in ("final-report.md", "final-result.json", "final-source-pins.json", "final-integrity.json", "final-runtime-summary.json", "new-runtime-cache-inventory.json", "archive-include.json", "final-manifest.json")}), indent=2))
