"""Source-only derivation. No candidate import, target native API or engine call."""
from pathlib import Path
import difflib

OUT = Path(__file__).resolve().parent


def replace_once(text, old, new):
    assert text.count(old) == 1, repr(old)
    return text.replace(old, new, 1)


def put(name, text):
    path = OUT / name
    assert not path.exists(), str(path)
    path.write_text(text, encoding="utf-8", newline="\n")


original_launcher = (OUT / "inputs/launcher_v2.py").read_text(encoding="utf-8")
launcher = original_launcher
for old, new in (
    ('WORK_ID = "A-GAME3D-ENUM-ASSOCIATION-CAPTURE-20261024-v1"', 'WORK_ID = "A-GAME3D-BACKEND-API-CAPTURE-20261024-v1"'),
    ('JOB_ID = "child-ff673689f0da408998a3a64ed82abd10"', 'JOB_ID = "child-9418116675a744ad9b39a7c4fe7f220a"'),
    ('SPACE = ROOT / ".local/deepeye-game3d-enum-association-capture-20261024"', 'SPACE = ROOT / ".local/deepeye-game3d-backend-api-capture-20261024"'),
    ('PLAN = OUT / "execution-plan-v2.json"', 'PLAN = OUT / "execution-plan.json"'),
    ('!= ("windows", "vulkan", "forward_plus"):', '!= ("Windows", "vulkan", "forward_plus"):'),
):
    launcher = replace_once(launcher, old, new)
put("launcher.py", launcher)
put("launcher.diff", "".join(difflib.unified_diff(original_launcher.splitlines(keepends=True), launcher.splitlines(keepends=True), fromfile="immutable-61c6de6/launcher_v2.py", tofile="9418/launcher.py")))

original_capture = (OUT / "inputs/capture_621.gd").read_text(encoding="utf-8")
helper = '''func _record_backend_observation(value: Dictionary) -> bool:
	# This API flush is not OS fsync; root must independently read the bytes.
	var path := _output.path_join("backend-observation.json")
	var io := {"path":path, "open_error":null, "store_return":null,
		"store_error":null, "position_after_store":null, "payload_bytes":null,
		"flush_error":null, "flush_return_type":"void", "close_return_type":"void",
		"close_returned":false, "os_fsync":null, "independent_readback":null}
	if FileAccess.file_exists(path):
		io["failure"] = "owned backend observation already exists"
		printerr("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
		return false
	var payload := (JSON.stringify(value, "\\t") + "\\n").to_utf8_buffer()
	io["payload_bytes"] = payload.size()
	var file := FileAccess.open(path, FileAccess.WRITE)
	var open_error := FileAccess.get_open_error()
	io["open_error"] = open_error
	if file == null or open_error != OK:
		if file != null:
			file.close()
			io["close_returned"] = true
		printerr("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
		return false
	var stored := file.store_buffer(payload)
	var store_error := file.get_error()
	var position := file.get_position()
	io["store_return"] = stored
	io["store_error"] = store_error
	io["position_after_store"] = position
	if not stored or store_error != OK or position != payload.size():
		file.close()
		io["close_returned"] = true
		printerr("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
		return false
	file.flush()
	var flush_error := file.get_error()
	io["flush_error"] = flush_error
	file.close()
	io["close_returned"] = true
	print("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
	return flush_error == OK

'''
capture = replace_once(original_capture, "func _run() -> void:\n", helper + "func _run() -> void:\n")
old_gate = '''	if DisplayServer.get_name() != "windows" or RenderingServer.get_current_rendering_driver_name() != "vulkan" or RenderingServer.get_current_rendering_method() != "forward_plus":
		_fail("actual backend does not equal windows/vulkan/forward_plus")
		return
'''
new_gate = '''	var sample_begin_usec := Time.get_ticks_usec()
	var raw_display: String = DisplayServer.get_name()
	var raw_driver: String = RenderingServer.get_current_rendering_driver_name()
	var raw_method: String = RenderingServer.get_current_rendering_method()
	var sample_end_usec := Time.get_ticks_usec()
	var observed_pid := OS.get_process_id()
	var process_clock := {"api":"Time.get_ticks_usec", "unit":"microseconds",
		"epoch":"this Godot process engine start", "pid":observed_pid,
		"sample_begin_usec":sample_begin_usec, "sample_end_usec":sample_end_usec,
		"cross_process_mapping":null, "timestamp_uncertainty_usec":null,
		"certified_interval":null}
	var raw := {"display_driver":raw_display, "rendering_driver":raw_driver, "rendering_method":raw_method}
	var expected := {"display_driver":"Windows", "rendering_driver":"vulkan", "rendering_method":"forward_plus"}
	var matches := {"display_driver":raw_display == expected["display_driver"],
		"rendering_driver":raw_driver == expected["rendering_driver"],
		"rendering_method":raw_method == expected["rendering_method"]}
	var observation := {"schema":1, "raw":raw, "expected":expected, "matches":matches,
		"godot_pid":observed_pid, "process_clock":process_clock,
		"declared_identity":{"job_id":"child-9418116675a744ad9b39a7c4fe7f220a",
			"work_id":"A-GAME3D-BACKEND-API-CAPTURE-20261024-v1",
			"run_id":"94181166-first-and-only-native-run", "attempt":1,
			"adapter_variant":"backend-api-observation-v1",
			"parent_capture_sha256":"6210469f30df17a2570bd7c48615b8cf901e739af36eb5e9f43b44b3e3f8caf5",
			"primary_commit":"ed1daf0bf001b61586d9930840f2f1394092c079",
			"expected_engine_sha256":"ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424",
			"source_pins":"source-pins.json", "identity_is_declaration_not_runtime_source_hash":true},
		"observation_phase":"pre_backend_admission_before_scene_load",
		"storage":{"API":"FileAccess.store_buffer/flush/close", "os_fsync":null,
			"independent_byte_readback":null}, "frame_native_time":null,
		"fresh_final_or_per_frame_backend_observation":false}
	if not _record_backend_observation(observation):
		_fail("backend observation recording failed")
		return
	if not matches["display_driver"] or not matches["rendering_driver"] or not matches["rendering_method"]:
		_fail("actual backend does not equal Windows/vulkan/forward_plus")
		return
'''
capture = replace_once(capture, old_gate, new_gate)
capture = replace_once(capture, '''		"display_driver":DisplayServer.get_name(), "rendering_driver":RenderingServer.get_current_rendering_driver_name(),
		"rendering_method":RenderingServer.get_current_rendering_method(),
''', '''		"display_driver":raw_display, "rendering_driver":raw_driver, "rendering_method":raw_method,
		"backend_values_provenance":{"phase":"pre_backend_admission_before_scene_load",
			"reference":"backend-observation.json", "process_clock":process_clock,
			"fresh_final_or_per_frame_observation":false},
''')
put("capture.gd", capture)
put("capture.diff", "".join(difflib.unified_diff(original_capture.splitlines(keepends=True), capture.splitlines(keepends=True), fromfile="immutable-6210469/capture.gd", tofile="9418/capture.gd")))
print("Prepared source only: launcher.py, capture.gd and complete diffs; target native/engine calls=0")
