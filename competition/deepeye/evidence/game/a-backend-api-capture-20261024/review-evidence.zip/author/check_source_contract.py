"""Independent primary-contract and change-boundary checks; never imports candidate."""
from pathlib import Path
import ast
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(node):
    return ast.dump(node, include_attributes=False)


def functions(tree):
    return {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}


mapping = json.loads((OUT / "inputs/backend-name-mapping.json").read_bytes())
primary = mapping["strict_intended_API_tuple"]
assert primary == ["Windows", "vulkan", "forward_plus"]
old_py = (OUT / "inputs/launcher_v2.py").read_text(encoding="utf-8")
new_py = (OUT / "launcher.py").read_text(encoding="utf-8")
old_gd = (OUT / "inputs/capture_621.gd").read_text(encoding="utf-8")
new_gd = (OUT / "capture.gd").read_text(encoding="utf-8")
old_tree, new_tree = ast.parse(old_py), ast.parse(new_py)
old_functions, new_functions = functions(old_tree), functions(new_tree)
assert old_functions.keys() == new_functions.keys()
changed = [name for name in old_functions if dump(old_functions[name]) != dump(new_functions[name])]
assert changed == ["validate_capture_outputs"], changed
expected_py = old_py
for before, after in (
    ('WORK_ID = "A-GAME3D-ENUM-ASSOCIATION-CAPTURE-20261024-v1"', 'WORK_ID = "A-GAME3D-BACKEND-API-CAPTURE-20261024-v1"'),
    ('JOB_ID = "child-ff673689f0da408998a3a64ed82abd10"', 'JOB_ID = "child-9418116675a744ad9b39a7c4fe7f220a"'),
    ('SPACE = ROOT / ".local/deepeye-game3d-enum-association-capture-20261024"', 'SPACE = ROOT / ".local/deepeye-game3d-backend-api-capture-20261024"'),
    ('PLAN = OUT / "execution-plan-v2.json"', 'PLAN = OUT / "execution-plan.json"'),
    ('!= ("windows", "vulkan", "forward_plus"):', '!= ("Windows", "vulkan", "forward_plus"):'),
):
    assert expected_py.count(before) == 1
    expected_py = expected_py.replace(before, after, 1)
assert new_py == expected_py
assert dump(ast.parse(expected_py)) == dump(new_tree)
parent_tuples = [ast.literal_eval(n) for n in ast.walk(new_functions["validate_capture_outputs"])
                 if isinstance(n, ast.Tuple) and all(isinstance(v, ast.Constant) and isinstance(v.value, str) for v in n.elts)]
assert tuple(primary) in parent_tuples
assert ("windows", "vulkan", "forward_plus") not in parent_tuples
adapter_expected = json.loads(re.search(r'var expected := (\{[^\n]+\})', new_gd).group(1))
assert list(adapter_expected.values()) == primary
getter_counts = {getter: new_gd.count(getter) for getter in (
    "DisplayServer.get_name()", "RenderingServer.get_current_rendering_driver_name()",
    "RenderingServer.get_current_rendering_method()")}
assert list(getter_counts.values()) == [1, 1, 1]
run = new_gd[new_gd.index("func _run() -> void:"):]
record = run.index("if not _record_backend_observation(observation):")
gate = run.index('if not matches["display_driver"] or not matches["rendering_driver"] or not matches["rendering_method"]:')
load = run.index('var packed := load("res://viewer/main.tscn") as PackedScene')
assert run.index('var observation :=') < record < gate < load
assert '\t\t_fail("backend observation recording failed")\n\t\treturn\n' in run[record:gate]
assert not any(token in run for token in (".to_lower(", ".to_upper(", ".nocasecmp_to(", ".replace("))
for variable, getter in (("raw_display", "DisplayServer.get_name()"),
                         ("raw_driver", "RenderingServer.get_current_rendering_driver_name()"),
                         ("raw_method", "RenderingServer.get_current_rendering_method()")):
    assert '\tvar %s: String = %s\n' % (variable, getter) in run[:record]
assert new_gd[:new_gd.index("func _record_backend_observation")] == old_gd[:old_gd.index("func _run()")]
old_suffix = old_gd[old_gd.index('\tvar packed := load('):]
new_suffix = new_gd[new_gd.index('\tvar packed := load('):]
approved_report_new = '''\t\t"display_driver":raw_display, "rendering_driver":raw_driver, "rendering_method":raw_method,
\t\t"backend_values_provenance":{"phase":"pre_backend_admission_before_scene_load",
\t\t\t"reference":"backend-observation.json", "process_clock":process_clock,
\t\t\t"fresh_final_or_per_frame_observation":false},
'''
approved_report_old = '''\t\t"display_driver":DisplayServer.get_name(), "rendering_driver":RenderingServer.get_current_rendering_driver_name(),
\t\t"rendering_method":RenderingServer.get_current_rendering_method(),
'''
assert new_suffix.count(approved_report_new) == 1
assert new_suffix.replace(approved_report_new, approved_report_old, 1) == old_suffix
helper = new_gd[new_gd.index("func _record_backend_observation"):new_gd.index("func _run()")]
assert helper.index("var stored := file.store_buffer(payload)") < helper.index("var store_error := file.get_error()") < helper.index("var position := file.get_position()")
assert helper.index("if not stored or store_error != OK or position != payload.size():") < helper.index("file.flush()")
assert helper.index("file.flush()") < helper.index("var flush_error := file.get_error()") < helper.index("return flush_error == OK")
assert '"os_fsync":null' in helper and '"independent_readback":null' in helper
assert '"frame_native_time":null' in run and '"timestamp_uncertainty_usec":null' in run
assert '"fresh_final_or_per_frame_backend_observation":false' in run
assert '"reference":"backend-observation.json", "process_clock":process_clock' in new_suffix
assert '"run_id":"94181166-first-and-only-native-run"' in run
render = ast.get_source_segment(new_py, new_functions["render_argv"])
assert '"--display-driver", "windows"' in render
assert '"--rendering-driver", "vulkan", "--rendering-method", "forward_plus"' in render
result = dict(schema=1, mode="primary_contract_and_exact_source_boundaries_not_runtime",
              primary_commit=mapping["commit"], primary_expected_API=primary,
              expected_CLI=["windows", "vulkan", "forward_plus"],
              changed_launcher_functions=changed,
              unchanged_launcher_functions_and_classes=[n for n in old_functions if n not in changed],
              exact_launcher_text_delta_only_five_substitutions=True,
              normalized_full_launcher_AST_after_authorized_substitutions_equal=True,
              API_getter_call_counts=getter_counts, record_before_admission_before_scene_load=True,
              original_scene_geometry_UI_views_suffix_equal_after_approved_report_restoration=True,
              original_adapter_prefix_helpers_equal=True, backend_record_source_order_checked=True,
              actual_backend_tuple=None, actual_IO_success=None, GDScript_parse_or_runtime=None,
              target_native_calls=0, actual_Godot_creates=0, old_controls_run=0,
              phase2_execution_authorized=False,
              hashes={p:sha(OUT / p) for p in ("launcher.py", "capture.gd", "inputs/root-decision.json", "inputs/root-addendum.json", "inputs/backend-name-mapping.json")},
              function_AST_sha256={n:dict(old=hashlib.sha256(dump(old_functions[n]).encode()).hexdigest(),
                                         new=hashlib.sha256(dump(new_functions[n]).encode()).hexdigest()) for n in old_functions})
path = OUT / "source-contract-green-result.json"
assert not path.exists()
path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({k:result[k] for k in ("mode", "primary_expected_API", "expected_CLI", "changed_launcher_functions", "API_getter_call_counts", "target_native_calls", "actual_Godot_creates")}, ensure_ascii=False, indent=2))
