"""Preserve rejected pre-start configuration; order the actual wrapper first."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os

P = Path(__file__).resolve().parent
R = P.parents[2]
A = P.parent / 'game3d-backend-api-capture-20261024'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
current = P / 'backend-api-capture-phase2-authorization.json'
preserved = P / 'backend-api-capture-phase2-authorization-rejected-prestart.json'
assert current.resolve().parent == preserved.resolve().parent == P.resolve()
assert not preserved.exists()
for suffix in ['started.json', 'child.json', 'exit.json', 'stdout.bin', 'stderr.bin']:
    assert not (P / ('backend-api-capture-wrapper-' + suffix)).exists(), suffix
assert not (A / 'attempt-01').exists()
failure = read(P / 'backend-api-capture-prestart-rejection-tool-result.json')
assert failure['exit_code'] == 1 and 'AssertionError' in failure['output']
assert 'line 26, in main' in failure['output'] and 'session_id' not in failure
old = read(current)
wrapper = P / 'run_backend_api_capture_once.py'
wrapper_rel = wrapper.relative_to(R).as_posix()
assert sha(wrapper) == old['exact_source_sha256'][wrapper_rel] == '845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5'
matches = [name for name in old['exact_source_sha256'] if name.endswith('/run_backend_api_capture_once.py')]
assert len(matches) == 2 and matches[0] != wrapper_rel and matches[1] == wrapper_rel
validation_path = P / 'backend-api-config2-fresh-author-validation.json'
validation = json.loads(read(validation_path)['content'][0]['text'])
assert validation['job_id'] == old['job_id'] == 'child-9418116675a744ad9b39a7c4fe7f220a'
assert validation['native_agent_id'] == '/root/pc_direct_window' and validation['execution_allowed'] is True
new = dict(old)
new['exact_source_sha256'] = {wrapper_rel: old['exact_source_sha256'][wrapper_rel]}
new['exact_source_sha256'].update({k: v for k, v in old['exact_source_sha256'].items() if k != wrapper_rel})
for name in ['backend-api-config2-fresh-author-validation.json', 'correct_backend_api_prestart_config.py',
             'backend-api-capture-prestart-rejection-tool-result.json']:
    new['exact_source_sha256'][(P / name).relative_to(R).as_posix()] = sha(P / name)
new['configuration_revision'] = 2
new['configuration_revision_utc'] = datetime.now(timezone.utc).isoformat()
new['preserved_prestart_rejected_configuration'] = {'path': preserved.name, 'sha256': sha(current)}
new['configuration_correction'] = 'Actual root wrapper first in the unchanged source map, so the existing first-suffix self-check selects it. No wrapper/candidate/native-control change; pre-start guard rejected before any Popen/started/attempt, actual Godot budget remains unconsumed.'
assert all(new['exact_source_sha256'][k] == v for k, v in old['exact_source_sha256'].items())
selected = next(name for name in new['exact_source_sha256'] if name.endswith('/run_backend_api_capture_once.py'))
assert selected == wrapper_rel and str(wrapper.resolve()).replace('\\', '/').endswith('/' + selected)
for name, expected in new['exact_source_sha256'].items():
    path = (R / name).resolve()
    assert path.is_relative_to(R.resolve()) and sha(path) == expected, name
current.rename(preserved)
with current.open('x', encoding='utf-8', newline='\n') as f:
    json.dump(new, f, ensure_ascii=False, indent=2)
    f.write('\n')
    f.flush()
    os.fsync(f.fileno())
assert sha(preserved) == new['preserved_prestart_rejected_configuration']['sha256']
print(json.dumps({'revision': 2, 'old388_pairs_unchanged': True,
                  'selected_actual_wrapper': selected, 'target_calls': 0,
                  'original_Godot_budget_remaining': 1, 'configuration_sha256': sha(current)}))
