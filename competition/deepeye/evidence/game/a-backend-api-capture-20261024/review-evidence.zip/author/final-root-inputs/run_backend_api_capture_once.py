"""Root wrapper for one separately authorized native job; no killing timeout/replay."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, sys

P = Path(__file__).resolve().parent
R = P.parents[2]
JOB = 'child-9418116675a744ad9b39a7c4fe7f220a'
PREFIX = 'backend-api-capture-wrapper'

def write_once(suffix, data):
    with (P / (PREFIX + '-' + suffix + '.json')).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())

def main():
    config = json.loads((P / 'backend-api-capture-phase2-authorization.json').read_bytes())
    assert config['job_id'] == JOB and config['actual_Godot_create_budget'] == 1
    assert config['independent_static_review_accepted'] is True
    assert config['fresh_native_validate_execution_allowed'] is True
    assert config['execution_authorized'] is True
    assert config['no_replay_or_fallback'] is True
    assert config['candidate'] in config['exact_source_sha256']
    assert __file__.replace('\\', '/').endswith('/' + next(
        name for name in config['exact_source_sha256'] if name.endswith('/run_backend_api_capture_once.py')))
    for filename, expected in config['exact_source_sha256'].items():
        path = (R / filename).resolve()
        path.relative_to(R.resolve())
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, filename
    assert not (R / config['attempt_directory']).exists()
    candidate = (R / config['candidate']).resolve()
    candidate.relative_to((R / '.planning/deepeye-resume-20261018/game3d-backend-api-capture-20261024').resolve())
    assert candidate.is_file()
    assert str(sys.executable).lower().endswith('\\.local\\venv\\scripts\\python.exe')
    argv = [sys.executable, '-B', '-X', 'utf8', str(candidate), '--execute-reviewed', '--attempt', '1']
    write_once('started', {'utc': datetime.now(timezone.utc).isoformat(), 'job_id': JOB,
                          'argv': argv, 'policy_changed': False, 'native_create_budget': 1})
    # Keep the same original Popen owner. A keeper must retain this live exec session.
    # There is deliberately no timeout, taskkill, terminate, PID reopen/adoption or retry.
    with (P / (PREFIX + '-stdout.bin')).open('xb') as out, (P / (PREFIX + '-stderr.bin')).open('xb') as err:
        child = subprocess.Popen(argv, cwd=R, stdout=out, stderr=err, creationflags=0x08000000)
        persistence_errors = []
        try:
            write_once('child', {'utc': datetime.now(timezone.utc).isoformat(), 'pid': child.pid,
                                'ownership': 'original Popen object retained until wait completes'})
        except BaseException as exc:
            persistence_errors.append('child receipt: ' + repr(exc))
        while True:
            try:
                code = child.wait()
                break
            except BaseException as exc:
                # The original owner remains live even if a query/interrupt fails.
                persistence_errors.append('original wait: ' + repr(exc))
    write_once('exit', {'utc': datetime.now(timezone.utc).isoformat(), 'pid': child.pid,
                       'original_Popen_executable_exit': code, 'original_Popen_wait_terminal': True,
                       'persistence_or_wait_errors_before_terminal': persistence_errors,
                       'Godot_exit': 'separate candidate HANDLE evidence; do not infer from Python exit'})
    print(json.dumps({'job_id': JOB, 'Popen_executable_pid': child.pid, 'Popen_executable_exit': code,
                      'native_result': 'read original candidate receipt; no automatic replay'}))
    return 0 if code == 0 else 1

if __name__ == '__main__':
    raise SystemExit(main())
