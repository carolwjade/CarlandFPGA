"""Root decision only after actual independent terminal and fresh lease evidence."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

P = Path(__file__).resolve().parent
R = P.parents[2]
A = P.parent / 'game3d-backend-api-capture-20261024'
V = P.parent / 'game3d-backend-api-capture-review-20261024'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
gate = read(P / 'backend-api-static-terminal-and-author-validation.json')
terminal = json.loads(gate['independent_static_terminal']['content'][0]['text'])[0]
fresh = json.loads(gate['fresh_author_validation']['content'][0]['text'])
assert terminal['job_id'] == 'child-018eab8f8562451ea3ca05a73ba80e23'
assert terminal['status'] == 'completed' and terminal['terminal'] is True and terminal['stale'] is False
assert fresh['job_id'] == 'child-9418116675a744ad9b39a7c4fe7f220a'
assert fresh['native_agent_id'] == '/root/pc_direct_window' and fresh['execution_allowed'] is True
acceptance = gate['root_review_acceptance']
assert acceptance['exact_v2_static_review_accepted'] is True
assert acceptance['F01_source_level_resolved'] is True
assert acceptance['runtime_IO_render_formal_acceptance_claimed'] is False
assert read(P / 'backend-api-capture-v2-root-preflight.json')['engine_bytes_verified'] is True
exact = {}

def add(path, expected):
    path = path.resolve()
    name = path.relative_to(R.resolve()).as_posix()
    assert sha(path) == expected, name
    if name in exact:
        assert exact[name] == expected
    exact[name] = expected

for name, expected in [
    ('phase1-manifest.json', '51b9fbb301326c7b9c96aea9a3469f3f03da1de766c03c025ea7fd115ad156ed'),
    ('v2-manifest.json', '7e1de6096c9ffc64d1c77b84c6cf2bf3e78f064064cb51e62c452432518dd006'),
]:
    add(A / name, expected)
    for row in read(A / name)['members']:
        for field in ['path', 'frozen_path']:
            path = (A / row[field]).resolve()
            assert path.is_relative_to(A.resolve())
            assert path.stat().st_size == row['bytes']
            add(path, row['sha256'])
baseline = read(A / 'source-baseline.json')
for row in baseline['files']:
    for base in [Path(baseline['product']), Path(baseline['snapshot'])]:
        add(base / row['path'], row['sha256'])
for name, expected in baseline['C4'].items():
    add(Path(baseline['product']) / name, expected)
add(Path(baseline['git_index']['path']), baseline['git_index']['sha256'])
for key in ['manifest', 'result', 'report']:
    spec = acceptance[key]
    path = (V / spec['path']).resolve()
    assert path.is_relative_to(V.resolve())
    add(path, spec['sha256'])
final_manifest = read(V / acceptance['manifest']['path'])
assert final_manifest['member_count'] == len(final_manifest['files'])
for name, pin in final_manifest['files'].items():
    path = (V / name).resolve()
    assert path.is_relative_to(V.resolve()) and path.stat().st_size == pin['bytes']
    add(path, pin['sha256'])
plan = read(A / 'execution-plan-v2.json')
add(Path(plan['engine']), plan['engine_sha256'])
add(P / 'run_backend_api_capture_once.py', '845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5')
for name in [
    'backend-api-capture-v2-root-preflight.json', 'preflight_backend_api_capture_v2.py',
    'backend-api-static-terminal-and-author-validation.json',
    'backend-api-capture-root-design-decision.json', 'backend-api-capture-root-design-addendum.json',
    'backend-api-F01-root-source-decision.json', 'authorize_backend_api_capture_phase2.py',
]:
    add(P / name, sha(P / name))
assert not (A / 'attempt-01').exists()
assert not (P / 'backend-api-capture-wrapper-started.json').exists()
decision = {
    'schema': 1, 'utc': datetime.now(timezone.utc).isoformat(),
    'director': '01a16988-bdcb-70e1-ae10-1304b5cf7875', 'generation': 3,
    'job_id': fresh['job_id'], 'actual_Godot_create_budget': 1,
    'candidate': (A / 'launcher_v2.py').relative_to(R).as_posix(),
    'attempt_directory': (A / 'attempt-01').relative_to(R).as_posix(),
    'independent_static_review_accepted': True, 'fresh_native_validate_execution_allowed': True,
    'execution_authorized': True, 'no_replay_or_fallback': True,
    'exact_source_sha256': exact,
    'reason': 'One new original-scene diagnostic with strict API Windows and raw-before-gate record, after F01 fresh READ byte-readback source correction and completed independent static review',
    'constraints': 'Original private noninput HDESK/WinSta0/birth/HANDLE/enum/15s/loss/55s/keeper/terminal controls; no switch/foreground/board/service/policy/product edits or import/fallback',
    'unknown_owner': 'Retain original Popen/native owner and any live exec session; never timeout-kill, replay or adopt by PID',
    'metadata_limit': 'Unchanged _run retains v1 source_pins.json and adapter_variant declaration. These are not v2 self-hashes. Actual v2 identity is external exact source-pins-v2/plan/capture_v2 hashes and runtime owner records.',
    'limits': 'Actual raw tuple/readback/PNG only if observed; same-process byte readback is not independent root readback, native flush success, fsync or future immutability. No no-flash/per-frame/visual/UI/physics/H12/formal acceptance.',
    'old_failed_jobs': 'Sealed/exhausted and unchanged; no replay or retroactive pass',
    'H01_H15_full_H12': 'preserved/open', 'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run',
}
with (P / 'backend-api-capture-phase2-authorization.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(decision, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({'authorized': True, 'job_id': fresh['job_id'], 'maximum_actual_Godot_creates': 1,
                  'exact_byte_pins': len(exact), 'actual_calls_so_far': 0}))
