"""Read-only integrity audit plus exclusive evidence freeze; no target native calls."""
from pathlib import Path
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(name, value):
    p = OUT / name
    assert not p.exists(), str(p)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def inventory(root):
    return [dict(path=p.relative_to(root).as_posix(), bytes=p.stat().st_size, sha256=sha(p))
            for p in sorted(root.rglob("*")) if p.is_file()]


def inventory_digest(rows):
    return hashlib.sha256(json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def read_head(product):
    marker = product / ".git"
    gitdir = (product / marker.read_text(encoding="utf-8").strip().split(": ", 1)[1]).resolve() if marker.is_file() else marker
    head = (gitdir / "HEAD").read_text(encoding="utf-8").strip()
    if not head.startswith("ref: "):
        return head
    ref = head[5:]
    common = (gitdir / (gitdir / "commondir").read_text().strip()).resolve() if (gitdir / "commondir").exists() else gitdir
    for base in (gitdir, common):
        if (base / ref).exists():
            return (base / ref).read_text().strip()
        packed = base / "packed-refs"
        if packed.exists():
            for line in packed.read_text().splitlines():
                if line.endswith(" " + ref):
                    return line.split()[0]
    raise AssertionError("Cannot resolve product HEAD")


baseline = json.loads((OUT / "source-baseline.json").read_bytes())
pins = json.loads((OUT / "source-pins.json").read_bytes())
plan = json.loads((OUT / "execution-plan.json").read_bytes())
product, snapshot = Path(baseline["product"]), Path(baseline["snapshot"])
assert read_head(product) == baseline["product_head"]
for row in baseline["files"]:
    for base in (product, snapshot):
        p = base / row["path"]
        assert p.stat().st_size == row["bytes"] and sha(p) == row["sha256"], str(p)
assert len(baseline["files"]) == 52
assert len(inventory(snapshot)) == 52
for name, expected in baseline["C4"].items():
    assert sha(product / name) == expected, name
assert sha(Path(baseline["git_index"]["path"])) == baseline["git_index"]["sha256"]
original_cache = product / "competition/deepeye/simulator/.godot"
assert inventory(original_cache) == baseline["original_cache"]
assert not (snapshot / "competition/deepeye/simulator/.godot").exists()
old_checks = []
for rootname, before in baseline["old_readonly_directory_inventories"].items():
    after = inventory(Path(rootname))
    assert after == before, rootname
    old_checks.append(dict(path=rootname, members=len(after), unchanged=True, inventory_sha256=inventory_digest(after)))
for item in baseline["source_inputs"]:
    assert sha(Path(item["source"])) == item["sha256"]
    assert sha(OUT / item["snapshot"]) == item["sha256"]
G = OUT.parent / "gen3-live-integration-20261024"
assert sha(G / "backend-api-capture-root-design-addendum.json") == sha(OUT / "inputs/root-addendum.json")
assert sha(G / "run_backend_api_capture_once.py") == sha(OUT / "inputs/root-wrapper.py") == "845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5"
assert sha(Path(plan["engine"])) == plan["engine_sha256"]
assert sha(OUT / "launcher.py") == plan["launcher_sha256"] == pins["launcher_sha256"]
assert sha(OUT / "capture.gd") == plan["adapter_sha256"] == pins["capture_sha256"]
assert sha(OUT / "source-pins.json") == plan["source_pins_sha256"]
assert not (OUT / "attempt-01").exists()
scope_path = ROOT / "docs/competition/deepeye-2026/immutable_scope.json"
scope = json.loads(scope_path.read_bytes())
scope_hash = hashlib.sha256(json.dumps(scope["requirements"], ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
assert scope_hash == pins["requirements_sha256"] == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
integrity = dict(schema=1, phase="phase1_source_only", product_head=read_head(product),
                 product_and_fresh_snapshot_52_each_unchanged=True,
                 source_pin_checks=104, C4_unchanged=True, index_unchanged=True,
                 original_cache_unchanged=True, original_cache_members=len(baseline["original_cache"]),
                 snapshot_has_only_52_source_files=True, snapshot_project_cache_exists=False,
                 old_readonly_directory_checks=old_checks,
                 old_ff69_runtime_cache_unchanged_by_full_inventory=True,
                 original_decision_addendum_wrapper_unchanged=True, engine_binary_hash_unchanged=True,
                 requirements_canonical_sha256=scope_hash, target_native_calls=0, actual_Godot_creates=0,
                 actual_backend_tuple=None, actual_Godot_exit=None, runtime_IO_success=None,
                 phase2_execution_authorized=False, attempt_01_absent=True)
put("phase1-integrity.json", integrity)
put("phase1-result.json", dict(schema=1, job_id=baseline["job_id"], work_id=baseline["work_id"],
                              outcome="source_candidate_frozen_await_independent_review_and_root_phase2",
                              job_active=True, native_complete_called=False, target_native_calls=0, actual_Godot_creates=0,
                              source_RED="old adapter and parent literal differ from exact primary Windows; tool exit1 preserved",
                              source_GREEN="primary tuple, getter count, record ordering and exact AST/diff boundaries checked; exit0",
                              GDScript_parse_or_runtime=None, actual_backend_tuple=None,
                              phase2_execution_authorized=False, maximum_later_actual_Godot_creates=1,
                              old_failures_and_exhausted_budgets="immutable; no retroactive pass",
                              H01_H15_full_H12="preserved/open", G03="not_run", R03="not_run", all29="not_run"))
report = """# Backend API capture: phase 1 source candidate

Job `child-9418116675a744ad9b39a7c4fe7f220a` is active at the review boundary. **0 target native/engine calls, 0 Godot creates.** No phase-2 authorization or native_complete. Product head `5d7a943094b3309254639aaace68f157246d2e89` and the fresh snapshot each match all 52 game/dependency pins, source-only equivalent to 360b102b. C4, index, original cache and the old ff/71958/029d/bfcc directory inventories are unchanged. The engine binary was hashed only.

The exact primary Godot commit `ed1daf0bf001b61586d9930840f2f1394092c079` distinguishes API `Windows` from CLI `windows`. The strict API tuple is `Windows/vulkan/forward_plus`; CLI remains `windows/vulkan/forward_plus`. The 34-member bfcc research manifest was verified. This does not fill the old actual API tuple, which remains null.

`capture.gd` reads the three actual Strings once, brackets only those calls with this Godot process's labelled microsecond ticks, and records raw/expected/per-field matches, PID and declared job/run/source identity into the exclusive attempt's `frames/backend-observation.json`. Store bool/error/UTF-8 byte position and flush error must pass before backend admission and scene load. An existing record or recording error fails closed; partial bytes are retained, without retry. API flush/returned close are not OS fsync, crash durability or independent readback. Runtime IO status is unknown in this phase. Clock uncertainty, cross-process mapping and frame native timestamps stay null.

The separately bound root addendum authorizes two disclosed exceptions: the parent `validate_capture_outputs` API expectation changes `windows` to `Windows`; final report backend fields reuse the pre-predicate raw Strings with an explicit file/process-clock reference. Those values do not claim fresh-final or per-frame observation. All remaining Python functions/classes, including journal complete-count, owned-HDESK/WinSta0/noninput/birth/stdio/HANDLE, enum association, both 15s checks, lost-Engine rejection, 55s stop, keeper and terminal-close, have identical normalized AST. Original adapter helpers are byte-equal; the complete scene/geometry/UI/30-object/16-view suffix is byte-equal after restoring only the approved final-report replacement. Complete diffs and per-function AST hashes disclose these boundaries; the parent validator is not claimed unchanged.

The independent source-contract RED found both old lowercase API oracles (exit1 preserved). The new source GREEN checks exact primary tuple, single getter calls, record-before-gate-before-load order, CLI preservation and the complete authorized diff/AST boundaries. It does not import/run the candidate, parse GDScript, emulate FileAccess, run old controls or prove render behavior. New authored files were checked for one final LF and no trailing whitespace; diff context markers and original byte snapshots are explicitly exempt.

The exact execution plan/argv retain only one possible later native create, complete original `res://viewer/main.tscn` in its root Window, original windows/vulkan/forward_plus, no fallback/import, 16 target views and original time limits. Root's new wrapper is a byte-pinned source reference only. A completed independent review, fresh allowed lease validation and separate exact root authorization are required before any run. An unknown child/creator must retain the original owner/session; 60s is an attempt budget, not a hard driver-stop promise.

Old71958 remains failed with two creates/0PNG; oldff remains failed with one create/0PNG and no main-scene load. This source correction repairs neither old result. No native/render/no-flash/visual-quality, complete G01/G02, physics/DPI or H12 proof is claimed. H01-H15/full H12 are preserved/open; `G03/R03/all29=not_run`.

Exact hashes are in source-pins.json, execution-plan.json, argv.json and phase1-manifest.json. Primary links and API limitations are in primary-api-notes.md. Await root's review decision; do not execute this candidate from the phase-1 record.
"""
report_path = OUT / "phase1-report.md"
assert not report_path.exists()
report_path.write_text(report, encoding="utf-8", newline="\n")
# Original byte snapshots and raw browser/tool receipts are not normalized.
exempt = {"source-contract-red-tool-result.json", "make-plan-tool-result.json", "primary-api-browse.txt"}
whitespace = []
for p in sorted(OUT.rglob("*")):
    if not p.is_file() or p.name == "lease.private.json" or "inputs" in p.relative_to(OUT).parts:
        continue
    if p.name in exempt:
        continue
    data = p.read_bytes()
    assert data.endswith(b"\n") and not data.endswith(b"\n\n"), str(p)
    for number, line in enumerate(data.splitlines(), 1):
        if p.suffix == ".diff" and line == b" ":
            continue  # Unified-diff context marker, not authored source whitespace.
        assert not re.search(rb"[\t ]+$", line), (str(p), number)
    whitespace.append(p.relative_to(OUT).as_posix())
put("phase1-whitespace.json", dict(schema=1, checked=whitespace, exactly_one_final_LF=True,
                                  no_trailing_whitespace=True, source_and_new_untracked_files_included=True,
                                  exemptions="inputs byte snapshots/raw receipts; unified-diff empty context marker"))
members = [p for p in sorted(OUT.rglob("*")) if p.is_file() and p.name != "lease.private.json"]
frozen = OUT / "frozen-phase1"
assert not frozen.exists()
frozen.mkdir()
rows = []
for p in members:
    relative = p.relative_to(OUT)
    target = frozen / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(p.read_bytes())
    assert sha(target) == sha(p)
    rows.append(dict(path=relative.as_posix(), bytes=p.stat().st_size, sha256=sha(p), frozen_path=target.relative_to(OUT).as_posix()))
put("phase1-manifest.json", dict(schema=1, root=str(OUT), frozen_root=str(frozen),
                                job_id=baseline["job_id"], phase="source_only_await_review",
                                members=rows, count=len(rows), total_bytes=sum(r["bytes"] for r in rows),
                                excludes=["lease.private.json", "phase1-manifest.json"],
                                snapshot52="external fresh source-only tree; exact paths and hashes in source-pins.json",
                                target_native_calls=0, actual_Godot_creates=0, native_complete_called=False))
for row in rows:
    assert sha(OUT / row["path"]) == row["sha256"] == sha(OUT / row["frozen_path"])
print(json.dumps(dict(count=len(rows), exactpins={name:sha(OUT / name) for name in
                 ("launcher.py", "capture.gd", "source-pins.json", "execution-plan.json", "argv.json", "launcher.diff", "capture.diff", "phase1-report.md", "phase1-manifest.json")}), indent=2))
