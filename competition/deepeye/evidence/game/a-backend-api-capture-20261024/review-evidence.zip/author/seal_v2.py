"""F01-only evidence freeze. Hashes/files only, no candidate import or target call."""
from pathlib import Path
import ast
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(name, value):
    path = OUT / name
    assert not path.exists(), str(path)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")


def inventory(root):
    return [dict(path=p.relative_to(root).as_posix(), bytes=p.stat().st_size, sha256=sha(p))
            for p in sorted(root.rglob("*")) if p.is_file()]


original_manifest_hash = "51b9fbb301326c7b9c96aea9a3469f3f03da1de766c03c025ea7fd115ad156ed"
assert sha(OUT / "phase1-manifest.json") == original_manifest_hash
v1 = json.loads((OUT / "phase1-manifest.json").read_bytes())
assert len(v1["members"]) == 35
for row in v1["members"]:
    assert sha(OUT / row["path"]) == row["sha256"] == sha(OUT / row["frozen_path"])
baseline = json.loads((OUT / "source-baseline.json").read_bytes())
product, snapshot = Path(baseline["product"]), Path(baseline["snapshot"])
for row in baseline["files"]:
    for base in (product, snapshot):
        assert (base / row["path"]).stat().st_size == row["bytes"]
        assert sha(base / row["path"]) == row["sha256"]
assert len(inventory(snapshot)) == 52
for name, expected in baseline["C4"].items():
    assert sha(product / name) == expected
assert sha(Path(baseline["git_index"]["path"])) == baseline["git_index"]["sha256"]
assert inventory(product / "competition/deepeye/simulator/.godot") == baseline["original_cache"]
assert not (snapshot / "competition/deepeye/simulator/.godot").exists()
old_counts = {}
for rootname, before in baseline["old_readonly_directory_inventories"].items():
    assert inventory(Path(rootname)) == before
    old_counts[rootname] = len(before)
plan = json.loads((OUT / "execution-plan-v2.json").read_bytes())
assert sha(OUT / "launcher_v2.py") == plan["launcher_sha256"]
assert sha(OUT / "capture_v2.gd") == plan["adapter_sha256"]
assert sha(OUT / "source-pins-v2.json") == plan["source_pins_sha256"]
assert sha(Path(plan["engine"])) == plan["engine_sha256"]
G = OUT.parent / "gen3-live-integration-20261024"
assert sha(G / "run_backend_api_capture_once.py") == "845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5"
assert sha(G / "backend-api-F01-root-source-decision.json") == sha(OUT / "f01-research/root-source-decision.json") == "ab994b7396f758d624949ab2886cd6b5c2d63e1ff83d46b19ba5b4944b82155b"
for row in json.loads((OUT / "f01-research/primary-source-pins.json").read_bytes())["files"]:
    assert sha(OUT / "f01-research" / row["path"]) == row["sha256"]
assert not (OUT / "attempt-01").exists()
scope = json.loads((ROOT / "docs/competition/deepeye-2026/immutable_scope.json").read_bytes())
contract = hashlib.sha256(json.dumps(scope["requirements"], ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
assert contract == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
old_py = (OUT / "launcher.py").read_text(encoding="utf-8")
new_py = (OUT / "launcher_v2.py").read_text(encoding="utf-8")
assert new_py == old_py.replace('PLAN = OUT / "execution-plan.json"', 'PLAN = OUT / "execution-plan-v2.json"', 1)
ast.parse(new_py)  # Pure source syntax only. No import or native API construction.
old_gd = (OUT / "capture.gd").read_text(encoding="utf-8")
new_gd = (OUT / "capture_v2.gd").read_text(encoding="utf-8")
assert new_gd[new_gd.index("func _run()"): ] == old_gd[old_gd.index("func _run()"): ]
assert new_gd[:new_gd.index("func _record_backend_observation")] == old_gd[:old_gd.index("func _record_backend_observation")]
put("v2-integrity.json", dict(schema=1, original35_active_and_frozen_unchanged=True,
                             original_manifest_sha256=original_manifest_hash,
                             original_manifest_unchanged=True, product_snapshot52_each_unchanged=True,
                             C4_index_original_cache_unchanged=True, old_readonly_roots_and_member_counts=old_counts,
                             old69cache_unchanged_by_full_inventory=True, root_wrapper845_unchanged=True,
                             root_source_decision_sha256=sha(OUT / "f01-research/root-source-decision.json"),
                             five_primary_raw_sources_rehashed=True, requirements_canonical_sha256=contract,
                             attempt01_absent=True, target_native_calls=0, actual_Godot_creates=0))
put("v2-result.json", dict(schema=1, job_id=baseline["job_id"], job_active=True,
                          outcome="F01_source_only_v2_frozen_await_independent_review_and_root_phase2",
                          original_candidate="blocked/preserved, never executed", source_RED_exit=1, source_GREEN_exit=0,
                          source_checks="only new F01 primary-contract/delta; not native fault injection",
                          same_process_filesystem_visible_readback=None, actual_fflush_result=None,
                          actual_fclose_result=None, independent_root_readback=None, fsync=None,
                          actual_backend_tuple=None, GDScript_parse_or_run=False, native_complete_called=False,
                          target_native_calls=0, actual_Godot_creates=0, phase2_authorized=False,
                          later_maximum_Godot_creates_after_separate_review_and_root_decision=1,
                          H01_H15_full_H12="preserved/open", G03="not_run", R03="not_run", all29="not_run"))
report = """# F01 source-only v2

The original 35 active/frozen members and manifest are byte-unchanged and remain blocked by F01. Job9418 stays active. No target Win32/desktop/window/engine call, candidate import, GDScript parse/run, old control or native_complete occurred; no attempt directory exists.

Exact primary commit ed1daf0bf001b61586d9930840f2f1394092c079 confirms that Windows flush does not expose fflush's return through cached get_error, and close ignores fclose's return. The original source GREEN did not prove filesystem visibility. F01 research, five full official source bytes/pins and exact raw-file line spans are preserved separately; web-extracted line offsets differ from raw lines.

Root decision ab994b7396f758d624949ab2886cd6b5c2d63e1ff83d46b19ba5b4944b82155b authorizes this minimal delta. capture_v2.gd changes only the backend-record I/O helper: retain writer open/store bool/error/byte-position, flush and close calls; label post-flush error as cached; keep native fflush/fclose results unknown. After writer close, open a new READ object at the same path, require exact payload length and initial cursor zero, perform one bounded get_buffer, immediately capture its error, and require exact length, complete byte equality, OK and expected end cursor. Close each obtained reader on all normal branch paths. Failure returns false before the original strict backend gate and scene load; partial files remain without retry/truncation. No payload serialization or backend metadata is rewritten.

This can establish only same-process filesystem-visible readback of that finite payload, when actually executed and observed. It does not establish an independent process/root readback, physical-media/crash durability, successful native flush/close return, or future immutability. Those results remain null. No readback was performed in phase1. The script-facing wrapper shrinks short reads; Windows read samples ferror/feof; PackedByteArray equality checks all bytes. Length/cached error alone are insufficient, since get_length does not check every seek result.

launcher_v2.py changes only its PLAN filename. Every Python function/class AST is equal to v1. capture_v2's prefix and complete _run suffix are byte-equal to v1: raw getters once, labelled clock/declarations, strict Windows/vulkan/forward_plus API, lowercase windows CLI, final-report provenance, original main/root Window/camera/UI/30objects/16views remain unchanged. All journal/HDESK/HANDLE/enum/loss/15s/55s/keeper/terminal paths remain unchanged; no teardown-loss exception. Root wrapper845 is unchanged and unexecuted. New plan/pins/argv bind v2 only; later execution still needs independent review, fresh allowed validation and separate root authorization, maximum one create, no import/fallback/retry.

The focused source RED (exit1) records the logical witness: store/position/cached OK can pass while late flush/close failures leave a short visible file. It is not an actual filesystem fault test. Source GREEN (exit0) checks new readback source ordering/conditions and complete delta boundaries. It does not prove runtime I/O or rendering. Complete diffs and all raw intermediate evidence are preserved.

Original/snapshot 52 files each, C4, index, original cache, old ff/71958/029d/bfcc directories and old69 GPUcache are unchanged. New authored/untracked source/JSON/report files have exactly one final LF and no trailing whitespace; official raw source and original byte snapshots are not normalized, diff empty-context markers are syntax. Old failed jobs/budgets are untouched. H01-H15/full H12 remain preserved/open; G03/R03/all29=not_run. No native/render/no-flash/visual quality/formal G01/G02/H12 acceptance is claimed.

Exact hashes: source-pins-v2.json, execution-plan-v2.json, argv-v2.json and v2-manifest.json. This delta is frozen for root/independent static review; execution is not authorized.
"""
path = OUT / "v2-report.md"
assert not path.exists()
path.write_text(report, encoding="utf-8", newline="\n")
original_names = {row["path"] for row in v1["members"]}
members = [p for p in sorted(OUT.rglob("*")) if p.is_file()
           and p.relative_to(OUT).parts[0] != "frozen-phase1"
           and p.relative_to(OUT).as_posix() not in original_names
           and p.name not in ("phase1-manifest.json", "lease.private.json")]
whitespace = []
for p in members:
    relative = p.relative_to(OUT).as_posix()
    if relative.startswith("f01-research/primary/") or relative == "f01-research/root-source-decision.json":
        continue
    data = p.read_bytes()
    assert data.endswith(b"\n") and not data.endswith(b"\n\n"), relative
    for number, line in enumerate(data.splitlines(), 1):
        if p.suffix == ".diff" and line == b" ":
            continue
        assert not re.search(rb"[\t ]+$", line), (relative, number)
    whitespace.append(relative)
put("v2-whitespace.json", dict(schema=1, checked=whitespace, exactly_one_final_LF=True,
                              no_trailing_whitespace=True, includes_new_untracked_source=True,
                              exempt="official primary bytes/root-decision snapshot; diff empty context syntax"))
members.append(OUT / "v2-whitespace.json")
frozen = OUT / "frozen-v2"
assert not frozen.exists()
frozen.mkdir()
rows = []
for p in sorted(members):
    relative = p.relative_to(OUT)
    target = frozen / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(p.read_bytes())
    assert sha(target) == sha(p)
    rows.append(dict(path=relative.as_posix(), bytes=p.stat().st_size, sha256=sha(p), frozen_path=target.relative_to(OUT).as_posix()))
put("v2-manifest.json", dict(schema=1, root=str(OUT), frozen_root=str(frozen), job_id=baseline["job_id"],
                            phase="F01_source_only_await_review", preserved_original_manifest_sha256=original_manifest_hash,
                            members=rows, count=len(rows), total_bytes=sum(r["bytes"] for r in rows),
                            excludes=["lease.private.json", "original35/frozen-phase1", "phase1-manifest.json", "v2-manifest.json"],
                            target_native_calls=0, actual_Godot_creates=0, native_complete_called=False))
for row in rows:
    assert sha(OUT / row["path"]) == row["sha256"] == sha(OUT / row["frozen_path"])
for row in v1["members"]:
    assert sha(OUT / row["path"]) == row["sha256"] == sha(OUT / row["frozen_path"])
assert sha(OUT / "phase1-manifest.json") == original_manifest_hash
print(json.dumps(dict(count=len(rows), exactpins={n:sha(OUT / n) for n in
                 ("launcher_v2.py", "capture_v2.gd", "source-pins-v2.json", "execution-plan-v2.json", "argv-v2.json", "capture-v2.diff", "launcher-v2.diff", "v2-report.md", "v2-manifest.json")}), indent=2))
