# Phase 1 source boundary

Job child-9418116675a744ad9b39a7c4fe7f220a. Bind root-decision.json and the separately approved root-addendum.json.

1. Preserve the independent primary-source RED, original 6210469 adapter and 61c6de6 launcher.
2. Derive the new adapter: read the three actual API Strings once, record their raw values and comparisons before admission, fail closed on recording error, and require Windows/vulkan/forward_plus. Reuse the same values in the final report with historical provenance.
3. Derive the launcher with only new job/paths/plan and the approved parent-validator Windows literal correction. Preserve all native proof, journal, lifecycle and deadline functions.
4. Check exact source contracts and normalized Python AST boundaries without importing or running the candidate. Compare all 52 original/snapshot files and protected inventories.
5. Freeze source, complete diffs, argv, plan, pins and evidence. Stop for independent review with the job active. No target native/engine call or native_complete in this phase.

FileAccess store/flush results are source-defined API facts, not execution evidence or OS fsync. No GDScript parse/run has been authorized. The old actual tuple remains null; old failures and exhausted budgets are immutable. H01-H15/full H12 remain open; G03/R03/all29 are not_run.
