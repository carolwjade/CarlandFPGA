"""F01 source-only delta derivation. Does not import candidate or call target APIs."""
from pathlib import Path
import difflib
import hashlib
import json

OUT = Path(__file__).resolve().parent
F01 = OUT / "f01-research"
G = OUT.parent / "gen3-live-integration-20261024"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(name, text):
    p = OUT / name
    assert not p.exists(), str(p)
    p.write_text(text, encoding="utf-8", newline="\n")


assert sha(OUT / "phase1-manifest.json") == "51b9fbb301326c7b9c96aea9a3469f3f03da1de766c03c025ea7fd115ad156ed"
manifest = json.loads((OUT / "phase1-manifest.json").read_bytes())
assert len(manifest["members"]) == 35
for row in manifest["members"]:
    assert sha(OUT / row["path"]) == row["sha256"] == sha(OUT / row["frozen_path"])
decision = G / "backend-api-F01-root-source-decision.json"
assert sha(decision) == "ab994b7396f758d624949ab2886cd6b5c2d63e1ff83d46b19ba5b4944b82155b"
assert not (F01 / "root-source-decision.json").exists()
(F01 / "root-source-decision.json").write_bytes(decision.read_bytes())
old_py = (OUT / "launcher.py").read_text(encoding="utf-8")
assert old_py.count('PLAN = OUT / "execution-plan.json"') == 1
new_py = old_py.replace('PLAN = OUT / "execution-plan.json"', 'PLAN = OUT / "execution-plan-v2.json"', 1)
put("launcher_v2.py", new_py)
put("launcher-v2.diff", "".join(difflib.unified_diff(old_py.splitlines(keepends=True), new_py.splitlines(keepends=True), fromfile="frozen-phase1/launcher.py", tofile="F01/launcher_v2.py")))
old = (OUT / "capture.gd").read_text(encoding="utf-8")
new = old
io_before = '''		"flush_error":null, "flush_return_type":"void", "close_return_type":"void",
		"close_returned":false, "os_fsync":null, "independent_readback":null}
'''
io_after = '''		"flush_error":null, "flush_return_type":"void", "close_return_type":"void",
		"flush_error_semantics":"cached get_error observation; not the fflush return",
		"flush_actual_result":null, "close_actual_result":null,
		"close_returned":false, "os_fsync":null, "independent_root_readback":null,
		"readback_scope":"same-process filesystem-visible bytes before scene load",
		"read_open_error":null, "read_length":null, "read_length_error":null,
		"read_start_position":null, "read_bytes":null, "read_bytes_equal":null,
		"read_error":null, "read_end_position":null, "reader_close_returned":false,
		"reader_close_actual_result":null, "same_process_filesystem_visible_readback":null}
'''
assert new.count(io_before) == 1
new = new.replace(io_before, io_after, 1)
old_end = '''	print("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
	return flush_error == OK
'''
new_end = '''	if flush_error != OK:
		printerr("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
		return false
	var read_file := FileAccess.open(path, FileAccess.READ)
	var read_open_error := FileAccess.get_open_error()
	io["read_open_error"] = read_open_error
	if read_file == null or read_open_error != OK:
		if read_file != null:
			read_file.close()
			io["reader_close_returned"] = true
		printerr("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
		return false
	var read_length := read_file.get_length()
	var read_length_error := read_file.get_error()
	var read_start_position := read_file.get_position()
	io["read_length"] = read_length
	io["read_length_error"] = read_length_error
	io["read_start_position"] = read_start_position
	if read_length != payload.size() or read_start_position != 0 or read_length_error != OK:
		read_file.close()
		io["reader_close_returned"] = true
		printerr("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
		return false
	var read_payload := read_file.get_buffer(payload.size())
	var read_error := read_file.get_error()
	var read_end_position := read_file.get_position()
	io["read_bytes"] = read_payload.size()
	io["read_bytes_equal"] = read_payload == payload
	io["read_error"] = read_error
	io["read_end_position"] = read_end_position
	read_file.close()
	io["reader_close_returned"] = true
	var read_ok := read_payload.size() == payload.size() and read_payload == payload and read_error == OK and read_end_position == payload.size()
	io["same_process_filesystem_visible_readback"] = read_ok
	print("PRIVATE_BACKEND_RECORD_IO " + JSON.stringify(io))
	return read_ok
'''
assert new.count(old_end) == 1
new = new.replace(old_end, new_end, 1)
put("capture_v2.gd", new)
put("capture-v2.diff", "".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), fromfile="frozen-phase1/capture.gd", tofile="F01/capture_v2.gd")))
# Record precise raw-file line spans, without relying on web text line offsets.
spans = []
for file, prefixes in (
    ("drivers/windows/file_access_windows.cpp", ["void FileAccessWindows::check_errors(", "void FileAccessWindows::_close()", "uint64_t FileAccessWindows::get_position()", "uint64_t FileAccessWindows::get_length()", "uint64_t FileAccessWindows::get_buffer(", "Error FileAccessWindows::get_error()", "void FileAccessWindows::flush()"]),
    ("core/io/file_access.cpp", ["Ref<FileAccess> FileAccess::open(", "Vector<uint8_t> FileAccess::get_buffer(int64_t"]),
):
    content = (F01 / "primary" / file).read_text(encoding="utf-8")
    for prefix in prefixes:
        start = content.index(prefix)
        end = content.index("\n}", start) + 2
        spans.append(dict(source=file, prefix=prefix, first_line=content[:start].count("\n")+1,
                          last_line=content[:end].count("\n")+1))
(F01 / "raw-source-line-spans.json").write_text(json.dumps(dict(primary_commit="ed1daf0bf001b61586d9930840f2f1394092c079", spans=spans), indent=2)+"\n", encoding="utf-8", newline="\n")
print(json.dumps({name:sha(OUT / name) for name in ("capture_v2.gd", "launcher_v2.py", "capture-v2.diff", "launcher-v2.diff")}, indent=2))
