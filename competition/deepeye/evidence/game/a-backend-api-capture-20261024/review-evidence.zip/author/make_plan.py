"""Prepare only pinned JSON/argv records; never imports candidate or calls engine."""
from pathlib import Path
import ast
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
G = OUT.parent / "gen3-live-integration-20261024"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(name, value):
    p = OUT / name
    assert not p.exists(), str(p)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


baseline = json.loads((OUT / "source-baseline.json").read_bytes())
wrapper = G / "run_backend_api_capture_once.py"
assert sha(wrapper) == "845a46b9def410bb9fb1b4ff8e2cd7b1bcdd1a5c5707f6dd3a1f20fafaf0c0e5"
assert not (OUT / "inputs/root-wrapper.py").exists()
(OUT / "inputs/root-wrapper.py").write_bytes(wrapper.read_bytes())
pins = dict(schema=1, product=baseline["product"], snapshot=baseline["snapshot"],
            files=baseline["files"], product_head=baseline["product_head"],
            published_game_head=baseline["published_game_head_source_only_equivalence"],
            requirements_sha256=baseline["requirements_sha256"],
            job_id=baseline["job_id"], work_id=baseline["work_id"],
            association_method="enum_desktop_windows_callback_v1",
            old_launcher_sha256=sha(OUT / "inputs/launcher_v2.py"),
            old_capture_sha256=sha(OUT / "inputs/capture_621.gd"),
            launcher_sha256=sha(OUT / "launcher.py"), capture_sha256=sha(OUT / "capture.gd"),
            root_decision_sha256=sha(OUT / "inputs/root-decision.json"),
            root_addendum_sha256=sha(OUT / "inputs/root-addendum.json"),
            primary_commit="ed1daf0bf001b61586d9930840f2f1394092c079",
            primary_research_manifest_sha256=sha(OUT / "inputs/research-artifact-manifest.json"),
            root_wrapper_reference=dict(path=str(wrapper), sha256=sha(wrapper), executed=False),
            source_baseline_sha256=sha(OUT / "source-baseline.json"),
            strict_API_tuple=["Windows", "vulkan", "forward_plus"],
            strict_CLI_tuple=["windows", "vulkan", "forward_plus"],
            narrowly_changed_parent_validator=True,
            final_report_backend_values="same pre-predicate Strings, historical provenance; no final/per-frame freshness",
            phase1_target_native_calls=0, phase1_actual_Godot_creates=0)
put("source-pins.json", pins)
old_plan_path = OUT.parent / "game3d-enum-association-capture-20261024/execution-plan-v2.json"
old_plan = json.loads(old_plan_path.read_bytes())
assert not (OUT / "inputs/original-execution-plan-v2.json").exists()
(OUT / "inputs/original-execution-plan-v2.json").write_bytes(old_plan_path.read_bytes())
plan = dict(old_plan)
plan.update(work_id=baseline["work_id"], job_id=baseline["job_id"],
            run_id="94181166-first-and-only-native-run",
            phase="phase1_backend_API_record_await_independent_review_and_root_phase2",
            project=str(Path(baseline["snapshot"]) / "competition/deepeye/simulator"),
            adapter=str(OUT / "capture.gd"), adapter_sha256=sha(OUT / "capture.gd"),
            launcher_sha256=sha(OUT / "launcher.py"), source_pins=str(OUT / "source-pins.json"),
            source_pins_sha256=sha(OUT / "source-pins.json"),
            desktop_name="DeepEye_94181166_729c0c33922d42868f24ee21eaad0690",
            frame_capture_clock="frame native timestamps still unknown; new backend-only process ticks do not timestamp frames",
            backend_observation="frames/backend-observation.json; actual Strings once before backend admission; FileAccess flush is not OS fsync",
            strict_API_tuple=["Windows", "vulkan", "forward_plus"],
            strict_CLI_tuple=["windows", "vulkan", "forward_plus"],
            root_decision_sha256=pins["root_decision_sha256"],
            root_addendum_sha256=pins["root_addendum_sha256"], phase2_execution_authorized=False)
assert sha(Path(plan["engine"])) == plan["engine_sha256"]
put("execution-plan.json", plan)
# Read the existing return-list AST, substitute only plan lookups. No eval/import.
tree = ast.parse((OUT / "launcher.py").read_text(encoding="utf-8"))
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "render_argv")
values = fn.body[0].value.elts
render_plan = dict(plan, frames=str(OUT / "attempt-01/frames"))
argv = []
for node in values:
    if isinstance(node, ast.Constant):
        argv.append(node.value)
    else:
        assert isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name) and node.value.id == "plan"
        argv.append(render_plan[ast.literal_eval(node.slice)])
put("argv.json", dict(schema=1, executed=False, engine_argv=argv,
                      engine_cwd=plan["project"],
                      launcher_argv=[str(ROOT / ".local/venv/Scripts/python.exe"), "-B", "-X", "utf8", str(OUT / "launcher.py"), "--execute-reviewed", "--attempt", "1"],
                      phase2_requires="separate exact root authorization, completed independent review and fresh allowed lease validation",
                      actual_Godot_create_budget_later=1, optional_import=False,
                      outer_killing_timeout_forbidden=True, plan_sha256=sha(OUT / "execution-plan.json")))
put("plan-delta.json", dict(schema=1, old_plan_sha256=sha(old_plan_path),
                           new_plan_sha256=sha(OUT / "execution-plan.json"),
                           changed={k:dict(old=old_plan.get(k),new=plan[k]) for k in plan if old_plan.get(k) != plan[k]},
                           unchanged={k:plan[k] for k in plan if k in old_plan and old_plan[k] == plan[k]}))
print(json.dumps({name:sha(OUT / name) for name in ("launcher.py", "capture.gd", "source-pins.json", "execution-plan.json", "argv.json")}, indent=2))
