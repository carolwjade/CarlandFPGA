"""Collect exact official source bytes only; no target native/engine/test call."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
from urllib.request import urlopen

OUT = Path(__file__).resolve().parent
COMMIT = "ed1daf0bf001b61586d9930840f2f1394092c079"
FILES = ["drivers/windows/file_access_windows.cpp", "core/io/file_access.cpp",
         "core/io/file_access.h", "doc/classes/FileAccess.xml", "doc/classes/PackedByteArray.xml"]


def collect(name):
    url = "https://raw.githubusercontent.com/godotengine/godot/" + COMMIT + "/" + name
    with urlopen(url, timeout=20) as response:
        status = response.status
        data = response.read()
    assert status == 200
    target = OUT / "primary" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(data)
    return dict(path=target.relative_to(OUT).as_posix(), source_path=name, url=url,
                http_status=status, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


with ThreadPoolExecutor(max_workers=5) as executor:
    rows = list(executor.map(collect, FILES))
with (OUT / "primary-source-pins.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(dict(schema=1, primary_commit=COMMIT, files=rows, target_native_calls=0,
                   actual_Godot_creates=0, candidate_or_v2_generated=False), stream, indent=2)
    stream.write("\n")
print(json.dumps(rows, indent=2))
