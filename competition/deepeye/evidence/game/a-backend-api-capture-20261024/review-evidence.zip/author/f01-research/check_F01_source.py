"""F01 source counterexample/boundary check; never imports or runs a candidate."""
from pathlib import Path
import hashlib
import json
import sys

OUT = Path(__file__).resolve().parent
PARENT = OUT.parent
mode = sys.argv[1]
assert mode in ("red", "green")


def text(path):
    return path.read_text(encoding="utf-8")


def body(source, prefix):
    start = source.index(prefix)
    # Source-level extraction of the complete next top-level C++ function.
    end = source.index("\n}", start) + 2
    return source[start:end]


win = text(OUT / "primary/drivers/windows/file_access_windows.cpp")
core = text(OUT / "primary/core/io/file_access.cpp")
flush = body(win, "void FileAccessWindows::flush()")
close = body(win, "void FileAccessWindows::_close()")
error = body(win, "Error FileAccessWindows::get_error()")
read = body(win, "uint64_t FileAccessWindows::get_buffer(")
wrapper = body(core, "Vector<uint8_t> FileAccess::get_buffer(int64_t")
assert "fflush(f);" in flush and "last_error" not in flush and "check_errors" not in flush
assert "fclose(f);" in close and "last_error" not in close and "check_errors" not in close
assert "return last_error;" in error
assert read.index("fread(") < read.index("check_errors();") < read.index("return read;")
assert "data.resize(len);" in wrapper and "len < p_length" in wrapper
source_path = PARENT / ("capture.gd" if mode == "red" else "capture_v2.gd")
source = text(source_path)
helper = source[source.index("func _record_backend_observation"):source.index("func _run()")]
fresh_read = "FileAccess.open(path, FileAccess.READ)" in helper
result = dict(schema=1, mode=mode, kind="source_contract_not_native_fault_injection",
              primary_commit="ed1daf0bf001b61586d9930840f2f1394092c079",
              source=str(source_path), source_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest(),
              Windows_flush_ignores_return_and_cached_error_unchanged=True,
              Windows_close_ignores_return=True, fresh_READ_object_after_writer_close=fresh_read,
              logical_counterexample=dict(actual_execution=False, store_return=True,
                                          buffered_position="expected payload size", cached_get_error="OK",
                                          native_fflush_return="failure, not exposed", native_fclose_return="failure, not exposed",
                                          filesystem_visible_bytes="short prefix", v1_final_expression_accepts=True),
              target_native_calls=0, actual_Godot_creates=0, GDScript_parse_or_run=False)
if mode == "red":
    assert "return flush_error == OK" in helper
    result["expected_red"] = not fresh_read
else:
    assert fresh_read
    fresh = helper.index("FileAccess.open(path, FileAccess.READ)")
    assert helper.index("file.close()", helper.index("file.flush()")) < fresh
    assert "if flush_error != OK:" in helper[:fresh]
    assert "read_length != payload.size() or read_start_position != 0 or read_length_error != OK" in helper
    assert helper.count("read_file.get_buffer(payload.size())") == 1
    assert "var read_payload := read_file.get_buffer(payload.size())\n\tvar read_error := read_file.get_error()" in helper
    assert "read_payload.size() == payload.size() and read_payload == payload" in helper
    assert "read_error == OK and read_end_position == payload.size()" in helper
    assert helper.index("read_file.close()", helper.index("var read_payload :=")) < helper.index("return read_ok")
    assert '"flush_actual_result":null' in helper and '"close_actual_result":null' in helper
    assert '"independent_root_readback":null' in helper and '"os_fsync":null' in helper
    old = text(PARENT / "capture.gd")
    assert source[source.index("func _run()"): ] == old[old.index("func _run()"): ]
    assert source[:source.index("func _record_backend_observation")] == old[:old.index("func _record_backend_observation")]
    old_py = text(PARENT / "launcher.py")
    new_py = text(PARENT / "launcher_v2.py")
    expected = old_py.replace('PLAN = OUT / "execution-plan.json"', 'PLAN = OUT / "execution-plan-v2.json"', 1)
    assert new_py == expected
    result.update(complete_adapter_delta_confined_to_IO_helper=True,
                  raw_getters_clock_metadata_strict_gate_full_scene_suffix_byte_equal=True,
                  launcher_delta_only_PLAN_filename=True,
                  single_bounded_read_exact_bytes_and_immediate_error_checked=True,
                  failed_read_returns_false_before_admission=True)
path = OUT / ("source-" + mode + "-result.json")
assert not path.exists()
path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(result, ensure_ascii=False, indent=2))
if mode == "red":
    print("Expected F01 source RED: v1 can accept cached OK without a filesystem-visible readback", file=sys.stderr)
    raise SystemExit(1)
