import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=ROOT/'.local/deepeye-implementation-a/competition/deepeye'
SUPPORT=D.parent/'r02-transient-quota-fix-20261021'
for n,h in {'win_job.py':'80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d','boundary.py':'04cf7d53f3dbf1fca66aab05fe497ae193aab94a56ab4e0d36e81d1eb0a040fe'}.items():assert hashlib.sha256((SUPPORT/n).read_bytes()).hexdigest()==h
sys.path.insert(0,str(SUPPORT))
from win_job import run_bounded
from boundary import save_new
label=sys.argv[1];assert label in ('red-01','green-01','green-02')
for previous in ['red-01','green-01'][:0 if label=='red-01' else 1 if label=='green-01' else 2]:
 r=json.loads((D/previous/'terminal.json').read_bytes());assert r['all_processes_terminated'] and all(x['signaled'] and x['wait_result']==0 for x in r['held_members'])
run=D/label;run.mkdir();snap=run/'source-snapshots';snap.mkdir()
for name in ['simulation/isolation/ipc_framing.py','tests/simulation/test_ipc_framing.py','docs/actor_ipc_framing.md']:
 if (P/name).exists():
  target=snap/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((P/name).read_bytes())
for n in ['run_tests.py','test_worker.py']:(snap/n).write_bytes((D/n).read_bytes())
env={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR')}
env.update(PATH='',TEMP=str(run),TMP=str(run),PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
budget={'seconds':30,'job_memory_bytes':512*1024**2,'process_memory_bytes':256*1024**2,'active_processes':4,'stdout_bytes':256*1024,'stderr_bytes':512*1024,'tree_bytes':16*1024**2,'tree_entries':300,'free_reserve_bytes':512*1024**2}
argv=[str(ROOT/'.local/venv/Scripts/python.exe'),'-I','-S','-B','-X','utf8',str(D/'test_worker.py'),str(run)]
save_new(run/'started.json',{'argv':argv,'budget':budget,'environment':env,'cwd':str(D)})
result=run_bounded(argv,env,D,run/'process',budget,[run]);save_new(run/'terminal.json',result)
assert result['all_processes_terminated'] and all(x['signaled'] and x['wait_result']==0 for x in result['held_members'])
print(json.dumps({k:result.get(k) for k in ('exit_code','seconds','all_processes_terminated','active_processes_final','held_members','stop_reason')}))
raise SystemExit(0 if result['exit_code']==0 else 1)
