"""Independent readback of new results; never reruns solves or runtime probes."""
import asyncio, base64, csv, hashlib, json
from pathlib import Path

D=Path(__file__).resolve().parent
OUT=D.parent
ROOT=OUT.parents[1]
P=ROOT/'.local/deepeye-implementation-a'

def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x',encoding='utf-8') as f: json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def normalized(d):
    if 'job_id' in d:return d
    return json.loads(next(x['text'] for x in d['content'] if x['type']=='text'))
def manifest(folder,name):
    d=read(folder/name)
    for n,r in d['files'].items():
        p=folder/n
        assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],str(p)
    return {'path':str(folder/name),'sha256':sha(folder/name),'verified_files':len(d['files'])}
def completed(folder,job_id):
    d=normalized(read(folder/'native-complete-response.json'))
    assert d['job_id']==job_id and d['status']=='completed' and d['terminal'] and not d['stale']
    assert d['result']['text']==(folder/'final-result.txt').read_text(encoding='utf-8')
    return {k:d[k] for k in ('job_id','status','terminal','stale')}

import sys
sys.path.insert(0,str(ROOT))
rm=read(OUT/"r02-live-runtime-main-review-20261021/review.json")["manifest"]
# Independent framing review: retrieve exact original controller result, not an invented completion.
f=OUT/'r03-ipc-framing-independent-20261021';fm=manifest(f,'review-manifest.json')
from fpga_mesh.child_control import LocalControlFileClient
from fpga_mesh.project_cli import discovery
async def original_job():
    return await LocalControlFileClient(discovery(ROOT)).call('job',{'job_id':'child-962e5b785992435eb7c0f6720624ef40'})
job=normalized(asyncio.run(original_job()))
assert job['status']=='completed' and job['terminal'] and not job['stale']
result=read(f/'review-result.json')
assert result['independent_edges']['tests']==4 and result['independent_edges']['passed']==4
assert not result['static_review']['findings']
pins=read(f/'assignment.json')['product_pins']
for n,rp in pins.items():assert sha(P/n)==rp['sha256']
fd=OUT/'r03-ipc-framing-main-review-20261021';fd.mkdir()
save(fd/'native-job-readback.json',job)
save(fd/'review.json',{'status':'ACCEPT_INACTIVE_BOUNDED_FRAMING_LEAF','manifest':fm,
    'native':{k:job[k] for k in ('job_id','status','terminal','stale')},'product_pins':pins,
    'author_new_tests':9,'independent_new_tests':4,'old_tests_repeated':False,
    'production_channels_activated':False,'formal_R03':'not_run','H12':'not_run'})

# L4 new result integrity. Independent saved-array arithmetic runs separately.
g=OUT/'g03-l4-saved-operator-solve-20261021';gm=manifest(g,'public-manifest.json')
assert gm['sha256']=='271aab6edb126600b8234bfc7ab9137b3e9889c8dd5d7a8ab0395f59fac731b0'
gn=completed(g,'child-5db883500e8145cca29801474585c2e1')
gr=read(g/'run-01/result.json');gt=read(g/'run-01/terminal.json')
assert gr['counts']=={'A_assemblies':0,'C_constructions':0,'factorizations':1,'RHS_columns':1}
assert gt['exit_code']==0 and gt['all_processes_terminated'] and gt['active_processes_final']==0
assert all(x['signaled'] and x['wait_result']==0 for x in gt['held_members'])
gd=OUT/'g03-l4-saved-main-review-20261021';gd.mkdir()
save(gd/'integrity.json',{'status':'NEW_SOLUTION_INTEGRITY_VERIFIED','manifest':gm,'native':gn,
    'counts':gr['counts'],'peak_job_memory_bytes':gt['peak_job_memory_bytes'],
    'source_review':'Loads saved AII and RHS; no mesh/PDE import, one COLAMD/solve, fixed residual gate. C/W/boundary read after releasing LU. Same source/reference and observed comparisons.',
    'factorization_repeated':False,'old_tests_repeated':False})
print(json.dumps({'runtime':rm,'framing':fm,'L4':gm,'independent_numeric_review_pending':True},ensure_ascii=False))
