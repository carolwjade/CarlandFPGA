"""Independent readback of new results; never reruns solves or runtime probes."""
import asyncio, base64, csv, hashlib, json
from pathlib import Path

D=Path(__file__).resolve().parent
OUT=D.parent
ROOT=OUT.parents[1]
P=ROOT/'.local/deepeye-implementation-a'

def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x',encoding='utf-8') as f: json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def normalized(d):
    if 'job_id' in d:return d
    return json.loads(next(x['text'] for x in d['content'] if x['type']=='text'))
def manifest(folder,name):
    d=read(folder/name)
    for n,r in d['files'].items():
        p=folder/n
        assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],str(p)
    return {'path':str(folder/name),'sha256':sha(folder/name),'verified_files':len(d['files'])}
def completed(folder,job_id):
    d=normalized(read(folder/'native-complete-response.json'))
    assert d['job_id']==job_id and d['status']=='completed' and d['terminal'] and not d['stale']
    assert d['result']['text']==(folder/'final-result.txt').read_text(encoding='utf-8')
    return {k:d[k] for k in ('job_id','status','terminal','stale')}

# New runtime: inspect actual source, original capture and installed file bytes.
r=OUT/'r02-live-runtime-identity-20261021'
rm=manifest(r,'manifest.json')
native=completed(r,'child-febba1e2180146a7a386821adc0847fa')
summary=read(r/'identity-summary.json');raw=read(r/'evidence/raw-result.json')
assert raw['status']=='success' and len(raw['torch_module_import_events'])==1 and not raw['prohibited_attempts']
module=summary['actual_loaded_module'];record=summary['installed_RECORD_binding']['record_file']
assert sha(Path(module['path']))==module['sha256'] and Path(module['path']).stat().st_size==module['bytes']
assert sha(Path(record['path']))==record['sha256'] and Path(record['path']).stat().st_size==record['bytes']
with Path(record['path']).open(encoding='utf-8',newline='') as f:
    rows=[x for x in csv.reader(f) if x[0]==summary['installed_RECORD_binding']['member']]
assert len(rows)==1
assert rows[0][1]=='sha256='+base64.urlsafe_b64encode(bytes.fromhex(module['sha256'])).decode().rstrip('=')
assert int(rows[0][2])==module['bytes']
for name,result in summary['HIP_version_APIs'].items():
    assert result==raw['identity']['APIs'][name]
    assert result['status']==0 and result['raw_value']==71460850
    assert module['base_address']<=result['function_address']<module['base_address']+module['image_size']
    assert result['provider_handle']==module['handle']
prov=read(r/'api-provenance.json')
for name in ('HIP_header','HIP_version_header'):
    x=prov[name];assert sha(Path(x['path']))==x['sha256']
term=read(r/'runs/actual/terminal.json')
assert term['exit_code']==0 and term['all_processes_terminated'] and term['active_processes_final']==0
assert all(x['signaled'] and x['wait_result']==0 for x in term['held_members'])
rd=OUT/'r02-live-runtime-main-review-20261021';rd.mkdir()
save(rd/'review.json',{'status':'ACCEPT_ONE_LIVE_HIP_IDENTITY_OBSERVATION','manifest':rm,'native':native,
    'module':{k:module[k] for k in ('path','bytes','sha256','file_version','product_version')},
    'HIP_version_APIs':summary['HIP_version_APIs'],'record_file':record,
    'source_review':'Typed Windows module APIs, image-bounded GetProcAddress and C int(int*) signatures; only fixed System32 API providers loaded by collector; source has no tensor/kernel call. Single selected torch import retained.',
    'raw_record_schema_qualification':'Raw installed_RECORD.bytes is member size, not RECORD file size; identity-summary installed_RECORD_binding correctly separates them. Future collector reuse should split these keys; no actual probe replay needed.',
    'probe_repeated':False,'old_tests_repeated':False,'R02':'not_run','C03':'not_run','official_SKU_support':'not_established'})

# Independent framing review: retrieve exact original controller result, not an invented completion.
f=OUT/'r03-ipc-framing-independent-20261021';fm=manifest(f,'review-manifest.json')
from fpga_mesh.child_control import LocalControlFileClient
from fpga_mesh.project_cli import discovery
async def original_job():
    return await LocalControlFileClient(discovery(ROOT)).call('job',{'job_id':'child-962e5b785992435eb7c0f6720624ef40'})
job=normalized(asyncio.run(original_job()))
assert job['status']=='completed' and job['terminal'] and not job['stale']
result=read(f/'review-result.json')
assert result['independent_edges']['tests']==4 and result['independent_edges']['passed']==4
assert not result['static_review']['findings']
pins=read(f/'assignment.json')['product_pins']
for n,rp in pins.items():assert sha(P/n)==rp['sha256']
fd=OUT/'r03-ipc-framing-main-review-20261021';fd.mkdir()
save(fd/'native-job-readback.json',job)
save(fd/'review.json',{'status':'ACCEPT_INACTIVE_BOUNDED_FRAMING_LEAF','manifest':fm,
    'native':{k:job[k] for k in ('job_id','status','terminal','stale')},'product_pins':pins,
    'author_new_tests':9,'independent_new_tests':4,'old_tests_repeated':False,
    'production_channels_activated':False,'formal_R03':'not_run','H12':'not_run'})

# L4 new result integrity. Independent saved-array arithmetic runs separately.
g=OUT/'g03-l4-saved-operator-solve-20261021';gm=manifest(g,'public-manifest.json')
assert gm['sha256']=='271aab6edb126600b8234bfc7ab9137b3e9889c8dd5d7a8ab0395f59fac731b0'
gn=completed(g,'child-5db883500e8145cca29801474585c2e1')
gr=read(g/'run-01/result.json');gt=read(g/'run-01/terminal.json')
assert gr['counts']=={'A_assemblies':0,'C_constructions':0,'factorizations':1,'RHS_columns':1}
assert gt['exit_code']==0 and gt['all_processes_terminated'] and gt['active_processes_final']==0
assert all(x['signaled'] and x['wait_result']==0 for x in gt['held_members'])
gd=OUT/'g03-l4-saved-main-review-20261021';gd.mkdir()
save(gd/'integrity.json',{'status':'NEW_SOLUTION_INTEGRITY_VERIFIED','manifest':gm,'native':gn,
    'counts':gr['counts'],'peak_job_memory_bytes':gt['peak_job_memory_bytes'],
    'source_review':'Loads saved AII and RHS; no mesh/PDE import, one COLAMD/solve, fixed residual gate. C/W/boundary read after releasing LU. Same source/reference and observed comparisons.',
    'factorization_repeated':False,'old_tests_repeated':False})
print(json.dumps({'runtime':rm,'framing':fm,'L4':gm,'independent_numeric_review_pending':True},ensure_ascii=False))
