"""Fixed single-attempt held-job launcher for the L4 ordering repair."""
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
SUPPORT=D.parent/'r02-amd-wheel-acquisition-20261021'
REF=D.parent/'g03-source-voltage-20261021/run-01/V_reference128_V.npy'
L1=D.parent/'g03-internal-source-grid-continuation-20261021'
L2=D.parent/'g03-l2-xy-refinement-20261021'
L3=D.parent/'g03-l3-z-refinement-20261021'
L4=D.parent/'g03-l4-global-refinement-20261021'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def publish_grant(stage,v):
    pending=stage/'grant.pending.json'
    save(pending,v)
    os.replace(pending,stage/'grant.json')
def pins():
    a=read(D/'assignment.json');t=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
    assert a['owner']=='/root/g03_grid_continuation_20261021'
    assert a['work_id']=='A-G03-L4-ORDERING-REPAIR-20261021-v1'
    assert a['selected_by']==t['new_director_thread_id'] and t['director_generation']==2 and t['status']=='active'
    assert sha(D/'design-plan.md')==a['design_sha256']
    scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
    digest=hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
    assert digest==a['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    assert sha(REF)==a['reference']['sha256']
    assert sha(L4/'public-manifest.json')==a['previous_manifest_sha256']
    prior=read(L4/'public-manifest.json')
    assert sha(D/'grid_model.py')==prior['files']['grid_model.py']['sha256']
    assert read(D.parent/'g03-l4-main-review-20261021/review.json')['source_manifest_sha256']==a['previous_manifest_sha256']
    for n in ('control-result.json','terminal.json','input-readback.json','W_faces_m2.npy',
              's_matrix_free_Am.npy','boundary_indices.npy','interior_indices.npy',
              'boundary_g_128x16_Vpm.npy'):
        p=L4/'controls-01'/n
        assert sha(p)==prior['files']['controls-01/'+n]['sha256']
    assert read(L4/'controls-01/control-result.json')['status']=='controls_pass'
    assert read(L4/'controls-01/terminal.json')['all_processes_terminated']
    l3prior=read(L3/'public-manifest.json')
    assert sha(L3/'run-01/V_compatible_V.npy')==l3prior['files']['run-01/V_compatible_V.npy']['sha256']
    l2prior=read(L2/'public-manifest.json')
    assert sha(L2/'run-01/V_compatible_V.npy')==l2prior['files']['run-01/V_compatible_V.npy']['sha256']
    assert sha(L2/'controls-01/disk_cell_areas_m2.npy')==l2prior['files']['controls-01/disk_cell_areas_m2.npy']['sha256']
    l1prior=read(L1/'public-manifest.json')
    assert sha(L1/'run-01/V_compatible_V.npy')==l1prior['files']['run-01/V_compatible_V.npy']['sha256']
    for n in ('grid_model.py','grid_worker.py','run_grid.py','seal_public_l4.py'):
        assert sha(D/'source-snapshot-l4'/n)==prior['files'][n]['sha256']
    sources=[D/n for n in ('assignment.json','design-plan.md','grid_model.py','grid_worker.py','run_grid.py')]
    sources += [SUPPORT/n for n in ('win_job.py','boundary.py')]
    sources += [REF,L1/'public-manifest.json',L1/'run-01/V_compatible_V.npy',
        L2/'public-manifest.json',L2/'run-01/V_compatible_V.npy',L2/'controls-01/disk_cell_areas_m2.npy',
        L3/'public-manifest.json',L3/'run-01/V_compatible_V.npy',
        L4/'public-manifest.json',D.parent/'g03-l4-main-review-20261021/review.json',
        ROOT/'docs/competition/deepeye-2026/immutable_scope.json',ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json']
    sources += [L4/'controls-01'/n for n in ('control-result.json','terminal.json','input-readback.json',
        'W_faces_m2.npy','s_matrix_free_Am.npy','boundary_indices.npy','interior_indices.npy',
        'boundary_g_128x16_Vpm.npy')]
    sources += [D/'source-snapshot-l4'/n for n in ('grid_model.py','grid_worker.py','run_grid.py','seal_public_l4.py')]
    return {p.relative_to(ROOT).as_posix():sha(p) for p in sources}
def main():
    mode=sys.argv[1];assert mode=='actual'
    label='run-01'
    before=pins()
    pin_path=D/'input-pins.json'
    if not pin_path.exists():save(pin_path,before)
    else:assert read(pin_path)==before
    import ctypes as ct
    class MemoryStatus(ct.Structure):
        _fields_=[('length',ct.c_uint32),('load',ct.c_uint32),
            ('total_physical',ct.c_uint64),('available_physical',ct.c_uint64),
            ('total_page_file',ct.c_uint64),('available_page_file',ct.c_uint64),
            ('total_virtual',ct.c_uint64),('available_virtual',ct.c_uint64),
            ('extended_virtual',ct.c_uint64)]
    status=MemoryStatus();status.length=ct.sizeof(status)
    if not ct.windll.kernel32.GlobalMemoryStatusEx(ct.byref(status)):
        raise OSError('GlobalMemoryStatusEx failed')
    memory={'available_physical_bytes':status.available_physical,
        'minimum_required_bytes':6*1024**3,'total_physical_bytes':status.total_physical,
        'sufficient':status.available_physical>=6*1024**3}
    save(D/'available-physical-memory-preflight.json',memory)
    if not memory['sufficient']:raise RuntimeError('insufficient available physical memory before ordering-repair actual model')
    sys.path.insert(0,str(SUPPORT))
    from win_job import run_bounded,process_identity
    stage=D/label;granted=False
    env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),
        'PATH':'','TEMP':str(D),'TMP':str(D),'TMPDIR':str(D),'PYTHONDONTWRITEBYTECODE':'1',
        'PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',
        **{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','VECLIB_MAXIMUM_THREADS')}}
    budget={'seconds':90,'active_processes':4,'process_memory_bytes':2*1024**3,
        'job_memory_bytes':3*1024**3,'stdout_bytes':128*1024,'stderr_bytes':128*1024,
        'tree_bytes':128*1024**2,'tree_entries':2048,'free_reserve_bytes':512*1024**2,
        'components':[{'path':str(stage),'bytes':128*1024**2,'entries':2048}]}
    def tick(job,pids):
        nonlocal granted
        if (stage/'hello.json').exists() and not granted:
            hello=read(stage/'hello.json');assert hello['pid'] in pids and hello['mode']==mode
            publish_grant(stage,{'worker':process_identity(hello['pid'],job),'mode':mode,
                'scientific_import_allowed':True,'source_pins':before})
            granted=True
    result=run_bounded([str(ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'),
        '-I','-B','-X','utf8',str(D/'grid_worker.py'),str(stage),mode],env,D,stage,budget,[D],on_tick=tick)
    after=pins();save(stage/'input-readback.json',{'unchanged':before==after,'before':before,'after':after})
    assert result['all_processes_terminated'] and before==after
    print(json.dumps({k:result.get(k) for k in ('status','exit_code','seconds','stop_reason','all_processes_terminated','held_members')}))
    raise SystemExit(result['exit_code'] if result['exit_code'] is not None else 125)
if __name__=='__main__':main()
