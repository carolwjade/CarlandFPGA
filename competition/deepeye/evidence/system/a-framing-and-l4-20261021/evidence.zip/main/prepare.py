"""Publish only newly reviewed framing, runtime identity and L4 evidence."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parent;O=D.parent;ROOT=O.parents[1]
P=ROOT/'.local/deepeye-implementation-a'
T=P/'competition/deepeye/evidence/system/a-framing-and-l4-20261021'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def enc(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(p,raw):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(raw)
specs=[('g03-l4-global-refinement-20261021','public-manifest.json'),
       ('g03-l4-ordering-repair-20261021','public-manifest.json'),
       ('g03-l4-saved-operator-solve-20261021','public-manifest.json'),
       ('r02-live-runtime-identity-20261021','manifest.json'),
       ('r03-ipc-framing-implementation-20261021','artifact-manifest.json'),
       ('r03-ipc-framing-independent-20261021','review-manifest.json')]
tokens=[read(O/n/'lease.private.json')['lease_token'].encode() for n,_ in specs if (O/n/'lease.private.json').exists()]
members={};derivatives=[]
def clean(v):
    if isinstance(v,list):return [clean(x) for x in v]
    if isinstance(v,dict):return {k:clean(x) for k,x in v.items() if k not in ('environment','env')}
    return v
def add(p):
    if 'private' in p.name.casefold() or p.name=='reserve-request.json':return
    raw=p.read_bytes();name=p.relative_to(O).as_posix()
    if p.suffix=='.json':
        try:v=read(p)
        except json.JSONDecodeError as exc:
            name=name.removesuffix('.json')+'-unparsed-public.json'
            v={'original_local_sha256':sha(raw),'original_bytes':len(raw),'original_environment_omitted':True,
               'original_retained_locally':True,'reason':'Malformed partial JSON retained from failed attempt',
               'parse_error':{'line':exc.lineno,'column':exc.colno,'message':exc.msg}}
            derivatives.append({'published_path':name,'original_sha256':sha(raw)})
            raw=enc(v)
        c=clean(v)
        if v!=c:
            name=name.removesuffix('.json')+'-public.json'
            c['original_environment_omitted']=True;c['original_local_sha256']=sha(raw)
            derivatives.append({'published_path':name,'original_sha256':sha(raw)})
            raw=enc(c)
    assert name not in members and not any(token in raw for token in tokens),name
    members[name]=raw
for name,manifest in specs:
    folder=O/name;m=read(folder/manifest)
    for rel,pin in m['files'].items():
        p=folder/rel;assert p.stat().st_size==pin['bytes'] and sha(p.read_bytes())==pin['sha256'],str(p)
        add(p)
    for extra in (manifest,'native-complete-response.json'):
        p=folder/extra
        if p.exists() and p.relative_to(O).as_posix() not in members:add(p)
reviews={}
for name in ('g03-l4-main-review-20261021','g03-l4-ordering-main-review-20261021',
             'g03-l4-saved-main-review-20261021','r02-live-runtime-main-review-20261021',
             'r03-ipc-framing-main-review-20261021'):
    folder=O/name;reviews[name]=read(folder/'review.json')
    for p in sorted(folder.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:add(p)
for name in ('review_new.py','review_remaining.py','review-new-attempt1-failure.json'):
    add(O/'goal-current-work-20261021'/name)
framing_pins=reviews['r03-ipc-framing-main-review-20261021']['product_pins']
for rel,pin in framing_pins.items():assert sha((P/rel).read_bytes())==pin['sha256']
assert reviews['g03-l4-saved-main-review-20261021']['status']=='ACCEPT_NEW_L4_SAVED_OPERATOR_NUMERICAL_RESULT_ONLY'
summary={'utc':datetime.now(timezone.utc).isoformat(),'reviews':reviews,'framing_product_pins':framing_pins,
    'public_derivatives':derivatives,'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    'old_tests_repeated':False,'formal_R03':'not_run','full_H12':'not_run','all29':'not_run'}
members['main/summary.json']=enc(summary);members['main/prepare.py']=Path(__file__).read_bytes()
T.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(T/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()):
        zi=zipfile.ZipInfo(name,(2026,10,21,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16
        z.writestr(zi,raw)
with zipfile.ZipFile(T/'evidence.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for name,raw in members.items():assert z.read(name)==raw
write(T/'.gitattributes',b'* -text -eol -filter\n')
write(T/'archive-index.json',enc({n:{'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(members.items())}))
write(T/'summary.json',enc(summary))
write(T/'README.md','''# Framing implementation, actual HIP identity and L4 solution

The new inactive private byte framing codec accepts fragmented/coalesced opaque
payloads with fixed chunk/frame bounds and permanent refusal on invalid input
or truncated EOF. Its nine new author tests passed after a retained absent-code
RED; four new independent boundary cases passed without rerunning the author
tests. All original held process objects terminated. The module grants no source,
clock, inference or movement authority and has no production call site. See
`docs/actor_ipc_framing.md` for the explicit future endpoint-adoption requirement.

The already installed ROCm environment was used for one new read-only identity
probe: one torch import, no collector tensor/kernel call. Its uniquely loaded
`amdhip64_7.dll` is 22,097,408 bytes, SHA256
`1c7bad4e8ddefc456e5c073d89b59ee0bcfbcda461a5ada145370fe9941df033`.
Both `hipRuntimeGetVersion` and `hipDriverGetVersion` returned status0/value71460850,
decoded by bundled headers as7.14.60850. The PE file/product resource version is
10.0.3581.0. These are distinct from a Windows display-driver version or official
8845H support. Main independently checked loaded-file/installed-RECORD identity,
typed API provenance,94-module snapshot and original terminal. The raw RECORD
entry's bytes field denotes member bytes; the separate identity summary gives
the correct75,947-byte RECORD file identity. No reinstall or GPU quicktest ran.

G03 L4 bisects every L2 interval, including outer x/y gaps:24x24x28 cells,
52,300 edges,44,620 interior edges. One new geometry/control stage passed with
unchanged physics, compatible finite-loop source and receiver weights. The first
launch failed before science on non-atomic grant JSON; its bytes were preserved
and only grant publication was repaired. The actual COLAMD solve then failed
at the2GiB process limit. One selected MMD ordering repair also hit that limit;
it saved exact C/A/AII/source/right-hand-side arrays before factorization.

A separately selected4GiB-process/5GiB-job continuation loaded those exact saved
operators, performed zero new assemblies, and completed one COLAMD factorization
and one RHS solve in44.562s. Peak job memory was3,948,060,672 bytes; every held
process terminated. Backward residual eta7.097523937546803e-17 passes the unchanged
128eps64 gate2.842170943040401e-14. Main independently checked the saved residual
and receiver values through the transposed functional, without factorization,
assembly, old controls or reference integration.

|Grid|Near receiver relative reference error|Far receiver relative reference error|
|---|---:|---:|
|Saved L3|30.1941%|29.9509%|
|New L4|14.9621%|11.4745%|

L4 voltages are(-3.9185684013635874e-7-0.0010089363656603258j)V and
(-2.501519436033116e-7-0.00021836612005138962j)V. Physical accuracy remains
unqualified. Numerical residual and observed grid improvement do not certify
total physical error, arbitrary3D heterogeneous cases, noise/unknown/OOD handling
or a complete sensor model. A newly assigned receiver-local error decomposition
will choose the next correction; it is not included as a result in this archive.

The existing PC_DIRECT, native pipe-read,13 R03 software groups and base-BRAM
384/384 result were reused. This checkpoint did not repeat those tests, program
the board, use the display, activate production providers or change services.
The private leases, inherited environments and vendor binaries are excluded;
public derivatives retain hashes of original local evidence. Original numerical
and launcher failures remain preserved. H01-H15 canonical requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 is unchanged.
Formal R02/G03/R03/C03/H12/all29 acceptance remains open.
'''.encode())
write(T/'manifest.json',enc({'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(T.iterdir())},'archive_members':len(members),'exact_member_bytes_and_crc_checked':True}))
guide=P/'competition/deepeye/docs/framing_and_l4_checkpoint_20261021.md'
write(guide,'''# New stream framing and numerical/runtime evidence

[The exact checkpoint](../evidence/system/a-framing-and-l4-20261021/README.md)
contains the newly reviewed private byte codec (9 author and4 independent tests),
one actual loaded-HIP identity observation, and the successful saved-operator L4
solve with its two retained memory failures. No old successful tests were rerun.

Receiver reference errors are now14.9621%/11.4745%; physical accuracy is still
unqualified. The framing leaf remains inactive pending actual producer/endpoint
adoption. Useful C project inference, authentic runtime providers, custom board
interfaces and the two complete H12 routes remain required.
'''.encode())
paths=[*sorted(T.iterdir()),guide,*[P/n for n in framing_pins]]
files={p.relative_to(P).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in paths}
write(D/'publication-files.json',enc(files));write(D/'owned-paths.nul',b''.join(n.encode()+b'\0' for n in files))
r={'files':len(files),'archive_members':len(members),'archive_bytes':(T/'evidence.zip').stat().st_size,
   'archive_sha256':sha((T/'evidence.zip').read_bytes()),'environment_derivatives':len(derivatives)}
write(D/'package-summary.json',enc(r));print(json.dumps(r))
