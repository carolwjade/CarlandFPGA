"""One saved L4 interior-system factorization; never assembles a mesh or PDE."""
import gc,hashlib,json,math,os,sys,time,warnings
from pathlib import Path
D=Path(__file__).resolve().parent
P=D.parent/'g03-l4-ordering-repair-20261021'
L4=D.parent/'g03-l4-global-refinement-20261021'
stage=Path(sys.argv[1])
mode=sys.argv[2]
def save_json(path,value):
    with path.open('x',encoding='utf-8') as f:
        json.dump(value,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def save_array(path,value):
    with path.open('xb') as f:
        import numpy as np
        np.save(f,value,allow_pickle=False)
def pair(values):
    return [[float(complex(v).real),float(complex(v).imag)] for v in values]
save_json(stage/'hello.json',{'pid':os.getpid(),'before_scientific_import':True,'mode':mode})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('no science grant')
    time.sleep(.01)
grant=json.loads((stage/'grant.json').read_text(encoding='utf-8'))
assert mode=='actual' and grant['worker']['pid']==os.getpid() and grant['mode']==mode
import ctypes as ct
import numpy as np
import scipy.linalg
from scipy.sparse import csc_matrix,csr_matrix
from scipy.sparse.linalg import splu
def threads():
    k=ct.WinDLL('kernel32',use_last_error=True)
    k.GetModuleHandleW.argtypes=[ct.c_wchar_p];k.GetModuleHandleW.restype=ct.c_void_p
    site=Path(np.__file__).resolve().parents[1];rows=[]
    for folder,symbol in (('numpy.libs','scipy_openblas_get_num_threads64_'),
                          ('scipy.libs','scipy_openblas_get_num_threads')):
        paths=list((site/folder).glob('*openblas*.dll'));assert len(paths)==1
        handle=k.GetModuleHandleW(str(paths[0]));assert handle
        getter=getattr(ct.CDLL(str(paths[0]),handle=handle),symbol)
        getter.argtypes=[];getter.restype=ct.c_int
        count=getter();assert count==1
        rows.append({'path':str(paths[0]),
                     'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),
                     'num_threads':count})
    return rows
def saved_matrix(path,kind):
    with np.load(path,allow_pickle=False) as archive:
        shape=tuple(int(v) for v in archive['shape'])
        data=archive['data'];indices=archive['indices'];indptr=archive['indptr']
    cls=csc_matrix if kind=='csc' else csr_matrix
    return cls((data,indices,indptr),shape=shape,copy=False)
def prior_voltage(directory):
    root=D.parent/directory
    manifest=json.loads((root/'public-manifest.json').read_text(encoding='utf-8'))
    path=root/'run-01/V_compatible_V.npy'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==manifest['files']['run-01/V_compatible_V.npy']['sha256']
    return np.load(path,allow_pickle=False)
started=time.monotonic();before=threads();error=None
counts={'A_assemblies':0,'C_constructions':0,'factorizations':0,'RHS_columns':0}
try:
    source=P/'run-01'
    evidence=json.loads((source/'pre-factorization-assembly.json').read_text(encoding='utf-8'))
    for name in ('AII-csc.npz','A_II_rhs.npy','C-csr.npz'):
        path=source/name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==evidence['files'][name]['sha256']
    AII=saved_matrix(source/'AII-csc.npz','csc')
    reduced=np.load(source/'A_II_rhs.npy',allow_pickle=False)
    if AII.shape!=(44620,44620) or AII.nnz!=558516 or reduced.shape!=(44620,):
        raise ValueError('saved AII/RHS dimensions')
    if AII.dtype!=np.complex128 or reduced.dtype!=np.complex128:
        raise ValueError('saved AII/RHS dtype')
    if not np.all(np.isfinite(AII.data)) or not np.all(np.isfinite(reduced)):
        raise ArithmeticError('nonfinite saved AII/RHS')
    with warnings.catch_warnings(record=True):
        warnings.simplefilter('error')
        lu=splu(AII,permc_spec='COLAMD');counts['factorizations']=1
        x=lu.solve(reduced);counts['RHS_columns']=1
    L_nnz=int(lu.L.nnz);U_nnz=int(lu.U.nnz)
    del lu
    gc.collect()
    residual=AII@x-reduced
    normA=float(np.max(np.asarray(abs(AII).sum(axis=1)).ravel()))
    den=normA*float(np.max(abs(x)))+float(np.max(abs(reduced)))
    eta=float(np.max(abs(residual))/den) if den else (0. if np.array_equal(residual,np.zeros_like(residual)) else math.inf)
    gate=128*np.finfo(float).eps
    if not math.isfinite(eta) or eta>gate:
        raise ArithmeticError('fixed 128eps backward residual gate')
    C=saved_matrix(source/'C-csr.npz','csr')
    control=L4/'controls-01'
    W=np.load(control/'W_faces_m2.npy',allow_pickle=False)
    B=np.load(control/'boundary_indices.npy',allow_pickle=False)
    I=np.load(control/'interior_indices.npy',allow_pickle=False)
    g=np.load(control/'boundary_g_128x16_Vpm.npy',allow_pickle=False)
    if C.shape!=(50304,52300) or C.nnz!=201216 or W.shape!=(3,50304):
        raise ValueError('saved C/receiver dimensions')
    if len(B)!=7680 or len(I)!=44620 or len(g)!=len(B) or not np.array_equal(np.sort(np.r_[B,I]),np.arange(52300)):
        raise ValueError('saved boundary/interior partition')
    if not all(np.all(np.isfinite(arr)) for arr in (C.data,W,g)):
        raise ArithmeticError('nonfinite receiver data')
    E=np.empty(52300,dtype=complex);E[B]=g;E[I]=x
    V=W@(C@E)
    refpath=D.parent/'g03-source-voltage-20261021/run-01/V_reference128_V.npy'
    if hashlib.sha256(refpath.read_bytes()).hexdigest()!='fd68cfa481e92251fd14616f0ca177f312db89904557c8c44fd9219fd1df1889':
        raise ValueError('reference pin')
    ref=np.load(refpath,allow_pickle=False)
    l1=prior_voltage('g03-internal-source-grid-continuation-20261021')
    l2=prior_voltage('g03-l2-xy-refinement-20261021')
    l3=prior_voltage('g03-l3-z-refinement-20261021')
    assert all(v.shape==(2,) for v in (ref,l1,l2,l3))
    diff=V[1:]-ref;delta_l1=V[1:]-l1;delta_l2=V[1:]-l2;delta_l3=V[1:]-l3
    for name,array in {'interior_solution_Vpm':x,'AII_residual':residual,'E_Vpm':E,
        'V_compatible_V':V[1:],'V_reference128_V':ref,'V_difference_V':diff,
        'V_L1_saved_V':l1,'V_L2_saved_V':l2,'V_L3_saved_V':l3,
        'V_L4_minus_L1_V':delta_l1,'V_L4_minus_L2_V':delta_l2,
        'V_L4_minus_L3_V':delta_l3}.items():
        save_array(stage/(name+'.npy'),array)
    result={'status':'one_saved_operator_L4_solve_complete','counts':counts,
        'factorization_ordering':'COLAMD','loaded_AII_shape':AII.shape,
        'loaded_AII_nnz':int(AII.nnz),'L_nnz':L_nnz,'U_nnz':U_nnz,
        'backward_residual_eta':eta,'backward_residual_gate':gate,
        'V_compatible_V':pair(V[1:]),'V_reference128_V':pair(ref),
        'finite_minus_reference_V':pair(diff),'absolute_difference_V':abs(diff).tolist(),
        'relative_difference':(abs(diff)/abs(ref)).tolist(),
        'V_L1_saved_V':pair(l1),'V_L2_saved_V':pair(l2),'V_L3_saved_V':pair(l3),
        'L4_minus_L1_V':pair(delta_l1),'L4_minus_L1_absolute_V':abs(delta_l1).tolist(),
        'L4_minus_L2_V':pair(delta_l2),'L4_minus_L2_absolute_V':abs(delta_l2).tolist(),
        'L4_minus_L3_V':pair(delta_l3),'L4_minus_L3_absolute_V':abs(delta_l3).tolist(),
        'physical_acceptance':'open','G03':'not_run','R03':'not_run','all29':'not_run'}
    save_json(stage/'result.json',result)
except BaseException as exc:
    error={'type':type(exc).__name__,'message':str(exc)}
    raise
finally:
    save_json(stage/'execution.json',{'mode':mode,'pid':os.getpid(),
        'seconds':time.monotonic()-started,'counts':counts,
        'blas_before':before,'blas_after':threads(),'error':error})
