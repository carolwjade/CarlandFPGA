"""Reusable read-only identity collector; HIP calls use already loaded handles.

Only fixed Windows System32 kernel32/version API providers may be loaded by
this collector. No HIP DLL path is ever passed to a loader. Importing torch is
the caller's one selected vendor effect; this function allocates no tensors.
"""
import base64
import csv
import ctypes as ct
from ctypes import wintypes as wt
import hashlib
from pathlib import Path
import os
import struct
from contracts import APIS,select_loaded_runtime

class ModuleInfo(ct.Structure):
    _fields_=[('base',ct.c_void_p),('size',wt.DWORD),('entry',ct.c_void_p)]
class FixedInfo(ct.Structure):
    _fields_=[(name,wt.DWORD) for name in ('signature','structure','fileMS','fileLS','productMS','productLS',
        'mask','flags','OS','type','subtype','dateMS','dateLS')]
def pin(path):
    p=Path(path)
    with p.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':p.stat().st_size,'sha256':sha}
def typed(lib,name,args,result):
    f=getattr(lib,name)
    f.argtypes,f.restype=args,result
    return f
def must(value):
    if not value: raise ct.WinError(ct.get_last_error())
def file_version(path,system32):
    # This is a fixed documented Windows resource API provider, never HIP.
    api_path=system32/'version.dll'
    version=ct.WinDLL(str(api_path),use_last_error=True)
    sizefn=typed(version,'GetFileVersionInfoSizeW',[wt.LPCWSTR,ct.POINTER(wt.DWORD)],wt.DWORD)
    getfn=typed(version,'GetFileVersionInfoW',[wt.LPCWSTR,wt.DWORD,wt.DWORD,ct.c_void_p],wt.BOOL)
    query=typed(version,'VerQueryValueW',[ct.c_void_p,wt.LPCWSTR,ct.POINTER(ct.c_void_p),ct.POINTER(wt.UINT)],wt.BOOL)
    ignored=wt.DWORD()
    size=sizefn(str(path),ct.byref(ignored))
    assert 0<size<=1024*1024,'file version resource missing or excessive'
    data=ct.create_string_buffer(size)
    must(getfn(str(path),0,size,data))
    pointer,length=ct.c_void_p(),wt.UINT()
    must(query(data,'\\',ct.byref(pointer),ct.byref(length)))
    assert length.value>=ct.sizeof(FixedInfo)
    info=ct.cast(pointer,ct.POINTER(FixedInfo)).contents
    assert info.signature==0xFEEF04BD,'invalid fixed version signature'
    parts=lambda ms,ls:[ms>>16,ms&65535,ls>>16,ls&65535]
    return {'file_version':parts(info.fileMS,info.fileLS),'product_version':parts(info.productMS,info.productLS),
        'resource_api_provider':{'path':str(api_path),**pin(api_path)}}
def collect_loaded_hip_identity(stage):
    assert os.name=='nt' and ct.sizeof(ct.c_void_p)==8 and ct.sizeof(ct.c_int)==4
    stage=Path(stage).resolve()
    system32=Path(os.environ['SYSTEMROOT'])/'System32'
    kernel=ct.WinDLL(str(system32/'kernel32.dll'),use_last_error=True)
    current=typed(kernel,'GetCurrentProcess',[],wt.HANDLE)
    enum=typed(kernel,'K32EnumProcessModules',[wt.HANDLE,ct.POINTER(wt.HMODULE),wt.DWORD,ct.POINTER(wt.DWORD)],wt.BOOL)
    modulepath=typed(kernel,'GetModuleFileNameW',[wt.HMODULE,wt.LPWSTR,wt.DWORD],wt.DWORD)
    infofn=typed(kernel,'K32GetModuleInformation',[wt.HANDLE,wt.HMODULE,ct.POINTER(ModuleInfo),wt.DWORD],wt.BOOL)
    proc=typed(kernel,'GetProcAddress',[wt.HMODULE,ct.c_char_p],ct.c_void_p)
    loaded=typed(kernel,'GetModuleHandleW',[wt.LPCWSTR],wt.HMODULE)
    process=current()
    handles=(wt.HMODULE*1024)()
    needed=wt.DWORD()
    must(enum(process,handles,ct.sizeof(handles),ct.byref(needed)))
    assert needed.value<=ct.sizeof(handles) and needed.value%ct.sizeof(wt.HMODULE)==0,'module snapshot capacity'
    count=needed.value//ct.sizeof(wt.HMODULE)
    assert 0<count<=1024
    snapshot={int(handles[i]) for i in range(count)}
    assert len(snapshot)==count,'duplicate module handle snapshot'
    rows=[]
    for handle in sorted(snapshot):
        buffer=ct.create_unicode_buffer(32768)
        length=modulepath(handle,buffer,len(buffer))
        assert 0<length<len(buffer),'module path missing/truncated'
        path=Path(buffer.value).resolve()
        mi=ModuleInfo()
        must(infofn(process,handle,ct.byref(mi),ct.sizeof(mi)))
        exports={name:int(proc(handle,name.encode()) or 0) for name in APIS}
        rows.append({'handle':handle,'path':str(path),'base_address':int(mi.base),'image_size':int(mi.size),'exports':exports})
    selected=select_loaded_runtime(rows,snapshot,stage)
    path=Path(selected['path'])
    assert int(loaded(str(path)) or 0)==selected['handle'],'provider no longer loaded at exact path'
    before=pin(path)
    # Bind newly observed loaded file to its existing installed package RECORD.
    site=stage/'Lib/site-packages'
    relative=path.relative_to(site).as_posix()
    record_matches=[]
    for record in site.glob('*.dist-info/RECORD'):
        for name,digest,size in csv.reader(record.open(encoding='utf-8',newline='')):
            if name==relative:
                expected='sha256='+base64.urlsafe_b64encode(bytes.fromhex(before['sha256'])).rstrip(b'=').decode()
                assert digest==expected and size==str(before['bytes']),'loaded file differs from selected installed RECORD'
                record_matches.append({'path':str(record),**pin(record),'member':name,'hash':digest,'bytes':size})
    assert len(record_matches)==1,'loaded HIP module package ownership missing/ambiguous'
    version=file_version(path,system32)
    results={}
    signature=ct.CFUNCTYPE(ct.c_int,ct.POINTER(ct.c_int))
    for name in APIS:
        # No WinDLL/LoadLibrary of the HIP module: invoke exact verified address.
        assert int(loaded(str(path)) or 0)==selected['handle']
        value=ct.c_int(-1)
        status=int(signature(selected['exports'][name])(ct.byref(value)))
        results[name]={'status':status,'raw_value':value.value,'return_type':'hipError_t / 32-bit C int',
            'argument_type':'int* / 32-bit C int pointer','calling_convention':'C ABI (CFUNCTYPE), Windows AMD64',
            'provider_handle':selected['handle'],'function_address':selected['exports'][name]}
    assert all(r['status']==0 and r['raw_value']>0 for r in results.values()),'HIP version API failure'
    assert int(loaded(str(path)) or 0)==selected['handle'] and pin(path)==before,'module identity changed during collection'
    return {'loaded_module':{**selected,**before,**version,'installed_RECORD':record_matches[0]},
        'APIs':results,'module_snapshot':rows,'module_count':len(rows),'collector_tensor_calls':0,'collector_kernel_calls':0,
        'HIP_library_load_calls_by_collector':0,'Windows_display_driver_version':'not_measured; separate evidence class',
        'official_SKU_support':'not established by version APIs','version_encoding':'HIP_VERSION_MAJOR*10000000 + HIP_VERSION_MINOR*100000 + HIP_VERSION_PATCH',
        'version_encoding_source':'bundled hip_runtime_api.h and hip_version.h'}
