"""New pure fail-closed selection contracts; no library loading or API calls."""
from pathlib import Path
APIS=('hipRuntimeGetVersion','hipDriverGetVersion')
def select_loaded_runtime(modules,loaded_handles,stage):
    candidates=[m for m in modules if any(m['exports'].get(n) for n in APIS)]
    assert len(candidates)==1,'missing or ambiguous loaded HIP API provider'
    m=candidates[0]
    assert m['handle'] in loaded_handles and m['handle']>0,'provider is not in actual loaded snapshot'
    assert Path(m['path']).resolve().is_relative_to(Path(stage).resolve()),'HIP provider outside selected stage'
    assert all(m['exports'].get(n) for n in APIS),'required HIP version API unavailable'
    assert m['base_address']==m['handle'] and m['image_size']>0,'module image bounds'
    assert all(m['base_address']<=m['exports'][n]<m['base_address']+m['image_size'] for n in APIS),'forwarded/outside-image API address'
    return m
