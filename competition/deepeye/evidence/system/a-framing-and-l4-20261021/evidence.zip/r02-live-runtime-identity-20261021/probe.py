"""One torch import and read-only loaded-HIP identity, no tensor/kernel APIs."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import site
import struct
import sys
import time
import traceback
D=Path(__file__).resolve().parent
P=json.loads((D/'prepared.json').read_bytes())
STAGE=Path(P['stage'])
sys.path.insert(0,str(D))
from collector import collect_loaded_hip_identity,pin
assert Path(sys.executable).resolve()==STAGE/'Scripts/python.exe'
assert sys.implementation.name=='cpython' and sys.version_info[:2]==(3,12) and struct.calcsize('P')==8
assert pin(sys._base_executable)==P['base_executable_pin']
sys.prefix=sys.exec_prefix=str(STAGE)
events=[]
imports=[]
loads=[]
def audit(event,args):
    if event in ('socket.connect','socket.connect_ex','socket.sendto','socket.getaddrinfo','socket.gethostbyname','socket.gethostbyaddr'):
        events.append(event)
        raise RuntimeError('read-only identity process forbids network')
    if event=='import' and args[0]=='torch': imports.append('torch module import event')
    if event=='ctypes.dlopen': loads.append(str(args[0]))
    if event=='open' and not isinstance(args[0],int):
        mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writing and not Path(args[0]).resolve().is_relative_to(D):
            events.append('outside write')
            raise RuntimeError('only new owned output/cache writes')
    if event in ('os.mkdir','os.remove','os.rmdir','os.chmod','os.utime','os.truncate') and not Path(args[0]).resolve().is_relative_to(D):
        events.append('outside mutation')
        raise RuntimeError('installed environment read only')
    if event in ('os.symlink','os.link','os.startfile','os.startfile/2','os.system','subprocess.Popen'):
        events.append(event)
        raise RuntimeError('unselected side effect')
sys.addaudithook(audit)
def save(name,value):
    with (D/'evidence'/name).open('x',encoding='utf-8',newline='\n') as f: json.dump(value,f,indent=2,ensure_ascii=False)
save('ready.json',{'pid':os.getpid(),'base_executable':sys._base_executable})
deadline=time.monotonic()+15
while not (D/'evidence/release.json').exists():
    assert time.monotonic()<deadline
    time.sleep(.02)
identity=json.loads((D/'evidence/release.json').read_bytes())
assert identity['pid']==os.getpid() and identity['image_sha256']==P['base_executable_pin']['sha256']
result={'status':'failed','started_utc':datetime.now(timezone.utc).isoformat(),'actual_probe_count':1,
    'collector_tensor_calls':0,'collector_kernel_calls':0,'pid':os.getpid(),'ppid':os.getppid(),
    'python_version':sys.version,'independent_live_image':identity}
try:
    for p,expected in P['pins'].items(): assert pin(p)==expected,p
    site.addsitedir(str(STAGE/'Lib/site-packages'))
    import torch
    result['torch_build_marker']={'version':torch.__version__,'file':torch.__file__,'hip':torch.version.hip,'cuda':torch.version.cuda}
    assert Path(torch.__file__).resolve().is_relative_to(STAGE)
    assert torch.__version__=='2.12.0+rocm7.14.1' and str(torch.version.hip).startswith('7.14') and torch.version.cuda is None
    result['identity']=collect_loaded_hip_identity(STAGE)
    assert len(imports)==1,'more than one initial torch module import event'
    assert not events
    for p,expected in P['pins'].items(): assert pin(p)==expected,p
    result['status']='success'
except BaseException:
    result['error']=traceback.format_exc()
    traceback.print_exc()
finally:
    result.update(torch_module_import_events=imports,ctypes_dlopen_events=loads,prohibited_attempts=events,
        ended_utc=datetime.now(timezone.utc).isoformat(),project_CNN='external_dependency_not_run',
        official_8845H_support='not_established',R02='not_run',C03='not_run',all29='not_run')
    save('raw-result.json',result)
print(json.dumps({'status':result['status'],'loaded_module':result.get('identity',{}).get('loaded_module'),
    'APIs':result.get('identity',{}).get('APIs'),'error':result.get('error')}),flush=True)
raise SystemExit(0 if result['status']=='success' else 1)
