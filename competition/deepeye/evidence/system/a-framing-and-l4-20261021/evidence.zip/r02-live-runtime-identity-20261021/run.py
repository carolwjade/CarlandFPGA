"""Freeze API provenance/code then execute exactly one bounded actual process."""
import ast
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback
D=Path(__file__).resolve().parent
ROOT=D.parents[2]
B=D.parent
STAGE=ROOT/'.local/deepeye-rocm-7.14.1-cp312-gfx1103'
def pin(p):
    p=Path(p)
    with p.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':p.stat().st_size,'sha256':sha}
def load(p): return json.loads(Path(p).read_bytes())
def save(name,value):
    with (D/name).open('x',encoding='utf-8',newline='\n') as f: json.dump(value,f,indent=2,ensure_ascii=False)
assignment=load(D/'assignment.json')
assert assignment['actual_probe_count']==1 and assignment['new_kernel_count']==0
assert pin(D/'design-plan.md')['sha256']==assignment['design_sha256']=='6617016a63c42629fcb9b44ed580b091ae83d9b4e284d24d094d2f3669265cfd'
scope=load(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
assert hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==assignment['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=load(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
assert transfer['status']=='active' and transfer['director_generation']==2 and transfer['new_director_thread_id']==assignment['selected_by']
assert load(D/'contract-controls-result.json')['status']=='success'
prior=load(B/'r02-runtime-install-20261021/installation-summary.json')
assert prior['status']=='success' and prior['installation']['packages']==17
assert load(B/'r02-runtime-main-review-20261021/review.json')['status']=='ACCEPT_OFFLINE_INSTALL_AND_ONE_REAL_AMD_KERNEL'
header=STAGE/'Lib/site-packages/_rocm_sdk_core/include/hip/hip_runtime_api.h'
version_header=header.parent/'hip_version.h'
text=header.read_text(encoding='utf-8')
assert 'hipError_t hipRuntimeGetVersion(int* runtimeVersion);' in text and 'hipError_t hipDriverGetVersion(int* driverVersion);' in text
assert 'HIP_VERSION_MAJOR * 10000000 + HIP_VERSION_MINOR * 100000 + HIP_VERSION_PATCH' in version_header.read_text()
snippets={}
for name in ('hipDriverGetVersion','hipRuntimeGetVersion'):
    at=text.index('hipError_t '+name)
    start=text.rfind('/**',0,at)
    snippets[name]=text[start:text.index(';',at)+1]
save('api-provenance.json',{'HIP_header':{'path':str(header),**pin(header)},'HIP_version_header':{'path':str(version_header),**pin(version_header)},
    'declarations_and_documentation':snippets,'C_ABI':'C linkage; hipError_t and int 32 bits; CFUNCTYPE c_int POINTER(c_int); process AMD64',
    'Microsoft_documentation':[
        'https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-enumprocessmodules',
        'https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-getmodulefilenamew',
        'https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-getmoduleinformation',
        'https://learn.microsoft.com/en-us/windows/win32/api/winver/nf-winver-getfileversioninfow',
        'https://learn.microsoft.com/en-us/windows/win32/api/winver/nf-winver-verqueryvaluew'],
    'Windows_API_provider_selection':'fixed System32 kernel32/version only; HIP uses GetProcAddress of an already loaded module handle'})
runner=B/'r02-amd-wheel-acquisition-20261021'
oldpins=load(runner/'incoming-pins.json')['files']
pins={}
for name in ('win_job.py','boundary.py'):
    assert pin(runner/name)==oldpins[str(runner/name)]
    pins[str(runner/name)]=pin(runner/name)
base=Path(sys._base_executable)
assert pin(base)==prior['runtime_binding']['base_pin']
for p in [base,Path(sys.base_prefix)/'python312.dll',STAGE/'Scripts/python.exe',STAGE/'pyvenv.cfg',header,version_header,
          D/'assignment.json',D/'design-plan.md',D/'api-provenance.json',D/'contract-controls-result.json',
          ROOT/'docs/competition/deepeye-2026/immutable_scope.json',ROOT/'docs/competition/deepeye-2026/immutable_scope.md',
          ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json',B/'r02-runtime-main-review-20261021/review.json']:
    pins[str(p)]=pin(p)
for p in D.glob('*.py'):
    tree=ast.parse(p.read_text(encoding='utf-8'))
    if p.name in ('collector.py','probe.py'):
        assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'tensor','matmul','synchronize','zeros','ones','randn','empty'} for n in ast.walk(tree)),'unselected tensor/kernel API in collector source'
    pins[str(p)]=pin(p)
save('prepared.json',{'stage':str(STAGE),'pins':pins,'base_executable_pin':pin(base),'actual_probe_count':1,'new_kernel_count':0,
    'old_tests_repeated':False,'frozen_utc':datetime.now(timezone.utc).isoformat()})
for name in ('evidence','runs','cache','tmp','userhome','appdata','localappdata'): (D/name).mkdir()
sys.path.insert(0,str(runner))
from win_job import run_bounded,process_identity
env={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR')}
env.update(PATH='',TEMP=str(D/'tmp'),TMP=str(D/'tmp'),USERPROFILE=str(D/'userhome'),HOME=str(D/'userhome'),
    APPDATA=str(D/'appdata'),LOCALAPPDATA=str(D/'localappdata'),XDG_CACHE_HOME=str(D/'cache'),
    TORCH_HOME=str(D/'cache/torch'),TORCH_EXTENSIONS_DIR=str(D/'cache/torch-extensions'),
    HIP_CACHE_PATH=str(D/'cache/hip'),AMD_COMGR_CACHE_DIR=str(D/'cache/comgr'),TRITON_CACHE_DIR=str(D/'cache/triton'),
    PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
argv=[str(STAGE/'Scripts/python.exe'),'-I','-S','-B','-X','utf8',str(D/'probe.py')]
budget={'seconds':60,'active_processes':4,'process_memory_bytes':2*1024**3,'job_memory_bytes':3*1024**3,
    'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':16*1024**2,'tree_entries':512,
    'free_reserve_bytes':512*1024**2}
save('command.json',{'argv':argv,'environment':env,'budget':budget,'collector_HIP_LoadLibrary_calls':0})
def on_tick(job,pids):
    ready=D/'evidence/ready.json'
    release=D/'evidence/release.json'
    if ready.exists() and not release.exists():
        identity=load(ready)
        assert identity['pid'] in pids
        observed=process_identity(identity['pid'],job)
        assert Path(observed['image'])==Path(identity['base_executable']) and observed['image_sha256']==pin(base)['sha256']
        save('evidence/release.json',observed)
outcome={'status':'failed','work_id':assignment['work_id'],'job_id':'child-febba1e2180146a7a386821adc0847fa'}
try:
    terminal=run_bounded(argv,env,D,D/'runs/actual',budget,[D/'evidence',D/'runs',D/'cache',D/'tmp'],on_tick=on_tick)
    outcome['terminal']=terminal
    assert terminal['all_processes_terminated'] and terminal['active_processes_final']==0 and not terminal['faults']
    assert terminal['held_members'] and all(m['signaled'] and m['wait_result']==0 for m in terminal['held_members'])
    raw=load(D/'evidence/raw-result.json')
    outcome['raw']=raw
    assert raw['pid'] in [m['pid'] for m in terminal['held_members']]
    assert terminal['status']=='success' and terminal['exit_code']==0 and raw['status']=='success'
    for p,expected in pins.items(): assert pin(p)==expected,p
    outcome['status']='success'
except BaseException:
    outcome['error']=traceback.format_exc()
finally:
    outcome.update(actual_probe_count=1,new_tensor_calls=0,new_kernel_calls=0,old_tests_repeated=False,
        ended_utc=datetime.now(timezone.utc).isoformat(),R02='not_run',C03='not_run',all29='not_run')
    save('result.json',outcome)
print(json.dumps({'status':outcome['status'],'raw':outcome.get('raw'),'error':outcome.get('error')}),flush=True)
raise SystemExit(0 if outcome['status']=='success' else 1)
