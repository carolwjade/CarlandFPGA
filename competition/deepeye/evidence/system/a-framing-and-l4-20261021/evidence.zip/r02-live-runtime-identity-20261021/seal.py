"""Seal the one actual identity collection, no new torch/API execution."""
import hashlib
import json
from pathlib import Path
D=Path(__file__).resolve().parent
def load(p): return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p)
    with p.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':p.stat().st_size,'sha256':sha}
def save(name,value):
    with (D/name).open('x',encoding='utf-8',newline='\n') as f: json.dump(value,f,indent=2,ensure_ascii=False)
p=load(D/'prepared.json')
result=load(D/'result.json')
raw=load(D/'evidence/raw-result.json')
t=load(D/'runs/actual/terminal.json')
assert result['status']==raw['status']==t['status']=='success' and t['exit_code']==0
assert t['all_processes_terminated'] and t['active_processes_final']==0 and not t['faults']
assert all(m['signaled'] and m['wait_result']==0 for m in t['held_members'])
assert raw['pid'] in [m['pid'] for m in t['held_members']]
assert len(raw['torch_module_import_events'])==1 and not raw['prohibited_attempts']
identity=raw['identity']
module=identity['loaded_module']
apis=identity['APIs']
assert all(v['status']==0 and v['provider_handle']==module['handle'] for v in apis.values())
for name,value in p['pins'].items(): assert pin(name)==value,name
record=module['installed_RECORD']
record_file=pin(record['path'])
assert record_file['sha256']==record['sha256'] and int(record['bytes'])==module['bytes']
decoded={name:{'major':v['raw_value']//10000000,'minor':v['raw_value']//100000%100,
               'patch':v['raw_value']%100000} for name,v in apis.items()}
summary={'status':'success','work_id':result['work_id'],'job_id':result['job_id'],
    'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    'torch_build_marker':raw['torch_build_marker'],'actual_loaded_module':module,
    'installed_RECORD_binding':{'record_file':{'path':record['path'],**record_file},
        'member':record['member'],'member_bytes':int(record['bytes']),'member_hash':record['hash'],
        'raw_schema_note':'raw installed_RECORD.bytes denotes matched member bytes; RECORD file bytes are separately pinned here'},
    'HIP_version_APIs':apis,'HIP_version_decoded_per_bundled_headers':decoded,
    'module_file_resource_version_is_not_HIP_API_or_Windows_display_driver_version':True,
    'Windows_display_driver_version':'not measured in this task; not inferred from hipDriverGetVersion',
    'official_8845H_support':'not established; experimental current runtime evidence only',
    'new_actual_processes_selected':1,'torch_module_import_events':len(raw['torch_module_import_events']),
    'collector_HIP_LoadLibrary_calls':0,'collector_tensor_calls':0,'collector_kernel_calls':0,
    'new_contract_controls':7,'old_tests_repeated':False,'retries':0,'installed_environment_changed':False,
    'module_snapshot_count':identity['module_count'],'original_held_processes':len(t['held_members']),
    'all_original_handles_signaled':True,'peak_job_memory_bytes':t['peak_job_memory_bytes'],
    'terminal':{'path':str(D/'runs/actual/terminal.json'),**pin(D/'runs/actual/terminal.json')},
    'raw_result':{'path':str(D/'evidence/raw-result.json'),**pin(D/'evidence/raw-result.json')},
    'reusable_collector':{'path':str(D/'collector.py'),**pin(D/'collector.py')},
    'API_provenance':{'path':str(D/'api-provenance.json'),**pin(D/'api-provenance.json')},
    'R02':'not_run','C03':'not_run','all29':'not_run','project_CNN':'external_dependency_not_run'}
save('identity-summary.json',summary)
files={str(f.relative_to(D)):pin(f) for f in D.rglob('*') if f.is_file() and 'private' not in f.name.lower()}
save('manifest.json',{'files':files,'module_file':{'path':module['path'],'bytes':module['bytes'],'sha256':module['sha256']},
    'source_pins_unchanged_after_single_actual_probe':True})
text=('已补齐实际加载 HIP 身份：`amdhip64_7.dll`（22,097,408 字节），SHA256：\n\n'
      '`1c7bad4e8ddefc456e5c073d89b59ee0bcfbcda461a5ada145370fe9941df033`\n\n'
      '`hipRuntimeGetVersion` 与 `hipDriverGetVersion` 均返回状态 0、原始值 71460850；按 bundled 头文件编码为 7.14.60850。DLL 文件资源版本为 10.0.3581.0；它们与 Windows 显示驱动版本分别记录，不据此宣称官方 8845H 支持。\n\n'
      '仅一次 torch 导入，采集器未调用张量或计算内核 API；原句柄全部终止，旧测试未重复。C 项目 CNN 仍为外部依赖，R02/C03/all29 保持 not_run。\n\n'
      f'[汇总]({D.as_posix()}/identity-summary.json) · [清单]({D.as_posix()}/manifest.json) · [完成回应]({D.as_posix()}/native-complete-response.json)\n')
with (D/'final-result.txt').open('x',encoding='utf-8',newline='\n') as f: f.write(text)
print(json.dumps({'status':'success','summary':pin(D/'identity-summary.json'),'manifest':pin(D/'manifest.json'),
    'final_text':pin(D/'final-result.txt'),'held_processes':len(t['held_members']),'peak_job_memory_bytes':t['peak_job_memory_bytes']}))
