"""Only new missing/ambiguous/notloaded selection contracts."""
import copy
import json
from pathlib import Path
import sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D))
from contracts import select_loaded_runtime
stage=D/'synthetic-stage'
base={'handle':4096,'base_address':4096,'image_size':4096,'path':str(stage/'runtime.dll'),
      'exports':{'hipRuntimeGetVersion':4352,'hipDriverGetVersion':4608}}
results=[]
for case in ('valid','missing','ambiguous','notloaded','outside','one_API_missing','forwarded_address'):
    rows=[copy.deepcopy(base)]
    handles={4096}
    if case=='missing': rows=[]
    if case=='ambiguous':
        extra=copy.deepcopy(base)
        extra.update(handle=8192,base_address=8192)
        extra['exports']={'hipRuntimeGetVersion':8448,'hipDriverGetVersion':8704}
        rows.append(extra)
        handles.add(8192)
    if case=='notloaded': handles={8192}
    if case=='outside': rows[0]['path']=str(D.parent/'outside.dll')
    if case=='one_API_missing': rows[0]['exports']['hipDriverGetVersion']=0
    if case=='forwarded_address': rows[0]['exports']['hipDriverGetVersion']=99999
    try:
        select_loaded_runtime(rows,handles,stage)
        accepted,reason=True,None
    except AssertionError as e: accepted,reason=False,str(e)
    results.append({'case':case,'accepted':accepted,'pass':accepted==(case=='valid'),'reason':reason})
out={'status':'success' if all(x['pass'] for x in results) else 'failed','controls':results,
    'torch_imports':0,'API_calls':0,'old_tests_repeated':False}
with (D/'contract-controls-result.json').open('x',encoding='utf-8') as f: json.dump(out,f,indent=2)
print(json.dumps(out))
raise SystemExit(0 if out['status']=='success' else 1)
