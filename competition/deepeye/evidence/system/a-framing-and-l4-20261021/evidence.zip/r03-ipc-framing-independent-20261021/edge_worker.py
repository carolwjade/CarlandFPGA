"""Independent, narrow edge cases for the inactive opaque framing leaf."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import unittest

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
PRODUCT = ROOT / '.local/deepeye-implementation-a/competition/deepeye'
RUN = Path(sys.argv[1]).resolve()
assert RUN.is_relative_to(D)
SOURCE = PRODUCT / 'simulation/isolation/ipc_framing.py'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == 'a134af7e8ade69a4624abf780575785dff76612454cf83f0ec92ff8b1da0ee09'
attempts = []


def audit(event, args):
    if event in {'subprocess.Popen', 'os.system', 'os.startfile', 'os.startfile/2',
                 'socket.connect', 'socket.bind', 'socket.sendto', 'socket.getaddrinfo'}:
        attempts.append(event)
        raise RuntimeError('external execution/network forbidden')
    if event == 'open' and not isinstance(args[0], int):
        p = Path(args[0]).resolve()
        mode, flags = args[1:3]
        writing = (isinstance(mode, str) and any(c in mode for c in 'wax+')) or (
            isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC))
        if writing and not p.is_relative_to(RUN):
            attempts.append('unowned_write')
            raise RuntimeError('unowned write')


sys.addaudithook(audit)
spec = importlib.util.spec_from_file_location('reviewed_ipc_framing', SOURCE)
framing = importlib.util.module_from_spec(spec)
spec.loader.exec_module(framing)


class IndependentEdges(unittest.TestCase):
    def retired(self, decoder):
        self.assertTrue(decoder._closed)
        self.assertEqual(len(decoder._buffer), 0)
        self.assertIsNone(decoder._payload_size)
        for call in (lambda: decoder.feed(b''), lambda: decoder.feed(framing.encode_frame(b'x')),
                     decoder.finish):
            with self.assertRaises(ValueError):
                call()

    def test_maximum_frame_tail_then_coalesced_next_frame(self):
        maximum = bytes(range(256)) * 64
        wire = framing.encode_frame(maximum) + framing.encode_frame(b'next')
        decoder = framing.FrameDecoder()
        self.assertEqual(decoder.feed(wire[:8192]), ())
        self.assertEqual(decoder.feed(wire[8192:16384]), ())
        self.assertEqual(decoder.feed(wire[16384:]), (maximum, b'next'))
        decoder.finish()
        self.retired(decoder)

    def test_four_complete_then_partial_fifth_across_calls(self):
        frame = framing.encode_frame(b'x')
        decoder = framing.FrameDecoder()
        self.assertEqual(decoder.feed(frame * 4 + frame[:4]), (b'x',) * 4)
        self.assertEqual(decoder.feed(frame[4:]), (b'x',))
        decoder.finish()
        self.retired(decoder)

    def test_malformed_after_complete_returns_nothing_and_retires(self):
        decoder = framing.FrameDecoder()
        self.assertEqual(decoder.feed(framing.encode_frame(b'earlier')), (b'earlier',))
        with self.assertRaises(ValueError):
            decoder.feed(framing.encode_frame(b'unreturned') + b'\x00\x00\x00\x00')
        self.retired(decoder)

    def test_fifth_completion_after_prior_partial_drops_failing_call(self):
        frame = framing.encode_frame(b'z')
        decoder = framing.FrameDecoder()
        self.assertEqual(decoder.feed(frame[:4]), ())
        with self.assertRaises(ValueError):
            decoder.feed(frame[4:] + frame * 4)
        self.retired(decoder)


result = unittest.TextTestRunner(verbosity=2).run(
    unittest.defaultTestLoader.loadTestsFromTestCase(IndependentEdges))
output = {'testsRun': result.testsRun, 'successful': result.wasSuccessful(),
          'failures': [(str(t), s) for t, s in result.failures],
          'errors': [(str(t), s) for t, s in result.errors],
          'prohibited_attempts': attempts,
          'product_source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest()}
(RUN / 'edge-result.json').write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
raise SystemExit(0 if result.wasSuccessful() and not attempts else 1)
