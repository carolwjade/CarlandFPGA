"""Verify pinned artifacts, then run only new independent edges in a held hidden job."""
import hashlib
import json
import os
from pathlib import Path
import sys

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
AUTHOR = D.parent / 'r03-ipc-framing-implementation-20261021'
SUPPORT = D.parent / 'r02-transient-quota-fix-20261021'
PRODUCT = ROOT / '.local/deepeye-implementation-a/competition/deepeye'
for name, expected in {
    'win_job.py': '80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d',
    'boundary.py': '04cf7d53f3dbf1fca66aab05fe497ae193aab94a56ab4e0d36e81d1eb0a040fe',
}.items():
    assert hashlib.sha256((SUPPORT / name).read_bytes()).hexdigest() == expected
sys.path.insert(0, str(SUPPORT))
from win_job import run_bounded
from boundary import save_new


def digest(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


assignment = json.loads((D / 'assignment.json').read_text(encoding='utf-8'))
scope = json.loads((ROOT / 'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
canonical = json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True,
                       separators=(',', ':')).encode('utf-8')
scope_hash = hashlib.sha256(canonical).hexdigest()
assert scope_hash == assignment['requirements_sha256'] == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
assert [item['id'] for item in scope['requirements']] == [f'H{i:02d}' for i in range(1, 16)]
assert digest(AUTHOR / 'artifact-manifest.json')['sha256'] == assignment['author_manifest_sha256']
manifest = json.loads((AUTHOR / 'artifact-manifest.json').read_text(encoding='utf-8'))
assert len(manifest['files']) == 26
for rel, expected in manifest['files'].items():
    assert digest(AUTHOR / rel) == expected, rel
for rel, expected in assignment['product_pins'].items():
    assert digest(ROOT / '.local/deepeye-implementation-a' / rel) == expected, rel
red = json.loads((AUTHOR / 'red-01/test-result.json').read_text(encoding='utf-8'))
green = json.loads((AUTHOR / 'green-01/test-result.json').read_text(encoding='utf-8'))
assert red['testsRun'] == 9 and len(red['failures']) == 9 and not red['errors']
assert all('bounded byte framing has not been implemented' in x['traceback'] for x in red['failures'])
assert green['testsRun'] == 9 and green['successful'] and not green['failures'] and not green['errors']
assert not red['prohibited_attempts'] and not green['prohibited_attempts']
for label, code in [('red-01', 1), ('green-01', 0)]:
    terminal = json.loads((AUTHOR / label / 'terminal.json').read_text(encoding='utf-8'))
    assert terminal['exit_code'] == code and terminal['all_processes_terminated']
    assert terminal['active_processes_final'] == 0
    assert all(x['signaled'] and x['wait_result'] == 0 for x in terminal['held_members'])

run = D / 'edge-01'
run.mkdir()
save_new(run / 'artifact-check.json', {
    'requirements_sha256': scope_hash, 'H01_H15_present': True,
    'author_manifest_sha256': digest(AUTHOR / 'artifact-manifest.json')['sha256'],
    'manifest_entries_verified': len(manifest['files']),
    'product_pins_verified': assignment['product_pins'],
    'author_red': '9 missing-implementation assertion failures, 0 errors, held exit 1',
    'author_green': '9 pass, 0 errors, held exit 0',
})
env = {k: v for k, v in os.environ.items() if k.upper() in ('SYSTEMROOT', 'WINDIR')}
env.update(PATH='', TEMP=str(run), TMP=str(run), PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')
budget = {'seconds': 30, 'job_memory_bytes': 512 * 1024**2,
          'process_memory_bytes': 256 * 1024**2, 'active_processes': 4,
          'stdout_bytes': 256 * 1024, 'stderr_bytes': 512 * 1024,
          'tree_bytes': 16 * 1024**2, 'tree_entries': 300,
          'free_reserve_bytes': 512 * 1024**2}
argv = [str(ROOT / '.local/venv/Scripts/python.exe'), '-I', '-S', '-B', '-X', 'utf8',
        str(D / 'edge_worker.py'), str(run)]
save_new(run / 'started.json', {'argv': argv, 'budget': budget, 'environment': env, 'cwd': str(D)})
terminal = run_bounded(argv, env, D, run / 'process', budget, [run])
save_new(run / 'terminal.json', terminal)
assert terminal['all_processes_terminated'] and terminal['active_processes_final'] == 0
assert all(x['signaled'] and x['wait_result'] == 0 for x in terminal['held_members'])
print(json.dumps({'exit_code': terminal['exit_code'], 'seconds': terminal['seconds'],
                  'all_processes_terminated': terminal['all_processes_terminated'],
                  'active_processes_final': terminal['active_processes_final'],
                  'held_members': terminal['held_members'], 'stop_reason': terminal['stop_reason']}))
raise SystemExit(0 if terminal['exit_code'] == 0 else 1)
