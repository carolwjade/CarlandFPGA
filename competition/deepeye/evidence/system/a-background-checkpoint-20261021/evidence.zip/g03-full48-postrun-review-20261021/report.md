# Independent audit of the saved centered full48 diagnostic

Work `A-G03-FULL48-POSTRUN-REVIEW-20261021-v1`, original job
`child-f5dc5b434185496fa410e6a89fee823b`, owner
`/root/g03_controls_reference_review_20261020`. Native validation allowed this
read-only source/data review and writes only in this folder. Main retains
selection and acceptance.

All 48 recorded complex differences agree with an independent stdlib
recalculation from the original batch03 NPY. The maximum is
**3.470108633346818e-18 V/m**, on global edge **29** (row 25), below the
unchanged **1.967577343353139e-12 V/m** numerical consistency gate. No mismatch
was found in the reviewed saved selection, data, source-pin, counter or process
receipt chain. This job did not repeat the physical/reference calculation.

## Numerical result and limits

The original complete-vector baseline norm remains exactly
0.01957577343353139 V/m. The separately main-selected diagnostic gate is
`1e-14 V/m + 1e-10 * original_full48_norm`, applied to the actual maximum
complex difference. It is neither an original physical-accuracy requirement
nor a receiver-voltage acceptance gate. The threshold was not adjusted.

At edge 29 the original value is
`(-4.6772151624974185e-05, -0.019575717557392007)` V/m, the adaptive value is
`(-4.677215162497425e-05, -0.01957571755739201)` V/m, and the difference is
`(-6.776263578034403e-20, -3.469446951953614e-18)` V/m.
Every row's complex values/difference, exact-zero reason, both estimate levels
and cumulative counters are in `data-audit-v1/delta-g-full48.json`.
The matching complex128 NPY is a frozen diagnostic input for later planning,
not a certified true-field error vector.

All 48 rows bind to the original indices, endpoints and tangents. There are
24 numerical edges and 24 exact geometric-zero routes: axial projection is
zero, or the appropriate reflection leaves distance even and projection odd.
The zero routes did not consume quadrature counters. Each numerical row used
outer component counts [21,21]. Totals are 1008 outer evaluations and 147168
kernel evaluations, under unchanged caps 4096 and 262144. Original absolute
tolerances are 2.5e-16 and relative tolerances 2e-13 at both levels, subdivision
limit 64, soft deadline 45 s and whole-tree hard deadline 50 s.

`saved-estimate-analysis.json` keeps the 48 outer component acceptance checks.
The relative term dominates the absolute term for 24 of those components.
Across numerical edges, the largest outer real/imaginary error estimates are
5.192751964530535e-19 and 2.1733412355775538e-16 V/m; largest observed inner
real/imaginary estimates are 2.9670810217273e-17 and
3.0698700088014327e-15 V/m. The largest stored sum is
3.2902004384155283e-15 V/m. In 24 stored inner-component maxima the estimate
exceeds the absolute tolerance; the actual rule uses
`max(abs_tol, rel_tol*abs(value))`, not the absolute term alone.

The successful run retains inner maxima, not every successful inner
value/target pair, so this audit cannot reconstruct all individual inner
acceptance comparisons from data alone. Source at `centered_reference.py:146–173`
establishes the unchanged rule. The two estimate levels and their sum are
QUADPACK estimates and observed maxima, not certified supremum or global
true-error bounds. The exact-arithmetic Psi series-tail bound has only series
truncation scope; it does not bound floating cancellation or total integration
error. None of these estimates substitutes for the actual saved-vector
difference used by the gate.

## Original selected run and process evidence

The sole run in the candidate's run directory is `centered-full48-v1`, with
16 retained files including three source snapshots. The main selection, config,
pre-science handshake, parent-verified OS identity, grant, payload start and
payload result hashes/ordering agree. The saved timestamps order selection
before run start, then handshake/identity before scientific payload, then
payload completion before tree terminal.

The original live-handle and terminal records bind:

| Held object | PID / PPID | Creation FILETIME | Terminal |
|---|---|---|---|
| launcher | 42060 / 39484 | 134369937572638310 | signaled, exit 0 |
| console | 24104 / 42060 | 134369937572852738 | signaled, exit 0 |
| worker | 12608 / 42060 | 134369937573168930 | signaled, exit 0 |

The original runner records hidden/below-normal execution, assignment while
suspended, own-job membership, resume and all retained handles signaled.
Final job state is active=0, total=3, terminated=0; no timeout or forced
termination. The actual run had driver duration 16.17200000002049 s and tree
duration 17.546999999991385 s, with empty stdout/stderr. Post-terminal source
pins were recorded unchanged and match the present independent hashes.
These are checks of the original retained process evidence, not new
observations of processes which have already terminated.

The actual worker's NumPy and SciPy BLAS queries both read one thread before
and after the driver and bind the same PID and DLL hashes. The execution record
contains one `reference_edges` call, 48 zero tests, 24 physical-integrand and
nested-average calls, 2064 `_quad` calls, and 147168 calls each to component,
integrand, centered kernel and Psi. The 24 retained nested results equal the
24 numerical answer records. No sampler entry calls, retry, quadrature refusal
file or tolerance relaxation appears in this actual run.

Core identities independently verified:

- Candidate 20-file manifest:
  `ede7c85ca867f889b3aefaf0aa745baf1b9e457533307d9d7b5cd7192a17e9ec`.
- Source review 43-file manifest:
  `4709d866a5c5c84c0c0e1a0c04ce32a87550c81c0ab081e6630ef35f4f9bcc38`;
  its original native completion is terminal with exact persisted text.
- 62-target candidate pins:
  `871081c441171b212c2b8d133e02de433f4961451d9314cd2157b4baa4b6b14d`;
  all 4008 saved dependency pins rechecked.
- Actual comparison:
  `3864f5903839550867bda610218bc52ae3bdf56a7947c67fbdd95e4d2424012d`.
- Payload result:
  `82cd8969bc6153d1a2a5977f7e2294b07b3dfa93e849b612d32cba0d93130834`.
- Delta-g NPY:
  `d115ed63e83f7edb88d66e3613366268403efb09c797edb3d3d16aed4c363ff1`.

`source-result-pins.json` records 4165 public external input hashes at final
recheck, plus current result-file hashes. `source-evidence.json` pins 13 exact
source/binary files with relevant line excerpts for the actual tolerance rule
and the proposed finite-model design. The compiled interpolation binary was
hashed only; no scientific source API was imported or executed by this job.

## Preserved failures and qualifications

The main's initial `select.py` shadowed the stdlib module during
`import asyncio -> selectors`. Its retained import-failure record says exit 1
before selection or physical start. `select.failed-source.txt` and renamed
`select_full48.py` are byte-identical, SHA256
`02e2e9838fee14c9eb12625ac305dfa25085aa0d6c5720f14a73585f31a8ccf3`.
The failed name is absent; original failure/source records remain. The failure
was not replayed and no additional process-lifetime claim is made for it.

The two older actual reference attempts remain failed with their original
files/hashes: `main-batch12-20261020-v1` failed the inner real quadrature, and
`regularized-sixedge-v1` failed the inner imaginary quadrature. This successful
run does not rewrite them. The historical 11 numerical batches retain unknown
OS parent/lifetime binding.

`G03-CRIR-OBS01` remains a near-orthogonal floating residual counterexample:
candidate point value zero versus a nonzero exact-input Decimal reference.
It concerns pointwise kernel arithmetic, not an established failure of the
selected saved-vector gate. The original mistaken Psi test literal and its
focused correction remain in that earlier review.

`G03-F48IR-OBS01` remains the omission of unused class metadata. Equality of
the old six rows is qualified to global_index, row, start_m, end_m and tangent.
The computational sources do not read class. The prior independent review's
whole-dictionary assumption failure and contiguous-numerical-row assumption
failure remain alongside its corrected result and process receipts.
No old fixture, candidate, failure or threshold was edited.

## Next dependency design and this job's execution

`finite-coil-transfer-design.md` specifies a minimal proposed W_B(2x36) by
exact finite-disk moments of the chosen trilinear Fz interpolant. It gives
actual-coordinate weights, orientation/units, independent 16-point-per-disk
interpolation controls and constant/affine/bilinear analytical controls.
It then derives the conditional fixed-model map
`T = W_B*C*(P_B-P_I*A_II^-1*A_IB)` (2x48, units m), implemented later through
one factorization and solves. Fixed source RHS/primary terms cancel in a
difference, so source construction is not a dependency of this conditional
sensitivity. Source equivalence and absolute voltage validity remain separate.

The design includes a hand-derived complex matrix oracle, sparse assembly
versus solves, residual/conditioning records, exact frozen delta-g input and
bounded future work. All proposed numerical guards are for main to freeze
before any later execution; no receiver budget or new run was selected here.
The proposed preparation folder was not created. W_B/T were not implemented.

This review executed only two hidden stdlib source/data workers:

| Worker | Exit | Duration | Held objects |
|---|---:|---:|---|
| `data-audit-v1` | 0 | 4.063 s | 51596, 21516, 26896: all signaled/exit 0 |
| `closeout-check-v1` | 0 | 2.953 s | 23548, 21860, 50688: all signaled/exit 0 |

Both private jobs ended empty with no missing/pending handles or faults.
Executed source snapshots and exact receipts remain. There were no scientific
imports, new physical/reference/sampler/Maxwell/receiver calculations,
product writes, board/service/network/UI actions, installs or other agents.

H01–H15 retain contract `DEEPEYE-HUMAN-LOCK-20261014/revision1` and requirements
SHA256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`.
The active director transfer remains generation 2. G03, old18, all29, Maxwell
and receiver formal status remain **not_run**; the **5e-11 V** receiver gate
remains unqualified. Source/mesh/material/receiver physical qualification is
not supplied by this diagnostic agreement or the proposed finite-model T.

The public manifest excludes only private/control reservation files and its
own seal/completion receipts as explicitly listed. The original job is to be
completed exactly once with `final-result.txt`, then its persisted terminal
response and manifest checked read-only; no further writes follow completion.
