# Proposed finite-coil and fixed-model preparation

Design only, for main review. This job has constructed or executed no W_B, T,
Maxwell matrix, solve, receiver functional or physical reference. No new run is
selected. Paths in this document are relative to
`.planning/deepeye-resume-20261018/` unless explicitly prefixed `.local/`.
Exact installed-source hashes and line excerpts are in `source-evidence.json`.

## Fixed scope and evidence inputs

Use the existing unrotated Cartesian TensorMesh with widths
`[[0.6,0.6],[0.6,0.6],[0.6,0.6]]` m and origin `[-0.6,-0.6,-0.85]` m:
8 cells, 54 edges, 36 faces. The x/y/z edge blocks each contain 18 entries.
Boundary order B is the original sorted 48-entry order:

```
[0,1,2,3,4,5,6,7,10,11,12,13,14,15,16,17,18,19,20,21,22,23,
 24,26,27,29,30,31,32,33,34,35,36,37,38,39,41,42,43,44,45,
 46,47,48,50,51,52,53]
```

Interior order I is `[8,9,25,28,40,49]`. Compare the future constructed mesh,
global order, endpoints, tangents and nominal lengths with the original
`g03-boundary-sampler-controls-20261020/geometry.npz` before assembly. Use
normalized tangential E averages in V/m, not edge integrals. The existing
adapter provides partition/reconstruction, not assembly or a solver.

Fix f = 2,000,000 Hz, omega = 2*pi*f, sigma = 0.0005 S/m,
epsilon = 1.77083756256e-10 F/m and mu = 1.2566370614359173e-6 H/m,
homogeneous in all eight cells. These are the existing full48 material values.
Use the peak phasor convention `real(X exp(+i omega t))`.
The two Rx disks have centers `(0,0,0.05)` and `(0,0,0.25)` m, radius
a = 0.02 m, normal +Z and one turn. Do not generalize to tilted disks, another
mesh, frequency or material in this preparation.

The later diagnostic delta g is the exact saved binary64 adaptive-minus-batch03
vector from this review, in the above B order:

- `data-audit-v1/delta-g-full48.npy`, little-endian complex128, shape (48,),
  V/m; SHA256 `d115ed63e83f7edb88d66e3613366268403efb09c797edb3d3d16aed4c363ff1`.
- Canonical value SHA256
  `f18aa2b7d08615a90f9029d7598c2ee04b8583e0b62ff89b47bfd67efb9b1faf`.
- Original baseline file SHA256
  `f1bea7e56f7abc833a9a203eeb192386c48f01c3fb37f3082cdce96264c24afe`;
  comparison JSON SHA256
  `3864f5903839550867bda610218bc52ae3bdf56a7947c67fbdd95e4d2424012d`.

This vector is a numerical comparison, not a certified error against exact
physical boundary data. Do not regenerate it from the sampler or reference.

## Finite disk functional W_B

Proposed definition: integrate the componentwise trilinear Fz interpolant of
the 36 face B degrees of freedom over each disk. Interpreting face values
through this interpolant is an explicit finite-model choice. It does not assert
that the true continuous B field is trilinear or that its face average is a
point measurement.

The installed source uses Fz tensor axes
`(cell_centers_x, cell_centers_y, nodes_z)`, first axis fastest, and places its
12 columns after the 12 Fx and 12 Fy columns. Both complete disks lie inside
one Fz interpolation prism: ideally x,y in [-0.3,0.3] and z in [-0.25,0.35].
Future code must check this against the actual constructed binary coordinates,
including the entire radius, not merely `is_inside(center)`. The library's
default containment test concerns the whole node domain.

At a fixed z the interpolant is bilinear in x,y. For a disk centered at (0,0),
the exact area moments of x, y and xy are zero. Therefore integration of this
chosen interpolant equals S = pi*a^2 times interpolation at the disk center.
This equality follows from the finite basis and disk symmetry; it is not a
physical small-coil approximation.

For actual coordinate endpoints x0,x1,y0,y1,z0,z1, define
`tx=(0-x0)/(x1-x0)`, `ty=(0-y0)/(y1-y0)` and
`tz=(z_Rx-z0)/(z1-z0)`, and basis weights
`lx=(1-tx,tx)`, `ly=(1-ty,ty)`, `lz=(1-tz,tz)`.
For i,j,k in {0,1}, the proposed row coefficient is

`W_B[Rx, 24+i+2*j+4*(k+1)] = S * lx[i] * ly[j] * lz[k]`.

Only global Fz columns 28..35 are nonzero: 28..31 on the lower z plane and
32..35 on the upper. Use actual binary coordinates for every weight; do not
force x/y symmetry or snap tz to ideal fractions. In ideal decimal geometry
the near disk has eight weights S/8; the far disk has four lower weights
S/24 and four upper weights 5S/24. These fractions are explanatory only.
W_B has shape 2x36, units m^2 and includes normal sign and turns. Preserve
complex B and define peak voltage `V = -i*omega*W_B*B`.

Two bounded approaches were considered. Analytic basis moments above are the
minimal proposed implementation for this exact geometry. Direct finite-disk
quadrature of installed interpolation rows is a useful independent control,
and would otherwise add unnecessary quadrature choices to the production
functional. A general adaptive coil integrator is outside this scope.

Independent control proposal: use t = r^2 with two Gauss nodes
`t = a^2*(1 +/- 1/sqrt(3))/2` and eight uniform angles `2*pi*k/8`.
There are 16 points per disk, each area weight S/16. Sum
`get_interpolation_matrix(points, "Fz", zeros_outside=False)` with these
weights and compare all 36 columns with analytic W_B. This rule integrates
the relevant bilinear basis moments; it checks the compiled interpolation
implementation rather than reusing the analytic production weight routine.
The installed Python wrapper delegates to a pinned `.pyd`; its execution has
not been validated by this source-only design.

Additional finite tests: row sums S; exact Fx/Fy zero blocks; expected column
support; constant complex Bz; affine complex Bz = alpha+beta*x+gamma*y+delta*z,
whose expected flux is S*(alpha+delta*z_Rx); and Bz = x*y, whose disk flux is
zero. Expected moments come from the analytical disk integrals, not from the
function being tested. These tests validate the selected interpolation
functional, not mesh or physical coil accuracy.

## Conditional transfer independent of a fixed source RHS

Installed `Simulation3DElectricField.getA(f)` implements the sparse matrix

`A = C.T*MfMui*C + i*omega*Me(sigma+i*omega*epsilon)`.

The metric curl C has shape 36x54, units 1/m, and already includes edge lengths
and inverse face areas. Do not add those factors again. `getA` does not require
the survey RHS: the constructor allows `survey=None`. The minimal proposed
driver supplies only mesh and explicit material properties and calls `getA`
once. Do not call `getRHS`, `getSourceTerm`, `fields`, a source constructor or a
receiver evaluation. Retain the installed permittivity warning as evidence;
its unqualified-model status remains unchanged.

For fixed A, b and prescribed boundary g, interior E satisfies
`A_II*E_I = b_I - A_IB*g`. If A_II is invertible, let P_I and P_B place vectors
in the original 54-entry order and define

`H = P_B - P_I*A_II^-1*A_IB`,   `T = W_B*C*H`.

H is 54x48 and dimensionless; T is 2x48 in m. The inverse denotes algebra
only. Compute H using one factorization and solves, never an explicit inverse.
For unchanged b, `delta E = H*delta g`. Installed field code gives
`B_secondary = (s_m-C*E)/(i*omega)` and adds source primary B. When s_m and
primary B are also fixed independently of g, their differences vanish:
`delta B = -C*delta E/(i*omega)` and hence `delta V = T*delta g`.
No complex conjugation enters this forward map.

This conditional sensitivity is independent of the value of the fixed source
RHS. It does not establish absolute received voltages, continuous-circle versus
segmented-source equivalence, or consistency of a changing source/primary
model. A source change or any change in A/C/W requires a separately bound
model. For this diagnostic use total direct E boundary values consistently;
do not silently apply total g to a secondary-field boundary convention.

Proposed assembly/solve sequence:

1. Bind exact mesh/material/order/delta-g and installed sources. Construct C
   and sparse A; persist canonical CSR shape/data/indices/indptr and hashes.
2. Call existing `eliminate(A, zeros((54,48)), mask, eye(48))`.
   It returns sparse A_II (6x6) and RHS -A_IB (6x48). Factor a copied 6x6
   dense complex A_II once with LU; solve its 48 columns together. Reconstruct
   H through the existing adapter. Assemble W_B, then T = W_B*C*H.
3. With the same LU factors solve one additional RHS `-A_IB*delta_g`;
   reconstruct delta E. Compare `W_B*C*delta_E` with `T*delta_g`.
   This is a second application check, not a second physical source solve.
4. Save A_II, A_IB, H, W_B, T, delta E, complex delta V, per-receiver absolute
   values and `gamma_inf=max_row_sum(abs(T))`. Record the conditional bound
   `||T*delta_g||inf <= gamma_inf*||delta_g||inf`. Floating evaluation of
   this inequality must include its own arithmetic comparison allowance.

Report A_II singular values and kappa_2 from one 6x6 SVD. Refuse singular,
nonfinite or failed factorization; never regularize, change the model or retry.
Record total and per-column normalized backward residuals for X = H[I,:]:
`eta = ||A_II*X+A_IB||inf /
       (||A_II||inf*||X||inf + ||A_IB||inf)`.
If both numerator and denominator are zero, define eta=0; positive numerator
with zero denominator is failure. Also check H[B,:]=identity exactly and
record `A[I,:]*H` residual. For the extra RHS use its corresponding denominator.

Propose freezing a dimensionless algebraic guard `eta <= 128*eps64` before a
future selected run, with analogous scale-normalized 128*eps64 comparisons
for manufactured/flux/application controls. Scale linear products by sums
of absolute term magnitudes, not by a cancellation-small output; zero-scale
comparisons require exact zero. These are proposed algebraic checks, not
receiver voltage error budgets. Main may select them only before execution.
Report kappa_2 and kappa_2 times the residual as diagnostics, not rigorous
forward error certificates; do not invent a conditioning cutoff after seeing
the results or equate backward stability with physical accuracy.

## Independent manufactured matrix control

Before any actual model assembly, use I=[0,2], B=[1,3] and the hand-derived
complex forward example below. This is an abstract algebra test, not a Maxwell
curl or receiver test:

```
A = [[2,2,0,4], [0,1,0,0], [0,8,4,12], [0,0,0,1]]
H_expected = [[-1,-2], [1,0], [-2,-3], [0,1]]
L = [[1,2i,3,4], [0,1,-i,2]]
T_expected = [[-7+2i,-7], [1+2i,2+3i]]
```

Use abstract W=identity(2), C=L, noncontiguous placement and complex inputs.
Expected H/T are literal independent values, not another invocation of the
production solve/transfer function. Test two different fixed b values and the
same pair of g vectors to show that each response difference equals
T_expected*(g2-g1). Include singular A_II, shape/order mismatch and nonfinite
input refusals. These controls exercise sign, order and accidental conjugation.
No manufactured control has been executed in this design-only job.

## Proposed next ownership and finite execution envelope

Main may create a new, disjoint preparation job rooted at
`g03-finite-coil-transfer-preparation-20261021/`. Do not reuse or edit current
review or prior candidates. Proposed files:
`design.json` (frozen dimensions, geometry, units, scope and algebraic guards),
`finite_coil_transfer.py` (pure W_B/partition/solve interfaces),
`manufactured_controls.py`, `fixed_transfer_driver.py`, and source/data/runtime
pins plus a derived handshake runner. This folder was not created here.

Preparation first implements interfaces and the manufactured/constant/affine
controls with inert matrices/fields, records failures, and leaves the actual
model entry point unselected. A separate independent review checks code,
source pins, finite geometry and counters. Only then may main select one fresh
fixed-model diagnostic under a new job/run ID. No selection file is proposed
for creation by this child.

The later actual diagnostic proposal permits one frequency and material,
8 cells, 54 edges, 36 faces, 2 disks, 32 interpolation-control points,
one A assembly, one metric C construction (cached accesses allowed),
one 6x6 LU factorization, 48+1 solved columns and one 6x6 SVD. Bounds include
A at most 2916 entries, C at most 144 nonzeros, W_B at most 16 nonzeros,
H exactly 2592 entries and T exactly 96 entries. Source RHS/fields/sampler/
reference calls are zero. Guard exact source-qualified call sites and matrix
shapes; reject scope expansion or an unexpected scientific entry point.

Retain the reviewed hidden, below-normal, suspended-assigned private-job
handshake: held launcher/console/worker identities, grant before scientific
import, actual NumPy/SciPy BLAS=1 readback before/after in that worker and
post-terminal input hashes. Proposed caps: 45 s cooperative / 50 s whole tree,
4 active processes, 384 MiB per process / 512 MiB job, 128 KiB per stream,
16 MiB and 256 entries in the new run tree, and 512 MiB free reserve.
Allocation sizes are bounded by the above fixed shapes. There is no retry,
refinement, fallback solver or threshold relaxation. The existing reference
kernel/outer caps do not authorize model work; reference call counts stay zero.

Future evidence must contain original source/data pins, exact operator arrays
and ordering, warnings, actual counters, condition/residual results and the
complete process terminal chain. A computed T is conditional finite-model
evidence. Continuous source equivalence, domain/mesh convergence, face-value
interpretation, true finite-coil field accuracy, floating error certification
and material validity remain distinct dependencies. The 5e-11 V receiver gate
is still unqualified; no 1e-11 V boundary allocation is selected. G03, old18,
all29, Maxwell and receiver formal status remain `not_run`.
