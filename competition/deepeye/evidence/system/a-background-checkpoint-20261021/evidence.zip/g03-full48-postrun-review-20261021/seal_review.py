"""Freeze public metadata after completed source/data checks; no scientific code."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

D = Path(__file__).resolve().parent
WORK = "A-G03-FULL48-POSTRUN-REVIEW-20261021-v1"
JOB = "child-f5dc5b434185496fa410e6a89fee823b"
OWNER = "/root/g03_controls_reference_review_20261020"
EXCLUDE = {"lease.private.json", "reserve-request.json",
           "artifact-manifest.json", "seal.json", "native-complete-response.json"}

def record(path):
    assert ".private." not in path.name
    data = path.read_bytes()
    return {"bytes":len(data), "sha256":hashlib.sha256(data).hexdigest()}

def load(path):
    assert ".private." not in path.name
    return json.loads(path.read_bytes())

def write(name, obj):
    with (D/name).open("x", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write("\n")

assert not (D/"native-complete-response.json").exists()
assert load(D/"native-validate-response.json")["execution_allowed"] is True
assert load(D/"native-validate-response.json")["job_id"] == JOB
for run in ("data-audit-v1","closeout-check-v1"):
    t = load(D/run/"terminal.json")
    assert t["status"] == "success" and t["exit_code"] == 0
    assert t["active_processes_final"] == 0 and t["all_processes_terminated"]
    assert len(t["held_members"]) == 3
    assert all(x["signaled"] and x["wait_result"] == 0 and x["exit_code"] == 0
               for x in t["held_members"])
    assert not t["faults"] and not t["absent_before_handle_open"]
    assert not t["empty_job_with_pending_handles"]
    for stream in ("stdout","stderr"):
        assert record(D/run/(stream+".txt")) == t["logs"][stream]
for snapshot, names in {
    "audit-source-snapshots":("audit_actual.py","run_audit.py","win_job.py","boundary.py"),
    "closeout-source-snapshots":("collect_closeout.py","run_closeout_check.py","win_job.py","boundary.py")
}.items():
    for name in names:
        assert (D/name).read_bytes() == (D/snapshot/name).read_bytes()
pins = load(D/"source-result-pins.json")
assert pins["file_count"] == len(pins["files"]) == 4165
for path, expected in pins["this_review_result_inputs"].items():
    assert record(Path(path)) == expected
assert load(D/"input-checks-final.json")["all_original_reviewed_inputs_unchanged"]
assert (D/"report.md").stat().st_size > 1000
assert (D/"finite-coil-transfer-design.md").stat().st_size > 1000
assert (D/"final-result.txt").read_text(encoding="utf-8").strip()
assert not any(n.split(".")[0] in ("numpy","scipy","discretize","simpeg") for n in sys.modules)

files, directories = {}, []
for path in sorted(D.rglob("*")):
    rel = path.relative_to(D).as_posix()
    assert not path.is_symlink()
    if path.is_dir():
        assert path.name != "__pycache__"
        directories.append(rel)
    elif rel not in EXCLUDE:
        assert ".private." not in path.name
        files[rel] = record(path)
write("artifact-manifest.json", {
    "work_id":WORK, "job_id":JOB, "owner":OWNER,
    "files":files, "directories":directories,
    "excluded":sorted(EXCLUDE),
    "scope":"All public assignment-folder files except explicit control/private and self-seal/completion exclusions.",
    "post_completion_policy":"Read-only exact terminal and manifest verification, then stop writes."})
manifest = record(D/"artifact-manifest.json")
write("seal.json", {
    "work_id":WORK, "job_id":JOB, "owner":OWNER,
    "utc":datetime.now(timezone.utc).isoformat(),
    "manifest_sha256":manifest["sha256"], "manifest_bytes":manifest["bytes"],
    "manifest_file_count":len(files), "manifest_directory_count":len(directories),
    "final_result_sha256":record(D/"final-result.txt")["sha256"],
    "complete_original_job_once_after_freeze":True,
    "post_completion_policy":"Read-only terminal/exact and manifest check; then stop writes.",
    "main_selection_acceptance":"reserved"})
print(json.dumps({"manifest_files":len(files), "directories":len(directories),
                  "manifest_sha256":manifest["sha256"],
                  "ready_for_original_native_complete":True}))
