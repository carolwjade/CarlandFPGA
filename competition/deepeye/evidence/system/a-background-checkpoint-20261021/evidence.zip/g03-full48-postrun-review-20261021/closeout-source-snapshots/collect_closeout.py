"""Source text and saved-result closeout only; no scientific imports or execution."""
import hashlib
import json
import math
from pathlib import Path
import sys

D = Path(__file__).resolve().parent
ROOT, BASE = D.parents[2], D.parent
OUT = D / "closeout-check-v1"
assert Path(sys.argv[1]).resolve() == OUT and OUT.is_dir()
SITE = ROOT / ".local/deepeye-fdem-validation-20261020/Lib/site-packages"

def digest(path):
    path = Path(path)
    assert ".private." not in path.name
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}

def load(path):
    assert ".private." not in Path(path).name
    return json.loads(Path(path).read_bytes())

def save(name, obj):
    with (D / name).open("x", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write("\n")

inputs = load(D / "data-audit-v1/reviewed-input-hashes.json")["files"]
for name, record in inputs.items():
    assert digest(name) == record, name
terminal = load(D / "data-audit-v1/terminal.json")
assert terminal["status"] == "success" and terminal["exit_code"] == 0
assert terminal["all_processes_terminated"] and terminal["active_processes_final"] == 0
assert len(terminal["held_members"]) == 3
assert not terminal["faults"] and not terminal["absent_before_handle_open"]
assert not terminal["empty_job_with_pending_handles"]
assert all(r["signaled"] and r["wait_result"] == 0 and r["exit_code"] == 0
           for r in terminal["held_members"])
for name in ("audit_actual.py", "run_audit.py", "win_job.py", "boundary.py"):
    assert (D/name).read_bytes() == (D/"audit-source-snapshots"/name).read_bytes()

specs = [
    (SITE/"discretize/base/base_tensor_mesh.py",
     "56fb85078a2b42184d4b17ec57fa484592d35c20beb76ecd339b50db4edb2b00",
     "Fz tensor, whole-domain containment and componentwise interpolation",
     [(611,616),(638,681),(684,748),(774,790)]),
    (SITE/"discretize/base/base_regular_mesh.py",
     "f6449682a8fed78f4b57353ba1221e19b249653184aee75608cc9a76dbd0b000",
     "Face component shapes and counts", [(693,762)]),
    (SITE/"discretize/utils/interpolation_utils.py",
     "98ad26abec3f09d2035bdab187e166345fde464897ddf19b8c2b4ec8606d8e0d",
     "nD linear interpolation wrapper; compiled kernel delegation",
     [(8,16),(44,56),(153,172)]),
    (SITE/"discretize/utils/matrix_utils.py",
     "ddf4ca7761ba095be5165163047f47e24aeb143dceec5bd38ee26f18fc96e062",
     "First-index-fastest sub2ind order F", [(496,544)]),
    (SITE/"discretize/_extensions/interputils_cython.cp312-win_amd64.pyd",
     "babde320cdbad8b8e0ab044344a3fdc9ec89f9513039490c0a80cb042f53325e",
     "Compiled interpolation binary identity only; not loaded/executed", []),
    (SITE/"discretize/operators/differential_operators.py",
     "f3c7ca3c54a50232202d08bf9768411273fcee7ce95eb5b110a79de6c42db70a",
     "Metric curl includes edge lengths and inverse face areas", [(2169,2181)]),
    (SITE/"simpeg/electromagnetics/frequency_domain/simulation.py",
     "1ba5c85e8e4b3e2b98a1db4589e4eea3a7521e1213fa22f0da12940ecd1b8cba",
     "Optional survey; retained permittivity warning; admittivity A and separate RHS",
     [(68,85),(141,167),(614,651),(835,839)]),
    (SITE/"simpeg/electromagnetics/frequency_domain/fields.py",
     "696931d95997fa38824f3f05cf8927206b96a79ba03ac9250af2b3725ca2ae53",
     "Fixed primary and source terms cancel only in the conditional difference",
     [(469,515)]),
    (SITE/"simpeg/electromagnetics/frequency_domain/receivers.py",
     "51c1879aae78e1e76e10f01452738cb12f350c03e97355a3ed03ecc6293f08dd",
     "Point component interpolation/real-imag selection; not finite area flux",
     [(136,192),(279,294)]),
    (BASE/"g03-prescribed-boundary-adapter-20261020/boundary_adapter.py",
     "c599d2aaf81374b7679bb005f25031bc9f9819ac839b77367031c6daabf6a13b",
     "Normalized E, multi-column elimination/reconstruction and boundary order",
     [(1,5),(23,85),(88,118)]),
    (BASE/"g03-boundary-sampler-preparation-20261020/boundary_sampler.py",
     "507eb9fc9ffe3412cbf540f8e0a5f01c89f40f7d0b167d2c6d0f7bedad0fa570",
     "Original mesh and geometry binding; sampler not imported", [(228,274)]),
    (BASE/"g03-full48-reference-preparation-20261021/centered_reference.py",
     "f796b4a86cec0e8c13e018a03ed736037f18e7923c628d201bfa1c7725371278",
     "Fixed limits; series tail; actual relative acceptance and two estimate levels",
     [(15,23),(33,53),(146,173),(176,227)]),
    (BASE/"g03-full48-reference-preparation-20261021/physical_driver.py",
     "70012d15455858faf6129591be4c259112dafdfeba1b23220d171fc1559759bf",
     "Actual thread query and source-qualified bounded profiler",
     [(31,57),(61,107),(149,202)]),
]
sources = []
for path, expected, purpose, ranges in specs:
    record = digest(path)
    assert record["sha256"] == expected, str(path)
    if str(path) in inputs:
        assert inputs[str(path)] == record
    excerpts = []
    if ranges:
        lines = path.read_text(encoding="utf-8").splitlines()
        for a, b in ranges:
            assert 0 < a <= b <= len(lines), (str(path), a, b, len(lines))
            excerpts.append({"start_line":a, "end_line":b,
                             "lines":[{"line":i, "text":lines[i-1]} for i in range(a,b+1)]})
    sources.append({"path":str(path.resolve()), "repo_path":path.relative_to(ROOT).as_posix(),
                    **record, "purpose":purpose, "excerpts":excerpts})
    inputs[str(path.resolve())] = record

contract_path = BASE/"g03-boundary-sampler-preparation-20261020/sampler-contract.json"
binding_path = BASE/"g03-boundary-sampler-controls-20261020/runs/batch-03/binding.json"
fixture_path = BASE/"g03-full48-reference-preparation-20261021/reference-input-full48.json"
for path in (contract_path, binding_path, fixture_path):
    record = digest(path)
    if str(path) in inputs:
        assert inputs[str(path)] == record
    inputs[str(path.resolve())] = record
contract, binding, fixture = map(load, (contract_path, binding_path, fixture_path))
assert binding["material"] == fixture["material"]
assert contract["fixed_benchmark"]["receiver_geometry_unchanged"] == {
    "centers_m":[[0,0,0.05],[0,0,0.25]], "radius_m":0.02, "normal":[0,0,1], "turns":1}
save("source-evidence.json", {
    "kind":"read_only_local_source_design_evidence",
    "sources":sources,
    "fixed_receiver_geometry":contract["fixed_benchmark"]["receiver_geometry_unchanged"],
    "material":binding["material"], "phasor":binding["phasor"],
    "contract_path":str(contract_path), "contract_pin":digest(contract_path),
    "original_binding_path":str(binding_path), "original_binding_pin":digest(binding_path),
    "reference_fixture_path":str(fixture_path), "reference_fixture_pin":digest(fixture_path),
    "source_APIs_imported_or_executed":False,
    "compiled_interpolation_executed":False, "W_B_T_implemented":False,
    "future_geometry_weights":"actual binary coordinate tensors, no snapping to ideal fractions"})

data = load(D/"data-audit-v1/delta-g-full48.json")
assert digest(D/"data-audit-v1/delta-g-full48.npy")["sha256"] == data["npy_sha256"]
rows = [r for r in data["per_edge"] if r["strict_zero_reason"] is None]
assert len(rows) == 24
outer_checks = []
for row in rows:
    for i, name in enumerate(("real","imag")):
        value, error = row["adaptive_value"][i], row["estimate"]["outer_component_errors"][i]
        relative_term = 2e-13*abs(value)
        threshold = max(2.5e-16, relative_term)
        assert error <= threshold
        outer_checks.append({"global_index":row["global_index"], "component":name,
                             "value_V_m":value,"estimate_V_m":error,
                             "absolute_term_V_m":2.5e-16,
                             "relative_term_V_m":relative_term,
                             "accepted_threshold_V_m":threshold,
                             "relative_term_dominates":relative_term > 2.5e-16})
stats = {
    "outer_checks":outer_checks,
    "relative_term_dominant_outer_components":sum(x["relative_term_dominates"] for x in outer_checks),
    "outer_components":len(outer_checks),
    "max_outer_component_error_estimates_V_m":[max(r["estimate"]["outer_component_errors"][i]
                                                 for r in rows) for i in (0,1)],
    "max_observed_inner_component_error_estimates_V_m":[
        max(r["estimate"]["max_observed_inner_component_errors"][i] for r in rows) for i in (0,1)],
    "max_combined_diagnostic_error_estimate_V_m":
        max(r["estimate"]["combined_diagnostic_error_estimate"] for r in rows),
    "inner_maxima_above_absolute_term":sum(e>2.5e-16 for r in rows
        for e in r["estimate"]["max_observed_inner_component_errors"]),
    "inner_per_call_value_target_pairs_retained":False,
    "limitation":"Observed maxima do not reconstruct every successful inner value/target pair. "
                 "Neither estimate level nor their sum is a strict global bound or replaces actual differences.",
    "max_difference_edge_record":next(r for r in data["per_edge"] if r["global_index"]==29),
    "reference_math_reexecuted":False}
save("saved-estimate-analysis.json", stats)
assert not any(n.split(".")[0] in ("numpy","scipy","discretize","simpeg") for n in sys.modules)
save("source-result-pins.json", {"files":inputs, "file_count":len(inputs),
                               "scope":"external public inputs rehashed at closeout; no private lease read",
                               "this_review_result_inputs":{
                                  str((D/"data-audit-v1"/n).resolve()):digest(D/"data-audit-v1"/n)
                                  for n in ("independent-actual-full48-result.json","terminal.json",
                                            "delta-g-full48.npy","delta-g-full48.json",
                                            "reviewed-input-hashes.json")}})
save("input-checks-final.json", {
    "all_original_reviewed_inputs_unchanged":True,
    "external_public_inputs_rehashed":len(inputs),
    "source_files_with_excerpts_or_binary_pin":len(sources),
    "first_data_worker_terminal":terminal,
    "audit_executed_source_snapshots_unchanged":True,
    "outer_component_thresholds_rechecked":48,
    "scientific_imports":[],
    "new_reference_sampler_Maxwell_receiver_calls":0,
    "W_B_T_implemented":False, "new_run_selection":False,
    "G03":"not_run","old18":"not_run","all29":"not_run","Maxwell":"not_run","receiver":"not_run"})
print(json.dumps({"inputs_rehashed":len(inputs), "source_records":len(sources),
                  "outer_components":48,
                  "relative_dominant":stats["relative_term_dominant_outer_components"],
                  "max_outer_errors":stats["max_outer_component_error_estimates_V_m"],
                  "max_inner_errors":stats["max_observed_inner_component_error_estimates_V_m"],
                  "max_combined":stats["max_combined_diagnostic_error_estimate_V_m"],
                  "science_imports":[],"W_B_T_implemented":False}))
