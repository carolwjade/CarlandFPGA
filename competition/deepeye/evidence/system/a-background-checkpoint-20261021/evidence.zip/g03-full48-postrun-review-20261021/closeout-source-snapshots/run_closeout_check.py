"""One bounded hidden final source/data rehash; no scientific computation."""
import hashlib
import json
import os
from pathlib import Path
import sys
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
for name,expected in {
    "win_job.py":"127daf70b2aa6cf3e7a299978596766fc310d191d13f6a2165626f719889052d",
    "boundary.py":"dc27aea6104424fbb2ee9109bb5e2adaf90684161e9d43bd2636b5ea4d6f2908"}.items():
    assert hashlib.sha256((D/name).read_bytes()).hexdigest()==expected
sys.path.insert(0,str(D))
from win_job import run_bounded
snap=D/"closeout-source-snapshots";snap.mkdir()
for name in ("collect_closeout.py","run_closeout_check.py","win_job.py","boundary.py"):
    with (snap/name).open("xb") as f:f.write((D/name).read_bytes())
env={"SYSTEMROOT":os.environ["SYSTEMROOT"],"WINDIR":os.environ.get("WINDIR",os.environ["SYSTEMROOT"]),
     "PATH":"","TEMP":str(D),"TMP":str(D),"TMPDIR":str(D),"PYTHONDONTWRITEBYTECODE":"1",
     "PYTHONNOUSERSITE":"1","PYTHONIOENCODING":"utf-8"}
budget={"seconds":30,"active_processes":4,"process_memory_bytes":384*1024**2,
    "job_memory_bytes":512*1024**2,"stdout_bytes":128*1024,"stderr_bytes":128*1024,
    "tree_bytes":16*1024**2,"tree_entries":256,"free_reserve_bytes":512*1024**2}
argv=[str(ROOT/".local/venv/Scripts/python.exe"),"-I","-S","-B","-X","utf8",
      str(D/"collect_closeout.py"),str(D/"closeout-check-v1")]
result=run_bounded(argv,env,D,D/"closeout-check-v1",budget,[D])
assert result["all_processes_terminated"]
print(json.dumps({k:result.get(k) for k in
    ("status","exit_code","seconds","stop_reason","all_processes_terminated","held_members")}))
raise SystemExit(result["exit_code"] if result["exit_code"] is not None else 125)
