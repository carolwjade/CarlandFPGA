# A-G03-FULL48-POSTRUN-REVIEW-20261021-v1

Independent audit of the actual full48 diagnostic. Own only this new directory.
Read mandatory A skill/role, active generation2 transfer, immutable scope md/json;
verify H01-H15 requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Validate this new native job before work and complete this exact job at closeout.
Background only; no GUI/display/board/service/network/vendor/model execution.

Main verified your original source-review job completed/terminal/exact and all
43 manifest files SHA4709d866a5c5c84c0c0e1a0c04ce32a87550c81c0ab081e6630ef35f4f9bcc38,
the root candidate20 manifest SHAede7c85ca867f889b3aefaf0aa745baf1b9e457533307d9d7b5cd7192a17e9ec,
62 candidate pins SHA871081c441171b212c2b8d133e02de433f4961451d9314cd2157b4baa4b6b14d.
Selection and metadata clarification are in ../g03-full48-main-selection-20261021/.
Initial select.py had a stdlib-name collision and failed during import, before
any selection or physical run. Original bytes and failure are preserved; the
byte-identical select_full48.py then made the single fresh selection.

Exactly one real run now exists:
../g03-full48-reference-preparation-20261021/candidate-runs/centered-full48-v1/
Original main-selection-batch12.json is in that candidate directory. Main observed
exit0/complete, one reference call, 48 answers, 24 numeric and24 strict zero routes,
1008 outer/147168 kernel, driver16.172s/tree17.547s, all3 held objects signaled,
actual BLAS1 before/after, max difference3.470108633346818e-18 V/m against
unchanged gate1.967577343353139e-12. These are input claims to check, not adopt.

Independently read full source/input/selection/handshake/grant/OS identity chain,
actual counters, per-edge complex outputs and unchanged post-terminal pins.
Recompute all48 differences and original norm from saved bounded NPY data.
Inspect zero identities, actual driver/thread library/readback and process receipt
ordering. Check aggregate caps/tolerance/fixed original norm, no timeout/retry,
exact payload/config hashes. Do not re-run sampler, reference math, Maxwell,
receiver or any prior numerical result. Stdlib bounded data-only worker allowed
with existing hidden runner and finite limits/held-object closure; no broad tests.

Retain original two failed physical attempts, old11 OS-lineage limitation,
G03-CRIR-OBS01, class-label omission/qualified five-field equality, both independent
test-assumption failures and main import failure. QUADPACK estimates and exact
series tail are not certified global true error. Receiver5e-11V remains unqualified.

After audit, refine the next dependency plan into a concrete minimal preparation:
finite-coil flux functional W_B(2x36) for the actual two centered disks and a
conditional finite-model boundary transfer T(2x48). Use pinned installed
discretize/SimPEG source and existing boundary adapter. Consider whether T can be
computed for fixed A/C/W independently of the fixed source RHS; make that
conditional scope explicit, do not claim missing source equivalence solved.

Specify exact interpolation/finite disk weights/orientation/units, fixed mesh and
material, sparse assembly versus solves, conditioning/residual checks, independent
manufactured matrix and constant/affine-field controls, bounded future run limits
and exact original full48 delta g as diagnostic input. Identify where actual
source/mesh/receiver/model qualification remains separate. Avoid inventing a
receiver error budget or installing a model. Provide precise new preparation
paths and implementation/test steps; do not implement or select a physical run
in this task. Main will choose scope after reading the plan.

Deliver report.md, source/result pins, public non-secret manifest, exact
final-result.txt. Complete once, verify original terminal/exact result, stop
writing. G03/old18/all29/Maxwell/receiver remain not_run.
