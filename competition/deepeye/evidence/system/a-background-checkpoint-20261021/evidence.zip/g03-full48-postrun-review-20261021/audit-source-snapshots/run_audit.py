"""One hidden stdlib-only saved-data audit with retained process handles."""
import hashlib
import json
import os
from pathlib import Path
import sys
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
PRIOR=D.parent/"g03-full48-reference-independent-20261021"
for name,expected in {
    "win_job.py":"127daf70b2aa6cf3e7a299978596766fc310d191d13f6a2165626f719889052d",
    "boundary.py":"dc27aea6104424fbb2ee9109bb5e2adaf90684161e9d43bd2636b5ea4d6f2908"}.items():
    b=(PRIOR/name).read_bytes();assert hashlib.sha256(b).hexdigest()==expected
    with (D/name).open("xb") as f:f.write(b)
sys.path.insert(0,str(D))
from win_job import run_bounded
snap=D/"audit-source-snapshots";snap.mkdir()
for name in ("audit_actual.py","run_audit.py","win_job.py","boundary.py"):
    with (snap/name).open("xb") as f:f.write((D/name).read_bytes())
env={"SYSTEMROOT":os.environ["SYSTEMROOT"],"WINDIR":os.environ.get("WINDIR",os.environ["SYSTEMROOT"]),
     "PATH":"","TEMP":str(D),"TMP":str(D),"TMPDIR":str(D),"PYTHONDONTWRITEBYTECODE":"1",
     "PYTHONNOUSERSITE":"1","PYTHONIOENCODING":"utf-8"}
budget={"seconds":30,"active_processes":4,"process_memory_bytes":384*1024**2,
    "job_memory_bytes":512*1024**2,"stdout_bytes":128*1024,"stderr_bytes":128*1024,
    "tree_bytes":16*1024**2,"tree_entries":256,"free_reserve_bytes":512*1024**2}
argv=[str(ROOT/".local/venv/Scripts/python.exe"),"-I","-S","-B","-X","utf8",
      str(D/"audit_actual.py"),str(D/"data-audit-v1")]
result=run_bounded(argv,env,D,D/"data-audit-v1",budget,[D])
assert result["all_processes_terminated"]
print(json.dumps({k:result.get(k) for k in
    ("status","exit_code","seconds","stop_reason","all_processes_terminated","held_members")}))
raise SystemExit(result["exit_code"] if result["exit_code"] is not None else 125)
