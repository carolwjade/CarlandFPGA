"""Stdlib saved-data audit. Never imports reference, science, model or receiver code."""
import ast
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import struct
import sys
import zipfile
D=Path(__file__).resolve().parent
BASE,ROOT=D.parent,D.parents[2]
A=BASE/"g03-full48-reference-preparation-20261021"
R=BASE/"g03-full48-reference-independent-20261021"
OLD=BASE/"g03-boundary-sampler-controls-20261020"
PRIOR=BASE/"g03-centered-reference-independent-20261020"
SEL=BASE/"g03-full48-main-selection-20261021"
RUN=A/"candidate-runs/centered-full48-v1"
OUT=D/"data-audit-v1"
assert OUT.is_dir() and Path(sys.argv[1]).resolve()==OUT
REQ="c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
PIN="871081c441171b212c2b8d133e02de433f4961451d9314cd2157b4baa4b6b14d"
inputs={}
def read(p):
    p=Path(p).resolve()
    assert ".private." not in p.name and p.name!="lease.private.json"
    b=p.read_bytes();h={"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
    assert inputs.get(str(p),h)==h,str(p)
    inputs[str(p)]=h
    return b
def sha(p):return hashlib.sha256(read(p)).hexdigest()
def load(p):return json.loads(read(p))
def save(name,obj):
    with (OUT/name).open("x",encoding="utf-8",newline="\n") as f:
        json.dump(obj,f,indent=2,ensure_ascii=False,allow_nan=False);f.write("\n")
def manifest(folder,digest,n):
    assert sha(folder/"artifact-manifest.json")==digest
    m=load(folder/"artifact-manifest.json");assert len(m["files"])==n
    for rel,e in m["files"].items():
        p=(folder/rel).resolve();assert p.is_relative_to(folder.resolve())
        read(p);assert inputs[str(p)]==e
manifest(A,"ede7c85ca867f889b3aefaf0aa745baf1b9e457533307d9d7b5cd7192a17e9ec",20)
manifest(R,"4709d866a5c5c84c0c0e1a0c04ce32a87550c81c0ab081e6630ef35f4f9bcc38",43)
done=load(R/"native-complete-response.json")
assert done["status"]=="completed" and done["terminal"] is True
assert done["result"]["text"]==read(R/"final-result.txt").decode()
assert sha(A/"candidate-pins.json")==PIN
pins=load(A/"candidate-pins.json")
assert len(pins["files"])==62
for p,h in pins["files"].items():assert sha(p)==h,p
deps=load(OLD/"source-pins.json")["pins"]
assert len(deps)==4008
for p,h in deps.items():assert sha(p)==h,p
scope=load(ROOT/"docs/competition/deepeye-2026/immutable_scope.json")
assert [v["id"] for v in scope["requirements"]]==[f"H{i:02}" for i in range(1,16)]
assert hashlib.sha256(json.dumps(scope["requirements"],ensure_ascii=False,sort_keys=True,
    separators=(",",":")).encode()).hexdigest()==scope["requirements_sha256"]==REQ
read(ROOT/"docs/competition/deepeye-2026/immutable_scope.md")
transfer=load(ROOT/".planning/deepeye-desktop-handoff-20261015/transfer.json")
assert transfer["status"]=="active" and transfer["director_generation"]==2
assert transfer["new_director_thread_id"]=="01a13d7e-dcf1-7272-a738-a637dd62ff9d"
selection=load(A/"main-selection-batch12.json")
main=load(SEL/"main-verification-and-selection.json")
assert main["selection"]==selection and main["no_automatic_retry"] and main["no_tolerance_or_budget_relaxation"]
assert selection["physical_reference_authorized"] is True and selection["run_id"]=="centered-full48-v1"
assert selection["candidate_pins_sha256"]==PIN and selection["requirements_sha256"]==REQ
assert selection["comparison_gate_sha256"]==sha(A/"main-selected-comparison-gate.json")
gate=load(A/"main-selected-comparison-gate.json")
assert sorted(p.name for p in (A/"candidate-runs").iterdir())==["centered-full48-v1"]
assert not (A/"runner-active.json").exists()
failure=load(SEL/"import-failure.json")
assert failure["exit_code"]==1 and failure["selection_created"] is False and failure["physical_run_started"] is False
assert failure["source_sha256"]==sha(SEL/"select.failed-source.txt")==sha(SEL/"select_full48.py")
assert read(SEL/"select.failed-source.txt")==read(SEL/"select_full48.py")
assert not (SEL/"select.py").exists()
assert "class" in read(SEL/"CORRECTION.md").decode()
load(SEL/"actual-full48-main-observed.json")
for p in RUN.rglob("*"):
    if p.is_file():read(p)
run_files=[p.relative_to(RUN).as_posix() for p in RUN.rglob("*") if p.is_file()]
assert len(run_files)==16
r,c,h,v,g,s,payload,start,drv,call,comp=[
    load(RUN/n) for n in ("receipt.json","config.json","handshake.json","verified-identity.json",
    "grant.json","suspended-assigned.json","payload-result.json","payload-started.json",
    "physical-driver-execution.json","physical-call-started.json","diagnostic-comparison.json")]
assert r["run_id"]==c["run_id"]==selection["run_id"]
assert r["mode"]==c["mode"]==selection["mode"]=="physical_batch12"
assert r["candidate_pins_sha256"]==c["candidate_pins_sha256"]==PIN
assert r["hard_seconds"]==c["hard_seconds"]==50
assert all(r[k] for k in ("physical_run","hidden","below_normal","assigned_while_suspended","resumed",
                         "job_empty_verified","all_retained_process_handles_signaled"))
assert r["outcome"]=="complete" and r["failure"] is None and not r["timed_out"]
assert r["final_job_state"]=={"active":0,"total":3,"terminated":0,"pids":[]}
assert r["launcher_terminal"]==r["worker_terminal"]=={"exit_code":0,"wait_state":0}
assert len(r["observed_member_live"])==len(r["observed_member_terminals"])==3
assert set(r["observed_member_live"])==set(r["observed_member_terminals"])
assert all(x=={"exit_code":0,"wait_state":0} for x in r["observed_member_terminals"].values())
launcher,worker=v["launcher"],v["worker"]
assert launcher==s["launcher"]==r["observed_member_live"][str(r["launcher_pid"])]
assert worker==r["observed_member_live"][str(worker["pid"])]
assert launcher["ppid"]==r["parent_pid"] and worker["ppid"]==launcher["pid"]
assert s["private_job_before_resume"]=={"active":1,"total":1,"terminated":0,"pids":[launcher["pid"]]}
assert v["worker_waiting_before_science"] and v["relation_verified_from_live_OS_handles"]
assert h["pid"]==g["worker_pid"]==start["pid"]==payload["pid"]==drv["pid"]==worker["pid"]
assert h["ppid"]==launcher["pid"] and h["isolated"] and h["no_site"] and h["science_imports"]==[]
assert c["nonce"]==h["nonce"]==g["nonce"]==start["nonce"]==payload["nonce"]
assert h["config_sha256"]==sha(RUN/"config.json")
assert g["handshake_sha256"]==sha(RUN/"handshake.json")
assert g["identity_file_sha256"]==sha(RUN/"verified-identity.json")
assert start["after_verified_grant"]
assert r["payload_result_sha256"]==sha(RUN/"payload-result.json") and payload["payload"]==comp
for k in ("pid","ppid","creation_filetime","image_path","image_sha256","priority_class","wait_state"):
    assert h["os_identity"][k]==worker[k]
for pid,rec in r["observed_member_live"].items():
    assert int(pid)==rec["pid"] and rec["own_job_member"] is True
    assert rec["wait_state"]==258 and rec["priority_class"]==0x4000
    assert sha(rec["image_path"])==rec["image_sha256"]
    if int(pid)!=launcher["pid"]:assert rec["ppid"]==launcher["pid"]
assert len({x["creation_filetime"] for x in r["observed_member_live"].values()})==3
times=[main["utc"],r["start_utc"],h["created_utc"],v["utc"],start["utc"],payload["utc"],r["end_utc"]]
assert list(map(datetime.fromisoformat,times))==sorted(map(datetime.fromisoformat,times))
assert r["tree_duration_seconds"]<50 and drv["elapsed_seconds"]<45
assert r["pinned_inputs_unchanged_after_tree_terminal"] is True
for stream in ("stdout","stderr"):
    assert read(RUN/(stream+".txt"))==b""
    assert sha(RUN/(stream+".txt"))==r[stream+"_sha256"]
for name in ("job_runner.py","reference_driver.py","candidate-pins.json"):
    assert read(RUN/"source-snapshots"/name)==read(A/name)
assert drv["reference_source_sha256"]==sha(A/"centered_reference.py")
assert drv["error"] is None and drv["blocked_physical_attempts"]==[]
assert drv["threads_before"]==drv["threads_after"] and len(drv["threads_before"])==2
for lib in drv["threads_before"]:
    assert lib["threads"]==1 and lib["pid"]==worker["pid"] and sha(lib["path"])==lib["sha256"]
limits={"inner_abs":2.5e-16,"inner_rel":2e-13,"outer_abs":2.5e-16,"outer_rel":2e-13,
    "quad_limit":64,"outer_cap":4096,"kernel_cap":262144,"soft_seconds":45.0}
assert call["limits"]==main["total_limits"]==limits
assert call["reference_calls_selected"]==1 and call["comparison_gate_V_m"]==gate["gate_V_m"]
assert not call["receiver_gate_qualified"] and call["receiver_transfer_bound"]=="unresolved"
assert not list(RUN.glob("quadrature-refusal-*"))

def npy(raw):
    assert len(raw)<100000 and raw[:6]==b"\x93NUMPY" and raw[6:8] in (b"\x01\x00",b"\x02\x00")
    sz=2 if raw[6]==1 else 4;n=int.from_bytes(raw[8:8+sz],"little")
    assert 0<n<4096
    hd=ast.literal_eval(raw[8+sz:8+sz+n].decode("ascii"));b=raw[8+sz+n:]
    assert set(hd)=={"descr","shape","fortran_order"} and hd["fortran_order"] is False
    assert len(hd["shape"]) in (1,2) and all(type(i) is int and 0<i<=144 for i in hd["shape"])
    fmt={"<c16":"dd","<f8":"d","<i8":"q"}[hd["descr"]]
    assert len(b)==math.prod(hd["shape"])*struct.calcsize("<"+fmt)
    vals=[complex(*v) if len(v)==2 else v[0] for v in struct.iter_unpack("<"+fmt,b)]
    assert all(math.isfinite(complex(z).real) and math.isfinite(complex(z).imag) for z in vals)
    if len(hd["shape"])==2:
        width=hd["shape"][1];vals=[vals[i:i+width] for i in range(0,len(vals),width)]
    head=json.dumps({"shape":list(hd["shape"]),"dtype":hd["descr"]},sort_keys=True,separators=(",",":")).encode()
    return hd,vals,hashlib.sha256(head+b"\n"+b).hexdigest()
bh,base,bhval=npy(read(OLD/"runs/batch-03/g.npy"))
assert bh["shape"]==(48,) and bh["descr"]=="<c16"
assert bhval==load(OLD/"runs/batch-03/binding.json")["values_sha256"]
read(OLD/"geometry.npz")
with zipfile.ZipFile(OLD/"geometry.npz") as z:
    assert z.testzip() is None
    names=("indices","starts","ends","tangents","lengths","nominal_lengths")
    assert set(z.namelist())=={n+".npy" for n in names}
    assert all(i.file_size<100000 for i in z.infolist())
    arrays={n:npy(z.read(n+".npy"))[1] for n in names}
fixture=load(A/"reference-input-full48.json")
mapping=load(R/"read-and-inert-v3/verified-fixture-mapping.json")["rows"]
indices=arrays["indices"]
assert indices==sorted(set(indices)) and len(indices)==48
assert [e["global_index"] for e in fixture["selected_edges"]]==call["selected_edges"]==gate["reference_subset"]==indices
assert [e["global_index"] for e in comp["per_edge"]]==indices and len(comp["per_edge"])==48
full_norm=max(abs(v) for v in base)
assert full_norm==comp["full48_baseline_sup_V_m"]==gate["baseline_full48_sup_V_m"]==0.01957577343353139
threshold=gate["absolute_V_m"]+gate["relative_to_fixed_full48_baseline_sup"]*full_norm
assert threshold==gate["gate_V_m"]==comp["gate_V_m"]==1.967577343353139e-12
differences=[];numeric=[];deltas=[];outer=kernel=0;elapsed=0.;zero_count=0
for n,(edge,answer,known) in enumerate(zip(fixture["selected_edges"],comp["per_edge"],mapping)):
    assert edge=={"global_index":indices[n],"row":n,"start_m":arrays["starts"][n],
                  "end_m":arrays["ends"][n],"tangent":arrays["tangents"][n]}
    assert {k:known[k] for k in edge}==edge
    assert answer["row"]==n and arrays["lengths"][n]==arrays["nominal_lengths"][n]==.6
    a,b=edge["start_m"],edge["end_m"];c0=fixture["source"]["center_m"]
    delta=[y-x for x,y in zip(a,b)]
    assert sum(x!=0 for x in delta)==1
    reason=None
    if delta[0]==delta[1]==0:reason="axial tangent: dl_z is pointwise zero"
    elif delta[2]==delta[1]==0 and a[1]==c0[1]:reason="reflection theta -> -theta: x projection odd, distance even"
    elif delta[2]==delta[0]==0 and a[0]==c0[0]:reason="reflection theta -> pi-theta: y projection odd, distance even"
    value=complex(*answer["adaptive_value"]);old=base[n];difference=value-old;est=answer["estimate"]
    assert answer["saved_baseline"]==[old.real,old.imag]
    assert answer["complex_difference"]==[difference.real,difference.imag]
    assert answer["absolute_difference_V_m"]==abs(difference)
    if reason:
        zero_count+=1
        assert value==0 and est["analytic_zero"] and not est["numerical_quadrature_executed"]
        assert est["reason"]==reason
    else:
        errors=est["outer_component_errors"]+est["max_observed_inner_component_errors"]
        assert len(errors)==4 and all(math.isfinite(x) and x>=0 for x in errors)
        assert sum(errors)==est["combined_diagnostic_error_estimate"] and "not certified" in est["error_scope"]
        assert est["outer_quad_neval"]==[21,21]
        outer+=sum(est["outer_quad_neval"]);kernel+=est["inner_quad_neval_total"]
        assert elapsed<=est["elapsed_seconds_total"]<45
        elapsed=est["elapsed_seconds_total"]
        numeric.append({"value":answer["adaptive_value"],"estimate":est})
    assert est["outer_evaluations_total"]==outer<=4096 and est["kernel_evaluations_total"]==kernel<=262144
    deltas.append(difference)
    differences.append({"row":n,"global_index":indices[n],"saved_baseline":answer["saved_baseline"],
        "adaptive_value":answer["adaptive_value"],"complex_difference":[difference.real,difference.imag],
        "abs_difference_V_m":abs(difference),"strict_zero_reason":reason,"estimate":est})
assert zero_count==len(numeric)==24 and drv["partial_nested_results"]==numeric
counts=drv["calls"]
assert counts["reference_edges"]==1 and counts["analytic_zero_reason"]==48
assert counts["_physical_integrand"]==counts["nested_average"]==24
assert counts["inner"]==outer==1008 and counts["inner_component"]==2*outer==2016
assert counts["_quad"]==2*outer+2*24==2064
assert counts["integrand"]==counts["component"]==counts["centered_circle_kernel"]==counts["psi"]==kernel==147168
assert counts["<lambda>"]==counts["tick"]==kernel+outer
assert counts["_finite"]==3*kernel+24
assert not any(counts.get(k,0) for k in ("sample_boundary","_physical_electric","_physical_green_kernel","record_failure"))
maximum=max(abs(v) for v in deltas)
assert maximum==comp["max_absolute_difference_V_m"]==3.470108633346818e-18
assert (maximum<=threshold)==comp["diagnostic_gate_pass"] is True
assert comp["physical_calls"]==1 and not comp["receiver_gate_qualified"]

# Exact binary64 diagnostic input; this is not a certified physical error vector.
header=repr({"descr":"<c16","fortran_order":False,"shape":(48,)}).encode("ascii")
header+=b" "*(-(10+len(header)+1)%64)+b"\n"
raw=b"\x93NUMPY\x01\x00"+struct.pack("<H",len(header))+header+b"".join(struct.pack("<dd",v.real,v.imag) for v in deltas)
dh,dv,dhval=npy(raw);assert dv==deltas and dh["shape"]==(48,)
with (OUT/"delta-g-full48.npy").open("xb") as f:f.write(raw)
save("delta-g-full48.json",{"order":indices,"shape":[48],"dtype":"<c16","units":"V/m",
    "npy_sha256":hashlib.sha256(raw).hexdigest(),"canonical_values_sha256":dhval,
    "source_comparison_sha256":sha(RUN/"diagnostic-comparison.json"),
    "baseline_file_sha256":sha(OLD/"runs/batch-03/g.npy"),"sup_V_m":maximum,
    "meaning":"recorded adaptive minus original batch03 diagnostic differences; not certified exact-field errors",
    "per_edge":differences})
old=load(PRIOR/"final-input-verification.json")
for item in old["retained_failed_real_diagnostics"]:
    for rel,e in item["files"].items():
        p=Path(item["path"])/rel;read(p);assert inputs[str(p.resolve())]==e
    assert load(Path(item["path"])/"receipt.json")["outcome"]=="failed"
obs=load(PRIOR/"near-orthogonal-counterexample.json")
assert obs["id"]=="G03-CRIR-OBS01" and obs["six_edge_V_m_gate_failure_established"] is False
assert not any(n.split(".")[0] in ("numpy","scipy","discretize","simpeg") for n in sys.modules)
summary={"candidate_manifest_files":20,"source_review_manifest_files":43,"candidate_pins":62,"dependency_pins":4008,
    "actual_run_files":16,"selected_reference_calls":1,"reference_answers":48,"numerical_edges":24,"analytic_zero_edges":24,
    "outer_evaluations":outer,"kernel_evaluations":kernel,"original_full48_norm_V_m":full_norm,
    "max_abs_difference_V_m":maximum,"max_difference_edges":[r["global_index"] for r in differences if r["abs_difference_V_m"]==maximum],
    "gate_V_m":threshold,"diagnostic_gate_pass":True,"original_processes":r["observed_member_live"],
    "original_process_terminals":r["observed_member_terminals"],
    "original_tree_seconds":r["tree_duration_seconds"],"driver_seconds":drv["elapsed_seconds"],
    "actual_BLAS_threads_before_after":[1,1],"payload_hash_chain_verified":True,"limits":limits,"hard_seconds":50,
    "main_import_failure_preserved":True,"main_selector_sources_byte_identical":True,
    "source_review_assumption_failures_preserved":True,"class_omission_qualification_preserved":True,
    "two_prior_real_failures_preserved":True,"pointwise_float_observation_retained":"G03-CRIR-OBS01",
    "historic11_OS_lineage":"unknown; unchanged","QUADPACK_scope":"estimates only; no certified global true error",
    "new_physical_reference_sampler_Maxwell_receiver_calls":0,"science_imports":[],"W_B_or_T_implemented":False,
    "requirements_sha256":REQ,"director_generation":2,"main_acceptance":"reserved",
    "G03":"not_run","old18":"not_run","all29":"not_run","Maxwell":"not_run","receiver":"not_run"}
save("independent-actual-full48-result.json",summary)
save("reviewed-input-hashes.json",{"files":inputs,"file_count":len(inputs)})
print(json.dumps({k:summary[k] for k in ("reference_answers","numerical_edges","analytic_zero_edges",
    "outer_evaluations","kernel_evaluations","max_abs_difference_V_m","max_difference_edges",
    "gate_V_m","diagnostic_gate_pass","new_physical_reference_sampler_Maxwell_receiver_calls")}))
