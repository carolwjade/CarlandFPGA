"""Only a newly acquired wheel is opened as bounded ZIP data."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import traceback

D = Path(__file__).resolve().parent
Q = (D / "requests" / sys.argv[1]).resolve()
assert Q.parent == D / "requests"
attempts = []


def guard(event, args):
    if event.startswith("socket.") or event in {"subprocess.Popen", "os.system",
            "os.startfile", "os.startfile/2", "ctypes.dlopen"}:
        attempts.append(event)
        raise RuntimeError("external/native effect forbidden")
    if event == "import" and args[0].split(".")[0] in {
            "filelock", "fsspec", "jinja2", "mpmath", "networkx", "torch", "rocm",
            "rocm_sdk", "rocm_bootstrap", "setuptools", "pip", "sympy"}:
        attempts.append("vendor_import:" + args[0])
        raise RuntimeError("vendor import forbidden")
    if event == "open" and not isinstance(args[0], int):
        p = Path(args[0]).resolve()
        if "private" in p.name.lower() or "reserve" in p.name.lower():
            raise RuntimeError("private file forbidden")
        mode, flags = args[1:3]
        writing = ((isinstance(mode, str) and any(x in mode for x in "wax+")) or
            (isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC)))
        if writing and not p.is_relative_to(Q):
            attempts.append("unowned_write")
            raise RuntimeError("write outside current request")
    if event == "exec" and str(D / "artifacts").casefold() in args[0].co_filename.casefold():
        attempts.append("artifact_execution")
        raise RuntimeError("artifact source is data")


sys.addaudithook(guard)


def pin(p):
    raw = Path(p).read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(name, value):
    with (Q / name).open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write("\n")


try:
    request = json.loads((Q / "request.json").read_bytes())
    incoming = json.loads((D / "incoming-pins.json").read_bytes())["files"]
    assert pin(D / "archive_data.py") == incoming[str(D / "archive_data.py")]
    sys.path.insert(0, str(D))
    from archive_data import zip_data
    artifact = Path(request["artifact_path"])
    assert artifact.parent == D / "artifacts" and artifact.name == request["filename"]
    assert artifact.stat().st_size == request["compressed_bytes"] <= 3*1024**2
    before = pin(artifact)
    assert before["sha256"] == request["published_sha256"]
    result, payload = zip_data(artifact.read_bytes(), request["filename"], 16*1024**2)
    name = re.sub(r"[-_.]+", "-", result["metadata"]["name"]).lower()
    assert name == request["name"] and result["metadata"]["version"] == request["version"]
    assert result["wheel"]["Tag"] in request["tags"] and request["tags"] == ["py3-none-any"]
    assert result["wheel"]["Root-Is-Purelib"] == "true"
    assert result["declared_uncompressed_bytes"] == request["declared_expanded_bytes"]
    accepted = request["accepted_metadata"]
    assert pin(accepted["path"]) == {k: accepted[k] for k in ("bytes", "sha256")}
    assert payload[result["metadata_name"]] == Path(accepted["path"]).read_bytes()
    result.update(accepted_metadata_bytes_equal=True, accepted_metadata=accepted,
        artifact_path=str(artifact), full_published_sha256_equal=True, vendor_imports=0,
        installations=0, extractions_to_executable_paths=0, prohibited_attempts=attempts,
        python={"executable": sys.executable, "base_executable": sys._base_executable,
            "pid": os.getpid(), "ppid": os.getppid(), "isolated": sys.flags.isolated,
            "no_site": sys.flags.no_site, "dont_write_bytecode": sys.dont_write_bytecode})
    assert result["python"]["isolated"] == result["python"]["no_site"] == 1
    assert result["python"]["dont_write_bytecode"]
    assert pin(artifact) == before and not attempts
    for target, member in (("METADATA.txt", result["metadata_name"]),
                           ("WHEEL.txt", result["metadata_name"].replace("METADATA", "WHEEL"))):
        with (Q / target).open("xb") as f:
            f.write(payload[member])
    save("archive-review.json", result)
    save("verification-result.json", {"status": "success", "artifact": before,
        "name": name, "version": request["version"], "members": result["member_count"],
        "record_hash_count": result["record_hash_count"], "declared_expanded_bytes": result["declared_uncompressed_bytes"],
        "accepted_metadata_bytes_equal": True, "vendor_imports": 0, "prohibited_attempts": attempts,
        "R02": "not_run", "C03": "not_run", "all29": "not_run"})
    print(json.dumps({"status": "success", "name": name, "members": result["member_count"],
        "record_hash_count": result["record_hash_count"], "sha256": before["sha256"]}))
except BaseException:
    save("verification-failure.json", {"status": "failed", "error": traceback.format_exc(),
        "prohibited_attempts": attempts})
    traceback.print_exc()
    raise
