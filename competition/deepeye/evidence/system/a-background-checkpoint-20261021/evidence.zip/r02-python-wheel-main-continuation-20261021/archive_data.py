"""Exact reviewed validator definitions; only trusted stdlib imports."""
import base64
import csv
from email.parser import BytesParser
from email import policy
import hashlib
import io
from pathlib import PurePosixPath
import stat
import struct
import unicodedata
import zipfile
import zlib

def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(value, message):
    if not value:
        raise AssertionError(message)


def safe_name(name):
    require(type(name) is str and name and "\\" not in name and ":" not in name
            and "\0" not in name and not name.startswith("/"), "unsafe archive path")
    p = PurePosixPath(name)
    require(p.as_posix() == name and all(x not in (".", "..", "") for x in p.parts), "noncanonical path")
    devices = {"con", "prn", "aux", "nul"} | {f"{p}{n}" for p in ("com", "lpt") for n in range(1, 10)}
    require(all(not x.endswith((".", " ")) and x.split(".")[0].casefold() not in devices
                for x in p.parts), "Windows alias path")
    return unicodedata.normalize("NFC", name).casefold()


def zip_data(raw, label, total_limit=64*1024**2):
    """All members, local headers, bounded inflate, CRC and complete RECORD."""
    require(len(raw) <= 16*1024**2, "compressed ZIP cap")
    members, payload, keys, spans = {}, {}, set(), []
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        require(0 < len(infos) <= 2000, "ZIP entry count")
        require(sum(i.file_size for i in infos) <= total_limit, "ZIP expansion cap")
        require(not archive.comment, "unexpected archive comment")
        for item in infos:
            name = item.filename.rstrip("/") if item.is_dir() else item.filename
            key = safe_name(name)
            require(key not in keys, "duplicate/case-colliding ZIP member")
            keys.add(key)
            require(not item.is_dir(), "this bounded wheel format expects file-only members")
            require(not stat.S_ISLNK(item.external_attr >> 16), "ZIP link")
            require(not item.flag_bits & 0x9 and item.compress_type in (0, 8), "unsupported ZIP flags/method")
            require(item.file_size <= 16*1024**2, "ZIP member cap")
            offset = item.header_offset
            require(0 <= offset <= len(raw)-30, "local header bounds")
            header = struct.unpack_from("<4s5H3I2H", raw, offset)
            sig, _, flags, method, _, _, crc, comp, uncomp, nlen, xlen = header
            require(sig == b"PK\x03\x04" and flags == item.flag_bits and method == item.compress_type,
                    "central/local flags")
            require((crc, comp, uncomp) == (item.CRC, item.compress_size, item.file_size), "central/local sizes")
            local_name = raw[offset+30:offset+30+nlen].decode("utf-8" if flags & 0x800 else "cp437")
            require(local_name == item.filename, "central/local name")
            end = offset + 30 + nlen + xlen + comp
            require(end <= archive.start_dir, "member overlaps central directory")
            spans.append((offset, end))
            data = archive.read(item)
            require(len(data) == item.file_size and zlib.crc32(data) & 0xffffffff == item.CRC, "ZIP CRC")
            payload[name] = data
            members[name] = {"bytes": len(data), "sha256": digest(data), "crc32": item.CRC,
                "compressed_bytes": item.compress_size, "method": item.compress_type, "local_offset": offset}
        spans.sort()
        require(all(a[1] <= b[0] for a, b in zip(spans, spans[1:])), "overlapping ZIP members")
        require(archive.testzip() is None, "all-member CRC")
    records = [n for n in members if n.endswith(".dist-info/RECORD")]
    require(len(records) == 1, "one RECORD required")
    rows = list(csv.reader(io.StringIO(payload[records[0]].decode("utf-8"))))
    require(all(len(r) == 3 for r in rows) and len({r[0] for r in rows}) == len(rows), "RECORD shape/duplicate")
    require({r[0] for r in rows} == set(members), "complete RECORD coverage")
    for name, checksum, size in rows:
        if name == records[0]:
            require(checksum == size == "", "RECORD self row")
        else:
            require(checksum.startswith("sha256="), "RECORD algorithm")
            expected = base64.urlsafe_b64encode(hashlib.sha256(payload[name]).digest()).rstrip(b"=").decode()
            require(checksum == "sha256=" + expected and size == str(len(payload[name])), "RECORD hash/size")
    wheel_name = records[0].replace("RECORD", "WHEEL")
    metadata_name = records[0].replace("RECORD", "METADATA")
    wheel = BytesParser(policy=policy.default).parsebytes(payload[wheel_name])
    metadata = BytesParser(policy=policy.default).parsebytes(payload[metadata_name])
    require(not wheel.defects and not metadata.defects, "metadata parse defects")
    return {"label": label, "archive": {"bytes": len(raw), "sha256": digest(raw)},
        "member_count": len(members), "declared_uncompressed_bytes": sum(x["bytes"] for x in members.values()),
        "members": members, "full_crc_verified": True, "safe_unique_paths": True,
        "record_hash_count": len(rows)-1, "complete_record_coverage": True,
        "metadata_name": metadata_name, "metadata": {"name": metadata["Name"], "version": metadata["Version"],
            "requires_dist": metadata.get_all("Requires-Dist", []),
            "provides_extra": metadata.get_all("Provides-Extra", []),
            "requires_python": metadata.get("Requires-Python")},
        "wheel": dict(wheel.items())}, payload
