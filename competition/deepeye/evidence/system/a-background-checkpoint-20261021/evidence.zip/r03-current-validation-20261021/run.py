from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
P=ROOT/'.local/deepeye-implementation-a';WORK=P/'competition/deepeye'
R=D.parent/'r02-transient-quota-fix-20261021'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
assert sha(R/'win_job.py')=='80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d'
assert sha(R/'boundary.py')=='04cf7d53f3dbf1fca66aab05fe497ae193aab94a56ab4e0d36e81d1eb0a040fe'
head=subprocess.run(['git','-C',str(P),'rev-parse','HEAD'],capture_output=True,check=True,timeout=10,creationflags=subprocess.CREATE_NO_WINDOW).stdout.decode().strip()
assert head=='b074eaa10012fc5b89f818926195fd24f0bef1bd'
pins={}
for rel in ['integration','tools','tests','docs']:
 for p in sorted((WORK/rel).rglob('*')):
  if p.is_file() and p.suffix in ('.py','.json','.md','.csv') and '__pycache__' not in p.parts:
   pins[p.relative_to(WORK).as_posix()]=sha(p)
protected=json.loads((D.parent/'r03-mailbox-stop-main-review-20261020/application.json').read_bytes())['protected_files']
for rel,h in protected.items():assert sha(P/rel)==h
(D/'empty-cache').mkdir();(D/'temp').mkdir()
env=dict(os.environ);env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPYCACHEPREFIX=str(D/'empty-cache'),PYTHONIOENCODING='utf-8',PYTHONNOUSERSITE='1',TEMP=str(D/'temp'),TMP=str(D/'temp'))
cmd=[str(ROOT/'.local/venv/Scripts/python.exe'),'-B','-X','utf8','tools/check_interface.py']
budget=dict(seconds=50,job_memory_bytes=1024**3,process_memory_bytes=512*1024**2,active_processes=8,stdout_bytes=8*1024**2,stderr_bytes=1024**2,tree_bytes=96*1024**2,tree_entries=10000,free_reserve_bytes=10*1024**3)
save('selection.json',dict(utc=datetime.now(timezone.utc).isoformat(),head=head,command=cmd,budget=budget,scope='default full_R03 checker; exit 2 may record open formal gates and is not promoted to formal pass',source_pins=pins,cache_policy='new empty PYTHONPYCACHEPREFIX inherited by children, -B and PYTHONDONTWRITEBYTECODE; preserve all prior caches'))
sys.path.insert(0,str(R));from win_job import run_bounded
t=run_bounded(cmd,env,WORK,D/'check-interface-v1',budget,[D])
assert t['all_processes_terminated'] and t['active_processes_final']==0
assert t['held_members'] and all(h['signaled'] and h['wait_result']==0 for h in t['held_members'])
assert not any((D/'empty-cache').rglob('*.pyc'))
for rel,h in pins.items():assert sha(WORK/rel)==h,rel
for rel,h in protected.items():assert sha(P/rel)==h
stdout=D/'check-interface-v1/stdout.txt'
result=json.loads(stdout.read_bytes());save('checker-result.json',result)
for rel,h in result.get('artifact_sha256',{}).items():assert sha(WORK/rel)==h,rel
summary=dict(utc=datetime.now(timezone.utc).isoformat(),head=head,checker_exit_code=t['exit_code'],runner_status=t['status'],software_checks=result.get('software_checks'),status=result.get('status'),R03=result.get('R03'),checks=[{'command':c['command'][4:],'exit_code':c['exit_code']} for c in result.get('checks',[])],remaining_gates=result.get('remaining_gates'),held_processes=len(t['held_members']),all_original_processes_signaled=True,source_pins_unchanged=True,empty_cache_preserved=True,protected_files_unchanged=True,board_testing='separate operation; no board access in this checker',full_H12='not_run',all29='not_run')
save('main-verification.json',summary)
print(json.dumps(summary,ensure_ascii=False))
