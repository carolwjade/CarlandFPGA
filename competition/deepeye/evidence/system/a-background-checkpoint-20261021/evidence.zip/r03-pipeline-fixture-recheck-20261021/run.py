from datetime import datetime,timezone
import hashlib,json,os,stat,subprocess,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];OUT=D.parent
P=ROOT/'.local/deepeye-implementation-a';WORK=P/'competition/deepeye';R=OUT/'r02-transient-quota-fix-20261021'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2)
old=json.loads((OUT/'r03-current-validation-20261021/selection.json').read_bytes())
for rel,h in old['source_pins'].items():assert sha(WORK/rel)==h,rel
for folder in ['r03-current-validation-20261021/check-interface-v1','r03-environment-recheck-20261021/05-pipeline','r03-pipeline-longpath-recheck-20261021/01-pipeline']:
 t=json.loads((OUT/folder/'terminal.json').read_bytes());assert t['all_processes_terminated'] and t['active_processes_final']==0
 assert all(x['signaled'] and x['wait_result']==0 for x in t['held_members'])
tree=subprocess.run(['git','-c','core.longpaths=true','-C',str(P),'ls-tree','-r','-l','-z','HEAD'],capture_output=True,check=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW).stdout
rows=[r.split(b'\t',1)[0].split() for r in tree.split(b'\0') if r]
blob_bytes=sum(int(r[3]) for r in rows if r[1]==b'blob');blob_count=sum(r[1]==b'blob' for r in rows)
temp_cap=2*blob_bytes+64*1024**2;entry_cap=2*blob_count+10000
assert temp_cap<=3*1024**3 and entry_cap<100000
for name in ['temp','empty-cache','runs']:(D/name).mkdir()
env=dict(os.environ);env.update(PYTHONPATH=str(ROOT/'.local/deepeye-host-deps'),PYTHONPYCACHEPREFIX=str(D/'empty-cache'),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',PYTHONNOUSERSITE='1',TEMP=str(D/'temp'),TMP=str(D/'temp'))
count=int(env.get('GIT_CONFIG_COUNT','0'));env['GIT_CONFIG_KEY_'+str(count)]='core.longpaths';env['GIT_CONFIG_VALUE_'+str(count)]='true';env['GIT_CONFIG_COUNT']=str(count+1)
budget=dict(seconds=50,job_memory_bytes=1024**3,process_memory_bytes=512*1024**2,active_processes=32,stdout_bytes=4*1024**2,stderr_bytes=4*1024**2,tree_bytes=16*1024**2,tree_entries=1000,free_reserve_bytes=10*1024**3)
peak={'bytes':0,'entries':0,'reparse_entries_observed':0,'scans':0}
def observe_temp(job,pids):
 # The frozen provenance tests deliberately create a link to another owned
 # temp directory. Count the link itself; never follow it. The product guard
 # is still exercised by the tests. No link policy in the runner is changed.
 total=entries=links=0;pending=[D/'temp']
 while pending:
  folder=pending.pop()
  try:
   with os.scandir(folder) as iterator:children=list(iterator)
  except FileNotFoundError:continue
  for entry in children:
   try:s=entry.stat(follow_symlinks=False)
   except FileNotFoundError:continue
   entries+=1
   if getattr(s,'st_file_attributes',0)&0x400 or stat.S_ISLNK(s.st_mode):links+=1;continue
   if stat.S_ISDIR(s.st_mode):pending.append(Path(entry.path))
   else:assert stat.S_ISREG(s.st_mode);total+=s.st_size
   assert entries<=entry_cap and total<=temp_cap,'derived fixture storage cap'
 peak['bytes']=max(peak['bytes'],total);peak['entries']=max(peak['entries'],entries);peak['reparse_entries_observed']=max(peak['reparse_entries_observed'],links);peak['scans']+=1
save('selection.json',dict(utc=datetime.now(timezone.utc).isoformat(),head=old['head'],blob_bytes=blob_bytes,blob_count=blob_count,temp_byte_cap=temp_cap,temp_entry_cap=entry_cap,budget=budget,scope='pipeline only; two frozen disposable shared clones and intended containment-link fixture; actual source unchanged',previous_failures_preserved=['missing jsonschema','8-process cap caused WinError1816','Windows Git long paths','96 MiB fixture quota too small for full checked-out source'],monitor='strict reviewed runner watches logs/cache; separate no-follow temp accounting allows intentional containment fixture; same original process handle guarantees'))
assert sha(R/'win_job.py')=='80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d'
sys.path.insert(0,str(R));from win_job import run_bounded
cmd=[str(ROOT/'.local/venv/Scripts/python.exe'),'-B','-X','utf8','tools/pipeline.py','verify','--selftest']
t=run_bounded(cmd,env,WORK,D/'runs/pipeline-v1',budget,[D/'runs',D/'empty-cache'],on_tick=observe_temp)
assert t['all_processes_terminated'] and t['active_processes_final']==0
assert all(x['signaled'] and x['wait_result']==0 for x in t['held_members'])
for rel,h in old['source_pins'].items():assert sha(WORK/rel)==h,rel
assert not any((D/'empty-cache').rglob('*.pyc'))
result=json.loads((D/'runs/pipeline-v1/stdout.txt').read_bytes());save('pipeline-result.json',result)
summary=dict(utc=datetime.now(timezone.utc).isoformat(),head=old['head'],exit_code=t['exit_code'],runner_status=t['status'],stop_reason=t['stop_reason'],selftest=result.get('selftest'),peak_temp=peak,held_original_processes=len(t['held_members']),all_signaled=True,source_unchanged=True,R03='not_run',full_H12='not_run',all29='not_run')
save('main-verification.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k!='selftest'},ensure_ascii=False));print(json.dumps(result.get('selftest'),ensure_ascii=False))
