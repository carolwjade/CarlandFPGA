from datetime import datetime,timezone
import hashlib,json,os,zipfile
from pathlib import Path
D=Path(__file__).resolve().parent;OUT=D.parent;ROOT=D.parents[2]
P=ROOT/'.local/deepeye-implementation-a'
T=P/'competition/deepeye/evidence/system/a-background-checkpoint-20261021'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
def encoded(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
load=lambda p:json.loads(p.read_bytes())
assert not T.exists()
original=load(OUT/'r03-current-validation-20261021/checker-result.json')
source=load(OUT/'r03-current-validation-20261021/selection.json')
assert source['head']=='b074eaa10012fc5b89f818926195fd24f0bef1bd'
for rel,h in source['source_pins'].items():assert sha((P/'competition/deepeye'/rel).read_bytes())==h,rel
adopted=[]
for c in original['checks']:
 if c['exit_code']==0:adopted.append({'command':c['command'][4:],'exit_code':0,'evidence':'r03-current-validation-20261021/checker-result.json','output_sha256':c['raw_output_sha256']})
for n in range(1,5):
 c=load(OUT/f'r03-environment-recheck-20261021/{n:02}-result.json');assert c['exit_code']==0
 adopted.append({'command':c['command'][4:],'exit_code':0,'evidence':f'r03-environment-recheck-20261021/{n:02}-result.json','output_sha256':c['output_sha256']})
pipeline=load(OUT/'r03-pipeline-fixture-recheck-20261021/pipeline-result.json')
assert pipeline['selftest']['ok'] and pipeline['selftest']['returncode']==0 and pipeline['selftest']['tests_ran']==25
assert 'OK (skipped=1)' in pipeline['selftest']['stdout_tail']
adopted.append({'command':['tools/pipeline.py','verify','--selftest'],'exit_code':0,'evidence':'r03-pipeline-fixture-recheck-20261021/pipeline-result.json','tests_ran':25,'passed':24,'skipped':1})
assert len(adopted)==13 and len({tuple(x['command']) for x in adopted})==13
board=load(OUT/'board-baseline-20261021/main-verification.json');assert board['status']=='passed' and board['comparisons']==384 and board['actual_loads']==1
wheels=load(OUT/'r02-python-wheel-owned-tree-20261021/main-verification.json');assert wheels['new_complete_wheels']==5 and wheels['compressed_bytes']==3197515
g03=load(OUT/'g03-full48-main-adoption-20261021/main-verification.json');assert g03['rehashed_external_pins']==4165
canaries=[]
for name in ['g03-full48-postrun-review-20261021','r02-python-wheel-acquisition-20261021']:
 canaries.append(load(OUT/name/'lease.private.json')['lease_token'].encode())
for key,value in os.environ.items():
 if any(term in key.upper() for term in ('TOKEN','SECRET','PASSWORD','API_KEY')) and len(value)>16:canaries.append(value.encode())
groups=['r03-current-validation-20261021','r03-environment-recheck-20261021','r03-pipeline-longpath-recheck-20261021','r03-pipeline-fixture-recheck-20261021','board-baseline-20261021','g03-full48-main-adoption-20261021','g03-full48-postrun-review-20261021','r02-python-wheel-main-continuation-20261021','r02-python-wheel-owned-image-20261021','r02-python-wheel-owned-tree-20261021']
members={};omitted=[];derived=[]
for name in groups:
 folder=OUT/name
 for p in sorted(folder.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(folder)
  if rel.parts[0] in ('temp','empty-cache','tool-image','artifacts') or p.suffix.lower() in ('.whl','.exe','.pyc') or 'private' in p.name.lower() or p.name=='reserve-request.json':continue
  raw=p.read_bytes();target=name+'/'+rel.as_posix()
  if p.name=='started.json':
   item=json.loads(raw)
   if 'environment' in item:
    env=item.pop('environment')
    item['environment_public_subset']={k:v for k,v in env.items() if k in ('PYTHONPYCACHEPREFIX','PYTHONDONTWRITEBYTECODE','PYTHONIOENCODING','PYTHONNOUSERSITE','PYTHONPATH','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')}
    item['original_environment_omitted']=True;item['original_local_sha256']=sha(raw)
    omitted.append({'original':target,'sha256':sha(raw),'reason':'original inherited environment retained locally, not published'})
    target=target.removesuffix('started.json')+'process-start-public.json';raw=encoded(item);derived.append(target)
  assert not any(token in raw for token in canaries),target
  members[target]=raw
summary=dict(utc=datetime.now(timezone.utc).isoformat(),tested_product_head=source['head'],R03_software={'checked_groups':13,'checks':adopted,'scope':'composed exact-source evidence across original and targeted corrected-environment runs; not a new full-checker invocation','prior_failures_preserved':True,'remaining_formal_gates':original['remaining_gates']},board_baseline=board,R02_downloads=wheels,G03_review=g03,requirements_sha256='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',R03='not_run',full_H12='not_run',all29='not_run',private_environment_exclusions=omitted,derived_process_start_files=derived)
members['main/summary.json']=encoded(summary)
members['main/prepare.py']=Path(__file__).read_bytes()
T.mkdir(parents=True)
with zipfile.ZipFile(T/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(members.items()):
  zi=zipfile.ZipInfo(name,(2026,10,21,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16;z.writestr(zi,raw)
with zipfile.ZipFile(T/'evidence.zip') as z:
 assert z.testzip() is None and len(z.namelist())==len(members) and set(z.namelist())==set(members)
 for name,raw in members.items():assert z.read(name)==raw
write(T/'.gitattributes',b'* -text -eol -filter\n')
write(T/'archive-index.json',encoded({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(members.items())}))
write(T/'summary.json',encoded(summary))
readme='''# A background verification checkpoint, 2026-10-21

The evidence binds software source at b074eaa10012fc5b89f818926195fd24f0bef1bd.
Thirteen R03 software command groups have passing evidence: eight from the first
checker, four targeted dependency rechecks, and the final pipeline selftest.
Pipeline ran 25 methods: 24 passed, one intentional nested-selftest skip. No
product source was altered to obtain these results. The first complete checker
still has its actual failed result; this summary combines exact-source records.

Preserved failures identify missing jsonschema in the chosen interpreter, the
initial eight-process test cap, Windows Git long-path fixture failures, and an
undersized 96 MiB clone quota. The successful test environment reused existing
host dependencies, scoped core.longpaths=true to child processes, and derived
fixture storage limits from the actual Git tree. The containment test intentionally
created one link; the temp monitor counted it without following it. Product
containment checks were unchanged. All recorded original process objects stopped.

The new A-only physical baseline loaded the exact previously reviewed PYNQ base
bit/HWH once and performed 384 actual MMIO comparisons in offsets FC00..FC3C.
All matched. Sixteen original words, observed reset and export state were restored;
independent post-read found FPGA manager operating. Request, source/tested commits,
script and bit/HWH hashes are in summary.json and the raw board report. This is
base-overlay/64-byte BRAM readiness, not DeepEye custom RTL, TTL or control acceptance.
The earlier FPGA configuration was recorded and was not restored.

Five selected Python wheels (3197515 bytes) now match published full hashes and
retained METADATA; ZIP/RECORD validation passed without installing or importing
vendor code. Twenty-five original process objects across successful acquisition
and verification runs stopped. Two earlier attempts remain failed: a trusted
system executable's hard link was refused before resume; a second resumed attempt
was stopped when its two-object native tree violated an incorrect single-process
assumption. No response body survived either. A new, separately selected attempt
used byte-identical single-link curl and a bounded four-object tree. Six AMD wheels
remain missing; project CNN/runtime acceptance is still open.

The saved G03 full48 independent source/data review was adopted after main rehashed
37 retained public files and 4165 external inputs. The worker ended on provider
quota before sealing/completion. Its original native job is cancelled, not relabeled
completed. The maximum saved-vector difference is 3.470108633346818e-18 V/m, below
the unchanged 1.967577343353139e-12 V/m consistency gate. This does not qualify the
receiver voltage budget or absolute physical model. Finite-coil W_B/T preparation
is the next dependency.

The archive contains public source, results, logs and terminal records. Private
reservation material, binaries/wheels, disposable clones and original inherited
environment records are excluded. Process-start derivatives retain relevant fields
and the hashes of originals held locally. Every published ZIP member was compared
byte-for-byte after CRC verification; the index distinguishes these derivatives.

R03, both complete H12 paths and all29 formal cards remain not_run. H01-H15 remain
DEEPEYE-HUMAN-LOCK-20261014/revision1 with requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
'''
write(T/'README.md',readme.encode())
write(T/'manifest.json',encoded({'files':{p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(T.iterdir())},'archive_members':len(members),'zip_crc_and_member_bytes_verified':True,'credential_canary_hits':0}))
guide=P/'competition/deepeye/docs/r03_background_validation_20261021.md'
write(guide,('''# R03 current software validation

At source b074eaa10012fc5b89f818926195fd24f0bef1bd all 13 selected software
groups have passing exact-source evidence, including PC_DIRECT heartbeat and
watchdog plus pipeline ownership/provenance checks. Pipeline reports 24 passed
and one intentional nested-selftest skip. See the
[checkpoint, preserved failures and individual command results](../evidence/system/a-background-checkpoint-20261021/README.md).

Use the existing jsonschema host dependency directory for these tests. On Windows,
scope Git core.longpaths=true to the test process; do not change global Git settings.
Pipeline's two disposable local shared clones need storage based on the current
tracked tree. Its containment test intentionally creates a temporary link. Keep
original process ownership and resource bounds while allowing that selected fixture.
The recorded scripts bind exact commands, environmental changes and live limits.

The first checker execution remains failed. Passing coverage is composed from its
eight successful groups and five targeted rechecks at unchanged source bytes;
this is not a claim that a later full-checker invocation occurred.

Formal R03 still needs current B/C byte interoperability, register/reset/HWH
integration, real runtime/source/clock/slot/IO evidence and both complete H12 chains.
The separate successful base-overlay BRAM operation establishes only current
physical baseline readiness. No formal task card was promoted by either result.
H01-H15 and their pinned canonical requirements hash are unchanged.
''').encode())
files={p.relative_to(P).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in [*sorted(T.iterdir()),guide]}
write(D/'publication-files.json',encoded(files));write(D/'owned-paths.nul',b''.join(n.encode()+b'\0' for n in files))
write(D/'package-summary.json',encoded({'files':len(files),'archive_members':len(members),'archive_sha256':sha((T/'evidence.zip').read_bytes()),'R03_software_groups':13,'board_comparisons':384,'new_wheels':5,'G03_external_pins':4165,'R03':'not_run'}))
print(json.dumps(load(D/'package-summary.json')))
