from pathlib import Path
import hashlib,json,os,sys
from contextlib import redirect_stdout
from datetime import datetime,timezone
D=Path(__file__).resolve().parent
request=json.loads((D/'request.json').read_bytes())
assert os.geteuid()==0 and os.environ.get('BOARD')=='Pynq-Z2' and os.environ.get('XILINX_XRT')=='/usr'
raw=(D/'reviewed_test.py').read_bytes()
assert hashlib.sha256(raw).hexdigest()==request['script_sha256']
expected=request.pop('request_hash')
assert hashlib.sha256(json.dumps(request,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()==expected
request['request_hash']=expected
identity={k:request[k] for k in ['operation_id','task_id','task_version','code_commit','tested_commit','request_hash','requirements_sha256']}
identity['work_id']='A-board-baseline-20261021'
namespace={'__file__':str(D/'reviewed_test.py'),'__name__':'reviewed_board_baseline'}
exec(compile(raw,str(D/'reviewed_test.py'),'exec'),namespace)
with (D/'operation-started.json').open('x',encoding='utf-8') as f:
 json.dump({'operation_id':request['operation_id'],'request_hash':expected,'pid':os.getpid(),'board_utc':datetime.now(timezone.utc).isoformat(),'process_start_ticks':Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]},f);f.flush();os.fsync(f.fileno())
with (D/'board-report.json').open('x',encoding='utf-8') as f:
 with redirect_stdout(sys.stderr):report=namespace['execute'](request['bitstream'],identity)
 text=json.dumps(report,sort_keys=True,indent=2)+'\n';f.write(text);f.flush();os.fsync(f.fileno())
print(text,end='')
raise SystemExit(0 if report['status']=='passed' else 1)
