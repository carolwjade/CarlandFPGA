"""One new A-owned base-overlay/BRAM operation, with exact old reviewed source."""
from datetime import datetime,timezone
import ast,hashlib,json,shlex,subprocess,time
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];OUT=D.parent
PRE=OUT/'board-preflight-20261021'
OP='DEEPEYE-A-BOARD-BASELINE-20261021-v1'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,value):
 with (D/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def write(name,b):
 with (D/name).open('xb') as f:f.write(b)
old=ROOT/'.local/board-review-b-v3-raw/examples/board_collaboration/base_bram_board_test.py'
source=old.read_bytes();assert sha(source)=='b0b6eef6064812deb34639306143972e740ed1e4dc38bfeb979ff31cdfd90eda'
oldproof=json.loads((ROOT/'artifacts/board-collaboration/BOARD-20261013-A/metadata-v3/A-frozen-handoff-verification.json').read_bytes())
assert oldproof['head']=='692f58bce38ff81d03204e46faf3c3792c5ff8f2'
assert oldproof['source']=='9b618204473c8fda1bffbaf436080d77a34db5fc'
row=next(x for x in oldproof['files'] if x['path']=='examples/board_collaboration/base_bram_board_test.py')
assert row['sha256']==sha(source) and row['size']==len(source)
git=subprocess.run(['git','-c','core.longpaths=true','-C',str(ROOT),'show',oldproof['head']+':examples/board_collaboration/base_bram_board_test.py'],capture_output=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
assert git.returncode==0 and git.stdout==source,'original frozen Git source must match before hardware'
state=json.loads((PRE/'board-observed.private.json').read_bytes())
sudo=json.loads((PRE/'sudo-readonly-result.json').read_bytes());assert sudo['exit_code']==0 and not sudo['timed_out']
runtime=json.loads(sudo['stdout']);assert runtime=={'euid':0,'BOARD':'Pynq-Z2','XILINX_XRT':'/usr'}
expected={'bit':'ecabdcb5d483c75335ab6f043824a2386971c7b0ffd6e3315f24860bf5088eb6','hwh':'cbd90c84f3a46d1eba95dff7ba7d0079812f7e46641a08e2318c9928cd36ce8f'}
for k,h in expected.items():assert state['base_overlay']['base.'+k]['sha256']==h
request=dict(operation_id=OP,task_id='DEEPEYE-IMPLEMENTATION-20261014',task_version=1,requester='node-a',code_commit=oldproof['source'],tested_commit=oldproof['head'],script_sha256=sha(source),bitstream=state['base_overlay']['base.bit']['path'],expected_hashes=expected,test_steps=['one matched base Overlay load','hold selected MicroBlaze reset','save 16 uint32 words at offset FC00..FC3C','3 rounds x8 patterns x16 actual MMIO comparisons','restore all 16 words and verify','restore observed reset/export state; inspect manager after'],expected_result='384 exact comparisons, 16 restored words, reset/export cleanup; board baseline only',requirements_sha256='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804')
request_hash=sha(json.dumps(request,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
request['request_hash']=request_hash
remote='/tmp/deepeye-board-baseline-20261021-'+request_hash[:12]
wrapper='''from pathlib import Path
import hashlib,json,os,sys
from contextlib import redirect_stdout
from datetime import datetime,timezone
D=Path(__file__).resolve().parent
request=json.loads((D/'request.json').read_bytes())
assert os.geteuid()==0 and os.environ.get('BOARD')=='Pynq-Z2' and os.environ.get('XILINX_XRT')=='/usr'
raw=(D/'reviewed_test.py').read_bytes()
assert hashlib.sha256(raw).hexdigest()==request['script_sha256']
expected=request.pop('request_hash')
assert hashlib.sha256(json.dumps(request,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()==expected
request['request_hash']=expected
identity={k:request[k] for k in ['operation_id','task_id','task_version','code_commit','tested_commit','request_hash','requirements_sha256']}
identity['work_id']='A-board-baseline-20261021'
namespace={'__file__':str(D/'reviewed_test.py'),'__name__':'reviewed_board_baseline'}
exec(compile(raw,str(D/'reviewed_test.py'),'exec'),namespace)
with (D/'operation-started.json').open('x',encoding='utf-8') as f:
 json.dump({'operation_id':request['operation_id'],'request_hash':expected,'pid':os.getpid(),'board_utc':datetime.now(timezone.utc).isoformat(),'process_start_ticks':Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]},f);f.flush();os.fsync(f.fileno())
with (D/'board-report.json').open('x',encoding='utf-8') as f:
 with redirect_stdout(sys.stderr):report=namespace['execute'](request['bitstream'],identity)
 text=json.dumps(report,sort_keys=True,indent=2)+'\\n';f.write(text);f.flush();os.fsync(f.fileno())
print(text,end='')
raise SystemExit(0 if report['status']=='passed' else 1)
'''
write('reviewed_test.py',source);write('invoke_reviewed.py',wrapper.encode());save('request.json',request)
save('selection.json',dict(utc=datetime.now(timezone.utc).isoformat(),operation_id=OP,request_hash=request_hash,script_sha256=sha(source),invocation_sha256=sha(wrapper.encode()),frozen_source_git_verified=True,source_review='historical independent review reused only for byte-identical source and exact bit/HWH; current results must be measured anew',owner='A/root sole physical operator',remote_directory=remote,scope='base-overlay BRAM readiness only; no DeepEye ABI/control/TTL/fullR03 acceptance',human_authorization='2026-10-21 board connected; programming and board tests authorized',prior_failed_root_ssh='authentication method only; existing xilinx plus sudo route verified without modifying credentials'))
base=json.loads((PRE/'started.private.json').read_bytes())['argv'][:-1]
old_ast=ast.parse((ROOT/'.local/bram-v3-board-execute.py').read_text(encoding='utf-8'))
auth=next(n for n in old_ast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='board_default_account' for t in n.targets))
assert ast.unparse(auth.value)=="base[-1].split('@', 1)[0]"
credential=base[-1].split('@',1)[0]
def call(label,command,data=None,timeout=25,allow_failure=False):
 save(label+'.started.json',{'utc':datetime.now(timezone.utc).isoformat(),'command':command,'timeout_seconds':timeout,'stdin_value_logged':False})
 with (D/(label+'.stdout.txt')).open('xb') as out,(D/(label+'.stderr.txt')).open('xb') as err:
  p=subprocess.Popen(base+[command],stdin=subprocess.PIPE if data is not None else subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  tick=time.monotonic()
  try:p.communicate(data,timeout=timeout);timed_out=False
  except subprocess.TimeoutExpired:p.kill();p.wait(timeout=10);timed_out=True
 r={'utc':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'timed_out':timed_out,'seconds':time.monotonic()-tick,'original_ssh_process_signaled':True,'remote_termination_not_inferred_from_ssh':True,'stdout_sha256':sha((D/(label+'.stdout.txt')).read_bytes()),'stderr_sha256':sha((D/(label+'.stderr.txt')).read_bytes())}
 save(label+'.result.json',r)
 assert not timed_out,'remote operation status unknown; inspect original saved operation, never repeat'
 if not allow_failure:assert p.returncode==0,(label,p.returncode)
 return (D/(label+'.stdout.txt')).read_bytes(),p.returncode
# Exclusive new remote directory and exclusive output prevent accidental replay.
call('reserve-remote','mkdir -- '+shlex.quote(remote))
for name in ['reviewed_test.py','invoke_reviewed.py','request.json']:
 b=(D/name).read_bytes();target=remote+'/'+name
 call('upload-'+name,'test ! -e '+shlex.quote(target)+' && cat > '+shlex.quote(target),b)
 raw,_=call('hash-'+name,'sha256sum -- '+shlex.quote(target));assert raw.decode().split()[0]==sha(b)
command='cd /tmp && /usr/local/share/pynq-venv/bin/python3 -I -B '+shlex.quote(remote+'/invoke_reviewed.py')
raw,exit_code=call('board-execute','sudo -S -p "" bash -lc '+shlex.quote(command),(credential+'\n').encode(),timeout=60,allow_failure=True)
# Read the original result after execution; never send the execution command twice.
saved,_=call('read-original-report','cat -- '+shlex.quote(remote+'/board-report.json'))
assert saved==raw;write('board-report.json',saved);report=json.loads(saved)
for k in ['operation_id','request_hash','code_commit','tested_commit','task_id','task_version']:assert report[k]==request[k]
assert report['script_sha256']==sha(source)
for k,h in expected.items():assert report['files'][k]['sha256']==h
pin=report.get('source',{}).get('reset_linux_gpio');assert type(pin) is int and pin>=0
check="import json;from pathlib import Path;p=Path('/sys/class/gpio/gpio"+str(pin)+"');print(json.dumps({'gpio_exported':p.exists(),'manager_state':Path('/sys/class/fpga_manager/fpga0/state').read_text().strip()}))"
post,_=call('post-cleanup','/usr/local/share/pynq-venv/bin/python3 -I -B -c '+shlex.quote(check))
post=json.loads(post);save('post-cleanup.json',post)
assert exit_code==0 and report['status']=='passed' and not report['errors']
assert len(report['samples'])==384 and all(s['passed'] and s['write_completed'] and s['expected']==s['observed'] for s in report['samples'])
rest=report['restoration'];assert len(rest['words'])==16 and all(s['passed'] and s['write_completed'] and s['expected']==s['observed'] for s in rest['words'])
assert rest['bram_restored'] and rest['reset_restored'] and rest['export_state_restored']
assert post['gpio_exported']==report['initial_reset']['exported'] and post['manager_state']=='operating'
save('main-verification.json',dict(utc=datetime.now(timezone.utc).isoformat(),operation_id=OP,request_hash=request_hash,code_commit=request['code_commit'],tested_commit=request['tested_commit'],script_sha256=sha(source),status='passed',actual_loads=1,comparisons=384,restored_words=16,reset_and_export_restored=True,post_manager='operating',original_configuration_restored=report['original_configuration_restored'],scope='matched PYNQ base Overlay and 64-byte BRAM window only; current physical readiness evidence',R03='not_run',full_H12='not_run',all29='not_run'))
print(json.dumps({'operation_id':OP,'request_hash':request_hash,'status':'passed','actual_loads':1,'comparisons':384,'restored_words':16,'manager':'operating','R03':'not_run'}),flush=True)
