"""Exactly one selected full GET, then one bounded data-only wheel verification."""
from datetime import datetime, timezone
import email.parser
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
import traceback

D = Path(__file__).resolve().parent
selection = json.loads((D / "selection.json").read_bytes())
incoming = json.loads((D / "incoming-pins.json").read_bytes())["files"]
tag = sys.argv[1]
chosen = next(n for n in selection["files"] if n["id"] == tag)
index = selection["files"].index(chosen)
Q = D / "requests" / tag
RUNS = D / "runs"


def pin(p):
    raw = Path(p).read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(path, value):
    assert path.resolve().is_relative_to(D)
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write("\n")


def closed(r):
    assert r["all_processes_terminated"] is True
    if "active_processes_final" in r:
        assert r["active_processes_final"] == 0
    else:
        assert r["status"] == "failed", "normal terminal requires active count"
    assert r["held_members"] and all(x["signaled"] is True and x["wait_result"] == 0 for x in r["held_members"])
    assert not r["faults"]


for name, expected in incoming.items():
    assert pin(name) == expected, name
for old in RUNS.iterdir():
    assert old.is_dir()
    r = json.loads((old / "terminal.json").read_bytes())
    closed(r)
    assert r["exit_code"] == 0 and r["status"] == "success", "prior failed/unknown run: stop new acquisition"
for n in selection["files"][:index]:
    old = D / "requests" / n["id"]
    assert json.loads((old / "download-result.json").read_bytes())["outcome"] == "complete"
    assert json.loads((old / "verification-result.json").read_bytes())["status"] == "success"
    assert json.loads((old / "request-closeout.json").read_bytes())["status"] == "complete"
assert sorted(p.name for p in (D / "requests").iterdir()) == sorted(n["id"] for n in selection["files"][:index])
assert len(selection["files"]) == 5 and sum(n["compressed_bytes"] for n in selection["files"]) == 3197515
assert sum(n["compressed_bytes"] for n in selection["files"]) <= 4*1024**2
artifact = Path(chosen["artifact_path"])
assert artifact.parent == D / "artifacts" and not artifact.exists() and not Q.exists()
assert chosen["compressed_bytes"] <= 3*1024**2
free_before = shutil.disk_usage(D).free
assert free_before - chosen["compressed_bytes"] - 256*1024 >= 10*1024**3
runner = Path(selection["runner"])
assert pin(runner / "win_job.py")["sha256"] == "80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d"
sys.path.insert(0, str(runner))
from win_job import run_bounded
Q.mkdir()
save(Q / "request.json", chosen)
env = {k: v for k, v in os.environ.items() if k.upper() in ("SYSTEMROOT", "WINDIR")}
env.update(PATH="", TEMP=str(Q), TMP=str(Q), PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
curl = Path(selection["curl"])
curl_pin = pin(curl)
assert curl_pin["sha256"] == "73d24149ff289afc49ec41f08918ef9faa727d39ad993e929757dc2ddafab805"
argv = [str(curl), "-q", "--http1.1", "--silent", "--show-error", "--proto", "=https",
    "--connect-timeout", "10", "--max-time", "40", "--retry", "0", "--max-redirs", "0",
    "--max-filesize", str(chosen["compressed_bytes"]), "--dump-header", str(Q / "headers.txt"),
    "--output", str(artifact), "--write-out", "%{json}",
    "--header", "Accept-Encoding: identity", "--header", "User-Agent: DeepEye-A-selected-five-wheels-20261021",
    "--url", chosen["artifact_url"]]
budget = {"seconds": 45, "job_memory_bytes": 512*1024**2, "process_memory_bytes": 256*1024**2,
    "active_processes": 4, "stdout_bytes": 65536, "stderr_bytes": 65536,
    "tree_bytes": 16*1024**2, "tree_entries": 3000, "free_reserve_bytes": 10*1024**3,
    "components": [{"path": str(D / "artifacts"), "bytes": 4*1024**2, "entries": 5}]}
before = {p: pin(p) for p in incoming}
receipt = {"id": tag, "request": chosen, "argv": argv, "environment": env,
    "started_utc": datetime.now(timezone.utc).isoformat(), "curl_image": {"path": str(curl), **curl_pin},
    "disk_free_before": free_before, "requested_response_cap": chosen["compressed_bytes"],
    "maximum_response_cap": 3*1024**2, "maximum_aggregate_cap": 4*1024**2,
    "conservative_charge_after_this_request": sum(n["compressed_bytes"] for n in selection["files"][:index+1]),
    "network_seconds": 40, "child_seconds": 45, "wrapper_seconds": 50,
    "inputs_before": before, "hidden": True, "retries": 0}
save(Q / "download-started.json", receipt)
process_dir = RUNS / (tag + "-curl")
tick = time.monotonic()


def on_tick(job, pids):
    assert len(pids) <= 4, "bounded original curl process tree"
    started = json.loads((process_dir / "started.json").read_bytes())
    assert started["launcher"]["image_sha256"] == curl_pin["sha256"]
    assert Path(started["launcher"]["image"]) == curl
    if artifact.exists():
        assert artifact.stat().st_size <= chosen["compressed_bytes"], "exact response byte cap"
    if (Q / "headers.txt").exists():
        assert (Q / "headers.txt").stat().st_size <= 65536, "header cap"
    actual = list((D / "artifacts").iterdir())
    assert all(p.is_file() for p in actual) and len(actual) <= 5
    assert sum(p.stat().st_size for p in actual) <= 4*1024**2


success = False
try:
    terminal = run_bounded(argv, env, D, process_dir, budget,
        [D / "artifacts", D / "requests", D / "runs"], on_tick=on_tick)
    receipt["process_terminal"] = terminal
    closed(terminal)
    assert 1 <= len(terminal["held_members"]) <= 4 and 1 <= terminal["total_job_processes"] <= 4
    assert terminal["exit_code"] == 0 and terminal["status"] == "success" and terminal["stop_reason"] is None
    started = json.loads((process_dir / "started.json").read_bytes())
    assert started["assigned_before_resume"] and started["private_job"] and started["hidden"]
    assert started["argv"] == argv and started["launcher"]["image_sha256"] == curl_pin["sha256"]
    receipt["source_process_identity"] = started["launcher"]
    raw = (Q / "headers.txt").read_bytes()
    blocks = [b for b in re.split(br"\r?\n\r?\n", raw) if b.startswith(b"HTTP/")]
    assert len(blocks) == 1, "one HTTP response only"
    status, fields = blocks[0].split(b"\n", 1)
    headers = {k.lower(): v.strip() for k, v in email.parser.BytesHeaderParser().parsebytes(fields).items()}
    curl_meta = json.loads((process_dir / "stdout.txt").read_bytes())
    receipt.update(status_line=status.strip().decode("ascii"), response_headers=headers, curl_metadata=curl_meta)
    assert curl_meta["exitcode"] == 0 and curl_meta["http_code"] == 200
    assert curl_meta["num_redirects"] == curl_meta["num_retries"] == curl_meta["ssl_verify_result"] == 0
    assert curl_meta["url_effective"] == chosen["artifact_url"] and curl_meta["scheme"] == "https"
    assert curl_meta["method"] == "GET" and headers.get("content-encoding", "identity") == "identity"
    actual = pin(artifact)
    assert actual == {"bytes": chosen["compressed_bytes"], "sha256": chosen["published_sha256"]}
    assert int(curl_meta["size_download"]) == actual["bytes"]
    assert headers.get("content-length") == str(actual["bytes"]) and "content-range" not in headers
    assert time.monotonic() - tick <= 50, "download wrapper deadline"
    assert pin(curl) == curl_pin and shutil.disk_usage(D).free >= 10*1024**3
    receipt["outcome"] = "complete"
    success = True
except BaseException:
    receipt.update(outcome="failed_stopped_object", error=traceback.format_exc())
finally:
    receipt.update(ended_utc=datetime.now(timezone.utc).isoformat(),
        wrapper_seconds_observed=time.monotonic()-tick,
        body=pin(artifact) if artifact.exists() else None, disk_free_after=shutil.disk_usage(D).free,
        inputs_after={p: pin(p) for p in incoming})
    receipt["inputs_unchanged"] = receipt["inputs_before"] == receipt["inputs_after"]
    save(Q / "download-result.json", receipt)
if not success or not receipt["inputs_unchanged"]:
    print(json.dumps({"id": tag, "outcome": receipt["outcome"], "new_acquisition_stopped": True}))
    raise SystemExit(1)

verify_argv = [selection["python"], "-I", "-S", "-B", "-X", "utf8", str(D / "verify_wheel.py"), tag]
verify_budget = {**budget, "seconds": 50, "active_processes": 4,
                 "stdout_bytes": 1024*1024, "stderr_bytes": 1024*1024}
verify_dir = RUNS / (tag + "-verify")
result = run_bounded(verify_argv, env, D, verify_dir, verify_budget,
    [D / "artifacts", D / "requests", D / "runs"])
closed(result)
assert result["status"] == "success" and result["exit_code"] == 0
verified = json.loads((Q / "verification-result.json").read_bytes())
assert verified["status"] == "success" and verified["artifact"] == receipt["body"]
detail = json.loads((Q / "archive-review.json").read_bytes())
assert detail["python"]["pid"] in [x["pid"] for x in result["held_members"]]
assert pin(detail["python"]["base_executable"])["sha256"] == selection["worker_image_sha256"]
assert all(pin(p) == expected for p, expected in incoming.items())
save(Q / "request-closeout.json", {"status": "complete", "artifact": receipt["body"],
    "request": pin(Q / "request.json"), "download_receipt": pin(Q / "download-result.json"),
    "curl_terminal": pin(process_dir / "terminal.json"), "verify_terminal": pin(verify_dir / "terminal.json"),
    "archive_review": pin(Q / "archive-review.json"), "verification_result": pin(Q / "verification-result.json"),
    "all_owned_processes_signaled": True, "input_pins_unchanged": True,
    "R02": "not_run", "C03": "not_run", "all29": "not_run"})
print(json.dumps({"id": tag, "status": "complete", "bytes": receipt["body"]["bytes"],
    "sha256": receipt["body"]["sha256"], "curl_held": len(terminal["held_members"]),
    "verify_held": len(result["held_members"]), "members": verified["members"]}))
