"""Prepare exact selected local data and copy reviewed validator definitions."""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
from urllib.parse import urlsplit, unquote

D = Path(__file__).resolve().parent
ROOT, B = D.parents[2], D.parent
PRIOR = B / "r02-wheel-postrun-independent-20261021"
LEDGER = PRIOR / "audit-03/missing-wheels.json"
PINS = {}


def pin(p):
    raw = p.read_bytes()
    out = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    PINS[str(p.resolve())] = out
    return out


def load(p):
    pin(p)
    return json.loads(p.read_bytes())


def save(name, value):
    with (D / name).open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write("\n")


assert pin(LEDGER)["sha256"] == "ef183fffa85631e9ff89e5dc2eb56c278fafadef661f3e5dfc6c74d402122ef5"
ledger = load(LEDGER)
contract = load(ROOT / "docs/competition/deepeye-2026/immutable_scope.json")
pin(ROOT / "docs/competition/deepeye-2026/immutable_scope.md")
contract_sha = hashlib.sha256(json.dumps(contract["requirements"], sort_keys=True,
    separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
assert contract_sha == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
assert [x["id"] for x in contract["requirements"]] == [f"H{i:02}" for i in range(1, 16)]
transfer = load(ROOT / ".planning/deepeye-desktop-handoff-20261015/transfer.json")
assert transfer["status"] == "active" and transfer["director_generation"] == 2
assert transfer["new_director_thread_id"] == "01a13d7e-dcf1-7272-a738-a637dd62ff9d"
validation = load(D / "main-selection.json")
assert validation["source_job_cancelled_terminal"] is True
assert validation["execution_allowed"] is True
old_manifest = load(PRIOR / "nonsecret-artifactmanifest.json")
assert pin(PRIOR / "nonsecret-artifactmanifest.json")["sha256"] == "02fe20f7d31c74b3d05fb47e379dc5a30227ee125326057f813416869bbad29a"
source = PRIOR / "audit_review.py"
assert pin(source) == old_manifest["files"]["audit_review.py"]
text = source.read_text(encoding="utf-8")
module = ast.parse(text)
names = ("digest", "require", "safe_name", "zip_data")
definitions = {n.name: ast.get_source_segment(text, n) for n in module.body
               if isinstance(n, ast.FunctionDef) and n.name in names}
assert set(definitions) == set(names)
header = '''"""Exact reviewed validator definitions; only trusted stdlib imports."""
import base64
import csv
from email.parser import BytesParser
from email import policy
import hashlib
import io
from pathlib import PurePosixPath
import stat
import struct
import unicodedata
import zipfile
import zlib

'''
with (D / "archive_data.py").open("x", encoding="utf-8", newline="\n") as f:
    f.write(header + "\n\n\n".join(definitions[n] for n in names) + "\n")
save("validator-provenance.json", {"source": str(source), "source_pin": pin(source),
    "definitions_copied_without_changes": list(names),
    "definition_text_sha256": {n: hashlib.sha256(definitions[n].encode()).hexdigest() for n in names},
    "new_module_pin": pin(D / "archive_data.py"),
    "top_level_original_audit_not_imported_or_executed": True})

runner = B / "r02-transient-quota-fix-20261021"
for name, value in {"win_job.py": "80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d",
    "boundary.py": "04cf7d53f3dbf1fca66aab05fe497ae193aab94a56ab4e0d36e81d1eb0a040fe"}.items():
    assert pin(runner / name)["sha256"] == value
curl = D / "tool-image/curl.exe"
assert pin(curl)["sha256"] == "73d24149ff289afc49ec41f08918ef9faa727d39ad993e929757dc2ddafab805"
recipe = load(runner / "prepared-recipe-v6.json")
for row in recipe["interpreter"]:
    assert pin(Path(row["path"])) == {"bytes": row["bytes"], "sha256": row["sha256"]}
for name in ("artifacts", "requests", "runs"):
    (D / name).mkdir()
selected = []
for n in ledger["entries"]:
    if n["group"] != "ordinary_python_five":
        continue
    url = urlsplit(n["artifact_url"])
    assert url.scheme == "https" and url.hostname == "files.pythonhosted.org" and not url.query
    assert not url.fragment and url.username is None and url.password is None
    filename = unquote(url.path.rsplit("/", 1)[1])
    assert filename.endswith(".whl") and filename.isascii() and "/" not in filename and "\\" not in filename
    assert 0 < n["compressed_bytes"] <= 3*1024**2 and len(n["published_sha256"]) == 64
    metadata = [s for s in n["metadata_sources"] if s["path"].endswith("METADATA.txt")]
    assert len(metadata) == 1
    assert pin(Path(metadata[0]["path"])) == {k: metadata[0][k] for k in ("bytes", "sha256")}
    selected.append({**n, "id": f"{len(selected)+1:03}-{n['name']}", "filename": filename,
        "artifact_path": str(D / "artifacts" / filename), "accepted_metadata": metadata[0]})
assert {n["name"] for n in selected} == {"filelock", "fsspec", "jinja2", "mpmath", "networkx"}
assert sum(n["compressed_bytes"] for n in selected) == 3197515 <= 4*1024**2
save("selection.json", {"work_id": validation["work_id"], "job_id": validation["job_id"],
    "requirements_sha256": contract_sha, "ledger": str(LEDGER), "ledger_pin": pin(LEDGER),
    "files": selected, "curl": str(curl), "runner": str(runner),
    "python": recipe["python"], "worker_image_sha256": recipe["worker_image_sha256"],
    "maximum_requests": 5, "maximum_response_bytes": 3*1024**2, "maximum_aggregate_bytes": 4*1024**2,
    "exact_selected_bytes": 3197515, "network_seconds": 40, "child_seconds": 45,
    "wrapper_seconds": 50, "free_reserve_bytes": 10*1024**3,
    "initial_free_bytes": shutil.disk_usage(D).free, "prepared_utc": datetime.now(timezone.utc).isoformat(),
    "AMD_acquisition_authorized": False, "R02": "not_run", "C03": "not_run", "all29": "not_run"})
pin(D / "selection.json")
for path in D.glob("*.py"):
    ast.parse(path.read_text(encoding="utf-8"))
    pin(path)
for name in ("plan.md", "assignment.md", "validator-provenance.json"):
    pin(D / name)
save("incoming-pins.json", {"files": PINS, "file_count": len(PINS)})
print(json.dumps({"status": "prepared", "five_urls": 5, "total_bytes": 3197515,
    "input_files": len(PINS), "free_bytes": shutil.disk_usage(D).free}))
