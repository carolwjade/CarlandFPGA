from datetime import datetime,timezone
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];OUT=D.parent
P=ROOT/'.local/deepeye-implementation-a';WORK=P/'competition/deepeye'
BASE=OUT/'r03-current-validation-20261021';R=OUT/'r02-transient-quota-fix-20261021'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
prior=json.loads((BASE/'checker-result.json').read_bytes())
before=json.loads((BASE/'selection.json').read_bytes())
for rel,h in before['source_pins'].items():assert sha(WORK/rel)==h,rel
deps=ROOT/'.local/deepeye-host-deps'
assert (deps/'jsonschema-4.25.1.dist-info/METADATA').is_file()
dep_pins={str(p):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(deps.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
(D/'empty-cache').mkdir();(D/'temp').mkdir()
env=dict(os.environ);env.update(PYTHONPATH=str(deps),PYTHONDONTWRITEBYTECODE='1',PYTHONPYCACHEPREFIX=str(D/'empty-cache'),PYTHONIOENCODING='utf-8',PYTHONNOUSERSITE='1',TEMP=str(D/'temp'),TMP=str(D/'temp'))
budget=dict(seconds=50,job_memory_bytes=1024**3,process_memory_bytes=512*1024**2,active_processes=32,stdout_bytes=4*1024**2,stderr_bytes=4*1024**2,tree_bytes=96*1024**2,tree_entries=12000,free_reserve_bytes=10*1024**3)
todo=[c for c in prior['checks'] if c['exit_code']!=0];assert len(todo)==5
save('selection.json',dict(utc=datetime.now(timezone.utc).isoformat(),head=before['head'],original_failure=str(BASE/'checker-result.json'),cause1='root venv lacked jsonschema; reuse existing pinned host dependency directory',cause2='original active_processes=8 produced WinError1816 during nested Git; no product logic changed',budget=budget,commands=[c['command'] for c in todo],dependency_pins=dep_pins,unchanged_passed_checks=len(prior['checks'])-len(todo),cache_policy='new empty prefix, inherited by child interpreters, no old cache deletion'))
assert sha(R/'win_job.py')=='80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d'
sys.path.insert(0,str(R));from win_job import run_bounded
results=[]
for index,c in enumerate(todo,1):
 target=D/(f'{index:02}-'+Path(c['command'][4]).stem)
 t=run_bounded(c['command'],env,WORK,target,budget,[D])
 assert t['all_processes_terminated'] and t['active_processes_final']==0
 assert all(h['signaled'] and h['wait_result']==0 for h in t['held_members'])
 raw=(target/'stdout.txt').read_bytes()+(target/'stderr.txt').read_bytes()
 row=dict(command=c['command'],exit_code=t['exit_code'],runner_status=t['status'],held=len(t['held_members']),output_sha256=hashlib.sha256(raw).hexdigest(),output=raw.decode('utf-8'),evidence=str(target))
 results.append(row);save(f'{index:02}-result.json',row)
 print(json.dumps({'command':c['command'][4:],'exit':t['exit_code'],'held':len(t['held_members']),'seconds':t['seconds']}),flush=True)
 if t['exit_code']!=0:break
for rel,h in before['source_pins'].items():assert sha(WORK/rel)==h,rel
for name,pin in dep_pins.items():assert sha(Path(name))==pin['sha256'],name
assert not any((D/'empty-cache').rglob('*.pyc'))
summary=dict(utc=datetime.now(timezone.utc).isoformat(),head=before['head'],rerun_results=[{k:v for k,v in x.items() if k!='output'} for x in results],all_selected_passed=len(results)==5 and all(x['exit_code']==0 for x in results),aggregate_scope='original eight passing groups plus five targeted repeats at the same unchanged source; not a new full-checker invocation',dependency_pins_unchanged=True,source_pins_unchanged=True,R03='not_run',full_H12='not_run',all29='not_run',remaining_gates=prior['remaining_gates'])
save('main-verification.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k!='rerun_results'},ensure_ascii=False))
