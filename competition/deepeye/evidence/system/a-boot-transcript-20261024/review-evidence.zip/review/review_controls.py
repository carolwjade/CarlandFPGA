"""Independent new local-pipe controls; never imports or reruns author tests."""
import binascii
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time
import traceback
from unittest.mock import patch

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCT = ROOT / '.local/deepeye-implementation-a'
sys.path.insert(0, str(PRODUCT))
from competition.deepeye.integration import boot_profile as boot
from competition.deepeye.integration import boot_transcript as module
from competition.deepeye.integration.live_board_receipts import CaptureIdentity, ReceiptLedger


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def ack(request, sequence_delta=0):
    # Direct independent CRC packet using only the actual emitted bytes.
    magic, version, _, length, epoch, sequence, tick = struct.unpack('<2sBBBBHI', request[:12])
    assert magic == b'\xa5\x5a' and version == 3 and len(request) == length + 14
    assert binascii.crc_hqx(request[2:-2], 0xffff) == struct.unpack('<H', request[-2:])[0]
    body = struct.pack('<2sBBBBHI', magic, version, 13, length, epoch,
                       (sequence + sequence_delta) & 0xffff, tick + 999) + request[12:-2]
    return body + struct.pack('<H', binascii.crc_hqx(body[2:], 0xffff))


def expect(exception, action):
    try:
        action()
    except exception as error:
        return type(error).__name__
    raise AssertionError('expected ' + exception.__name__)


class Fixture:
    def __init__(self, name):
        self.directory = OUT / 'controls' / name
        self.directory.mkdir(parents=True, exist_ok=False)
        self.rx, self.tx = os.pipe()
        self.ir, self.iw = os.pipe()
        os.set_blocking(self.rx, False)
        os.set_blocking(self.ir, False)
        self.manifest = b'independent-review original opaque manifest bytes\x00\xff'
        self.identity = CaptureIdentity('independent-boot-review', '1'*64, '2'*40,
            hashlib.sha256(self.manifest).hexdigest(), 71)
        self.ledger = ReceiptLedger(self.ir, self.identity, max_bytes=4096, max_reads=20)
        self.profile = boot.load_document(PRODUCT / 'competition/deepeye/docs/boot_profiles.json')
        self.args = dict(identity=self.identity, profile=self.profile,
            profile_sha256=boot.canonical_sha256(self.profile).hex(), build_manifest=self.manifest,
            bit_sha256='3'*64, hwh_sha256='4'*64, session=0x1234abcd,
            mode=boot.compose_boot_mode('fast_9600', 'software_fixture', 'pc_direct'),
            config_epoch=71, sequence=0x9876, tick_ms=0x11223344,
            max_ack_checks=3, journal_path=self.directory / 'attempt.jsonl')
        self.transcript = None

    def make(self):
        self.transcript = module.BootTranscript(self.tx, self.ledger, **self.args)
        return self.transcript

    def receive(self, raw):
        assert os.write(self.iw, raw) == len(raw)
        event, = self.ledger.read_once()
        return event

    def close(self):
        if self.transcript is not None:
            save(self.directory / 'transcript-before-close.json', self.transcript.snapshot())
            self.transcript.close()
            save(self.directory / 'transcript-closed.json', self.transcript.snapshot())
        save(self.directory / 'ledger.json', self.ledger.snapshot())
        self.ledger.close()
        for fd in (self.rx, self.tx, self.ir, self.iw):
            os.close(fd)


def durable_start_ack_failure():
    f = Fixture('durable-start-ack-journal-failure')
    try:
        tx = f.make()
        original_write, original_fsync = os.write, os.fsync
        calls, syncs = [], []
        def sync(fd):
            original_fsync(fd)
            syncs.append(fd)
        def write(fd, raw):
            if fd == tx._fd:
                saved = [json.loads(x) for x in f.args['journal_path'].read_bytes().splitlines()]
                assert saved[-1]['kind'] == 'write_started'
                assert saved[-1]['outcome'] == 'started_unknown'
                assert saved[-1]['raw_hex'] == raw.hex()
                assert tx._journal.fileno() in syncs
                calls.append({'fd': fd, 'raw_hex': raw.hex(), 'journal_at_entry': saved[-1]})
            return original_write(fd, raw)
        with patch.object(module.os, 'fsync', sync), patch.object(module.os, 'write', write):
            attempt = tx.send_once()
            emitted = os.read(f.rx, 4096)
            assert len(emitted) == attempt['bytes_written'] == 41
            bad_raw = ack(emitted, 1)
            bad = f.receive(bad_raw)
            assert tx.check_ack(bad)['echo'] == {'ok': False, 'mismatches': ['sequence']}
            expect(ValueError, lambda: tx.check_ack(bad))
            good_raw = ack(emitted)
            good = f.receive(good_raw)
            with patch.object(module.os, 'fsync', side_effect=OSError('independent ACK fsync fault')):
                expect(OSError, lambda: tx.check_ack(good))
            state = tx.snapshot()
            assert state['journal_failed'] and len(state['ack_checks']) == 2
            assert state['ack_checks'][-1]['echo']['ok']
            expect(ValueError, lambda: tx.check_ack(good))
            expect(ValueError, tx.send_once)
            tx.close()
            expect(ValueError, tx.send_once)
            expect(ValueError, lambda: tx.check_ack(good))
            assert len(calls) == 1
            # Both caller endpoints remain usable after the transcript close.
            assert original_write(f.tx, b'caller-writer-lives') == 19
            assert os.read(f.rx, 4096) == b'caller-writer-lives'
            next_raw = ack(emitted, 2)
            next_event = f.receive(next_raw)
            assert next_event.raw == next_raw
            expect(BlockingIOError, lambda: os.read(f.rx, 1))
        (f.directory / 'boot-emitted.bin').write_bytes(emitted)
        (f.directory / 'bad-ack.bin').write_bytes(bad_raw)
        (f.directory / 'good-ack.bin').write_bytes(good_raw)
        save(f.directory / 'write-observer.json', {'calls': calls, 'successful_fsyncs': syncs})
    finally:
        f.close()


def saturate(fd):
    os.set_blocking(fd, False)
    written = 0
    while written < 1024*1024:
        try:
            count = os.write(fd, b'F'*4096)
        except BlockingIOError:
            return written
        assert count > 0
        written += count
    raise AssertionError('unexpectedly large pipe; bounded fill stopped')


def real_pipe_full():
    f = Fixture('real-pipe-full')
    try:
        filled = saturate(f.tx)
        assert filled > 0
        tx = f.make()
        failure = expect(BlockingIOError, tx.send_once)
        state = tx.snapshot()
        assert state['attempt']['outcome'] == 'write_error_unknown'
        assert state['attempt']['bytes_written'] is None
        expect(ValueError, tx.send_once)
        tx.close()
        chunks = []
        while True:
            try:
                chunk = os.read(f.rx, 8192)
            except BlockingIOError:
                break
            assert chunk
            chunks.append(chunk)
        drained = b''.join(chunks)
        assert drained == b'F'*filled
        (f.directory / 'actual-drained.bin').write_bytes(drained)
        save(f.directory / 'control.json', {'filled_bytes': filled, 'drained_bytes': len(drained),
             'exception': failure, 'drained_sha256': hashlib.sha256(drained).hexdigest(),
             'boot_bytes_observed': 0, 'fault_injection': False})
    finally:
        f.close()


def invalid_before_effects_and_frozen_profile():
    f = Fixture('invalid-before-effects-and-frozen-profile')
    try:
        original_write = os.write
        attempts = []
        def track(fd, raw):
            attempts.append({'fd': fd, 'hex': raw.hex()})
            return original_write(fd, raw)
        invalid = [dict(session=False), dict(max_ack_checks=65), dict(mode=255),
                   dict(build_manifest=bytearray(f.manifest)), dict(profile_sha256='A'*64)]
        for change in invalid:
            with patch.object(module.os, 'write', track):
                expect(ValueError, lambda: module.BootTranscript(f.tx, f.ledger, **(f.args | change)))
            assert not f.args['journal_path'].exists()
        assert not attempts
        expect(BlockingIOError, lambda: os.read(f.rx, 1))
        frozen_sha = f.args['profile_sha256']
        tx = f.make()
        f.profile.clear()  # Mutating the caller document cannot change the frozen packet.
        attempt = tx.send_once()
        actual = os.read(f.rx, 4096)
        assert attempt['raw_hex'] == actual.hex()
        state = tx.snapshot()
        assert state['prepared']['profile_sha256'] == frozen_sha
        assert boot.canonical_sha256(state['profile']).hex() == frozen_sha
        event = f.receive(ack(actual))
        f.ledger.identity = dataclasses.replace(f.identity, connection_generation=72)
        expect(ValueError, lambda: tx.check_ack(event))
        assert not tx.snapshot()['ack_checks']
        f.ledger.identity = f.identity
        assert tx.check_ack(event)['echo']['ok']
        assert not tx.snapshot()['authenticated']
        (f.directory / 'boot-emitted.bin').write_bytes(actual)
        save(f.directory / 'control.json', {'invalid_cases': len(invalid),
            'writes_for_invalid_inputs': len(attempts), 'postwrite_identity_change_rejected': True,
            'profile_digest_after_caller_mutation': boot.canonical_sha256(state['profile']).hex(),
            'authority': False})
    finally:
        f.close()


def blocking_child():
    f = Fixture('blocked-child')
    filled = saturate(f.tx)
    os.set_blocking(f.tx, True)
    tx = f.make()
    original_write = os.write
    def write(fd, raw):
        if fd == tx._fd:
            save(f.directory / 'write-entry.json', {'pid': os.getpid(), 'filled_bytes': filled,
                'raw_hex': raw.hex(), 'marker': 'immediately before actual blocking os.write'})
        return original_write(fd, raw)
    with patch.object(module.os, 'write', write):
        tx.send_once()
    raise AssertionError('full blocking pipe unexpectedly returned')


def terminated_blocking_write():
    command = [sys.executable, '-B', '-X', 'utf8', str(Path(__file__).resolve()), '--blocking-child']
    process = subprocess.Popen(command, cwd=ROOT, env=os.environ.copy(),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    directory = OUT / 'controls/blocked-child'
    entry = directory / 'write-entry.json'
    deadline = time.monotonic() + 8
    try:
        while not entry.exists() and process.poll() is None and time.monotonic() < deadline:
            time.sleep(.025)
        assert entry.exists(), 'child failed to reach actual OS-write boundary'
        time.sleep(.15)
        assert process.poll() is None, 'child did not remain blocked'
        process.terminate()
        stdout, stderr = process.communicate(timeout=3)
        rows = [json.loads(x) for x in (directory / 'attempt.jsonl').read_bytes().splitlines()]
        assert [x['kind'] for x in rows] == ['prepared', 'write_started']
        assert rows[-1]['outcome'] == 'started_unknown'
        # Same-path reopening still refuses to write, using independent parent endpoints.
        f = Fixture('same-path-after-process-termination')
        try:
            f.args['journal_path'] = directory / 'attempt.jsonl'
            expect(FileExistsError, f.make)
            expect(BlockingIOError, lambda: os.read(f.rx, 1))
        finally:
            f.close()
        (directory / 'child.stdout').write_bytes(stdout)
        (directory / 'child.stderr').write_bytes(stderr)
        save(directory / 'supervisor.json', {'command': command, 'pid': process.pid,
            'exit_code': process.returncode, 'termination_requested': True,
            'alive_after_write_boundary_150ms': True, 'journal_kinds': [x['kind'] for x in rows],
            'limits': 'write-entry is an observation wrapper; child had no reader draining the full OS pipe; '
                      'no BOOT delivery, hardware, durability-after-power-loss or global deduplication claim'})
    finally:
        if process.poll() is None:
            process.kill()
            process.communicate(timeout=3)


if __name__ == '__main__':
    if '--blocking-child' in sys.argv:
        blocking_child()
    else:
        results = []
        for control in [durable_start_ack_failure, real_pipe_full,
                        invalid_before_effects_and_frozen_profile, terminated_blocking_write]:
            begin = time.time_ns()
            try:
                control()
                result = {'name': control.__name__, 'status': 'passed'}
            except BaseException as error:
                traceback.print_exc()
                result = {'name': control.__name__, 'status': 'failed', 'error': repr(error)}
            result.update(started_unix_ns=begin, finished_unix_ns=time.time_ns())
            results.append(result)
            print(json.dumps(result), flush=True)
        save(OUT / 'new-controls.json', {'controls': results, 'author_tests_rerun': False})
        sys.exit(0 if all(x['status'] == 'passed' for x in results) else 1)
