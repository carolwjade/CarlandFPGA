"""Seal only the assigned review output; omit lease secrets and terminal receipt."""
import hashlib
import json
from pathlib import Path
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCT = ROOT / '.local/deepeye-implementation-a'


def load(name):
    return json.loads((OUT/name).read_text(encoding='utf-8'))


def save(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n',encoding='utf-8')


# Preserve the exact failed checker revision without executing it again.
current = (OUT/'audit_saved_evidence.py').read_text(encoding='utf-8')
begin = current.index("actual_head = git_evidence['rev-parse HEAD']['stdout'].strip()")
end = current.index("source['git']=git_evidence", begin)
previous = current[:begin] + "assert git_evidence['rev-parse HEAD']['stdout'].strip() == '2403ae496719b7321599471edc5b70b4ff5fee2c'\n" + current[end:]
assert hashlib.sha256(previous.encode('utf-8')).hexdigest() == 'bbd58c91c2d14067f18b6d659152abea1bbf9a7a0513a07266460fb30dc98c33'
(OUT/'audit-01.py').write_text(previous, encoding='utf-8', newline='\n')

preflight = load('preflight.json')
sources = preflight['source_files']
for row in sources:
    raw=(PRODUCT/row['path']).read_bytes()
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
save('sourcehashes.json', {'files':sources, 'verified_unix_ns':time.time_ns(),
                         'candidate_base':'2403ae496719b7321599471edc5b70b4ff5fee2c',
                         'observed_head':preflight['git']['rev-parse HEAD']['stdout'].strip()})
execution=load('execution.json')
controls=load('new-controls.json')['controls']
assert execution['exit_code']==0 and len(controls)==4 and all(x['status']=='passed' for x in controls)
audit=load('saved-evidence-audit.json')
save('audit-02-execution.json', {'command':[sys.executable,'-B','-X','utf8',str(OUT/'audit_saved_evidence.py')],
    'tool':'exec_command','exit_code':0,'directories':len(audit['directories']),
    'frames_reconstructed':sum(x['frames_reconstructed_from_original_spans'] for x in audit['directories']),
    'ack_checks':sum(x['ack_checks_independently_compared'] for x in audit['directories']),
    'note':'Recorded from completed tool output; no controls rerun during sealing.'})
(OUT/'audit-02.log').write_text('directories=20 frames=19 ack_checks=15 source_pins_unchanged=true head=353aa3a540576e92e023eaa62c68487a8a1d00d6\nexit_code=0\n',encoding='utf-8')
save('result.json', {
    'work_id':'A-BOOT-TRANSCRIPT-REVIEW-20261024-v1',
    'task':'DEEPEYE-IMPLEMENTATION-20261014/v1',
    'agent_id':'/root/boot_transcript_review',
    'job_id':'child-cfed5144a8384501b99ecdbd2a41a951',
    'status':'independent_review_complete_pending_main_integration',
    'finding':'no_material_defect_found_in_assigned_diagnostic_scope',
    'material_findings':[],
    'candidate_base':'2403ae496719b7321599471edc5b70b4ff5fee2c',
    'observed_head':'353aa3a540576e92e023eaa62c68487a8a1d00d6',
    'head_difference':'root-owned archive of five op25/26 evidence files; reviewed source pins unchanged',
    'candidate_sources':[x for x in sources if x['group']=='owned'],
    'frozen_dependencies':[x for x in sources if x['group']=='readonly_inputs'],
    'requirements_sha256':preflight['requirements_sha256'],
    'contract_id':'DEEPEYE-HUMAN-LOCK-20261014/revision1',
    'H01_H15_preserved':True,
    'director_generation':3,
    'director_thread':'01a16988-bdcb-70e1-ae10-1304b5cf7875',
    'controls':{'new_local_pipe_controls':4,'passed':4,'exit_code':0,
                'command':execution['command'],'tool':execution['tool'],
                'child_only_pythonpath':execution['PYTHONPATH_child_only'],
                'actual_terminated_child_exit_code':1,
                'termination_exit_is_expected':True,
                'author_16_tests_rerun':False,'old_tests_PDE_384_rerun':False},
    'saved_evidence':{'author_manifest_artifacts_verified':45,
                      'directories_audited':20,'original_frames_reconstructed':19,
                      'ack_checks_independently_compared':15,'exit_code':0,
                      'initial_stale_head_assertion_exit_code':1,
                      'initial_failure_preserved':'audit-01-failure.log and audit-01.py'},
    'product_acceptance':False,'board_run':False,'G03':'not_run','R03':'not_run','all29':'not_run',
    'report':'report.md','sourcehashes':'sourcehashes.json','manifest':'manifest.json',
    'limits':[
        'diagnostic correlation only; no authenticated/fresh BOOT, BootBinding, Verified object, action, sample or provider activation',
        'original profile/build labels and hashes do not prove actual load, authenticity or bit/HWH manifest membership',
        'read/write brackets are not UART arrival/completion or source sample time',
        'main owns global operation/session/connection deduplication, original-operation recovery and a bounded supervisor',
        'local OS controls and explicit fsync injection do not establish UART/FPGA or end-to-end acceptance',
        'root alone operates the physical board; no board/serial/network/service/display/PR/message/delegation operations'
    ]})
excluded={'lease.private.json','manifest.json','native-complete.json','freeze-verification.json'}
entries=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name not in excluded:
        raw=path.read_bytes()
        entries.append({'path':path.relative_to(OUT).as_posix(),'bytes':len(raw),
                        'sha256':hashlib.sha256(raw).hexdigest()})
save('manifest.json', {'schema':1,'scope':'frozen independent review artifacts',
    'excluded':sorted(excluded),'files':entries,'file_count':len(entries),
    'note':'Lease secret excluded; native-complete is a later controller receipt and is separately hashed.'})
for row in entries:
    raw=(OUT/row['path']).read_bytes()
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
manifest=(OUT/'manifest.json').read_bytes()
save('freeze-verification.json', {'manifest_sha256':hashlib.sha256(manifest).hexdigest(),
    'file_count':len(entries),'all_manifest_members_verified':True,'source_pins_unchanged':True,
    'freeze_command':[sys.executable,'-B','-X','utf8',str(Path(__file__).resolve())],
    'tool':'exec_command','exit_code':0})
print(json.dumps({'file_count':len(entries),'manifest_sha256':hashlib.sha256(manifest).hexdigest(),
                  'result_sha256':hashlib.sha256((OUT/'result.json').read_bytes()).hexdigest()}))
