# BOOT transcript 独立审查

任务 `A-BOOT-TRANSCRIPT-REVIEW-20261024-v1`，`DEEPEYE-IMPLEMENTATION-20261014/v1`，agent `/root/boot_transcript_review`，job `child-cfed5144a8384501b99ecdbd2a41a951`。执行前 native_validate 以 canonical agent_id 返回 `execution_allowed=true`；token 未输出。仅写本目录，未修改产品、作者证据或其它归属文件。

结论：在本次明确的**诊断准备组件**范围内，未发现需修复的实质代码缺陷。以下是审查证据，最终集成和产品验收由 A/root 决定。本次没有验证生产准入、真实 UART/FPGA、实际 overlay 加载、动作或观测采样。

## 源与范围

产品工作区 `.local/deepeye-implementation-a`。作者候选基础提交为 `2403ae496719b7321599471edc5b70b4ff5fee2c`，三个新产品文件仍未提交。开始审查后 root 归档提交使当前 HEAD 前进到 `353aa3a540576e92e023eaa62c68487a8a1d00d6`；差异仅为五个 `competition/deepeye/evidence/transport/a-op25-26-review-20261024/` 证据文件，未涉及九个审查源 pins。root 已确认此变更归属。审查绑定下列字节，不能把归档提交误称新的生产实现。

| 产品文件（均在 competition/deepeye 下） | 字节 | SHA256 |
| --- | ---: | --- |
| integration/boot_transcript.py | 11160 | `42c9ab081d9266a6a5297cd65e41afd89090608932fb3b432ce1bbaa504f5ebe` |
| integration/test_boot_transcript.py | 14876 | `51e1f9be61ba90884eb6a0d4c849a3a059bab21692b38c3878e1ea707ddc5401` |
| docs/boot_transcript.md | 7293 | `adbd1c75d839b6d925da4decd15c7a20b4a938cb8af5ca2a6c451d49708f23bb` |

六个冻结依赖以及三个候选的完整 pins 在 `sourcehashes.json` / `preflight.json`。在新增控制之前和保存证据重建之后重算均一致；作者最终 manifest 的45项原始 artifacts 亦全部重算长度和SHA一致。

已读当前 ROOT AGENTS、两项项目技能与 A role、协作协议、Gen3 transfer 与 handoff、immutable_scope md/json。现有 node-a.toml 的 node_id 为 A，Gen3 director 为 `01a16988-bdcb-70e1-ae10-1304b5cf7875`。实算 requirements 数组的 UTF-8、ensure_ascii=False、sort_keys=True、紧凑分隔符 canonical SHA256 为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`。H01–H15、私密状态、源时钟和两条 H12 路径不变；root 是唯一实板操作者。

## 代码与证据边界

1. `boot_transcript.py:127` 的 `send_once` 在设置不可重入 attempt 后，先将完整 `write_started/started_unknown` 写入自有 journal、flush、fsync，才调用唯一的 `os.write`（第155行）。short/error/interruption/result-journal-failure 后 attempt 不会清空；journal 故障同时关闭 active gate。没有补余数、循环重送或恢复发送分支。现有 journal 使用 xb 拒绝重开。
2. `check_ack` 第185行先调用原 `ReceiptLedger._original` 验证同一 ledger 的同一对象，直接使用 `event.raw`。原始 read spans 和 stream offsets 来自 ledger；不通过 host 编码 ACK 或复制外来 receipt 建立来源。第194行同时排除已读 pre-write bytes 和跨越写前/后的包；原始不匹配 ACK 消耗一次检查。ACK journal 故障后同一 receipt 不可回收，关闭或后续异常路径没有写调用。
3. 第188–190行和写前第136–139行检查当前 receive identity。完整 profile 被复制、验证并比对冻结 helper 的完整SHA；host_inference 依原helper排除于该SHA，完整复制文档仍保留。原 build manifest bytes 的完整SHA必须与 identity一致；bit/HWH标签完整保留。这些均为调用方 correlation，不能证明连接/peer/build真实性、manifest成员关系、实际加载或 tested commit。
4. 旧ACK已在descriptor队列中、但写后才读取时仍可匹配。代码注释、文档及作者原控制均明确匹配仅为未经认证的诊断，没有 freshness 字段或授予动作。write/read call bracket 不是串口完成、到达或采样时刻；sample_interval 与 physical_capture引用保持 null。
5. 构造中的非法标量、digest、profile、build bytes/mode在写与journal创建前被拒绝；构造异常关闭已取得的自有duplicate。close只关闭自有writer duplicate与journal；原caller fd和ledger独立存活。owner线程和有限read/check预算保留。
6. snapshot与check结果始终 authenticated=false、motion_authorized=false；没有 BootBinding、VerifiedEnvelope/Observation、动作/采样对象或生产门禁。源、文档与实际行为的诊断范围一致。

## 本次新增控制与保存证据复核

只执行 `review_controls.py` 的四组新增控制，没有导入或重跑作者16项测试，也没有旧软件/PDE/384板组重放。

| 新控制 | 本次原始证据和结果 |
| --- | --- |
| durable_start_ack_failure | 在真实41B管道BOOT写调用入口观察journal尾行已为started_unknown，且该journal已有成功fsync；记录恰好一次BOOT写。真实原始错误sequence ACK被消费，随后匹配ACK处注入fsync故障。检查/再次send/close/关闭后调用均未引发第二次BOOT写；transcript关闭后，caller writer与原ledger仍实际可用。 |
| real_pipe_full | 实际将非阻塞OS管道写满4096B；send触发真实BlockingIOError，记录write_error_unknown和未知接受数，第二次send拒绝。关闭后实际读取4096B，逐字节全部是原filler，无BOOT bytes；没有注入write错误。 |
| invalid_before_effects_and_frozen_profile | 五个新增非法参数实例均在journal文件创建和任何OS写之前拒绝；caller profile随后被清空，实际发出的BOOT和完整冻结profile SHA不变。写后更改ledger identity阻止ACK检查，恢复原identity后原receipt仍仅给出未经认证的诊断。 |
| terminated_blocking_write | 独立OS子进程先写满管道、改为blocking，在已经完成durable started之后进入真实os.write调用边界，150ms后仍存活阻塞，父控制器实际terminate并等待终态（Windows exit1，预期终止）。原journal只有prepared和write_started/started_unknown，无result；父进程另建端点用同一路径重开被FileExistsError拒绝且未写。 |

外层控制命令使用已有 `.local/venv/Scripts/python.exe -B -X utf8 <本目录>/review_controls.py`，仅对子进程设置 `.local/deepeye-host-deps;产品目录` PYTHONPATH。`exec_command` 返回 exit0，4/4通过；命令argv、UTC epoch纳秒、环境范围和退出码在 `execution.json`，输出在 `new-controls.log`。原始字节、journal、ledger、进程PID和终态都保存在 `controls/`。fsync异常属于明确故障注入；满管道、原始read/write、实际进程终止是本地OS行为，均不代替串口驱动/FPGA测量。

保存证据审计命令为 `.local/venv/Scripts/python.exe -B -X utf8 <本目录>/audit_saved_evidence.py`，`exec_command` 最终 exit0。对作者16个目录及本次4个含ledger的目录重建19个frame的原始read spans、offsets和CRC，并对15个已记录ACK check按原字段独立比较；没有运行生产者测试。统计和细项在 `saved-evidence-audit.json`。

首次保存证据审计在所有原始字节检查后因“当前HEAD必须仍等于2403”的审查器假设退出1。`audit-01-failure.log`保留原命令、错误及当时脚本SHA；该失败属于root并行证据归档导致的stale-head断言，非候选功能失败。root要求保留失败，按准确source pins与两HEAD差异继续；没有重跑已通过的四项控制。最终审计仍严格核对九项source bytes，并核对跨HEAD差异未涉及这些源。最初读取任务简写目录时少了competition/deepeye前缀，发生只读路径不存在错误；随后以作者manifest定位，没有产品副作用。

## 必须保留的局限

本工具既不认证连接，也不建立global operation/session/connection唯一性。其它journal路径可创建新对象；唯一性、异常恢复、原操作核对与是否允许新BOOT由main管理。descriptor阻塞策略由caller继承，实际集成需要独立有界supervisor；本次只检验一个本地阻塞终止场景。fsync记录依赖OS/文件系统语义，没有断电持久性证明。Python调用入口观察并不能提升为UART完成或硬件执行证据。

未操作实际板、串口、外部网络、服务或显示器，未发送外部消息/PR，未派工，未提交/暂存/部署。未授予生产provider、实际加载、BootBinding、Verified、动作/采样或验收。`G03/R03/all29=not_run`，product_acceptance=false。最终source-pinned review和manifest只供root独立核对、集成与后续真实联调使用。
