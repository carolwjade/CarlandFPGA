"""Read-only reconstruction of saved producer and independent original bytes."""
import binascii
import hashlib
import json
from pathlib import Path
import shutil
import struct
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCT = ROOT / '.local/deepeye-implementation-a'
AUTHOR = ROOT / '.planning/deepeye-resume-20261018/boot-transcript-20261024'


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def parse(raw):
    assert len(raw) >= 14
    magic, version, kind, length, epoch, sequence, tick = struct.unpack('<2sBBBBHI', raw[:12])
    assert magic == b'\xa5\x5a' and version == 3 and len(raw) == length + 14
    assert binascii.crc_hqx(raw[2:-2], 0xffff) == struct.unpack('<H', raw[-2:])[0]
    return dict(kind=kind, length=length, epoch=epoch, sequence=sequence, tick=tick,
                payload=raw[12:-2])


def audit_directory(directory):
    ledger = load(directory / ('receive-ledger.json' if (directory / 'receive-ledger.json').exists() else 'ledger.json'))
    read_data = {index: bytes.fromhex(row['raw_hex']) for index, row in enumerate(ledger['reads'])}
    for row in ledger['frames']:
        reconstructed = b''.join(read_data[s['read_index']][s['offset']:s['offset']+s['length']]
                                  for s in row['spans'])
        assert reconstructed.hex() == row['raw_hex']
        assert digest(reconstructed) == row['raw_sha256']
        offsets = []
        for s in row['spans']:
            start = ledger['reads'][s['read_index']]['stream_start'] + s['offset']
            offsets.extend(range(start, start+s['length']))
        assert offsets == list(range(row['stream_start'], row['stream_end']))
        parse(reconstructed)
    checks = 0
    snapshots = list(directory.glob('snapshot-*.json'))
    if (directory/'transcript-before-close.json').exists():
        snapshots.append(directory/'transcript-before-close.json')
    for snapshot in snapshots:
        data = load(snapshot)
        assert data['authenticated'] is False and data['motion_authorized'] is False
        prepared = data['prepared']
        profile_covered = {k:v for k,v in data['profile'].items() if k != 'host_inference'}
        assert digest(json.dumps(profile_covered, ensure_ascii=False, sort_keys=True,
                                 separators=(',',':')).encode('utf-8')) == prepared['profile_sha256']
        assert digest(bytes.fromhex(prepared['build_manifest_hex'])) == prepared['identity']['build_manifest_sha256']
        for check in data['ack_checks']:
            frame = ledger['frames'][check['receipt_index']]
            assert check['raw_hex'] == frame['raw_hex'] and check['spans'] == frame['spans']
            assert check['raw_sha256'] == frame['raw_sha256']
            assert check['stream_start'] == frame['stream_start'] and check['stream_end'] == frame['stream_end']
            assert check['sample_interval_ns'] is None and check['physical_capture_record_sha256'] is None
            assert check['authenticated'] is False and check['motion_authorized'] is False
            request = parse(bytes.fromhex(data['attempt']['raw_hex']))
            response = parse(bytes.fromhex(check['raw_hex']))
            expected = []
            if response['kind'] != 13 or response['length'] != 27:
                assert check['echo']['ok'] is False
            else:
                # These fields reproduce the frozen echo contract independently.
                fields = [('session',0,4),('mode',4,5),('slot_profile_sha128',5,21),
                          ('guard_total_ms',21,23),('primary_slot_ms',23,25),('config_slot_ms',25,27)]
                for label, begin, end in fields:
                    if request['payload'][begin:end] != response['payload'][begin:end]: expected.append(label)
                if request['sequence'] != response['sequence']: expected.append('sequence')
                if request['epoch'] != response['epoch']: expected.append('config_epoch')
                assert check['echo']['ok'] == (not expected)
                assert check['echo']['mismatches'] == expected
            for pair in check['read_call_intervals_ns']:
                assert pair[0] >= data['attempt']['write_call_interval_ns'][1]
            checks += 1
    return {'directory': str(directory.relative_to(ROOT)), 'reads': len(read_data),
            'frames_reconstructed_from_original_spans': len(ledger['frames']),
            'snapshots_audited': len(snapshots), 'ack_checks_independently_compared': checks}


result = []
for directory in sorted((AUTHOR/'green-02-artifacts').iterdir()):
    result.append(audit_directory(directory))
for directory in sorted((OUT/'controls').iterdir()):
    if (directory/'ledger.json').exists():
        result.append(audit_directory(directory))
source = load(OUT/'preflight.json')
for row in source['source_files']:
    raw=(PRODUCT/row['path']).read_bytes()
    assert len(raw)==row['bytes'] and digest(raw)==row['sha256']
git=shutil.which('git')
assert git is not None
git_evidence={}
for args in [['rev-parse','HEAD'],['status','--short']]:
    process=subprocess.run([git,'-C',str(PRODUCT),*args],capture_output=True,text=True,encoding='utf-8')
    assert process.returncode == 0
    git_evidence[' '.join(args)]={'command':[git,'-C',str(PRODUCT),*args], 'exit_code':process.returncode,
                                'stdout':process.stdout,'stderr':process.stderr}
assert git_evidence['rev-parse HEAD']['stdout'].strip() == '2403ae496719b7321599471edc5b70b4ff5fee2c'
source['git']=git_evidence
source['git_probe_note']='Initial fixed-location Git probes missed the available bundled runtime; corrected with shutil.which.'
write(OUT/'preflight.json',source)
write(OUT/'saved-evidence-audit.json', {'directories':result,'source_pins_unchanged':True,
      'G03':'not_run','R03':'not_run','all29':'not_run', 'author_tests_rerun':False})
print(json.dumps({'directories':len(result), 'frames':sum(x['frames_reconstructed_from_original_spans'] for x in result),
                  'ack_checks':sum(x['ack_checks_independently_compared'] for x in result),
                  'source_pins_unchanged':True,'git_head':git_evidence['rev-parse HEAD']['stdout'].strip()}))
