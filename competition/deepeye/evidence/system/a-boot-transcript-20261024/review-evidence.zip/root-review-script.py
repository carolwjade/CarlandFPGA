"""Root source-pinned review and evidence archive; executes no producer tests."""
from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, struct, subprocess, tarfile, zipfile

P=Path(__file__).resolve().parent; R=P.parents[2]; O=P.parent; W=R/'.local/deepeye-implementation-a'
GIT=r'C:\Users\CarlJade\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe'
H='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
BASE='353aa3a540576e92e023eaa62c68487a8a1d00d6'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def save(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def git(*a):return subprocess.check_output([GIT,'--no-optional-locks','-C',str(W),*a])
def check_file(path,row):
 raw=path.read_bytes();assert sha(raw)==row['sha256'],str(path)
 expected=row.get('bytes',row.get('size'));assert len(raw)==expected,(str(path),len(raw),expected)
 return raw
assert git('rev-parse','HEAD').decode().strip()==BASE
assert not git('diff','--cached','--name-only').strip()
protected=read(O/'r03-mailbox-stop-main-review-20261020/application.json')['protected_files']
assert all(sha((W/n).read_bytes())==h for n,h in protected.items())
scope=read(R/'docs/competition/deepeye-2026/immutable_scope.json');assert sha(canon(scope['requirements']))==H
terminal=read(P/'native-terminal-readback-4.json')
assert len(terminal)==2 and all(x['status']=='completed' and x['terminal'] and not x['stale'] for x in terminal)
author=O/'boot-transcript-20261024';review=O/'boot-transcript-independent-20261024';crc=O/'b-crc27-independent-20261024'
secrets=[read(d/'lease.private.json')['lease_token'].encode() for d in (author,review,crc)]

# BOOT: independently inspect pins, durable evidence and original byte spans.
pins=read(author/'sourcehashes.json');assert len(pins['owned'])==3 and len(pins['readonly_inputs'])==6
for row in pins['owned']+pins['readonly_inputs']:check_file(W/row['path'],row)
assert read(review/'sourcehashes.json')['files']==[dict(group=g,**row) for g in ('owned','readonly_inputs') for row in pins[g]]
for row in read(author/'control-artifact-manifest.json'):check_file(author/row['path'],row)
for row in read(review/'manifest.json')['files']:check_file(review/row['path'],row)
ar=read(author/'green-02.json');assert ar['exit_code']==0
al=(author/'green-02.log').read_text();assert 'Ran 16 tests' in al and al.rstrip().endswith('OK') and al.count(' ... ok')==16
rr=read(review/'result.json');assert rr['controls']['passed']==4 and rr['controls']['exit_code']==0 and not rr['board_run']
controls=read(review/'new-controls.json')['controls'];assert len(controls)==4 and all(x['status']=='passed' for x in controls)
assert read(review/'execution.json')['exit_code']==0
src=ast.parse((W/pins['owned'][0]['path']).read_bytes())
writes=[n for n in ast.walk(src) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='os' and n.func.attr=='write']
assert len(writes)==1
observer=read(review/'controls/durable-start-ack-journal-failure/write-observer.json')
assert len(observer['calls'])==1 and observer['calls'][0]['journal_at_entry']['outcome']=='started_unknown' and len(observer['successful_fsyncs'])>=2
emitted=(review/'controls/durable-start-ack-journal-failure/boot-emitted.bin').read_bytes()
assert emitted==bytes.fromhex(observer['calls'][0]['raw_hex']) and len(emitted)==41
supervisor=read(review/'controls/blocked-child/supervisor.json')
assert supervisor['termination_requested'] and supervisor['exit_code']==1 and supervisor['alive_after_write_boundary_150ms'] and supervisor['journal_kinds']==['prepared','write_started']
blocked=[json.loads(s) for s in (review/'controls/blocked-child/attempt.jsonl').read_text().splitlines()]
assert [x['kind'] for x in blocked]==['prepared','write_started'] and blocked[-1]['outcome']=='started_unknown'
def update(crc_value,byte):
 crc_value^=byte<<8
 for _ in range(8):crc_value=((crc_value<<1)^(0x1021 if crc_value&0x8000 else 0))&65535
 return crc_value
frames_checked=0;ledgers_checked=0
for path in list((author/'green-02-artifacts').rglob('receive-ledger.json'))+list((review/'controls').rglob('ledger.json')):
 data=read(path);ledgers_checked+=1
 for f in data['frames']:
  chunks=[];cursor=f['stream_start']
  for span in f['spans']:
   rd=data['reads'][span['read_index']];assert rd['stream_start']+span['offset']==cursor
   piece=bytes.fromhex(rd['raw_hex'])[span['offset']:span['offset']+span['length']];assert len(piece)==span['length'];chunks.append(piece);cursor+=len(piece)
  raw=b''.join(chunks);assert cursor==f['stream_end'] and raw==bytes.fromhex(f['raw_hex']) and sha(raw)==f['raw_sha256']
  assert raw[:3]==b'\xa5\x5a\x03' and len(raw)==14+raw[4]
  cc=65535
  for byte in raw[2:-2]:cc=update(cc,byte)
  assert cc==struct.unpack('<H',raw[-2:])[0] and f['sample_interval_ns'] is None and f['physical_capture_record_sha256'] is None
  frames_checked+=1
boot_decision={'schema':1,'utc':datetime.now(timezone.utc).isoformat(),'main':'01a16988-bdcb-70e1-ae10-1304b5cf7875','generation':3,'disposition':'ACCEPT_DIAGNOSTIC_SINGLE_ATTEMPT_BOOT_TRANSCRIPT_ONLY','product_base':BASE,'source_pins':pins,'requirements_sha256':H,'H01_H15_preserved':True,'author_new_controls':16,'independent_new_control_groups':4,'root_saved_ledgers_reconstructed':ledgers_checked,'root_original_frames_reconstructed':frames_checked,'root_os_write_call_sites':len(writes),'actual_terminated_local_process':supervisor,'original_failures_preserved':True,'production_gate_changed':False,'board_run':False,'G03':'not_run','R03':'not_run','all29':'not_run','limits':['OS writes and local original ACK correlation only; no authentication, freshness, actual bit/HWH load, build membership or motion authority','main retains global operation/session uniqueness and bounded transport supervision','unknown writes never automatically replayed; journal path exclusivity is not global deduplication','read/write brackets are not source sample or UART completion times']}

# CRC27: recheck saved source/API bytes and new simulation receipts, no exhaustive replay.
cm=read(crc/'evidence-manifest.json');assert cm['files_count']==555==len(cm['files'])
for row in cm['files']:
 path=(R/row['path']).resolve();assert path.is_relative_to(R.resolve());check_file(path,row)
cr=read(crc/'result.json');assert cr['tested_commit']=='11e24d80ebf2acf822a7b45d3c3c346eb2a4d7cc' and cr['source_commit']=='779e66ddc7d454ee997f449f6ee5c86063a97324'
cw=R/'.local/deepeye-b-crc27-review-20261024';ch=cw/'head'
handoff=ch/'handoffs/b/B-DEEPEYE-CRC16-BYTE-20261024-27/manifest.json';hm=read(handoff)
assert sha(handoff.read_bytes())==cr['manifest_sha256'] and sha(canon(hm['request']))==cr['request_hash']
assert len(hm['files'])==12
for name,row in hm['files'].items():check_file(ch/name,row)
for row in read(crc/'artifact-identity.json')['records']:
 raw=(R/row['path']).read_bytes();assert sha(raw)==row['sha256'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob_sha1']
for label,code in [('vlib',0),('vlog',0),('vsim',0),('negative',1)]:
 base='sim-ascii-02-'+label;receipt=read(crc/'raw'/(base+'.command.json'));assert receipt['exit_code']==code
 for stream in ['stdout','stderr']:assert sha((crc/'raw'/(base+'.'+stream)).read_bytes())==receipt[stream+'_sha256']
positive=(crc/'raw/sim-ascii-02-vsim.stdout').read_text();negative=(crc/'raw/sim-ascii-02-negative.stdout').read_text()
assert positive.count('INDEPENDENT_PASS checks=196')==1 and 'Errors: 0, Warnings: 0' in positive
assert 'INDEPENDENT_MISMATCH' in negative and 'actual=0000 expected=0001' in negative and 'INDEPENDENT_PASS' not in negative and 'Errors: 1' in negative
vectors=read(crc/'vectors.json');assert len(vectors['vectors'])==196
for v in vectors['vectors']:assert update(v['seed'],v['byte'])==v['expected']
assert len({(v['seed'],v['byte']) for v in vectors['vectors']})==189
dut=(cw/'sim-ascii-02/dut.sv').read_bytes();assert sha(dut)==cr['independent_simulation']['rtl_sha256']
raw_archive=ch/'competition/deepeye/evidence/transport/crc16-byte-20261024-27/publication/raw-evidence.tar.gz'
with tarfile.open(raw_archive,'r:gz') as tf:
 members=tf.getmembers();assert len(members)==355 and all(x.isfile() for x in members) and len({x.name for x in members})==355
assert read(crc/'ascii-mapping.json')['removed']
crc_decision={'schema':1,'utc':datetime.now(timezone.utc).isoformat(),'main':'01a16988-bdcb-70e1-ae10-1304b5cf7875','generation':3,'disposition':'ACCEPT_STANDALONE_BINARY_COMBINATIONAL_CRC_BYTE_UPDATE_SIMULATION_ONLY','tested_commit':cr['tested_commit'],'source_commit':cr['source_commit'],'operation_id':cr['operation_id'],'request_hash':cr['request_hash'],'manifest_sha256':cr['manifest_sha256'],'requirements_sha256':H,'H01_H15_preserved':True,'root_verified_manifest_artifacts':12,'root_verified_review_artifacts':555,'saved_archive_members':355,'independent_checks':196,'independent_unique_pairs':189,'independent_mismatches':0,'independent_negative_exit':1,'old_exhaustive_and_author_runs_rerun':False,'board_run':False,'B04':'not_run','G03':'not_run','R03':'not_run','all29':'not_run','limits':['binary mathematical byte update only; not packet CRC/seed/byte order/framing or parser','new GF(2) oracle differs from archived binascii code path; 196 comparisons are not exhaustive','no synthesis/implementation/timing/CDC/RDC, X/Z guarantee, hardware build or board/system acceptance','authenticated immutable API snapshot and Git blob/tree checks; no full checkout or raw unsigned commit reconstruction']}

def archive(dest,mapping,decision,description):
 assert not dest.exists();dest.mkdir(parents=True)
 assert len(mapping)==len(set(mapping)) and all(not any(t in name for t in ['lease.private','__pycache__']) for name in mapping)
 data={}
 for name,path in mapping.items():
  raw=path.read_bytes();assert not any(secret in raw for secret in secrets),(name,'secret');data[name]=raw
 zip_path=dest/'review-evidence.zip'
 with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,raw in sorted(data.items()):z.writestr(name,raw)
 with zipfile.ZipFile(zip_path) as z:
  assert z.testzip() is None and set(z.namelist())==set(data)
  for name,raw in data.items():assert z.read(name)==raw
 save(dest/'manifest.json',{'schema':1,'zip_sha256':sha(zip_path.read_bytes()),'zip_bytes':zip_path.stat().st_size,'members':[{'path':n,'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(data.items())],'private_credentials_excluded':True})
 save(dest/'decision.json',decision)
 (dest/'README.md').write_text(description+'\n\nSee decision.json and the exact member hashes in manifest.json. Original failures remain in the archive. H01-H15 unchanged; G03/R03/all29=not_run.\n',encoding='utf-8',newline='\n')
 return {str(f.relative_to(W)).replace('\\','/'):sha(f.read_bytes()) for f in dest.iterdir() if f.is_file()}

boot_files={}
for prefix,folder in [('author',author),('review',review)]:
 for file in folder.rglob('*'):
  if file.is_file() and 'private' not in file.name and '__pycache__' not in file.parts:boot_files[prefix+'/'+file.relative_to(folder).as_posix()]=file
for row in pins['owned']+pins['readonly_inputs']:boot_files['source/'+row['path']]=W/row['path']
boot_files['root-review-script.py']=Path(__file__);boot_files['native-terminal-readback.json']=P/'native-terminal-readback-4.json'
for suffix in ['md','json']:boot_files['contract/immutable_scope.'+suffix]=R/('docs/competition/deepeye-2026/immutable_scope.'+suffix)
crc_files={x['path']:R/x['path'] for x in cm['files']}
for name in ['evidence-manifest.json','final_hashes.json','native-complete.json']:crc_files['review-final/'+name]=crc/name
crc_files['root-review-script.py']=Path(__file__);crc_files['native-terminal-readback.json']=P/'native-terminal-readback-4.json'
files=archive(W/'competition/deepeye/evidence/system/a-boot-transcript-20261024',boot_files,boot_decision,'Root accepts the single-attempt BOOT/ACK diagnostic preparation component. Author16 and independent4 local OS controls passed; this is not authenticated BOOT, freshness, build-load or motion acceptance.')
files.update(archive(W/'competition/deepeye/evidence/transport/a-op27-review-20261024',crc_files,crc_decision,'Root accepts only CRC27 binary combinational byte-update simulation at the exact B head. New ModelSim196 checks and negative control are distinct from saved producer exhaustive evidence. No packet or board acceptance.'))
files.update({row['path']:row['sha256'] for row in pins['owned']})
save(P/'boot-crc-root-decisions.json',{'boot':boot_decision,'crc27':crc_decision,'archive_member_counts':{'boot':len(boot_files),'crc27':len(crc_files)}})
save(P/'boot-crc-publication.json',{'expected_head':BASE,'message':'Prepare single-attempt BOOT transcript and archive bounded CRC27 review','files':files})
assert all(sha((W/n).read_bytes())==h for n,h in protected.items())
print(json.dumps({'prepared_files':len(files),'boot_archive_members':len(boot_files),'crc_archive_members':len(crc_files),'root_reconstructed_frames':frames_checked,'C4_unchanged':True}))
