# A BOOT transcript worker result

Work `A-BOOT-TRANSCRIPT-20261024-v1`, task `DEEPEYE-IMPLEMENTATION-20261014/v1`, canonical agent `/root/boot_transcript`, mesh job `child-5fb532520ddb4c83abc8cdc09d5cde0a`. Lease validation returned `execution_allowed=true` before project execution. A Gen3 director remains `01a16988-bdcb-70e1-ae10-1304b5cf7875`; base `2403ae496719b7321599471edc5b70b4ff5fee2c` confirmed. H01-H15 canonical requirements SHA256 was recomputed as `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`.

## Delivered candidate

Only three new product files were written:

- `competition/deepeye/integration/boot_transcript.py`: one original OS BOOT write, exclusive durable new journal, full profile and build correlation, original ReceiptLedger ACK diagnostics.
- `competition/deepeye/integration/test_boot_transcript.py`: 16 new local Windows pipe and explicit injected-fault controls.
- `competition/deepeye/docs/boot_transcript.md`: exact API and limits, including blocking supervision, unknown-write recovery and the absence of authentication/freshness authority.

`BootTranscript` owns its duplicate writer descriptor and journal; main keeps the original endpoint and sole receive ledger. The complete profile is frozen and validated, its full frozen-helper digest checked, original opaque build-manifest bytes matched to CaptureIdentity's digest, and full bit/HWH labels retained. That is correlation only and does not establish manifest membership, build authenticity or actual load. No Verified/BootBinding object or production gate is created.

A persisted `started_unknown` marker precedes exactly one `os.write`. Partial, timeout, interruption and error paths retain the attempted bytes and known/unknown byte count; no send path retries. An existing journal cannot be reopened. Journal-path exclusivity is not global operation deduplication; main remains responsible for original operation/session/connection reconciliation and a bounded transport supervisor. Write-call brackets do not mean UART completion.

`check_ack` calls frozen `verify_boot_ack` on the original written packet and exact original same-ledger receipt bytes; it records original read spans and brackets. It does not host-reencode ACKs. Sequence/epoch/session/mode/profile/guard/slot mismatches fail. ACK tick is outside the frozen echo fields. Copied/foreign/already-used/read-before-write receipts are refused; bounded checks consume original mismatches. A matching but previously queued unread ACK remains an unauthenticated diagnostic. Read brackets never become arrival/sample clocks. Close and check paths do not send.

## Verification retained

| Attempt | Result | Evidence |
| --- | --- | --- |
| red-01 | 14 failures, exit 1; missing module assertion | `red-01.log`, `red-01.json` |
| green-01 | 14 pass, exit 0, 0.123 s | `green-01.log`, `green-01.json` |
| red-02 | 1 failure / 16, exit 1; send failed to reject changed receive identity | `red-02.log`, `red-02.json`, `red-02-artifacts/` |
| green-02 | 16 pass, exit 0, 0.268 s | `green-02.log`, `green-02.json`, `green-02-artifacts/` |

The changed-identity failure was fixed by comparing the receive identity again before any write. No old tests were executed. The final 45 retained raw artifacts contain JSONL prepared/started/result/ACK records, raw received-byte ledgers and detached snapshots. `control-artifact-manifest.json` hashes every final raw control artifact. `sourcehashes.json` hashes all three owned sources and six read-only API/doc/profile inputs; `verification.json` binds the candidate files and contract to the unchanged base.

Actual OS controls cover full pipe writes, independently CRC-built split ACK reception and broken-pipe error. Short writes are a disclosed fault adapter that forwards a prefix through a real pipe. Timeout and KeyboardInterrupt controls inject the exception after actual full pipe writes. Journal failures inject `fsync` errors. These are software fault controls, not real UART/FPGA fault measurements. The first test-run journals were temporary; the two later runs retain their complete raw control artifacts. The initial lease-read JavaScript helper lacked `atob`; it failed before validation or any project operation, and the subsequent direct JSON parse validated successfully without exposing the token.

## Review boundary

Status: implementation complete, pending A/root independent review and integration. This worker did not stage, commit, install dependencies, operate board/serial/network/display, modify live_board_receipts/boot_profile/actor gates/C4, run old groups or 384-case baseline, send to peers/group/PR, or delegate further work. Existing unrelated dirty paths were left in place. The worker used only the existing venv and subprocess PYTHONPATH for host dependencies.

This is a small provider-preparation unit, not a production provider or completed end-to-end run. Main still owns actual connection/build/BOOT/context authentication, source clocks, original-deadline enforcement, causal AI/broker association, geometry/CAS, supervisor/process-death stop and real-board integration. A/root alone operates the board. H01-H15 and both H12 paths are preserved. G03/R03/all29 remain `not_run`; product acceptance remains false.
