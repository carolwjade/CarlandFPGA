"""Hash the assigned sources and existing controls; no test or board rerun."""
import hashlib
import json
from pathlib import Path
import subprocess

out = Path(__file__).resolve().parent
root = out.parents[2]
product = root / '.local/deepeye-implementation-a'
owned = ['competition/deepeye/integration/boot_transcript.py',
         'competition/deepeye/integration/test_boot_transcript.py',
         'competition/deepeye/docs/boot_transcript.md']
inputs = ['competition/deepeye/integration/live_board_receipts.py',
          'competition/deepeye/docs/live_board_receipts.md',
          'competition/deepeye/integration/boot_profile.py',
          'competition/deepeye/integration/test_boot_binding.py',
          'competition/deepeye/integration/wire.py',
          'competition/deepeye/docs/boot_profiles.json']

def record(path, name):
    raw = path.read_bytes()
    return dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

sourcehashes = dict(owned=[record(product/p, p) for p in owned],
                    readonly_inputs=[record(product/p, p) for p in inputs])
(out/'sourcehashes.json').write_text(json.dumps(sourcehashes, indent=2)+'\n', encoding='utf-8')
manifest = [record(path, str(path.relative_to(out)).replace('\\','/'))
            for path in sorted((out/'green-02-artifacts').rglob('*')) if path.is_file()]
(out/'control-artifact-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
scope = json.loads((root/'docs/competition/deepeye-2026/immutable_scope.json').read_bytes())
digest = hashlib.sha256(json.dumps(scope['requirements'], ensure_ascii=False,
    sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()
assert digest == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
assert [x['id'] for x in scope['requirements']] == ['H%02d'%i for i in range(1,16)]
transfer = json.loads((root/'.planning/deepeye-desktop-handoff-20261015/transfer.json').read_bytes())
assert transfer['director_generation'] == 3
assert transfer['new_director_thread_id'] == '01a16988-bdcb-70e1-ae10-1304b5cf7875'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=product, text=True).strip()
assert head == '2403ae496719b7321599471edc5b70b4ff5fee2c'
verification = dict(contract_id='DEEPEYE-HUMAN-LOCK-20261014/revision1',
    requirements_sha256=digest, H01_H15_preserved=True, director_generation=3,
    director_thread=transfer['new_director_thread_id'], tested_base=head,
    owned_sources=sourcehashes['owned'], final_control_artifacts=len(manifest))
(out/'verification.json').write_text(json.dumps(verification, indent=2)+'\n', encoding='utf-8')
result = dict(work_id='A-BOOT-TRANSCRIPT-20261024-v1',
    task='DEEPEYE-IMPLEMENTATION-20261014/v1', agent_id='/root/boot_transcript',
    job_id='child-5fb532520ddb4c83abc8cdc09d5cde0a',
    status='implementation_complete_pending_main_review',
    product_acceptance=False, board_run=False, G03='not_run', R03='not_run', all29='not_run',
    contract=verification, tests=dict(red_01=dict(tests=14, failures=14, exit_code=1),
       green_01=dict(tests=14, failures=0, exit_code=0),
       red_02=dict(tests=16, failures=1, exit_code=1),
       green_02=dict(tests=16, failures=0, exit_code=0)),
    report='report.md', sourcehashes='sourcehashes.json',
    final_raw_controls='green-02-artifacts/', control_manifest='control-artifact-manifest.json',
    limits=['main-supplied correlation only; no authenticated/fresh BOOT or verified envelope/observation',
      'opaque build-manifest digest and bit/HWH labels do not prove actual build/load/membership',
      'write/read call times are not UART completion/arrival or sample time',
      'journal exclusive path prevents same-path reopening; main owns global operation deduplication',
      'runtime needs separately bounded transport supervisor and main-owned original endpoint'])
(out/'result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(verification, indent=2))
