"""Run only the new controls; preserve each attempt under a unique stage name."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
product = root / '.local/deepeye-implementation-a'
env = os.environ.copy()
env['PYTHONPATH'] = str(root / '.local/deepeye-host-deps') + os.pathsep + str(product)
env['PYTHONDONTWRITEBYTECODE'] = '1'
stage = sys.argv[1]
env['BOOT_TRANSCRIPT_CONTROL_OUT'] = str(out / (stage + '-artifacts'))
log = out / (stage + '.log')
metadata = out / (stage + '.json')
command = [str(root / '.local/venv/Scripts/python.exe'), '-B', '-X', 'utf8', '-m',
           'unittest', 'competition.deepeye.integration.test_boot_transcript', '-v']
started = time.time_ns()
with log.open('xb') as file:
    result = subprocess.run(command, cwd=product, env=env, stdout=file, stderr=subprocess.STDOUT, timeout=45)
with metadata.open('x', encoding='utf-8') as file:
    json.dump(dict(command=command, cwd=str(product), started_unix_ns=started,
        finished_unix_ns=time.time_ns(), exit_code=result.returncode,
        scope='only new BOOT transcript controls; local pipes, no board'), file, indent=2)
print(log.read_text(encoding='utf-8'))
print('EXIT_CODE=' + str(result.returncode))
sys.exit(result.returncode)
