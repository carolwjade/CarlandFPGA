import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

D = Path(__file__).resolve().parent
B = D.parent / 'b-op23-independent-20261022'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())
native = read(D / 'original-native-result.json')
assert native['status'] == 'completed' and native['terminal'] and not native['stale']
assert native['native_agent_id'] == '/root/b_op23_independent_20261022'
report = read(B / 'review.json')
assert sha(B / 'review.json') == 'ad1bc245264e611ca034f01e7ac6267d6e4575fabaf76c76129534df0ebf88f5'
missing = '8d05c0c5856896bfab648052e3c658a2f568f603187a44806b8dab2e4d30f89e'
freeze = read(B / 'inert-members/main-original/main/PREDISPATCH_FREEZE.json')
row = [r for r in freeze['files'] if r['path'].endswith('main_verify_raw_scan_queue.py')]
assert len(row) == 1 and row[0]['sha256'] == missing and row[0]['bytes'] == 5421
indexes = sorted((B / 'snapshot/competition/deepeye/evidence/acquisition/raw-scan-queue-20261022-23/publication/bundles').glob('*.index.json'))
assert len(indexes) == 6
assert all(missing not in p.read_text(encoding='utf-8') for p in indexes)
wrapper = (B / 'inert-members/main-original/main/run_main23.py').read_text(encoding='utf-8')
assert 'main_verify_raw_scan_queue.py' in wrapper and 'spec.loader.exec_module(verify)' in wrapper
assert 'HTTP 404' in (B / 'retrieve-classifier.stderr.txt').read_text(encoding='utf-8')
checks = {}
for name in ['audit', 'evidence-bindings', 'raw-record-audit']:
    process = read(B / (name + '.process.json'))
    checks[name] = process
    assert process.get('exit_code', process.get('exit')) == 0
decision = {
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'decision': 'REVISE_EVIDENCE_ONLY', 'operation_id': report['operation_id'],
    'reviewed_commit': report['head'], 'request_hash': report['request_sha256'],
    'manifest_sha256': report['manifest_sha256'], 'review_sha256': sha(B / 'review.json'),
    'finding': 'A-OP23-EVIDENCE-01: missing frozen baseline comparator',
    'missing_source_sha256': missing, 'missing_source_bytes': 5421,
    'main_checks': ['original completed terminal', 'exact review hash', 'frozen comparator identity',
                    'absent hash in six indexes', 'actual wrapper import', 'saved fixed-head HTTP404', 'three audit exits0'],
    'preserved': '21 artifacts and 7910 member integrity verified by reviewer; no demonstrated RTL/parser failure',
    'required_next': 'B publishes exact original comparator bytes with new request/manifest/head; no old tests or vendor rerun',
    'new_test_runs': 0, 'R03': 'not_run', 'all29': 'not_run',
    'requirements_sha256': 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
}
(D / 'decision.json').write_text(json.dumps(decision, indent=2), encoding='utf-8')
print(json.dumps(decision, indent=2))
