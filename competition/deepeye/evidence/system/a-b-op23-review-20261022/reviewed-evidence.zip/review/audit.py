"""Independent inert byte/archive/AST audit; never import or execute artifact code."""
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

OUT=Path(__file__).resolve().parent
SNAP=OUT/'snapshot'
OP='handoffs/b/B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23/'
PUB='competition/deepeye/evidence/acquisition/raw-scan-queue-20261022-23/publication/'
EXPECTED='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def main():
    report={'execution':'inert bytes/archive/AST only; no artifact import, parser run, simulation, solve or vendor process','files':[],'archives':[],'source_bindings':[]}
    manifest_raw=(SNAP/OP/'manifest.json').read_bytes()
    manifest=json.loads(manifest_raw)
    assert sha(manifest_raw)=='d154382bdb01110b645169084603cd423e169b5aab8ea09352e0846f2fe9e597'
    inp=json.loads((SNAP/OP/'input.json').read_bytes())
    assert inp['request']==manifest['request']
    report['request_hash']=sha(canonical(inp['request']))
    assert report['request_hash']==manifest['request_hash']=='9f1f2d28bffcb973a73b53fe49a090a2ac29f20a1d3ebf8d539e1fd4bc7366d1'
    for path,expected in manifest['files'].items():
        raw=(SNAP/path).read_bytes()
        actual={'path':path,'size':len(raw),'sha256':sha(raw)}
        assert actual['size']==expected['size'] and actual['sha256']==expected['sha256'],path
        report['files'].append(actual)
    for path in manifest['artifacts'][:4]:
        raw=(SNAP/path).read_bytes(); old=(SNAP/'source-commit'/path).read_bytes()
        assert raw==old,path
        report['source_bindings'].append({'path':path,'source_commit':manifest['request']['code_commit'],'head_bytes_equal':True,'sha256':sha(raw)})
    immutable=json.loads((SNAP/'docs/competition/deepeye-2026/immutable_scope.json').read_bytes())
    report['requirements_sha256']=sha(canonical(immutable['requirements']))
    assert report['requirements_sha256']==EXPECTED
    assert [r['id'] for r in immutable['requirements']]==['H%02d'%i for i in range(1,16)]
    for name in ('immutable_scope.json','immutable_scope.md'):
        assert (SNAP/'docs/competition/deepeye-2026'/name).read_bytes()==(SNAP/'source-commit/docs/competition/deepeye-2026'/name).read_bytes()
    collector=SNAP/'competition/deepeye/fpga/acquisition/deepeye_sample_scan_capture.sv'
    report['collector_sha256']=sha(collector.read_bytes())
    assert report['collector_sha256']=='fc8064a11ac40b6ee59418994825f0fc550ee867954bd1f1ccd2c9464e52028d'
    for spec in json.loads((SNAP/PUB/'BUNDLE_MANIFEST.json').read_bytes())['bundles']:
        index=json.loads((SNAP/spec['index']).read_bytes())
        assert sha((SNAP/spec['index']).read_bytes())==spec['index_sha256']
        assert sha((SNAP/spec['archive']).read_bytes())==spec['sha256']==index['archive_sha256']
        seen=set(); members=[]; total=0
        with tarfile.open(SNAP/spec['archive'],'r|gz') as tf:
            for m in tf:
                p=PurePosixPath(m.name)
                assert m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name not in seen,m.name
                seen.add(m.name); expected=index['files'][m.name]
                h=hashlib.sha256(); capture=m.size<=1000000 and p.suffix in ('.json','.md','.py','.sv','.tcl')
                chunks=[]; f=tf.extractfile(m); count=0
                while True:
                    chunk=f.read(1024*1024)
                    if not chunk: break
                    h.update(chunk); count+=len(chunk)
                    if capture: chunks.append(chunk)
                assert count==m.size==expected['bytes'] and h.hexdigest()==expected['sha256'],m.name
                total+=count
                members.append({'name':m.name,'size':count,'sha256':h.hexdigest()})
                if capture:
                    dest=OUT/'inert-members'/Path(spec['archive']).name.removesuffix('.tar.gz')/m.name
                    dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(b''.join(chunks))
        assert seen==set(index['files']) and len(seen)==spec['raw_files'] and total==spec['raw_bytes']
        report['archives'].append({'path':spec['archive'],'members':len(seen),'raw_bytes':total,'all_members_verified':True})
        (OUT/(Path(spec['archive']).name+'.members.json')).write_text(json.dumps(members,indent=2),encoding='utf-8')
    runner=SNAP/'competition/deepeye/tools/acquisition/run_raw_scan_queue.py'
    tree=ast.parse(runner.read_text(encoding='utf-8'),filename=str(runner))
    report['ast']={'parsed':True,'functions':[{'name':n.name,'line':n.lineno,'end_line':n.end_lineno} for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]}
    report['totals']={'manifest_artifacts':len(report['files']),'archive_members':sum(x['members'] for x in report['archives']),'archive_raw_bytes':sum(x['raw_bytes'] for x in report['archives'])}
    (OUT/'audit-results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report['totals']))
if __name__=='__main__': main()
