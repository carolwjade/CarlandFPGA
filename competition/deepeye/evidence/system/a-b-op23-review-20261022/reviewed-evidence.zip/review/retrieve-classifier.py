import json
from pathlib import Path
import runpy
OUT=Path(__file__).resolve().parent
helper=runpy.run_path(str(OUT/'retrieve.py'))
record=helper['retrieve']('competition/deepeye/tools/acquisition/main_verify_raw_scan_queue.py')
(OUT/'source-manifest-classifier.json').write_text(json.dumps([record],indent=2),encoding='utf-8')
