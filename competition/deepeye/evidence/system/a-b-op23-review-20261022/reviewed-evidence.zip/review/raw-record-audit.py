"""Inspect exact saved raw version/port bytes and nested gzip integrity only."""
import gzip
import hashlib
import json
from pathlib import Path
import runpy
OUT=Path(__file__).resolve().parent
helper=runpy.run_path(str(OUT/'evidence-bindings.py'))
raw=helper['raw']; j=helper['j']; sha=helper['sha']
report={'method':'read and hash saved bytes; no artifact execution or semantic test rerun','versions':[]}
for tool in ('vlog','vsim'):
    prefix='main/repair02/vendor-wrap-final/tool-check/'+tool
    receipt=j('repair02',prefix+'.invocation.json')
    stream=receipt['streams']['stdout']
    output=raw('repair02',str(Path(prefix).parent/stream['path']).replace('\\','/'))
    assert sha(output)==stream['sha256'] and len(output)==stream['bytes']
    report['versions'].append({'argv':receipt['argv'],'exit':receipt['exit'],'stdout_sha256':sha(output),'stdout':output.decode('utf-8',errors='replace')})
prefix='main/repair02/vendor-wrap-final/cases/mutant_wrap_depth5'
receipt=j('repair02',prefix+'/vsim.invocation.json')
stream=receipt['streams']['stdout']
compressed=raw('repair02',prefix+'/'+stream['path'])
assert sha(compressed)==stream['compressed_sha256'] and len(compressed)==stream['compressed_bytes']
output=gzip.decompress(compressed)
assert sha(output)==stream['sha256'] and len(output)==stream['bytes']
report['final_wrap_nested_gzip']={'compressed_size':len(compressed),'expanded_size':len(output),'expanded_sha256':sha(output),'first_raw_lines':output.decode('utf-8',errors='replace').splitlines()[:12],'execution_source':'saved repair02 selected wrap receipt; final repair03 changes parser only'}
ports=raw('repair02','main/repair02/runs/baseline02/c00/ports.txt')
report['raw_port_sample']={'path':'main/repair02/runs/baseline02/c00/ports.txt','size':len(ports),'sha256':sha(ports),'first_two_lines':ports.decode('utf-8',errors='replace').splitlines()[:2],'recorded_edge_count_not_recomputed':6274}
for name in ('PROPERTY_CASES.json','PROPERTY_GREEN.json','PROPERTY_RED.json'):
    d=j('repair03','main/repair03/'+name)
    report[name]={'sha256':sha(raw('repair03','main/repair03/'+name)),'type':type(d).__name__,'keys':list(d) if isinstance(d,dict) else None,'list_lengths':{k:len(v) for k,v in d.items() if isinstance(v,list)} if isinstance(d,dict) else {'length':len(d)}}
(OUT/'raw-record-audit-results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'saved_versions':[v['stdout'].strip() for v in report['versions']],'nested_gzip_checked':True,'raw_port_sample_hash_bound':True,'property_outcomes_read_only':True}))
