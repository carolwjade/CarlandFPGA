# Independent A review of B operation23

Review complete with **one medium evidence gap**. No new RTL or parser correctness defect was found in the checked static scope. This worker does not grant acceptance; root owns the decision and feedback.

Exact PR30 head `f49e30d2cf9a82b1a8f7963768ad3520f68dbd47`, source `913b98ac02a1ddc84ffeae8ec158138cd79b6837`, request `9f1f2d28bffcb973a73b53fe49a090a2ac29f20a1d3ebf8d539e1fd4bc7366d1`, manifest SHA256 `d154382bdb01110b645169084603cd423e169b5aab8ea09352e0846f2fe9e597`, runner SHA256 `9a06a7a368313dc96b6941fdaa8dfc4bcda27ed426bf5e75e00e2a1072b39996`. Worker `/root/b_op23_independent_20261022`; work A-B-OP23-INDEPENDENT-20261022-v1; native job validated with execution_allowed=true. Writes stayed inside this directory. No public communication, service/UI/board action or product edit occurred.

## Medium: missing frozen baseline comparator

**A-OP23-EVIDENCE-01 — Publish the frozen baseline trace comparator.** `inert-members/main-original/main/PREDISPATCH_FREEZE.json:291-293` pins `competition/deepeye/tools/acquisition/main_verify_raw_scan_queue.py`, 5,421 bytes, SHA256 `8d05c0c5856896bfab648052e3c658a2f568f603187a44806b8dab2e4d30f89e`. No file in any of the six archive indexes has that hash. The exact-head GitHub path returns HTTP404; captured command/exit/error are in `retrieve-classifier.process.json` and `.stderr.txt`.

`inert-members/main-original/main/run_main23.py:11,29` names and loads it; corrected wrapper `inert-members/repair02/main/repair02/run_main23.py:13,90` calls its `verify.check_trace` for positive comparisons. Therefore A can bind the saved sources, commands and raw ports to the reported baseline, but cannot inspect the original exact comparison implementation or reproduce that comparison from the delivered sources. The other 47 frozen inputs are present by identity. This is an evidence/reproducibility gap, not a demonstrated queue failure. The publication explicitly promises only selected members; the archive integrity itself is valid.

Requested correction: publish that exact frozen source as a tracked artifact with its pinned hash and a fresh publication manifest/request/head. Preserve old evidence and dispositions. Supplying the missing source requires no vendor or previous qualification rerun. Root decides how this gap affects acceptance.

## A checks actually executed

`audit.py`, `evidence-bindings.py` and `raw-record-audit.py` ran under project Python with `-B -P -X utf8`, in hidden bounded subprocesses. Captured argv, exit0, stdout/stderr and hashes are in their corresponding `.process.json` and `.stdout.txt`/`.stderr.txt` files. Only inert byte/hash/archive/AST checks ran; downloaded code was never imported or executed.

- Canonical input/request match and request hash verified. All21 manifest artifacts match their SHA256 and size. Four source files match source commit and head identity.
- Six archives and all7,910 regular members match their indexed SHA256/size; no duplicate or escaping paths. Total uncompressed member bytes1,396,669,229. Members were inspected as data. Original failures remain byte-identical.
- Contract files at the fixed head match the published `f5989cd5defce561f9ba98e6b18fc2682945f0a2` pin. H01-H15 are present and canonical requirements hash `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` matches. All remain mandatory; this increment satisfies none of their full-system gates.
- Corrected queue/TB diff is exactly five/ten legal-range fallback expressions. Repair03 adds exactly six lines and changes only `_parse_trace_row` AST. Collector hash is the unchanged `fc8064a11ac40b6ee59418994825f0fc550ee867954bd1f1ccd2c9464e52028d`.
- Saved baseline has30 cases:17positive/87,836 recorded edges,10single-parameter illegal guards,2legal controls,1competing-invalid priority control. All90 saved vlib/vlog/vsim receipts bind to raw streams; all source snapshots and17positive port hashes bind. Those are B historical executions, not A reruns or independent recomputation of all event comparisons.
- Saved ModelSim raw version bytes say SE-64 vlog/vsim10.7,2017.12. Selected final-wrap nested gzip compressed and expanded hashes/sizes match its receipt.

## Static source review

Queue `snapshot/competition/deepeye/fpga/acquisition/deepeye_raw_scan_queue.sv:7-14,41-57,59-129,131-170`: legal depth1..8, explicit end-pointer wrap for nonpowers of two, six payload fields copied on push, input not admitted while old-full, no empty bypass, and held output remains selected while stalled. Reset suppresses handshakes and clears counters; cancel suppresses handshakes, accounts old occupancy with widened saturation and preserves accepted/retired counters. Memory is intentionally unspecified when invalid.

TB `snapshot/competition/deepeye/tests/rtl/acquisition/tb_raw_scan_queue.sv:190-323,725-796`: complete-record checks, input-derived pre/post ordering, reset-before-cancel model, collector out_ready connected to queue in_ready, stop/rearm cancels queue. The documented finite queue does not promise lossless sustained input under indefinite consumer stall.

Runner `snapshot/competition/deepeye/tools/acquisition/run_raw_scan_queue.py:269-371,450-527,542-739,752-1047,1306-1368,1527-1544`: strict marker/token sets, widths and exact case/phase/cycle multiplicity; known padding bits rejected in mixed X/Z words without coercing symbolic unknowns. History derives queue/collector state from inputs and ignores ref_* oracle metadata. Queue reset/cancel and collector reset/stop/rearm origins are distinct. The documented stall and circuit counts are selected contiguous intervals. Numeric mutant corroboration maps exactly the six payload aliases to out_*; aggregation rejects missing/extra/failed selected cases.

Pinned collector `snapshot/competition/deepeye/fpga/acquisition/deepeye_sample_scan_capture.sv:112-187,194-272,280-350,362-383`: explicit overrun/drop, ordinal exhaustion and reset/stop/rearm window semantics were checked against the composition wiring and runner model. No additional concrete defect was established in this scope.

## Historical qualification retained, not replayed

Repair02's alias false negative, failed original24-case summary and exact six-label correction are retained. Saved final classification lists24 captures; its original new_vendor_runs=0 denotes reclassification only. Only the selected wrap mutant has the separately saved final vendor rerun. Its actual argv selects `--case mutant_wrap_depth5`.

Repair03 property input/red/green files each contain45,412 saved rows. Recorded outcomes are old23,504 false accepts/new0; A read and hashed those files without rerunning the properties. Saved qualification has58original+5coordinator direct/CLI fixtures, all recorded matches, and3normal-main exits0/1/1. The15saved actual executables are explicitly Python synthetic emitters, with30bound raw streams and separate intended vendor argv. They are process/parser evidence, not new ModelSim simulation. B coordinator's own count correction70=66qualification+4Git is preserved and remains separate from A evidence.

No30-case vendor baseline,24-case runner suite,45,412-property group,58+5fixtures,15emitters, prior RTL/ModelSim/GPU/board test, simulation or solve was rerun by A.

## Limits and authority

Head runner contents read timed out at180seconds, then direct blob read at60seconds. The successfully retrieved source-commit bytes were reused only after recomputed Git blob `232698e9143daa47be95dca63eb29aa52d5806a3` matched the runner path in root's saved exact-head comparison. Root's earlier schannel/earlyEOF full-fetch failure and mistaken OVERVIEW404 are preserved; actual handoff README was retrieved. There was no full clone/fetch.

The first A binding script assumed every frozen input lived in the evidence directory and failed. `initial-evidence-bindings.*` preserves it and its exit1. The correction handles source paths and reports47/48 accurately. The final audit command exited0. No B evidence was changed.

All29/R02/R03/B02/B03/G05/B06/full-product/full-product simulation/synthesis/implementation/timing/CDC_RDC/board/system remain **not_run**. No public ABI/source-clock/DMA/PS/freshness/ENABLE/motion authority or physical scope is granted. Board operation remains A-only. Root owns acceptance, peer delivery and PR feedback. `feedback-draft.md` is unsent.
