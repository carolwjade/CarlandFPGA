"""Read saved metadata and bind it to independently hashed archive members.
This does not run any classifier, test fixture, simulator, property or solver.
"""
import ast
from collections import Counter
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

OUT=Path(__file__).resolve().parent
PUB=OUT/'snapshot/competition/deepeye/evidence/acquisition/raw-scan-queue-20261022-23/publication'
MEM=OUT/'inert-members'
RTL='630e14803d82b3379517d91626de4ad7e7d3c509ad14363b3164031a5f633ee4'
RUNNER='9a06a7a368313dc96b6941fdaa8dfc4bcda27ed426bf5e75e00e2a1072b39996'
indexes={b:json.loads((PUB/'bundles'/f'{b}.index.json').read_bytes())['files'] for b in ['author','main-original','repair01','repair02','repair03','coordinator-reviews']}
def sha(b): return hashlib.sha256(b).hexdigest()
def raw(bundle,path):
    saved=MEM/bundle/path
    if saved.is_file(): return saved.read_bytes()
    with tarfile.open(PUB/'bundles'/f'{bundle}.tar.gz','r:gz') as tf:
        data=tf.extractfile(path).read()
    assert sha(data)==indexes[bundle][path]['sha256']
    return data
def j(bundle,path): return json.loads(raw(bundle,path))
def local(path): return path.replace('\\','/').split('/raw-scan-queue-20261022-23/',1)[1]
def bind_flat(bundle,path):
    d=j(bundle,path)
    assert d['exit']==0 and d['timed_out'] is False,path
    for side in ['stdout','stderr']:
        name=local(d[side+'_path'])
        assert indexes[bundle][name]['sha256']==d[side+'_sha256'],name
    return {'path':path,'argv':d['argv'],'exit':d['exit'],'stdout_sha256':d['stdout_sha256'],'stderr_sha256':d['stderr_sha256']}
def main():
    report={'method':'saved evidence metadata + bytes/AST audit only; no group reruns'}
    freeze=j('main-original','main/PREDISPATCH_FREEZE.json')
    bound=[]; omitted=[]
    for f in freeze['files']:
        if '/raw-scan-queue-20261022-23/' not in f['path'].replace('\\','/'):
            matches=[b+':'+p for b,idx in indexes.items() for p,v in idx.items() if v['sha256']==f['sha256']]
            if matches: bound.append({'original_path':f['path'],'same_bytes_in_archives':matches[:5]})
            else: omitted.append(f['path'])
            continue
        name=local(f['path'])
        if name in indexes['main-original']:
            assert indexes['main-original'][name]['sha256']==f['sha256']
            bound.append(name)
        else: omitted.append(name)
    report['original_freeze']={'sha256':sha(raw('main-original','main/PREDISPATCH_FREEZE.json')),'recorded_inputs':len(freeze['files']),'published_bound_inputs':len(bound),'omitted_inputs':omitted,'recorded_utc':freeze['at_utc'],'chronology':'saved B receipt only; A did not observe historical dispatch'}
    baseline=j('repair02','main/repair02/runs/baseline02/RESULT.json')
    assert baseline['planned']==baseline['executed']==30 and baseline['complete'] and baseline['all_pass'] and baseline['DUT_sha256']==RTL
    receipts=[]; edges=0; port_bindings=[]
    for i,c in enumerate(baseline['results']):
        prefix=f'main/repair02/runs/baseline02/c{i:02}'
        assert c['pass']
        for source in c['source_snapshots']:
            assert indexes['repair02'][local(source['path'])]['sha256']==source['sha256']
        for tool in ('vlib','vlog','vsim'):
            receipts.append(bind_flat('repair02',prefix+'/'+tool+'.result.json'))
        if c['kind']=='positive':
            comparison=c['comparison']; edges+=comparison['edges']
            assert indexes['repair02'][prefix+'/ports.txt']['sha256']==comparison['trace_sha256']
            assert comparison['trace_rows']==2*comparison['edges'] and comparison['pass'] and comparison['first_mismatch'] is None
            port_bindings.append({'case':c['name'],'edges':comparison['edges'],'ports_path':prefix+'/ports.txt','sha256':comparison['trace_sha256']})
    assert edges==87836 and len(port_bindings)==17
    counts=Counter(c['kind'] for c in baseline['results'])
    report['baseline']={'cases':30,'recorded_positive':17,'recorded_positive_edges':edges,'illegal_single_parameter_guards':10,'legal_controls':2,'competing_invalid_priority_controls':1,'kind_counts':dict(counts),'saved_source_and_90_process_receipts_bound':True,'port_bindings':port_bindings,'receipts':receipts,'A_rerun':False}
    coverage=j('repair02','main/repair02/runs/baseline02/ACTUAL_COVERAGE.json')
    assert coverage['actual_complete_positive_edges']==edges and coverage['result_sha256']==sha(raw('repair02','main/repair02/runs/baseline02/RESULT.json'))
    # Inspect source diffs only; no compilation or test calls.
    sourcebase=OUT/'snapshot/competition/deepeye'
    diffs={}
    for filename,relative in [('deepeye_raw_scan_queue.sv','fpga/acquisition/deepeye_raw_scan_queue.sv'),('tb_raw_scan_queue.sv','tests/rtl/acquisition/tb_raw_scan_queue.sv')]:
        old=raw('repair02','main/repair02/snapshots/'+filename).decode().splitlines()
        new=(sourcebase/relative).read_text(encoding='utf-8').splitlines()
        sm=difflib.SequenceMatcher(a=old,b=new)
        changes=[{'old_line':a+1,'old':old[a:b],'new_line':c+1,'new':new[c:d]} for tag,a,b,c,d in sm.get_opcodes() if tag!='equal']
        diffs[filename]=changes
    report['guard_source_diff']=diffs
    old=raw('repair03','main/repair03/snapshots/run_raw_scan_queue.py').decode()
    new=(sourcebase/'tools/acquisition/run_raw_scan_queue.py').read_text(encoding='utf-8')
    changes=list(difflib.unified_diff(old.splitlines(),new.splitlines(),lineterm=''))
    assert len([s for s in changes if s.startswith('+') and not s.startswith('+++')])==6
    assert len([s for s in changes if s.startswith('-') and not s.startswith('---')])==0
    oldtree=ast.parse(old); newtree=ast.parse(new)
    oldfunc={n.name:ast.dump(n,include_attributes=False) for n in oldtree.body if isinstance(n,ast.FunctionDef)}
    newfunc={n.name:ast.dump(n,include_attributes=False) for n in newtree.body if isinstance(n,ast.FunctionDef)}
    assert set(oldfunc)==set(newfunc)
    changed=[n for n in oldfunc if oldfunc[n]!=newfunc[n]]
    assert changed==['_parse_trace_row']
    report['repair03_diff']={'added_lines':6,'removed_lines':0,'changed_functions':changed,'diff':changes}
    mapping=j('repair02','main/repair02/alias-correction/MAPPING_FREEZE.json')
    report['alias_correction']={'mapping':mapping['mapping'],'freeze_sha256':sha(raw('repair02','main/repair02/alias-correction/MAPPING_FREEZE.json'))}
    saved=j('repair02','main/repair02/final-saved/RESULT.json')
    assert len(saved['saved_vendor_cases'])==24 and all(c['ok'] and c['exit']==0 for c in saved['saved_vendor_cases']) and saved['new_vendor_runs']==0
    wrap=bind_flat('repair02','main/repair02/final-wrap/execute.result.json')
    assert wrap['argv'][-2:]==['--case','mutant_wrap_depth5']
    report['saved_classification_and_final_wrap']={'saved_cases':24,'recorded_reclassification_only':True,'new_vendor_runs_in_saved_group':0,'selected_final_wrap':wrap,'old_failed_vendor_summary_sha256':j('repair02','main/repair02/FINAL_EXECUTION_BINDING.json')['old_failed_vendor_summary_sha256']}
    qual=j('repair03','main/repair03/qualification/RESULT.json')
    assert qual['runner_sha256']==RUNNER and len(qual['direct_and_cli'])==63 and all(c['match'] for c in qual['direct_and_cli']) and [c['actual_exit'] for c in qual['normal_main_entries']]==[0,1,1]
    assert Counter(c['group'] for c in qual['direct_and_cli'])=={'frozen58':58,'coordinator5':5}
    report['saved_repair03_qualification']={'direct_and_cli':63,'groups':{'frozen58':58,'coordinator5':5},'normal_main_exits':[0,1,1],'actual_vendor_runs':qual['actual_vendor_runs'],'A_rerun':False}
    decision=j('repair03','main/repair03/REVIEW_DECISION.json')
    props=decision['property_summary']
    assert props['total']==45412 and props['old_false_accepts']==23504 and props['new_false_accepts']==props['new_false_rejects']==0
    report['width_property_saved_summary']={'total':45412,'old_false_accepts':23504,'new_false_accepts':0,'new_false_rejects':0,'A_property_rerun':False,'source':'main/repair03/REVIEW_DECISION.json'}
    # Bind explicitly synthetic emitter process records to exact raw stream members.
    emitters=[]; stream_checks=[]
    for path in sorted(indexes['repair03']):
        if not path.startswith('main/repair03/qualification/entries/') or not path.endswith('.invocation.json'): continue
        d=j('repair03',path)
        assert d['synthetic_vendor_seam'] is True and 'python.exe' in d['argv'][0].lower() and d['vendor_intended_argv'][0].lower().endswith('.exe')
        assert d['exit']==0 and d['timed_out'] is False
        parent=PurePosixPath(path).parent
        for side,s in d['streams'].items():
            member=str(parent/s['path']); meta=indexes['repair03'][member]
            assert meta['sha256']==s.get('compressed_sha256',s['sha256'])
            stream_checks.append({'path':member,'sha256':meta['sha256']})
        emitters.append({'path':path,'actual_argv':d['argv'],'vendor_intended_argv':d['vendor_intended_argv'],'synthetic':True})
    assert len(emitters)==15 and len(stream_checks)==30
    report['composition_process_bindings']={'synthetic_emitters':15,'streams':30,'processes':emitters,'stream_hash_bindings':stream_checks}
    correction=j('coordinator-reviews','coordinator/repair03-review/COORDINATOR_AUDIT_CORRECTION.json')
    assert correction['actual_count']==70 and correction['qualification_count']==66 and correction['git_count']==4
    report['B_coordinator_count_correction']={'total':70,'qualification':66,'git':4,'scope':'B coordinator own evidence, separate from A audit'}
    (OUT/'evidence-bindings-results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'baseline_receipts':90,'positive_ports':17,'recorded_edges':edges,'saved_cases':24,'saved_fixtures':63,'synthetic_emitters':15,'changed_parser_functions':changed,'A_old_test_reruns':0}))
if __name__=='__main__': main()
