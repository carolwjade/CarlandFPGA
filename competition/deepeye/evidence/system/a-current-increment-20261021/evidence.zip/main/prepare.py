"""Publish completed new work; do not rerun any functional test."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

D = Path(__file__).resolve().parent
O = D.parent
ROOT = O.parents[1]
P = ROOT / '.local/deepeye-implementation-a'
T = P / 'competition/deepeye/evidence/system/a-current-increment-20261021'
CONTRACT = 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def load(p): return json.loads(p.read_bytes())
def encoded(x): return (json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False)+'\n').encode()
def write(p, raw):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f: f.write(raw)

scope = load(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
assert sha(json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()) == CONTRACT
assert load(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')['status'] == 'active'
canaries = []
for name in ('g03-finite-coil-transfer-preparation-20261021', 'r02-amd-wheel-acquisition-20261021', 'r02-same-object-continuation-20261021'):
    j = load(O/name/'lease.private.json')
    token = j.get('lease_token')
    if token: canaries.append(token.encode())

members, derivatives = {}, []
def clean_environment(value):
    if isinstance(value, list):
        return [clean_environment(v) for v in value]
    if isinstance(value, dict):
        return {k: clean_environment(v) for k,v in value.items() if k not in ('environment', 'env')}
    return value

def add(p, name=None):
    assert p.is_file() and not p.is_symlink()
    assert 'private' not in p.name.casefold() and p.name != 'reserve-request.json'
    raw = p.read_bytes()
    name = name or p.relative_to(O).as_posix()
    if p.suffix == '.json':
        j = json.loads(raw)
        clean = clean_environment(j)
        if clean != j:
            name = name.removesuffix('.json')+'-public.json'
            if isinstance(clean, dict):
                clean['original_environment_omitted'] = True
                clean['original_local_sha256'] = sha(raw)
            derivatives.append({'published_path':name, 'original_sha256':sha(raw)})
            raw = encoded(clean)
    assert not any(token in raw for token in canaries), name
    assert name not in members, name
    members[name] = raw

prep = O/'g03-finite-coil-transfer-preparation-20261021'
for row in load(prep/'public-manifest.json')['files']:
    p = prep/row['path']; raw=p.read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    if p.name!='reserve-request.json': add(p)
add(prep/'public-manifest.json')
for name in ('g03-fixed-transfer-main-20261021', 'b-op19-current-review-20261021'):
    for p in sorted((O/name).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and 'private' not in p.name.casefold() and p.name!='reserve-request.json':
            add(p)
rec = O/'r02-same-object-continuation-20261021'
rec_manifest = load(rec/'manifest.json')
for name,row in rec_manifest['files'].items():
    p=rec/name; raw=p.read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    if p.name!='reserve-request.json': add(p)
add(rec/'manifest.json')
for name in ('review.json','native-job-readback.json'): add(O/'r02-same-object-main-review-20261021'/name)
amd = O/'r02-amd-wheel-acquisition-20261021'
for name in ('streaming_zip.py','verify_wheel.py','run_one.py','main-runtime-selection.json','incoming-pins.json'):
    add(amd/name)
for prefix in ('requests/001-amd-torch-device-gfx1103', 'runs/001-amd-torch-device-gfx1103-curl'):
    for p in sorted((amd/prefix).iterdir()):
        if p.is_file(): add(p)
tail = load(rec/'selection.json')['complete_tail_record']
add(Path(tail['receipt']['path']))
write(D/'public-derivatives.json',encoded(derivatives))

g03 = load(O/'g03-fixed-transfer-main-20261021/main-result-adoption.json')
b = load(O/'b-op19-current-review-20261021/main-review.json')
r02 = load(O/'r02-same-object-main-review-20261021/review.json')
summary = {'utc':datetime.now(timezone.utc).isoformat(), 'parent_product_head':'0b30bab0253f655506682c95e3e9d67ae4234565',
           'requirements_sha256':CONTRACT, 'G03_conditional_transfer':g03, 'B_op19_review':b,
           'R02_complete_wheel':r02, 'public_environment_derivatives':derivatives,
           'old_functional_tests_repeated':False, 'R03':'not_run', 'full_H12':'not_run', 'all29':'not_run'}
members['main/summary.json']=encoded(summary)
members['main/prepare.py']=Path(__file__).read_bytes()
T.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(T/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()):
        zi=zipfile.ZipInfo(name,(2026,10,21,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16
        z.writestr(zi,raw)
with zipfile.ZipFile(T/'evidence.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for name,raw in members.items(): assert z.read(name)==raw
write(T/'.gitattributes',b'* -text -eol -filter\n')
write(T/'archive-index.json',encoded({n:{'bytes':len(v),'sha256':sha(v)} for n,v in sorted(members.items())}))
write(T/'summary.json',encoded(summary))
readme='''# New work validated without repeating completed tests

This checkpoint preserves three completed increments. Earlier board baseline,
pipeline, PC_DIRECT heartbeat and R03 software checks are reused at their recorded
versions. No new claim is made that those operations ran again.

G03 now has an implemented finite-disk functional W_B and boundary-to-receiver
transfer T. New analytic/matrix controls passed, then one selected 8-cell model
assembled A/C and solved 49 columns in 6.94 seconds. It reused the saved full48
boundary difference instead of recalculating it. Observed voltage changes were
7.266574824975231e-21 and 3.635898391555066e-21 V, with conditional bound
1.453555705290784e-20 V. The largest normalized column residual was
9.13659674250848e-17; kappa2=461.7733816605193 is only a diagnostic. Source and
absolute-voltage equivalence, mesh/domain/continuous-coil accuracy and the receiver
error budget remain open. This fixed-model sensitivity is not G03 acceptance.

B PR30 exact aef19351f1836b23f9a714bc5626db4eb4df98c5 changes two Python
qualification files. Main ran only the 12 new tests and 8 independent diagnostic
cases; all passed. The previous 33 test class bodies were unchanged and were not
rerun. This accepts the bounded Python repair, not the unreviewed op18 RTL campaign.
Feedback was posted once and read back at issuecomment-6310510195 on PR30.

The AMD gfx1103 wheel is now complete: 50,718,246 bytes, computed SHA256
a684f7689d514b20b889c56bb5aa6b137028b8351f3edc4fd4f8c81e81188140.
The first GET failed with curl56 and returned 50,660,462 bytes. A new offline
operation used the previously complete 65,557-byte HTTP206 tail of the same URL,
ETag and AWS version. All 7,773 overlap bytes matched; appending 57,784 bytes
created a new complete file. One streaming validation checked all 5 members,
4 RECORD hashes, CRCs, sizes, METADATA and Tags. Main read the exact terminal result
and independently rehashed the complete file. No request was sent by this recovery,
no code from the wheel ran, and no installation occurred. The failed GET/old partial
remain unchanged; the new hash is not a published vendor digest. Twelve selected
packages are complete; five remaining AMD objects are a separate active assignment.

The archive holds public source, actual outputs and terminal evidence. Vendor
wheels, private lease material and full inherited environments are excluded.
Environment-removed derivatives identify their original local hashes. ZIP CRC and
every member's bytes were verified once during packaging; this is archive integrity,
not another functional test run. New source/absolute-voltage and remaining-package
work is pending outside this frozen checkpoint.

H01-H15 remain DEEPEYE-HUMAN-LOCK-20261014/revision1, requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
R03, complete H12 paths and all29 formal task cards remain not_run.
'''
write(T/'README.md',readme.encode())
write(T/'manifest.json',encoded({'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(T.iterdir())},'archive_members':len(members),'archive_crc_and_exact_bytes_verified':True}))
guide=P/'competition/deepeye/docs/current_increment_20261021.md'
write(guide,('''# Current G03, B qualification and R02 increment

The [reviewed checkpoint](../evidence/system/a-current-increment-20261021/README.md)
contains the new finite-coil transfer implementation and actual fixed-model result,
the independent B op19 Python qualification review, and the completed gfx1103 wheel
reconstruction/validation evidence. Their source identities and actual process
terminals are separate from formal acceptance. See summary.json for numeric results.

Next: resolve the circular-source projection and absolute receiver voltage, then
mesh/domain accuracy; obtain the five remaining pinned AMD packages before selecting
an isolated runtime installation. Project CNN artifacts remain a C dependency.
R03 custom register/HWH and B/C interoperability remain dependencies on B's design.
The already successful physical base-BRAM baseline and software pipeline are reused.
Human display/input remain reserved; all new work runs in background.
''').encode())
files={p.relative_to(P).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in [*sorted(T.iterdir()),guide]}
write(D/'publication-files.json',encoded(files))
write(D/'owned-paths.nul',b''.join(name.encode()+b'\0' for name in files))
result={'files':len(files),'archive_members':len(members),'archive_bytes':(T/'evidence.zip').stat().st_size,'archive_sha256':sha((T/'evidence.zip').read_bytes()),'environment_derivatives':len(derivatives)}
write(D/'package-summary.json',encoded(result))
print(json.dumps(result))
