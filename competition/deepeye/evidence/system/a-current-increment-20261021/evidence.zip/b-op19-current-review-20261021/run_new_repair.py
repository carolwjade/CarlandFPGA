from pathlib import Path
import hashlib,json,os,sys,ast
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
pins=json.loads((D/'retrieved-pins.json').read_bytes())
for n,row in pins.items():assert hashlib.sha256((D/'snapshot'/n).read_bytes()).hexdigest()==row['sha256']
testpath='competition/deepeye/tests/control/test_first_capture_deadline_runner.py'
old=ast.parse((D/'old18'/testpath).read_text(encoding='utf-8'));new=ast.parse((D/'snapshot'/testpath).read_text(encoding='utf-8'))
oldclasses={x.name:ast.dump(x) for x in old.body if isinstance(x,ast.ClassDef)}
newclasses={x.name:ast.dump(x) for x in new.body if isinstance(x,ast.ClassDef)}
assert all(newclasses[k]==v for k,v in oldclasses.items())
runner=D.parent/'r02-transient-quota-fix-20261021'
assert hashlib.sha256((runner/'win_job.py').read_bytes()).hexdigest()=='80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d'
sys.path.insert(0,str(runner));from win_job import run_bounded
out=D/'new-tests';out.mkdir();(out/'tmp').mkdir()
env={k:v for k,v in os.environ.items() if k.upper() in {'SYSTEMROOT','WINDIR'}}
env.update(PATH='',TEMP=str(out/'tmp'),TMP=str(out/'tmp'),PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PYTHONIOENCODING='utf-8')
cmd=[str(ROOT/'.local/venv/Scripts/python.exe'),'-I','-S','-B','-X','utf8',str(D/'check_new_repair.py')]
budget={'seconds':50,'job_memory_bytes':512*1024**2,'process_memory_bytes':256*1024**2,'active_processes':4,'stdout_bytes':256*1024,'stderr_bytes':256*1024,'tree_bytes':16*1024**2,'tree_entries':3000,'free_reserve_bytes':10*1024**3}
r=run_bounded(cmd,env,D,out/'process',budget,[out])
assert r['status']=='success' and r['exit_code']==0 and r['active_processes_final']==0 and r['all_processes_terminated']
assert all(x['signaled'] and x['wait_result']==0 for x in r['held_members']) and not r['faults']
result=json.loads((out/'result.json').read_bytes());assert result['pid'] in [x['pid'] for x in r['held_members']]
with (D/'main-review.json').open('x',encoding='utf-8') as f:json.dump({'head':'aef19351f1836b23f9a714bc5626db4eb4df98c5','decision':'ACCEPT_BOUNDED_PYTHON_QUALIFICATION_REPAIR','new_test_methods':12,'independent_diagnostic_cases':8,'old_test_classes_AST_unchanged':True,'old_tests_not_repeated':True,'original_process_objects_stopped':len(r['held_members']),'B_op18_RTL_scope_not_promoted':True,'full_R03':'not_run','full_H12':'not_run','all29':'not_run'},f,indent=2)
print(json.dumps({'new_methods':12,'independent_cases':8,'original_process_objects_stopped':len(r['held_members']),'decision':'accept_bounded_python_repair'}))
