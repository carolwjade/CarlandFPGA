"""Retrieve exact current B repair blobs for a bounded new-source review."""
from pathlib import Path
import base64,hashlib,json,subprocess
D=Path(__file__).resolve().parent
HEAD='aef19351f1836b23f9a714bc5626db4eb4df98c5'
def save(p,raw):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(raw)
def js(p,o):save(p,(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode())
def api(label,url):
    cmd=['gh','api',url]
    js(D/(label+'.started.json'),{'argv':cmd})
    with (D/(label+'.stdout.bin')).open('xb') as out,(D/(label+'.stderr.bin')).open('xb') as err:
        p=subprocess.Popen(cmd,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        try:code=p.wait(timeout=50)
        except subprocess.TimeoutExpired:
            p.kill();p.wait(timeout=10)
            js(D/(label+'.timeout.json'),{'original_parent_pid':p.pid,'signaled':True,'no_retry':True})
            raise
    js(D/(label+'.result.json'),{'exit_code':code})
    assert code==0,(label,code)
    assert (D/(label+'.stdout.bin')).stat().st_size<16*1024**2
    return json.loads((D/(label+'.stdout.bin')).read_bytes())
tree=json.loads((D/'tree.stdout.bin').read_bytes()); rows={x['path']:x for x in tree['tree'] if x['type']=='blob'}
old=json.loads((D.parent/'peer-git-snapshot-20261021/b-tree.stdout.bin').read_bytes());oldrows={x['path']:x for x in old['tree'] if x['type']=='blob'}
prefix='competition/deepeye/evidence/control3d/first-capture-runner-qualification-20261021-19/'
paths=['competition/deepeye/tools/control3d/run_first_capture_deadline.py','competition/deepeye/tests/control/test_first_capture_deadline_runner.py','competition/deepeye/tools/control3d/main_verify_first_capture_deadline.py','handoffs/b/B-DEEPEYE-FIRST-CAPTURE-RUNNER-QUALIFICATION-20261021-19/manifest.json',prefix+'ACCEPTANCE.json',prefix+'README.md',prefix+'POLICY.md']
pins={}
for num,path in enumerate(paths,1):
 row=rows[path];assert row['mode']=='100644' and row['size']<=3*1024**2
 response=api('blob-'+str(num),'repos/carolwjade/CarlandFPGA/git/blobs/'+row['sha'])
 assert response['encoding']=='base64' and response['sha']==row['sha']
 data=base64.b64decode(response['content']);assert len(data)==row['size'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['sha']
 save(D/'snapshot'/path,data);pins[path]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':row['sha']}
for num,path in enumerate(paths[:2],1):
 row=oldrows[path];response=api('old-blob-'+str(num),'repos/carolwjade/CarlandFPGA/git/blobs/'+row['sha']);data=base64.b64decode(response['content']);assert len(data)==row['size'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['sha'];save(D/'old18'/path,data)
assert pins[paths[3]]['sha256']=='3e957ee6ee98e0e5168ec5164ef8d75954cbf81a2ab5ab29c87587b57a8ac54a'
assert pins[paths[0]]['sha256']=='283902fbb281bd313b553e2efbc622b49441c9250cded0461fa92bc700ad8eba'
assert pins[paths[1]]['sha256']=='1247a7c84fde50368ddf88d967e7b8d14468719da023b498d64014c63ebe8159'
js(D/'retrieved-pins.json',pins)
print(json.dumps({'review_head':HEAD,'new_source_evidence_files':len(pins),'old_sources_for_readonly_diff':2,'old_tests_rerun':False}))
