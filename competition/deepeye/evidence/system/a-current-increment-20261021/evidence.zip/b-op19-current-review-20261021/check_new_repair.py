"""Only op19's new methods and independent new diagnostic cases; no RTL replay."""
from pathlib import Path
import importlib.util,json,os,sys,unittest
D=Path(__file__).resolve().parent
OUT=D/'new-tests'
def audit(event,args):
    if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.startfile','ctypes.dlopen'}:
        raise RuntimeError('No external effect in parser repair review: '+event)
    if event=='open' and not isinstance(args[0],int):
        mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writing and not Path(args[0]).resolve().is_relative_to(OUT):raise RuntimeError('Unowned write')
sys.addaudithook(audit)
p=D/'snapshot/competition/deepeye/tests/control/test_first_capture_deadline_runner.py'
spec=importlib.util.spec_from_file_location('reviewed_new_b_tests',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
suite=unittest.defaultTestLoader.loadTestsFromTestCase(m.ErrorAccountingAndAggregationTests)
assert suite.countTestCases()==12
result=unittest.TextTestRunner(verbosity=2).run(suite)
assert result.wasSuccessful() and result.testsRun==12
r=m.runner
good_mutant=m.MainQualificationRegressionTests.complete_mutant()
cases=[
 ('normal_multiple_zero',lambda:r.qualify_normal_log('Errors: 0, Warnings: 9\n'+m.REAL_NORMAL_LOG+'Errors: 0, Warnings: 4\n',1,'standalone',r.SMALL_GROUPS,0)[0],True),
 ('guard_prefixed_plain_lower',lambda:r.qualify_guard_log('# fatal: foreign build failure\n'+m.REAL_GUARD0_LOG,0,0)[0],False),
 ('guard_own_fatal_twice',lambda:r.qualify_guard_log(m.REAL_GUARD0_LOG+'DEEPEYE_FIRST_CAPTURE_INVALID_PARAM unsupported width\n',0,0)[0],False),
 ('normal_tally_plus_suffix',lambda:r.qualify_normal_log(m.REAL_NORMAL_LOG+'Errors: 0, Warnings: 0 extra\n',1,'standalone',r.SMALL_GROUPS,0)[0],False),
 ('guard_unicode_digit_tally',lambda:r.qualify_guard_log(m.REAL_GUARD0_LOG+'Errors: １, Warnings: 0\n',0,0)[0],False),
 ('mutant_foreign_after_hit',lambda:r.classify_mutant_execution(good_mutant+'# FATAL: foreign trailing fault\n',1,0,False)['run_valid'],False),
 ('mutant_zero_before_one_after',lambda:r.classify_mutant_execution('Errors: 0, Warnings: 1\n'+good_mutant+'Errors: 1, Warnings: 0\n',1,0,False)['target_hit'],True),
 ('mutant_two_positive_tallies',lambda:r.classify_mutant_execution(good_mutant+'Errors: 1, Warnings: 0\nErrors: 1, Warnings: 0\n',1,0,False)['run_valid'],False),
]
observed=[]
for name,call,expected in cases:
    actual=call();observed.append({'case':name,'expected':expected,'actual':actual});assert actual==expected,name
with (OUT/'result.json').open('x',encoding='utf-8') as f:json.dump({'new_methods':12,'independent_cases':observed,'old_33_methods_rerun':False,'RTL_rerun':False,'status':'passed','pid':os.getpid()},f,indent=2)
print(json.dumps({'new_methods':12,'independent_cases':len(cases),'old_methods_rerun':False,'status':'passed'}))
