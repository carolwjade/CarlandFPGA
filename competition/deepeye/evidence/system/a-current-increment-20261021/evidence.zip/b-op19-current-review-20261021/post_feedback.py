from pathlib import Path
import hashlib,json,subprocess
D=Path(__file__).resolve().parent
r=json.loads((D/'main-review.json').read_bytes());assert r['decision']=='ACCEPT_BOUNDED_PYTHON_QUALIFICATION_REPAIR'
body='''A coordinator review — `A-B-OP19-REPAIR-REVIEW-20261021-v1`

**Accept the bounded Python qualification repair** at exact head `aef19351f1836b23f9a714bc5626db4eb4df98c5`, runner SHA256 `283902fbb281bd313b553e2efbc622b49441c9250cded0461fa92bc700ad8eba`, test SHA256 `1247a7c84fde50368ddf88d967e7b8d14468719da023b498d64014c63ebe8159`.

A retrieved exact Git blobs and verified the reported manifest SHA256 `3e957ee6ee98e0e5168ec5164ef8d75954cbf81a2ab5ab29c87587b57a8ac54a`. The complete tree comparison found 5,743 prior files unchanged, two Python files changed, zero deleted, and 2,914 newly added files (2,916 changed/new blobs). Source review confirms shared ordered diagnostic accounting and the separate target-hit/survivor/execution-error outcomes; every selected mutant invocation must now be valid.

Following the human instruction to avoid repeating passed work, A ran only the new `ErrorAccountingAndAggregationTests` class: **12/12 methods passed**. Eight additional A diagnostic cases passed: multiple legitimate zero tallies; lower-case foreign fatal; duplicated own fatal; malformed tally suffix; non-ASCII tally count; foreign failure after a target hit; zero-before/one-after own-fatal accounting; and duplicated positive tallies. The previous test classes are AST-identical and were not rerun. All three original owned process objects stopped. No ModelSim, Vivado, RTL, mutation compilation or board suite was rerun.

This closes FC18-P2-01/02/03 for this Python repair. Original operation18 REVISE and its historical RTL evidence remain preserved; this decision does not independently accept operation18 RTL, public ABI/register integration, physical timing, H12 or formal R03. All29 formal cards remain not_run. H01-H15 remain `DEEPEYE-HUMAN-LOCK-20261014/revision1`, requirements SHA256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`.

Please read back this exact feedback and continue the existing register/capture integration proposal using the accepted repair; do not repeat earlier passed tests solely to generate another receipt.
'''
with (D/'feedback.md').open('x',encoding='utf-8',newline='\n') as f:f.write(body)
payload={'body':body}
with (D/'feedback-request.json').open('x',encoding='utf-8') as f:json.dump(payload,f,ensure_ascii=False)
def call(label,args):
    cmd=['gh',*args]
    with (D/(label+'.started.json')).open('x',encoding='utf-8') as f:json.dump({'argv':cmd},f,indent=2)
    with (D/(label+'.stdout.bin')).open('xb') as out,(D/(label+'.stderr.bin')).open('xb') as err:
        p=subprocess.Popen(cmd,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        try:code=p.wait(timeout=50)
        except subprocess.TimeoutExpired:
            p.kill();p.wait(timeout=10)
            raise RuntimeError('Unknown delivery; inspect original operation marker before any retry')
    assert code==0,(label,code)
    return json.loads((D/(label+'.stdout.bin')).read_bytes())
sent=call('feedback-post',['api','repos/carolwjade/CarlandFPGA/issues/30/comments','--method','POST','--input',str(D/'feedback-request.json')])
assert sent['body']==body
back=call('feedback-readback',['api','repos/carolwjade/CarlandFPGA/issues/comments/'+str(sent['id'])])
assert back['body']==body and back['id']==sent['id']
with (D/'feedback-result.json').open('x',encoding='utf-8') as f:json.dump({'comment_url':back['html_url'],'comment_id':back['id'],'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'remote_bytes_read_back':True,'peer_readback':'pending'},f,indent=2)
print(json.dumps({'url':back['html_url'],'remote_readback':True}))
