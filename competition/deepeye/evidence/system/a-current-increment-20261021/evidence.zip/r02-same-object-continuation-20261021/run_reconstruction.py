"""Minimal new wrapper; reuse reviewed held-job, runtime and streaming guards."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import traceback

D=Path(__file__).resolve().parent
ROOT=D.parents[2]
SOURCE=D.parent/'r02-amd-wheel-acquisition-20261021'
sys.path.insert(0,str(SOURCE))
from streaming_zip import file_pin

def load(p): return json.loads(Path(p).read_bytes())
def save(name,v):
    with (D/name).open('x',encoding='utf-8',newline='\n') as f:
        json.dump(v,f,indent=2,ensure_ascii=False)
        f.write('\n')

selection=load(D/'selection.json')
assert selection['work_id']=='A-R02-SAME-OBJECT-CONTINUATION-20261021-v1'
assert selection['new_network_requests_selected']==0
assert selection['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
contract=load(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
assert hashlib.sha256(json.dumps(contract['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==selection['requirements_sha256']
assert [r['id'] for r in contract['requirements']]==[f'H{i:02}' for i in range(1,16)]
transfer=load(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
assert transfer['status']=='active' and transfer['director_generation']==2 and transfer['new_director_thread_id']=='01a13d7e-dcf1-7272-a738-a637dd62ff9d'
old_manifest=SOURCE/'incoming-pins.json'
assert file_pin(old_manifest)=={'bytes':37595,'sha256':'fcffad05c4345da2ab83aa362e1aaef99b327e9d17b941f792ab7f62ff8ffa7d'}
old_pins=load(old_manifest)['files']
for name in ('streaming_zip.py','win_job.py','boundary.py','verify_wheel.py','main-runtime-selection.json','runtime-input-observation.json'):
    p=SOURCE/name
    assert file_pin(p)==old_pins[str(p)]
runtime=load(SOURCE/'main-runtime-selection.json')
assert runtime['status']=='selected_by_main_for_data_only_acquisition_validation'
for p,expected in runtime['selected_stdlib_files'].items(): assert file_pin(p)==expected
for r in load(SOURCE/'runtime-input-observation.json')['inputs']: assert file_pin(r['path'])==r['observed']
old_selection=load(SOURCE/'selection.json')
worker_image=old_selection['worker_image_sha256']
assert worker_image=='ceabb31054d429f57cb3825775677eeaf0db35fdabbc5ff6aef661c037154b00'
prefix_root=Path(selection['prefix']['path']).parent.parent
prefix_request=prefix_root/'requests'/selection['first_wheel']['id']
prefix_curl=prefix_root/'runs'/(selection['first_wheel']['id']+'-curl')
input_paths=[D/'selection.json',D/'reserve-request.json',D/'reconstruct_worker.py',D/'run_reconstruction.py',
    old_manifest,ROOT/'docs/competition/deepeye-2026/immutable_scope.md',ROOT/'docs/competition/deepeye-2026/immutable_scope.json',
    ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json',
    prefix_request/'download-result.json',prefix_request/'request.json',prefix_request/'headers.txt',
    prefix_curl/'stdout.txt',prefix_curl/'stderr.txt',prefix_curl/'terminal.json',
    Path(selection['complete_tail_record']['receipt']['path']),Path(selection['first_wheel']['accepted_metadata']['path'])]
input_paths += [SOURCE/n for n in ('streaming_zip.py','win_job.py','boundary.py','verify_wheel.py','main-runtime-selection.json','runtime-input-observation.json')]
readonly={str(p):file_pin(p) for p in input_paths}
readonly.update(runtime['selected_stdlib_files'])
for r in load(SOURCE/'runtime-input-observation.json')['inputs']: readonly[r['path']]=r['observed']
tail_receipt=selection['complete_tail_record']['receipt']
assert readonly[tail_receipt['path']]=={k:tail_receipt[k] for k in ('bytes','sha256')}
assert shutil.disk_usage(D).free-selection['first_wheel']['compressed_bytes']-8*1024**2>=10*1024**3
save('input-manifest.json',{'work_id':selection['work_id'],'job_id':'child-659e6b9beb6b4181b866b5e6b4078cb1',
    'requirements_sha256':selection['requirements_sha256'],'reviewed_source_directory':str(SOURCE),
    'worker_image_sha256':worker_image,'readonly_inputs':readonly,
    'expected_prefix':selection['prefix'],'expected_tail':selection['complete_tail_record']['body'],
    'large_source_hashes_verified_while_copying':True,'new_network_requests':0})
for name in ('artifacts','evidence','runs'): (D/name).mkdir()
from win_job import run_bounded,process_identity
from boundary import check_no_links
for p in (D,Path(selection['prefix']['path']),Path(selection['complete_tail_record']['body']['path'])): check_no_links(p)
env={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR')}
env.update(PATH='',TEMP=str(D/'evidence'),TMP=str(D/'evidence'),PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
def on_tick(job,pids):
    ready=D/'evidence/worker-ready.json'
    release=D/'evidence/worker-release.json'
    if ready.exists() and not release.exists():
        identity=load(ready)
        assert identity['pid'] in pids
        actual=process_identity(identity['pid'],job)
        assert Path(actual['image'])==Path(identity['base_executable']) and actual['image_sha256']==worker_image
        save('evidence/worker-release.json',actual)
budget={'seconds':60,'active_processes':4,'process_memory_bytes':256*1024**2,'job_memory_bytes':512*1024**2,
    'stdout_bytes':1024*1024,'stderr_bytes':1024*1024,'tree_bytes':64*1024**2,'tree_entries':100,
    'free_reserve_bytes':10*1024**3,'components':[
        {'path':str(D/'artifacts'),'bytes':50718246,'entries':1},
        {'path':str(D/'evidence'),'bytes':8*1024**2,'entries':30}]}
argv=[old_selection['python'],'-I','-S','-B','-X','utf8',str(D/'reconstruct_worker.py')]
result={'status':'failed','work_id':selection['work_id'],'new_network_requests':0}
try:
    terminal=run_bounded(argv,env,D,D/'runs/reconstruct-verify',budget,[D/'artifacts',D/'evidence'],on_tick=on_tick)
    result['terminal']=terminal
    assert terminal['all_processes_terminated'] is True and not terminal['faults']
    assert terminal['active_processes_final']==0
    assert terminal['held_members'] and all(m['signaled'] and m['wait_result']==0 for m in terminal['held_members'])
    assert terminal['status']=='success' and terminal['exit_code']==0
    worker=load(D/'evidence/worker-result.json')
    assert worker['status']=='success'
    image=load(D/'evidence/worker-release.json')
    assert image['pid'] in [m['pid'] for m in terminal['held_members']]
    for p,expected in readonly.items(): assert file_pin(p)==expected,p
    result.update(status='success',worker_result=worker,terminal_pin=file_pin(D/'runs/reconstruct-verify/terminal.json'),
        all_original_handles_signaled=True,inputs_unchanged=True,installations=0,vendor_imports=0,extractions=0,
        origin='new local same-object/version range reconstruction; failed full GET remains failed',
        disk_free_after_bytes=shutil.disk_usage(D).free,
        remaining_five_AMD_packages=[n['name'] for n in old_selection['files'][1:]],
        R02='not_run',C03='not_run',all29='not_run')
except BaseException:
    result.update(error=traceback.format_exc())
finally:
    result['ended_utc']=datetime.now(timezone.utc).isoformat()
    save('result.json',result)
print(json.dumps({'status':result['status'],'result':file_pin(D/'result.json'),
    'worker':result.get('worker_result'),'error':result.get('error')}))
raise SystemExit(0 if result['status']=='success' else 1)
