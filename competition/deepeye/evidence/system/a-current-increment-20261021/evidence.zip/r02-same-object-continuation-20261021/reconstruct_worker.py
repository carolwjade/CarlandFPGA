"""Offline same-object reconstruction and one reviewed streaming validation."""
from datetime import datetime,timezone
import email.parser
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import sys
import time
import traceback

D=Path(__file__).resolve().parent
Q=D/'evidence'
manifest=json.loads((D/'input-manifest.json').read_bytes())
source=Path(manifest['reviewed_source_directory'])
sys.path.insert(0,str(source))
from streaming_zip import file_pin,verify_stream

assert sys.implementation.name=='cpython' and sys.version_info[:2]==(3,12) and struct.calcsize('P')==8
attempts=[]
def guard(event,args):
    if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.startfile','os.startfile/2',
            'ctypes.dlopen','os.symlink','os.link'}:
        attempts.append(event)
        raise RuntimeError('offline worker external/native effect forbidden')
    if event=='import' and args[0].split('.')[0] in {'torch','rocm','rocm_sdk','rocm_bootstrap','setuptools','pip',
            'filelock','fsspec','jinja2','mpmath','networkx','sympy'}:
        attempts.append('vendor_import:'+args[0])
        raise RuntimeError('vendor import forbidden')
    if event=='open' and not isinstance(args[0],int):
        p=Path(args[0]).resolve()
        if 'private' in p.name.lower():
            attempts.append('private_read')
            raise RuntimeError('private files forbidden')
        mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (
            isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writing and not (p.is_relative_to(Q) or p.is_relative_to(D/'artifacts')):
            attempts.append('unowned_write')
            raise RuntimeError('write outside new task output paths')
    if event=='exec' and any(x.casefold() in args[0].co_filename.casefold() for x in ('/artifacts/','\\artifacts\\')):
        attempts.append('artifact_execution')
        raise RuntimeError('artifact is data')
sys.addaudithook(guard)

def save(name,value):
    with (Q/name).open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,indent=2,ensure_ascii=False)
        f.write('\n')

def one_response(path):
    raw=Path(path).read_bytes()
    require=len(raw)<=65536
    assert require
    blocks=[b for b in re.split(br'\r?\n\r?\n',raw) if b.startswith(b'HTTP/')]
    assert len(blocks)==1
    status,fields=blocks[0].split(b'\n',1)
    parsed=email.parser.BytesHeaderParser().parsebytes(fields)
    for key in ('etag','x-amz-version-id','content-length','content-range'):
        assert len(parsed.get_all(key,[]))<=1
    return status.strip().decode('ascii'),{k.lower():v.strip() for k,v in parsed.items()}

try:
    for p,pin in manifest['readonly_inputs'].items(): assert file_pin(p)==pin,p
    selection=json.loads((D/'selection.json').read_bytes())
    expected=selection['first_wheel']
    prefix=selection['prefix']
    tail_record=selection['complete_tail_record']
    prefix_root=Path(prefix['path']).parent.parent
    prefix_request=prefix_root/'requests'/expected['id']
    prefix_download=json.loads((prefix_request/'download-result.json').read_bytes())
    prefix_curl=prefix_root/'runs'/(expected['id']+'-curl')
    prefix_meta=json.loads((prefix_curl/'stdout.txt').read_bytes())
    prefix_error=(prefix_curl/'stderr.txt').read_text(encoding='utf-8')
    status,headers=one_response(prefix_request/'headers.txt')
    assert status=='HTTP/1.1 200 OK' and headers['content-length']==str(expected['compressed_bytes'])
    assert 'content-range' not in headers and headers.get('content-encoding','identity')=='identity'
    assert headers['etag']==expected['etag'] and headers['x-amz-version-id']==expected['version_id']
    assert prefix_meta['http_code']==200 and prefix_meta['exitcode']==56
    assert prefix_meta['size_download']==prefix['bytes'] and prefix_download['body']=={k:prefix[k] for k in ('bytes','sha256')}
    assert prefix_download['outcome']=='failed_stopped_object' and prefix_download['process_terminal']['status']=='failed'
    assert '--range' not in prefix_download['argv'] and not any(s.startswith('Range:') for s in prefix_download['argv'])
    assert 'If-Match: '+expected['etag'] in prefix_download['argv']
    tail_receipt=json.loads(Path(tail_record['receipt']['path']).read_bytes())
    th=tail_receipt['response_headers']
    tm=tail_receipt['curl_metadata']
    assert tail_receipt['outcome']=='complete' and tail_receipt['exit_code']==0 and tail_receipt['inputs_unchanged'] is True
    assert tail_receipt['status_line']=='HTTP/1.1 206 Partial Content' and tm['http_code']==206 and tm['exitcode']==0
    assert th['etag']==headers['etag'] and th['x-amz-version-id']==headers['x-amz-version-id']
    assert th['content-length']==str(tail_record['body']['bytes']) and th['content-range']==tail_record['content_range']
    assert tail_receipt['object_range']==tail_record['object_range']
    assert tail_receipt['request']['url']==expected['artifact_url'] and tail_receipt['request']['method']=='GET'
    assert tail_receipt['request']['headers']['Range']=='bytes=-65557'
    for meta in (prefix_meta,tm):
        assert meta['url_effective']==expected['artifact_url'] and meta['method']=='GET' and meta['scheme']=='https'
        assert meta['ssl_verify_result']==meta['num_redirects']==meta['num_retries']==0
    extent=tail_receipt['object_range']
    assert extent=={'start':50652689,'end':50718245,'total':50718246}
    overlap=prefix['bytes']-extent['start']
    assert overlap==7773==selection['overlap_bytes'] and extent['end']+1==expected['compressed_bytes']
    raw_tail=Path(tail_record['body']['path']).read_bytes()
    tail_actual={'bytes':len(raw_tail),'sha256':hashlib.sha256(raw_tail).hexdigest()}
    assert tail_actual=={k:tail_record['body'][k] for k in ('bytes','sha256')}
    assert tail_receipt['body_sha256']==tail_actual['sha256'] and tail_receipt['received_bytes']==len(raw_tail)
    # Establish live image binding before any large-data work.
    save('worker-ready.json',{'pid':os.getpid(),'base_executable':sys._base_executable})
    deadline=time.monotonic()+15
    while not (Q/'worker-release.json').exists():
        assert time.monotonic()<deadline,'independent live image binding deadline'
        time.sleep(.02)
    image=json.loads((Q/'worker-release.json').read_bytes())
    assert image['pid']==os.getpid() and image['image_sha256']==file_pin(sys._base_executable)['sha256']==manifest['worker_image_sha256']
    output=D/'artifacts'/expected['filename']
    prefix_h,full_h=hashlib.sha256(),hashlib.sha256()
    prefix_size=0
    last=b''
    with Path(prefix['path']).open('rb') as src,output.open('xb') as out:
        for block in iter(lambda:src.read(128*1024),b''):
            prefix_size+=len(block)
            assert prefix_size<=prefix['bytes']
            prefix_h.update(block)
            full_h.update(block)
            last=(last+block)[-overlap:]
            out.write(block)
        copied_prefix={'bytes':prefix_size,'sha256':prefix_h.hexdigest()}
        assert copied_prefix=={k:prefix[k] for k in ('bytes','sha256')},'prefix hash/size changed while copying'
        assert last==raw_tail[:overlap],'overlap bytes differ'
        suffix=raw_tail[overlap:]
        assert len(suffix)==57784 and prefix_size+len(suffix)==expected['compressed_bytes']
        out.write(suffix)
        full_h.update(suffix)
        out.flush()
        os.fsync(out.fileno())
    assembled={'bytes':output.stat().st_size,'sha256':full_h.hexdigest()}
    assert assembled['bytes']==expected['compressed_bytes']
    identity={'status':'same_object_ranges_independently_matched','url':expected['artifact_url'],
        'etag':headers['etag'],'x-amz-version-id':headers['x-amz-version-id'],
        'prefix_http':{'status':status,'content-length':headers['content-length'],'curl_exit':56,
            'actual_error':prefix_error,'TLS_verify_result':prefix_meta['ssl_verify_result'],
            'num_redirects':prefix_meta['num_redirects'],'headers_path':str(prefix_request/'headers.txt')},
        'tail_http':{'status':tail_receipt['status_line'],'content-length':th['content-length'],'content-range':th['content-range'],
            'curl_exit':0,'TLS_verify_result':tm['ssl_verify_result'],'num_redirects':tm['num_redirects']},
        'prefix':copied_prefix,'tail':tail_actual,'overlap_bytes':overlap,'overlap_equal':True,
        'overlap_sha256':hashlib.sha256(last).hexdigest(),'appended_bytes':len(suffix),'reconstructed_artifact':assembled,
        'full_GET_success':False,'publisher_full_hash_available':False,'new_network_requests':0,
        'old_failed_operation_preserved':True,'old_partial_opened_read_only':True,'output_created_exclusively':True}
    save('reconstruction.json',identity)
    accepted=expected['accepted_metadata']
    assert file_pin(accepted['path'])=={k:accepted[k] for k in ('bytes','sha256')}
    review=verify_stream(output,expected,Path(accepted['path']).read_bytes())
    assert file_pin(output)==assembled
    for p,pin in manifest['readonly_inputs'].items(): assert file_pin(p)==pin,p
    assert not attempts
    review.update(artifact={'path':str(output),**assembled},origin='local reconstruction of exact same-version HTTP ranges',
        full_GET_success=False,publisher_full_hash_available=False,new_network_requests=0,prohibited_attempts=attempts,
        independent_image_binding=image,python={'executable':sys.executable,'base_executable':sys._base_executable,
            'pid':os.getpid(),'ppid':os.getppid(),'version':sys.version,'isolated':sys.flags.isolated,
            'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode})
    assert review['python']['isolated']==review['python']['no_site']==1 and review['python']['dont_write_bytecode']
    save('archive-review.json',review)
    save('worker-result.json',{'status':'success','artifact':review['artifact'],'members':review['member_count'],
        'record_hash_count':review['record_hash_count'],'declared_expanded_bytes':review['declared_uncompressed_bytes'],
        'accepted_metadata_bytes_equal':True,'tags':review['tags'],'name':review['metadata']['name'],'version':review['metadata']['version'],
        'reconstruction':file_pin(Q/'reconstruction.json'),'archive_review':file_pin(Q/'archive-review.json'),
        'source_inputs_unchanged':True,'new_network_requests':0,'vendor_imports':0,'installations':0,'extractions':0,
        'R02':'not_run','C03':'not_run','all29':'not_run'})
    print(json.dumps({'status':'success','artifact':review['artifact'],'members':review['member_count']}))
except BaseException:
    save('worker-failure.json',{'status':'failed','error':traceback.format_exc(),'prohibited_attempts':attempts})
    traceback.print_exc()
    raise
