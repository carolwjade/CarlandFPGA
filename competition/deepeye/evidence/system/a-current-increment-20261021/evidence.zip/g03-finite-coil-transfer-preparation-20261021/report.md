# G03 finite-coil transfer preparation

Worker `/root/g03_finite_coil_prep_20261021`, work
`A-G03-finite-coil-transfer-preparation-20261021-v1`, native job
`child-ae88c608efca4da9ac402f6461d9c0a1`. This is preparation only and awaits
independent main review. The current generation-2 director remains
`01a13d7e-dcf1-7272-a738-a637dd62ff9d`.

Contract `DEEPEYE-HUMAN-LOCK-20261014/revision1`, H01-H15 requirements canonical
SHA256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`
was recomputed and matched. `transfer.json` was active; assignment's four
explicit input hashes matched. `input-pins.json` binds those inputs, geometry,
saved delta-g, original adapter, reviewed runner/support and relevant installed
source identities. `runtime-pins.json` records the numerical runtime sources,
actual worker image and NumPy/SciPy BLAS DLL identities. This is not a claim of
complete OS or transitive runtime closure.

## Prepared implementation

`finite_coil_transfer.py` constructs W_B (2x36, m^2) from the actual floating
TensorMesh coordinates, verifies the full disks lie in their Fz prism and
retains normal +Z / one turn. The area-times-center identity follows from the
chosen bilinear basis and circular moments. It is not a physical small-coil
approximation. Original 48-boundary / 6-interior order, endpoints, tangents,
lengths and nominal lengths are checked against the saved geometry without
importing or running a physical boundary sampler.

The supplied-matrix interface reuses the original adapter and forms
H = P_B - P_I solve(A_II,A_IB), T = W_B C H. It uses one LU, a multi-column
solve, one SVD, no inverse/regularization/fallback, exact H[B,:]=identity,
normalized total/per-column backward residuals and the A[I,:]H check.
The extra-RHS application verifies linear reconstruction, T delta-g and the
conditional infinity-norm bound using sums of absolute product magnitudes.
The guard is fixed at 128 eps64 = 2.842170943040401e-14; kappa2 and kappa2*eta
are diagnostics rather than physical or rigorous forward-error certificates.

## New controls and preserved failures

The following are the only numerical control runs in this preparation.
All use the unchanged reviewed `r02-transient-quota-fix-20261021/win_job.py`
(SHA256 `80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d`).
The runner assigned each hidden below-normal launcher to its private job while
suspended, retained original member handles, granted the actual worker before
scientific imports and persisted its raw process terminals. Caps were 50 s,
4 processes, 384 MiB/process, 512 MiB/job, 128 KiB/stream, 16 MiB/256 tree
entries and 512 MiB free reserve. NumPy and SciPy DLL getters read BLAS=1
before and after controls. No old full48, adapter or runner suite was rerun.

| Stage | Outer/worker exit | Evidence |
|---|---:|---|
| red-01 | 1 | Missing optional threadpoolctl before tests. Preserved; no install. |
| red-02 | 1 | Expected new implementation absent. Existing DLL getter used instead. |
| green-01 | 0 | Three new functional control groups passed. |
| green-02 | 0 | Only new future-entry refusal/syntax control ran; prior passed controls were not repeated. |

Each stage has `started.json`, raw `stdout.txt`/`stderr.txt`, `hello.json`,
`grant.json`, `terminal.json`, post-terminal `input-readback.json`, and a
separate pre-run source hash snapshot. All three observed original processes
in every stage were signaled; active processes were zero at final readback.
Original console processes with exit 0 are distinguished from failed workers.
No original failed/interrupted directory or status was overwritten or replayed.
The first stdlib metadata seal also exited 1 because isolated Python omitted
the script directory from imports. `seal-01-failure.json` preserves that cause;
the local import path was made explicit. No numerical control was repeated.

Green functional evidence covers:

- Independent 2 r^2 Gauss nodes x 8 angles per disk using installed compiled
  `get_interpolation_matrix(...,"Fz",zeros_outside=False)`: all 36 columns
  agree with analytic W_B within the frozen arithmetic guard; maximum raw
  difference 5.421010862427522e-20 m^2. Row sums, zero Fx/Fy blocks, support,
  constant complex Bz, complex affine Bz and xy disk moments also passed.
- Noncontiguous I=[0,2], B=[1,3] hand matrix: literal H and complex T oracle
  were independently checked with built-in scalar complex sums. The resulting
  T was `[[-7+2i,-7],[1+2i,2+3i]]`. Two different fixed b vectors with the same
  two complex g vectors gave the prescribed difference and linear field
  reconstruction. This abstract example is not a Maxwell/receiver model.
- Shape/order/nonfinite/singular refusals, explicit g shape without broadcast,
  zero-scale exact-zero behavior, and unsupported receiver geometry refusal.
- Unselected future draft refused before any SimPEG import; all new Python
  files passed syntax-only compilation without emitting pycache.

No actual SimPEG call, Maxwell A assembly, metric C construction, source,
fields/model/source-RHS/sampler/reference calculation or full48 physical
transfer run occurred. The only computed T is the abstract 2x2 oracle case.
All writes were confined to this assignment directory; no UI/board/service,
provider/credential change, download, install, group or peer action occurred.

## Future entry, still unselected

`future-selection.draft.json` has `selected=false`. A responsible main must
independently review these exact bytes, copy/select a fresh record with a new
work_id, run_id, explicit output directory, exact new assignment ownership,
review hash and current-director identity. No such selection was created here.
The prepared command is:

```
.local/deepeye-fdem-validation-20261020/Scripts/python.exe -I -S -B -X utf8 <this-preparation>/run_future.py --selection <new-main-selection.json>
```

The stdlib runner verifies input/runtime/code/design pins and exact new output
ownership, then uses the unchanged private-job runner and held-worker grant.
The scientific driver is imported only by the granted selected worker. It
prepares one frequency/material, one actual getA, one metric C construction,
one 6x6 LU, 48+1 solved columns, one 6x6 SVD and 32 interpolation points.
It guards source-qualified call sites and rejects extra/forbidden scientific
entries or shapes. It persists canonical A/C CSR arrays, A_II/A_IB/H/W_B/T,
delta-g/delta-E/delta-V, conditions/residuals, counters, original warnings,
pre/post BLAS identity, process terminals and post-terminal input hashes.
Future numerical path is prepared code, not executed evidence in this job.

G03, R03, H12, old18 and all29 remain `not_run`. Receiver 5e-11 V qualification,
boundary 1e-11 V allocation, source equivalence, mesh/domain convergence,
continuous finite-coil accuracy, material validity and absolute received
voltages remain unresolved. The cancelled prior reviewer remains cancelled;
its retained design/data audit and main's 4165-pin adoption are reused only as
the exact supplied inputs. Main acceptance is pending.
