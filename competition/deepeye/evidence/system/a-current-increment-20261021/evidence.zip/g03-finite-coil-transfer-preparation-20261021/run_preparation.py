"""Stdlib launcher. Reuse reviewed job runner without changing its limits/code."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
SUPPORT = D.parent / "r02-transient-quota-fix-20261021"
CONTRACT = "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(p, value):
    with p.open("x", encoding="utf-8") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write("\n")


def verify_inputs():
    assignment = json.loads((D / "assignment.json").read_text(encoding="utf-8"))
    pins = dict(assignment["inputs"])
    for path, expected in pins.items():
        assert digest(ROOT / path) == expected, path
    scope_path = ROOT / "docs/competition/deepeye-2026/immutable_scope.json"
    scope = json.loads(scope_path.read_text(encoding="utf-8"))
    canonical = json.dumps(scope["requirements"], sort_keys=True,
                           ensure_ascii=False, separators=(",", ":")).encode()
    assert hashlib.sha256(canonical).hexdigest() == CONTRACT
    assert [r["id"] for r in scope["requirements"]] == [f"H{i:02}" for i in range(1, 16)]
    transfer_path = ROOT / ".planning/deepeye-desktop-handoff-20261015/transfer.json"
    transfer = json.loads(transfer_path.read_text(encoding="utf-8"))
    assert transfer["status"] == "active" and transfer["director_generation"] == 2
    assert transfer["new_director_thread_id"] == assignment["director_thread"]
    review = D.parent / "g03-full48-postrun-review-20261021"
    evidence = json.loads((review / "source-evidence.json").read_text(encoding="utf-8"))
    # Reuse the reviewed identities; no old numerical tests are rerun.
    for row in evidence["sources"]:
        if row["purpose"].startswith(("Fz tensor", "Face component", "nD linear", "First-index", "Compiled interpolation", "Metric curl", "Optional survey", "Fixed primary")):
            assert digest(ROOT / row["repo_path"]) == row["sha256"], row["repo_path"]
            pins[row["repo_path"]] = row["sha256"]
    delta = review / "data-audit-v1/delta-g-full48.npy"
    assert digest(delta) == "d115ed63e83f7edb88d66e3613366268403efb09c797edb3d3d16aed4c363ff1"
    more = [scope_path, ROOT / "docs/competition/deepeye-2026/immutable_scope.md",
            transfer_path, D / "assignment.json", SUPPORT / "boundary.py",
            review / "source-evidence.json", delta,
            D.parent / "g03-boundary-sampler-controls-20261020/geometry.npz",
            ROOT / ".local/deepeye-fdem-validation-20261020/Scripts/python.exe",
            ROOT / ".local/deepeye-fdem-validation-20261020/pyvenv.cfg"]
    for p in more:
        pins[p.relative_to(ROOT).as_posix()] = digest(p)
    return {"requirements_sha256": CONTRACT, "pins": dict(sorted(pins.items())),
            "scope": "exact used inputs and reviewed source identities; not full OS/runtime closure"}


def main():
    label = sys.argv[1]
    assert re.fullmatch(r"(?:red|green)-\d\d", label)
    before = verify_inputs()
    if not (D / "input-pins.json").exists():
        save(D / "input-pins.json", before)
    else:
        assert json.loads((D / "input-pins.json").read_text(encoding="utf-8")) == before
    assert digest(SUPPORT / "win_job.py") == "80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d"
    sys.path.insert(0, str(SUPPORT))
    from win_job import run_bounded, process_identity
    stage = D / label
    save(D / (label + "-source-pins.json"), {
        p.name: digest(p) for p in sorted(D.glob("*.py"))})
    env = {"SYSTEMROOT": os.environ["SYSTEMROOT"],
           "WINDIR": os.environ.get("WINDIR", os.environ["SYSTEMROOT"]),
           "PATH": "", "TEMP": str(D), "TMP": str(D), "TMPDIR": str(D),
           "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1", "PYTHONIOENCODING": "utf-8",
           **{k: "1" for k in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS",
                                "BLIS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")}}
    budget = {"seconds": 50, "active_processes": 4,
              "process_memory_bytes": 384 * 1024**2, "job_memory_bytes": 512 * 1024**2,
              "stdout_bytes": 128 * 1024, "stderr_bytes": 128 * 1024,
              "tree_bytes": 16 * 1024**2, "tree_entries": 256,
              "free_reserve_bytes": 512 * 1024**2}
    granted = False

    def on_tick(job, pids):
        nonlocal granted
        hello = stage / "hello.json"
        if hello.exists() and not granted:
            request = json.loads(hello.read_text(encoding="utf-8"))
            assert request["pid"] in pids
            identity = process_identity(request["pid"], job)
            save(stage / "grant.json", {"worker": identity, "scientific_import_allowed": True,
                                       "scope": "manufactured_only"})
            granted = True

    result = run_bounded([
        str(ROOT / ".local/deepeye-fdem-validation-20261020/Scripts/python.exe"),
        "-I", "-B", "-X", "utf8", str(D / "manufactured_controls.py"), str(stage),
        *(sys.argv[2:] if len(sys.argv)>2 else [])],
        env, D, stage, budget, [D], on_tick=on_tick)
    after = verify_inputs()
    save(stage / "input-readback.json", {"unchanged": before == after, **after})
    assert before == after
    assert result["all_processes_terminated"], "unresolved original handles: no replay"
    print(json.dumps({k: result.get(k) for k in (
        "status", "exit_code", "all_processes_terminated", "held_members", "stop_reason", "seconds")}))
    raise SystemExit(result["exit_code"] if result["exit_code"] is not None else 125)


if __name__ == "__main__":
    main()
