"""Future-only runner, reusing the reviewed win_job.py unchanged.

No actual model run is selected or invoked by the preparation task.
"""
import json
import os
from pathlib import Path
import sys
import time

D=Path(__file__).resolve().parent
ROOT=D.parents[2]
sys.path.insert(0,str(D))
from fixed_transfer_driver import load,sha,save,validate_selection


def worker(selection_path,output):
    selection=load(selection_path)
    validate_selection(selection)  # stdlib only
    output=Path(output)
    save(output/"hello.json",{"pid":os.getpid(),"before_scientific_import":True,
                              "selection_sha256":sha(selection_path)})
    deadline=time.monotonic()+5
    while not (output/"grant.json").exists():
        if time.monotonic()>deadline:raise RuntimeError("no science grant")
        time.sleep(.01)
    from fixed_transfer_driver import run_selected
    run_selected(selection_path,output)


def main(selection_path):
    s=load(selection_path);design=validate_selection(s)
    from run_preparation import verify_inputs
    before=verify_inputs()
    if before!=load(D/"input-pins.json"):raise RuntimeError("original inputs changed")
    output=Path(s["output_directory"]).resolve()
    if output.exists():raise RuntimeError("existing attempt: no replay")
    assignment=load(ROOT/s["assignment_repo_path"])
    if sha(ROOT/s["assignment_repo_path"])!=s["assignment_sha256"] or assignment["work_id"]!=s["new_work_id"]:
        raise RuntimeError("new task assignment binding mismatch")
    if output.relative_to(ROOT).as_posix() not in assignment["ownership"]:
        raise RuntimeError("new exact output ownership missing")
    support=D.parent/"r02-transient-quota-fix-20261021"
    if sha(support/"win_job.py")!="80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d":
        raise RuntimeError("reviewed runner changed")
    sys.path.insert(0,str(support))
    from win_job import run_bounded,process_identity
    env={"SYSTEMROOT":os.environ["SYSTEMROOT"],"WINDIR":os.environ.get("WINDIR",os.environ["SYSTEMROOT"]),
         "PATH":"","TEMP":str(output),"TMP":str(output),"TMPDIR":str(output),
         "PYTHONDONTWRITEBYTECODE":"1","PYTHONNOUSERSITE":"1","PYTHONIOENCODING":"utf-8",
         **{k:"1" for k in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS",
                            "BLIS_NUM_THREADS","VECLIB_MAXIMUM_THREADS","NUMEXPR_NUM_THREADS")}}
    granted=False
    def tick(job,pids):
        nonlocal granted
        if not granted and (output/"hello.json").exists():
            hello=load(output/"hello.json")
            if hello["pid"] not in pids or hello["selection_sha256"]!=sha(selection_path):
                raise RuntimeError("worker identity mismatch")
            identity=process_identity(hello["pid"],job)
            save(output/"grant.json",{"worker":identity,"selection_sha256":sha(selection_path),
                                      "scope":"main_selected_fixed_transfer","scientific_import_allowed":True})
            granted=True
    budget={k:v for k,v in design["budget"].items() if k!="cooperative_seconds"}
    terminal=run_bounded([str(ROOT/".local/deepeye-fdem-validation-20261020/Scripts/python.exe"),
                         "-I","-B","-X","utf8",str(D/"run_future.py"),"--worker",str(selection_path),str(output)],
                         env,ROOT,output,budget,[output],on_tick=tick)
    after=verify_inputs()
    save(output/"input-readback.json",{"unchanged":before==after,**after})
    save(output/"output-manifest.json",{"files":{
        p.name:{"sha256":sha(p),"bytes":p.stat().st_size} for p in sorted(output.iterdir()) if p.is_file()}})
    assert before==after
    assert terminal["all_processes_terminated"],"unresolved held process: no replay"
    print(json.dumps(terminal))
    raise SystemExit(terminal["exit_code"] if terminal["exit_code"] is not None else 125)


if __name__=="__main__":
    if len(sys.argv)==3 and sys.argv[1]=="--selection":
        main(Path(sys.argv[2]).resolve())
    elif len(sys.argv)==4 and sys.argv[1]=="--worker":
        worker(Path(sys.argv[2]).resolve(),sys.argv[3])
    else:
        raise SystemExit("Usage: run_future.py --selection <new-main-selection.json>")
