"""Pure finite-basis disk functional and conditional linear transfer.

No SimPEG, source, fields, solver selection, regularization, explicit inverse,
or physical accuracy claim. All complex products are forward (no conjugation).
"""
from dataclasses import dataclass
import math
import warnings

import numpy as np
from scipy import linalg, sparse

EPS_GATE = 128 * np.finfo(np.float64).eps
BOUNDARY = np.array([0,1,2,3,4,5,6,7,10,11,12,13,14,15,16,17,18,19,20,21,22,23,
                     24,26,27,29,30,31,32,33,34,35,36,37,38,39,41,42,43,44,45,
                     46,47,48,50,51,52,53], dtype=np.int64)
INTERIOR = np.array([8,9,25,28,40,49], dtype=np.int64)


def finite(value, name):
    a = np.asarray(value)
    if a.dtype.kind not in "iufc":
        raise TypeError(f"{name}: numeric array required")
    if not np.all(np.isfinite(a)):
        raise ValueError(f"{name}: nonfinite values")
    return a


def compare_scaled(actual, expected, scale):
    a, b, s = finite(actual, "actual"), finite(expected, "expected"), finite(scale, "scale")
    if a.shape != b.shape or s.shape != a.shape or np.any(s < 0):
        raise ValueError("comparison shape or scale mismatch")
    with np.errstate(over="raise", invalid="raise"):
        if not np.all(np.abs(a-b) <= EPS_GATE*s):
            raise ArithmeticError("128eps64 scale-normalized comparison failed")


def _fixed_mesh(mesh):
    if mesh.dim != 3 or mesh.reference_system != "cartesian" or not np.array_equal(mesh.orientation, np.eye(3)):
        raise ValueError("unrotated Cartesian 3D mesh required")
    if (mesh.n_cells, mesh.n_edges, mesh.n_faces) != (8,54,36):
        raise ValueError("fixed 8-cell/54-edge/36-face geometry required")
    if not np.array_equal(mesh.origin, [-.6,-.6,-.85]) or any(
            not np.array_equal(h, [.6,.6]) for h in mesh.h):
        raise ValueError("fixed widths/origin required")
    for axis in (mesh.cell_centers_x, mesh.cell_centers_y, mesh.nodes_z):
        finite(axis, "interpolation axis")
        if np.any(np.diff(axis) <= 0):
            raise ValueError("nonincreasing interpolation coordinates")


def bind_geometry(mesh, adapter, saved_geometry):
    """Check exact binary coordinates and original order, without sampler calls."""
    _fixed_mesh(mesh)
    mask = adapter.tangential_boundary_mask(mesh)
    if not np.array_equal(np.flatnonzero(mask), BOUNDARY) or not np.array_equal(np.flatnonzero(~mask), INTERIOR):
        raise ValueError("original boundary/interior ordering changed")
    nodes = (mesh.nodes_x, mesh.nodes_y, mesh.nodes_z)
    starts, ends = np.empty((48,3)), np.empty((48,3))
    offset = 0
    for axis, shape in enumerate((mesh.shape_edges_x, mesh.shape_edges_y, mesh.shape_edges_z)):
        count = math.prod(shape)
        take = (BOUNDARY >= offset) & (BOUNDARY < offset+count)
        subs = np.unravel_index(BOUNDARY[take]-offset, shape, order="F")
        for d in range(3):
            starts[take,d] = nodes[d][subs[d]]
            ends[take,d] = nodes[d][subs[d]+(d == axis)]
        offset += count
    delta = ends-starts
    lengths = np.linalg.norm(delta, axis=1)
    actual = {"indices": BOUNDARY, "starts": starts, "ends": ends,
              "tangents": delta/lengths[:,None], "lengths": lengths,
              "nominal_lengths": mesh.edge_lengths[BOUNDARY]}
    with np.load(saved_geometry, allow_pickle=False) as prior:
        if set(prior.files) != set(actual):
            raise ValueError("saved geometry keys changed")
        for key, value in actual.items():
            if not np.array_equal(value, prior[key]):
                raise ValueError(f"saved binary geometry/order differs: {key}")
    return mask


def finite_disk_rows(mesh, centers=((0.,0.,.05),(0.,0.,.25)), radius=.02):
    """Integrate Fz bilinear basis over the complete +Z one-turn disks.

    The area-times-center identity is exact for this selected finite basis,
    not a small-physical-coil approximation. Retain actual binary coordinates.
    """
    _fixed_mesh(mesh)
    centers = finite(centers, "centers")
    if centers.shape != (2,3) or not np.array_equal(centers, [[0,0,.05],[0,0,.25]]):
        raise ValueError("only the two fixed receiver centers are supported")
    if not math.isfinite(radius) or radius != .02:
        raise ValueError("fixed finite positive radius .02 m required")
    x, y, z = mesh.cell_centers_x, mesh.cell_centers_y, mesh.nodes_z
    W = np.zeros((2,36), dtype=np.float64)
    area = math.pi*radius**2
    for row, (cx,cy,cz) in enumerate(centers):
        if not (x[0] <= cx-radius and cx+radius <= x[1] and
                y[0] <= cy-radius and cy+radius <= y[1] and z[1] <= cz <= z[2]):
            raise ValueError("entire disk must lie within the fixed Fz interpolation prism")
        tx, ty, tz = (cx-x[0])/(x[1]-x[0]), (cy-y[0])/(y[1]-y[0]), (cz-z[1])/(z[2]-z[1])
        for i in range(2):
            for j in range(2):
                for k in range(2):
                    W[row,24+i+2*j+4*(k+1)] = area*((1-tx,tx)[i])*((1-ty,ty)[j])*((1-tz,tz)[k])
    return finite(W, "W_B")


def residual(A, X, rhs):
    """Backward residual for A X = rhs; zero denominator requires exact zero."""
    with np.errstate(over="raise", invalid="raise"):
        R = finite(A@X-rhs, "residual")
        normA = float(np.linalg.norm(A, np.inf))
        denominator = normA*float(np.linalg.norm(X, np.inf)) + float(np.linalg.norm(rhs, np.inf))
        numerator = float(np.linalg.norm(R, np.inf))
        eta = numerator/denominator if denominator else (0. if numerator == 0 else math.inf)
        columns = []
        for c in range(X.shape[1]):
            den = normA*float(np.max(np.abs(X[:,c]))) + float(np.max(np.abs(rhs[:,c])))
            num = float(np.max(np.abs(R[:,c])))
            columns.append(num/den if den else (0. if num == 0 else math.inf))
        if not math.isfinite(eta) or eta > EPS_GATE or any(not math.isfinite(v) or v > EPS_GATE for v in columns):
            raise ArithmeticError("backward residual exceeds frozen 128eps64 guard")
        return {"eta_total": eta, "eta_per_column": columns, "residual_inf": numerator,
                "denominator": denominator}


@dataclass
class Transfer:
    A: object
    C: object
    W: np.ndarray
    B: np.ndarray
    I: np.ndarray
    lu: tuple
    H: np.ndarray
    T: np.ndarray
    AII: np.ndarray
    AIB: np.ndarray
    adapter: object
    diagnostics: dict

    def response(self, b, g):
        b, g = finite(b, "b"), finite(g, "g")
        if b.shape != (self.A.shape[0],) or g.shape != (len(self.B),):
            raise ValueError("response requires explicit b[n] and g[n_B]")
        mask = np.zeros(self.A.shape[0], dtype=bool); mask[self.B] = True
        reduction = self.adapter.eliminate(self.A, b, mask, g)
        x = linalg.lu_solve(self.lu, reduction.rhs, check_finite=True)
        finite(x, "interior response")
        residual(self.AII, x[:,None], reduction.rhs[:,None])
        return reduction.reconstruct(x)

    def apply_delta(self, delta_g):
        dg = finite(delta_g, "delta_g")
        if dg.shape != (len(self.B),):
            raise ValueError("delta_g shape mismatch; no broadcast")
        with np.errstate(over="raise", invalid="raise"):
            rhs = finite(-self.AIB@dg, "delta rhs")
            x = finite(linalg.lu_solve(self.lu, rhs), "delta interior")
            extra_residual = residual(self.AII, x[:,None], rhs[:,None])
            field = np.empty(self.A.shape[0], dtype=complex)
            field[self.B], field[self.I] = dg, x
            linear = finite(self.H@dg, "linear delta E")
            compare_scaled(field, linear, np.abs(field)+np.abs(self.H)@np.abs(dg))
            direct = finite(self.W@(self.C@field), "direct delta V")
            mapped = finite(self.T@dg, "mapped delta V")
            scale = np.abs(self.W)@(abs(self.C)@np.abs(field)) + np.abs(self.T)@np.abs(dg)
            compare_scaled(direct, mapped, np.asarray(scale))
            gamma = float(np.max(np.sum(np.abs(self.T), axis=1)))
            bound = gamma*float(np.max(np.abs(dg)))
            lhs = float(np.max(np.abs(mapped)))
            if not math.isfinite(bound) or lhs > bound + EPS_GATE*(bound+float(np.max(np.abs(self.T)@np.abs(dg)))):
                raise ArithmeticError("conditional infinity bound arithmetic check failed")
        return {"delta_E": field, "delta_V": mapped, "direct_delta_V": direct,
                "gamma_inf_m": gamma, "bound_V": bound, "lhs_V": lhs,
                "extra_rhs_residual": extra_residual}


def build_transfer(A, C, W, boundary, interior, adapter):
    """One LU + batched solve + SVD. Inputs are supplied; never assembles A/C."""
    if not sparse.isspmatrix(A) or A.shape[0] != A.shape[1] or not 2 <= A.shape[0] <= 54:
        raise ValueError("bounded square sparse A required")
    finite(A.data, "A")
    A = A.tocsr(copy=True).astype(np.complex128)
    C = C.tocsr(copy=True) if sparse.issparse(C) else finite(C, "C").copy()
    finite(C.data if sparse.issparse(C) else C, "C")
    W = finite(W, "W").copy()
    if len(C.shape) != 2 or C.shape[1] != A.shape[0] or not 1 <= C.shape[0] <= 36:
        raise ValueError("C shape mismatch")
    if W.ndim != 2 or W.shape[1] != C.shape[0] or not 1 <= W.shape[0] <= 2:
        raise ValueError("W shape mismatch")
    B, I = np.asarray(boundary), np.asarray(interior)
    for name, indices in (("boundary",B), ("interior",I)):
        if indices.ndim != 1 or indices.dtype.kind not in "iu" or not len(indices) or np.any(np.diff(indices.astype(np.int64)) <= 0):
            raise ValueError(f"{name}: nonempty sorted integer order required")
    if not np.array_equal(np.sort(np.concatenate((B,I))), np.arange(A.shape[0])):
        raise ValueError("boundary/interior must be a disjoint complete partition")
    mask = np.zeros(A.shape[0], dtype=bool); mask[B] = True
    reduction = adapter.eliminate(A, np.zeros((A.shape[0],len(B))), mask, np.eye(len(B)))
    AII, AIB = reduction.matrix.toarray(), A[I,:][:,B].toarray()
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", linalg.LinAlgWarning)
            lu = linalg.lu_factor(AII.copy(), check_finite=True)
        singular_values = finite(linalg.svdvals(AII), "singular_values")
        if singular_values[-1] == 0:
            raise ArithmeticError("singular A_II")
        X = finite(linalg.lu_solve(lu, reduction.rhs, check_finite=True), "H interior")
    except (linalg.LinAlgWarning, linalg.LinAlgError, ValueError) as e:
        raise ArithmeticError("singular or failed factorization/solve; no fallback") from e
    diag = residual(AII, X, -AIB)
    H = finite(reduction.reconstruct(X), "H")
    if not np.array_equal(H[B,:], np.eye(len(B))):
        raise ArithmeticError("H boundary is not exactly identity")
    interior_rows = A[I,:].toarray()
    compare_scaled(interior_rows@H, np.zeros((len(I),len(B)), dtype=complex), np.abs(interior_rows)@np.abs(H))
    T = finite(W@(C@H), "T")
    kappa = float(singular_values[0]/singular_values[-1])
    if not math.isfinite(kappa):
        raise ArithmeticError("nonfinite conditioning diagnostic")
    diag.update({"singular_values": singular_values.tolist(), "kappa_2": kappa,
                 "kappa_times_eta": kappa*diag["eta_total"], "gate": EPS_GATE,
                 "LU_factorizations": 1, "batched_solved_columns": len(B), "SVDs": 1,
                 "conditioning_is_diagnostic_only": True})
    return Transfer(A,C,W,B.copy(),I.copy(),lu,H,T,AII,AIB,adapter,diag)
