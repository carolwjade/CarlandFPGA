"""Stdlib-only bounded local metadata; never import scientific packages."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import sys

D=Path(__file__).resolve().parent;ROOT=D.parents[2]
sys.path.insert(0,str(D))


def read(p):return json.loads(p.read_text(encoding="utf-8"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open("x",encoding="utf-8") as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write("\n")


def draft():
    result=read(D/"green-01/control-result.json")
    grant=read(D/"green-01/grant.json")
    runtime_paths=[Path(r["path"]) for r in result["blas_after"]]+[Path(grant["worker"]["image"])]
    site=ROOT/".local/deepeye-fdem-validation-20261020/Lib/site-packages"
    runtime_paths += [site/p for p in ("numpy/__init__.py","scipy/__init__.py","discretize/__init__.py",
                     "scipy/linalg/_decomp_lu.py","scipy/linalg/_decomp_svd.py")]
    save(D/"runtime-pins.json",{"pins":{str(p.resolve()):sha(p) for p in runtime_paths},
                              "scope":"Python worker image, used numerical entry sources and BLAS DLLs; other reviewed identities in input-pins.json; not full OS closure"})
    design=read(D/"design.json")
    code_names=("finite_coil_transfer.py","fixed_transfer_driver.py","run_future.py","run_preparation.py","manufactured_controls.py")
    save(D/"future-selection.draft.json",{
        "schema":1,"selected":False,"selected_by":None,"director_generation":2,
        "task_id":"DEEPEYE-IMPLEMENTATION-20261014","task_version":1,"new_work_id":None,"run_id":None,
        "output_directory":None,"assignment_repo_path":None,"assignment_sha256":None,
        "independent_review":{"approved":False,"repo_path":None,"sha256":None},
        "requirements_sha256":design["requirements_sha256"],"design_sha256":sha(D/"design.json"),
        "input_pins_sha256":sha(D/"input-pins.json"),"runtime_pins_sha256":sha(D/"runtime-pins.json"),
        "prepared_code_sha256":{n:sha(D/n) for n in code_names},
        "future_work":design["future_work"],"budget":design["budget"],
        "note":"Inert draft. Main must independently review, copy into a fresh owned assignment/run, bind exact review/assignment and select explicitly. No actual run authorized by this preparation.",
        "command":".local/deepeye-fdem-validation-20261020/Scripts/python.exe -I -S -B -X utf8 <this-preparation>/run_future.py --selection <new-main-selection.json>"})


def seal():
    from run_preparation import verify_inputs
    for p in D.glob("*.py"):
        compile(p.read_text(encoding="utf-8"),str(p),"exec")
    pins=verify_inputs();assert pins==read(D/"input-pins.json")
    stages=[]
    for label in ("red-01","red-02","green-01","green-02"):
        t=read(D/label/"terminal.json")
        assert t["all_processes_terminated"] and t["active_processes_final"]==0
        assert t["held_members"] and all(p["signaled"] and p["wait_result"]==0 for p in t["held_members"])
        stages.append({"run":label,"exit_code":t["exit_code"],"status":t["status"],
                       "seconds":t["seconds"],"held_members":t["held_members"],
                       "raw_terminal_sha256":sha(D/label/"terminal.json")})
    assert stages[0]["exit_code"]==1 and stages[1]["exit_code"]==1
    assert stages[2]["exit_code"]==0 and stages[3]["exit_code"]==0
    g1=read(D/"green-01/control-result.json");g2=read(D/"green-02/control-result.json")
    assert g1["success"] and g1["tests_run"]==3 and g2["success"] and g2["tests_run"]==1
    draft=read(D/"future-selection.draft.json")
    assert not draft["selected"]
    assert all(sha(D/n)==h for n,h in draft["prepared_code_sha256"].items())
    save(D/"result.json",{"utc":datetime.now(timezone.utc).isoformat(),
        "scope":"new finite-coil W_B / conditional transfer preparation and manufactured controls only",
        "requirements_sha256":pins["requirements_sha256"],"preparation_only":True,
        "controls_new":4,"actual_model_runs":0,"actual_SimPEG_calls":0,
        "actual_Maxwell_A_assemblies":0,"actual_metric_C_constructions":0,
        "future_selection":"unselected","independent_main_acceptance":"pending",
        "stages":stages,"status":read(D/"design.json")["status"],
        "input_pins_unchanged":True,"private_lease_excluded":True})
    files=[]
    for p in sorted(D.rglob("*")):
        if not p.is_file() or p.name in ("lease.private.json","reserve-request.json","native-owner.json","public-manifest.json","native-complete-response.json"):
            continue
        assert p.stat().st_size<=16*1024**2
        files.append({"path":p.relative_to(D).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p)})
    save(D/"public-manifest.json",{"files":files,"exclusions":["lease.private.json","reserve-request.json and native-owner.json (parent job bookkeeping)","public-manifest.json (self)","native-complete-response.json (post-seal controller receipt)"],
        "input_pins_sha256":sha(D/"input-pins.json"),"runtime_pins_sha256":sha(D/"runtime-pins.json")})
    print(json.dumps({"public_files":len(files),"new_controls":4,"all_owned_processes_signaled":True,
                      "actual_model_runs":0,"result_sha256":sha(D/"result.json")}))


if __name__=="__main__":
    if sys.argv[1]=="draft":draft()
    elif sys.argv[1]=="seal":seal()
    else:raise SystemExit("draft or seal required")
