"""New functional controls only; no SimPEG, Maxwell assembly or source evaluation."""
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import time
import unittest

D = Path(__file__).resolve().parent
stage = Path(sys.argv[1])
with (stage / "hello.json").open("x", encoding="utf-8") as f:
    json.dump({"pid": os.getpid(), "before_scientific_import": True}, f)
deadline = time.monotonic() + 5
while not (stage / "grant.json").exists():
    if time.monotonic() > deadline:
        raise RuntimeError("no scientific-import grant")
    time.sleep(.01)
grant = json.loads((stage / "grant.json").read_text(encoding="utf-8"))
assert grant["worker"]["pid"] == os.getpid() and grant["scope"] == "manufactured_only"


def audit(event, args):
    if event == "import" and args[0].split(".")[0] == "simpeg":
        raise RuntimeError("SimPEG is forbidden during preparation")


sys.addaudithook(audit)
import numpy as np
from scipy import sparse
from discretize import TensorMesh
import ctypes


def threads():
    # Same installed NumPy/SciPy DLL getters as the previously reviewed common.py.
    import hashlib
    import scipy.linalg
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetModuleHandleW.argtypes = [ctypes.c_wchar_p]
    kernel.GetModuleHandleW.restype = ctypes.c_void_p
    site = Path(np.__file__).resolve().parents[1]
    rows = []
    for folder, symbol in (("numpy.libs", "scipy_openblas_get_num_threads64_"),
                           ("scipy.libs", "scipy_openblas_get_num_threads")):
        paths = list((site / folder).glob("*openblas*.dll"))
        assert len(paths) == 1
        handle = kernel.GetModuleHandleW(str(paths[0])); assert handle
        lib = ctypes.CDLL(str(paths[0]), handle=handle)
        getter = getattr(lib, symbol); getter.argtypes = []; getter.restype = ctypes.c_int
        rows.append({"path": str(paths[0]), "sha256": hashlib.sha256(paths[0].read_bytes()).hexdigest(),
                     "getter": symbol, "num_threads": getter()})
    assert all(r["num_threads"] == 1 for r in rows)
    return rows


before_threads = threads()
sys.path.insert(0, str(D))
spec = importlib.util.spec_from_file_location("original_boundary_adapter", D.parent /
            "g03-prescribed-boundary-adapter-20261020/boundary_adapter.py")
adapter = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = adapter
spec.loader.exec_module(adapter)
api = None
metrics = {}


class Controls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        global api
        if not (D / "finite_coil_transfer.py").exists():
            raise AssertionError("new W_B/T implementation is absent (expected RED)")
        import finite_coil_transfer
        api = finite_coil_transfer

    def check_scaled(self, got, expected, scale):
        error = np.abs(np.asarray(got) - np.asarray(expected))
        scale = np.broadcast_to(scale, error.shape)
        self.assertTrue(np.all(error <= 128 * np.finfo(float).eps * scale),
                        str((error.max(), scale.max())))

    def test_complex_oracle_and_two_fixed_rhs(self):
        # Breaks on wrong sign, conjugation, contiguous ordering, b-dependence.
        A = sparse.csr_matrix([[2, 2, 0, 4], [0, 1, 0, 0], [0, 8, 4, 12], [0, 0, 0, 1]])
        I, B = np.array([0, 2]), np.array([1, 3])
        L = np.array([[1, 2j, 3, 4], [0, 1, -1j, 2]])
        Hwant = np.array([[-1, -2], [1, 0], [-2, -3], [0, 1]])
        Twant = np.array([[-7+2j, -7], [1+2j, 2+3j]])
        # Independent built-in complex arithmetic verifies the design literals.
        oracle = [[sum(complex(L[r, k]) * int(Hwant[k, c]) for k in range(4))
                   for c in range(2)] for r in range(2)]
        self.assertEqual(oracle, Twant.tolist())
        model = api.build_transfer(A, L, np.eye(2), B, I, adapter)
        np.testing.assert_array_equal(model.H, Hwant)
        np.testing.assert_array_equal(model.T, Twant)
        g1, g2 = np.array([1+2j, -3+.5j]), np.array([-.25-1j, 2+4j])
        dg = g2 - g1
        differences = []
        for b in (np.array([3+1j, 7j, -2+4j, 6]), np.array([-9+2j, -8, 13-7j, -5j])):
            outputs, fields = [], []
            for g in (g1, g2):
                field = model.response(b, g)
                # Independent explicit scalar elimination, never uses model H.
                want = np.array([(b[0]-2*g[0]-4*g[1])/2, g[0],
                                 (b[2]-8*g[0]-12*g[1])/4, g[1]])
                self.check_scaled(field, want, np.abs(want) + 1)
                fields.append(field)
                outputs.append(L @ field)
            difference = outputs[1] - outputs[0]
            self.check_scaled(difference, Twant @ dg,
                              np.abs(outputs[1]) + np.abs(outputs[0]) + np.abs(Twant) @ np.abs(dg))
            self.check_scaled(fields[1]-fields[0], model.H @ dg,
                              np.abs(fields[1])+np.abs(fields[0])+np.abs(model.H) @ np.abs(dg))
            differences.append(difference)
        self.check_scaled(differences[0], differences[1], np.abs(differences[0])+np.abs(differences[1]))
        control = model.apply_delta(dg)
        self.check_scaled(control["delta_V"], Twant @ dg, np.abs(Twant) @ np.abs(dg))
        self.assertLessEqual(model.diagnostics["eta_total"], 128*np.finfo(float).eps)
        metrics["complex_oracle"] = {"literal_T_verified_independently": True,
                                    "fixed_rhs_count": 2, "diagnostics": model.diagnostics}

    def test_finite_disk_independent_quadrature_and_moments(self):
        # Breaks on ideal-coordinate snapping, column offset, point-only area use.
        mesh = TensorMesh([[.6, .6], [.6, .6], [.6, .6]], origin=[-.6, -.6, -.85])
        api.bind_geometry(mesh, adapter, D.parent / "g03-boundary-sampler-controls-20261020/geometry.npz")
        W = api.finite_disk_rows(mesh)
        S = math.pi * .02**2
        self.assertEqual(W.shape, (2, 36))
        np.testing.assert_array_equal(W[:, :28], np.zeros((2, 28)))
        self.assertEqual(np.count_nonzero(W), 16)
        self.check_scaled(W.sum(axis=1), [S, S], S)
        # Quadrature uses installed compiled interpolation, no analytic-row helper.
        Q = []
        for z in (.05, .25):
            points = []
            for sign in (-1, 1):
                radius = math.sqrt(.02**2 * (1 + sign/math.sqrt(3))/2)
                for angle in range(8):
                    theta = 2*math.pi*angle/8
                    points.append([radius*math.cos(theta), radius*math.sin(theta), z])
            rows = mesh.get_interpolation_matrix(np.asarray(points), "Fz", zeros_outside=False)
            Q.append(np.asarray(rows.sum(axis=0)).ravel() * S/16)
        Q = np.asarray(Q)
        self.check_scaled(W, Q, np.abs(W)+np.abs(Q))
        xyz = mesh.faces_z
        for label, bz, want in (
            ("constant", np.full(12, 2-3j), np.full(2, S*(2-3j))),
            ("affine", (1+2j)+(3-4j)*xyz[:, 0]+(-2+1j)*xyz[:, 1]+(5+3j)*xyz[:, 2],
             S*((1+2j)+(5+3j)*np.array([.05, .25]))),
            ("xy", xyz[:, 0]*xyz[:, 1], np.zeros(2)),
        ):
            face = np.zeros(36, dtype=complex); face[24:] = bz
            self.check_scaled(W @ face, want, np.abs(W) @ np.abs(face)+np.abs(want))
        metrics["disk_functional"] = {"points_per_disk": 16, "quadrature_max_difference_m2": float(np.max(abs(W-Q))),
                                      "actual_x_centers": mesh.cell_centers_x.tolist(),
                                      "actual_y_centers": mesh.cell_centers_y.tolist(),
                                      "actual_z_nodes": mesh.nodes_z.tolist(),
                                      "W_B_m2": W.tolist(), "only_chosen_interpolant": True}

    def test_rejections_and_scale_zero(self):
        # Breaks on silent broadcast/order coercion/nonfinite/singular acceptance.
        A = sparse.csr_matrix([[2, 2, 0, 4], [0, 1, 0, 0], [0, 8, 4, 12], [0, 0, 0, 1]])
        C = np.array([[1, 2j, 3, 4], [0, 1, -1j, 2]])
        B, I = np.array([1, 3]), np.array([0, 2])
        for a, c, w, b, i in (
            (A, C[:, :3], np.eye(2), B, I),
            (A, C, np.ones((2, 1)), B, I),
            (A, C, np.eye(2), B[::-1], I),
            (A, C, np.eye(2), B, np.array([0, 1])),
            (A, C*np.nan, np.eye(2), B, I),
            (A, C, np.full((2,2), np.inf), B, I),
            (sparse.csr_matrix(np.eye(4)*np.nan), C, np.eye(2), B, I),
            (sparse.csr_matrix([[0,2,0,4],[0,1,0,0],[0,8,0,12],[0,0,0,1]]), C, np.eye(2), B, I),
        ):
            with self.assertRaises((TypeError, ValueError, ArithmeticError)):
                api.build_transfer(a, c, w, b, i, adapter)
        model = api.build_transfer(A, C, np.eye(2), B, I, adapter)
        for bad in (np.ones((2, 1)), np.array([1, np.nan])):
            with self.assertRaises((TypeError, ValueError)):
                model.apply_delta(bad)
        api.compare_scaled(np.zeros(2), np.zeros(2), np.zeros(2))
        with self.assertRaises(ArithmeticError):
            api.compare_scaled(np.array([1e-300]), np.zeros(1), np.zeros(1))
        mesh = TensorMesh([[.6, .6], [.6, .6], [.6, .6]], origin=[-.6, -.6, -.85])
        with self.assertRaises(ValueError):
            api.finite_disk_rows(mesh, centers=((.295,0,.05),(0,0,.25)))
        with self.assertRaises(ValueError):
            api.finite_disk_rows(mesh, radius=float("nan"))

    def test_future_entry_refuses_unselected_before_simpeg(self):
        # Breaks if an inert draft can reach any scientific model import/run.
        import fixed_transfer_driver as driver
        import run_future
        draft_path = D / "future-selection.draft.json"
        draft = json.loads(draft_path.read_text(encoding="utf-8"))
        with self.assertRaisesRegex(ValueError, "unselected"):
            driver.validate_selection(draft)
        with self.assertRaisesRegex(ValueError, "unselected"):
            run_future.main(draft_path)
        self.assertFalse(any(n == "simpeg" or n.startswith("simpeg.") for n in sys.modules))
        # Syntax-only compilation: no import, execution, getA or emitted pycache.
        for path in sorted(D.glob("*.py")):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        metrics["future_entry"] = {"draft_refused_before_simpeg": True,
                                    "new_actual_run": "unselected", "all_new_python_syntax_checked": True}


suite = (unittest.TestSuite([Controls("test_future_entry_refuses_unselected_before_simpeg")])
         if len(sys.argv)>2 and sys.argv[2]=="entries-only" else
         unittest.defaultTestLoader.loadTestsFromTestCase(Controls))
result = unittest.TextTestRunner(verbosity=2).run(suite)
after_threads = threads()
assert not any(name == "simpeg" or name.startswith("simpeg.") for name in sys.modules)
with (stage / "control-result.json").open("x", encoding="utf-8") as f:
    json.dump({"success": result.wasSuccessful(), "tests_run": result.testsRun,
               "failures": len(result.failures), "errors": len(result.errors),
               "blas_before": before_threads, "blas_after": after_threads,
               "actual_SimPEG_calls": 0, "actual_Maxwell_A_assemblies": 0,
               "actual_metric_C_constructions": 0, "metrics": metrics}, f, indent=2)
raise SystemExit(0 if result.wasSuccessful() else 1)
