"""Future diagnostic entry. Stdlib only until selected, assigned and granted.

This file has not assembled or solved an actual finite Maxwell model in this job.
Use run_future.py only after independent main review and a new recorded task.
"""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import sys
import time

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
DIRECTOR = "01a13d7e-dcf1-7272-a738-a637dd62ff9d"


def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, value):
    with Path(p).open("x", encoding="utf-8") as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.write("\n")


def validate_selection(s):
    if s.get("selected") is not True:
        raise ValueError("future model diagnostic remains unselected")
    if s.get("selected_by") != DIRECTOR or s.get("director_generation") != 2:
        raise ValueError("current director selection required")
    if s.get("task_id") != "DEEPEYE-IMPLEMENTATION-20261014" or s.get("task_version") != 1:
        raise ValueError("task identity mismatch")
    if not s.get("new_work_id") or s["new_work_id"] == "A-G03-finite-coil-transfer-preparation-20261021-v1":
        raise ValueError("separate actual-run assignment required")
    if not isinstance(s.get("run_id"), str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,79}", s["run_id"]):
        raise ValueError("fresh explicit run_id required")
    review = s.get("independent_review")
    if not isinstance(review, dict) or review.get("approved") is not True or not review.get("repo_path"):
        raise ValueError("main-approved independent review required")
    review_path = (ROOT / review["repo_path"]).resolve()
    if not review_path.is_relative_to(ROOT) or sha(review_path) != review.get("sha256"):
        raise ValueError("independent-review binding mismatch")
    if sha(D / "design.json") != s.get("design_sha256") or sha(D / "input-pins.json") != s.get("input_pins_sha256"):
        raise ValueError("frozen design/input manifest changed")
    if sha(D / "runtime-pins.json") != s.get("runtime_pins_sha256"):
        raise ValueError("runtime manifest changed")
    runtime = load(D / "runtime-pins.json")
    if any(sha(Path(name)) != value for name,value in runtime["pins"].items()):
        raise ValueError("bound runtime input changed")
    pins = s.get("prepared_code_sha256", {})
    expected_names = {"finite_coil_transfer.py", "fixed_transfer_driver.py", "run_future.py", "run_preparation.py", "manufactured_controls.py"}
    if set(pins) != expected_names or any(sha(D / name) != value for name,value in pins.items()):
        raise ValueError("prepared code binding mismatch")
    design = load(D / "design.json")
    if s.get("future_work") != design["future_work"] or s.get("budget") != design["budget"]:
        raise ValueError("future call/resource budget may not expand")
    if s.get("requirements_sha256") != design["requirements_sha256"]:
        raise ValueError("contract mismatch")
    if not s.get("output_directory"):
        raise ValueError("fresh explicit output directory required")
    output = Path(s["output_directory"]).resolve()
    if not output.is_relative_to(ROOT) or output in (ROOT,D) or output.is_relative_to(D):
        raise ValueError("new separately owned output directory required")
    return design


def actual_threads():
    import ctypes as ct
    import numpy as np
    import scipy.linalg
    k = ct.WinDLL("kernel32", use_last_error=True)
    k.GetModuleHandleW.argtypes, k.GetModuleHandleW.restype = [ct.c_wchar_p], ct.c_void_p
    site = Path(np.__file__).resolve().parents[1]
    rows = []
    for folder, symbol in (("numpy.libs", "scipy_openblas_get_num_threads64_"),
                           ("scipy.libs", "scipy_openblas_get_num_threads")):
        paths = list((site/folder).glob("*openblas*.dll")); assert len(paths) == 1
        handle = k.GetModuleHandleW(str(paths[0])); assert handle
        getter = getattr(ct.CDLL(str(paths[0]), handle=handle), symbol)
        getter.argtypes, getter.restype = [], ct.c_int
        count = getter(); assert count == 1
        rows.append({"path":str(paths[0]), "sha256":sha(paths[0]), "num_threads":count})
    return rows


def run_selected(selection_path, output):
    """Called once by an already suspended-assigned/held/granted private worker."""
    selection = load(selection_path)
    design = validate_selection(selection)  # no scientific imports before this gate
    output = Path(output).resolve()
    if output != Path(selection["output_directory"]).resolve():
        raise ValueError("output selection mismatch")
    grant = load(output / "grant.json")
    if grant["worker"]["pid"] != os.getpid() or grant.get("selection_sha256") != sha(selection_path):
        raise ValueError("worker identity/grant mismatch")
    if grant.get("scope") != "main_selected_fixed_transfer" or not grant.get("scientific_import_allowed"):
        raise ValueError("missing science grant")
    import numpy as np
    from scipy import sparse
    from discretize import TensorMesh
    import warnings
    sys.path.insert(0,str(D))
    import finite_coil_transfer as api
    before = actual_threads()
    started = time.monotonic()
    counts = {"A_assemblies":0,"metric_C_constructions":0,"LU_factorizations":0,
              "solved_columns":0,"SVDs":0,"interpolation_points":0,"source_calls":0,
              "RHS_calls":0,"fields_calls":0,"sampler_calls":0,"reference_calls":0}
    blocked, error, warning_records = [], None, []
    site = ROOT/".local/deepeye-fdem-validation-20261020/Lib/site-packages"
    simulation_file = (site/"simpeg/electromagnetics/frequency_domain/simulation.py").as_posix().casefold()
    curl_file = (site/"discretize/operators/differential_operators.py").as_posix().casefold()
    lu_file = (site/"scipy/linalg/_decomp_lu.py").as_posix().casefold()
    svd_file = (site/"scipy/linalg/_decomp_svd.py").as_posix().casefold()
    expected_A_code = None
    events = 0

    def profile(frame,event,arg):
        nonlocal events
        if event != "call": return
        events += 1
        if events % 1024 == 0 and time.monotonic()-started > 45:
            raise RuntimeError("cooperative 45s stop; no retry")
        name = frame.f_code.co_name
        if name not in ("getA","getRHS","getSourceTerm","fields","eval","__init__",
                        "edge_curl","lu_factor","lu_solve","svd","sample_boundary",
                        "_physical_electric","_physical_green_kernel","reference_edges","_physical_integrand"):
            return
        file = frame.f_code.co_filename.replace("\\","/").casefold()
        if file == simulation_file:
            if name == "getA":
                if frame.f_code is not expected_A_code or counts["A_assemblies"]:
                    raise RuntimeError("unexpected/repeated actual getA entry")
                counts["A_assemblies"] += 1
            elif name in ("getRHS","getSourceTerm","fields"):
                counts["RHS_calls" if name != "fields" else "fields_calls"] += 1
                blocked.append(file+":"+name); raise RuntimeError("forbidden FDEM entry")
        if file.endswith("/frequency_domain/sources.py") and name in ("eval","__init__"):
            counts["source_calls"] += 1
            blocked.append(file+":"+name); raise RuntimeError("source construction/evaluation forbidden")
        if file.endswith("boundary_sampler.py") and name in ("sample_boundary","_physical_electric","_physical_green_kernel"):
            counts["sampler_calls"] += 1; raise RuntimeError("sampler forbidden")
        if file.endswith(("centered_reference.py","independent_reference.py")) and name in ("reference_edges","_physical_integrand"):
            counts["reference_calls"] += 1; raise RuntimeError("reference forbidden")
        if file == curl_file and name == "edge_curl" and getattr(frame.f_locals["self"],"_edge_curl",None) is None:
            counts["metric_C_constructions"] += 1
            if counts["metric_C_constructions"] > 1: raise RuntimeError("repeated C construction")
        if file == lu_file and name == "lu_factor":
            counts["LU_factorizations"] += 1
            if counts["LU_factorizations"] > 1: raise RuntimeError("LU factorization budget")
        if file == lu_file and name == "lu_solve":
            b = frame.f_locals["b"]
            counts["solved_columns"] += 1 if b.ndim == 1 else b.shape[1]
            if counts["solved_columns"] > 49: raise RuntimeError("solved column budget")
        if file == svd_file and name == "svd":
            counts["SVDs"] += 1
            if counts["SVDs"] > 1: raise RuntimeError("SVD budget")

    sys.setprofile(profile)
    try:
        with warnings.catch_warnings(record=True) as warning_records:
            warnings.simplefilter("always")
            from simpeg.electromagnetics.frequency_domain.simulation import Simulation3DElectricField
            expected_A_code = Simulation3DElectricField.getA.__code__
            model = design["model"]
            mesh = TensorMesh(model["widths_m"],origin=model["origin_m"])
            adapter_path = D.parent/"g03-prescribed-boundary-adapter-20261020/boundary_adapter.py"
            spec = importlib.util.spec_from_file_location("fixed_transfer_original_adapter",adapter_path)
            adapter = importlib.util.module_from_spec(spec);sys.modules[spec.name]=adapter;spec.loader.exec_module(adapter)
            api.bind_geometry(mesh,adapter,D.parent/"g03-boundary-sampler-controls-20261020/geometry.npz")
            W = api.finite_disk_rows(mesh)
            # Independent 2 r^2 Gauss nodes x 8 angles/receiver, compiled interpolation.
            Q=[];area=math.pi*.02**2
            for z in (.05,.25):
                points=[]
                for sign in (-1,1):
                    r=math.sqrt(.02**2*(1+sign/math.sqrt(3))/2)
                    points.extend([[r*math.cos(2*math.pi*k/8),r*math.sin(2*math.pi*k/8),z] for k in range(8)])
                rows=mesh.get_interpolation_matrix(np.asarray(points),"Fz",zeros_outside=False)
                counts["interpolation_points"]+=len(points)
                Q.append(np.asarray(rows.sum(axis=0)).ravel()*area/16)
            Q=np.asarray(Q);api.compare_scaled(W,Q,np.abs(W)+np.abs(Q))
            sim=Simulation3DElectricField(mesh,survey=None,sigma=np.full(8,model["sigma_S_per_m"]),
                                         mu=np.full(8,model["mu_H_per_m"]),
                                         permittivity=np.full(8,model["epsilon_F_per_m"]))
            C=mesh.edge_curl.tocsr(copy=True)
            A=sim.getA(model["frequency_Hz"]).tocsr(copy=True)
            if A.shape!=(54,54) or A.nnz>2916 or C.shape!=(36,54) or C.nnz>144:
                raise ValueError("actual operator shape/storage expansion")
            result=api.build_transfer(A,C,W,api.BOUNDARY,api.INTERIOR,adapter)
            delta=np.load(D.parent/"g03-full48-postrun-review-20261021/data-audit-v1/delta-g-full48.npy",allow_pickle=False)
            if delta.shape!=(48,) or delta.dtype.str!="<c16": raise ValueError("pinned delta shape/type")
            application=result.apply_delta(delta)
            if counts!=design["future_work"]: raise RuntimeError("actual call counters do not match selected finite budget")
            arrays={"A_II":result.AII,"A_IB":result.AIB,"H":result.H,"W_B":W,"T":result.T,
                    "delta_g":delta,"delta_E":application["delta_E"],"delta_V":application["delta_V"],
                    "direct_delta_V":application["direct_delta_V"],"boundary_indices":api.BOUNDARY,"interior_indices":api.INTERIOR}
            for name,array in arrays.items():
                with (output/(name+".npy")).open("xb") as f:np.save(f,array,allow_pickle=False)
            for name,matrix in (("A",A),("C",C)):
                matrix.sum_duplicates();matrix.sort_indices()
                with (output/(name+"-canonical-csr.npz")).open("xb") as f:
                    np.savez(f,shape=np.asarray(matrix.shape,dtype="<i8"),data=matrix.data.astype("<c16"),
                             indices=matrix.indices.astype("<i8"),indptr=matrix.indptr.astype("<i8"))
            save(output/"conditional-result.json",{
                "kind":"conditional finite-model sensitivity only","diagnostics":result.diagnostics,
                "delta_V_complex_V":[[v.real,v.imag] for v in application["delta_V"]],
                "abs_delta_V_V":np.abs(application["delta_V"]).tolist(),
                **{k:application[k] for k in ("gamma_inf_m","bound_V","lhs_V","extra_rhs_residual")},
                "counts":counts,"status":design["status"],"absolute_voltage":"not_run"})
    except BaseException as exc:
        error={"type":type(exc).__name__,"message":str(exc)}
        raise
    finally:
        sys.setprofile(None)
        save(output/"execution.json",{"selection_sha256":sha(selection_path),"counts":counts,
             "blocked":blocked,"error":error,"warnings":[{"category":str(w.category.__name__),"text":str(w.message),
             "file":str(w.filename),"line":w.lineno} for w in warning_records],
             "blas_before":before,"blas_after":actual_threads(),"seconds":time.monotonic()-started})


if __name__ == "__main__":
    if len(sys.argv)==2 and sys.argv[1]=="--describe":
        print(json.dumps({"entry":"run_future.py --selection <new-main-selection.json>",
                          "selected":False,"future_work":load(D/"design.json")["future_work"]}))
    else:
        raise SystemExit("Import only through run_future.py after a fresh main selection and verified job grant.")
