"""Data-only wheel verification: bounded blocks, no extraction or vendor imports.

ZipFile parses only the bounded central directory. Payload inflation is explicit
so compressed tails, member-size lies and expansion bounds cannot be ignored.
"""
import base64
import csv
from email import policy
from email.parser import BytesParser
import hashlib
import io
from pathlib import Path, PurePosixPath
import re
import stat
import struct
import unicodedata
import zipfile
import zlib

BLOCK = 128 * 1024
TEXT_CAP = 8 * 1024**2
MAX_ENTRIES = 20000
CENTRAL_CAP = 16 * 1024**2

def require(ok, why):
    if not ok:
        raise AssertionError(why)

def file_pin(path):
    h, size = hashlib.sha256(), 0
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(BLOCK), b''):
            h.update(b)
            size += len(b)
    return {'bytes':size, 'sha256':h.hexdigest()}

def safe_name(name):
    require(isinstance(name,str) and name and not any(ord(c)<32 for c in name)
            and '\\' not in name and ':' not in name and not name.startswith('/'), 'unsafe archive path')
    p = PurePosixPath(name)
    require(p.as_posix()==name and all(x not in ('','.','..') for x in name.split('/')), 'noncanonical archive path')
    devices = {'con','prn','aux','nul'} | {f'{p}{n}' for p in ('com','lpt') for n in range(10)}
    require(all(not x.endswith(('.',' ')) and x.split('.')[0].casefold() not in devices for x in p.parts), 'Windows alias path')
    return unicodedata.normalize('NFC',name).casefold()

def extras(raw):
    result = {}
    while raw:
        require(len(raw)>=4, 'extra field header')
        tag,size = struct.unpack_from('<HH',raw)
        require(len(raw)>=4+size and tag not in result, 'extra field length/duplicate')
        result[tag],raw = raw[4:4+size],raw[4+size:]
    return result

def local_span(f, item, start_dir):
    offset = item.header_offset
    require(0<=offset<=start_dir-30, 'local header bounds')
    f.seek(offset)
    raw = f.read(30)
    require(len(raw)==30, 'local header truncated')
    sig,version,flags,method,tm,dt,crc,comp,size,nlen,xlen = struct.unpack('<4s5H3I2H',raw)
    require(sig==b'PK\x03\x04' and flags==item.flag_bits and method==item.compress_type, 'central/local flags/method')
    require(version==item.extract_version, 'central/local required version')
    name = f.read(nlen)
    extra = f.read(xlen)
    require(len(name)==nlen and len(extra)==xlen, 'local name/extra bounds')
    require(name.decode('utf-8' if flags&0x800 else 'cp437')==item.orig_filename==item.filename, 'central/local name')
    ex = extras(extra)
    zip64 = comp==0xffffffff or size==0xffffffff
    if zip64:
        require(1 in ex, 'local ZIP64 field missing')
        data = ex[1]
        for field in ('size','comp'):
            value = size if field=='size' else comp
            if value==0xffffffff:
                require(len(data)>=8, 'local ZIP64 truncated')
                value, = struct.unpack_from('<Q',data)
                data = data[8:]
                if field=='size': size=value
                else: comp=value
        require(not data, 'unexpected local ZIP64 value')
    else:
        require(1 not in ex, 'unneeded local ZIP64')
    if flags & 8:
        require(crc in (0,item.CRC) and comp in (0,item.compress_size) and size in (0,item.file_size), 'local descriptor placeholders')
    else:
        require((crc,comp,size)==(item.CRC,item.compress_size,item.file_size), 'central/local CRC/size')
    start = offset+30+nlen+xlen
    end = start+item.compress_size
    require(end<=start_dir, 'member overlaps central directory')
    if flags & 8:
        f.seek(end)
        first=f.read(4)
        signed=first==b'PK\x07\x08'
        if not signed: f.seek(end)
        desc=f.read(20 if zip64 else 12)
        require(len(desc)==(20 if zip64 else 12), 'descriptor truncated')
        values=struct.unpack('<IQQ' if zip64 else '<III',desc)
        require(values==(item.CRC,item.compress_size,item.file_size), 'central/descriptor CRC/size')
        end += (4 if signed else 0)+len(desc)
        require(end<=start_dir, 'descriptor overlaps central directory')
    return start,end,zip64

def verify_stream(path, expected, accepted_metadata):
    """Return hashes and sizes only; retain at most 3 bounded dist-info texts."""
    path=Path(path)
    require(path.stat().st_size < 1536*1024**2, 'compressed archive cap')
    require(type(accepted_metadata) is bytes and len(accepted_metadata)<=TEXT_CAP, 'accepted metadata cap')
    members, texts, keys, spans = {}, {}, set(), []
    zip64_count=0
    # Validate the declared central-directory allocation before ZipFile reads it.
    require(path.stat().st_size>=22, 'EOCD truncated')
    with path.open('rb') as f:
        f.seek(-22,2)
        eocd=f.read(22)
        sig,disk,cd_disk,on_disk,count,cd_size,cd_offset,comment=struct.unpack('<4s4H2IH',eocd)
        require(sig==b'PK\x05\x06' and disk==cd_disk==comment==0 and on_disk==count and 0<count<=MAX_ENTRIES, 'EOCD single disk/count/comment')
        require(cd_size<=CENTRAL_CAP and cd_offset+cd_size+22==path.stat().st_size, 'central directory bounds/no tail')
    with path.open('rb') as f, zipfile.ZipFile(f) as archive:
        infos=archive.infolist()
        require(0<len(infos)<=MAX_ENTRIES, 'ZIP entry count')
        require(not archive.comment, 'unexpected archive comment')
        total=sum(i.file_size for i in infos)
        require(total==expected['declared_expanded_bytes'] and total<=4*1024**3, 'ZIP expanded total')
        # The six pinned archives fit classic EOCD; local ZIP64 is admitted only
        # when an actual sentinel appears (e.g. force_zip64 output).
        require(count==len(infos), 'EOCD actual count')
        require(cd_size<=CENTRAL_CAP and cd_offset==archive.start_dir and cd_offset+cd_size+22==path.stat().st_size, 'central directory bounds/no tail')
        records=[i.filename for i in infos if i.filename.endswith('.dist-info/RECORD')]
        require(len(records)==1, 'one RECORD required')
        record=records[0]
        prefix=record[:-6]
        wanted={record,prefix+'METADATA',prefix+'WHEEL'}
        for item in infos:
            key=safe_name(item.filename)
            require(key not in keys, 'duplicate/case-colliding member')
            keys.add(key)
            require(not item.is_dir(), 'file-only wheel required')
            mode=item.external_attr>>16
            require(not stat.S_ISLNK(mode) and stat.S_IFMT(mode) in (0,stat.S_IFREG), 'ZIP nonregular/link')
            require(not item.flag_bits & ~0x80e and not item.flag_bits&1 and item.compress_type in (0,8), 'ZIP encryption/flags/method')
            require(item.file_size>=0 and item.compress_size>=0, 'negative member size')
            start,end,is64=local_span(f,item,archive.start_dir)
            zip64_count+=int(is64)
            spans.append((item.header_offset,end))
            capture=item.filename in wanted
            require(not capture or item.file_size<=TEXT_CAP, 'dist-info text cap')
            chunks=[] if capture else None
            sha,crc,size=hashlib.sha256(),0,0
            f.seek(start)
            remaining=item.compress_size
            inflater=zlib.decompressobj(-15) if item.compress_type==8 else None
            def consume(b):
                nonlocal crc,size
                require(len(b)<=BLOCK, 'internal output block cap')
                size+=len(b)
                require(size<=item.file_size, 'member expanded size cap')
                sha.update(b)
                crc=zlib.crc32(b,crc)
                if capture: chunks.append(b)
            while remaining:
                b=f.read(min(BLOCK,remaining))
                require(b, 'compressed payload truncated')
                remaining-=len(b)
                if inflater is None:
                    consume(b)
                else:
                    while b:
                        out=inflater.decompress(b,BLOCK)
                        consume(out)
                        require(not inflater.unused_data, 'deflate trailing compressed data')
                        b=inflater.unconsumed_tail
            if inflater is not None:
                # Drain buffered output without allocating an unbounded flush.
                while True:
                    b=inflater.decompress(b'',BLOCK)
                    if not b: break
                    consume(b)
                require(inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail, 'incomplete deflate stream')
            require(size==item.file_size, 'member actual size')
            require(crc&0xffffffff==item.CRC, 'ZIP CRC')
            members[item.filename]={'bytes':size,'sha256':sha.hexdigest(),'crc32':crc&0xffffffff,
                'compressed_bytes':item.compress_size,'method':item.compress_type,'local_offset':item.header_offset}
            if capture: texts[item.filename]=b''.join(chunks)
        spans.sort()
        require(spans[0][0]==0 and spans[-1][1]==archive.start_dir and all(a[1]==b[0] for a,b in zip(spans,spans[1:])), 'ZIP overlap/gap/prefix')
        for key in keys:
            require(all('/'.join(key.split('/')[:i]) not in keys for i in range(1,len(key.split('/')))), 'file/parent collision')
    require(set(texts)==wanted, 'required dist-info texts')
    rows=list(csv.reader(io.StringIO(texts[record].decode('utf-8'),newline='')))
    require(all(len(r)==3 for r in rows) and len({r[0] for r in rows})==len(rows), 'RECORD shape/duplicate')
    require({r[0] for r in rows}==set(members), 'complete RECORD coverage')
    for name,h,size in rows:
        if name==record:
            require(h==size=='', 'RECORD self row')
        else:
            encoded=base64.urlsafe_b64encode(bytes.fromhex(members[name]['sha256'])).rstrip(b'=').decode()
            require(h=='sha256='+encoded and size==str(members[name]['bytes']), 'RECORD hash/size')
    meta_raw=texts[prefix+'METADATA']
    require(meta_raw==accepted_metadata, 'accepted METADATA bytes differ')
    meta=BytesParser(policy=policy.default).parsebytes(meta_raw)
    wheel=BytesParser(policy=policy.default).parsebytes(texts[prefix+'WHEEL'])
    norm=lambda s: re.sub(r'[-_.]+','-',s).lower()
    require(len(meta.get_all('Name',[]))==len(meta.get_all('Version',[]))==1, 'metadata unique name/version')
    require(norm(meta['Name'])==expected['name'] and meta['Version']==expected['version'], 'metadata name/version')
    require(set(wheel.get_all('Tag',[]))==set(expected['tags']) and len(wheel.get_all('Tag',[]))==len(expected['tags']), 'wheel tags')
    require(wheel['Wheel-Version']=='1.0' and wheel['Root-Is-Purelib'] in ('true','false'), 'WHEEL version/purelib')
    return {'member_count':len(members),'record_hash_count':len(rows)-1,'members':members,
        'declared_uncompressed_bytes':total,'zip64_local_members':zip64_count,'metadata_name':prefix+'METADATA',
        'metadata':{'name':meta['Name'],'version':meta['Version']},'tags':wheel.get_all('Tag'),
        'metadata_bytes_equal':True,'block_bytes':BLOCK,'vendor_imports':0,'extractions':0}
