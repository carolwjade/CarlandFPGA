"""Exactly one main-selected new full GET, then bounded streaming verification.

Does nothing on import. No resume, merge, redirect, retry, extract or install.
"""
from datetime import datetime,timezone
import email.parser
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
import traceback

D=Path(__file__).resolve().parent

def pin(p):
    p=Path(p)
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(128*1024),b''): h.update(b)
    return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}

def save(p,v):
    assert p.resolve().is_relative_to(D)
    with p.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(v,f,indent=2,ensure_ascii=False)
        f.write('\n')

def closed(r):
    assert r['all_processes_terminated'] is True
    if 'active_processes_final' in r:
        assert r['active_processes_final']==0
    else:
        assert r['status']=='failed','normal terminal requires active count'
    assert r['held_members'] and all(x['signaled'] is True and x['wait_result']==0 for x in r['held_members'])
    assert not r['faults']

def main():
    assert len(sys.argv)==3 and sys.argv[2]=='--execute-selected','explicit execution mode required'
    selection=json.loads((D/'selection.json').read_bytes())
    incoming=json.loads((D/'incoming-pins.json').read_bytes())['files']
    for name,expected in incoming.items(): assert pin(name)==expected,name
    approval=json.loads((D/'main-selection.json').read_bytes())
    assert approval['work_id']==selection['work_id'] and approval['job_id']==selection['job_id']
    assert approval['requirements_sha256']==selection['requirements_sha256']
    assert approval['approved_incoming_pins']==pin(D/'incoming-pins.json')
    assert approval['new_full_get_selected'] is True and sys.argv[1] in approval['selected_ids']
    runtime=json.loads((D/'runtime-input-observation.json').read_bytes())
    assert approval['approved_runtime_observation']==pin(D/'runtime-input-observation.json')
    assert approval['worker_image_sha256']==runtime['worker_observed_pin']['sha256']
    for r in runtime['inputs']: assert pin(r['path'])==r['observed'],'runtime changed after main review'
    chosen=next(n for n in selection['files'] if n['id']==sys.argv[1])
    index=selection['files'].index(chosen)
    assert len(selection['files'])==6 and sum(n['compressed_bytes'] for n in selection['files'])==1338113780
    Q=D/'requests'/chosen['id']
    artifact=Path(chosen['artifact_path'])
    assert artifact.parent==D/'artifacts' and not artifact.exists() and not Q.exists()
    # Failures/unknown/missing terminals stop the whole round, including later IDs.
    assert sorted(p.name for p in (D/'requests').iterdir())==sorted(n['id'] for n in selection['files'][:index])
    for n in selection['files'][:index]:
        prior=D/'requests'/n['id']
        assert json.loads((prior/'request-closeout.json').read_bytes())['status']=='complete'
        assert json.loads((prior/'verification-result.json').read_bytes())['status']=='success'
    for prior in (D/'runs').iterdir():
        r=json.loads((prior/'terminal.json').read_bytes())
        closed(r)
        assert r['status']=='success' and r['exit_code']==0
    free=shutil.disk_usage(D).free
    remaining=sum(n['compressed_bytes'] for n in selection['files'][index:])
    assert free-remaining-16*1024**2>=10*1024**3
    sys.path.insert(0,str(D))
    from boundary import check_no_links
    for p in (D,D/'artifacts',D/'requests',D/'runs',Path(selection['curl'])): check_no_links(p)
    from win_job import run_bounded,process_identity
    curl=Path(selection['curl'])
    curl_pin=pin(curl)
    assert curl_pin['sha256']=='73d24149ff289afc49ec41f08918ef9faa727d39ad993e929757dc2ddafab805'
    Q.mkdir()
    save(Q/'request.json',chosen)
    env={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR')}
    env.update(PATH='',TEMP=str(Q),TMP=str(Q),PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
    argv=[str(curl),'-q','--http1.1','--silent','--show-error','--fail','--proto','=https',
        '--connect-timeout','10','--max-time','600','--retry','0','--max-redirs','0',
        '--max-filesize',str(chosen['compressed_bytes']),'--dump-header',str(Q/'headers.txt'),
        '--output',str(artifact),'--write-out','%{json}',
        '--header','Accept-Encoding: identity','--header','If-Match: '+chosen['etag'],
        '--header','User-Agent: DeepEye-A-selected-AMD-wheels-20261021','--url',chosen['artifact_url']]
    budget={'seconds':660,'job_memory_bytes':512*1024**2,'process_memory_bytes':256*1024**2,
        'active_processes':4,'stdout_bytes':65536,'stderr_bytes':65536,
        'tree_bytes':1338113780+16*1024**2,'tree_entries':3000,'free_reserve_bytes':10*1024**3,
        'components':[{'path':str(D/'artifacts'),'bytes':1338113780,'entries':6},
            {'path':str(D/'requests'),'bytes':12*1024**2,'entries':200},
            {'path':str(D/'runs'),'bytes':4*1024**2,'entries':200}]}
    receipt={'id':chosen['id'],'request':chosen,'argv':argv,'environment':env,
        'started_utc':datetime.now(timezone.utc).isoformat(),'curl_image':{'path':str(curl),**curl_pin},
        'disk_free_before':free,'requested_response_cap':chosen['compressed_bytes'],
        'maximum_aggregate_cap':1338113780,'network_seconds':600,'child_seconds':660,
        'main_selection':pin(D/'main-selection.json'),'inputs_before':{p:pin(p) for p in incoming},
        'hidden':True,'retries':0,'published_full_hash_available':False}
    save(Q/'download-started.json',receipt)
    process_dir=D/'runs'/(chosen['id']+'-curl')
    tick=time.monotonic()
    def on_tick(job,pids):
        assert len(pids)<=4
        started=json.loads((process_dir/'started.json').read_bytes())
        assert started['launcher']['image_sha256']==curl_pin['sha256']
        assert Path(started['launcher']['image'])==curl
        if artifact.exists():
            check_no_links(artifact)
            assert artifact.stat().st_size<=chosen['compressed_bytes'],'exact response cap'
        if (Q/'headers.txt').exists(): assert (Q/'headers.txt').stat().st_size<=65536
        actual=list((D/'artifacts').iterdir())
        assert len(actual)<=6 and all(p.is_file() for p in actual)
        assert sum(p.stat().st_size for p in actual)<=1338113780<1536*1024**2
    success=False
    try:
        terminal=run_bounded(argv,env,D,process_dir,budget,[D/'artifacts',D/'requests',D/'runs'],on_tick=on_tick)
        receipt['process_terminal']=terminal
        closed(terminal)
        assert terminal['status']=='success' and terminal['exit_code']==0 and terminal['stop_reason'] is None
        assert 1<=len(terminal['held_members'])<=4 and 1<=terminal['total_job_processes']<=4
        started=json.loads((process_dir/'started.json').read_bytes())
        assert started['assigned_before_resume'] and started['private_job'] and started['hidden'] and started['argv']==argv
        receipt['source_process_identity']=started['launcher']
        raw=(Q/'headers.txt').read_bytes()
        blocks=[b for b in re.split(br'\r?\n\r?\n',raw) if b.startswith(b'HTTP/')]
        assert len(blocks)==1,'one HTTP response only'
        status,fields=blocks[0].split(b'\n',1)
        parsed=email.parser.BytesHeaderParser().parsebytes(fields)
        for key in ('content-length','etag','x-amz-version-id','content-encoding'):
            assert len(parsed.get_all(key,[]))<=1,'duplicate binding header'
        headers={k.lower():v.strip() for k,v in parsed.items()}
        meta=json.loads((process_dir/'stdout.txt').read_bytes())
        receipt.update(status_line=status.strip().decode('ascii'),response_headers=headers,curl_metadata=meta)
        assert meta['exitcode']==0 and meta['http_code']==200
        assert meta['num_redirects']==meta['num_retries']==meta['ssl_verify_result']==0
        assert meta['url_effective']==chosen['artifact_url'] and meta['scheme']=='https' and meta['method']=='GET'
        assert headers.get('content-encoding','identity')=='identity' and 'content-range' not in headers
        assert headers.get('etag')==chosen['etag'] and headers.get('x-amz-version-id')==chosen['version_id']
        actual=pin(artifact)
        assert actual['bytes']==chosen['compressed_bytes']==int(meta['size_download'])
        assert headers.get('content-length')==str(actual['bytes'])
        assert pin(curl)==curl_pin and shutil.disk_usage(D).free>=10*1024**3
        receipt.update(outcome='complete',full_sha256_scope='locally observed new full GET; not a publisher digest')
        success=True
    except BaseException:
        receipt.update(outcome='failed_stopped_object',error=traceback.format_exc())
    finally:
        receipt.update(ended_utc=datetime.now(timezone.utc).isoformat(),wrapper_seconds_observed=time.monotonic()-tick,
            body=pin(artifact) if artifact.exists() else None,disk_free_after=shutil.disk_usage(D).free,
            inputs_after={p:pin(p) for p in incoming})
        receipt['inputs_unchanged']=receipt['inputs_before']==receipt['inputs_after']
        save(Q/'download-result.json',receipt)
    if not success or not receipt['inputs_unchanged']:
        save(Q/'request-closeout.json',{'status':'failed_stopped','stage':'download','new_acquisition_stopped':True})
        return 1
    try:
        verify_argv=[selection['python'],'-I','-S','-B','-X','utf8',str(D/'verify_wheel.py'),chosen['id']]
        verify_dir=D/'runs'/(chosen['id']+'-verify')
        def verify_tick(job,pids):
            ready=Q/'verifier-ready.json'
            release=Q/'verifier-release.json'
            if ready.exists() and not release.exists():
                identity=json.loads(ready.read_bytes())
                assert identity['pid'] in pids
                observed=process_identity(identity['pid'],job)
                assert Path(observed['image'])==Path(identity['base_executable'])
                assert observed['image_sha256']==approval['worker_image_sha256']
                save(release,observed)
        result=run_bounded(verify_argv,env,D,verify_dir,{**budget,'stdout_bytes':1024*1024,'stderr_bytes':1024*1024},[D/'artifacts',D/'requests',D/'runs'],on_tick=verify_tick)
        closed(result)
        assert result['status']=='success' and result['exit_code']==0
        verified=json.loads((Q/'verification-result.json').read_bytes())
        detail=json.loads((Q/'archive-review.json').read_bytes())
        assert verified['status']=='success' and verified['artifact']==receipt['body']
        assert detail['python']['pid'] in [x['pid'] for x in result['held_members']]
        assert detail['independent_image_binding']['pid']==detail['python']['pid']
        assert pin(detail['python']['base_executable'])['sha256']==approval['worker_image_sha256']
        assert all(pin(p)==v for p,v in incoming.items())
        save(Q/'request-closeout.json',{'status':'complete','artifact':receipt['body'],
            'request':pin(Q/'request.json'),'download_receipt':pin(Q/'download-result.json'),
            'curl_terminal':pin(process_dir/'terminal.json'),'verify_terminal':pin(verify_dir/'terminal.json'),
            'archive_review':pin(Q/'archive-review.json'),'verification_result':pin(Q/'verification-result.json'),
            'all_owned_processes_signaled':True,'input_pins_unchanged':True,'R02':'not_run','C03':'not_run','all29':'not_run'})
        print(json.dumps({'id':chosen['id'],'status':'complete','artifact':receipt['body'],'members':verified['members']}))
        return 0
    except BaseException:
        save(Q/'request-closeout.json',{'status':'failed_stopped','stage':'verification','error':traceback.format_exc(),'new_acquisition_stopped':True})
        return 1

if __name__=='__main__':
    raise SystemExit(main())
