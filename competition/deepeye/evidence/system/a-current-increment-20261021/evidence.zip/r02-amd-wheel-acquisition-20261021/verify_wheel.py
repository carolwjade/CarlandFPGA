"""Isolated, no-site, data-only streaming verification of this request."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

D=Path(__file__).resolve().parent
sys.path.insert(0,str(D))
from streaming_zip import verify_stream,file_pin
Q=(D/'requests'/sys.argv[1]).resolve()
assert Q.parent==D/'requests'
attempts=[]

def guard(event,args):
    if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.startfile','os.startfile/2','ctypes.dlopen','os.symlink','os.link'}:
        attempts.append(event)
        raise RuntimeError('external/native effect forbidden')
    if event=='import' and args[0].split('.')[0] in {'torch','rocm','rocm_sdk','rocm_bootstrap','setuptools','pip','filelock','fsspec','jinja2','mpmath','networkx','sympy'}:
        attempts.append('vendor_import:'+args[0])
        raise RuntimeError('vendor import forbidden')
    if event=='open' and not isinstance(args[0],int):
        p=Path(args[0]).resolve()
        if 'private' in p.name.lower() or 'reserve' in p.name.lower(): raise RuntimeError('private file forbidden')
        mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writing and not p.is_relative_to(Q):
            attempts.append('unowned_write')
            raise RuntimeError('write outside current request')
    if event=='exec' and str(D/'artifacts').casefold() in args[0].co_filename.casefold():
        attempts.append('artifact_execution')
        raise RuntimeError('artifact source is data')

sys.addaudithook(guard)

def save(name,value):
    with (Q/name).open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,indent=2,ensure_ascii=False)
        f.write('\n')

try:
    request=json.loads((Q/'request.json').read_bytes())
    selection=json.loads((D/'selection.json').read_bytes())
    incoming=json.loads((D/'incoming-pins.json').read_bytes())['files']
    for name,expected in incoming.items(): assert file_pin(name)==expected,name
    artifact=Path(request['artifact_path'])
    assert artifact.parent==D/'artifacts' and artifact.name==request['filename']
    downloaded=json.loads((Q/'download-result.json').read_bytes())
    assert downloaded['outcome']=='complete'
    before=file_pin(artifact)
    assert before==downloaded['body'] and before['bytes']==request['compressed_bytes']
    accepted=request['accepted_metadata']
    assert file_pin(accepted['path'])=={k:accepted[k] for k in ('bytes','sha256')}
    save('verifier-ready.json',{'pid':os.getpid(),'base_executable':sys._base_executable})
    deadline=time.monotonic()+15
    while not (Q/'verifier-release.json').exists():
        assert time.monotonic()<deadline,'independent image binding deadline'
        time.sleep(.02)
    release=json.loads((Q/'verifier-release.json').read_bytes())
    assert release['pid']==os.getpid() and release['image_sha256']==file_pin(sys._base_executable)['sha256']
    result=verify_stream(artifact,request,Path(accepted['path']).read_bytes())
    result.update(artifact=before,accepted_metadata=accepted,
        full_sha256_scope='locally observed new full GET; no publisher full hash available',
        full_published_sha256_equal=None,prohibited_attempts=attempts,
        independent_image_binding=release,
        python={'executable':sys.executable,'base_executable':sys._base_executable,
            'pid':os.getpid(),'ppid':os.getppid(),'isolated':sys.flags.isolated,
            'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode})
    assert result['python']['isolated']==result['python']['no_site']==1
    assert result['python']['dont_write_bytecode'] and not attempts
    assert file_pin(artifact)==before
    save('archive-review.json',result)
    save('verification-result.json',{'status':'success','artifact':before,'name':request['name'],
        'version':request['version'],'members':result['member_count'],'record_hash_count':result['record_hash_count'],
        'accepted_metadata_bytes_equal':True,'declared_expanded_bytes':result['declared_uncompressed_bytes'],
        'published_full_hash_available':False,'vendor_imports':0,'installations':0,'extractions':0,
        'prohibited_attempts':attempts,'R02':'not_run','C03':'not_run','all29':'not_run'})
    print(json.dumps({'status':'success','name':request['name'],'members':result['member_count'],'artifact':before}))
except BaseException:
    save('verification-failure.json',{'status':'failed','error':traceback.format_exc(),'prohibited_attempts':attempts})
    traceback.print_exc()
    raise
