"""Seal accepted bounded raw CPU transcript and combine the limited RX31 evidence."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import subprocess
import zipfile

P = Path(__file__).resolve().parent
R = P.parents[2]
O = P.parent
W = R / '.local/deepeye-implementation-a'
A = O / 'cpu-invocation-transcript-20261024'
V = O / 'cpu-invocation-transcript-independent-20261024'
F = O / 'cpu-transcript-root-constructor-probe-20261024'
BASE = '360b102b299849a24a0b8cb2b6592f64f475e611'
GIT = r'C:\Users\CarlJade\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe'
CONTRACT = 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_bytes())


def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')


def unwrap(value):
    if isinstance(value, dict) and 'content' in value:
        return json.loads(next(x['text'] for x in value['content'] if x['type'] == 'text'))
    return value


def terminal(name):
    job = unwrap(read(P/name))[0]
    assert job['status'] == 'completed' and job['terminal'] and not job['stale']
    return job


assert subprocess.check_output([GIT,'--no-optional-locks','-C',str(W),'rev-parse','HEAD']).decode().strip() == BASE
assert not subprocess.check_output([GIT,'--no-optional-locks','-C',str(W),'diff','--cached','--name-only']).strip()
scope = read(W/'docs/competition/deepeye-2026/immutable_scope.json')['requirements']
assert len(scope) == 15 and sha(json.dumps(scope,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()) == CONTRACT
protected = read(O/'r03-mailbox-stop-main-review-20261020/application.json')['protected_files']
assert all(sha((W/name).read_bytes()) == pin for name,pin in protected.items())
author_job = terminal('cpu-transcript-author-terminal.json')
review_job = terminal('cpu-transcript-review-terminal.json')
for folder,job in [(A,author_job),(V,review_job)]:
    for name in ['report.md','result.json','artifact-manifest.json']:
        assert sha((folder/name).read_bytes()) in job['result']['text']
members = {}


def add(name, raw):
    canonical = name.replace('\\','/')
    assert canonical not in members
    members[canonical] = raw


for folder,prefix,count,postname in [(A,'author/',126,'verification.json'),(V,'independent/',110,'freeze.json')]:
    manifest = read(folder/'artifact-manifest.json')
    assert len(manifest['files']) == count
    for name,row in manifest['files'].items():
        path = (folder/name).resolve()
        assert path.is_relative_to(folder.resolve()) and path.is_file()
        raw = path.read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        add(prefix+name,raw)
    for name in ['artifact-manifest.json',postname,'native-complete-receipt.json']:
        add(prefix+name,(folder/name).read_bytes())
pins = read(V/'final-sourcepins.json')
final_sources = pins['final_candidate_sources']
assert len(final_sources) == 3
for name,row in final_sources.items():
    raw = (W/name).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    assert b'\r' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n')
    assert all(line.rstrip(b' \t') == line for line in raw.splitlines())
    if name.endswith('.py'): ast.parse(raw)
assert len(pins['unchanged_dependencies']) == 16
assert all(sha((W/name).read_bytes()) == row['sha256'] for name,row in pins['unchanged_dependencies'].items())
result = read(V/'result.json')
assert result['frozen_controls'] == dict(methods=9,runs=1,failures=0,errors=0,exit_code=0,oracle_changed=False)
assert result['independent_constructor_control'] == dict(methods=1,runs=1,failures=0,errors=0,exit_code=0)
assert not result['reviewer_controls_executed_on_author_original_pin']
for name in ['controls-execution.json','constructor-control-execution.json']:
    receipt = read(V/name)
    assert receipt.get('returncode',receipt.get('exit_code',receipt.get('exit'))) == 0
for name in ['controls-stderr.log','constructor-control-stderr.log']:
    log = (V/name).read_bytes()
    assert b'\nOK' in log and b'FAILED' not in log
delta = read(F/'root-correction.json')
assert delta['original_sha256'] == '369ec6aee4a86f42c2932aebb7c859fd11befe2a7b748b6c495886402357a53d'
assert delta['final_sha256'] == '444f68e94a9adaaab0406b7402fb8029319bc192052b861f520b8982f89a4266'
assert {name:row['sha256'] for name,row in final_sources.items()} == delta['final_owned_source_pins']
for path in F.rglob('*'):
    if path.is_file():
        assert 'lease' not in path.name and '__pycache__' not in path.parts
        add('root-constructor/'+path.relative_to(F).as_posix(),path.read_bytes())
for name in ['cpu-transcript-author-terminal.json','cpu-transcript-review-terminal.json',
             'cpu-invocation-transcript-decision.json','cpu-transcript-phase1-root-check.json',
             'cpu-transcript-phase2-candidate.json']:
    add('root/'+name,(P/name).read_bytes())
add('root/archive_cpu_transcript_increment.py',Path(__file__).read_bytes())
secrets = [unwrap(read(folder/'lease.private.json'))['lease_token'].encode() for folder in [A,V]]
assert all(secret not in raw for raw in members.values() for secret in secrets)
assert all('lease.private' not in name for name in members)
decision = dict(schema=1,utc=datetime.now(timezone.utc).isoformat(),
    owner='A/root 01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3',
    disposition='ACCEPT_BOUNDED_RAW_SINGLE_INVOCATION_OS_TRANSCRIPT_SOFTWARE_INCREMENT_ONLY',
    source_base=BASE,final_source_pins={name:row['sha256'] for name,row in final_sources.items()},
    root_constructor_correction=delta,requirements_sha256=CONTRACT,H01_H15_preserved=True,
    author_original_final_methods=14,author_original_final_subtests=9,
    author_14_scope='original369ec module plus original test/doc, not root444f',
    intermediate_author_13_exact_full_source_binding='not established; old complete sourcepins overwritten, no reconstruction',
    independent_final_frozen_methods=9,independent_final_constructor_methods=1,
    frozen_oracle_changed=False,author_manifest_members=126,independent_manifest_members=110,
    unchanged_dependencies=16,protected_C_files_unchanged=True,
    original_RED_and_old_module_snapshots_preserved=True,
    input_output_scope='actual bounded local OS pipes/journals with scripted private clocks/fault seams',
    component_scope='one exact opaque request, durable-start once-write, original raw output/offsets/budgets, unknown side-effects retained, permanent veto',
    adopted_inference_format=False,actual_model_actor_or_original_completion_source_established=False,
    timestamp_uncertainty_ns=None,availability_sample_completion_intervals_ns=None,
    production_gate='unchanged unconditional refusal; new transcript not installed as a provider',
    old_clock_or_component_suites_rerun=False,PL_ADC_model_motion_build_board_system_or_formal_acceptance=False,
    G03='not_run',R03='not_run',all29='not_run')
dest = W/'competition/deepeye/evidence/system/a-cpu-invocation-transcript-20261024'
dest.mkdir(parents=True,exist_ok=False)
zp = dest/'review-evidence.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()): z.writestr(name,raw)
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None and len(z.namelist()) == len(members) and set(z.namelist()) == set(members)
    assert all(z.read(name) == raw for name,raw in members.items())
save(dest/'manifest.json',dict(schema=1,zip_sha256=sha(zp.read_bytes()),zip_bytes=zp.stat().st_size,
    member_count=len(members),members=[dict(path=name,bytes=len(raw),sha256=sha(raw))
    for name,raw in sorted(members.items())],credentials_excluded=True))
save(dest/'decision.json',decision)
(dest/'README.md').write_text('Bounded raw single-invocation OS transcript software only: once dispatch with original durable-start marker, exact raw output/offsets/budgets and permanent unknown-side-effect retirement. No adopted C format, model/actor/source/completion or motion authority. Author14 methods/9 subtests bind original369ec; intermediate13 fullsource provenance is unestablished. Root journal-close primary-error fix444f binds final9 frozen independent methods plus1 new constructor control, oracle unchanged. Original failure/source snapshots and root RED/GREEN retained;16 old dependencies/C4 unchanged. No old tests/clock trials replayed, no production gate opening. H01-H15 preserved; G03/R03/all29=not_run.\n',encoding='utf-8',newline='\n')
files = {path.relative_to(W).as_posix():sha(path.read_bytes()) for path in dest.iterdir()}
files.update({name:row['sha256'] for name,row in final_sources.items()})
rx = read(P/'rx31-publication.json')
assert rx['expected_head'] == BASE and not set(files)&set(rx['files'])
files.update(rx['files'])
assert len(files) == 12
save(P/'cpu-transcript-root-decision.json',decision)
save(P/'cpu-transcript-rx31-publication.json',dict(expected_head=BASE,
    message='Record raw CPU invocation I/O and preserve constructor errors; archive RX31 review',files=files))
assert all(sha((W/name).read_bytes()) == pin for name,pin in protected.items())
print(json.dumps(dict(prepared_files=len(files),archive_members=len(members),zip_bytes=zp.stat().st_size,
    zip_sha256=sha(zp.read_bytes()),final_source_files=3,C4_unchanged=True)))
