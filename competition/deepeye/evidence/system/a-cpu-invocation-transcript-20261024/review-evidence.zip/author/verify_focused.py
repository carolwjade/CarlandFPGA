"""Only new invocation controls; scripted clocks, source/format/dependency pins."""
import ast
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PRODUCT=ROOT/'.local/deepeye-implementation-a'
BASE='360b102b299849a24a0b8cb2b6592f64f475e611'
OWNED=['competition/deepeye/integration/cpu_invocation_transcript.py',
       'competition/deepeye/integration/test_cpu_invocation_transcript.py',
       'competition/deepeye/docs/cpu_invocation_transcript.md']
DEPENDENCIES=[
 'competition/deepeye/integration/host_clock.py',
 'competition/deepeye/integration/live_board_receipts.py',
 'competition/deepeye/integration/boot_transcript.py',
 'competition/deepeye/integration/clock_bounds.py',
 'competition/deepeye/integration/candidate_mailbox.py',
 'competition/deepeye/integration/pc_direct_watchdog.py',
 'competition/deepeye/integration/wire.py',
 'competition/deepeye/docs/boot_profiles.json',
 'competition/deepeye/simulation/isolation/actor_owner.py',
 'competition/deepeye/simulation/isolation/actor_lifetime.py',
 'competition/deepeye/simulation/isolation/pipe_read.py',
 'competition/deepeye/simulation/isolation/ipc_framing.py',
 'competition/deepeye/simulation/authority/actor_composition.py',
 'competition/deepeye/simulation/authority/candidate_owner.py',
 'competition/deepeye/simulation/authority/pc_direct_runtime.py',
 'competition/deepeye/simulation/authority/motion_executor.py']
sys.path.insert(0,str(PRODUCT))
def sha(raw): return hashlib.sha256(raw).hexdigest()
def save(name,value):
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def git(*args):
 return subprocess.run(['git',*args],cwd=PRODUCT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)

formatting={}
for path in OWNED:
 text=(PRODUCT/path).read_text(encoding='utf-8').replace('\r\n','\n').replace('\r','\n')
 text='\n'.join(line.rstrip(' \t') for line in text.split('\n')).rstrip('\n')+'\n'
 (PRODUCT/path).write_bytes(text.encode('utf-8'))
 raw=(PRODUCT/path).read_bytes()
 assert raw.endswith(b'\n') and not raw.endswith(b'\n\n') and b'\r' not in raw
 assert all(not line.endswith((b' ',b'\t')) for line in raw.splitlines())
 if path.endswith('.py'): ast.parse(text,filename=path)
 formatting[path]=dict(exactly_one_final_LF=True,no_trailing_whitespace=True,LF_only=True)
scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
requirements=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
assert requirements=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
pins={}
for path in OWNED+DEPENDENCIES:
 raw=(PRODUCT/path).read_bytes(); original=git('show',BASE+':'+path)
 pins[path]=dict(bytes=len(raw),sha256=sha(raw),base_sha256=None if original.returncode else sha(original.stdout),
                 same_as_base=not original.returncode and raw==original.stdout)
assert all(pins[path]['same_as_base'] for path in DEPENDENCIES)
protected=json.loads((ROOT/'.planning/deepeye-resume-20261018/r03-mailbox-stop-main-review-20261020/application.json').read_text(encoding='utf-8'))['protected_files']
assert all(sha((PRODUCT/path).read_bytes())==value for path,value in protected.items())
assert git('diff','--check','--',*OWNED).returncode==0
decision=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024/cpu-invocation-transcript-decision.json'
save('source-pins.json',dict(base_commit=BASE,head_readback=git('rev-parse','HEAD').stdout.decode().strip(),
 requirements_sha256=requirements,decision_sha256=sha(decision.read_bytes()),owned_files=OWNED,
 source=pins,protected_files_sha256=protected,formatting=formatting))
(OUT/'git-status.txt').write_bytes(git('status','--short').stdout)

name='competition.deepeye.integration.test_cpu_invocation_transcript'
suite=unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(name))
def cases(suite):
 for case in suite:
  if isinstance(case,unittest.TestSuite): yield from cases(case)
  else: yield case
ids=[case.id() for case in cases(suite)]
assert len(ids)==14 and all('.test_cpu_invocation_transcript.' in case for case in ids)
os.environ['CPU_TRANSCRIPT_CONTROL_OUT']=str(OUT/'raw-controls-final')
class Results(unittest.TextTestResult):
 def __init__(self,*args): super().__init__(*args); self.subtests=[]
 def addSubTest(self,test,subtest,error):
  self.subtests.append(dict(test=test.id(),parameters=str(subtest),success=error is None))
  super().addSubTest(test,subtest,error)
with (OUT/'focused-green.log').open('w',encoding='utf-8') as log:
 result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Results).run(suite)
save('focused-result.json',dict(tests_run=result.testsRun,executed_test_ids=ids,subtests=result.subtests,
 success=result.wasSuccessful(),failures=len(result.failures),errors=len(result.errors),
 old_test_cases_executed=0,clock_scope='private scripted legacy/QPC leaf and capability seams; no actual product clock observation',
 actual_scope='local OS pipes and new journals only; no model/native actor/board',
 source_pins_sha256=sha((OUT/'source-pins.json').read_bytes())))
assert all(sha((PRODUCT/path).read_bytes())==value['sha256'] for path,value in pins.items())
assert all(sha((PRODUCT/path).read_bytes())==value for path,value in protected.items())
print(json.dumps(dict(tests_run=result.testsRun,subtests=len(result.subtests),success=result.wasSuccessful(),
 failures=len(result.failures),errors=len(result.errors),three_new_files_format_AST='passed',
 existing_dependencies_and_C_four_unchanged=True),sort_keys=True))
sys.exit(0 if result.wasSuccessful() else 1)
