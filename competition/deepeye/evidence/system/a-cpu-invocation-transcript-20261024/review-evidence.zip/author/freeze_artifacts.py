"""Freeze final raw invocation sources and new-control evidence; no tests or I/O replay."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PRODUCT=ROOT/'.local/deepeye-implementation-a'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(name): return json.loads((OUT/name).read_text(encoding='utf-8'))
def save(name,value):
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
pins=read('source-pins.json'); focused=read('focused-result.json')
assert focused['success'] and focused['tests_run']==14 and len(focused['subtests'])==9
for path,value in pins['source'].items(): assert sha((PRODUCT/path).read_bytes())==value['sha256']
for path,value in pins['protected_files_sha256'].items(): assert sha((PRODUCT/path).read_bytes())==value
for path in pins['owned_files']:
 raw=(PRODUCT/path).read_bytes()
 assert raw.endswith(b'\n') and not raw.endswith(b'\n\n') and b'\r' not in raw
 assert all(not line.endswith((b' ',b'\t')) for line in raw.splitlines())
 destination=OUT/'source-snapshot'/path
 destination.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(PRODUCT/path,destination)
 assert sha(destination.read_bytes())==pins['source'][path]['sha256']
before=(OUT/'before-late-veto-cpu_invocation_transcript.py').read_text(encoding='utf-8')
after=(PRODUCT/pins['owned_files'][0]).read_text(encoding='utf-8')
(OUT/'late-veto-fix.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),
 after.splitlines(True),fromfile='before-late-veto',tofile='final')),encoding='utf-8')
raw='raw-controls-final/'
post_write=read(raw+'test_post_write_stamp_failure_preserves_actual_count_and_unknown_end/snapshot-0.json')
hidden_write=read(raw+'test_write_interruption_after_hidden_bytes_keeps_count_null_and_never_repeats/snapshot-0.json')
hidden_read=read(raw+'test_read_interruption_after_hidden_consumption_preserves_unknown_attempt/snapshot-0.json')
late_veto=read(raw+'test_foreign_veto_after_final_checkpoint_never_reopens_next_io/snapshot-0.json')
assert post_write['dispatch']['bytes_written']==14 and post_write['dispatch']['raw_write_call_bracket_ns']==[101,None]
assert hidden_write['dispatch']['bytes_written'] is None and hidden_write['failed']
assert hidden_read['unknown_consumption'] and hidden_read['bytes_read']==0 and hidden_read['failed']
assert hidden_read['reads'][0]['raw_hex'] is None and hidden_read['reads'][0]['returned_bytes'] is None
assert late_veto['failed'] and late_veto['veto_generation']>0 and late_veto['reads']==[]
save('raw-readback.json',dict(post_write_known_count=14,post_write_end=None,
 hidden_write_count=None,hidden_read_returned_raw=None,hidden_read_count=None,
 hidden_read_known_prefix=0,hidden_read_total_consumption='unknown',late_veto_failed=True,
 late_veto_read_attempts=0,scope='actual local OS pipe I/O; hidden consumption is known only to the private test seam and never backfilled'))
save('execution-notes.json',dict(
 initial_RED='new module absent assertion, no actual request/write path existed yet',
 constructor_cleanup_RED='primary FileExistsError was masked by the first duplicate-close error; later closes were skipped. Final code attempts each owned close once and preserves primary exception with notes.',
 initial_clock_RED='initial high-water 0 incorrectly looked like a sampled value; changed to None until first selected-clock stamp',
 late_veto_RED='foreign thread veto after final checkpoint could be overwritten by temporary failed=False. Final entry/snapshot consult irreversible veto independently and preserve first retirement reason.',
 intermediate_13_provenance_limit='Earlier 13-method raw/log/result artifacts are kept, but their prior complete source-pins JSON was superseded during the final verifier run and not retained as a separate original file. Do not claim full exact-source provenance for that intermediate green run. Final14 binds exact current3 bytes and all dependencies; the failed late-veto module is retained verbatim.',
 no_old_tests_or_actual_clock_trial=True,no_existing_product_module_edits=True,
 no_stage_commit_board_serial_UI_services_network_delegation=True))
result=dict(schema=1,status='raw_single_invocation_transcript_implemented_focused_controls_passed',
 task_id='DEEPEYE-IMPLEMENTATION-20261014',task_version=1,
 work_id='A-CPU-INVOCATION-TRANSCRIPT-20261024-v1',
 job_id='child-572f0914508448568766dfae21580825',agent_id='/root/pc_direct_window',
 base_commit=pins['base_commit'],head_readback=pins['head_readback'],
 requirements_sha256=pins['requirements_sha256'],H01_H15_preserved=True,
 source_files={path:pins['source'][path] for path in pins['owned_files']},
 focused_tests=dict(methods=14,subtests=9,failures=0,errors=0,old_test_cases_executed=0),
 actual_scope='local pipes and journals; all product time reads scripted; no actor/model/board',
 raw_unknown_preserved=True,prequeued_output_promoted=False,codec_selected=False,
 completion_or_readiness_or_authentication_granted=False,existing_production_gate_unchanged=True,
 existing_16_dependencies_and_C_four_bytes_unchanged=True,
 source_pins_sha256=sha((OUT/'source-pins.json').read_bytes()),
 focused_result_sha256=sha((OUT/'focused-result.json').read_bytes()),
 G03='not_run',R03='not_run',all29='not_run',formal_acceptance=False,
 raw_manifest='artifact-manifest.json')
save('result.json',result)
table='\n'.join('| `'+path+'` | `'+pins['source'][path]['sha256']+'` |' for path in pins['owned_files'])
report='''# Raw single-invocation transcript implementation

Implemented the root-frozen opaque request / original OS output ledger in three
new files only. This is a diagnostic component for root review, not an inference
producer, model/readiness authentication or motion authority. Task
DEEPEYE-IMPLEMENTATION-20261014/v1; work
A-CPU-INVOCATION-TRANSCRIPT-20261024-v1; canonical /root/pc_direct_window;
new job child-572f0914508448568766dfae21580825 independently validated
execution_allowed=true. No old lease token reused. Transfer/immutable md/json
were read; active director remains Gen3 01a16988-bdcb-70e1-ae10-1304b5cf7875.
Requirements canonical UTF-8 ensure_ascii=False/sort_keys=True/compact recomputed:
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
DEEPEYE-HUMAN-LOCK-20261014/revision1/H01-H15 and A/root-only board operation
are unchanged. Base and HEAD readback: 360b102b299849a24a0b8cb2b6592f64f475e611.
The exact cpu-invocation-transcript root decision hash is in source-pins.json.

## Behavior and deliberate limits

Exact frozen InvocationIdentity contains bounded correlation labels/hashes,
run/invocation/actor ids. It authenticates none of them. The original operation
request_hash and separately computed opaque request_raw SHA256 are distinct.
InvocationTranscript accepts caller-owned original input/output descriptors,
exact nonempty bytes<=16384, a new exclusive journal, explicit byte/read/size
budgets and None or an exact existing fresh-run QPC binding. Type checks reject
replay regular files and ordinary callable clocks. Actual connection/exclusive
endpoint/actor ownership and blocking supervision remain main's obligations.
No global invocation uniqueness across new objects/journals is claimed.

Dispatch reserves before its first selected-clock read, then flushes/fsyncs a
started_unknown marker before one exact os.write. Partial/error/interruption,
clock/journal failure or veto cannot retry/remainder-write or admit output.
Known returned counts are saved before the trailing stamp; unknown count remains
None. Reads only follow a fully recorded successful dispatch. Each read reserves
an unknown row and closes the temporary latch before OS I/O, retaining a started
journal row. Known raw bytes/count/continuous offsets are saved before poststamp.
Interrupted consumption without a return retains raw/count=None, byte count as
known prefix only, and permanent unknown/failure; no subsequent OS read/claim.
Empty/EAGAIN, data and actual EOF differ. Byte/read budgets clip the original
read, EOF/budget forbid extras. These are raw chunks, never completion framing.

The owner checks stable clock/domain, strict bounded monotonic values and one
thread. No actual stamp is invented at construction: high-water initially None.
Caught reentry/foreign veto is irreversible even if it arrives after the final
operation checkpoint: every future entry and snapshot checks the permanent veto
separately from the temporary I/O latch and retains the first retirement reason.
Already recorded positive OS write/count facts remain facts; no later veto
relables them as absent or retries them. Close touches each owned duplicate and
journal once; caller descriptors survive. Constructor cleanup attempts every
acquired duplicate once and preserves the primary failure if a close also fails.

Snapshot is detached and retains request, dispatch, exact original output rows,
offsets/read index/counts/budgets/EOF/journal/failure/clock metadata. Raw call
brackets are diagnostic; all availability/sample/completion and read/write
measurement intervals remain None. Nominal QPC resolution gives no uncertainty.
Prequeued READY/model_candidate bytes stay raw, with no inference of freshness,
readiness, execution, completion, usefulness or causality. The new module imports
no inactive IPC codec, actor, runtime, mailbox, executor or provider. It returns
no _CompletedInference/BootBinding/model candidate/authority record, acquires no
actor/endpoint and does not open any production gate.

Private details selected within the frozen contract: read_once/dispatch_once
return detached diagnostic dictionaries; every read has a pre-I/O journal row;
normal no-I/O duplicate/not-yet-dispatched/EOF/budget refusals have no new I/O;
legacy and QPC raw timing both remain measurement-unknown. Label shape and all
bound values are documented in the product doc. The code has no timeout,
background worker, sleep or hard cancellation guarantee. Returned flush/fsync
calls are OS observations, not an independent power-loss durability measurement.

## Focused RED/GREEN evidence

Final command from ROOT:
`$env:PYTHONDONTWRITEBYTECODE='1'; & .local/venv/Scripts/python.exe -X utf8 .planning/deepeye-resume-20261018/cpu-invocation-transcript-20261024/verify_focused.py`

Final: **14 new methods, 9 subtests, zero failures/errors**. All executed IDs are
asserted to belong to the one new test_cpu_invocation_transcript module; no old
TestCase/helper suite or producer exhaustive run is executed. Actual local OS
pipes/journals are used. Legacy clock and QPC capability/leaf reads are private
scripted seams; no actual product-clock/capability query, clock observation,
sleep, policy consume, model/native actor, board/serial, UI, service, network,
new delegation, stage or commit operation occurs. Existing product modules were
not edited. Raw final controls are under raw-controls-final/; prior controls
remain under raw-controls/. Scripted hidden-consumption witnesses are separately
marked test knowledge and are never backfilled into transcript raw/count fields.

Controls cover exact request/durable-before-write order and multiple raw output
offsets; actual partial write with no remainder/read; post-write stamp failure
retaining 14-byte returned count and unknown end; hidden write interruption with
unknown count despite test-observed two sent bytes; hidden read interruption
with unknown raw/count despite test-observed consumed bytes; post-read exception
and regression retaining three known returned bytes; empty/EOF/byte/read budgets;
prequeued output and detached snapshots; marker/pre-write/journal failures with
no OS write retry; second clock/callable refusal; foreign/reentrant/late-veto
retirement; regular replay file/shape/read-before-dispatch refusal; duplicate-only
close and caller-fd survival; no journal reopen and per-owned-descriptor close.

All RED/failed records remain:

- red.log: expected absent new module assertion before implementation. This is
  API-absent RED, not preexisting model/CPU numerical execution.
- constructor-cleanup-red.log: primary FileExistsError masked by the first close
  OSError. New one-pass-all-duplicates cleanup preserves the primary error.
- unknown-initial-clock-red.log: initial high-water 0 was not an observed time;
  corrected to None until first actual selected-clock stamp.
- late-veto-red.log: a private final-check seam delivered an actual foreign thread
  call after the last checkpoint; the temporary failed flag was overwritten.
  The final irreversible-veto guard/snapshot correct it. The exact failed module
  is preserved verbatim in before-late-veto-cpu_invocation_transcript.py, with the
  final minimal delta in late-veto-fix.diff. This does not rerun any old module.

Initial12 and next13 new-method runs passed before later controls were added.
The intermediate13 raw/log/result artifacts are preserved; their prior complete
source-pins JSON was superseded during rerun and was not separately retained.
Do not claim complete exact-source provenance for that intermediate GREEN run.
Final14 binds all three exact final files and unchanged dependencies afresh.
execution-notes.json records the limitation; no reconstructed artifact is called
an original. No old test replay, policy widening or invented clock bound was used.

## Integrity and exact final pins

All three new/untracked files were checked explicitly for LF-only endings,
exactly one final LF, no trailing spaces/tabs and valid Python AST; owned
git diff --check also passed. Sixteen existing dependencies equal base bytes,
including QPC source, receipt/BOOT, inactive framing/pipe, clocks, actor/lifetime,
composition/progress, owner/mailbox/runtime/executor, watchdog, ABI wire/profile.
The four C-protected byte hashes match their original application record.
source-pins.json and post-control source re-read confirm these exact identities.

| Product-relative file | SHA256 |
|---|---|
'''+table+'''

source-snapshot/ holds the three final raw files. raw-readback.json independently
re-reads final known and unknown pipe facts and the late-veto no-read state.
artifact-manifest.json covers non-secret scripts/reports/results/logs/raw controls,
journals and source copies. lease.private.json is excluded and must not be
published. Manifest itself, verification.json and post-freeze native completion
request/receipt are excluded to avoid circular hashes. verification.json reads
every manifest member and exact source pin again before native completion.

The next original CPU/provider must separately prove actual entry/package,
endpoint ownership, invocation/causal association, computation/timing and useful
decision before making authority records. This raw component alone establishes
none of them. H01-H15, both full H12 paths and complete 3D/UI scope remain;
G03=not_run, R03=not_run, all29=not_run, formal_acceptance=false. Root owns final
source review/selection and independent reviewer phase2 unlock.
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
excluded={'lease.private.json','artifact-manifest.json','verification.json',
          'native-complete-request.json','native-complete-receipt.json'}
members={path.relative_to(OUT).as_posix():dict(bytes=path.stat().st_size,sha256=sha(path.read_bytes()))
         for path in sorted(OUT.rglob('*')) if path.is_file() and path.name not in excluded}
save('artifact-manifest.json',dict(schema=1,files=members,excluded=sorted(excluded),lease_private_publish=False))
assert all((OUT/path).stat().st_size==value['bytes'] and sha((OUT/path).read_bytes())==value['sha256']
           for path,value in members.items())
verification=dict(frozen=True,member_count=len(members),all_members_readback_match=True,
 all_final_source_pins_readback_match=True,no_existing_product_module_writes=True,
 report_sha256=sha((OUT/'report.md').read_bytes()),result_sha256=sha((OUT/'result.json').read_bytes()),
 source_pins_sha256=sha((OUT/'source-pins.json').read_bytes()),
 artifact_manifest_sha256=sha((OUT/'artifact-manifest.json').read_bytes()))
save('verification.json',verification)
print(json.dumps(verification,sort_keys=True))
