# Raw single-invocation transcript implementation

Implemented the root-frozen opaque request / original OS output ledger in three
new files only. This is a diagnostic component for root review, not an inference
producer, model/readiness authentication or motion authority. Task
DEEPEYE-IMPLEMENTATION-20261014/v1; work
A-CPU-INVOCATION-TRANSCRIPT-20261024-v1; canonical /root/pc_direct_window;
new job child-572f0914508448568766dfae21580825 independently validated
execution_allowed=true. No old lease token reused. Transfer/immutable md/json
were read; active director remains Gen3 01a16988-bdcb-70e1-ae10-1304b5cf7875.
Requirements canonical UTF-8 ensure_ascii=False/sort_keys=True/compact recomputed:
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
DEEPEYE-HUMAN-LOCK-20261014/revision1/H01-H15 and A/root-only board operation
are unchanged. Base and HEAD readback: 360b102b299849a24a0b8cb2b6592f64f475e611.
The exact cpu-invocation-transcript root decision hash is in source-pins.json.

## Behavior and deliberate limits

Exact frozen InvocationIdentity contains bounded correlation labels/hashes,
run/invocation/actor ids. It authenticates none of them. The original operation
request_hash and separately computed opaque request_raw SHA256 are distinct.
InvocationTranscript accepts caller-owned original input/output descriptors,
exact nonempty bytes<=16384, a new exclusive journal, explicit byte/read/size
budgets and None or an exact existing fresh-run QPC binding. Type checks reject
replay regular files and ordinary callable clocks. Actual connection/exclusive
endpoint/actor ownership and blocking supervision remain main's obligations.
No global invocation uniqueness across new objects/journals is claimed.

Dispatch reserves before its first selected-clock read, then flushes/fsyncs a
started_unknown marker before one exact os.write. Partial/error/interruption,
clock/journal failure or veto cannot retry/remainder-write or admit output.
Known returned counts are saved before the trailing stamp; unknown count remains
None. Reads only follow a fully recorded successful dispatch. Each read reserves
an unknown row and closes the temporary latch before OS I/O, retaining a started
journal row. Known raw bytes/count/continuous offsets are saved before poststamp.
Interrupted consumption without a return retains raw/count=None, byte count as
known prefix only, and permanent unknown/failure; no subsequent OS read/claim.
Empty/EAGAIN, data and actual EOF differ. Byte/read budgets clip the original
read, EOF/budget forbid extras. These are raw chunks, never completion framing.

The owner checks stable clock/domain, strict bounded monotonic values and one
thread. No actual stamp is invented at construction: high-water initially None.
Caught reentry/foreign veto is irreversible even if it arrives after the final
operation checkpoint: every future entry and snapshot checks the permanent veto
separately from the temporary I/O latch and retains the first retirement reason.
Already recorded positive OS write/count facts remain facts; no later veto
relables them as absent or retries them. Close touches each owned duplicate and
journal once; caller descriptors survive. Constructor cleanup attempts every
acquired duplicate once and preserves the primary failure if a close also fails.

Snapshot is detached and retains request, dispatch, exact original output rows,
offsets/read index/counts/budgets/EOF/journal/failure/clock metadata. Raw call
brackets are diagnostic; all availability/sample/completion and read/write
measurement intervals remain None. Nominal QPC resolution gives no uncertainty.
Prequeued READY/model_candidate bytes stay raw, with no inference of freshness,
readiness, execution, completion, usefulness or causality. The new module imports
no inactive IPC codec, actor, runtime, mailbox, executor or provider. It returns
no _CompletedInference/BootBinding/model candidate/authority record, acquires no
actor/endpoint and does not open any production gate.

Private details selected within the frozen contract: read_once/dispatch_once
return detached diagnostic dictionaries; every read has a pre-I/O journal row;
normal no-I/O duplicate/not-yet-dispatched/EOF/budget refusals have no new I/O;
legacy and QPC raw timing both remain measurement-unknown. Label shape and all
bound values are documented in the product doc. The code has no timeout,
background worker, sleep or hard cancellation guarantee. Returned flush/fsync
calls are OS observations, not an independent power-loss durability measurement.

## Focused RED/GREEN evidence

Final command from ROOT:
`$env:PYTHONDONTWRITEBYTECODE='1'; & .local/venv/Scripts/python.exe -X utf8 .planning/deepeye-resume-20261018/cpu-invocation-transcript-20261024/verify_focused.py`

Final: **14 new methods, 9 subtests, zero failures/errors**. All executed IDs are
asserted to belong to the one new test_cpu_invocation_transcript module; no old
TestCase/helper suite or producer exhaustive run is executed. Actual local OS
pipes/journals are used. Legacy clock and QPC capability/leaf reads are private
scripted seams; no actual product-clock/capability query, clock observation,
sleep, policy consume, model/native actor, board/serial, UI, service, network,
new delegation, stage or commit operation occurs. Existing product modules were
not edited. Raw final controls are under raw-controls-final/; prior controls
remain under raw-controls/. Scripted hidden-consumption witnesses are separately
marked test knowledge and are never backfilled into transcript raw/count fields.

Controls cover exact request/durable-before-write order and multiple raw output
offsets; actual partial write with no remainder/read; post-write stamp failure
retaining 14-byte returned count and unknown end; hidden write interruption with
unknown count despite test-observed two sent bytes; hidden read interruption
with unknown raw/count despite test-observed consumed bytes; post-read exception
and regression retaining three known returned bytes; empty/EOF/byte/read budgets;
prequeued output and detached snapshots; marker/pre-write/journal failures with
no OS write retry; second clock/callable refusal; foreign/reentrant/late-veto
retirement; regular replay file/shape/read-before-dispatch refusal; duplicate-only
close and caller-fd survival; no journal reopen and per-owned-descriptor close.

All RED/failed records remain:

- red.log: expected absent new module assertion before implementation. This is
  API-absent RED, not preexisting model/CPU numerical execution.
- constructor-cleanup-red.log: primary FileExistsError masked by the first close
  OSError. New one-pass-all-duplicates cleanup preserves the primary error.
- unknown-initial-clock-red.log: initial high-water 0 was not an observed time;
  corrected to None until first actual selected-clock stamp.
- late-veto-red.log: a private final-check seam delivered an actual foreign thread
  call after the last checkpoint; the temporary failed flag was overwritten.
  The final irreversible-veto guard/snapshot correct it. The exact failed module
  is preserved verbatim in before-late-veto-cpu_invocation_transcript.py, with the
  final minimal delta in late-veto-fix.diff. This does not rerun any old module.

Initial12 and next13 new-method runs passed before later controls were added.
The intermediate13 raw/log/result artifacts are preserved; their prior complete
source-pins JSON was superseded during rerun and was not separately retained.
Do not claim complete exact-source provenance for that intermediate GREEN run.
Final14 binds all three exact final files and unchanged dependencies afresh.
execution-notes.json records the limitation; no reconstructed artifact is called
an original. No old test replay, policy widening or invented clock bound was used.

## Integrity and exact final pins

All three new/untracked files were checked explicitly for LF-only endings,
exactly one final LF, no trailing spaces/tabs and valid Python AST; owned
git diff --check also passed. Sixteen existing dependencies equal base bytes,
including QPC source, receipt/BOOT, inactive framing/pipe, clocks, actor/lifetime,
composition/progress, owner/mailbox/runtime/executor, watchdog, ABI wire/profile.
The four C-protected byte hashes match their original application record.
source-pins.json and post-control source re-read confirm these exact identities.

| Product-relative file | SHA256 |
|---|---|
| `competition/deepeye/integration/cpu_invocation_transcript.py` | `369ec6aee4a86f42c2932aebb7c859fd11befe2a7b748b6c495886402357a53d` |
| `competition/deepeye/integration/test_cpu_invocation_transcript.py` | `ffe5f7e7158671889d6fd395382c10e78266adaa48a53acfe6a21646a1cb2ee9` |
| `competition/deepeye/docs/cpu_invocation_transcript.md` | `42fca58970a140c4b59423387231a7001837cf1236597df7413a0edde6478cfb` |

source-snapshot/ holds the three final raw files. raw-readback.json independently
re-reads final known and unknown pipe facts and the late-veto no-read state.
artifact-manifest.json covers non-secret scripts/reports/results/logs/raw controls,
journals and source copies. lease.private.json is excluded and must not be
published. Manifest itself, verification.json and post-freeze native completion
request/receipt are excluded to avoid circular hashes. verification.json reads
every manifest member and exact source pin again before native completion.

The next original CPU/provider must separately prove actual entry/package,
endpoint ownership, invocation/causal association, computation/timing and useful
decision before making authority records. This raw component alone establishes
none of them. H01-H15, both full H12 paths and complete 3D/UI scope remain;
G03=not_run, R03=not_run, all29=not_run, formal_acceptance=false. Root owns final
source review/selection and independent reviewer phase2 unlock.
