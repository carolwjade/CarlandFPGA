"""Preserve the original author set and record root's journal cleanup correction."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import json

P = Path(__file__).resolve().parent
O = P.parent
R = O.parents[1]
W = R / '.local/deepeye-implementation-a'
A = O / 'cpu-invocation-transcript-20261024'
name = 'competition/deepeye/integration/cpu_invocation_transcript.py'
original = (A / 'source-snapshot' / name).read_bytes()
final = (W / name).read_bytes()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert sha(original) == '369ec6aee4a86f42c2932aebb7c859fd11befe2a7b748b6c495886402357a53d'
assert sha(final) == '444f68e94a9adaaab0406b7402fb8029319bc192052b861f520b8982f89a4266'
pins = {name:sha(final),
    'competition/deepeye/integration/test_cpu_invocation_transcript.py':'ffe5f7e7158671889d6fd395382c10e78266adaa48a53acfe6a21646a1cb2ee9',
    'competition/deepeye/docs/cpu_invocation_transcript.md':'42fca58970a140c4b59423387231a7001837cf1236597df7413a0edde6478cfb'}
for path, pin in pins.items():
    raw = (W / path).read_bytes()
    assert sha(raw) == pin and b'\r' not in raw
    assert raw.endswith(b'\n') and not raw.endswith(b'\n\n')
    assert all(line.rstrip(b' \t') == line for line in raw.splitlines())
    if path.endswith('.py'): ast.parse(raw)
for filename, raw in [('original-module.py',original),('final-module.py',final)]:
    with (P / filename).open('xb') as f: f.write(raw)
diff = ''.join(difflib.unified_diff(original.decode().splitlines(True),final.decode().splitlines(True),
    fromfile='author-frozen/cpu_invocation_transcript.py',tofile='root-corrected/cpu_invocation_transcript.py'))
(P / 'correction.diff').write_text(diff,encoding='utf-8',newline='\n')
red = json.loads((P / 'attempt1-red/result.json').read_bytes())
green = json.loads((P / 'attempt2-green/result.json').read_bytes())
assert not red['passed'] and green['passed']
assert red['raised_type'] == 'JournalCloseFailure' and red['context_types'] == ['PreparedSyncFailure']
assert green['raised_type'] == 'PreparedSyncFailure'
for result in [red,green]:
    assert result['product_clock_calls'] == result['dispatch_calls'] == result['output_reads'] == 0
    assert result['journal_close_calls'] == 1
    assert result['duplicate_descriptors'] == result['closed_duplicate_descriptors']
value = dict(schema=1,utc=datetime.now(timezone.utc).isoformat(),
    original_sha256=sha(original),final_sha256=sha(final),final_owned_source_pins=pins,
    changed_product_files_after_author_freeze=1,unchanged_other_files=2,
    issue='prepared journal append/fsync failure followed by journal.close failure replaced the raised primary error; original survived only as exception context',
    correction='Catch journal close failure as a secondary note, re-raise original prepared failure; preserve outer once-per-duplicate cleanup unchanged',
    scope='actual local pipe descriptors and prepared journal; injected fsync and close errors; no product clock or request/output IO',
    original_author_14_method_evidence='still binds original369ec candidate; not rerun or relabeled as final444f evidence',
    intermediate_author_13_method_limit='prior complete sourcepins JSON was overwritten, so full intermediate source binding is not asserted or reconstructed',
    original_author_manifest_unchanged=True,
    commands=[dict(argv=['.local/venv/Scripts/python.exe','-B','-X','utf8',
        '.planning/deepeye-resume-20261018/cpu-transcript-root-constructor-probe-20261024/probe.py',
        '.planning/deepeye-resume-20261018/cpu-transcript-root-constructor-probe-20261024/'+attempt],
        observed_exit_code=exit_code) for attempt,exit_code in [('attempt1-red',1),('attempt2-green',0)]])
with (P / 'root-correction.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump(value,f,indent=2)
    f.write('\n')
print(json.dumps(dict(changed_product_files=1,unchanged_other_files=2,
    root_RED_exit=1,root_GREEN_exit=0,final_sha256=sha(final))))
