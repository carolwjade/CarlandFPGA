"""New constructor journal-cleanup fault control; no dispatch/read or clock call."""
from pathlib import Path
import hashlib
import json
import os
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
PRODUCT = ROOT / '.local/deepeye-implementation-a'
sys.path.insert(0, str(PRODUCT))
from competition.deepeye.integration import cpu_invocation_transcript as api


class PreparedSyncFailure(OSError):
    pass


class JournalCloseFailure(OSError):
    pass


def run(destination):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    journal = destination / 'actual-prepared.jsonl'
    source = PRODUCT / 'competition/deepeye/integration/cpu_invocation_transcript.py'
    result = dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        actual_scope='local constructor journal and duplicate descriptors; explicit fault seams',
        product_clock_calls=0, dispatch_calls=0, output_reads=0,
        duplicate_descriptors=[], closed_duplicate_descriptors=[], journal_close_calls=0,
        failed_fsync_calls=0)
    native_dup, native_close = os.dup, os.close
    readers_writers = (*os.pipe(), *os.pipe())
    real_file = None
    def duplicate(fd):
        value = native_dup(fd)
        result['duplicate_descriptors'].append(value)
        return value
    def close_duplicate(fd):
        result['closed_duplicate_descriptors'].append(fd)
        return native_close(fd)
    def fail_sync(fd):
        result['failed_fsync_calls'] += 1
        raise PreparedSyncFailure('original prepared journal sync failed')
    def forbidden_clock():
        result['product_clock_calls'] += 1
        raise AssertionError('constructor must not stamp time')
    def forbidden_write(*args):
        result['dispatch_calls'] += 1
        raise AssertionError('constructor must not dispatch')
    def forbidden_read(*args):
        result['output_reads'] += 1
        raise AssertionError('constructor must not read output')
    class Journal:
        def __init__(self, value): self.value = value
        def write(self, raw): return self.value.write(raw)
        def flush(self): return self.value.flush()
        def fileno(self): return self.value.fileno()
        def close(self):
            result['journal_close_calls'] += 1
            self.value.close()  # The real journal descriptor is closed once.
            raise JournalCloseFailure('secondary journal close failure after actual close')
    class JournalPath:
        def __init__(self, path): self.path = Path(path)
        def open(self, mode):
            nonlocal real_file
            assert mode == 'xb'
            real_file = self.path.open(mode)
            return Journal(real_file)
    identity = api.InvocationIdentity('A-CPU-CTOR-JOURNAL-20261024-01',
        '1'*64, '2'*40, '3'*64, 'new-root-probe', 1, 'local-pipe-only')
    try:
        with patch.object(api, 'Path', JournalPath), patch.object(api, 'monotonic_ns', forbidden_clock), \
                patch.object(api.os, 'dup', duplicate), patch.object(api.os, 'close', close_duplicate), \
                patch.object(api.os, 'fsync', fail_sync), patch.object(api.os, 'write', forbidden_write), \
                patch.object(api.os, 'read', forbidden_read):
            try:
                api.InvocationTranscript(readers_writers[1], readers_writers[2], identity,
                    request_raw=b'opaque-only', journal_path=journal,
                    max_output_bytes=8, max_reads=2, read_size=4)
            except BaseException as error:
                result['raised_type'] = type(error).__name__
                result['raised_text'] = str(error)
                result['notes'] = list(getattr(error, '__notes__', ()))
                chain = []
                context = error.__context__
                while context is not None:
                    chain.append(type(context).__name__)
                    context = context.__context__
                result['context_types'] = chain
        result['journal_file_closed'] = real_file is not None and real_file.closed
        result['original_descriptors_survive'] = all(os.fstat(fd) for fd in readers_writers)
        result['prepared_bytes_hex'] = journal.read_bytes().hex()
        checks = dict(primary_error_preserved=result.get('raised_type') == 'PreparedSyncFailure',
            both_duplicates_closed_once=(len(result['duplicate_descriptors']) == 2
                and result['closed_duplicate_descriptors'] == result['duplicate_descriptors']),
            journal_close_once=result['journal_close_calls'] == 1,
            real_journal_closed=result['journal_file_closed'],
            originals_survive=bool(result['original_descriptors_survive']),
            no_dispatch_read_clock=(result['dispatch_calls'] == result['output_reads'] == result['product_clock_calls'] == 0),
            secondary_failure_retained=any('JournalCloseFailure' in item for item in result['notes']))
        result['checks'] = checks
        result['passed'] = all(checks.values())
    finally:
        # Original caller descriptors were never transferred to the component.
        for fd in readers_writers:
            native_close(fd)
    (destination / 'result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k != 'prepared_bytes_hex'}, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    sys.exit(run(sys.argv[1]))
