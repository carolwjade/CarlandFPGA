"""Capture only the committed baseline and public frozen contract."""
import hashlib,json,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];PRODUCT=ROOT/'.local/deepeye-implementation-a'
BASE='360b102b299849a24a0b8cb2b6592f64f475e611'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(data):return hashlib.sha256(data).hexdigest()
paths=['integration/host_clock.py','integration/live_board_receipts.py','integration/boot_transcript.py',
 'integration/clock_bounds.py','simulation/authority/actor_composition.py','simulation/isolation/actor_owner.py',
 'simulation/isolation/actor_lifetime.py','simulation/authority/pc_direct_runtime.py',
 'simulation/authority/candidate_owner.py','simulation/authority/motion_executor.py',
 'integration/candidate_mailbox.py','integration/wire.py','docs/boot_profiles.json']
pins={}
for rel in paths:
    name='competition/deepeye/'+rel
    raw=subprocess.check_output([GIT,'-C',str(PRODUCT),'show',BASE+':'+name])
    dest=OUT/'baseline'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    pins[name]={'sha256':sha(raw),'bytes':len(raw)}
scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
requirements=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8'))
assert requirements=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=json.loads((ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json').read_text(encoding='utf-8'))
assert transfer['status']=='active' and transfer['director_generation']==3 and transfer['new_director_thread_id']=='01a16988-bdcb-70e1-ae10-1304b5cf7875'
decision_path=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024/cpu-invocation-transcript-decision.json'
decision=json.loads(decision_path.read_text(encoding='utf-8'));assert decision['base_commit']==BASE
(OUT/'public-frozen-contract.json').write_bytes(decision_path.read_bytes())
inputs={}
for rel in ['AGENTS.md','.agents/skills/fpga-multi-node/SKILL.md','.agents/skills/fpga-multi-node/skill-role.json',
 '.agents/skills/fpga-multi-node/references/protocol.md','.agents/skills/pynq-z2-single-node/SKILL.md',
 '.agents/skills/pynq-z2-single-node/skill-role.json','.planning/deepeye-desktop-handoff-20261015/transfer.json',
 'docs/competition/deepeye-2026/immutable_scope.md','docs/competition/deepeye-2026/immutable_scope.json']:
    raw=(ROOT/rel).read_bytes();inputs[rel]={'sha256':sha(raw),'bytes':len(raw)}
record={'schema':1,'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,
 'work_id':'A-CPU-INVOCATION-TRANSCRIPT-REVIEW-20261024-v1','job_id':'child-0d2f964c0c3f4f349e2c2842176e9bef',
 'agent_id':'/root/pc_direct_window_review','baseline_commit':BASE,'requirements_sha256':requirements,
 'contract_sha256':sha(decision_path.read_bytes()),'H01_H15_preserved':True,
 'baseline_files':pins,'inputs':inputs,'author_current_three_files_read':False,'tests_run':False,
 'actualclock_sleep_consume_model_actor_board_serial_UI_service_network':False,'native_complete_called':False}
(OUT/'phase1-source-pins.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'baseline_commit':BASE,'baseline_files':len(pins),'requirements_sha256':requirements,'contract_sha256':record['contract_sha256']}))
