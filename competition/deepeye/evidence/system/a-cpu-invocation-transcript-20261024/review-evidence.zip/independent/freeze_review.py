import hashlib,json,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];PRODUCT=ROOT/'.local/deepeye-implementation-a'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
original=load(OUT/'phase2-sourcehashes.json');final={}
for name,pin in original['candidate_sources'].items():
    raw=(PRODUCT/name).read_bytes();expected='444f68e94a9adaaab0406b7402fb8029319bc192052b861f520b8982f89a4266' if name.endswith('/cpu_invocation_transcript.py') else pin['sha256']
    assert sha(raw)==expected,name
    target=OUT/'final-source-snapshot'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    final[name]={'sha256':sha(raw),'bytes':len(raw),'author_original_sha256':pin['sha256'],'root_modified':expected!=pin['sha256']}
    assert b'\r' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n'),name
    assert all(line.rstrip(b' \t')==line for line in raw.splitlines()),name
for category in ['unchanged_dependencies','protected_files']:
    for name,pin in original[category].items():assert sha((PRODUCT/name).read_bytes())==pin['sha256'],name
for name,pin in load(OUT/'phase1-manifest.json')['files'].items():assert sha((OUT/name).read_bytes())==pin['sha256'],name
controls=load(OUT/'controls-execution.json');constructor=load(OUT/'constructor-control-execution.json')
assert controls['exit_code']==constructor['exit_code']==0
assert controls['module_sha256']==final['competition/deepeye/integration/cpu_invocation_transcript.py']['sha256']
for sub in ['attempt1-red','attempt2-green']:
    p=ROOT/'.planning/deepeye-resume-20261018/cpu-transcript-root-constructor-probe-20261024'/sub/'result.json'
    (OUT/('root-constructor-'+sub+'.json')).write_bytes(p.read_bytes())
scope=load(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
requirements=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
assert requirements==original['requirements_sha256']
check=subprocess.run([GIT,'-C',str(PRODUCT),'diff','--check','--',*final],capture_output=True);assert check.returncode==0
(OUT/'final-owned-diff-check.stdout').write_bytes(check.stdout);(OUT/'final-owned-diff-check.stderr').write_bytes(check.stderr)
record=dict(original,final_candidate_sources=final,root_revision='Only prepared journal cleanup primary-error preservation; 2 test/doc pins unchanged',
    phase1_oracle_unchanged=True,reviewer_controls_executed_only_on_root_final_pin=True)
(OUT/'final-sourcepins.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
result={'schema':1,'status':'independent_review_passed_after_root_constructor_primary_error_fix',
 'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'A-CPU-INVOCATION-TRANSCRIPT-REVIEW-20261024-v1',
 'job_id':'child-0d2f964c0c3f4f349e2c2842176e9bef','agent_id':'/root/pc_direct_window_review',
 'director':'01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3','base_commit':original['base_commit'],
 'requirements_sha256':requirements,'H01_H15_preserved':True,
 'frozen_controls':{'methods':9,'runs':1,'failures':0,'errors':0,'exit_code':0,'oracle_changed':False},
 'independent_constructor_control':{'methods':1,'runs':1,'failures':0,'errors':0,'exit_code':0},
 'reviewer_controls_executed_on_author_original_pin':False,'final_module_sha256':final['competition/deepeye/integration/cpu_invocation_transcript.py']['sha256'],
 'root_modified_files':1,'unchanged_test_doc_pins':2,'author_original_manifest_members':126,
 'unchanged_dependencies':16,'C_protected_files':4,'historical_intermediate13_complete_source_binding':'not established; original sourcepins superseded and not retained',
 'author_final14_source_scope':'author original 369ec module and original test/doc; not root444f',
 'root_red_primary_error':'PreparedSyncFailure retained in __context__ while JournalCloseFailure was raised',
 'root_final_primary_error':'PreparedSyncFailure raised; JournalCloseFailure retained as note',
 'final_sourcepins_sha256':sha((OUT/'final-sourcepins.json').read_bytes()),'report_sha256':sha((OUT/'report.md').read_bytes()),
 'harness_sha256':controls['harness_sha256'],'adapter_sha256':controls['adapter_sha256'],
 'actualclock_sleep_consume_model_actor_board_serial_UI_services_network':False,'old_or_author_tests_run':False,
 'root_probe_replayed':False,'product_writes_by_reviewer':False,'stage_commit':False,
 'completion_source_or_model_authority_established':False,'production_available':False,'formal_acceptance':False,'acceptance_owner':'A/root',
 'G03':'not_run','R03':'not_run','all29':'not_run'}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
excluded={'lease.private.json','artifact-manifest.json','freeze.json','native-complete-request.json','native-complete-receipt.json'}
files={}
for p in sorted(OUT.rglob('*')):
    if not p.is_file() or p.name in excluded:continue
    raw=p.read_bytes();files[p.relative_to(OUT).as_posix()]={'sha256':sha(raw),'bytes':len(raw)}
(OUT/'artifact-manifest.json').write_text(json.dumps({'schema':1,'files':files,'excluded':sorted(excluded),'lease_private_publish':False},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name,pin in files.items():assert sha((OUT/name).read_bytes())==pin['sha256'],name
freeze={'schema':1,'manifest_sha256':sha((OUT/'artifact-manifest.json').read_bytes()),'member_count':len(files),
 'result_sha256':sha((OUT/'result.json').read_bytes()),'report_sha256':result['report_sha256'],
 'all_members_readback_verified':True,'final_sourcepins_rechecked':True,'phase1_oracle_unchanged':True,
 'tests_rerun_by_freezer':False,'native_complete_not_yet_called':True}
(OUT/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n',encoding='utf-8');print(json.dumps(freeze))
