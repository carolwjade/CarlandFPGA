"""Phase2 fixture wiring only. Product state/snapshots are never synthesized."""
from contextlib import contextmanager,ExitStack
from dataclasses import asdict
import hashlib,importlib,json,os,sys
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];PRODUCT=ROOT/'.local/deepeye-implementation-a'
sys.path.insert(0,str(PRODUCT))
m=importlib.import_module('competition.deepeye.integration.cpu_invocation_transcript')
clocks=importlib.import_module('competition.deepeye.integration.host_clock')
READ,WRITE,FSYNC=os.read,os.write,os.fsync

def dispatch(s):return s['dispatch']
def reads(s):return s['reads']
def identity(s):return s['identity']
def request_parts(s):return s['request_raw_hex'],s['request_raw_sha256']
def known_bytes(s):return s['bytes_read']
def failed(s):return s['failed']
def closed(s):return s['closed']
def eof(s):return s['eof']
def read_index(row):return row['read_index']
def raw(row):return None if row['raw_hex'] is None else bytes.fromhex(row['raw_hex'])
def returned_count(row):return row['bytes_written'] if 'bytes_written' in row else row['returned_bytes']
def stream_start(row):return row['stream_start']
def raw_end(row):
    return row['raw_write_call_bracket_ns'][1] if 'raw_write_call_bracket_ns' in row else row['raw_read_call_bracket_ns'][1]
def uncertainty(s):return s['host_clock']['timestamp_uncertainty_ns']
def binding(value):return value.clock_domain
def callable(value):return value._clock

def make_identity():
    return m.InvocationIdentity('independent-cpu-raw','a'*64,'b'*40,'c'*64,'independent-run',1,'original-actor-label')

class Fixture:
    def initialize(self,request=b'opaque\x00independent-request\xff',max_output_bytes=4096,max_reads=8,read_size=8192,
                   legacy=False,host_clock_override=None):
        self.stack=ExitStack();self.transcript=None;self.fds=[];self.closed_setup=set()
        base=OUT/'fixture-evidence';base.mkdir(exist_ok=True);index=1
        while (base/('%04d'%index)).exists():index+=1
        self.directory=base/('%04d'%index);self.directory.mkdir();self.journal=self.directory/'invocation.jsonl'
        self.request=request;self.write_entries=self.read_entries=self.kernel_writes=self.kernel_reads=self.clock_leaf_calls=0
        self.value=100;self.fail_next_clock=None;self.fsync_returned=0;self.after_write=False
        self.marker_durable_at_write=False;self.actual_dispatch_bytes=b''
        self.hidden_write_witness=self.hidden_read_witness=None;self.captured=[]
        self.write_fault=self.read_fault=None;self.marker_fault=False;self.post_journal_fault=False
        self.input_reader,self.input_writer=os.pipe();self.output_reader,self.output_writer=os.pipe()
        self.fds=[self.input_reader,self.input_writer,self.output_reader,self.output_writer]
        os.set_blocking(self.input_reader,False);os.set_blocking(self.output_reader,False)
        self.stack.enter_context(patch.object(clocks,'_qpc_leaf',side_effect=self.clock_leaf))
        self.stack.enter_context(patch.object(clocks,'_qpc_capability',return_value={
            'implementation':'QueryPerformanceCounter()','monotonic':True,'adjustable':False,'resolution':1e-7}))
        self.stack.enter_context(patch.object(m,'monotonic_ns',self.clock_leaf))
        self.selected_legacy_module_leaf=m.monotonic_ns
        self.binding=None if legacy else clocks.qpc_clock_for_new_run()
        if host_clock_override is not None:self.binding=host_clock_override
        self.stack.enter_context(patch.object(m.os,'read',side_effect=self.read_boundary))
        self.stack.enter_context(patch.object(m.os,'write',side_effect=self.write_boundary))
        self.stack.enter_context(patch.object(m.os,'fsync',side_effect=self.fsync_boundary))
        self.identity_record=make_identity();self.supplied_identity=asdict(self.identity_record)
        self.args=dict(request_raw=request,journal_path=self.journal,max_output_bytes=max_output_bytes,
                       max_reads=max_reads,read_size=read_size,host_clock=self.binding)
        self.transcript=m.InvocationTranscript(self.input_writer,self.output_reader,self.identity_record,**self.args)

    def clock_leaf(self):
        self.clock_leaf_calls+=1
        if self.fail_next_clock is not None:
            exc=self.fail_next_clock;self.fail_next_clock=None;raise exc
        value=self.value;self.value+=1;return value
    def fsync_boundary(self,fd):
        if self.marker_fault:raise OSError('independent started-marker fsync failure')
        if self.post_journal_fault and self.after_write:raise OSError('independent post-write journal fsync failure')
        result=FSYNC(fd);self.fsync_returned+=1;return result
    def journal_rows(self):return [json.loads(line) for line in self.journal.read_text(encoding='utf-8').splitlines()]
    def has_durable_started_marker(self):
        return self.fsync_returned>=2 and any('outcome' in row and row['outcome']=='started_unknown' for row in self.journal_rows())
    def write_boundary(self,fd,data):
        self.write_entries+=1
        if self.write_entries>1:raise AssertionError('second dispatch OS boundary reached')
        rows=self.journal_rows()
        self.marker_durable_at_write=(self.fsync_returned>=2 and rows[-1]['outcome']=='started_unknown'
                                      and bytes.fromhex(rows[-1]['raw_hex'])==data)
        if not self.marker_durable_at_write:raise AssertionError('no returned fsync/started marker before write')
        if self.write_fault=='error':raise OSError('independent dispatch error')
        selected=data[:2] if self.write_fault in ('partial','hidden') else data
        self.kernel_writes+=1;count=WRITE(fd,selected)
        self.actual_dispatch_bytes+=selected[:count];self.after_write=True
        if self.write_fault=='hidden':
            self.hidden_write_witness=selected[:count];raise KeyboardInterrupt('independent hidden dispatch consumption')
        if self.write_fault=='post_stamp':self.fail_next_clock=ValueError('independent post-dispatch stamp failure')
        return count
    def read_boundary(self,fd,count):
        self.read_entries+=1
        if self.read_fault in ('hidden','post_stamp') and self.read_entries>1:
            raise AssertionError('second output OS boundary reached after failure; kernel read blocked')
        self.kernel_reads+=1
        value=READ(fd,count)
        if self.read_fault=='hidden':
            self.hidden_read_witness=value;raise KeyboardInterrupt('independent hidden output consumption')
        if self.read_fault=='post_stamp':self.fail_next_clock=ValueError('independent post-output stamp failure')
        return value
    def queue_output(self,value):WRITE(self.output_writer,value)
    def close_output_writer(self):
        os.close(self.output_writer);self.closed_setup.add(self.output_writer)
    def arm_partial_write(self,count):
        if count!=2:raise AssertionError('frozen independent partial fixture is exactly two bytes')
        self.write_fault='partial'
    def arm_write_error(self):self.write_fault='error'
    def arm_hidden_write_interrupt(self,count):
        if count!=2:raise AssertionError('frozen independent hidden fixture is exactly two bytes')
        self.write_fault='hidden'
    def arm_post_write_stamp_failure(self):self.write_fault='post_stamp'
    def arm_post_write_journal_failure(self):self.post_journal_fault=True
    def arm_marker_failure(self):self.marker_fault=True
    def arm_post_read_stamp_failure(self):self.read_fault='post_stamp'
    def arm_hidden_read_interrupt(self):self.read_fault='hidden'
    def replace_with_second_binding_for_fault(self):
        self.transcript._clock_domain=clocks.qpc_clock_for_new_run()
    def capture_failure(self,call):
        try:return call()
        except BaseException as error:self.captured.append(type(error).__name__);return None
    def original_descriptors_still_open(self):
        for fd in self.fds:
            if fd not in self.closed_setup:os.fstat(fd)
        return True
    def construct_same_journal(self):
        return m.InvocationTranscript(self.input_writer,self.output_reader,self.identity_record,**self.args)
    def cleanup(self):
        try:
            if self.transcript is not None:
                (self.directory/'snapshot.json').write_text(json.dumps(self.transcript.snapshot(),indent=2)+'\n',encoding='utf-8')
            meta=dict(write_entries=self.write_entries,read_entries=self.read_entries,kernel_writes=self.kernel_writes,
                kernel_reads=self.kernel_reads,clock_leaf_calls=self.clock_leaf_calls,
                marker_durable_at_write=self.marker_durable_at_write,fsync_returned=self.fsync_returned,
                actual_dispatch_hex=self.actual_dispatch_bytes.hex(),captured_exceptions=self.captured,
                hidden_write_witness_hex=None if self.hidden_write_witness is None else self.hidden_write_witness.hex(),
                hidden_read_witness_hex=None if self.hidden_read_witness is None else self.hidden_read_witness.hex())
            (self.directory/'fixture-witness.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
            if self.transcript is not None:self.transcript.close()
        finally:
            self.stack.close()
            for fd in self.fds:
                if fd not in self.closed_setup:os.close(fd)

@contextmanager
def fixture(**options):
    value=Fixture()
    try:value.initialize(**options)
    except BaseException:
        value.cleanup();raise
    try:yield value
    finally:value.cleanup()

def assert_no_authority(test,objects):
    def walk(value):
        test.assertNotIn(type(value).__name__,['_CompletedInference','BootBinding','VerifiedEnvelope','VerifiedObservation'])
        if isinstance(value,dict):
            if 'kind' in value:test.assertNotIn(value['kind'],['model_candidate','completion','boot_binding'])
            for key in ['authenticated','completion_verified','motion_authorized']:
                if key in value:test.assertIs(value[key],False)
            for child in value.values():walk(child)
        elif isinstance(value,(tuple,list)):
            for child in value:walk(child)
    walk(objects)
    snapshot=objects[1]
    test.assertIs(snapshot['authenticated'],False);test.assertIs(snapshot['completion_verified'],False)
    for key in ['availability_interval_ns','sample_interval_ns','completion_interval_ns']:test.assertIsNone(snapshot[key])

def protected_hashes():
    pins=json.loads((OUT/'phase1-source-pins.json').read_text(encoding='utf-8'))['baseline_files']
    return {name:hashlib.sha256((PRODUCT/name).read_bytes()).hexdigest()==pin['sha256'] for name,pin in pins.items()}
