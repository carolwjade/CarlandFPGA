"""Independent one-method primary/cleanup failure control, no root script replay."""
import hashlib,json,os,sys,unittest
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
import candidate_adapter as a
OUT=Path(__file__).resolve().parent

class PreparedControlFailure(OSError):pass
class JournalControlCloseFailure(RuntimeError):pass

class ConstructorControl(unittest.TestCase):
    def test_prepared_sync_primary_survives_actual_journal_close_failure(self):
        raw=(a.PRODUCT/'competition/deepeye/integration/cpu_invocation_transcript.py').read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(),'444f68e94a9adaaab0406b7402fb8029319bc192052b861f520b8982f89a4266')
        directory=OUT/'constructor-control';directory.mkdir(exist_ok=True)
        journal=directory/'independent-prepared-failure.jsonl'
        self.assertFalse(journal.exists(),'refuse to replay existing constructor attempt')
        in_r,in_w=os.pipe();out_r,out_w=os.pipe();originals=[in_r,in_w,out_r,out_w]
        duplicate,close,path_open=os.dup,os.close,Path.open
        state={'duplicates':[],'duplicate_close_calls':[],'journal_close_calls':0,'fsync_calls':0,'clock_leaf_calls':0}
        opened=[]
        class BrokenClose:
            def __init__(self,real):self.real=real
            def write(self,data):return self.real.write(data)
            def flush(self):return self.real.flush()
            def fileno(self):return self.real.fileno()
            def close(self):
                state['journal_close_calls']+=1
                self.real.close()
                raise JournalControlCloseFailure('actual file closed, seam reports cleanup failure')
        def opener(path,*args,**kwargs):
            if path!=journal:raise AssertionError('unexpected journal path')
            wrapper=BrokenClose(path_open(path,*args,**kwargs));opened.append(wrapper);return wrapper
        def dup(fd):
            value=duplicate(fd);state['duplicates'].append(value);return value
        def release(fd):
            if fd in state['duplicates']:state['duplicate_close_calls'].append(fd)
            else:raise AssertionError('source attempted to close a caller descriptor')
            return close(fd)
        def sync(fd):
            state['fsync_calls']+=1
            raise PreparedControlFailure('independent prepared fsync primary failure')
        def forbidden_clock():
            state['clock_leaf_calls']+=1;raise AssertionError('constructor must not sample clock')
        captured=None
        try:
            with patch.object(a.clocks,'_qpc_capability',return_value=dict(
                    implementation='QueryPerformanceCounter()',monotonic=True,adjustable=False,resolution=1e-7)),\
                 patch.object(a.clocks,'_qpc_leaf',side_effect=forbidden_clock):
                binding=a.clocks.qpc_clock_for_new_run()
                with patch.object(a.m.Path,'open',opener),patch.object(a.m.os,'dup',side_effect=dup),\
                     patch.object(a.m.os,'close',side_effect=release),patch.object(a.m.os,'fsync',side_effect=sync),\
                     patch.object(a.m.os,'write',side_effect=AssertionError('no dispatch')) as write,\
                     patch.object(a.m.os,'read',side_effect=AssertionError('no output read')) as read:
                    try:
                        a.m.InvocationTranscript(in_w,out_r,a.make_identity(),request_raw=b'constructor-only',
                            journal_path=journal,max_output_bytes=32,max_reads=1,read_size=8,host_clock=binding)
                    except BaseException as error:captured=error
                    self.assertIsInstance(captured,PreparedControlFailure)
                    self.assertTrue(any('JournalControlCloseFailure' in note for note in captured.__notes__))
                    self.assertEqual(write.call_count,0);self.assertEqual(read.call_count,0)
            self.assertEqual(len(state['duplicates']),2)
            self.assertEqual(state['duplicate_close_calls'],state['duplicates'])
            self.assertEqual(state['journal_close_calls'],1)
            self.assertEqual(state['fsync_calls'],1)
            self.assertEqual(state['clock_leaf_calls'],0)
            self.assertTrue(opened[0].real.closed)
            for fd in originals:os.fstat(fd)
            state.update(source_sha256=hashlib.sha256(raw).hexdigest(),raised_primary=type(captured).__name__,
                primary_notes=captured.__notes__,primary_context_type=None if captured.__context__ is None else type(captured.__context__).__name__,
                caller_descriptors_survived=True,dispatch_entries=0,output_read_entries=0,root_probe_replayed=False)
            (OUT/'constructor-cleanup-witness.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
        finally:
            for fd in originals:close(fd)
            for wrapper in opened:
                if not wrapper.real.closed:wrapper.real.close()

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ConstructorControl))
    raise SystemExit(0 if result.wasSuccessful() else 1)
