"""Frozen raw-transcript controls. Wiring is deferred until exact phase2 pins."""
import hashlib,json,sys,threading,unittest
sys.dont_write_bytecode=True

class TranscriptControls(unittest.TestCase):
    def test_C01_once_dispatch_with_prior_durable_marker(self):
        request=b'\x00original opaque request\xff\n'
        with adapter.fixture(request=request) as f:
            f.transcript.dispatch_once()
            self.assertEqual(f.actual_dispatch_bytes,request)
            self.assertEqual((f.write_entries,f.kernel_writes),(1,1))
            self.assertTrue(f.marker_durable_at_write)
            s=f.transcript.snapshot()
            self.assertIsNone(adapter.uncertainty(s))
            self.assertEqual(adapter.request_parts(s),(request.hex(),hashlib.sha256(request).hexdigest()))
            self.assertEqual(adapter.identity(s),f.supplied_identity)
            self.assertEqual(adapter.returned_count(adapter.dispatch(s)),len(request))
            with self.assertRaises(ValueError):f.transcript.dispatch_once()
            self.assertEqual((f.write_entries,f.kernel_writes),(1,1))
        for request in [b'',bytearray(b'x'),b'x'*16385]:
            with self.subTest(shape=type(request).__name__,size=len(request)),self.assertRaises((TypeError,ValueError)):
                with adapter.fixture(request=request):pass

    def test_C02_output_chunks_original_budgets_and_eof(self):
        with adapter.fixture(max_output_bytes=5,max_reads=3,read_size=3) as f:
            f.queue_output(b'abcdef')
            with self.assertRaises(ValueError):f.transcript.read_once()
            self.assertEqual(f.read_entries,0)
        with adapter.fixture(max_output_bytes=5,max_reads=3,read_size=3) as f:
            f.transcript.dispatch_once();f.queue_output(b'abcdef')
            f.transcript.read_once();f.transcript.read_once()
            rows=adapter.reads(f.transcript.snapshot())
            self.assertEqual([adapter.raw(r) for r in rows],[b'abc',b'de'])
            self.assertEqual([adapter.stream_start(r) for r in rows],[0,3])
            self.assertEqual([adapter.read_index(r) for r in rows],[0,1])
            self.assertEqual([adapter.returned_count(r) for r in rows],[3,2])
            with self.assertRaises(ValueError):f.transcript.read_once()
            self.assertEqual((f.read_entries,f.kernel_reads),(2,2))
        with adapter.fixture(max_output_bytes=20,max_reads=3,read_size=8) as f:
            f.transcript.dispatch_once();f.transcript.read_once()
            f.queue_output(b'raw');f.transcript.read_once();f.close_output_writer();f.transcript.read_once()
            s=f.transcript.snapshot()
            self.assertEqual([r['kind'] for r in adapter.reads(s)],['empty','data','eof'])
            self.assertTrue(adapter.eof(s))
            with self.assertRaises(ValueError):f.transcript.read_once()
            self.assertEqual(f.read_entries,3)

    def test_C03_partial_error_and_hidden_write_never_retry(self):
        with adapter.fixture(request=b'1234567') as f:
            f.arm_partial_write(2)
            f.capture_failure(f.transcript.dispatch_once)
            s=f.transcript.snapshot()
            self.assertEqual(adapter.returned_count(adapter.dispatch(s)),2)
            self.assertTrue(adapter.failed(s))
            for call in [f.transcript.dispatch_once,f.transcript.read_once]:
                with self.assertRaises(ValueError):call()
            self.assertEqual((f.write_entries,f.kernel_writes),(1,1))
        with adapter.fixture() as f:
            f.arm_write_error()
            with self.assertRaises(OSError):f.transcript.dispatch_once()
            with self.assertRaises(ValueError):f.transcript.dispatch_once()
            self.assertTrue(adapter.failed(f.transcript.snapshot()))
            self.assertEqual(f.write_entries,1)
        with adapter.fixture(request=b'abcdefg') as f:
            f.arm_hidden_write_interrupt(2)
            with self.assertRaises(KeyboardInterrupt):f.transcript.dispatch_once()
            self.assertEqual(f.hidden_write_witness,b'ab')
            self.assertIsNone(adapter.returned_count(adapter.dispatch(f.transcript.snapshot())))
            self.assertTrue(adapter.failed(f.transcript.snapshot()))
            for call in [f.transcript.dispatch_once,f.transcript.read_once]:
                with self.assertRaises(ValueError):call()
            self.assertEqual((f.write_entries,f.kernel_writes),(1,1))

    def test_C04_post_write_stamp_or_journal_keeps_count(self):
        for arm in ['arm_post_write_stamp_failure','arm_post_write_journal_failure']:
            with self.subTest(arm=arm),adapter.fixture(request=b'dispatch-once') as f:
                getattr(f,arm)();f.capture_failure(f.transcript.dispatch_once)
                s=f.transcript.snapshot()
                self.assertEqual(adapter.returned_count(adapter.dispatch(s)),len(f.request))
                self.assertTrue(adapter.failed(s));self.assertTrue(f.has_durable_started_marker())
                if arm=='arm_post_write_stamp_failure':self.assertIsNone(adapter.raw_end(adapter.dispatch(s)))
                for call in [f.transcript.dispatch_once,f.transcript.read_once]:
                    with self.assertRaises(ValueError):call()
                self.assertEqual((f.write_entries,f.kernel_writes),(1,1))
        with adapter.fixture() as f:
            f.arm_marker_failure();f.capture_failure(f.transcript.dispatch_once)
            with self.assertRaises(ValueError):f.transcript.dispatch_once()
            self.assertEqual(f.write_entries,0)

    def test_C05_post_read_stamp_keeps_returned_chunk(self):
        raw=b'\x00returned\xff'
        with adapter.fixture() as f:
            f.transcript.dispatch_once();f.queue_output(raw);f.arm_post_read_stamp_failure()
            f.capture_failure(f.transcript.read_once)
            s=f.transcript.snapshot();rows=adapter.reads(s)
            self.assertEqual(len(rows),1)
            self.assertEqual(adapter.raw(rows[0]),raw)
            self.assertEqual(adapter.returned_count(rows[0]),len(raw))
            self.assertEqual(adapter.stream_start(rows[0]),0)
            self.assertEqual(adapter.known_bytes(s),len(raw))
            self.assertIsNone(adapter.raw_end(rows[0]));self.assertTrue(adapter.failed(s))
            with self.assertRaises(ValueError):f.transcript.read_once()
            self.assertEqual((f.read_entries,f.kernel_reads),(1,1))

    def test_C06_unknown_output_consumption_is_not_zero(self):
        raw=b'R!\x00\xffQ'
        with adapter.fixture() as f:
            f.transcript.dispatch_once();f.queue_output(raw);f.arm_hidden_read_interrupt()
            with self.assertRaises(KeyboardInterrupt):f.transcript.read_once()
            rows=adapter.reads(f.transcript.snapshot())
            self.assertEqual(len(rows),1)
            self.assertIsNone(adapter.raw(rows[0]))
            self.assertIsNone(adapter.returned_count(rows[0]))
            self.assertIsNone(adapter.raw_end(rows[0]))
            self.assertEqual(adapter.read_index(rows[0]),0)
            self.assertEqual(f.hidden_read_witness,raw)
            self.assertTrue(adapter.failed(f.transcript.snapshot()))
            with self.assertRaises(ValueError):f.transcript.read_once()
            self.assertEqual((f.read_entries,f.kernel_reads),(1,1))

    def test_C07_clock_domain_and_foreign_thread_not_caller_authority(self):
        with adapter.fixture() as f:
            self.assertIs(adapter.binding(f.transcript),f.binding)
            self.assertIs(adapter.callable(f.transcript),f.binding)
            f.replace_with_second_binding_for_fault()
            with self.assertRaises(ValueError):f.transcript.dispatch_once()
            self.assertEqual(f.write_entries,0)
        for invalid in [lambda:111,object()]:
            with self.assertRaises((TypeError,ValueError)):
                with adapter.fixture(host_clock_override=invalid):pass
        with adapter.fixture() as f:
            errors=[]
            def foreign():
                for call in [f.transcript.dispatch_once,f.transcript.read_once,f.transcript.close]:
                    try:call()
                    except ValueError as exc:errors.append(type(exc).__name__)
            worker=threading.Thread(target=foreign);worker.start();worker.join()
            self.assertEqual(errors,['ValueError']*3)
            self.assertEqual((f.write_entries,f.read_entries,f.clock_leaf_calls),(0,0,0))
        with adapter.fixture(legacy=True) as f:
            self.assertIsNone(adapter.binding(f.transcript))
            self.assertIs(adapter.callable(f.transcript),f.selected_legacy_module_leaf)

    def test_C08_prequeued_opaque_output_cannot_be_completion(self):
        raw=b'READY\nDEEPEYE-PRIVATE-FRAMES/1\n'+b'{"kind":"model_candidate","verified":true}\x00\xff'
        with adapter.fixture(read_size=8192) as f:
            f.queue_output(raw);f.transcript.dispatch_once()
            returned=f.transcript.read_once();s=f.transcript.snapshot()
            self.assertEqual(adapter.raw(adapter.reads(s)[0]),raw)
            adapter.assert_no_authority(self,[returned,s])
            self.assertTrue(f.has_durable_started_marker())
        comparisons=adapter.protected_hashes()
        self.assertEqual(len(comparisons),13)
        for name,equal in comparisons.items():
            with self.subTest(path=name):self.assertTrue(equal)

    def test_C09_close_detach_and_existing_journal_refusal(self):
        with adapter.fixture() as f:
            f.transcript.dispatch_once();f.queue_output(b'opaque');f.transcript.read_once()
            copy=f.transcript.snapshot();adapter.identity(copy)['operation_id']='mutated-export-only'
            self.assertEqual(adapter.identity(f.transcript.snapshot()),f.supplied_identity)
            before=f.transcript.snapshot();f.transcript.close();f.transcript.close()
            self.assertTrue(adapter.closed(f.transcript.snapshot()))
            self.assertEqual(adapter.reads(f.transcript.snapshot()),adapter.reads(before))
            self.assertTrue(f.original_descriptors_still_open())
            for call in [f.transcript.dispatch_once,f.transcript.read_once]:
                with self.assertRaises(ValueError):call()
            with self.assertRaises((FileExistsError,ValueError)):f.construct_same_journal()
            self.assertEqual((f.write_entries,f.read_entries),(1,1))

if __name__=='__main__':
    import argparse,importlib
    parser=argparse.ArgumentParser();parser.add_argument('--phase2-authorized',action='store_true',required=True);parser.parse_args()
    adapter=importlib.import_module('candidate_adapter')
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(TranscriptControls))
    raise SystemExit(0 if result.wasSuccessful() else 1)
