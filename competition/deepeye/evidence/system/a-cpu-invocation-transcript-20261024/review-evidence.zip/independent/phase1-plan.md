# CPU raw invocation transcript 独立审查计划

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`；work `A-CPU-INVOCATION-TRANSCRIPT-REVIEW-20261024-v1`；agent `/root/pc_direct_window_review`；新job `child-0d2f964c0c3f4f349e2c2842176e9bef`已以新lease/canonical agent验证execution_allowed=true。仅本目录可写；产品全部只读，不使用已completed旧lease，不派工、不发外部消息。

已重读两项项目技能/A role/协作协议、transfer、immutable md及root公开冻结合同；A/fpga-main现场核对。Gen3 director `01a16988-bdcb-70e1-ae10-1304b5cf7875` active，H01–H15 requirements canonical UTF-8 ensure_ascii=False/sort_keys=True/compact SHA256=`c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`。A/root独占实板。

唯一基准commit `360b102b299849a24a0b8cb2b6592f64f475e611`。只以git show读取13个已发表保护源/文档，固定hash，不重跑QPC/BOOT或旧组。公开合同SHA256=`02bc0c30d586e41f2c3cd5a78f15a13edf002eca4e0bef5167fbb1e6fed6393b`。作者正在写的3个新文件均未读；phase2只有root确认terminal并给exact pins后才解封。

## 最高结论与既定范围

新模块只记录一次原始本地OS dispatch/output及journal事实。相关operation/package/run/invocation/actor标签、hash与registry身份不证明真实模型/actor/执行、因果性或新鲜度。原output即使预排队、包含READY、候选样式JSON或 `DEEPEYE-PRIVATE-FRAMES/1` 字节，也只是opaque bytes，不能产生completion/source authority。不采用inactive framing格式，不改生产gate/API/actor、时间区间类型或scalar deadline规则。

## 冻结的9组少量控制

| 组 | 独立刺激与固定预期 |
|---|---|
| C01 dispatch once/durable | 原exact请求含NUL/0xff，原identity在detached snapshot不变；OS write边界现场读取journal确认started_unknown已flush/fsync；唯一actual write为原request。第二dispatch拒绝，无remainder/retry。空/bytearray/16385B请求拒绝；16384B合法形状由source/边界审读，不循环写满pipe。|
| C02 原output/预算 | read在dispatch前拒绝且零OSread；随后原chunk按read_size/剩余byte预算截取，offset/index连续，count/raw正确；耗尽bytes或reads拒绝下一入口。正常empty/data/EOF区分，EOF后永久不再read。|
| C03 partial/error/hidden write | partial返回2 bytes保存count=2并退休，不能补写/读输出。OSerror拒绝且不重发。wrapper实际写入前缀后KeyboardInterrupt：原durable started_unknown保留，未返回的count为None，外部witness另存；第二dispatch/read拒绝、无第二kernel write。|
| C04 dispatch后stamp/journal | actual write已返回后stamp故障：原request/returned count保留、end unknown，journal原started_unknown保留。post-write journal失败同样不能改成未写或再发；marker/prestamp故障则0次actual write且不能第二attempt。|
| C05 read后stamp故障 | actual read返回原chunk后末stamp故障，raw/count/offset与已消耗read/byte预算保存，end unknown/failed；第二read拒绝。不填begin=bad end，不用100ns advertisedresolution补interval。|
| C06 hidden read interruption | actual kernel read仅一次取走5字节后wrapper抛KeyboardInterrupt；模块unknown read条目占用read预算，raw/count为None、end unknown、failed。已知返回前缀累计不是kernel未消耗的证明；外部witness单独留存5 bytes。第二read被source拒绝，不能只让spy阻止第二真实读。|
| C07 domain/线程 | 同一existing exactQPC binding稳定贯穿；None仅legacy标记，其实际_clock保持原monotonic路由。普通callable/伪domain拒绝，原binding被第二binding替换在IO前拒绝；foreign-thread dispatch/read/close不能执行clock或IO。所有取时使用script私有leaf，无actualclock。|
| C08 opaque/prequeued不晋升 | 输出在dispatch前已排队，含READY、inactive frame magic及候选样式JSON；正常dispatch/read后仅保留原bytes。没有completion framing/parser/模型候选/BootBinding/_CompletedInference/source认证结果；仅raw输出不证明该次dispatch因果性。13个既有保护源/文档hash保持，不重证明旧QPC/BOOT/actor门。|
| C09 close/detach/no resume | snapshot嵌套身份/输出修改不改变原记录；same-owner close只关duplicate及新journal一次，原descriptor仍有效，snapshot保留；closed后read/write拒绝，不重开journal。相同已存在journal_path的重新构造拒绝，不resume/adopt/replay。|

预期以公开合同/字面原bytes和调用计数为oracle，不从作者测试、实现输出或“成功布尔”倒推。phase2的 `candidate_adapter.py` 只允许按 `adapter-contract.md` 接线和读取实际字段；不能用dict.get伪造None/通过、忽略预算/错误或改变阈值。若冻结前提确有歧义，先保留实际失败，root明确审定后才做限定delta，不改产品。

本阶段仅AST parse并冻结计划/harness，未运行任何测试/时钟/模型/IO。phase2只运行本目录新增9组；实际有限local OS pipe/journal和scripted-clock/private syscall故障seam，无actualclock/sleep/consume/model/actor/板/串口/UI/服务/网络/产品写入。已知返回与未知消费严格区分，所有原错误和首次输出保留。

准备后结束回合，lease保持running等root followup，无模型轮询。phase2最终report/result/sourcepins/manifest冻结后才native_complete。即使控制通过，也仅为raw transcript有限软件证据；无production/来源/实质AI/physical deadline/真实板联动验收，`G03/R03/all29=not_run`。正式接受与发布归root。
