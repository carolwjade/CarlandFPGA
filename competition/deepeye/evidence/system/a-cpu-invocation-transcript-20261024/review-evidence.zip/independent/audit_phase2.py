import hashlib,json,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];PRODUCT=ROOT/'.local/deepeye-implementation-a'
AUTHOR=OUT.parent/'cpu-invocation-transcript-20261024';BASE='360b102b299849a24a0b8cb2b6592f64f475e611'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
candidate=load(OUT.parent/'gen3-live-integration-20261024/cpu-transcript-phase2-candidate.json')
assert candidate['base_commit']==BASE
assert sha((AUTHOR/'source-pins.json').read_bytes())==candidate['author_sourcepins_sha256']=='2082b20b7dcc0c85744b4e94d702ce2000dc5f4d3f0b63bf11b62fd51f08d1f4'
assert sha((AUTHOR/'artifact-manifest.json').read_bytes())==candidate['author_manifest_sha256']=='ae3f5208e3eca762eb36c3f8c52d4a29a9df034d9b32579f934e959a6f750948'
manifest=load(AUTHOR/'artifact-manifest.json');assert len(manifest['files'])==126
for name,pin in manifest['files'].items():
    p=AUTHOR/name;assert p.resolve().is_relative_to(AUTHOR.resolve())
    raw=p.read_bytes();assert sha(raw)==pin['sha256'] and len(raw)==pin['bytes'],name
for name,pin in load(OUT/'phase1-manifest.json')['files'].items():assert sha((OUT/name).read_bytes())==pin['sha256'],name
sources={}
for name,digest in candidate['final_pins'].items():
    raw=(PRODUCT/name).read_bytes();assert sha(raw)==digest and raw==(AUTHOR/'source-snapshot'/name).read_bytes(),name
    p=OUT/'source-snapshot'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    sources[name]={'sha256':digest,'bytes':len(raw)}
pins=load(AUTHOR/'source-pins.json');deps={};protected={}
for name,pin in pins['source'].items():
    if name in sources:continue
    raw=(PRODUCT/name).read_bytes();original=subprocess.check_output([GIT,'-C',str(PRODUCT),'show',BASE+':'+name])
    assert sha(raw)==pin['sha256']==sha(original),name
    deps[name]={'sha256':sha(raw),'bytes':len(raw)}
assert len(deps)==16
for name,digest in pins['protected_files_sha256'].items():
    assert sha((PRODUCT/name).read_bytes())==digest,name
    protected[name]={'sha256':digest}
scope=load(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
req=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
assert req=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
record={'schema':1,'base_commit':BASE,'candidate_sources':sources,'unchanged_dependencies':deps,'protected_files':protected,
 'author_manifest_members_verified':126,'author_manifest_sha256':candidate['author_manifest_sha256'],
 'author_sourcepins_sha256':candidate['author_sourcepins_sha256'],'author_report_sha256':sha((AUTHOR/'report.md').read_bytes()),
 'requirements_sha256':req,'historical_intermediate13_sourcepins_retained':False,
 'historical_intermediate13_exact_full_source_binding':'not established; do not reconstruct',
 'tests_run_by_this_audit':False,'product_writes':False}
(OUT/'phase2-sourcehashes.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
for name in ['report.md','raw-readback.json','execution-notes.json','late-veto-fix.diff']:
    (OUT/('author-'+name)).write_bytes((AUTHOR/name).read_bytes())
print(json.dumps({'sources':len(sources),'dependencies':len(deps),'protected':len(protected),'manifest_members':126,'author_report_sha256':record['author_report_sha256']}))
