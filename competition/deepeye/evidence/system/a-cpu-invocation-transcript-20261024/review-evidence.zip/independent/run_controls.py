import hashlib,json,os,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];PRODUCT=ROOT/'.local/deepeye-implementation-a'
def sha(raw):return hashlib.sha256(raw).hexdigest()
frozen=json.loads((OUT/'phase1-manifest.json').read_text(encoding='utf-8'))
for name,pin in frozen['files'].items():assert sha((OUT/name).read_bytes())==pin['sha256'],name
assert sha((PRODUCT/'competition/deepeye/integration/cpu_invocation_transcript.py').read_bytes())=='444f68e94a9adaaab0406b7402fb8029319bc192052b861f520b8982f89a4266'
command=[str(ROOT/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(OUT/'independent_controls.py'),'--phase2-authorized']
assert not (OUT/'controls-execution.json').exists()
run=subprocess.run(command,cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True)
(OUT/'controls-stdout.log').write_bytes(run.stdout);(OUT/'controls-stderr.log').write_bytes(run.stderr)
record={'command':command,'exit_code':run.returncode,'test_methods':9,
 'harness_sha256':sha((OUT/'independent_controls.py').read_bytes()),'adapter_sha256':sha((OUT/'candidate_adapter.py').read_bytes()),
 'module_sha256':'444f68e94a9adaaab0406b7402fb8029319bc192052b861f520b8982f89a4266',
 'stdout_sha256':sha(run.stdout),'stderr_sha256':sha(run.stderr),'old_or_author_tests_run':False,
 'actualclock_sleep_consume_model_actor_board_UI_network':False}
(OUT/'controls-execution.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(run.stderr.decode('utf-8',errors='replace'));print(json.dumps(record))
raise SystemExit(run.returncode)
