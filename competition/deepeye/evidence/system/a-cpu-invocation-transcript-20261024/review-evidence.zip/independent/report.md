# CPU raw invocation transcript 独立限定复核

最终root修正版的 **冻结9组独立控制及新增1组constructor双故障控制全部通过**，两次命令均exit 0、零failures/errors。原9组oracle未改，也没有先在旧源执行后把结果改绑新源。本轮没有发现这些有限控制之外可据以宣称生产、模型或completion来源成立的证据；正式接受/发布由root决定。

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，work `A-CPU-INVOCATION-TRANSCRIPT-REVIEW-20261024-v1`，canonical agent `/root/pc_direct_window_review`，新job `child-0d2f964c0c3f4f349e2c2842176e9bef` 实际新lease validate返回execution_allowed=true。未复用已completed租约。两项项目技能/Arole/协议、Gen3 transfer和immutable md/json已重核，当前A/fpga-main、director `01a16988-bdcb-70e1-ae10-1304b5cf7875` active。requirements canonical UTF-8 ensure_ascii=False/sort_keys/compact实算为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，H01–H15、原29卡与A/root独占实板保留。

## 准确来源与版本

基准commit `360b102b299849a24a0b8cb2b6592f64f475e611`。phase1仅git show读取13个已发表保护源/文档，未看作者正在写的3文件；公开冻结合同SHA256=`02bc0c30d586e41f2c3cd5a78f15a13edf002eca4e0bef5167fbb1e6fed6393b`。phase1计划、adapter边界和原9组harness冻结manifest有19成员，SHA256=`3b674b6f7efba1958702e9b107b961c38178da55eab19d0fa422e56c06971b88`。实际执行的原harness仍SHA256=`08af49e5a702bcddf006b5f07e0d86ed4d0d50cf34e48a0fb1fb2aa281446a9d`，无oracle delta。

root确认作者terminal并解封后，实算核对126个作者manifest成员（不含manifest本身）、3个原source-snapshot/当前源、16个基准依赖和4个C保护字节。作者原manifest SHA256=`ae3f5208e3eca762eb36c3f8c52d4a29a9df034d9b32579f934e959a6f750948`；source-pins SHA256=`2082b20b7dcc0c85744b4e94d702ce2000dc5f4d3f0b63bf11b62fd51f08d1f4`；report SHA256=`444e3839ee32486f02c0fa67ac5bda97dcea705262df29d9d9555b9a85520643`。作者两测试/文档及全部原记录只读，未运行其14方法9子控制或旧组。

作者原module SHA256=`369ec6aee4a86f42c2932aebb7c859fd11befe2a7b748b6c495886402357a53d`。root之后仅修该module的内层journal cleanup，最终为 **`444f68e94a9adaaab0406b7402fb8029319bc192052b861f520b8982f89a4266`**；test SHA256=`ffe5f7e7158671889d6fd395382c10e78266adaa48a53acfe6a21646a1cb2ee9`、doc SHA256=`42fca58970a140c4b59423387231a7001837cf1236597df7413a0edde6478cfb` 不变。作者原126工件、原snapshot不重写。原/最终module副本、root最小delta和最终3pins分别保存，不能说作者14方法跑在root新pin上。

作者中间13方法GREEN的完整source-pins JSON被final覆盖，未另存；原日志/结果仍在，但该历史run的完整精确source绑定**未建立**。本复核不重构其工件或把重构物叫原件。作者final14对其原369ec三文件有新鲜完整绑定；本复核9+1对root最终444f三文件另行绑定。历史12/13、作者final14、root新probe、独立9+1严格分开。

## 实际独立执行

`run_controls.py` 只运行本目录冻结9方法；新增 `constructor_cleanup_control.py` 只运行1方法。原始stdout/stderr、参数数组、exit code、harness/adapter/source hashes留存在各execution.json/log。现有venv、禁bytecode，无安装依赖。adapter仅导入新module与已发表host_clock；不导入作者或旧TestCase。私有clock/capability全由script供值，无实际clock/capability查询、sleep、policy consume、模型、actor、板、串口、UI、服务、网络、再派工、产品编辑或stage/commit。

测试使用实际有限local OS pipe/journal。setup preload、产品OS入口、真实kernel call、隐藏消费witness分别计数；unknown失败后若实现错误地再次到OS入口，spy在第二真实read/write前拒绝。所有fixture原journal/snapshot/witness保存于本目录。

| 组 | 实际结果 |
|---|---|
| C01 | exact含NUL/0xff请求、身份/hash保留；write边界读原journal确认started_unknown与已返回flush/fsync先于唯一write；第二dispatch拒绝；非法请求形状拒绝。|
| C02 | dispatch前零read；原字节按3+2预算截取，offset0/3、index0/1、counts3/2；bytes/read预算、empty/data/真实EOF及后续拒绝通过。|
| C03 | 实际partial2字节保存count2并退休，不补写/读；OSerror不重试；实际写入前缀后KeyboardInterrupt保留None returned count，外部witness另存，第二IO拒绝。|
| C04 | 实际write返回后stamp或journal故障仍保留原request/count与started_unknown；末stamp未知、不重发。marker故障零write。|
| C05 | 实际read返回后末stamp故障保留原chunk/count/offset/已用预算，end未知、failed；第二read拒绝。|
| C06 | 实际kernel read一次取走5字节后抛KeyboardInterrupt，原read预算/unknown条目保留，raw/count/end仍None；外部witness证明5字节，未倒灌source，第二read入口拒绝。|
| C07 | actual stored callable/domain为同一QPC binding；legacyNone标记与其selected模块monotonic callable分开核验；第二domain/普通callable拒绝；foreign-thread dispatch/read/close零clock/IO。|
| C08 | 预排队READY、inactive frame magic和候选样式JSON仅作为原raw bytes保存，无candidate/BOOT/completion/source authority；13个原保护源/文档hash相同。|
| C09 | detached身份修改不改原值；close两次只关闭owned资源，调用者descriptor存活，snapshot保留；closed IO及同journal reopen拒绝。|
| 新constructor控制 | prepared fsync主故障加实际journal close后再次抛错，最终仍抛PreparedControlFailure并以note留JournalControlCloseFailure；journal实际close1、两duplicate各close1、4个caller fd存活，clock/dispatch/read均0。|

known returned prefix的bytes_read不代表未知kernel消费为零。raw/count=None是实际未知，不能由测试witness、READY内容、标签或advertised100ns resolution补齐。所有测量/availability/sample/completion interval仍None。flush/fsync返回仅为OS调用观察，不是独立断电持久性测量。

## root constructor 缺陷与最终修正

root在原369ec上用新有限故障probe确认：prepared `_append` 的PreparedSyncFailure发生后，journal.close再次抛JournalCloseFailure，原代码把后者作为抛出的主异常。原PreparedSyncFailure仍留在 `__context__`，不能称其完全丢失。两duplicate/journal关闭次数与caller fd存活原本已正确；本次缺陷是主异常优先级。

root只将内层except改为捕获原error，journal close异常加入原error的note，再bare raise原error。root RED/GREEN原记录只读复制，未重跑其probe。独立新增控制使用不同异常类/identity/fixture实现，同样确认原primary保留、secondary note可见且资源各关闭一次。准确差异在 `root-constructor-fix.diff`；没有改变dispatch/read、预算、clock、veto或authority语义。

作者已保留的constructor duplicate-cleanup、初始clock未知、late-veto RED与原失败源保持。最终source中永久veto与临时I/O latch分开，未来入口和snapshot均检查veto；本轮通过准确源审读与未变差异核对保留其含义，不把作者late-veto测试说成本复核执行过。

新module只有raw OS I/O诊断，不解析或自动采用DEEPEYE-PRIVATE-FRAMES/1，不生成model_candidate/_CompletedInference/BootBinding，不变更原ActorRegistry/lifetime/composition/runtime/mailbox/executor/ABI/profile/clock代码或生产门。16个依赖与C4字节最终重核一致。本轮不重新证明已发表QPC/BOOT或旧系统行为。

最终3pins和工件manifest在当前review native_complete前冻结。结论仅限上述raw transcript软件控制；关联hash/actor标签、预排队输出和普通OS读写均不证明真实模型、invocation因果性、原完成/源测时、AI收益或生产可运行。H01–H15、完整3D/UI、两条完整H12和原29卡保持，`G03/R03/all29=not_run`。root拥有正式接受与发布。
