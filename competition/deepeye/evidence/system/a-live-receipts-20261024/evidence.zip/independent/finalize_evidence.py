"""Readback/pin public evidence only. Never read/export the private lease."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCT = ROOT / '.local/deepeye-implementation-a'
result = json.loads((OUT / 'result.json').read_text(encoding='utf-8'))
delta = json.loads((OUT / 'delta-controls-result.json').read_text(encoding='utf-8'))
assert delta['successful'] and delta['tests'] == 4 and not delta['failures'] and not delta['errors']
assert delta['source_unchanged']
assert result['canonical_contract'] == 'DEEPEYE-HUMAN-LOCK-20261014/revision1'
assert result['requirements_sha256'] == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
actual = {}
for name, expected in result['final_source_pins'].items():
    raw = (PRODUCT / name).read_bytes()
    actual[name] = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
    assert actual[name] == expected, 'parent product changed after delta: ' + name
after = OUT / 'source-after'
after.mkdir(exist_ok=True)
for name in list(actual)[:3]:
    raw = (PRODUCT / name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == actual[name]['sha256']
    (after / Path(name).name).write_bytes(raw)
check = dict(verified=True, source_pins=actual, delta_tests=4, delta_errors=0,
             initial_failures_preserved=True, credential_files_excluded=True)
(OUT / 'finalization-check.json').write_text(json.dumps(check, ensure_ascii=False, indent=2), encoding='utf-8')
entries = []
for path in sorted(OUT.rglob('*')):
    if not path.is_file() or '.private.' in path.name or '__pycache__' in path.parts:
        continue
    if path.name in {'manifest.json', 'native-complete.json'}:
        continue
    raw = path.read_bytes()
    entries.append(dict(path=path.relative_to(OUT).as_posix(), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw)))
manifest = dict(schema=1, work_id=result['work_id'], entries=entries,
                excluded=['lease.private.json', 'manifest.json', 'native-complete.json', '__pycache__'],
                scope='public independent review evidence; native completion is saved after this manifest')
(OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
for entry in entries:
    assert hashlib.sha256((OUT / entry['path']).read_bytes()).hexdigest() == entry['sha256']
summary = dict(entries=len(entries), all_entries_verified=True,
    result_sha256=hashlib.sha256((OUT / 'result.json').read_bytes()).hexdigest(),
    report_sha256=hashlib.sha256((OUT / 'report.md').read_bytes()).hexdigest(),
    manifest_sha256=hashlib.sha256((OUT / 'manifest.json').read_bytes()).hexdigest(),
    final_source_sha256=actual['competition/deepeye/integration/live_board_receipts.py']['sha256'])
print(json.dumps(summary, ensure_ascii=False, indent=2))
