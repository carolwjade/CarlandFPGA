# Independent receipt review — original failure evidence

Task `DEEPEYE-IMPLEMENTATION-20261014/v1`; work `A-LIVE-RECEIPTS-REVIEW-20261024-v1`; agent `/root/live_receipts_review`. Native validation allowed execution before project work. Base head `66913fa61270b4e61d453c245d927824548bc267`; the three reviewed files were uncommitted root-owned additions.

Status at 2026-10-23 16:37:32 UTC: two related correctness findings reproduced. Root has requested a bounded repair and delta review; this report preserves the original failure and is not a final acceptance decision. No product, board, service, peer, UI or credential operation was performed. All child writes are within this review directory.

## Scope and pins

Read the project AGENTS, both installed project skills and A roles, collaboration protocol, authoritative active generation3 transfer and current handoff, and immutable md/json. Canonical requirements SHA-256 computed with UTF-8, `ensure_ascii=False, sort_keys=True, separators=(',', ':')` is `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`; H01–H15 unchanged.

Original files (same bytes before and after both independent control runs):

| File | SHA-256 | Bytes |
|---|---|---:|
| integration/live_board_receipts.py | 8cd86fb97e48f6234b0d5a50bb56afd36dd9f9dc086c2e81d5572e84cc5dc83a | 10266 |
| integration/test_live_board_receipts.py | dc42e1fb855072b3048c4b6534baa6b3c34cd69e2485980ed42bbd5aecbf0098 | 6441 |
| docs/live_board_receipts.md | 180754f4bd02342afb26d3985d2df03ab52769c26547f8790d1d07dcc2ca158e | 4113 |

Full pins, actual Python/runtime, read snapshots, raw packets and exact intervals are in `controls-result.json` and `observations.json`. Original source/doc bytes are additionally retained in `source-before/`; the author test began changing for root's new RED control before the optional snapshot, so its original hash above remains authoritative for these runs.

## Findings

**F1 — recovered frame offsets are inferred from the newest tail (lines 134–144).** A corrupt yet legal-looking type12/length27 header can hold a valid independently CRC-built STATE. The 41-byte stream is `a55a030c1b + STATE32 + JUNK`. The original decoder recovers the STATE at literal stream range `[5,37)` only once the outer candidate is rejected at byte41. The ledger instead takes the newest32 bytes, `[9,41)`, and raises `wrong magic or ABI version` at line139. The good original frame is consumed from the decoder but never receives a receipt. See `controls.log` and `observations.json:nested_recovery`. This is an original-byte/span recovery failure, not a CRC acceptance or authentication bypass.

**F2 — this parser exception leaves the capture usable with false byte accounting (lines 123–141).** In the single targeted followup, set `max_bytes=73` and write the above41 bytes followed by another valid32-byte STATE. One OS read consumes all73 bytes (journal retains them; a separate real read finds the kernel empty), but the exception interrupts the per-byte accounting at41 and leaves `failed=false`. A new32-byte write is then accepted: actual journal bytes total105, while snapshot reports73, so the configured73-byte bound is violated. The new frame's stream coordinates are `[41,73)` rather than the journal's `[73,105)`. See `followup-recovery-result.json` and `followup-recovery.log`. The bad accounting is a follow-on effect of F1 combined with failure handling.

Root was informed with exact reproduction and source hash, and is deciding/implementing the correction. The review requirement for a repair is that frame location, last-byte read provenance, full OS-read accounting and terminal parser errors remain consistent even when recovery is delayed.

## New independent controls and limits

Only `review_controls.py` ran (7 tests,6 passed,1 error, exit1), followed by one new targeted `followup_recovery.py` check (violated budget invariant, exit1). Original failures are retained. The root author's9 tests and all earlier software/board groups were not executed.

The six passing controls covered partial EOF and original retained fragments; partial byte-budget stop with remaining bytes still in the actual kernel pipe; finite empty-read budget; foreign-thread claim/snapshot/close rejection without mutation; split frame across an actual EAGAIN with exact raw spans and null sample/physical timing; repeated identical bytes entering the OS as two separate receipts; and permanent consumption after failed schema translation.

The replay positive control deliberately shows this layer has no anti-replay proof: identical pipe input can produce two separately claimable schema records. Documentation correctly requires upstream authenticated BOOT/context and external freshness/history. The EAGAIN control establishes descriptor complete-frame availability only, with no source/sample time or physical-capture reference; the claim remains JSON bytes. No VerifiedEnvelope/VerifiedObservation, motion grant, physical timing, FPGA capture, production gate, H09/H12/G03/R03 or all29 acceptance follows from these software controls.

## Continuation fence

Parent instructed this lease to remain running until a narrow delta review after root's targeted RED/fix. Do not rerun the original7 controls or erase the two original exit1 results. G03/R03/all29 remain `not_run`.

