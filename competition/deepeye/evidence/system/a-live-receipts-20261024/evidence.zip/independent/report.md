# Independent original-receipt review

The original two related defects were reproduced and then addressed by root. The independent repair delta controls pass4/4 at source `ebd24a6a53710a1e2d8c24d13bd64fafed8b03ff27f8382935dc2ea0c75cfe4e`. No additional material finding remains in the assigned delta scope. This reports software evidence to the main; it is not product, board or card acceptance.

Task `DEEPEYE-IMPLEMENTATION-20261014/v1`; work `A-LIVE-RECEIPTS-REVIEW-20261024-v1`; agent `/root/live_receipts_review`; job `child-3ef63c75dd85451f8bc78c089c784de3`. Execution authorization was validated before project work. Product base remains `66913fa61270b4e61d453c245d927824548bc267`; reviewed additions are uncommitted pending root integration. Report time: 2026-10-23 16:42:18 UTC.

## Exact reviewed bytes

| Product file | Final SHA-256 | Bytes |
|---|---|---:|
| competition/deepeye/integration/live_board_receipts.py | ebd24a6a53710a1e2d8c24d13bd64fafed8b03ff27f8382935dc2ea0c75cfe4e | 11483 |
| competition/deepeye/integration/test_live_board_receipts.py | 96b1bfea33bfdbddfa9a7d53ee84aaf000f92fc54a4f7df759a40fa6e5fbeef3 | 8013 |
| competition/deepeye/docs/live_board_receipts.md | 29103e9dfdd56c18b16a82559d63fad9f85cac5e5b563493aac44dea2d3db304 | 4602 |

Before and after each independent run pins match. Initial/final full pins, including unchanged `wire.py` and `host_envelope.py`, are retained in `controls-result.json` and `delta-controls-result.json`. Root alone changed the product. This child wrote only within this review directory, did not run root author tests/old groups, and did not touch services, board, display, peer, group, providers or credentials.

Read root AGENTS, both installed project skills and A roles, protocol, authoritative generation3 transfer/current handoff and immutable scope md/json. The computed UTF-8 canonical requirements hash is `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`; H01–H15 remain unchanged.

## Reproduced findings and repair evidence

**F1: delayed decoder recovery picked the wrong original bytes.** At original hash `8cd86fb97e48f6234b0d5a50bb56afd36dd9f9dc086c2e81d5572e84cc5dc83a`, `a55a030c1b + independently CRC-built STATE32 + JUNK` produces a legal-looking41-byte corrupt outer candidate. The existing decoder correctly finds STATE at `[5,37)`; the ledger incorrectly picked the newest32 bytes `[9,41)` and raised `wrong magic or ABI version`. Original single-run7-control log:6 passed/1 error, exit1. See `initial-report.md`, `controls.log`, `observations.json`.

**F2: the same exception undercounted OS reads and left the capture active.** The one new followup configured73 bytes. The first real read consumed73 but exception left `bytes_read=41,failed=false`. It accepted another32 bytes: raw journal105 versus reported/budget73, and wrong stream coordinates for the next receipt. Followup exit1 and exact raw snapshots are preserved in `followup-recovery-result.json` and `followup-recovery.log`.

Root repaired only the receiving source path and added focused author regressions. Source review confirms full OS-read accounting before parsing, terminal capture failure on parser exceptions, locating actual original recovered packets after the previous receipt, and binding descriptor timing to the packet's actual last-byte read. The original ABI decoder and envelope validator were not changed.

Independent post-repair controls ran once,4/4 passed, exit0:

1. Two identical18-byte frames embedded in one corrupt41-byte candidate are recovered at distinct original ranges after one recovery step; both exact spans reconstruct across two reads.
2. A73-byte OS read containing delayed-recovered STATE plus the next STATE is completely counted. Both ranges are correct; another read is denied at budget and additional bytes remain in the real kernel pipe.
3. In separate unknown/known cases, a later EAGAIN cannot provide a new lower bound or replace the last-byte read's upper bound. Unknown remains unclaimable. A40ms real clock separation distinguishes the earlier upper bound from the later recovery call, without fabricated clocks. Schema translation still leaves source-timing and physical references null.
4. A local software fault injection in `_locate` causes terminal failure after a full64-byte actual OS read. All bytes are retained/counted, further read and previously received receipt claim both fail, and snapshots/explicit close still work. Fault injection establishes software failure behavior only.

See `delta-controls.log`, `delta-controls-result.json`, `delta-execution-record.json`. The original7 and followup were not rerun after repair.

Root's external logs were read, not executed by this review: targeted RED2 errors; first11-test green attempt had one overstrict inequality because successive real monotonic readings were equal; final `recovery-green-02` reports11/11 pass. Their distinction is retained in `result.json`.

## Evidence boundaries

The six original passing controls covered EOF fragments, empty/data budget boundaries, foreign-thread claim/snapshot/close rejection, split actual EAGAIN provenance, raw repeated OS input and failed-translation consumption. They bind the initial source; the four new delta controls bind the repaired source. Source review establishes that the repair is limited to recovery/accounting/timing.

Regular-file rejection, local receipt object identity and owner thread checks do not authenticate a peer, build or BOOT. A local pipe meets the descriptor type check. Two identical frames that enter the OS can be translated separately at this layer; external replay/freshness/history must remain authoritative. Caller-provided correlation labels and context are assertions until independently authenticated.

The actual EAGAIN anchor is only complete-frame availability at this descriptor. It does not establish UART/USB arrival, sensor/FPGA acquisition or sample time. Read-call intervals are retained, and unknown availability remains unknown. No `VerifiedEnvelope`, `VerifiedObservation`, physical capture, motion authorization or production admission is created. Blocking descriptors still require upstream nonblocking policy or a bounded supervisor.

No board, actual end-to-end PC_DIRECT/HIL motion, sensor accuracy or final game/UI requirement was tested here. Existing production gates were not relaxed. G03/R03/all29 remain `not_run`; H01–H15 are preserved. Main retains integration and acceptance authority.

## Evidence retention

`initial-report.md`/`initial-result.json` and both original exit1 logs remain unchanged. Before source/doc snapshots and final three-file snapshots are retained with their exact hashes. `manifest.json` lists public review artifacts and excludes the private lease and the post-manifest native completion receipt. The latter is separately stored as `native-complete.json` after its tool return.

