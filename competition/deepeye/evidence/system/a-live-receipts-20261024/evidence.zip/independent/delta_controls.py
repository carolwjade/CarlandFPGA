"""Only recovery/accounting/timing delta controls after root's targeted fix."""
import binascii
import json
import os
from pathlib import Path
import struct
import sys
import time
import unittest
from unittest import mock

sys.dont_write_bytecode = True
from review_controls import actual_pipe, context, pins, reconstruct, state_packet

OUT = Path(__file__).resolve().parent
EXPECTED_SOURCE = 'ebd24a6a53710a1e2d8c24d13bd64fafed8b03ff27f8382935dc2ea0c75cfe4e'
SOURCE = 'competition/deepeye/integration/live_board_receipts.py'
OBSERVATIONS = {}


def tiny_packet():
    body = struct.pack('<2sBBBBHI', b'\xa5\x5a', 3, 6, 4, 2, 30, 4321) + struct.pack('<I', 7)
    return body + struct.pack('<H', binascii.crc_hqx(body[2:], 0xffff))


class RecoveryDeltaControls(unittest.TestCase):
    def test_01_two_identical_embedded_packets_have_distinct_original_ranges(self):
        tiny = tiny_packet()
        raw = b'\xa5\x5a\x03\x0c\x1b' + tiny + tiny
        self.assertEqual(len(raw), 41)
        self.assertNotEqual(binascii.crc_hqx(raw[2:-2], 0xffff), struct.unpack('<H', raw[-2:])[0])
        with actual_pipe() as (ledger, _, write_fd):
            os.write(write_fd, b'xyz' + raw[:24])
            self.assertEqual(ledger.read_once(), ())
            os.write(write_fd, raw[24:])
            first, second = ledger.read_once()
            snap = ledger.snapshot()
            self.assertEqual([e.raw for e in (first, second)], [tiny, tiny])
            self.assertEqual([(e.stream_start, e.stream_end) for e in (first, second)],
                             [(8, 26), (26, 44)])
            self.assertEqual(reconstruct(snap, snap['frames'][0]), tiny)
            self.assertEqual(reconstruct(snap, snap['frames'][1]), tiny)
            self.assertEqual(snap['bytes_read'], 44)
            self.assertEqual(snap['frames'][0]['spans'], [dict(read_index=0, offset=8, length=18)])
            self.assertEqual(snap['frames'][1]['spans'],
                             [dict(read_index=0, offset=26, length=1),
                              dict(read_index=1, offset=0, length=17)])
            OBSERVATIONS['two_identical_embedded'] = snap

    def test_02_whole_os_read_accounted_and_budget_stops_after_delayed_recovery(self):
        good, next_frame = state_packet(), state_packet(21)
        raw = b'\xa5\x5a\x03\x0c\x1b' + good + b'JUNK' + next_frame
        with actual_pipe(max_bytes=73) as (ledger, read_fd, write_fd):
            os.write(write_fd, raw)
            first, second = ledger.read_once()
            self.assertEqual([(e.stream_start, e.stream_end) for e in (first, second)],
                             [(5, 37), (41, 73)])
            snap = ledger.snapshot()
            self.assertEqual(snap['bytes_read'], 73)
            self.assertEqual(sum(len(bytes.fromhex(r['raw_hex'])) for r in snap['reads']), 73)
            self.assertEqual([reconstruct(snap, row) for row in snap['frames']], [good, next_frame])
            os.write(write_fd, state_packet(22))
            with self.assertRaisesRegex(ValueError, 'budget'):
                ledger.read_once()
            self.assertEqual(os.read(read_fd, 100), state_packet(22))
            self.assertEqual(ledger.snapshot(), snap)
            OBSERVATIONS['whole_read_budget'] = snap

    def test_03_delayed_recovery_uses_actual_last_byte_read_anchor_and_upper(self):
        good = state_packet()
        prefix = b'\xa5\x5a\x03\x0c\x1b' + good
        for anchored in (False, True):
            with self.subTest(initial_empty=anchored), actual_pipe() as (ledger, _, write_fd):
                if anchored:
                    ledger.read_once()
                os.write(write_fd, prefix)
                self.assertEqual(ledger.read_once(), ())
                prefix_index = 1 if anchored else 0
                prefix_record = ledger.snapshot()['reads'][prefix_index]
                # Separate real host clock observations; no clocks are fabricated.
                time.sleep(0.04)
                ledger.read_once()
                later_empty = ledger.snapshot()['reads'][-1]
                os.write(write_fd, b'JUNK')
                event, = ledger.read_once()
                snap = ledger.snapshot()
                self.assertEqual((event.stream_start, event.stream_end), (5, 37))
                self.assertEqual(snap['frames'][0]['spans'],
                                 [dict(read_index=prefix_index, offset=5, length=32)])
                if anchored:
                    expected = (snap['reads'][0]['read_call_interval_ns'][0],
                                prefix_record['read_call_interval_ns'][1])
                    self.assertEqual(event.availability_interval_ns, expected)
                    self.assertLess(expected[1], snap['reads'][-1]['read_call_interval_ns'][1])
                    document = json.loads(ledger.claim_board_response(event, context=context()))
                    self.assertIsNone(document['timing_record_sha256'])
                    self.assertIsNone(document['physical_capture_record_sha256'])
                else:
                    self.assertIsNone(event.availability_interval_ns)
                    with self.assertRaisesRegex(ValueError, 'unknown'):
                        ledger.claim_board_response(event, context=context())
                OBSERVATIONS['delayed_known' if anchored else 'delayed_unknown'] = dict(
                    snapshot=snap, later_empty=later_empty)

    def test_04_controlled_parser_exception_retires_without_losing_read_accounting(self):
        with actual_pipe(max_bytes=128) as (ledger, read_fd, write_fd):
            ledger.read_once()
            os.write(write_fd, state_packet(40))
            earlier, = ledger.read_once()
            raw = state_packet(41) + b'x' * 32
            os.write(write_fd, raw)
            # Fault injection is local parser testing, never provenance evidence.
            with mock.patch.object(ledger, '_locate', side_effect=RuntimeError('controlled parser fault')):
                with self.assertRaisesRegex(RuntimeError, 'controlled parser fault'):
                    ledger.read_once()
            snap = ledger.snapshot()
            self.assertTrue(snap['failed'])
            self.assertEqual(snap['bytes_read'], 96)
            self.assertEqual(sum(len(bytes.fromhex(r['raw_hex'])) for r in snap['reads']), 96)
            self.assertEqual(bytes.fromhex(snap['reads'][-1]['raw_hex']), raw)
            with self.assertRaises(BlockingIOError):
                os.read(read_fd, 200)
            with self.assertRaisesRegex(ValueError, 'failed'):
                ledger.read_once()
            with self.assertRaisesRegex(ValueError, 'failed'):
                ledger.claim_board_response(earlier, context=context())
            self.assertEqual(ledger.snapshot(), snap)
            ledger.close()
            self.assertTrue(ledger.snapshot()['closed'])
            OBSERVATIONS['controlled_parser_failure'] = dict(snapshot=ledger.snapshot(),
                fault_injection='local _locate RuntimeError; all transport reads remained actual OS reads')


if __name__ == '__main__':
    before = pins()
    assert before[SOURCE]['sha256'] == EXPECTED_SOURCE, 'source changed; need parent review pin'
    with (OUT / 'delta-controls.log').open('w', encoding='utf-8') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(RecoveryDeltaControls))
    after = pins()
    value = dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
        successful=result.wasSuccessful(), source_unchanged=before == after,
        before=before, after=after, observations=OBSERVATIONS,
        interpretation='local software/OS controls only; no board/auth/sample/capture/production acceptance')
    (OUT / 'delta-controls-result.json').write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    print((OUT / 'delta-controls.log').read_text(encoding='utf-8'), end='')
    print(json.dumps({k:value[k] for k in ['tests','failures','errors','successful','source_unchanged']}))
    sys.exit(0 if result.wasSuccessful() and before == after else 1)
