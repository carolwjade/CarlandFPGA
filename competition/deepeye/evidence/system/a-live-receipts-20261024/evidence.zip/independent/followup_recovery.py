"""One additional OS control for the observed decoder exception only."""
import json
import os
from pathlib import Path
import sys
import traceback

sys.dont_write_bytecode = True
from review_controls import actual_pipe, pins, state_packet

out = Path(__file__).resolve().parent
before = pins()
raw = b'\xa5\x5a\x03\x0c\x1b' + state_packet() + b'JUNK' + state_packet(21)
assert len(raw) == 73
result = dict(before=before, configured_max_bytes=73, first_os_input_hex=raw.hex())
with actual_pipe(max_bytes=73) as (ledger, read_fd, write_fd):
    ledger.read_once()
    os.write(write_fd, raw)
    try:
        ledger.read_once()
    except Exception as error:
        result['first_error'] = str(error)
        result['traceback'] = traceback.format_exc()
    result['after_exception'] = ledger.snapshot()
    try:
        unread = os.read(read_fd, 200)
        result['kernel_remainder_hex'] = unread.hex()
    except BlockingIOError:
        result['kernel_remainder'] = 'actually empty: BlockingIOError'
    os.write(write_fd, state_packet(22))
    result['subsequent_receipts'] = [dict(receipt_index=e.receipt_index, raw_hex=e.raw.hex(),
        stream_start=e.stream_start, stream_end=e.stream_end) for e in ledger.read_once()]
    result['final_snapshot'] = ledger.snapshot()
    result['journal_actual_bytes'] = sum(len(bytes.fromhex(r['raw_hex']))
        for r in result['final_snapshot']['reads'])
    result['snapshot_bytes_read'] = result['final_snapshot']['bytes_read']
result['after'] = pins()
result['source_unchanged'] = before == result['after']
result['budget_and_offsets_coherent'] = result['journal_actual_bytes'] == result['snapshot_bytes_read'] <= 73
(out / 'followup-recovery-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
summary = {key:result[key] for key in ['first_error', 'kernel_remainder', 'journal_actual_bytes',
    'snapshot_bytes_read','budget_and_offsets_coherent','source_unchanged','subsequent_receipts']}
text = json.dumps(summary, ensure_ascii=False, indent=2)
(out / 'followup-recovery.log').write_text(text + '\n', encoding='utf-8')
print(text)
sys.exit(0 if result['budget_and_offsets_coherent'] else 1)
