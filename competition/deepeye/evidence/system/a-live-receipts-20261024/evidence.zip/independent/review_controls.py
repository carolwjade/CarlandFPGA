"""Independent new local OS-pipe evidence controls; no board or product writes."""
from __future__ import annotations

import binascii
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import threading
import time
import traceback
import unittest

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCT = ROOT / '.local/deepeye-implementation-a'
sys.path[:0] = [str(PRODUCT), str(ROOT / '.local/deepeye-host-deps')]
from competition.deepeye.integration import live_board_receipts as receipt
from competition.deepeye.integration import wire

OBSERVATIONS = {}
TARGETS = [
    'competition/deepeye/integration/live_board_receipts.py',
    'competition/deepeye/integration/test_live_board_receipts.py',
    'competition/deepeye/docs/live_board_receipts.md',
    'competition/deepeye/integration/wire.py',
    'competition/deepeye/integration/host_envelope.py',
]


def pins():
    return {p: {'sha256': hashlib.sha256((PRODUCT / p).read_bytes()).hexdigest(),
                'bytes': (PRODUCT / p).stat().st_size} for p in TARGETS}


def state_packet(sequence=20, session=7):
    payload = struct.pack('<IHhBBHHHBB', session, 0, 0, 0, 0, 0, 0, 0, 2, 0)
    body = struct.pack('<2sBBBBHI', b'\xa5\x5a', 3, 8, len(payload), 2, sequence, 4321) + payload
    return body + struct.pack('<H', binascii.crc_hqx(body[2:], 0xffff))


def context():
    return dict(session=7, config_epoch=2, boot_sha256='d'*64,
                transport_profile_id=1, source_id=4, topology_id=2,
                acquisition_profile_id=1)


@contextlib.contextmanager
def actual_pipe(**limits):
    read_fd, write_fd = os.pipe()
    os.set_blocking(read_fd, False)
    ledger = receipt.ReceiptLedger(read_fd, receipt.CaptureIdentity(
        'independent-local-pipe', 'a'*64, 'b'*40, 'c'*64, 1),
        max_bytes=limits.get('max_bytes', 512), max_reads=limits.get('max_reads', 32),
        read_size=limits.get('read_size', 4096))
    try:
        yield ledger, read_fd, write_fd
    finally:
        ledger.close()
        for fd in (read_fd, write_fd):
            try:
                os.close(fd)
            except OSError:
                pass


def reconstruct(snapshot, frame):
    return b''.join(bytes.fromhex(snapshot['reads'][s['read_index']]['raw_hex'])[
                   s['offset']:s['offset']+s['length']] for s in frame['spans'])


class IndependentOSControls(unittest.TestCase):
    def test_01_embedded_valid_packet_recovered_after_long_bad_crc_candidate(self):
        # A legal-looking type12/27-byte candidate defers scanning until byte41.
        # The valid STATE starts at byte5 and ended at byte37, before recovery.
        good = state_packet()
        corrupt = b'\xa5\x5a\x03\x0c\x1b' + good + b'JUNK'
        self.assertEqual(len(corrupt), 41)
        reference = wire.FrameDecoder().feed(corrupt)
        self.assertEqual(len(reference), 1)
        self.assertEqual(reference[0], wire.decode(good))
        with actual_pipe() as (ledger, _, write_fd):
            os.write(write_fd, corrupt)
            try:
                events = ledger.read_once()
            except Exception as error:
                OBSERVATIONS['nested_recovery'] = dict(
                    raw_hex=corrupt.hex(), intended_packet_hex=good.hex(),
                    expected_span=[5, 37], reference_decoder_frames=len(reference),
                    raised=type(error).__name__ + ': ' + str(error),
                    traceback=traceback.format_exc(), snapshot=ledger.snapshot())
                raise
            OBSERVATIONS['nested_recovery'] = dict(snapshot=ledger.snapshot())
            self.assertEqual([event.raw for event in events], [good])
            self.assertEqual((events[0].stream_start, events[0].stream_end), (5, 37))

    def test_02_eof_retains_unfinished_packet_without_empty_time_anchor(self):
        fragment = state_packet()[:17]
        with actual_pipe() as (ledger, _, write_fd):
            os.write(write_fd, fragment)
            os.close(write_fd)
            self.assertEqual(ledger.read_once(), ())
            self.assertEqual(ledger.read_once(), ())
            snap = ledger.snapshot()
            self.assertTrue(snap['eof'])
            self.assertFalse(snap['failed'])
            self.assertEqual(snap['decoder']['buffered_bytes'], 17)
            self.assertEqual(snap['frames'], [])
            self.assertEqual([x['kind'] for x in snap['reads']], ['data', 'eof'])
            self.assertEqual(bytes.fromhex(snap['reads'][0]['raw_hex']), fragment)
            with self.assertRaises(ValueError):
                ledger.read_once()
            self.assertEqual(len(ledger.snapshot()['reads']), 2)
            OBSERVATIONS['partial_eof'] = snap

    def test_03_byte_budget_preserves_partial_and_leaves_kernel_remainder(self):
        good = state_packet()
        with actual_pipe(max_bytes=17, max_reads=4) as (ledger, read_fd, write_fd):
            os.write(write_fd, good)
            self.assertEqual(ledger.read_once(), ())
            with self.assertRaises(ValueError):
                ledger.read_once()
            snap = ledger.snapshot()
            self.assertEqual(snap['bytes_read'], 17)
            self.assertEqual(snap['decoder']['buffered_bytes'], 17)
            self.assertFalse(snap['eof'])
            self.assertEqual(os.read(read_fd, 100), good[17:])
            OBSERVATIONS['partial_budget'] = snap

    def test_04_empty_budget_and_owner_claim_close_rejections_leave_state_intact(self):
        with actual_pipe(max_reads=1) as (ledger, _, write_fd):
            ledger.read_once()
            before = ledger.snapshot()
            with self.assertRaises(ValueError):
                ledger.read_once()
            self.assertEqual(ledger.snapshot(), before)
        with actual_pipe() as (ledger, _, write_fd):
            ledger.read_once()
            os.write(write_fd, state_packet())
            event, = ledger.read_once()
            rejected = []
            def foreign():
                for operation in (lambda: ledger.claim_board_response(event, context=context()),
                                  ledger.snapshot, ledger.close):
                    try:
                        operation()
                    except ValueError as error:
                        rejected.append(str(error))
            thread = threading.Thread(target=foreign)
            thread.start()
            thread.join(5)
            self.assertFalse(thread.is_alive())
            self.assertEqual(len(rejected), 3)
            self.assertFalse(ledger.snapshot()['closed'])
            self.assertFalse(ledger.snapshot()['frames'][0]['claimed'])
            OBSERVATIONS['owner'] = rejected

    def test_05_eagain_between_fragments_bounds_complete_descriptor_frame_only(self):
        good = state_packet()
        with actual_pipe() as (ledger, _, write_fd):
            os.write(write_fd, good[:17])
            ledger.read_once()
            prior_end = ledger.snapshot()['reads'][0]['read_call_interval_ns'][1]
            ledger.read_once()  # Actual empty queue after the stored prefix.
            empty = ledger.snapshot()['reads'][1]
            os.write(write_fd, good[17:])
            event, = ledger.read_once()
            snap = ledger.snapshot()
            self.assertEqual(event.availability_interval_ns[0], empty['read_call_interval_ns'][0])
            self.assertGreaterEqual(event.availability_interval_ns[0], prior_end)
            self.assertEqual(reconstruct(snap, snap['frames'][0]), good)
            self.assertEqual([s['read_index'] for s in snap['frames'][0]['spans']], [0, 2])
            self.assertIsNone(snap['frames'][0]['sample_interval_ns'])
            document = json.loads(ledger.claim_board_response(event, context=context()))
            self.assertIsNone(document['timing_record_sha256'])
            self.assertIsNone(document['physical_capture_record_sha256'])
            OBSERVATIONS['split_after_empty'] = dict(snapshot=snap, envelope=document)

    def test_06_os_replayed_identical_bytes_remain_distinct_untrusted_schema_events(self):
        # Positive boundary control: this layer has no anti-replay authority.
        good = state_packet()
        with actual_pipe() as (ledger, _, write_fd):
            ledger.read_once()
            os.write(write_fd, good+good)
            first, second = ledger.read_once()
            a = json.loads(ledger.claim_board_response(first, context=context()))
            b = json.loads(ledger.claim_board_response(second, context=context()))
            self.assertEqual(a['wire_frame_hex'], b['wire_frame_hex'])
            self.assertEqual((first.receipt_index, second.receipt_index), (0, 1))
            snap = ledger.snapshot()
            self.assertEqual(reconstruct(snap, snap['frames'][0]), good)
            self.assertEqual(reconstruct(snap, snap['frames'][1]), good)
            self.assertEqual([(e['stream_start'], e['stream_end']) for e in snap['frames']],
                             [(0, 32), (32, 64)])
            OBSERVATIONS['same_bytes_replayed_on_os'] = dict(snapshot=snap,
                interpretation='actual OS bytes and schema only; no authenticity/freshness/anti-replay')

    def test_07_failed_schema_translation_consumes_original_event(self):
        with actual_pipe() as (ledger, _, write_fd):
            ledger.read_once()
            os.write(write_fd, state_packet(session=8))
            event, = ledger.read_once()
            with self.assertRaisesRegex(ValueError, 'session'):
                ledger.claim_board_response(event, context=context())
            self.assertTrue(ledger.snapshot()['frames'][0]['claimed'])
            with self.assertRaisesRegex(ValueError, 'already claimed'):
                ledger.claim_board_response(event, context=context())


if __name__ == '__main__':
    initial = pins()
    scope = json.loads((ROOT / 'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
    scope_sha = hashlib.sha256(json.dumps(scope['requirements'], ensure_ascii=False,
        sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()
    assert scope_sha == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    meta = dict(agent_id='/root/live_receipts_review', work_id='A-LIVE-RECEIPTS-REVIEW-20261024-v1',
                task_id='DEEPEYE-IMPLEMENTATION-20261014', task_version=1,
                python=sys.version, executable=sys.executable, product=str(PRODUCT),
                requirements_sha256=scope_sha, requirements_ids=[r['id'] for r in scope['requirements']],
                before=initial, started_monotonic_ns=time.monotonic_ns())
    (OUT / 'preflight.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
    with (OUT / 'controls.log').open('w', encoding='utf-8') as log:
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(IndependentOSControls)
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    (OUT / 'observations.json').write_text(json.dumps(OBSERVATIONS, ensure_ascii=False, indent=2), encoding='utf-8')
    meta.update(after=pins(), source_unchanged=initial == pins(), tests=result.testsRun,
                failures=len(result.failures), errors=len(result.errors),
                successful=result.wasSuccessful(), finished_monotonic_ns=time.monotonic_ns())
    (OUT / 'controls-result.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
    print((OUT / 'controls.log').read_text(encoding='utf-8'), end='')
    print(json.dumps({k:meta[k] for k in ['tests','failures','errors','successful','source_unchanged']}, ensure_ascii=False))
    sys.exit(0 if result.wasSuccessful() else 1)
