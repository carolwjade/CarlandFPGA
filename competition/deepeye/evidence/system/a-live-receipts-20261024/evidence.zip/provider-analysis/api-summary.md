# 建议 root 首个实现单元（未实现）

新增：`competition/deepeye/integration/live_board_receipts.py`，文档 `docs/live_board_receipts.md`，只验证新代码。现有 actor_composition production gate 保持闭合。

```python
# 主authority私有；以下为建议接口，不是现有API或可执行承诺。
receipt_owner = open_reviewed_board_channel(operation_manifest, endpoint_record)
event = receipt_owner.capture_next()  # 内部真实read/owner monotonic；外部不可submit bytes
summary = receipt_owner.diagnostic(event)  # 原bytes/packet spans/read区间；无准入能力
board_raw = receipt_owner.board_envelope(event, active_or_proposed_context)
observation_raw = receipt_owner.diagnostic_observation(event, context)
receipt_owner.close(reason)
```

- opener必须从 main-owned原端点获得连续ownership，沿用既有认证；不能仅解析endpoint JSON后自称认证。没有可核验endpoint时不采集，不创建 live credential。端点/脚本实板动作仅root执行。
- event仅本实例原registry可识别；opaque身份与dataclass不取代OS ACL/进程隔离。只读诊断可返回不敏感summary，原board_response只送world_authority，绝不送AI。
- 同时保存 `read_call_interval_ns` 和有证据时的 `final_byte_availability_interval_ns`。后二者语义不同；无availability证据则不生成host board envelope。
- packet从原chunk精确切片，并保存offset/span。wire.decode校CRC/ABI，不以重新encode后的内容替代原包证据。FrameDecoder返回Frame而非raw/offset，需有界原packet保留适配。
- board_envelope遵循现有board_response全部字段并调用host_envelope.validate_message；timing缺项null，PC_DIRECT capture始终null。不存在的measurement record不能仅填hash。
- diagnostic_observation拆真实TELEM/EVENT；mapped acquisition interval缺测量为null，只是诊断，不返回VerifiedObservation或给runtime.observe。
- manifest把operation/request/tested_commit/同次bit/HWH/build与channel generation、source数字注入来源联系起来；这些关联字段不能升级测量/身份或H09结论。

后续 provider 实现单元（不是本轮交付）需补：

| Adapter | 已有下游API | 必须新增的原依据 |
|---|---|---|
| BootTranscript | boot_profile.verify_boot_ack → BootBinding | 原实际BOOT发送/ACK、完整profile/build、stopped状态、新session和本authority BOOT generation、实际AI instance |
| MeasuredClockSource | make_anchor/map_tick/adc_first_sample_interval → VerifiedObservation | 原TX tick/receipt availability、独立测得delay/rate/quantum/holdover/sample bounds、source quality/native age |
| OriginalActorCompletion | ActorOwner.ai_lease / _CompletedInference | 原owned HANDLE life及原endpoint completion/invocation/model/preprocess/dispatch时刻；JSON本身无认证 |
| OriginalBrokerLedger | VerifiedEnvelope + candidate owner | exact候选/观测/target关联、一次消费、原issue/completion期限 |
| OwnedHeadlessWorld | OwnedMotionExecutor.prepare_step/commit_step | 完整私有scene/model/budgets、合法initialize/history、same boot/raw、runtime final fence一次及CAS |

现有全composition另有 exact-nanosecond slot消费约束（candidate_mailbox.py:306–309），需root新设计决定；不能用fixtures/冻结clock/回填now绕过。BOOT generation不是Desktop Gen3。数值实际CAS不等于Godot/UI或板物理动作证明。
