# 新实板 PC_DIRECT provider 只读准备

工作 `A-LIVE-PROVIDER-PREP-20261024-v1`；任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`；native agent `/root/live_provider_plan`，job `child-224ea08b3b2b4b65bd3802fca674f687`。本轮先通过 `fpga_native_validate`，`execution_allowed=true`。父主是 Desktop `01a16988-bdcb-70e1-ae10-1304b5cf7875`；activation record 实读 `active/generation 3`。既有配置实读 `node_id=A/project_id=fpga-main`；root 是唯一实板操作者。

根 AGENTS、两项项目技能及 A role、协作协议、交接和 board-next-review 已读。immutable_scope.md/.json 已读；使用 UTF-8、ensure_ascii=False、sort_keys=True、紧凑分隔符实算 15 项 requirements：`c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`。合同 `DEEPEYE-HUMAN-LOCK-20261014/revision1` 及 H01–H15 保留。产品实读 HEAD 为 `66913fa61270b4e61d453c245d927824548bc267`。产品 AGENTS 仍有 Gen2 旧文本，按明确人类更新及 authoritative transfer 识别 Gen3，未修改它。

本轮只读源码与文档并写本目录；没有运行旧测试、求解、板测、服务、显示器操作、网络发送或派工，没有修改产品。源文件 SHA256 见 result.json。下面是供 root 选择的实现边界，不是生产准入或正式验收决定。

## 可立即落地的小模块

建议 root 本轮先新增 `competition/deepeye/integration/live_board_receipts.py`、对应短文档与少量针对新模块的检查。它应完成**真实读取、原字节保存和现有静态验证器适配**，即使未知采样时间仍能交付有用的真实接收证据；不能只是永远 blocked 的外壳，也不能把同名方法、dataclass 或来源旗标变成凭据。

模块由 main-owned 明确 transport opener 取得并独占原端点，使用现有已认证连接，不接受 controller 传入 bytes 后自称 live。实际端点开关、读写和任何实板动作仍由 root 审定/执行。本子任务未取得这些端点，也没有声称已有可运行的 transport。

最小行为：

1. `capture_next()` 在真实 read 边界记录原 chunk bytes、同一 host monotonic clock 的调用区间、原端点/连接世代，并将有限缓冲中每一有效原 packet 与原 chunk 的 offset/span 对应。CRC/类型/长度仍交 `wire.decode`；坏包与截断保留原字节和拒绝原因。
2. 返回只能由本实例私有 registry 识别的 opaque event。外部 JSON/dict、重建 dataclass、别的实例事件、旧连接事件不成为 live 输入；这是主 authority 内部来源关联，Python 身份本身仍不是 OS 安全边界。采集端点/文件/原 registry 对 AI 不可写。
3. `board_envelope(event, proposed_or_active_context)` 只从本 registry 原记录导出 `board_response` bytes，并调用 `host_envelope.validate_message(... producer='hardware_bridge', consumer='world_authority', ...)`。`physical_capture_record_sha256` 在 PC_DIRECT 固定 null。未知 timing hash 保持 null。
4. `diagnostic_observation(event, context)` 从真实 TELEM/EVENT payload 拆出 schema 字段；若缺测时，mapped interval 保持 null。允许形成明确的采集诊断材料；不能返回 `VerifiedObservation`、给候选填虚构 sample time 或授予动作。
5. `close(reason)` 先永久退休该 registry、拒绝后续新输入，再关闭唯一端点并保留清理事实。不自动 reconnect/adopt/replay；未知已发送写入不得重发。

独立保存 receipt sidecar，不向现有 strict envelope 增加字段：operation_id、request_hash、tested_commit、同次 bit/HWH/build hashes、transport 身份/端点获取记录、connection generation、host clock domain、read index、原 chunk hash/path、packet spans、input provenance。software_fixture 数字输入经过真实 PL 的诊断必须明确标注；标注只描述来源，不能证明 H09/ADC/G03。

**接收时间的必要区分：** `before_read/after_read` 只是实际 read 调用区间。数据可能早已在驱动/USB/kernel queue，不能把 before_read 当作 final-byte availability 的下界。现有 timing contract 要求的是末字节变为可用的区间。可以在唯一 reader、已核实 queue/driver 语义下，用可信的最后一次空队列观察调用前时刻作为保守 availability lower，取末字节读回后的时刻为 upper；保留两者的原调用记录。没有这种证据时，receipt availability 应为 unknown，保存 read interval 继续诊断；不伪装为可用的 runtime receipt。静态 envelope 要求 nonnull receipt，所以 unknown 情况只能导出诊断 sidecar，不能调用可执行接收适配。原时钟测量也不能从 read interval 自动推得。

`wire.FrameDecoder.feed` 只返回 Frame，未返回原 packet offset/raw bytes（wire.py:83–137）。不能只 `wire.encode(frame)` 后称之为原收到 bytes；必须保存原 chunk 和准确 packet spans。若最早 PL 镜像只提供 BRAM/register 数字回读，host 编码 ABI3 不能冒充板端原始 BOOT/STATE/TELEM。可保存真实 MMIO 诊断，但接入现有 authority 需要 B 原生帧路径，或另经 root 决策的明确原子快照协议适配。

## 已有接口与缺失的真实 provider

以下路径均相对产品 `competition/deepeye/`。

| 边界 | 可复用接口 | 真实输入与限制 |
|---|---|---|
| BOOT | `integration/boot_profile.py:1629` boot_frame、`:1685` verify_boot_ack；runtime.py:261 boot | 使用本次实际发送原 request bytes 与真实收到 ACK，核 session/mode/sha128/guard/primary/config/seq/epoch 精确回显。full boot SHA256 必须绑定实际协议文件/profile/build。还需 stopped 状态、新 session、本 authority 的递增 BOOT generation、当前真实 AI instance。BOOT generation 与 Desktop director generation 是不同量。 |
| 原始板响应 | `wire.decode`；`host_envelope.validate_message`；runtime.py:302 board | 从唯一真实端点原 packet 与 receipt availability 导出 `VerifiedEnvelope(boot, raw)`。静态验证器只检查 CRC/schema/context/session 和有限 cross-field，不建立来源认证、完成 BOOT 或板存活。STATE8 才更新 watchdog；CONFIG/GAIN/ACK 不替代心跳。 |
| 原采样时间 | `clock_bounds.make_anchor/map_tick/adc_first_sample_interval`；runtime.py:329 observe | 带 first-byte TX tick 的 STATE/ACK 与真实末字节接收区间建立 anchor。TELEM tick 是最后 ADC acquisition，EVENT tick 是 trigger acquisition。由测量得到 d_lo/d_hi、tick quantum upper、host-relative rate bound、holdover、实际 sample-period bounds；不可猜默认值或把 nominal baud/晶振标称误差当实测。 |
| 观测有效性 | `VerifiedObservation(boot, raw, sample_lower_ns)`；runtime.py:338–356 | 真实 TELEM/EVENT、原 seq/counts/quality/source continuity、测时记录与 acquisition mapping。sample_lower 必须保守覆盖原 native/held age，不能取 receipt time。FAST/STRESS count=50/800，首末 nominal span=(N-1)*10ms；缺样不能补齐。未知 native EM update time 保持 null，held bit 不证明 update 相位。quality/source_fault 拒绝是 provider 责任，runtime/host schema 不等于完整质量检查。 |
| AI 身份与存活 | `simulation/isolation/actor_owner.py` ActorRegistry.launch、ActorOwner.bind_verified_boot/ai_lease；actor_lifetime.py | 已有 actual native acquisition、原 process HANDLE ownership continuity、creation FILETIME、AppContainer/job 检查、Wait(handle,0) 的有界最近生命采样。复用原 actor；不 PID 查找/adopt、重用 instance、缓存 alive。生命采样不证明模型加载/响应/任务收益。 |
| 模型/原完成事件 | `candidate_owner._CompletedInference`；composition.py:487 accept_completion | 固定实际 CPU baseline package/model/preprocess identity；原 actor 输出 pipe 的 exact bytes、dispatch/completion 原区间及 invocation ID。现有 ipc_framing 和 pipe_read 是 inactive/diagnostic leaf，不完成 endpoint acquisition、readiness 或 completion 认证。不能用任意输出 JSON/READY 文本造完成证明。 |
| 候选→请求 | composition.py:254–278、candidate_owner.py:select/commit | 原候选、模型 hash、candidate_id、observation key、完整 target 与原 broker motion_request 关联；命令 issue 原时刻，候选只消费一次。原完成下界+progress age 不由重复心跳/收件续期。 |
| 几何/提交 | motion_executor.py:OwnedMotionExecutor、prepare_step、commit_step | 使用 authority 私有完整 scene、确实包含渲染/碰撞实体的 capsule/model、显式 error budgets、有效完整 PassageState 历史和当前 pose revision。禁止硬塞中间阶段 state 或从 AI 提供 pose。准备无副作用；commit 调用 runtime fence 一次，随后唯一 root CAS，无 I/O/时钟/hash/callback。 |

BOOT/source 模式已有 `enums.json` 定义：software_fixture=source_id 4，PC_DIRECT=topology_id 2。该组合合法地标记最早集成诊断；它不自动满足物理 sensing 或完整产品准入。不可将 `twin_fixture`、sensor_live 或 acquisition profile 名称移植到软件注入以升级结论。

## root 接入现有 authority 的顺序与真实阻塞

可复用的 lower-level `AuthorityDependencies` 精确签名在 runtime.py:111–151。`verify_*` 返回值必须来自前述原记录；`ai_lease` 调现有原 actor；prepare/commit 直接委托 OwnedMotionExecutor，不重写运动学或绕过最终 fence。

本轮生产 `create_authority` **不能**直接启动：actor_composition.py:162–164 的 `_production_channels` 无条件抛 ActivationUnavailable，并在 :561 于 registry 获取之前调用。不能 patch 私有 factory/test seams 或新增 caller provider/flag 让生产门敞开。真实 channels 尚需 verify_boot、verify_board、verify_observation、verify_command、checkpoint、mailbox_activation_for_boot、verify_completion、verify_slot；lifetime 与 geometry 的目标已固定到本 composition 原 actor/executor，channels 不应替换它们。

另有一个独立的 live availability 问题：composition `verify_slot` 后重新采样实际时钟，candidate owner 调 `LatestCompletedMailbox.consume(now_ns)`；candidate_mailbox.py:306–309 要求 `now_ns == selected.slot_start_ns`。文档 actor_composition.md 已明确，没有证据证明真实 scheduler 可命中这个单纳秒时点。不能冻结时钟、传预定时刻冒充 current time、重设 origin 追随 now 或暗改 equality。该问题需要 root 的新设计/范围决定；只安装真实 providers 不能承诺既有完整 composition 可实跑。

若 root 选择新的有限诊断 authority，独立复用 PcDirectRuntime + OwnedMotionExecutor 是可讨论的 lower-level路线，但它仍须明确实现 BOOT/channel provenance、实际原 HANDLE、原候选完成与一次消费、进度期限、完整几何和 owner serialization；不能把未采用原 stateful owner 的诊断宣称为该 production composition 的通过。本报告不替 root 作该决策，也不建议为了赶单步而降低任何既有生产门。

在这些 provider 真实存在后，单次 owner 流程应为：新 run/world/history → 实际 CPU actor及受限 IPC → stopped-state BOOT原发送/回显 → 同一 BootBinding 激活 runtime/executor并绑定 actor → 新 STATE8 → 新因果 TELEM/EVENT及原采样映射 → 实际 CPU baseline 原完成 → 原 broker请求/候选一次消费 → runtime.command 成功后 executor.admit_command 同一原 bytes → runtime.step(expected_pose_revision, dt_ns) → 原 receipt 与 pose/revision/history readback → 原期限后的停止 readback。

`dt_ns` 为已有 1–10ms 几何区间；execute 端目前严格 `step_end < deadline`（motion_executor.py:352），尽管 runtime 单独允许等号，runner 按更严格约束。所有 logs/hash/pose readback 放在 commit 返回后；不能塞入最终 fence 与 CAS 之间。数值 CAS 是本 headless world 的实际状态提交，不能称外部板动作或 Godot渲染证明。旧执行器本身不自主积分，等待不移动 pose；原命令到期清动作仍需真实 owner loop/poll，runtime 没有后台 timer。进程失去 owner 时必须由独立监督路径默认 stopped，不能声称同步函数已覆盖进程崩溃。

## 必须来自现场或实际计算的字段

- 真实现场/端点：原发送及收到 bytes、kernel/driver队列观察、真实 endpoint所有权/认证、read/receipt时刻、实际 PL snapshot/frame/source/quality、原 tick、当前 build/bit/HWH身份、原 actor HANDLE/creation identity与Wait结果、实际候选执行与完成 bytes、实际 pose revision/CAS/停止 readback。
- 独立测量：transport full-frame delay bounds（含8N1全部frame、baud容差、USB/bridge处理及timestamp不确定性）、tick量化/相对时钟rate/holdover、sample period、native/held source时间与校准、已证明的asset/obstacle/engine上界。文件hash只绑定记录，不证明测量真实或足够。
- 主会话显式策略：heartbeat timeout、AI probe/sample/lifetime/progress上限、dt/max_slices、approved模型/包、run/session/generation和完整world epoch。策略可以选择，不能把选择的字面值包装成实测。
- 现有纯算术：CRC/schema、BOOT exact echo、map_tick、first-sample interval、freshness和各deadline最小值、几何proof/CAS绑定。纯算术建立一致性，不能升级其输入来源。

## 失败及停止策略

1. 未知 receipt availability、缺 clock/source/held measurement、缺真实BOOT/STATE或模型关联时，保存实际采集材料，保持 stopped；缺项不填默认值。pre-acquisition/只采集失败不叫单步完成。
2. CRC、未知类型、坏 seq/epoch/session、回绕歧义、重放/changed duplicate、quality/source fault、时钟回退、AI death/unknown、mode/config/source/world编辑或任何 reentry 立刻退休新准入；在同 owner 序列域调用 runtime.stop 与 executor.revoke。场景编辑先 invalidate_world，再建新run/store/history。
3. 原TTL、原sample_lower+age cap、heartbeat lower+timeout、原完成下界+progress cap、原actor生命期限取最小值。duplicate不得更新 issue/receipt/sample/completion时间；新心跳也不续旧动作。
4. 一次 step 可能已CAS但receipt/log丢失时，保留 uncertain；只读 owned revision/frame对账，禁止自动重放。看见正CAS后再出现veto，应保留已提交事实并停止未来动作，不把它重写成未发生。
5. 原期限后记录实际 host monotonic、没有新 commit、实际 stopped状态及 pose revision。不能用 future timestamp、metadata `stopped=true` 或单纯time.sleep声称停止执行发生于原期限。

## 仅针对新代码的少量检查建议

不执行旧套件。本子任务未执行下面建议检查：

1. 新 reader 使用受控真实 OS pipe 的小型子进程写已固定原 bytes，检查 bounded read、exact packet span和read interval；明示该检查是本机pipe，不是板来源认证。
2. buffered data 在read前已存在时，验证read start不能成为availability lower；缺 empty/arrival证据不得输出可执行receipt；真实 empty→data的原记录仍保留。
3. fragmented/concatenated/corrupt/truncated帧保持原bytes与拒绝，foreign/retired event和connection世代拒绝；原合法原包能进入现有静态validator。
4. actual BOOT echo一字段变化、旧session/seq/epoch及完整profile/build关联缺失拒绝；unknown timing只保存诊断，不得到 VerifiedObservation。
5. 确认新模块导入/只采集不会调用create_authority、获取 actor或改变现有 closed production gate；PC_DIRECT capture ref为null。
6. 后续获实施授权的首次新 live single-step才检查实际新观测→原候选→请求→pose revision/CAS→原期限停止链；不调用旧384 BRAM、旧数值求解或旧系统回归来替代。

本报告不建立 H09、ADC、G03、R03、完整H12、完整路线、游戏/UI或all29通过。HIL的真实外部三路PWM捕获仍独立待办；PC_DIRECT最早诊断不以它为前置。
