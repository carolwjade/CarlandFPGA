# Original board receipt component

This implements the already authorized headless/provider preparation. The existing product linked worktree and branch are retained; no baseline suite is replayed. Root owns all three new product files below.

Design selected under brainstorming/writing-plans: an OS-descriptor receipt ledger, independent of production activation. Compared with accepting JSON timing claims or re-encoding decoded frames, it retains exact bytes and actual read-call intervals. A successful nonblocking empty-read observation can bound subsequent byte availability; otherwise receipt availability remains unknown. Read-call time never becomes sample time. Authentication, complete BOOT, measured source time and AI/geometry providers remain separate obligations.

Files: integration/live_board_receipts.py, integration/test_live_board_receipts.py, docs/live_board_receipts.md under competition/deepeye in the product worktree. No existing product gate or C-owned file changes.

API: CaptureIdentity(operation_id, request_hash, tested_commit, build_manifest_sha256, connection_generation); ReceiptLedger(fd, identity, *, max_bytes, max_reads, read_size=4096). read_once() performs exactly one OS read and returns original frame receipts. snapshot() exports detached evidence. claim_board_response(receipt, *, context) accepts only an original unconsumed local receipt, needs known availability, and applies the existing host envelope validator. It returns schema-checked bytes, never an authenticated VerifiedEnvelope/VerifiedObservation or motion grant. Both timing_record_sha256 and physical_capture_record_sha256 remain null.

- [x] Write focused behavior tests using actual local OS pipes and independently CRC-built ABI3 bytes: split/coalesced/corrupt frames, unknown availability, EAGAIN bound, original receipt identity/single consumption, STATE validation, resource/byte/read bounds and owner behavior. These are OS/software controls, not real board evidence.
- [x] Run only the new test module; save RED output without altering old tests.
- [x] Implement the bounded component, retain raw chunks and exact packet spans, refuse regular files/replay injection, close only its duplicated fd. Never infer sample timing or physical capture.
- [x] Run only new tests; save commands/stdout/stderr/exit. Review actual diff and C4 hashes.
- [ ] Independent reviewer checks provenance limits and new code, then root integrates/records a bounded result. No board operation or formal card acceptance is implied.

The full ActorComposition additionally requires exact slot scheduling that existing docs explicitly leave unverified. This component does not relax that or substitute frozen clocks.
