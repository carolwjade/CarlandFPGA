"""Run only the newly added receipt controls and retain raw output bytes."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

folder = Path(__file__).resolve().parent
root = folder.parents[2]
name = sys.argv[1]
command = [sys.executable, '-B', '-X', 'utf8', '-m', 'unittest',
           *(sys.argv[2:] or ['competition.deepeye.integration.test_live_board_receipts']), '-v']
started = time.monotonic_ns()
environment = dict(os.environ)
environment['PYTHONPATH'] = str(root/'.local/deepeye-host-deps')
result = subprocess.run(command, cwd=root/'.local/deepeye-implementation-a', capture_output=True,
                        env=environment)
elapsed = time.monotonic_ns() - started
for suffix, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
    with (folder/(name+'.'+suffix+'.txt')).open('xb') as stream: stream.write(raw)
record = {'command': command, 'cwd': str(root/'.local/deepeye-implementation-a'),
          'exit_code': result.returncode, 'elapsed_ns': elapsed,
          'environment_overrides': {'PYTHONPATH': environment['PYTHONPATH']}}
with (folder/(name+'.json')).open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record))
print(result.stderr.decode('utf-8', errors='replace')[-2400:])
