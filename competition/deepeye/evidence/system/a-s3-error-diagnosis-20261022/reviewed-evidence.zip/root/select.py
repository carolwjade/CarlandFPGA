import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
INPUT = D.parent / 'g03-s3-error-diagnosis-20261022'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = read(INPUT / 'manifest.json')
assert sha(INPUT / 'manifest.json') == '9a08ccfc84bf8a998d1f740653e8b4f673ff1b8f71ab53fc813bd8d6b8f75bdd'
for name, record in manifest['files'].items():
    p = INPUT / name
    assert p.stat().st_size == record['bytes'] and sha(p) == record['sha256'], name
changed = []
for name, record in read(INPUT / 'source-pins.json')['files'].items():
    p = ROOT / name
    if p.stat().st_size != record['bytes'] or sha(p) != record['sha256']:
        changed.append(name)
assert changed == ['.planning/deepeye-resume-20261018/continuation-current-increment-20261022.md'], changed
for name, record in read(INPUT / 'proposed-input-pins.json')['files'].items():
    p = ROOT / name
    assert p.stat().st_size == record['bytes'] and sha(p) == record['sha256'], name
native = read(D / 'original-native-result.json')
assert native['status'] == 'completed' and native['terminal'] and not native['stale']
scalar = read(INPUT / 'scalar-reduction.json')
for row in scalar['rows']:
    c = lambda key: complex(*row[key])
    residual, bias, gap = c('S3_V')-c('H_reference_V'), c('sampled_reference_trace_V')-c('H_reference_V'), c('S3_V')-c('sampled_reference_trace_V')
    assert abs(residual-(bias+gap)) == row['decomposition_identity_abs_V'] == 0
    assert abs(gap)/abs(c('H_reference_V')) == row['field_gap_relative_H']
    assert row['bias_relative_H'] < .01 and row['field_gap_lower_bound_relative_H'] > .01
decision = {
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'selected_work_id': 'A-G03-CONSISTENT-HODGE-ACTION-20261022-v1',
    'basis': 'Root read actual diagnosis, scalar collector, prior source projection design and mathematical local Hodge formulas; native result terminal. Nine artifact hashes and 78 immutable source pins plus five new action inputs checked.',
    'diagnosis_manifest_sha256': sha(INPUT/'manifest.json'),
    'mutable_checkpoint_changed_by_root': changed,
    'selected': 'Implement matrix-free consistent-Hodge delta action, new local analytic controls, one saved full S3-field action after controls pass',
    'PDE_solves': 0, 'old_tests_rerun': 0, 'source_geometry_or_receiver_change': False,
    'boundary_rule': 'Apply full DeltaA to full E including existing boundary, then restrict I. Accumulated saved residual plus delta action is alternative-operator residual.',
    'resource_plan': 'One scientific Python worker; existing held Win32 guard/controller allowed up to3 total handles/processes. Each stage30s sampled threshold,512MiB per process,1GiB job,BLAS1,chunk<=256. No sparse global matrix or solver.',
    'stop': 'Any pin/analytic/finite/resource failure retains original stage and stops without rerun; nonzero defect does not authorize solve or claim receiver improvement.',
    'fixed_physical_receiver_gate': .01,
    'requirements_sha256': 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    'physical_accuracy': 'unqualified', 'G03': 'not_run', 'all29': 'not_run'
}
(D/'decision.json').write_text(json.dumps(decision,indent=2),encoding='utf-8')
print(json.dumps(decision,indent=2))
