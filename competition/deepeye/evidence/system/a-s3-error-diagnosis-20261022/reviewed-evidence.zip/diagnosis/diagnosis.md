# G03 S3: evidence-led diagnosis and one bounded proposed increment

Work `A-G03-S3-ERROR-DIAGNOSIS-20261022-v1`, native job `child-4b2ed2b0da0f4efc803dc76c155239af`, agent `/root/g03_s3_error_diagnosis_20261022`. This is engineering evidence and a proposal for root selection, not selection, implementation, independent acceptance, or a physical-accuracy claim.

**Finding:** the remaining error is primarily a discrepancy between the computed field and the sampled continuum reference under the same receiver functional. The saved evidence does not identify one unique cause. The unmodified lumped background operator is the leading remaining implementation hypothesis. Source projection, boundary replacement and receiver integration alone have not removed the error. Propose one new **matrix-free consistent-Hodge correction kernel on the frozen L5 mesh**, with local analytic validation and a single saved-field action. Do not select another PDE solve at this point.

## Scope and actual execution

The original controller lease validated with `execution_allowed=true` for this canonical agent. Host configuration reads `node_id=A`, `project_id=fpga-main`; the active transfer identifies generation 2 and director `01a13d7e-dcf1-7272-a738-a637dd62ff9d`. The canonical UTF-8 requirements-array SHA256 was recomputed as `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`, with exactly H01–H15. All remain mandatory and unchanged.

Read the assignment, current G03 checkpoint, S3 design, actual S1/S2/S3 implementation, installed operator/inner-product implementation, saved results and independent review. `source-pins.json` contains 79 current source/input hashes, including all 57 frozen S3 input matches and selected S3 source/result matches against its existing manifest. Hashing is integrity evidence only. Node configuration and private credentials are excluded from deliverables.

The only new numerical work was a **short scalar decomposition of existing JSON voltage vectors**, performed by the standard-library-only `collect_evidence.py`: 0.5126594 s including hashing, peak working set 21,188,608 bytes. Zero numerical-array loads, old test runs, operator actions, Green evaluations, quadratures, PDE solves or sweeps. The whole process remained below the assignment's 30 s / 512 MiB bounds. No product, service, UI, hardware, provider, peer, external message or other owner's file was changed. Existing failed L6 and failed S1/S2/S3 executions remain untouched.

## What the actual mathematical objects are

Let `zeta0=sigma0+i*omega*epsilon0`, `d_zeta=zeta0*1_D`, and use `exp(+i*omega*t)`. The selected quantity is the first derivative at zero dimensionless contrast strength, with fixed mu, not a finite-strength scene response:

```
curl(mu^-1 curl e_dot) + i omega zeta0 e_dot = -i omega d_zeta E_primary.
```

The source, oracle and finite-domain derivative use the same 2 MHz, sigma=0.0005 S/m, epsilon=1.77083756256e-10 F/m, mu=1.2566370614359173e-6 H/m, tilted finite Tx/Rx geometry, 1 A and one turn. Source strength includes both conductivity and displacement-current contrast. No missing permittivity or selected-case turn factor was found. The receiver trace does not itself multiply by `turns`; the selected assignment fixes turns=1, so that generalization issue cannot explain this failure.

| Object | Actual implementation and units | Evidence |
|---|---|---|
| Unknown | Tangential edge-average E, V/m; not edge circulation | Installed discretize gradient/curl normalization and S1 edge-average source, pinned S3 design |
| Operator | `A0=C.T Mf(1/mu) C + i omega Me(zeta0)`; both scalar-material Hodge matrices diagonal/lumped | Installed `simulation.py:641`, `base_tensor_mesh.py:792,840`; L5 `grid_worker.py` actual assembly |
| S1 source | `b1=-i omega diag(Me(d_zeta))*E_primary_edge_average` | S1 `s1_model.py:53`, `s1_worker.py:77` |
| S3 source | `b3_j=-i omega sum_K integral_K N_j dot (d_zeta E_primary) dV`, cell Gauss4 approximation, dimensionless bilinear edge-average basis | S3 `s3_projector.py`; `s3_stages.py:9–26` |
| Source units | J=A/m², weak source=A m, RHS=A m/s; exactly one `-i omega` | S3 source and independent saved-array review |
| Boundary | S2 sampled Born E edge averages, same ordered B; zero S3 boundary correction | S2 `s2_stages.actual`, S3 `s3_stages.actual` |
| Measurement | `V=t e`, segmented true tilted circle integrated against the bilinear edge reconstruction; t has units m | S1 `s1_model.py:19–52` |
| Reference | `V_H=-i omega mu integral_disk H_dot dot n dS`, H from saved volume current moments `d_zeta E_primary dV` | S1 `s1_oracle.py:19–38` |

The accumulated solve is `A0_II e3_I = b3_I - A0_IB gB`, `e3_B=gB`. This follows by adding the three recorded systems: S1 source, S2 `-AIB*gB`, S3 `b3-b1`. The full old RHS subtraction occurred before restricting I. There is no second boundary addition or original filament residual. Normalizing by the small derivative signal is intentional; dividing by the primary carrier would change the test.

The finite-loop primary uses the outgoing `exp(-q*r)/r` branch with `q²=i omega mu zeta0` and `-i omega mu` prefactor. S1 H-flux and S2 independently expressed E-contour agree at the saved high rule to 1.48e-11 / 3.66e-12 relative. These checks support winding/time-sign and same-quantity consistency; they do not certify all spatial discretization errors. No outside theory was needed for this code comparison or the elementary polynomial formulas below.

## New reduction: the receiver representation is not the dominant discrepancy

Use the already saved S2 high-order continuum edge-average reference under the *same* t, denoted `V_star`, and the saved H-flux reference `H`. The exact scalar identity is

```
V_S3 - H = (V_S3 - V_star) + (V_star - H).
```

`V_star-H` is a diagnostic interpolation bias for this smooth reference, not an oracle correction to apply to product outputs. This reduction does not identify how much of `V_S3-V_star` comes from the operator versus the load or another approximation.

| Rx | Total S3 discrepancy / abs(H) | Reference interpolation bias / abs(H) | S3 minus sampled reference / abs(H) | Reverse-triangle lower bound for that field gap |
|---|---:|---:|---:|---:|
| 1 | 13.30859872% | 0.33489829% | **13.64349701%** | **12.97370043%** |
| 2 | 3.21104999% | 0.20752462% | **3.00352537%** | **3.00352536%** |

Both complex identities have zero floating-point discrepancy at the recorded scalar precision. Full complex vectors and exact input hashes are in `scalar-reduction.json` and `source-pins.json`. The slight difference from S2's printed bias is because S2 subtracted its direct E-contour, while this reduction subtracts H; their already saved difference is tiny.

`V_S3/H` is approximately `0.8669140129 - 3.6477e-6 i` and `1.0321104947 + 1.8278e-5 i`. One receiver is too small and the other too large. An arbitrary global amplitude/sign/turn-factor adjustment is not an evidence-supported fix. No such tuning is proposed.

## Ranked hypotheses for the root

1. **Frozen operator and approximation-space error: leading remaining hypothesis, not proved.** Installed scalar-material inner products use cell contributions V/4 to each parallel edge and V/2 to each parallel face, without cross-edge/face entries. S3 integrates the load in the bilinear edge test space; the left side still uses those lumped inner products. The exact inner products of those same functions have nonzero off-diagonals. This is an explicit mathematical difference, not proof of a software bug: the mimetic discretization is a legitimate selected method. Source/boundary corrections leave 13.64% / 3.00% field discrepancies under the common functional, while source pair and solve checks pass. Coarse and graded-cell approximation error remains possible even after a consistent-Hodge change. Existing evidence cannot rank electric-mass versus curl-Hodge contributions or predict their receiver-weighted effect.
2. **Residual source representation or common primary/reference error: still possible, less supported as the sole explanation.** S3 Gauss2/4 source pair 3.1493e-5 and difference pair 6.4110e-4 pass the selected 0.001 checks, but a pair is not a rigorous error bound and no adjoint-weighted source-error bound exists. Primary is shared by source and reference, so agreement of their downstream checks does not independently certify every primary assumption. S3's measured source correction slightly worsened Rx1 and improved Rx2. Another quadrature level is not justified by these data alone.
3. **Boundary/oracle mismatch: reduced but not eliminated.** S2 supplies the same continuum Born boundary with tight saved quadrature pairs and exact discrete partition/boundary preservation. That removes the selected zero-boundary approximation for this derivative experiment, within sampling accuracy. It does not make a generic radiation boundary for finite tau or prove that coarse boundary-region Hodge/field interpolation is harmless.
4. **Receiver functional defect as sole cause: contradicted for the sampled smooth reference.** Existing closure, contour/H agreement and new decomposition show the smooth-reference interpolation bias is much smaller than the failure. This does not prove accurate reconstruction of an arbitrary erroneous solved field. Increasing contour quadrature or subtracting the known oracle bias would not resolve the field gap.
5. **Linear-solve arithmetic, source sign/scaling or duplicated boundary correction: no supporting evidence in this exact case.** The independent saved-array audit verifies the source subtraction, zero B delta, unchanged gB, residual and trace; eta=4.187683382636219e-18. Tiny backward residual alone is not a forward-error bound for a conditioned system, but an unexplained solver retry is not warranted. No complex-conjugation, mu, volume or edge-length mismatch was found in the selected path.

## One proposed next implementation: consistent-Hodge delta action

**Selection requested from root, not executed here.** Implement a standalone, matrix-free local kernel for `DeltaA = A_consistent - A0` on the identical L5 cells, edge ordering and physical parameters. This is one coherent left-hand-side consistency increment matching the S3 test functions, not a new mesh, source, measurement or oracle. Write it in a new recorded evidence directory. Do not modify installed discretize, product code or previous evidence.

For local dimensionless edge functions `N_x,bc=L_b(eta)L_c(nu) xhat` and cyclic variants, define explicitly

```
M_K[i,j] = integral_K N_i dot N_j dV
K_K[i,j] = integral_K curl(N_i) dot curl(N_j) dV
A_consistent,K = mu^-1 K_K + i omega zeta0 M_K.
```

These are finite polynomial integrals, not Green evaluations. For each parallel-edge 4x4 block,

```
M_K = V * (T tensor T),  T = [[1/3,1/6],[1/6,1/3]],
M_lumped,K = (V/4) I4.
```

Cross-axis edge-mass blocks are zero. Local curl coefficients use physical 1/h derivatives with the existing positive edge orientation. Equivalently, for face-average curl unknowns the consistent two-opposing-face block is `V*T`, while the lumped block is `(V/2)*I2`; use the same oriented local C to obtain `K=C_K.T M_face C_K`. Thus the new correction should be saved as separate electric-mass and curl-Hodge actions before summation, to expose their scale and cancellation. These formulas specify edge averages; no circulation rescaling, inverse mass or conjugation is introduced. Ordinary transpose gives the complex symmetric wave operator; Hermitian products are only for separate real geometric energy checks.

Implement only local blocks and assembled **actions**, without storing global sparse matrices or any factorization. After the new local controls pass, apply DeltaA once to the saved full S3 field and retain `d_mass`, `d_curl` and their sum on I. Load the three already saved S1/S2/S3 residual vectors and add them to obtain the old accumulated residual. Then `r_consistent = r_S1+r_S2+r_S3+(DeltaA e3)[I]` measures how the frozen solution satisfies this alternative consistent weak operator. This is a new algebraic test of a new kernel, not an old-operator rerun. No old C/A action or old residual recomputation is required.

For a later independently selected solve, the mathematically correct update would be

```
A_consistent,II delta_e_I = -r_consistent,  delta_e_B=0,
e_new=e3+delta_e,  V_new=t e_new.
```

Using A0 for that correction would only be a defect iteration and would not establish the consistent-system solution. A nonzero operator defect, or a small local kernel error, does not prove response improvement. The proposed next job ends with the kernel/action evidence; it does **not** include this solve or an automatic follow-on experiment.

### New validation and stop conditions

1. Before implementation, capture one genuine new failing check for the absent delta-action kernel. Reuse all existing science passes; no old RED, old test suite or field integration is replayed.
2. On one anisotropic synthetic cell (fixed h=(0.03,0.05,0.07) m), compare every local entry with independently integrated monomials using exact rational coefficients, and separately check constant/affine fields. In particular, the parallel-edge consistent block row sums are V/4; differences annihilate a constant component; wrong 1/h or circulation scaling is rejected. Declare `128*eps*sum_abs` entry/action bounds before running and retain absolute scales. Reject duplicate/local-global ID inconsistencies rather than silently summing duplicates as cells.
3. Check curl of an interpolated nodal trilinear gradient is zero; ordinary-transpose symmetry; positive geometric mass energy and nonnegative curl energy using independent fixed real vectors. Add one deliberate reversed-edge mapping negative case. These validate this new kernel, not the old projector.
4. On the frozen mesh, assert exact node/edge/order/material pins, same I/B partition, and 19,584 cells/63,250 edges. Apply the new action once to saved e3. Preserve the full S2 boundary values as input, then restrict the action to I; ignoring boundary entries when forming DeltaA e3 would omit a changed `A_IB*gB` contribution.
5. Record separate raw operator defects, cancellation scales and units; compare them with the accumulated saved residual for scale only. **Do not set a physical pass/fail threshold from an unweighted residual norm** and do not claim it identifies receiver error. If defects are at roundoff, reject this proposed correction as numerically immaterial for that field. If resolved, return evidence to root for a separate decision; do not auto-solve or infer benefit from defect magnitude.
6. One process, one BLAS thread if NumPy is used, chunk at most 256 cells, 30 s sampled stop threshold, 512 MiB process cap, no sparse assembly/solve/network. Expected working arrays are below roughly 64 MiB (saved field/residuals and local chunks); ceiling is a proposal, not a measured guarantee. Any pin, analytic, orientation, finite-value, time or memory failure stops without retry, parameter change or broader sweep. Preserve original terminal/handles as usual.

Later physical validation, if separately selected, must retain the exact same H reference, boundary, S3 source and t and require **both receiver errors <=1%** plus the existing backward-error gate. LU cost/fill for a different operator is unknown: the old 57.453 s / 3.349 GB observation cannot be promised for the new operator. A solve requires its own root-selected resource plan and preflight. The kernel increment resolves the missing consistent-inner-product implementation and exposes its action on the saved field; it does not resolve finite-resolution accuracy, guarantee the 1% screen, or qualify finite tau/noise/OOD/training.

## Delivery and unchanged acceptance

`diagnosis.json` is the machine-readable summary; `source-pins.json`, `scope-check.json`, `scalar-reduction.json` and `collect_evidence.py` retain provenance and the only new calculation. No external sources were required; all numerical claims are either explicitly reused exact saved results or the recorded new scalar reduction.

`physical_accuracy=unqualified`, noise/calibration/OOD/training unqualified, finite tau/G03/all29 `not_run`. No hidden truth or oracle information is exposed to PC AI. Game-level 3D, causal sensing, substantive PC AI and both H12 control routes remain unchanged. Root retains difficult mathematical selection, any future solve, integration and final acceptance.
