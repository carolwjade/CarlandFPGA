"""Verify this new diagnosis package only; do not execute prior science."""
import ast
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

def put(name, value):
    with (D / name).open("x", encoding="utf-8") as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write("\n")

d = read(D / "diagnosis.json")
r = read(D / "scalar-reduction.json")
s = read(D / "scope-check.json")
p = read(D / "source-pins.json")
assert d["requirements_sha256"] == s["requirements_sha256"]
assert len(p["files"]) == d["actual_new_execution"]["source_input_hashes"] == 79
assert p["frozen_input_count_verified"] == 57
assert d["proposed_next_implementation"]["selected"] is False
assert d["G03"] == "not_run" and d["physical_accuracy"] == "unqualified"
for i, row in enumerate(r["rows"]):
    assert row["field_gap_relative_H"] == d["new_scalar_findings"]["S3_minus_sampled_reference_relative_H"][i]
    assert row["bias_relative_H"] == d["new_scalar_findings"]["reference_interpolation_bias_relative_H"][i]
    assert row["decomposition_identity_abs_V"] == 0
    assert row["field_gap_lower_bound_relative_H"] > .01
for name in ("collect_evidence.py", "verify_delivery.py"):
    ast.parse((D / name).read_text(encoding="utf-8"))
report = (D / "diagnosis.md").read_text(encoding="utf-8")
assert "13.64349701%" in report and "3.00352537%" in report
assert "not executed here" in report and "both receiver errors <=1%" in report

future = {}
for name in (
    "g03-s3-json-continuation-20261021/run-01/corrected_derivative_Vpm.npy",
    "g03-s1-cache-path-continuation-20261021/run-01/residual.npy",
    "g03-s2-boundary-correction-20261021/run-01/correction_residual.npy",
    "g03-s3-json-continuation-20261021/run-01/new_source_residual.npy",
    "g03-s3-json-continuation-20261021/projection-01/g4_projected_full_RHS.npy",
):
    path = D.parent / name
    future[path.relative_to(ROOT).as_posix()] = pin(path)
put("proposed-input-pins.json", {"scope": "future proposal inputs, byte hashing only; arrays not loaded", "files": future})
put("delivery-verification.json", {"status": "passed", "scope": "new report/JSON/schema/scalar crosschecks and script AST only", "old_science_replayed": False, "arrays_loaded": 0, "proposed_inputs_hashed": len(future)})
names = ["diagnosis.md", "diagnosis.json", "scope-check.json", "source-pins.json", "scalar-reduction.json", "collect_evidence.py", "verify_delivery.py", "proposed-input-pins.json", "delivery-verification.json"]
put("manifest.json", {"work_id": d["work_id"], "files": {name: pin(D / name) for name in names}, "private_records_included": False})
print(json.dumps({"status": "passed", "artifacts": len(names), "report_sha256": pin(D / "diagnosis.md")["sha256"], "diagnosis_json_sha256": pin(D / "diagnosis.json")["sha256"], "manifest_sha256": pin(D / "manifest.json")["sha256"]}))
