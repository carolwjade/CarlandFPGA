"""Read-only source/pin inventory and NEW scalar error decomposition.

Standard library only. No scientific module, numerical array load, old test,
operator action, field evaluation, factorization or PDE solve is executed.
Writes exclusively beside this script. No credential record is inspected.
"""
import ctypes
import hashlib
import json
import time
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
P = D.parent
started = time.perf_counter()

def read(p):
    return json.loads(p.read_text(encoding="utf-8"))

def put(name, value):
    with (D / name).open("x", encoding="utf-8") as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.write("\n")

def pin(p):
    digest = hashlib.sha256()
    with p.open("rb") as f:
        while block := f.read(1024 * 1024):
            digest.update(block)
    return {"bytes": p.stat().st_size, "sha256": digest.hexdigest()}

scope = read(ROOT / "docs/competition/deepeye-2026/immutable_scope.json")
scope_hash = hashlib.sha256(json.dumps(scope["requirements"], ensure_ascii=False,
    sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
assert scope_hash == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
assert [x["id"] for x in scope["requirements"]] == [f"H{i:02}" for i in range(1,16)]
transfer = read(ROOT / ".planning/deepeye-desktop-handoff-20261015/transfer.json")
assert transfer["status"] == "active" and transfer["director_generation"] == 2
assert transfer["new_director_thread_id"] == "01a13d7e-dcf1-7272-a738-a637dd62ff9d"
put("scope-check.json", {"requirements_sha256": scope_hash, "H01_H15": "unchanged",
    "transfer_status": transfer["status"], "director_generation": 2})

s3 = P / "g03-s3-json-continuation-20261021"
s2 = P / "g03-s2-boundary-correction-20261021"
frozen = read(s3 / "frozen-source-pins.json")
assert len(frozen) == 57
files = {}
for name, expected in frozen.items():
    current = pin(ROOT / name)
    assert current == {k: expected[k] for k in ("bytes", "sha256")}, name
    files[name] = current

selected = {
    "g03-s3-source-projection-design-20261021": ["design.md", "source-pins.json", "source-evidence.json", "reuse-inputs.json"],
    "g03-s3-json-continuation-20261021": ["report.md", "result.json", "main-selection.json", "assignment.json", "manifest.json", "frozen-source-pins.json", "s3_data.py", "s3_projector.py", "s3_stages.py", "s3_worker.py", "run-01/result.json"],
    "g03-s3-json-independent-review-20261021": ["report.md", "result.json", "audit_math.py", "audit_saved.py", "run-01/audit.json"],
    "g03-s1-cache-path-continuation-20261021": ["assignment.json", "s1_model.py", "s1_geometry.py", "s1_oracle.py", "s1_worker.py"],
    "g03-s2-boundary-correction-20261021": ["s2_stages.py", "s2_electric.py", "report.md", "controls-01/result.json", "controls-01/receiver_reference_trace_V.npy", "controls-01/functional_bias_V.npy", "controls-01/E_line_V.npy", "run-01/result.json"],
    "g03-l5-propagation-z-refinement-20261021": ["assignment.json", "grid_model.py", "grid_worker.py"],
}
for directory, names in selected.items():
    for name in names:
        path = P / directory / name
        files[path.relative_to(ROOT).as_posix()] = pin(path)
for name in ["docs/competition/deepeye-2026/immutable_scope.md", "docs/competition/deepeye-2026/immutable_scope.json",
    ".planning/deepeye-desktop-handoff-20261015/transfer.json",
    ".planning/deepeye-resume-20261018/continuation-current-increment-20261022.md",
    ".local/deepeye-fdem-validation-20261020/Lib/site-packages/simpeg/electromagnetics/frequency_domain/simulation.py",
    ".local/deepeye-fdem-validation-20261020/Lib/site-packages/discretize/operators/inner_products.py",
    ".local/deepeye-fdem-validation-20261020/Lib/site-packages/discretize/operators/differential_operators.py",
    ".local/deepeye-fdem-validation-20261020/Lib/site-packages/discretize/base/base_tensor_mesh.py"]:
    files[name] = pin(ROOT / name)

# Check the 11 selected S3 source/receipt files against its existing manifest;
# no prior numerical audit or complete manifest audit is rerun.
manifest = read(s3 / "manifest.json")["files"]
bound = []
for name in selected["g03-s3-json-continuation-20261021"]:
    if name in manifest:
        actual = files[(s3 / name).relative_to(ROOT).as_posix()]
        assert actual == {k: manifest[name][k] for k in ("bytes", "sha256")}, name
        bound.append(name)
put("source-pins.json", {"files": dict(sorted(files.items())), "frozen_input_count_verified": 57,
    "selected_S3_manifest_matches": bound, "scope": "byte integrity, not science rerun"})

# New reduction: split final S3 voltage discrepancy using the ALREADY SAVED
# smooth-reference edge interpolation voltage. This was not the old residual
# audit and uses only short JSON vectors. B is diagnostic, never a correction.
r3 = read(s3 / "run-01/result.json")
c2 = read(s2 / "controls-01/result.json")
as_complex = lambda a: complex(a[0], a[1])
pair = lambda z: [z.real, z.imag]
rows = []
for receiver in range(2):
    v3 = as_complex(r3["V_S3_V"][receiver])
    href = as_complex(r3["saved_H_V"][receiver])
    sampled = as_complex(c2["receiver_trace_reference_V"][2 + receiver])
    residual = v3 - href
    bias = sampled - href
    field_gap = v3 - sampled
    rows.append({"receiver": receiver + 1, "S3_V": pair(v3), "H_reference_V": pair(href),
        "sampled_reference_trace_V": pair(sampled), "residual_V": pair(residual),
        "reference_interpolation_bias_V": pair(bias), "S3_minus_sampled_reference_V": pair(field_gap),
        "residual_relative_H": abs(residual) / abs(href),
        "bias_relative_H": abs(bias) / abs(href),
        "field_gap_relative_H": abs(field_gap) / abs(href),
        "field_gap_lower_bound_relative_H": (abs(residual) - abs(bias)) / abs(href),
        "complex_ratio_S3_over_H": pair(v3 / href),
        "decomposition_identity_abs_V": abs(residual - (field_gap + bias))})

class PMC(ctypes.Structure):
    _fields_ = [("cb", ctypes.c_ulong), ("PageFaultCount", ctypes.c_ulong)] + [
        (name, ctypes.c_size_t) for name in ("PeakWorkingSetSize", "WorkingSetSize",
        "QuotaPeakPagedPoolUsage", "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage",
        "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage")]
kernel = ctypes.WinDLL("kernel32", use_last_error=True)
kernel.GetCurrentProcess.restype = ctypes.c_void_p
psapi = ctypes.WinDLL("psapi", use_last_error=True)
psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.POINTER(PMC), ctypes.c_ulong]
pmc = PMC(); pmc.cb = ctypes.sizeof(pmc)
assert psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(pmc), pmc.cb)
elapsed = time.perf_counter() - started
assert elapsed < 30 and pmc.PeakWorkingSetSize < 512 * 1024**2
put("scalar-reduction.json", {"kind": "new scalar decomposition of saved JSON voltages",
    "rows": rows, "elapsed_seconds_including_hashes": elapsed,
    "peak_working_set_bytes": pmc.PeakWorkingSetSize,
    "array_loads": 0, "old_test_runs": 0, "PDE_solves": 0, "Green_evaluations": 0,
    "operator_actions": 0, "interpretation": "Field gap relative to interpolated smooth reference; not a unique error decomposition or permission to subtract oracle bias from product output."})
print(json.dumps({"scope_hash": scope_hash, "pins": len(files), "frozen_inputs_matched":57,
    "elapsed_seconds":elapsed, "peak_working_set_bytes":pmc.PeakWorkingSetSize,
    "rows":rows}, indent=2))
