"""New coupled overlap, boundary algebra, and analytic circle controls only."""
import itertools,math
from fractions import Fraction as F
import numpy as np
from evidence_json import write_new_report as save
import coupled_moments as cm
EPS=np.finfo(float).eps
def mul(a,b):
 out={}
 for i,x in a.items():
  for j,y in b.items():
   k=tuple(i[d]+j[d] for d in range(3));out[k]=out.get(k,F(0))+x*y
 return {k:v for k,v in out.items() if v}
def physical_q(box,n,t,side):
 b=3-n-t;lo,hi=box;h=[hi[j]-lo[j] for j in range(3)];one={(0,0,0):F(1)}
 def coordinate(j):
  e=[0,0,0];e[j]=1;return {(0,0,0):-lo[j]/h[j],tuple(e):1/h[j]}
 sn=coordinate(n);sb=coordinate(b)
 def subone(a):return {k:one.get(k,F(0))-a.get(k,F(0)) for k in set(one)|set(a)}
 q=mul(sn if side==0 else subone(sn),mul(sb,subone(sb)))
 return {k:4*v for k,v in q.items()}
def derivative(q,j):return {tuple(k[d]-(d==j) for d in range(3)):v*k[j] for k,v in q.items() if k[j]}
def curl(q,t):
 out=[{} for _ in range(3)]
 for j in range(3):
  if j==t:continue
  c=3-j-t;sgn=1 if (c,j,t) in ((0,1,2),(1,2,0),(2,0,1)) else -1
  out[c]={k:sgn*v for k,v in derivative(q,j).items()}
 return out
def integral(q,box):
 lo,hi=box
 return sum((v*math.prod((hi[j]**(k[j]+1)-lo[j]**(k[j]+1))/F(k[j]+1) for j in range(3)) for k,v in q.items()),F(0))
def oracle(box,a,b):
 qa=physical_q(box,*a);qb=physical_q(box,*b);ca=curl(qa,a[1]);cb=curl(qb,b[1])
 return integral(mul(qa,qb),box) if a[1]==b[1] else F(0),sum((integral(mul(x,y),box) for x,y in zip(ca,cb)),F(0))
def run(stage):
 boxes=[[[F(1,3),F(-1,4),F(2,5)],[F(11,6),F(1),F(43,20)]],[[F(11,6),F(-1,4),F(2,5)],[F(37,12),F(1),F(43,20)]]]
 entries=[[(0,(0,1,0)),(1,(2,1,1)),(2,(1,0,0))],[(0,(0,1,1)),(3,(2,1,1))]]
 exact=[]
 for ci,entry in enumerate(entries):
  for ga,a in entry:
   for gb,b in entry:
    m,k=oracle(boxes[ci],a,b);exact.append({'cell':ci,'row':ga,'col':gb,'M':str(m),'K':str(k)})
 save(stage/'independent-expectations.json',{'physical_Fraction_pairs':exact,'partial_circle_trace':'-sqrt(3)/2-pi/12','partial_patch_x':'[-2,0] and [0,1/2]','partial_patch_y':'[-2,2]','partial_patch_z':'[0,2]','circle':'center(0,0,1), A(1,0,0), B(0,1,0)','new_controls_only':True})
 errors=[]
 def check(got,want,scale):
  error=float(np.max(abs(np.asarray(got)-np.asarray(want)),initial=0));bound=4096*EPS*float(np.max(np.asarray(scale),initial=0));assert error<=bound,(error,bound);errors.append(error)
 M=np.zeros((4,4));K=np.zeros((4,4));Ms=np.zeros((4,4));Ks=np.zeros((4,4));EM=np.zeros((4,4));EK=np.zeros((4,4));row=0
 for ci,entry in enumerate(entries):
  widths=[float(b-a) for a,b in zip(*boxes[ci])]
  for ga,a in entry:
   for gb,b in entry:
    out=cm.local_pair(widths,a,b);em,ek=oracle(boxes[ci],a,b)
    check(out['M'],float(em),out['Ms']);check(out['K'],float(ek),out['Ks'])
    M[ga,gb]+=out['M'];K[ga,gb]+=out['K'];Ms[ga,gb]+=out['Ms'];Ks[ga,gb]+=out['Ks'];EM[ga,gb]+=float(em);EK[ga,gb]+=float(ek);row+=1
 check(M,EM,Ms);check(K,EK,Ks);check(M,M.T,Ms+Ms.T);check(K,K.T,Ks+Ks.T)
 assert M[1,3]==K[1,3]==0 and M[0,1]!=0 and K[0,2]!=0
 D=K+(2+3j)*M;assert np.max(abs(D-np.diag(np.diag(D))))>1e6*EPS*np.max(abs(D))
 # Exactly two free coarse and two bubble unknowns, plus one nonzero boundary datum.
 A=np.array([[4+1j,1-.5j],[1-.5j,3+2j]]);U=np.array([[.5+1j,-.3j],[.25-.4j,.8+.2j]]);DB=np.array([[2+.5j,.3+.7j],[.3+.7j,1.5+.9j]])
 AIB=np.array([[.2+.3j],[.6-.2j]]);UB=np.array([[.4-.1j,-.2+.6j]]);g=np.array([.7-.4j]);e=np.array([.3+.2j,-.1+.4j]);alpha=np.array([-.2+.1j,.5-.3j])
 b=A@e+U@alpha+AIB@g;fq=U.T@e+DB@alpha+UB.T@g;omega=7.;joint_current=np.r_[b,fq]/(-1j*omega)
 bi,fi=cm.boundary_rhs(b,fq,AIB,UB,g)
 check(bi,A@e+U@alpha,abs(b)+abs(AIB)@abs(g));check(fi,U.T@e+DB@alpha,abs(fq)+abs(UB.T)@abs(g))
 invD=np.array([[DB[1,1],-DB[0,1]],[-DB[1,0],DB[0,0]]])/(DB[0,0]*DB[1,1]-DB[0,1]*DB[1,0])
 S=A-U@invD@U.T;rhs=bi-U@invD@fi;check(S@e,rhs,abs(A)@abs(e)+abs(U)@abs(invD)@abs(fi))
 recovered=invD@(fi-U.T@e);check(recovered,alpha,abs(invD)@(abs(fi)+abs(U.T)@abs(e)))
 negatives={'missing_boundary':max(np.max(abs(b-bi)),np.max(abs(fq-fi))),'conjugate_transpose':np.max(abs(U.conj().T@e-U.T@e)),'wrong_source_factor':np.max(abs(joint_current-np.r_[b,fq])),'diagonal_D':np.max(abs((DB-np.diag(np.diag(DB)))@alpha))}
 assert all(x>1e6*EPS for x in negatives.values())
 import bubble_trace as bt
 patch=np.array([[[-2.,-2.,0.],[0.,2.,2.]],[[0.,-2.,0.],[.5,2.,2.]]]);c=np.array([0.,0.,1.]);aa=np.array([1.,0.,0.]);bb=np.array([0.,1.,0.])
 trace,scale,info=bt.trace_patch(patch,0,1,c,aa,bb);want=-math.sqrt(3)/2-math.pi/12
 check(trace,want,scale+abs(want));reverse,rs,ri=bt.trace_patch(patch,0,1,c,aa,-bb);check(reverse,-want,rs+abs(want));assert abs(trace-reverse)>1e6*EPS*scale
 tangent=bt.plane_roots(0.,1.,0.,1.);assert tangent['classification']=='tangent' and tangent['roots']==[0.]
 periodic=bt.plane_roots(0.,0.,1.,0.);assert periodic['classification']=='crossing' and periodic['roots'][0]==0. and len(periodic['roots'])==2
 coplanar=bt.plane_roots(1.,0.,0.,1.);assert coplanar['classification']=='coplanar' and not coplanar['roots']
 no=bt.plane_roots(0.,1.,0.,2.);assert no['classification']=='outside' and not no['roots']
 # Coplanar shared face must be visited once, even though both cell boxes contain it.
 shared,ss,si=bt.trace_patch(patch,0,1,c,np.array([0.,.5,0.]),np.array([0.,0.,.5]))
 check(shared,0.,ss);assert si['shared_face_intervals']==1 and si['active_intervals']==1
 return {'status':'new_coupled_controls_pass','new_physical_Fraction_pair_checks':row,'new_manufactured_block':'2 free coarse, 2 bubbles, 1 fixed boundary','ordinary_transpose':True,'negative_directions':{k:float(v) for k,v in negatives.items()},'partial_circle_trace':float(trace),'partial_circle_expected':want,'trace_cases':['partial','reverse','tangent','periodic_endpoint','coplanar_shared_face','outside'],'comparison_count':len(errors),'maximum_absolute_error':max(errors),'old_tests_replayed':0,'physical_source_or_solver_calls':0}
