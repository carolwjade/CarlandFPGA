"""Exact normalized overlap table, physical derivatives, ordinary transpose."""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import math,sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'g03-face-enrichment-20261023'))
from face_probe_moments import deriv,sign
def factors(descriptor):
    n,t,side=descriptor
    if n not in (0,1,2) or t not in (0,1,2) or n==t or side not in (0,1):raise ValueError('bubble descriptor')
    q=[(1,)]*3;q[n]=(0,1) if side==0 else (1,-1);q[3-n-t]=(0,4,-4)
    return q
def product(a,b):
    value=F(1);scale=F(1)
    for x,y in zip(a,b):
        terms=[F(c)*F(d)/F(i+j+1) for i,c in enumerate(x) for j,d in enumerate(y)]
        value*=sum(terms,F(0));scale*=sum((abs(z) for z in terms),F(0))
    return value,scale
@lru_cache(maxsize=144)
def table(first,second):
    a=factors(first);b=factors(second);n,t,s=first;m,u,r=second
    mass,ms=product(a,b) if t==u else (F(0),F(0));terms=[]
    for j in (n,3-n-t):
        c=3-j-t;da=list(a);da[j]=deriv(da[j])
        for k in (m,3-m-u):
            if 3-k-u!=c:continue
            db=list(b);db[k]=deriv(db[k]);v,sc=product(da,db)
            terms.append((j,k,sign(c,j,t)*sign(c,k,u)*v,sc))
    return mass,ms,terms
def local_pair(widths,first,second):
    h=tuple(float(x) for x in widths)
    if len(h)!=3 or any(not math.isfinite(x) or x<=0 for x in h):raise ValueError('positive finite widths')
    mass,ms,terms=table(tuple(first),tuple(second));v=math.prod(h)
    kvals=[v*float(k)/(h[j]*h[r]) for j,r,k,sc in terms];ks=[v*float(sc)/(h[j]*h[r]) for j,r,k,sc in terms]
    return {'M':v*float(mass),'K':math.fsum(kvals),'Ms':v*float(ms),'Ks':math.fsum(ks)}
def boundary_rhs(b,fq,A_IB,U_B,gB):
    return np.asarray(b)-np.asarray(A_IB)@np.asarray(gB),np.asarray(fq)-np.asarray(U_B).T@np.asarray(gB)
