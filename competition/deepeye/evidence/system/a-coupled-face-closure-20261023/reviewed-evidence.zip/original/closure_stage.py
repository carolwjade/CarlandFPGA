"""One new bounded local coupled-space/trace assembly; no global solve."""
import hashlib,json,math,sys
from pathlib import Path
import numpy as np
from evidence_json import write_new_report as save
import coupled_moments as coupling
import bubble_trace
D=Path(__file__).resolve().parent;P=D.parent;ROOT=D.parents[2];EPS=np.finfo(float).eps
sys.path.insert(0,str(P/'g03-face-enrichment-20261023'));import face_probe_moments as accepted
sys.path.insert(0,str(P/'g03-s1-cache-path-continuation-20261021'));from s1_geometry import selected_coils
def read(p):return json.loads(p.read_text(encoding='utf8'))
def path(alias):
 spec=read(D/'input-pins.json');name=spec['aliases'][alias];p=ROOT/name
 if p.stat().st_size!=spec['files'][name]['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=spec['files'][name]['sha256']:raise ValueError('input pin '+alias)
 return p
def load(alias):
 value=np.load(path(alias),allow_pickle=False)
 if not np.all(np.isfinite(value)):raise ValueError('nonfinite '+alias)
 return value
def array(stage,name,value):
 if not np.all(np.isfinite(value)):raise ValueError('nonfinite output '+name)
 with (stage/(name+'.npy')).open('xb') as f:np.save(f,value,allow_pickle=False)
def choose(keys,cells,score,resolved):
 N=len(keys)
 if keys.shape!=(113088,5) or cells.shape!=(N,2) or score.shape!=(N,) or resolved.shape!=(N,) or resolved.dtype!=np.bool_ or np.any(score<0):raise ValueError('fixed selection arrays')
 canonical=np.lexsort((keys[:,4],keys[:,3],keys[:,2],keys[:,1],keys[:,0]))
 if not np.array_equal(canonical,np.arange(N)):raise ValueError('saved canonical order')
 order=np.lexsort((keys[:,4],keys[:,3],keys[:,2],keys[:,1],keys[:,0],-score));available=order[resolved[order]]
 if len(available)<128:raise ValueError('insufficient fixed seeds')
 seeds=available[:128];marked=np.unique(cells[seeds])
 if len(marked)>134:raise ValueError('marked cell cap')
 mask=np.zeros(19584,bool);mask[marked]=True;closure=np.flatnonzero(mask[cells[:,0]]&mask[cells[:,1]])
 if len(closure)>804 or len(closure)==0 or len(closure)%2:raise ValueError('closure direction cap or pairing')
 selected=keys[closure]
 if not np.array_equal(selected[::2,:4],selected[1::2,:4]) or np.any(selected[::2,4]==selected[1::2,4]):raise ValueError('both tangent modes required')
 return seeds.astype(np.int32),marked.astype(np.int32),closure.astype(np.int32)
def run(stage):
 keys=load('keys');cells=load('cells');seeds,marked,ids=choose(keys,cells,load('score8'),load('resolved8'));Q=len(ids)
 bounds=load('bounds');mapping=load('mapping');B=load('B');gB=load('gB')
 if bounds.shape!=(19584,2,3) or mapping.shape!=(19584,12) or B.shape!=(8832,) or gB.shape!=(8832,):raise ValueError('fixed saved geometry/boundary')
 selected_keys=keys[ids];selected_cells=cells[ids];cell_entries={int(c):[] for c in marked}
 for q,(key,pair) in enumerate(zip(selected_keys,selected_cells)):
  n=int(key[0]);t=int(key[4]);left,right=bounds[pair]
  if left[1,n]!=right[0,n] or any(not np.array_equal(left[:,j],right[:,j]) for j in range(3) if j!=n):raise ValueError('shared nominal face')
  for side,c in enumerate(pair):cell_entries[int(c)].append((q,(n,t,side)))
 ordered_pairs=sum(len(v)**2 for v in cell_entries.values());coarse_pairs=12*sum(len(v) for v in cell_entries.values())
 if ordered_pairs>19296 or coarse_pairs>19296 or any(len(v)>12 for v in cell_entries.values()):raise ValueError('local contribution cap')
 save(stage/'before-assembly.json',{'seed_count':128,'marked_cells':len(marked),'closure_directions':Q,'local_ordered_bubble_pairs':ordered_pairs,'local_coarse_bubble_pairs':coarse_pairs,'source_and_field_calls':0,'global_operator_actions':0,'PDE_solves':0,'coarse_trace_recomputed':False,'local_form':'ordinary transpose, full cross-face and cross-tangent overlap'})
 p=read(path('S1_assignment'))['inputs'];omega=2*math.pi*p['frequency_Hz'];mu=p['mu_background_Hpm'];zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm'];coeff=1j*omega*zeta
 # Lists retain every local contribution; deterministic fsum follows sorted cells.
 block={};coarse={}
 for cell,entries in sorted(cell_entries.items()):
  h=bounds[cell,1]-bounds[cell,0]
  for qa,a in entries:
   lm=accepted.local_moments(h[None,:],*a)
   for edge,m,k,ms,ks in zip(mapping[cell],lm['M'][0],lm['K'][0],lm['Ms'][0],lm['Ks'][0]):
    entry=coarse.setdefault((int(edge),qa),[[],[]]);entry[0].append(k/mu+coeff*m);entry[1].append(ks/mu+abs(coeff)*ms)
   for qb,b in entries:
    out=coupling.local_pair(h,a,b);entry=block.setdefault((qa,qb),[[],[],[],[]])
    for target,name in zip(entry,('M','K','Ms','Ks')):target.append(out[name])
 pairs=sorted(block);rows=np.array([x[0] for x in pairs],np.int32);cols=np.array([x[1] for x in pairs],np.int32)
 values=np.array([[math.fsum(v) for v in block[key]] for key in pairs]);M,K,Ms,Ks=values.T;DD=K/mu+coeff*M;Ds=Ks/mu+abs(coeff)*Ms
 if len(pairs)>ordered_pairs:raise ValueError('block scatter bound')
 lookup={pair:i for i,pair in enumerate(pairs)};transpose=np.array([lookup[(b,a)] for a,b in pairs])
 if np.any(abs(M-M[transpose])>128*EPS*(Ms+Ms[transpose])) or np.any(abs(K-K[transpose])>128*EPS*(Ks+Ks[transpose])):raise ArithmeticError('ordinary symmetry')
 diagonal=np.array([lookup[(i,i)] for i in range(Q)]);expected_M=load('Mq')[ids];expected_K=load('Kq')[ids]
 if np.any(abs(M[diagonal]-expected_M)>128*EPS*(Ms[diagonal]+abs(expected_M))) or np.any(abs(K[diagonal]-expected_K)>128*EPS*(Ks[diagonal]+abs(expected_K))):raise ArithmeticError('new block versus accepted diagonal identity')
 ukeys=sorted(coarse);urows=np.array([x[0] for x in ukeys],np.int32);ucols=np.array([x[1] for x in ukeys],np.int32)
 U=np.array([complex(math.fsum(x.real for x in coarse[key][0]),math.fsum(x.imag for x in coarse[key][0])) for key in ukeys]);Us=np.array([math.fsum(coarse[key][1]) for key in ukeys])
 if len(U)>16080 or np.any(np.bincount(ucols,minlength=Q)>20):raise ValueError('U entry cap')
 fQ=load('F8')[ids];ellQ=load('ell8')[ids];b8=load('b8');delta=load('delta_b8_minus_b4')
 if b8.shape!=(63250,) or delta.shape!=(63250,) or np.any(b8[B]!=0) or np.any(delta[B]!=0):raise ValueError('consistent coarse source boundary')
 boundary_mask=np.isin(urows,B)
 # Preserve the complete new algebra before the new trace and all reports.
 for name,value in {'seed_indices':seeds,'seed_keys':keys[seeds],'marked_cells':marked,'closure_indices':ids,'closure_keys':selected_keys,'closure_cells':selected_cells,'Q_rows':rows,'Q_cols':cols,'MQ':M,'KQ':K,'MQ_absolute_scale':Ms,'KQ_absolute_scale':Ks,'D':DD,'D_absolute_scale':Ds,'U_rows':urows,'U_cols':ucols,'U':U,'U_absolute_scale':Us,'U_boundary_rows_mask':boundary_mask,'F8_Q':fQ,'ell8_Q':ellQ}.items():array(stage,name,value)
 _,receivers=selected_coils(p);trace=np.zeros((2,Q));trace_scale=np.zeros((2,Q));stats=np.zeros((2,Q,5));events=[]
 for r,receiver in enumerate(receivers):
  center=receiver.c;A=receiver.a*receiver.u;BB=receiver.a*receiver.v
  for q,(key,pair) in enumerate(zip(selected_keys,selected_cells)):
   value,scale,info=bubble_trace.trace_patch(bounds[pair],int(key[0]),int(key[4]),center,A,BB)
   trace[r,q]=p['turns']*value;trace_scale[r,q]=abs(p['turns'])*scale
   stats[r,q]=[info['intervals'],info['active_intervals'],info['shared_face_intervals'],max(x['root_residual_max'] for x in info['planes']),max(x['root_residual_scale'] for x in info['planes'])]
   events.append({'receiver':r,'column':q,**info})
 for name,value in {'tQ':trace,'tQ_absolute_scale':trace_scale,'trace_interval_root_statistics':stats}.items():array(stage,name,value)
 save(stage/'trace-events.json',events)
 off=rows!=cols
 return {'status':'coupled_face_assembly_completed','fixed_seed_count':128,'marked_cells':len(marked),'closure_directions':Q,'local_ordered_bubble_pairs':ordered_pairs,'local_coarse_bubble_pairs':coarse_pairs,'U_entries':len(U),'U_boundary_entries':int(np.count_nonzero(boundary_mask)),'coupled_block_entries':len(pairs),'nonzero_offdiagonal_MQ':int(np.count_nonzero(M[off])),'nonzero_offdiagonal_KQ':int(np.count_nonzero(K[off])),'new_block_diagonals_match_accepted':True,'ordinary_symmetry_verified':True,'trace_nonzero_entries':int(np.count_nonzero(trace)),'trace_active_intervals':int(stats[:,:,1].sum()),'trace_total_intervals':int(stats[:,:,0].sum()),'trace_max_root_residual':float(np.max(stats[:,:,3])),'trace_zero_reason':'no active patch support on either receiver' if not np.any(stats[:,:,1]) else 'see exact per-column interval events','consistent_b8_delta_provenance_retained':True,'full_boundary_U_rows_retained':True,'F8_Q_ell8_Q_direct_saved_indexing':True,'source_or_field_evaluations':0,'coarse_trace_recomputed':False,'old_tests_replayed':0,'global_operator_actions':0,'factorizations':0,'PDE_solves':0,'original_GMRES_info':3,'original_disjoint_coverage_failure_unchanged':True,'physical_receiver_gate':.01,'physical_receiver_screens':'not_run','physical_accuracy':'unqualified','finite_strength_noise_OOD_runtime':'not_run','G03':'not_run','R03':'not_run','all29':'not_run','root_acceptance':'pending'}
