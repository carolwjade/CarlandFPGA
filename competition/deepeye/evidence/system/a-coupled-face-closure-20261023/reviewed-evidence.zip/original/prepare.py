"""Inert pins and array headers; no scientific imports or payload decoding."""
import ast,hashlib,json,struct,sys
from pathlib import Path
D=Path(__file__).resolve().parent;P=D.parent;ROOT=D.parents[2]
HELPER=ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py'
sys.path.insert(0,str(HELPER.parent));from evidence_json import write_new_report as save,dumps_report
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def header(p):
 with p.open('rb') as f:
  assert f.read(6)==b'\x93NUMPY';v=tuple(f.read(2));n=struct.unpack('<H' if v==(1,0) else '<I',f.read(2 if v==(1,0) else 4))[0]
  return ast.literal_eval(f.read(n).decode('latin1' if v[0]<3 else 'utf8'))
files={};aliases={}
def add(alias,path,expected=None):
 value=pin(path)
 if expected is not None:assert value==expected,(alias,value,expected)
 name=path.relative_to(ROOT).as_posix();files[name]=value
 if alias:aliases[alias]=name
face=P/'g03-face-enrichment-20261023';source=P/'g03-source8-enrichment-20261023';design=P/'g03-next-space-design-20261023'
for folder,sha in [(face,'be76a5f5fd79c84e4396bea30fd7ce7214c62757c44c46eb63ab90c73ab0781c'),(source,'1675faac6617b77609ecf9b524c0c3768325a869543227124a16436d77f1059a'),(design,'d1607e6dde579490a0d5a950334489fb36c8f107a56538acb19e0bf119fbf8e9')]:
 assert pin(folder/'manifest.json')['sha256']==sha;add(None,folder/'manifest.json')
fm=read(face/'manifest.json')['files'];sm=read(source/'manifest.json')['files'];dm=read(design/'manifest.json')['files']
for n in ('design.md','design.json'):add(None,design/n,dm[n])
for n in ('face_probe_geometry.py','face_probe_moments.py'):add(None,face/n,fm[n])
for n in ('keys','cells','Mq','Kq'):
 rel='indicator-01/'+n+'.npy';add(n,face/rel,fm[rel])
for n in ('score8','resolved8','F8','ell8','b8','delta_b8_minus_b4'):
 rel='source-01/'+n+'.npy';add(n,source/rel,sm[rel])
old=read(P/'g03-consistent-solve-20261023/input-pins.json')
for a in ('bounds','mapping','B','gB','trace','L5_assignment','S1_assignment'):
 n=old['paths'][a];add(a,ROOT/n,old['files'][n])
s1=P/'g03-s1-cache-path-continuation-20261021';add(None,s1/'s1_geometry.py',read(s1/'manifest.json')['files']['s1_geometry.py'])
decision=P/'g03-source8-main-review-20261023/decision.json';assert read(decision)['decision']=='ACCEPT_SOURCE8_CONSISTENCY_AND_NEGATIVE_BOUNDED_ENRICHMENT_EVIDENCE';add(None,decision)
add(None,P/'g03-coupled-face-main-review-20261023/implementation-selection.json')
for path in [HELPER,P/'r02-amd-wheel-acquisition-20261021/win_job.py',P/'r02-amd-wheel-acquisition-20261021/boundary.py',ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe']:add(None,path)
assert pin(HELPER)['sha256']=='a0aabdbf259f7232bf3e1e77a81d130a8f676ad0b87eba39fae99d118f858554'
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
assert hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json');assert transfer['status']=='active' and transfer['director_generation']==2
headers={a:header(ROOT/n) for a,n in aliases.items() if n.endswith('.npy')}
assert headers['keys']['shape']==(113088,5) and headers['score8']['shape']==(113088,) and headers['trace']['shape']==(2,63250)
save(D/'input-pins.json',{'files':files,'aliases':aliases,'headers':headers,'payloads_decoded':0,'canonical_scope_verified':True,'coarse_trace_reference_only':True})
print(dumps_report({'status':'inert_preflight_pass','pins':len(files),'headers':len(headers)}),end='')
