"""Plane-split analytic circle traces; no point quadrature or coordinate snapping."""
import cmath,math
from decimal import Decimal,localcontext
from fractions import Fraction
import numpy as np
EPS=np.finfo(float).eps;TAU=2*math.pi
def plane_roots(center,A,B,plane):
    values=tuple(float(x) for x in (center,A,B,plane))
    if any(not math.isfinite(x) for x in values):raise ValueError('finite plane data')
    center,A,B,plane=values
    # 4096 decimal digits exceed the exact common-exponent product length of
    # any two finite binary64 values (including subnormals). No tolerance is
    # used to turn a crossing into a tangent or a near plane into coplanarity.
    with localcontext() as ctx:
        ctx.prec=4096;c,a,b,p=map(Decimal.from_float,values);C=p-c;delta=a*a+b*b-C*C
        if A==0 and B==0:
            return {'classification':'coplanar' if C==0 else 'outside','roots':[],'root_branches':[],'root_residual_max':0.,'root_residual_scale':0.}
        if delta<0:return {'classification':'outside','roots':[],'root_branches':[],'root_residual_max':0.,'root_residual_scale':0.}
        tangent=delta==0;endpoint=C==a;df=float(delta);cf=float(C)
    if not tangent and (not math.isfinite(df) or df<=0):raise ArithmeticError('unresolved positive root discriminant')
    if not math.isfinite(cf):raise ArithmeticError('unrepresentable plane offset')
    phase=math.atan2(B,A);offset=math.atan2(math.sqrt(df),cf)
    roots=[(phase+offset)%TAU] if tangent else [(phase-offset)%TAU,(phase+offset)%TAU]
    branches=[0] if tangent else [1,-1] # sign of -A*sin(theta)+B*cos(theta)
    if endpoint:roots[min(range(len(roots)),key=lambda i:min(roots[i],TAU-roots[i]))]=0.
    if not tangent and len(set(roots))!=2:raise ArithmeticError('distinct crossings collapsed to one floating root')
    ordered=sorted(zip(roots,branches));roots=[x[0] for x in ordered];branches=[x[1] for x in ordered]
    if any(t==0. or t==TAU for t in roots) and not endpoint:raise ArithmeticError('nonendpoint root rounded to periodic endpoint')
    if TAU in roots:raise ArithmeticError('root represented at both periodic endpoints')
    residual=max((abs(A*math.cos(t)+B*math.sin(t)-cf) for t in roots),default=0.)
    scale=abs(A)+abs(B)+abs(cf)
    if not math.isfinite(residual) or not math.isfinite(scale):raise ArithmeticError('unrepresentable root residual scale')
    if residual>64*EPS*scale:raise ArithmeticError('root residual outside floating scale')
    return {'classification':'tangent' if tangent else 'crossing','roots':roots,'root_branches':branches,'root_residual_max':residual,'root_residual_scale':scale}
def same_circle_root(first,second,center,A,B,first_branch,second_branch):
    # For two equal floating angles, prove their two exact stored-float plane
    # equations share a unit-circle point. Never merge merely close roots.
    j,p=first;k,q=second;f=Fraction.from_float
    a,b,c=f(float(A[j])),f(float(B[j])),f(p)-f(float(center[j]))
    d,e,g=f(float(A[k])),f(float(B[k])),f(q)-f(float(center[k]))
    determinant=a*e-d*b
    if determinant==0:
        if not (a*g==d*c and b*g==e*c):return False
        ratio=d/a if a else e/b
        return second_branch==(1 if ratio>0 else -1)*first_branch
    cosine_numerator=c*e-g*b;sine_numerator=a*g-d*c
    if cosine_numerator**2+sine_numerator**2!=determinant**2:return False
    derivative_first=(-a*sine_numerator+b*cosine_numerator)/determinant
    derivative_second=(-d*sine_numerator+e*cosine_numerator)/determinant
    sign=lambda x:1 if x>0 else -1 if x<0 else 0
    return sign(derivative_first)==first_branch and sign(derivative_second)==second_branch
def polynomial(constant,cosine=0.,sine=0.):
    values={0:complex(constant),1:complex(cosine,-sine)/2,-1:complex(cosine,sine)/2}
    return values,{k:abs(v) for k,v in values.items()}
def add_one_minus(poly):
    a,scale=poly;out={k:-v for k,v in a.items()};out[0]+=1;sc=dict(scale);sc[0]+=1
    return out,sc
def multiply(first,second):
    a,sa=first;b,sb=second;out={};scale={}
    for i,x in a.items():
        for j,y in b.items():
            out[i+j]=out.get(i+j,0j)+x*y;scale[i+j]=scale.get(i+j,0.)+sa[i]*sb[j]
    return out,scale
def integrate(poly,lo,hi):
    values,scales=poly;mid=(lo+hi)/2;half=(hi-lo)/2;terms=[]
    if max(abs(k) for k in values)>4:raise ValueError('trace degree')
    for k,c in values.items():
        primitive=(hi-lo) if k==0 else cmath.exp(1j*k*mid)*(2*math.sin(k*half)/k)
        terms.append(c*primitive)
    value=complex(math.fsum(t.real for t in terms),math.fsum(t.imag for t in terms));scale=math.fsum(scales.values())*(hi-lo)
    if abs(value.imag)>128*EPS*scale:raise ArithmeticError('nonreal analytic trace')
    return value.real,scale
def trace_patch(bounds,n,t,center,A,B):
    bounds=np.asarray(bounds,float);center=np.asarray(center,float);A=np.asarray(A,float);B=np.asarray(B,float)
    if bounds.shape!=(2,2,3) or center.shape!=(3,) or A.shape!=(3,) or B.shape!=(3,) or n==t or n not in (0,1,2) or t not in (0,1,2):raise ValueError('trace geometry')
    if any(not np.all(np.isfinite(x)) for x in (bounds,center,A,B)) or np.any(bounds[:,1]<=bounds[:,0]):raise ValueError('finite positive trace geometry')
    if bounds[0,1,n]!=bounds[1,0,n] or any(not np.array_equal(bounds[0,:,j],bounds[1,:,j]) for j in range(3) if j!=n):raise ValueError('two-cell shared face')
    planes=sorted({(j,float(bounds[s,k,j])) for s in (0,1) for k in (0,1) for j in range(3)})
    if len(planes)>7:raise ValueError('patch plane bound')
    cuts={0.,TAU};root_planes={};events=[]
    for j,p in planes:
        event=plane_roots(center[j],A[j],B[j],p);events.append({'axis':j,'plane':p,**event})
        for angle,branch in zip(event['roots'],event['root_branches']):
            if angle in root_planes:
                previous,previous_branch=root_planes[angle]
                if not same_circle_root(previous,(j,p),center,A,B,previous_branch,branch):raise ArithmeticError('different plane roots collapsed to one floating angle')
            root_planes[angle]=((j,p),branch);cuts.add(angle)
    cuts=sorted(cuts)
    if len(cuts)-1>15:raise ValueError('patch interval bound')
    values=[];scales=[];active=0;shared=0
    for lo,hi in zip(cuts[:-1],cuts[1:]):
        mid=(lo+hi)/2
        if not lo<mid<hi:raise ArithmeticError('collapsed root interval midpoint')
        point=center+A*math.cos(mid)+B*math.sin(mid)
        # A near noncoplanar classification is evidence of unresolved floating
        # geometry, not permission to enlarge a cell or merge nearby roots.
        for event in events:
            j=event['axis'];p=event['plane']
            if event['classification']=='coplanar':continue
            if A[j]==0 and B[j]==0:continue
            scale=abs(center[j])+abs(A[j])+abs(B[j])+abs(p)
            if abs(point[j]-p)<=8*EPS*scale:raise ArithmeticError('ambiguous noncoplanar interval membership')
        owners=[s for s in (0,1) if np.all(point>=bounds[s,0]) and np.all(point<=bounds[s,1])]
        if not owners:continue
        if len(owners)==2:
            if not (A[n]==B[n]==0 and center[n]==bounds[0,1,n]):raise ArithmeticError('nonunique interval ownership')
            shared+=1
        side=owners[0];active+=1;h=bounds[side,1]-bounds[side,0];b=3-n-t
        sn=polynomial((center[n]-bounds[side,0,n])/h[n],A[n]/h[n],B[n]/h[n]);sb=polynomial((center[b]-bounds[side,0,b])/h[b],A[b]/h[b],B[b]/h[b])
        lam=sn if side==0 else add_one_minus(sn);bubble=multiply(sb,add_one_minus(sb));bubble=({k:4*v for k,v in bubble[0].items()},{k:4*v for k,v in bubble[1].items()})
        derivative=polynomial(0.,B[t],-A[t]);v,s=integrate(multiply(multiply(lam,bubble),derivative),lo,hi);values.append(v);scales.append(s)
    return math.fsum(values),math.fsum(scales),{'intervals':len(cuts)-1,'active_intervals':active,'shared_face_intervals':shared,'planes':events,'zero_reason':'no active support interval' if not active else 'analytic sum' if math.fsum(values)==0 else None}
