# Saved evidence

Source8 F8/F4 pair6.758928552783555e-10 passes unchanged0.001 consistency screen. All113088 probes resolved. Original24-cell-disjoint selected fraction0.28300503696486534 fails unchanged0.50. Source8 b8 must replace b4 in any new discretization. No enriched candidate/solve exists.

Candidate receiver errors5.7027777284%/2.8609120129% fail1%; info3 preserved. Old full preconditioner68.172s and complete GMRES84.281s/3.4206GB leave little room for fresh global refinement/factorization. These are saved parent evidence, not reruns.

Question for the single spatial reduction: how many high-score directions share cells, and which axes/layers/aspects carry their scores? No reference or receiver data enters reduction or candidate selection.
