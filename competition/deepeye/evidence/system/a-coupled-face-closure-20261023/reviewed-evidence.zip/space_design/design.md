# Coupled conforming face-patch space — recommendation for root selection

Recommend **one new support-closed, coupled face-bubble construction**, followed by coupling/receiver-column assembly only. Keep the original mesh and coarse space. Root must select the implementation; no new PDE solve or global factorization is selected here.

Work A-G03-NEXT-SPACE-DESIGN-20261023-v1; agent /root/b_op23_independent_20261022; new native job child-000d57ef05084bfd9f9c28daac1f74ef validated execution_allowed=true. Only this directory was written. Source8 manifest SHA2561675faac6617b77609ecf9b524c0c3768325a869543227124a16436d77f1059a was checked. Active generation2 director and pinned H01-H15 canonical hash c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 were verified. Previous op23 work stays closed.

## Why this step

Source8 passed F8/F4 consistency6.758928552783555e-10 versus0.001, with consistent b8. Original24-cell-disjoint coverage0.28300503696486534 still fails unchanged0.50. There is no enriched candidate. Prior receiver errors5.7027777284%/2.8609120129% still fail1%; original GMRESinfo3 remains failed.

One frozen saved-array reduction completed once: exit0, 1.281s, 46,809,088B peak job memory; all3held handles signaled. Exact unchanged win_job.py and strict evidence_json wrote/read back equal result file/stdout. It used standard library only, not NumPy/SciPy; no score, primary, field, operator, source, Green/reference or solver evaluation occurred. No old tests reran. Raw outputs, command/limits/terminal and unchanged input readback are under diagnostic-01/ and diagnostic-readback.json.

The unrestricted top24 carry39.6381% of saved score, still below50%; simply removing disjointness from24 is insufficient. The frozen top128 topology summary carries72.3048%, with134support cells,122reused cell incidences and up to5directions per cell. Thus preserving neighboring directions and their mutual coupling is warranted. z-normal directions carry77.0708%; only23.0586% of score touches a source cell. Peaks occur around transverse grading transitions such as cell(20,16,17), widths50mm/6.25mm/18.75mm. This is not evidence that z-only refinement or source-only enrichment will suffice. The raw >8aspect bin includes values8.000000000000002: treat it as literal floating-bin output, not proof that those cells exceed aspect8. No rerun/rebin was performed.

Compared alternatives:

| Option | Assessment |
|---|---|
| Coupled support closure | Recommended: local work, retained geometry/source, explicitly handles the observed overlap and both tangent directions. |
| Global anisotropic h refinement | Original z-bisection proposal grows interior edges24%; old LU68.172s/fullGMRES84.281s and failed refinedL6 leave fill/time unresolved. z-normal score is not an axis-of-error proof; transverse grading is also implicated. |
| Broad all-face p enrichment | Adds113088functions before a small coupled construction is qualified; creates a much larger global algebra/solver obligation. |

The fixed128seed count was among the prediagnostic topology summaries; it is not the rank42 reaching50%, and no count was searched until a gate passed. More importantly the proposed construction changes the mathematical space to a closed coupled patch space with exact offdiagonals, rather than enlarging the old diagonal/disjoint shortlist. The original gate remains failed. Summed overlapping scores are a priority description, not captured independent energy or a physical error bound.

## Exact space and deterministic construction

From pinned source8 score8/resolved8 and original keys/cells, sort resolved directions by(-saved_score,canonical_key), take first128, and form C as the union of their two support cells. Add every original interior face whose two cells are in C, **both tangential modes**, regardless of its individual score. Emit in original canonical key order. Stop without truncation/backfill if inputs/pins fail, C exceeds134cells, or closure exceeds804directions. Root must first disposition source8 evidence; this proposal is conditional on that review.

For each chosen face F normal n, tangent t, remaining axis b, retain the accepted basis

```
q_F,t = e_t lambda_n B(s_b), B(s)=4s(1-s), q=0 outside its two cells.
lambda=s_n on minus cell; lambda=1-s_n on plus cell.
```

This matches tangential traces across F and vanishes tangentially at the patch boundary and on every coarse edge; no hanging-face or external-boundary unknown is added. Use pinned nominal bounds and exact original edge IDs/orientations, including the existing nominal/actual endpoint convention. Do not merge close coordinates. Every face trace owns its two independent tangent components, so the added functions are linearly independent of the edge space and each other. Marked-cell closure can connect the14seed components; their largest25-cell seed component is **not** a bound on final D blocks.

## Full coupling, source and boundary consistency

Preserve the accepted ordinary-transpose form

```
a(u,v)=sum integral(mu^-1 curl(u).curl(v)+i omega zeta0 u.v).
U_jq=a(N_j,q); D_pq=KQ_pq/mu+i omega zeta0 MQ_pq.
```

Compute all overlapping-cell pairs, including distinct faces/tangents. D is not diagonal; zero it only for disjoint volume support or exact polynomial cancellation. In normalized coordinates, for monomial coefficients c_alpha,d_beta,

```
integral = cell_volume sum_alpha,beta c_alpha d_beta
           product_j 1/(alpha_j+beta_j+1).
```

Apply1/h_j in physical curl derivatives before integration. Assemble MQ,KQ,U with canonical local-to-global scatter and keep absolute product sums. Diagonals must reproduce accepted analytic Mqq/Kqq identities without rerunning old controls. A new shared-cell offdiagonal fixture is the independent control.

Index F8_Q directly from saved F8; b8 must accompany it. Both originate from the same saved Gauss8 current and exactly one -i omega factor. Do not regenerate primary samples or substitute b4. Retain boundary U rows:

```
[A_II U_I; U_I^T D] [e_I;alpha]
    = [b8_I-A_IB gB; F8_Q-U_B^T gB].
```

For a later separate correction at saved Eh, ell8_Q already includes the full boundary contribution. If the old saved r4=(A Eh-b4)_I is pinned, update r8=r4-(b8-b4)_I without replaying an operator. Then

```
S=A_II-U_I D^-1 U_I^T
S delta=-r8+U_I D^-1 ell8_Q; delta_B=0
alpha=D^-1(ell8_Q-U_I^T delta).
```

These are future solve formulas, not executed operations. Do not invert D elementwise or omit offdiagonals. Optional positive-energy diagonal normalization s_q=1/sqrt(Kqq/mu+abs(i omega zeta0)Mqq) must consistently map U→US,D→SDS,F→SF,t→tS,alpha=S beta. It is no convergence/conditioning certificate.

## Measurement consistency

Use V=t_coarse e+t_Q alpha on the identical original tilted circles; reuse existing coarse trace and compute only the new bubble columns. Partition each circle at the patch's7distinct axis planes, including the shared face: at most14roots/15intervals per circle. On an active interval q dot rprime is a trigonometric polynomial of degree<=4, so integrate analytic sine/cosine primitives. Tangencies and identically coplanar planes need explicit deterministic handling; preserve signed orientation. No receiver/reference value selects support or changes a coefficient. Omitting t_Q would produce an inconsistent observable. Original high H and both1%receiver gates remain unchanged for a later selected solve.

## Bounded next implementation

Propose A-G03-COUPLED-FACE-CLOSURE-20261023-v1 in a new root-owned assignment: freeze source8 arrays/pins, local basis, current coarse assembler/trace and independent expectations; run only the3new controls below, then one assembly of canonical seed/cell/closure IDs,U,MQ,KQ,D,F8_Q,ell8_Q,new t_Q and arithmetic scales. No global mesh/operator action, new physical target, factorization, PDE solve, old tests or receiver-reference evaluation.

1. One tiny unequal-cell Fraction-monomial fixture: cross-face/cross-tangent shared-cell pairings, exact disjoint zero, symmetry and zero boundary/edge traces. A deliberately diagonal-D implementation must fail.
2. One tiny2coarse/2bubble manufactured ordinary-transpose block with nonzero gB and offdiagonal D, verifying augmented/condensed identity and one shared-current source convention. Missing-boundary and wrong-source-factor negatives must fail.
3. One partial-circle polynomial fixture for the new trace primitives and orientation/sign negative.

Resource proof uses C=134: at most3C=402interior faces and6C=804modes. At most12bubble functions touch a cell, hence <=134*144=19,296ordered local bubble/bubble and the same number of coarse/bubble pair contributions. U has <=20*804=16,080entries. Int32/complex128 CSC U<=324,820B; CSR D<=389,140B; separate real KQ/MQ CSR<=469,544B. A hypothetical extra41-vector Krylov storage is527,424B; it is not allocated in this task. New receiver columns<=1,608complex entries, <=24,120segment evaluations. These are conservative bounds; actual closure counts are not computed here. Dense D would be10,342,656B but is unnecessary, and no factorization is selected.

Proposed next one-attempt guard:30s,512MiB/process,1GiB/job,3held processes,BLAS1,64MiBtree/1024entries,128KiB per stdout/stderr,512MiBfree reserve. Working-array allowance128MiB plus runtime overhead fits the process ceiling; time is unmeasured, not promised. Any failure stops without retry/capraise. Keep unchanged held Win32 guard and strict reporter; save raw arrays before reports and confirm all held handles terminated. No coarse LU object was persisted, so a later solver cannot claim free factor reuse; the expensive global solver choice remains a separate root decision.

Even success would define an intermediate derivative discretization, not1%accuracy, boundary-error isolation, finite-strength/noise/OOD qualification,20Hz performance, training or runtime acceptance. Full G03/R03/all29 remain not_run; original arbitrary3D materials, all taskbook groups, hidden truth/causal sensing, substantive PC AI and both H12 paths remain mandatory. H01-H15 are unchanged. No UI/board/service/Git/peer operation or product write occurred.
