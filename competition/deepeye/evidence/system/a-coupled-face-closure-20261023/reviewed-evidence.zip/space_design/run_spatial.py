"""One frozen standard-library saved-array reduction, unchanged held guard."""
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
sys.path.insert(0,str(ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools'))
from evidence_json import write_new_report as save,dumps_report
spec=json.loads((D/'diagnostic-freeze.json').read_bytes())
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
before={n:pin(ROOT/n) for n in spec['files']};assert before==spec['files']
sys.path.insert(0,str(D.parent/'r02-amd-wheel-acquisition-20261021'))
from win_job import run_bounded,process_identity
stage=D/'diagnostic-01';granted=False
env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),'PATH':'','TEMP':str(stage),'TMP':str(stage),'TMPDIR':str(stage),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',**{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS')}}
def tick(job,pids):
 global granted
 if (stage/'hello.json').exists() and not granted:
  h=json.loads((stage/'hello.json').read_bytes());assert h['pid'] in pids
  save(stage/'grant.pending.json',{'worker':process_identity(h['pid'],job)});os.replace(stage/'grant.pending.json',stage/'grant.json');granted=True
result=run_bounded([str(ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'),'-I','-B','-P','-X','utf8',str(D/'spatial_worker.py'),str(stage)],env,D,stage,spec['budget'],[D],on_tick=tick)
after={n:pin(ROOT/n) for n in spec['files']}
save(D/'diagnostic-readback.json',{'unchanged':before==after,'all_processes_terminated':result['all_processes_terminated'],'files':after})
assert before==after and result['all_processes_terminated']
if result['exit_code']==0:
 assert json.loads((stage/'result.json').read_bytes())==json.loads((stage/'stdout.txt').read_bytes())
print(dumps_report({k:result.get(k) for k in ('status','exit_code','seconds','stop_reason','peak_job_memory_bytes','all_processes_terminated','held_members')}),end='',flush=True)
raise SystemExit(result['exit_code'] if result['exit_code'] is not None else 125)
