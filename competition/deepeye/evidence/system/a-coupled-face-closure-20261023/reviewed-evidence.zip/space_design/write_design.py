"""Static design/report sealing, no array decoding or numerical execution."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent
def read(p):return json.loads(p.read_bytes())
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
freeze=read(D/'diagnostic-freeze.json');result=read(D/'diagnostic-01/result.json');terminal=read(D/'diagnostic-01/terminal.json')
assert terminal['exit_code']==0 and terminal['status']=='success' and terminal['all_processes_terminated'] and len(terminal['held_members'])==3 and all(x['signaled'] for x in terminal['held_members'])
assert read(D/'diagnostic-readback.json')['unchanged'] and read(D/'diagnostic-01/stdout.txt')==result
assert result['score_recomputed'] is False and result['scientific_imports']==0 and result['PDE_solves']==0
M=result['top128_support']['distinct_cells'];m=6*M;pair_work=144*M;u_entries=20*m
resources={'seed_directions':128,'marked_cells':M,'closure_face_upper_bound':3*M,'closure_direction_upper_bound':m,'local_ordered_bubble_pair_terms_upper_bound':pair_work,'local_coarse_bubble_pair_terms_upper_bound':pair_work,'coarse_bubble_U_entries_upper_bound':u_entries,'U_CSC_int32_complex128_bytes_upper_bound':20*u_entries+4*(m+1),'D_CSR_int32_complex128_bytes_upper_bound':20*pair_work+4*(m+1),'two_real_K_M_CSR_bytes_upper_bound':2*(12*pair_work+4*(m+1)),'extra_41vector_complex_Krylov_bytes_upper_bound':41*16*m,'two_receiver_trace_complex_entries_upper_bound':2*m,'circle_segment_evaluations_upper_bound':2*m*15,'full_CSR_unchanged':{'edges':63250,'interior':54418,'nnz':1969810}}
design={
 'work_id':'A-G03-NEXT-SPACE-DESIGN-20261023-v1','job_id':'child-000d57ef05084bfd9f9c28daac1f74ef','agent_id':'/root/b_op23_independent_20261022','execution_allowed_validated':True,
 'status':'design_recommendation_for_root_selection','recommendation':'fixed-top128 residual-support closure with fully coupled conforming face bubbles; assemble new U/KQ/MQ/trace columns, no global solve',
 'source8_manifest_sha256':'1675faac6617b77609ecf9b524c0c3768325a869543227124a16436d77f1059a',
 'spatial_evidence':{'old_disjoint24_fraction':.28300503696486534,'old_gate':.5,'old_status':'bounded_enrichment_not_supported','new_saved_array_reduction':{'exit':0,'attempts':1,'elapsed_seconds':terminal['seconds'],'peak_job_memory_bytes':terminal['peak_job_memory_bytes'],'held_processes':3,'all_held_terminated':True,'unrestricted24_fraction':result['unrestricted_rank_score_fractions']['24'],'unrestricted128_fraction':result['unrestricted_rank_score_fractions']['128'],'z_normal_score_fraction':sum(r['fraction'] for r in result['axis_pair_shares'] if r['normal']==2),'top128_distinct_cells':M,'top128_reused_cell_incidences':result['top128_support']['reused_cell_incidences'],'source_incident_fraction':result['source_cell_incident_score_fraction']},'warning':'saved residual priority is not response error or certified error estimator; rank50 is descriptive and not a selection threshold; literal aspect>8 bin includes floating representations of8'},
 'alternatives':[
  {'name':'coupled support-closed face space','recommend':True,'reason':'saved high-score supports overlap heavily; add the missing neighbor/multidirectional couplings while retaining geometry, b8 and existing coarse space; bound added work locally'},
  {'name':'global anisotropic h refinement','recommend':False,'reason':'z-normal share is high but largest cells are long transverse grading transitions; z-only attribution unsupported; new global preconditioner fill/time is unbounded by current evidence'},
  {'name':'all-face higher-order space','recommend':False,'reason':'adds113088 directions and admits broad couplings before establishing a small coupled-patch construction; not the minimal next increment'}],
 'selection':{'input':'pinned source8 score8/resolved8 and original keys/cells only','seed':'first128 resolved indices sorted by (-saved_score,canonical_key); fixed before reduction as a topology summary count; never rank-to50','marked_cells':'union of both cells incident on seed directions','closure':'all original interior faces with both cells in marked_cells; include both tangential directions regardless of score; canonical order','preflight_stops':'more than134 marked cells or804 closure directions, nonfinite/pin/topology mismatch, source8 not accepted by root; no truncation/backfill/retry','old_gate':'original24/disjoint/0.50 rule is unchanged and remains failed; no new pass is assigned by summed overlapping scores'},
 'basis':'q=e_t lambda_n B(s_b), B=4s_b(1-s_b); lambda=s_n on minus cell,1-s_n on plus cell; zero outside the two-cell support; same orientation and geometry as accepted face code',
 'operator':{'a':'integral(mu^-1 curl(u).curl(v)+i*omega*zeta0*u.v), ordinary transpose, no conjugation','local_integral':'For normalized-coordinate monomial coefficients c_alpha,d_beta: integral=cell_volume*sum(c_alpha*d_beta*product_j 1/(alpha_j+beta_j+1)); physical derivatives include1/h_j','U':'U_jq=a(N_j,q), retain all global edge rows including boundary','D':'D_pq=KQ_pq/mu+i*omega*zeta0*MQ_pq, all overlapping-cell pairings; zero only for disjoint volume supports or exact analytic cancellation','normalization':'optional S_qq=1/sqrt(KQ_qq/mu+abs(i*omega*zeta0)*MQ_qq); use Uhat=US,Dhat=SDS,Fhat=SF,tracehat=traceS,alpha=S*beta consistently; not a conditioning certificate'},
 'source_boundary':{'source':'F8_Q directly indexed from accepted source8 array; consistent coarse load b8 from the same current and exactly one -i*omega factor; no primary/current recomputation','fixed_rhs':'[b8_I-A_IB*gB; F8_Q-U_B^T*gB]','candidate_correction':'r8=(A*Eh-b4)_I-(b8-b4)_I if original residual is pinned; ell8_Q already includes full U^T*Eh. With S=A_II-U_I*D^-1*U_I^T, S*delta=-r8+U_I*D^-1*ell8_Q; alpha=D^-1*(ell8_Q-U_I^T*delta); delta_B=0','no_solve_selected':True},
 'measurement':{'formula':'V=t_coarse*e+t_Q*alpha; exact original tilted receiver circles','new_work':'only bubble trace columns; split at the patch seven distinct axis planes and internal face, <=14 roots/15 segments per circle; q dot rprime has trig degree<=4 on a segment, integrate analytic primitives','forbidden':'receiver/reference values never select modes or tune amplitude; no omitted bubble trace'},
 'resources':resources,'proposed_next_guard':freeze['budget'],
 'minimal_new_controls':['one Fraction-monomial anisotropic shared-cell fixture covering cross-face/cross-tangent overlap, exact disjoint zero, symmetry and zero boundary/coarse-edge traces; diagonal-D mutant must fail','one tiny two-coarse/two-bubble manufactured ordinary-transpose block including offdiagonalD and nonzero fixedgB/shared current; augmented-condensed identity, missing-boundary/wrong-source-factor negatives','one partial-circle polynomial fixture for new bubble trace primitives with sign/orientation negative'],
 'next_task':'A-G03-COUPLED-FACE-CLOSURE-20261023-v1: root-selected new owned folder, freeze inputs/independent expectations; run only new controls and one bounded coupling/trace assembly. Emit canonical seed/cell/closure keys, U/MQ/KQ/D,F8_Q,ell8_Q,traceQ,scales and source/load pins. No global factorization, mesh rebuild, field/source replay, PDE solve, receiver reference evaluation or old controls. Root independently reviews before selecting any new solve.',
 'limitations':['No actual closure count, coupled-block conditioning or response improvement has been measured;804 is a proved combinatorial upper bound, not an emitted candidate','Seed graph14components with maximum25cells is descriptive; adding closure faces can merge components, so it is not a factor-block bound','The saved ell8 is evaluated at the old unqualified Eh; b8 source consistency does not repair finite-element approximation error or prove radiation-boundary accuracy','A later global solve remains a separate selection; no LU object was persisted, so claiming free reuse of old factorization would be false; old68.172s/84.281s/3.4206GB remain historical risk evidence'],
 'requirements_sha256':freeze['requirements_sha256'],'H01_H15':'preserved','physical_accuracy':'unqualified','G03':'not_run','R03':'not_run','all29':'not_run','20Hz_noise_OOD_finite_strength':'not_run','root_selection_and_acceptance':True,'previous_jobs_reopened':False}
(D/'design.json').write_text(json.dumps(design,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
md=f'''# Coupled conforming face-patch space — recommendation for root selection

Recommend **one new support-closed, coupled face-bubble construction**, followed by coupling/receiver-column assembly only. Keep the original mesh and coarse space. Root must select the implementation; no new PDE solve or global factorization is selected here.

Work A-G03-NEXT-SPACE-DESIGN-20261023-v1; agent /root/b_op23_independent_20261022; new native job child-000d57ef05084bfd9f9c28daac1f74ef validated execution_allowed=true. Only this directory was written. Source8 manifest SHA2561675faac6617b77609ecf9b524c0c3768325a869543227124a16436d77f1059a was checked. Active generation2 director and pinned H01-H15 canonical hash {freeze['requirements_sha256']} were verified. Previous op23 work stays closed.

## Why this step

Source8 passed F8/F4 consistency6.758928552783555e-10 versus0.001, with consistent b8. Original24-cell-disjoint coverage0.28300503696486534 still fails unchanged0.50. There is no enriched candidate. Prior receiver errors5.7027777284%/2.8609120129% still fail1%; original GMRESinfo3 remains failed.

One frozen saved-array reduction completed once: exit0, {terminal['seconds']:.3f}s, {terminal['peak_job_memory_bytes']:,}B peak job memory; all3held handles signaled. Exact unchanged win_job.py and strict evidence_json wrote/read back equal result file/stdout. It used standard library only, not NumPy/SciPy; no score, primary, field, operator, source, Green/reference or solver evaluation occurred. No old tests reran. Raw outputs, command/limits/terminal and unchanged input readback are under diagnostic-01/ and diagnostic-readback.json.

The unrestricted top24 carry39.6381% of saved score, still below50%; simply removing disjointness from24 is insufficient. The frozen top128 topology summary carries72.3048%, with134support cells,122reused cell incidences and up to5directions per cell. Thus preserving neighboring directions and their mutual coupling is warranted. z-normal directions carry77.0708%; only23.0586% of score touches a source cell. Peaks occur around transverse grading transitions such as cell(20,16,17), widths50mm/6.25mm/18.75mm. This is not evidence that z-only refinement or source-only enrichment will suffice. The raw >8aspect bin includes values8.000000000000002: treat it as literal floating-bin output, not proof that those cells exceed aspect8. No rerun/rebin was performed.

Compared alternatives:

| Option | Assessment |
|---|---|
| Coupled support closure | Recommended: local work, retained geometry/source, explicitly handles the observed overlap and both tangent directions. |
| Global anisotropic h refinement | Original z-bisection proposal grows interior edges24%; old LU68.172s/fullGMRES84.281s and failed refinedL6 leave fill/time unresolved. z-normal score is not an axis-of-error proof; transverse grading is also implicated. |
| Broad all-face p enrichment | Adds113088functions before a small coupled construction is qualified; creates a much larger global algebra/solver obligation. |

The fixed128seed count was among the prediagnostic topology summaries; it is not the rank42 reaching50%, and no count was searched until a gate passed. More importantly the proposed construction changes the mathematical space to a closed coupled patch space with exact offdiagonals, rather than enlarging the old diagonal/disjoint shortlist. The original gate remains failed. Summed overlapping scores are a priority description, not captured independent energy or a physical error bound.

## Exact space and deterministic construction

From pinned source8 score8/resolved8 and original keys/cells, sort resolved directions by(-saved_score,canonical_key), take first128, and form C as the union of their two support cells. Add every original interior face whose two cells are in C, **both tangential modes**, regardless of its individual score. Emit in original canonical key order. Stop without truncation/backfill if inputs/pins fail, C exceeds134cells, or closure exceeds804directions. Root must first disposition source8 evidence; this proposal is conditional on that review.

For each chosen face F normal n, tangent t, remaining axis b, retain the accepted basis

```
q_F,t = e_t lambda_n B(s_b), B(s)=4s(1-s), q=0 outside its two cells.
lambda=s_n on minus cell; lambda=1-s_n on plus cell.
```

This matches tangential traces across F and vanishes tangentially at the patch boundary and on every coarse edge; no hanging-face or external-boundary unknown is added. Use pinned nominal bounds and exact original edge IDs/orientations, including the existing nominal/actual endpoint convention. Do not merge close coordinates. Every face trace owns its two independent tangent components, so the added functions are linearly independent of the edge space and each other. Marked-cell closure can connect the14seed components; their largest25-cell seed component is **not** a bound on final D blocks.

## Full coupling, source and boundary consistency

Preserve the accepted ordinary-transpose form

```
a(u,v)=sum integral(mu^-1 curl(u).curl(v)+i omega zeta0 u.v).
U_jq=a(N_j,q); D_pq=KQ_pq/mu+i omega zeta0 MQ_pq.
```

Compute all overlapping-cell pairs, including distinct faces/tangents. D is not diagonal; zero it only for disjoint volume support or exact polynomial cancellation. In normalized coordinates, for monomial coefficients c_alpha,d_beta,

```
integral = cell_volume sum_alpha,beta c_alpha d_beta
           product_j 1/(alpha_j+beta_j+1).
```

Apply1/h_j in physical curl derivatives before integration. Assemble MQ,KQ,U with canonical local-to-global scatter and keep absolute product sums. Diagonals must reproduce accepted analytic Mqq/Kqq identities without rerunning old controls. A new shared-cell offdiagonal fixture is the independent control.

Index F8_Q directly from saved F8; b8 must accompany it. Both originate from the same saved Gauss8 current and exactly one -i omega factor. Do not regenerate primary samples or substitute b4. Retain boundary U rows:

```
[A_II U_I; U_I^T D] [e_I;alpha]
    = [b8_I-A_IB gB; F8_Q-U_B^T gB].
```

For a later separate correction at saved Eh, ell8_Q already includes the full boundary contribution. If the old saved r4=(A Eh-b4)_I is pinned, update r8=r4-(b8-b4)_I without replaying an operator. Then

```
S=A_II-U_I D^-1 U_I^T
S delta=-r8+U_I D^-1 ell8_Q; delta_B=0
alpha=D^-1(ell8_Q-U_I^T delta).
```

These are future solve formulas, not executed operations. Do not invert D elementwise or omit offdiagonals. Optional positive-energy diagonal normalization s_q=1/sqrt(Kqq/mu+abs(i omega zeta0)Mqq) must consistently map U→US,D→SDS,F→SF,t→tS,alpha=S beta. It is no convergence/conditioning certificate.

## Measurement consistency

Use V=t_coarse e+t_Q alpha on the identical original tilted circles; reuse existing coarse trace and compute only the new bubble columns. Partition each circle at the patch's7distinct axis planes, including the shared face: at most14roots/15intervals per circle. On an active interval q dot rprime is a trigonometric polynomial of degree<=4, so integrate analytic sine/cosine primitives. Tangencies and identically coplanar planes need explicit deterministic handling; preserve signed orientation. No receiver/reference value selects support or changes a coefficient. Omitting t_Q would produce an inconsistent observable. Original high H and both1%receiver gates remain unchanged for a later selected solve.

## Bounded next implementation

Propose A-G03-COUPLED-FACE-CLOSURE-20261023-v1 in a new root-owned assignment: freeze source8 arrays/pins, local basis, current coarse assembler/trace and independent expectations; run only the3new controls below, then one assembly of canonical seed/cell/closure IDs,U,MQ,KQ,D,F8_Q,ell8_Q,new t_Q and arithmetic scales. No global mesh/operator action, new physical target, factorization, PDE solve, old tests or receiver-reference evaluation.

1. One tiny unequal-cell Fraction-monomial fixture: cross-face/cross-tangent shared-cell pairings, exact disjoint zero, symmetry and zero boundary/edge traces. A deliberately diagonal-D implementation must fail.
2. One tiny2coarse/2bubble manufactured ordinary-transpose block with nonzero gB and offdiagonal D, verifying augmented/condensed identity and one shared-current source convention. Missing-boundary and wrong-source-factor negatives must fail.
3. One partial-circle polynomial fixture for the new trace primitives and orientation/sign negative.

Resource proof uses C=134: at most3C=402interior faces and6C=804modes. At most12bubble functions touch a cell, hence <=134*144=19,296ordered local bubble/bubble and the same number of coarse/bubble pair contributions. U has <=20*804=16,080entries. Int32/complex128 CSC U<=324,820B; CSR D<=389,140B; separate real KQ/MQ CSR<=469,544B. A hypothetical extra41-vector Krylov storage is527,424B; it is not allocated in this task. New receiver columns<=1,608complex entries, <=24,120segment evaluations. These are conservative bounds; actual closure counts are not computed here. Dense D would be10,342,656B but is unnecessary, and no factorization is selected.

Proposed next one-attempt guard:30s,512MiB/process,1GiB/job,3held processes,BLAS1,64MiBtree/1024entries,128KiB per stdout/stderr,512MiBfree reserve. Working-array allowance128MiB plus runtime overhead fits the process ceiling; time is unmeasured, not promised. Any failure stops without retry/capraise. Keep unchanged held Win32 guard and strict reporter; save raw arrays before reports and confirm all held handles terminated. No coarse LU object was persisted, so a later solver cannot claim free factor reuse; the expensive global solver choice remains a separate root decision.

Even success would define an intermediate derivative discretization, not1%accuracy, boundary-error isolation, finite-strength/noise/OOD qualification,20Hz performance, training or runtime acceptance. Full G03/R03/all29 remain not_run; original arbitrary3D materials, all taskbook groups, hidden truth/causal sensing, substantive PC AI and both H12 paths remain mandatory. H01-H15 are unchanged. No UI/board/service/Git/peer operation or product write occurred.
'''
(D/'design.md').write_text(md,encoding='utf-8')
used=dict(freeze['files'])
for rel in ['g03-face-enrichment-20261023/face_probe_geometry.py','g03-face-enrichment-20261023/face_probe_moments.py','g03-face-enrichment-20261023/face_probe_selection.py','g03-consistent-solve-main-review-20261023/README.md']:
 p=P/rel;used[p.relative_to(ROOT).as_posix()]=pin(p)
for name in ('F8.npy','b8.npy','delta_b8_minus_b4.npy'):
 p=P/'g03-source8-enrichment-20261023/source-01'/name;used[p.relative_to(ROOT).as_posix()]=pin(p)
(D/'source-manifest.json').write_text(json.dumps({'files':used,'role_identity':{'node_id':'A','project_id':'fpga-main','method':'current node configuration allowlist read; credentials excluded'},'private_credentials_excluded':True,'array_payload_reads':'one held diagnostic only; other array pins hash bytes without decoding','requirements_sha256':freeze['requirements_sha256']},indent=2),encoding='utf-8')
(D/'next-task-proposal.md').write_text('Proposed work A-G03-COUPLED-FACE-CLOSURE-20261023-v1. Root selection required. Implement the exact support closure, full coupled moments and receiver columns specified in design.md. Run only the three new independent controls and one bounded coupling/trace assembly, with the frozen30s/512MiB/1GiB/3process/64MiB guard. No new source/primary/operator/old-test/PDE solve or global LU. Emit source-pinned arrays and truthful single-attempt terminal evidence; root reviews before a separate solver decision.\n',encoding='utf-8')
(D/'task_plan.md').write_text('# A-G03-NEXT-SPACE-DESIGN-20261023-v1\n\n- Completed: lease/scope/source8 evidence and H01-H15 verification.\n- Completed: one frozen saved-array diagnostic, exit0, all3held processes terminated; no replay.\n- Completed: three alternatives and exact coupled-support-closure proposal, formulas/controls/resource ceilings.\n- Completed: self-review of source/boundary/measurement consistency and public artifact manifest.\n- Remaining: root selection/acceptance, outside this worker scope.\n',encoding='utf-8')
(D/'progress.md').write_text('Design delivered for root selection. One diagnostic completed once with unchanged pins and matching strict JSON file/stdout. H01-H15/G03/R03/all29 unchanged/not_run. No implementation or solve selected.\n',encoding='utf-8')
files={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ('lease.private.json','manifest.json','native-completion.json')}
manifest={'work_id':design['work_id'],'status':'design_for_root_selection','files':files,'private_credentials_excluded':True,'saved_array_diagnostic_attempts':1,'scientific_calls':0,'PDE_solves':0,'G03':'not_run','R03':'not_run'}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
assert all(pin(D/n)==v for n,v in files.items())
assert read(D/'design.json')['resources']['closure_direction_upper_bound']==804
print(json.dumps({'design_written':True,'public_files':len(files),'manifest_sha256':pin(D/'manifest.json')['sha256'],'diagnostic_attempts':1,'all_held_terminated':True,'old_tests_replayed':0,'implementation_selection':'root'}))
