"""Hash/header freeze only, no numerical payload reduction."""
import ast,hashlib,json,struct
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def header(p):
 with p.open('rb') as f:
  assert f.read(6)==b'\x93NUMPY';version=f.read(2);width=2 if version[0]==1 else 4
  size=int.from_bytes(f.read(width),'little');assert size<4096
  return ast.literal_eval(f.read(size).decode('latin1'))
old=json.loads((P/'g03-source8-enrichment-20261023/input-pins.json').read_bytes())
aliases={k:old['aliases'][k] for k in ['keys','cells','bounds','source_ids','L5_assignment']}
for name in ['ell8','score8','resolved8']:
 aliases[name]=f'.planning/deepeye-resume-20261018/g03-source8-enrichment-20261023/source-01/{name}.npy'
extra=['.planning/deepeye-resume-20261018/g03-source8-enrichment-20261023/'+s for s in ['manifest.json','report.md','result-summary.json','source8_stage.py']]
extra += ['.planning/deepeye-resume-20261018/g03-next-precision-design-20261023/design.md','.planning/deepeye-desktop-handoff-20261015/transfer.json','docs/competition/deepeye-2026/immutable_scope.md','docs/competition/deepeye-2026/immutable_scope.json']
extra += [old['aliases']['L5_assignment'],'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py','.planning/deepeye-resume-20261018/r02-amd-wheel-acquisition-20261021/win_job.py','.planning/deepeye-resume-20261018/r02-amd-wheel-acquisition-20261021/boundary.py','.local/deepeye-fdem-validation-20261020/Scripts/python.exe']
files={n:pin(ROOT/n) for n in sorted(set(aliases.values())|set(extra))}
assert files['.planning/deepeye-resume-20261018/g03-source8-enrichment-20261023/manifest.json']['sha256']=='1675faac6617b77609ecf9b524c0c3768325a869543227124a16436d77f1059a'
for n in files:
 if n in old['files']:assert files[n]==old['files'][n]
scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_bytes())
h=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
assert [r['id'] for r in scope['requirements']]==['H%02d'%i for i in range(1,16)]
for n in ('prepare.py','run_spatial.py','spatial_worker.py','assignment.md'):files[(D/n).relative_to(ROOT).as_posix()]=pin(D/n)
record={'work_id':'A-G03-NEXT-SPACE-DESIGN-20261023-v1','aliases':aliases,'files':files,'headers':{k:header(ROOT/n) for k,n in aliases.items() if n.endswith('.npy')},'requirements_sha256':h,'budget':{'seconds':30,'active_processes':3,'process_memory_bytes':512*1024**2,'job_memory_bytes':1024**3,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':64*1024**2,'tree_entries':1024,'free_reserve_bytes':512*1024**2},'single_attempt':True,'forbidden':'no recompute of score, field, primary, operator, source, Green/reference, solve or prior test','outputs':['diagnostic-01/result.json','diagnostic-01/stdout.txt','diagnostic-01/stderr.txt','diagnostic-01/terminal.json'],'statistics_frozen':['axis-pair score shares','top-count shares24/64/128/256/512','rank attaining50percent for description only','cell overlap/components of fixed top128','per-layer half-incidence score mass','aspect bins1..2/2..4/4..8/>8','top32cells and top32probes']}
with (D/'diagnostic-freeze.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2,ensure_ascii=False,allow_nan=False)
print(json.dumps({'freeze':'created','files':len(files),'npy_payloads_decoded':0,'H01_H15_verified':True}))
