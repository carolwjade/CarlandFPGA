"""Saved-score reduction only; no numerical/scientific package imports."""
import array,ast,hashlib,json,math,os,sys,time,traceback
from collections import Counter
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];stage=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools'))
from evidence_json import write_new_report as save,dumps_report
spec=json.loads((D/'diagnostic-freeze.json').read_bytes());allowed={(ROOT/p).resolve() for p in spec['aliases'].values() if p.endswith('.npy')}
save(stage/'hello.json',{'pid':os.getpid(),'before_array_read':True,'scientific_imports':0})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
 if time.monotonic()>deadline:raise RuntimeError('no held grant')
 time.sleep(.01)
assert json.loads((stage/'grant.json').read_bytes())['worker']['pid']==os.getpid()
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):raise PermissionError('no network/subprocess')
 if event=='import' and args[0].split('.')[0] in ('numpy','scipy'):raise PermissionError('no scientific imports')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).resolve();mode=args[1];flags=args[2]
  writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if writing and not p.is_relative_to(stage):raise PermissionError('stage-only writes')
  if not writing and (p.suffix=='.npz' or (p.suffix=='.npy' and p not in allowed)):raise PermissionError('unlisted numeric input')
sys.addaudithook(audit)
def load(alias):
 p=ROOT/spec['aliases'][alias];data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==spec['files'][p.relative_to(ROOT).as_posix()]['sha256']
 assert data[:6]==b'\x93NUMPY';width=2 if data[6]==1 else 4;n=int.from_bytes(data[8:8+width],'little');h=ast.literal_eval(data[8+width:8+width+n].decode('latin1'))
 assert h==spec['headers'][alias] or (h['descr']==spec['headers'][alias]['descr'] and list(h['shape'])==spec['headers'][alias]['shape'] and h['fortran_order'] is False)
 assert h['fortran_order'] is False;body=data[8+width+n:];descr=h['descr']
 if descr=='|b1':a=body
 else:
  code={'<i4':'i','<i8':'q','<f8':'d','<c16':'d'}[descr];a=array.array(code);a.frombytes(body)
  if sys.byteorder!='little':a.byteswap()
  if code=='d':assert all(math.isfinite(v) for v in a)
 factor=2 if descr=='<c16' else 1
 assert len(a)==math.prod(h['shape'])*factor
 return a,h['shape']
try:
 keys,_=load('keys');cells,_=load('cells');score,_=load('score8');resolved,_=load('resolved8');ell,_=load('ell8');bounds,_=load('bounds');source_ids,_=load('source_ids')
 N=len(score);assert N==113088 and len(cells)==2*N and len(keys)==5*N and len(bounds)==19584*6
 assert all(s>=0 for s in score) and all(v in (0,1) for v in resolved)
 order=sorted((i for i in range(N) if resolved[i]),key=lambda i:(-score[i],tuple(keys[5*i:5*i+5])))
 total=math.fsum(score[i] for i in order);assert total>0
 pair={};cell_mass=[0.0]*19584;aspect_mass=[0.0]*4;source_set=set(source_ids);source_mass=0.0
 widths=[tuple(bounds[6*c+3+j]-bounds[6*c+j] for j in range(3)) for c in range(19584)];assert all(min(h)>0 for h in widths)
 for i in order:
  s=score[i];n=keys[5*i];t=keys[5*i+4];pair[(n,t)]=pair.get((n,t),0.0)+s
  cs=cells[2*i:2*i+2];aspect=max(max(widths[c])/min(widths[c]) for c in cs);b=0 if aspect<=2 else 1 if aspect<=4 else 2 if aspect<=8 else 3;aspect_mass[b]+=s
  for c in cs:cell_mass[c]+=s/2
  if any(c in source_set for c in cs):source_mass+=s
 shares={str(k):math.fsum(score[i] for i in order[:k])/total for k in (24,64,128,256,512)}
 running=0.0;half=None
 for rank,i in enumerate(order,1):
  running+=score[i]
  if running>=.5*total:half=rank;break
 subset=order[:128];incidence=Counter(c for i in subset for c in cells[2*i:2*i+2]);parent={c:c for c in incidence}
 def find(x):
  while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
  return x
 for i in subset:
  a,b=cells[2*i:2*i+2];parent[find(a)]=find(b)
 comps=Counter(find(c) for c in incidence);layers=[[0.0]*n for n in (24,24,34)]
 for c,s in enumerate(cell_mass):
  for axis,index in enumerate((c%24,(c//24)%24,c//576)):layers[axis][index]+=s
 topcells=sorted(range(19584),key=lambda c:(-cell_mass[c],c))[:32]
 result={'status':'saved_array_spatial_reduction_complete','score_recomputed':False,'scientific_imports':0,'PDE_solves':0,'resolved_count':len(order),'recorded_total_probes':N,'total_saved_score':total,'axis_pair_shares':[{'normal':n,'tangent':t,'fraction':v/total} for (n,t),v in sorted(pair.items())],'unrestricted_rank_score_fractions':shares,'rank_reaching_half_saved_score':half,'rank_summary_is_not_candidate_selection':True,'top128_support':{'distinct_cells':len(incidence),'maximum_selected_face_directions_per_cell':max(incidence.values()),'reused_cell_incidences':256-len(incidence),'component_cell_counts':sorted(comps.values(),reverse=True)},'maximum_incident_aspect_bin_fractions':dict(zip(('<=2','(2,4]','(4,8]','>8'),[s/total for s in aspect_mass])),'source_cell_incident_score_fraction':source_mass/total,'axis_layer_half_incidence_score_fractions':[[s/total for s in row] for row in layers],'top32cells':[{'id':c,'ijk':[c%24,(c//24)%24,c//576],'half_incidence_fraction':cell_mass[c]/total,'widths_m':list(widths[c]),'aspect':max(widths[c])/min(widths[c])} for c in topcells],'top32probes':[{'index':i,'key':list(keys[5*i:5*i+5]),'cells':list(cells[2*i:2*i+2]),'score_fraction':score[i]/total} for i in order[:32]],'physical_accuracy':'unqualified','G03':'not_run','R03':'not_run'}
 save(stage/'result.json',result);print(dumps_report(result),end='',flush=True)
except BaseException as e:
 save(stage/'failure.json',{'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'no_retry':True});raise
