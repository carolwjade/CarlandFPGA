"""Single bounded new saved-data audit under unchanged held guard."""
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parents[2];S=D.parent/'g03-coupled-face-closure-20261023';stage=D/'saved-assembly-audit-01';support=D.parent/'r02-amd-wheel-acquisition-20261021';py=R/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'
sys.path.insert(0,str(R/'.local/deepeye-implementation-a/competition/deepeye/tools'));from evidence_json import write_new_report as save,dumps_report
sys.path.insert(0,str(support));from win_job import run_bounded,process_identity
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
paths=[S/'source-pins.json',S/'assembly-01/result.json',S/'assembly-01/trace-events.json',D/'postassembly-audit-plan.md',D/'assembly-audit-worker.py',D/'audit_saved_assembly.py',Path(__file__),support/'win_job.py',support/'boundary.py',R/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py',py]
before={p.relative_to(R).as_posix():pin(p) for p in paths};assert pin(support/'win_job.py')['sha256']=='c997e69b7439776fdaf63cd3dc8235e3448ef26556e69a980b2d9e9315610f59'
save(D/'saved-audit-before.json',{'scope':'one predeclared saved-artifact audit, at most12QQ/6U Fraction pair samples; no fullassembly or oldscience/test replay','before':before,'root_selection':pin(D.parent/'g03-coupled-face-main-review-20261023/assembly-selection.json')})
env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),'PATH':'','TEMP':str(stage),'TMP':str(stage),'TMPDIR':str(stage),'MPLCONFIGDIR':str(stage/'mplconfig'),'MPLBACKEND':'Agg','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf8',**{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS')}}
budget={'seconds':30,'active_processes':3,'process_memory_bytes':512*1024**2,'job_memory_bytes':1024**3,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':64*1024**2,'tree_entries':1024,'free_reserve_bytes':512*1024**2};granted=False
def tick(job,pids):
 global granted
 if (stage/'hello.json').exists() and not granted:
  hello=read(stage/'hello.json');assert hello['pid'] in pids;save(stage/'grant.pending.json',{'worker':process_identity(hello['pid'],job),'mode':'saved_assembly_audit'});os.replace(stage/'grant.pending.json',stage/'grant.json');granted=True
result=run_bounded([str(py),'-I','-B','-X','utf8',str(D/'assembly-audit-worker.py'),str(stage)],env,D,stage,budget,[D],on_tick=tick)
after={p.relative_to(R).as_posix():pin(p) for p in paths};save(D/'saved-audit-readback.json',{'unchanged':before==after,'before':before,'after':after});assert before==after and result['all_processes_terminated'];print(dumps_report({k:result.get(k) for k in ('status','exit_code','seconds','stop_reason','peak_job_memory_bytes','all_processes_terminated','held_members')}),end='');raise SystemExit(result['exit_code'] if result['exit_code'] is not None else 125)
