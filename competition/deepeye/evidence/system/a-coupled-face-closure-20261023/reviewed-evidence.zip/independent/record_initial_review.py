"""Metadata-only initial record; no scientific stages or numerical libraries."""
import hashlib,importlib.util,json
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parents[2];P=D.parent
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
h=R/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py';assert pin(h)['sha256']=='a0aabdbf259f7232bf3e1e77a81d130a8f676ad0b87eba39fae99d118f858554'
sp=importlib.util.spec_from_file_location('reporter',h);reporter=importlib.util.module_from_spec(sp);sp.loader.exec_module(reporter)
scope=read(R/'docs/competition/deepeye-2026/immutable_scope.json');digest=hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest();assert digest=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=read(R/'.planning/deepeye-desktop-handoff-20261015/transfer.json');assert transfer['status']=='active' and transfer['director_generation']==2 and transfer['new_director_thread_id']=='01a13d7e-dcf1-7272-a738-a637dd62ff9d'
design=P/'g03-next-space-design-20261023';assert pin(design/'manifest.json')['sha256']=='d1607e6dde579490a0d5a950334489fb36c8f107a56538acb19e0bf119fbf8e9'
selection=read(P/'g03-coupled-face-main-review-20261023/implementation-selection.json');assert selection['design_file']==pin(design/'design.md') and selection['full_assembly_selected'] is False
paths=[D/'assignment.md',D/'design-review-notes.md',design/'manifest.json',design/'design.md',design/'design.json',P/'g03-coupled-face-main-review-20261023/implementation-selection.json',R/'docs/competition/deepeye-2026/immutable_scope.md',R/'docs/competition/deepeye-2026/immutable_scope.json',R/'.planning/deepeye-desktop-handoff-20261015/transfer.json',h]
reporter.write_new_report(D/'initial-design-review.json',{'work_id':'A-G03-COUPLED-FACE-REVIEW-20261023-v1','status':'provisional_static_design_review','execution_allowed_verified':True,'canonical_agent':'/root/g03_hodge_independent_20261023','blocking_design_findings':[],'author_sources_frozen':False,'actual_assembly_selected':False,'scientific_stages_executed':0,'old_tests_replayed':0,'H01_H15_preserved':True,'requirements_sha256':digest,'pins':{p.relative_to(R).as_posix():pin(p) for p in paths},'root_retains':'actual assembly selection and acceptance','next':'review developing code and independent new controls; final frozen preexecution review'})
print(reporter.dumps_report({'status':'initial_design_review_recorded','blocking_findings':0,'canonical_requirements_sha256':digest}),end='')
