"""Only new branch/collapsed-root behavior; no old tests or science arrays."""
import ctypes as ct,hashlib,importlib.util,json,math,os,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parents[2];stage=Path(sys.argv[1]).resolve();source=Path(sys.argv[2]).resolve()
sys.path.insert(0,str(R/'.local/deepeye-implementation-a/competition/deepeye/tools'));from evidence_json import write_new_report as save,dumps_report
save(stage/'hello.json',{'pid':os.getpid(),'mode':'new_collision_probe','before_scientific_import':True});deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
 if time.monotonic()>deadline:raise RuntimeError('no held grant')
 time.sleep(.01)
grant=json.loads((stage/'grant.json').read_text(encoding='utf8'));assert grant['worker']['pid']==os.getpid()
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):raise PermissionError('no network/subprocess')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).resolve();mode=args[1];flags=args[2]
  writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if writing and not p.is_relative_to(stage):raise PermissionError('stage-only writes')
  if not writing and p.suffix in ('.npy','.npz'):raise PermissionError('science arrays prohibited')
sys.addaudithook(audit)
def threads():
 import numpy as np,scipy.linalg,scipy
 kernel=ct.WinDLL('kernel32',use_last_error=True);kernel.GetModuleHandleW.argtypes=[ct.c_wchar_p];kernel.GetModuleHandleW.restype=ct.c_void_p;rows=[]
 for folder,symbol in [('numpy.libs','scipy_openblas_get_num_threads64_'),('scipy.libs','scipy_openblas_get_num_threads')]:
  paths=list((Path(np.__file__).resolve().parents[1]/folder).glob('*openblas*.dll'));assert len(paths)==1;handle=kernel.GetModuleHandleW(str(paths[0]));assert handle
  getter=getattr(ct.CDLL(str(paths[0]),handle=handle),symbol);getter.argtypes=[];getter.restype=ct.c_int;count=getter();assert count==1
  rows.append({'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),'threads':count})
 return {'numpy':np.__version__,'scipy':scipy.__version__,'BLAS':rows}
before=None;t0=time.monotonic()
try:
 before=threads();spec=importlib.util.spec_from_file_location('reviewed_bubble_trace',source);bt=importlib.util.module_from_spec(spec);spec.loader.exec_module(bt)
 cases=[]
 try:bt.plane_roots(0.,2.**-80,1.,1.)
 except ArithmeticError as error:
  assert str(error)=='distinct crossings collapsed to one floating root';cases.append({'name':'positive_discriminant_collapsed_float_roots','expected':'ArithmeticError','actual':str(error),'pass':True})
 else:raise AssertionError('collapsed crossing was not rejected')
 e=2.**-52;center=[0.,0.,0.];aa=[1.+e,1.,0.];bb=[1.,1.-e,0.];first=(0,aa[0]);second=(1,aa[1])
 assert bt.same_circle_root(first,second,center,aa,bb,1,1) is True
 assert bt.same_circle_root(first,second,center,aa,bb,-1,-1) is False
 cases.append({'name':'exact_shared_theta_zero_matching_branches','expected':True,'actual':True,'pass':True})
 cases.append({'name':'other_branches_cannot_use_shared_theta_zero_proof','expected':False,'actual':False,'pass':True})
 aa=[1.,-1.,0.];bb=[1.,-1.,0.];first=(0,1.);second=(1,-1.)
 assert bt.same_circle_root(first,second,center,aa,bb,1,-1) is True
 assert bt.same_circle_root(first,second,center,aa,bb,1,1) is False
 cases.append({'name':'antiparallel_equations_opposite_branch','expected':True,'actual':True,'pass':True})
 cases.append({'name':'antiparallel_equations_same_branch_rejected','expected':False,'actual':False,'pass':True})
 result={'status':'new_collision_probe_pass','cases':cases,'old_tests_replayed':0,'physical_source_or_map_or_operator_or_solver_calls':0,'roundoff_policy':'exact branch proof and explicit ambiguity rejection; no tolerance modification'}
 save(stage/'result.json',result);save(stage/'worker-evidence.json',{'seconds':time.monotonic()-t0,'runtime_before':before,'runtime_after':threads()});print(dumps_report(result),end='',flush=True)
except BaseException as error:
 save(stage/'failure.json',{'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc(),'runtime_before':before,'seconds':time.monotonic()-t0});raise
