"""Granted new saved-artifact audit; stage-only writes, no physical operations."""
import ctypes as ct,hashlib,json,os,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parents[2];stage=Path(sys.argv[1]).resolve();sys.path.insert(0,str(R/'.local/deepeye-implementation-a/competition/deepeye/tools'));from evidence_json import write_new_report as save,dumps_report
save(stage/'hello.json',{'pid':os.getpid(),'mode':'saved_assembly_audit','before_scientific_import':True});deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
 if time.monotonic()>deadline:raise RuntimeError('no held worker grant')
 time.sleep(.01)
grant=json.loads((stage/'grant.json').read_text(encoding='utf8'));assert grant['worker']['pid']==os.getpid()
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):raise PermissionError('no network/subprocess')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).resolve();m=args[1];flags=args[2];writing=(isinstance(m,str) and any(c in m for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if writing and not p.is_relative_to(stage):raise PermissionError('stage-only writes')
  if not writing and p.suffix=='.npz':raise PermissionError('global matrices forbidden')
sys.addaudithook(audit)
def threads():
 import numpy as np,scipy.linalg,scipy
 kernel=ct.WinDLL('kernel32',use_last_error=True);kernel.GetModuleHandleW.argtypes=[ct.c_wchar_p];kernel.GetModuleHandleW.restype=ct.c_void_p;rows=[]
 for folder,symbol in [('numpy.libs','scipy_openblas_get_num_threads64_'),('scipy.libs','scipy_openblas_get_num_threads')]:
  paths=list((Path(np.__file__).resolve().parents[1]/folder).glob('*openblas*.dll'));assert len(paths)==1;handle=kernel.GetModuleHandleW(str(paths[0]));assert handle;getter=getattr(ct.CDLL(str(paths[0]),handle=handle),symbol);getter.argtypes=[];getter.restype=ct.c_int;count=getter();assert count==1;rows.append({'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),'threads':count})
 return {'numpy':np.__version__,'scipy':scipy.__version__,'BLAS':rows}
before=None;t0=time.monotonic()
try:
 before=threads();sys.path.insert(0,str(D));import audit_saved_assembly;result=audit_saved_assembly.run(stage,save)
 save(stage/'result.json',result);save(stage/'worker-evidence.json',{'seconds':time.monotonic()-t0,'runtime_before':before,'runtime_after':threads()});print(dumps_report(result),end='',flush=True)
except BaseException as error:
 save(stage/'failure.json',{'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc(),'runtime_before':before,'seconds':time.monotonic()-t0});raise
