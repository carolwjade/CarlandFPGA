"""Definitive frozen-source/control metadata audit; no numerical replay."""
import hashlib,importlib.util,json
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parents[2];S=D.parent/'g03-coupled-face-closure-20261023';used={}
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def use(p):used[p.relative_to(R).as_posix()]=pin(p);return p
def read(p):return json.loads(use(p).read_text(encoding='utf8'))
h=R/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py';assert pin(h)['sha256']=='a0aabdbf259f7232bf3e1e77a81d130a8f676ad0b87eba39fae99d118f858554'
sp=importlib.util.spec_from_file_location('reporter',h);reporter=importlib.util.module_from_spec(sp);sp.loader.exec_module(reporter)
def save(name,value):reporter.write_new_report(D/name,value)
handoff=read(S/'control-review-handoff.json');assert handoff['source_pins']['sha256']=='f7db8e5194fede45d4ea324702c78a8b4b148678d6cc714155672a7b5038ebb1'
assert pin(S/'source-pins.json')==handoff['source_pins'];frozen=read(S/'source-pins.json');assert frozen==read(S/'control-source-pins.json') and len(frozen)==41
assert all(pin(use(R/n))==p for n,p in frozen.items());assert len(read(S/'input-pins.json')['files'])==31
revision=read(S/'pre-green-control-revision.json');red=read(S/'red-source-pins.json')
for original,snapshot in [('test_coupled.py','red-test-source.txt'),('run_closure.py','red-runner-source.txt')]:
 assert pin(use(S/snapshot))==red[(S/original).relative_to(R).as_posix()] and pin(S/original)==revision['revised'][original]
old=(S/'red-test-source.txt').read_text(encoding='utf8');new=(S/'test_coupled.py').read_text(encoding='utf8');assert old.replace('K[1,2]!=0','K[0,2]!=0')==new
assert pin(use(S/'red-coupled-moments.txt'))==red[(S/'coupled_moments.py').relative_to(R).as_posix()]
expect=[];stages=[]
for mode,code in [('red',1),('controls',0)]:
 A=S/(mode+'-01');t=read(A/'terminal.json');rb=read(A/'input-readback.json');start=read(A/'started.json')
 assert t['exit_code']==code and t['stop_reason'] is None and t['all_processes_terminated'] and t['active_processes_final']==0
 assert len(t['held_members'])==3 and all(x['signaled'] and x['wait_result']==0 for x in t['held_members'])
 assert rb['unchanged'] and rb['before']==rb['after'];assert start['budget']['seconds']==30 and start['readback_limits']=={'job_memory_bytes':1024**3,'process_memory_bytes':512*1024**2,'active_processes':3}
 for stream in ['stdout','stderr']:assert pin(use(A/(stream+'.txt')))==t['logs'][stream]
 expect.append(pin(use(A/'independent-expectations.json')))
 if mode=='red':
  f=read(A/'failure.json');assert f['type']=='NotImplementedError' and f['message']=='new coupled face pair not implemented'
 else:
  c=read(A/'result.json');assert c==read(A/'stdout.txt')==handoff['result'] and c['comparison_count']==37 and c['new_physical_Fraction_pair_checks']==13
  assert pin(A/'result.json')==handoff['control_result'] and pin(A/'terminal.json')==handoff['control_terminal']
  rt=read(A/'worker-evidence.json');assert rt['runtime_before']==rt['runtime_after']
  for dll in rt['runtime_before']['BLAS']:assert dll['threads']==1 and pin(use(Path(dll['path'])))['sha256']==dll['sha256']
 for q in A.iterdir():
  if q.is_file():use(q)
 stages.append({'mode':mode,'terminal':t})
assert expect[0]==expect[1] and revision['independent_Fraction_expectations_changed'] is False
probe=D/'collision-probe-01';pt=read(probe/'terminal.json');pr=read(probe/'result.json');pw=read(probe/'worker-evidence.json');pb=read(D/'collision-probe-readback.json')
assert pt['exit_code']==0 and pt['stop_reason'] is None and pt['all_processes_terminated'] and len(pt['held_members'])==3 and all(x['signaled'] and x['wait_result']==0 for x in pt['held_members'])
assert pr==read(probe/'stdout.txt') and pr['status']=='new_collision_probe_pass' and len(pr['cases'])==5
assert pw['runtime_before']==pw['runtime_after'] and all(x['threads']==1 for x in pw['runtime_before']['BLAS'])
assert pb['unchanged'] and pb['before']==pb['after'] and pb['after'][(S/'bubble_trace.py').relative_to(R).as_posix()]==pin(S/'bubble_trace.py')
for stream in ['stdout','stderr']:assert pin(use(probe/(stream+'.txt')))==pt['logs'][stream]
for q in probe.iterdir():
 if q.is_file():use(q)
use(D/'collision-probe-plan.json');use(D/'design-review-notes.md');use(D/'provisional-source-findings.md');use(D/'control-tolerance-review.md');use(S/'pre-green-control-revision.json')
save('preexecution-pins.json',used)
save('preexecution-review.json',{'status':'definitive_preexecution_review_no_blocking_findings','work_id':'A-G03-COUPLED-FACE-REVIEW-20261023-v1','source_pins':pin(S/'source-pins.json'),'source_pin_count':41,'used_pin_count':len(used),'source_assessment':{'support_closed_Hcurl_independence':True,'all_overlapping_mass_curl_pairs':True,'physical_curl_scales':True,'ordinary_transpose':True,'full_boundary_U_rows':True,'same_saved_b8_F8_ell8_provenance':True,'no_source_field_global_operator_or_solver_actions':True,'analytic_degree4_circle_primitives':True,'exact_discriminant_and_branch_proofs':True,'ambiguous_root_geometry_stops':True,'strict_file_stdout_and_guard':True},'pre_GREEN_trace_bug':'positive-discriminant float collapse and insufficient common-root proof corrected before GREEN;5case distinct new probe passed','new_controls':c,'expected_RED':True,'RED_GREEN_expectations':expect[0],'test_index_revision_expected_values_unchanged':True,'new_control_bound4096eps_separate_from_production128eps':True,'new_collision_probe':pr,'stages':stages,'probe_terminal':pt,'bounded_single_assembly_acceptable_for_root_selection':True,'assembly_selected_by_reviewer':False,'PDE_solve_selected':False,'actual_result_review_pending':True,'root_retains':'actual assembly selection and evidence acceptance','H01_H15_preserved':True,'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','limitations':['Assembly success does not establish physical1% accuracy or convergence.','Original24disjoint coverage failure and GMRESinfo3 remain failed.','No finite-strength/noise/OOD/runtime/G03/R03/all29 qualification.']})
print(reporter.dumps_report({'status':'preexecution_no_blocking_findings','source_pins':pin(S/'source-pins.json'),'used_pins':len(used),'new_control_comparisons':37,'new_collision_cases':5}),end='')
