"""Distinct bounded saved-artifact audit; no production numerical imports."""
import ast,hashlib,json,math,struct,sys
from fractions import Fraction as F
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parents[2];S=D.parent/'g03-coupled-face-closure-20261023';A=S/'assembly-01';EPS=sys.float_info.epsilon
def run(stage,save):
 used={};checks=[]
 def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 def use(p):used[p.relative_to(R).as_posix()]=pin(p);return p
 def read(p):return json.loads(use(p).read_text(encoding='utf8'))
 def npy(p):
  raw=use(p).read_bytes();assert raw[:6]==b'\x93NUMPY';v=raw[6];assert v in (1,2,3);start=10 if v==1 else 12;n=int.from_bytes(raw[8:start],'little');h=ast.literal_eval(raw[start:start+n].decode('latin1' if v<3 else 'utf8'));assert not h['fortran_order'];data=raw[start+n:]
  formats={'<f8':('d',8),'<i8':('q',8),'<i4':('i',4),'|b1':('?',1),'<c16':('dd',16)};fmt,size=formats[h['descr']];assert len(data)==math.prod(h['shape'])*size
  values=[complex(*x) if h['descr']=='<c16' else x[0] for x in struct.iter_unpack('<'+fmt,data)];assert all(math.isfinite(x.real) and math.isfinite(x.imag) if isinstance(x,complex) else math.isfinite(x) for x in values)
  return values,tuple(h['shape'])
 def vec(name,shape=None):
  v,h=npy(A/(name+'.npy'));assert shape is None or shape==h;return v
 inputs=read(S/'input-pins.json')
 def old(name):return npy(R/inputs['aliases'][name])[0]
 frozen=read(S/'source-pins.json');assert len(frozen)==41 and pin(S/'source-pins.json')['sha256']=='f7db8e5194fede45d4ea324702c78a8b4b148678d6cc714155672a7b5038ebb1'
 assert all(pin(use(R/n))==p for n,p in frozen.items())
 selection=read(D.parent/'g03-coupled-face-main-review-20261023/assembly-selection.json');assert selection==read(S/'root-assembly-selection.json') and selection['assembly_attempt_selected'] and selection['source_pins_sha256']==pin(S/'source-pins.json')['sha256']
 assert selection['independent_preexecution_review']==pin(D/'preexecution-review.json')
 result=read(A/'result.json');assert pin(A/'result.json')['sha256']=='051bf08aae3b80779196cf885785b20f578d270d4e04b7d025a48f6c3320a1cb' and result==read(A/'stdout.txt')
 terminal=read(A/'terminal.json');runtime=read(A/'worker-evidence.json');start=read(A/'started.json');rb=read(A/'input-readback.json')
 assert terminal['exit_code']==0 and terminal['stop_reason'] is None and terminal['all_processes_terminated'] and terminal['active_processes_final']==0 and len(terminal['held_members'])==3 and all(x['signaled'] and x['wait_result']==0 and x['exit_code']==0 for x in terminal['held_members'])
 assert start['budget']['seconds']==30 and start['readback_limits']=={'job_memory_bytes':1024**3,'process_memory_bytes':512*1024**2,'active_processes':3}
 assert rb['unchanged'] and rb['before']==rb['after']==frozen and runtime['runtime_before']==runtime['runtime_after']
 for dll in runtime['runtime_before']['BLAS']:assert dll['threads']==1 and pin(use(Path(dll['path'])))['sha256']==dll['sha256']
 for stream in ('stdout','stderr'):assert pin(use(A/(stream+'.txt')))==terminal['logs'][stream]
 assert (A/'stderr.txt').stat().st_size==0
 keys=old('keys');cells=old('cells');score=old('score8');resolved=old('resolved8');bounds=old('bounds');mapping=old('mapping');B=set(old('B'))
 seeds=vec('seed_indices',(128,));seedkeys=vec('seed_keys',(128,5));marked=vec('marked_cells',(134,));ids=vec('closure_indices',(556,));ck=vec('closure_keys',(556,5));cc=vec('closure_cells',(556,2));Q=len(ids)
 key=lambda i:tuple(keys[i*5:i*5+5])
 assert len(set(seeds))==128 and all(resolved[i] for i in seeds) and seeds==sorted(seeds,key=lambda i:(-score[i],key(i)))
 seedset=set(seeds);last=(-score[seeds[-1]],key(seeds[-1]));assert all((-score[i],key(i))>=last for i in range(len(score)) if resolved[i] and i not in seedset)
 assert seedkeys==[v for i in seeds for v in keys[5*i:5*i+5]] and marked==sorted({v for i in seeds for v in cells[2*i:2*i+2]})
 markedset=set(marked);assert ids==sorted(set(ids)) and ck==[v for i in ids for v in keys[5*i:5*i+5]] and cc==[v for i in ids for v in cells[2*i:2*i+2]]
 idset=set(ids);assert all((cells[2*i] in markedset and cells[2*i+1] in markedset)==(i in idset) for i in range(len(score)))
 for i in range(0,Q,2):assert ck[5*i:5*i+4]==ck[5*(i+1):5*(i+1)+4] and ck[5*i+4]!=ck[5*(i+1)+4]
 fq=vec('F8_Q',(Q,));ell=vec('ell8_Q',(Q,));f8=old('F8');e8=old('ell8');assert fq==[f8[i] for i in ids] and ell==[e8[i] for i in ids]
 rows=vec('Q_rows');cols=vec('Q_cols');M=vec('MQ');K=vec('KQ');Ms=vec('MQ_absolute_scale');Ks=vec('KQ_absolute_scale');Dq=vec('D');Ds=vec('D_absolute_scale');pairs=list(zip(rows,cols));assert len(pairs)==8888 and pairs==sorted(set(pairs)) and all(0<=a<Q and 0<=b<Q for a,b in pairs)
 lookup={pair:i for i,pair in enumerate(pairs)};assert all((b,a) in lookup for a,b in pairs) and all(x>=0 for x in Ms+Ks+Ds)
 p=read(R/inputs['aliases']['S1_assignment'])['inputs'];omega=2*math.pi*p['frequency_Hz'];mu=p['mu_background_Hpm'];coeff=1j*omega*complex(p['sigma_background_Spm'],omega*p['epsilon_background_Fpm'])
 for i,(a,b) in enumerate(pairs):
  j=lookup[(b,a)];assert abs(M[i]-M[j])<=128*EPS*(Ms[i]+Ms[j]) and abs(K[i]-K[j])<=128*EPS*(Ks[i]+Ks[j])
  expected=K[i]/mu+coeff*M[i];assert abs(Dq[i]-expected)<=128*EPS*(Ds[i]+abs(K[i]/mu)+abs(coeff*M[i]))
  es=Ks[i]/mu+abs(coeff)*Ms[i];assert abs(Ds[i]-es)<=128*EPS*(abs(Ds[i])+abs(es))
 mq=old('Mq');kq=old('Kq')
 for q,index in enumerate(ids):
  j=lookup[(q,q)];assert abs(M[j]-mq[index])<=128*EPS*(Ms[j]+abs(mq[index])) and abs(K[j]-kq[index])<=128*EPS*(Ks[j]+abs(kq[index]))
 ur=vec('U_rows');uc=vec('U_cols');uv=vec('U');us=vec('U_absolute_scale');bm=vec('U_boundary_rows_mask');upairs=list(zip(ur,uc));assert len(uv)==11120 and upairs==sorted(set(upairs)) and all(0<=a<63250 and 0<=b<Q for a,b in upairs)
 assert bm==[r in B for r in ur] and sum(bm)==result['U_boundary_entries']==0 and all(v>=0 for v in us)
 counts={q:0 for q in range(Q)}
 for edge,q in upairs:
  counts[q]+=1;support=set(mapping[cc[2*q]*12:cc[2*q]*12+12]+mapping[cc[2*q+1]*12:cc[2*q+1]*12+12]);assert edge in support
 assert max(counts.values())<=20
 off=[i for i,(a,b) in enumerate(pairs) if a!=b];assert sum(M[i]!=0 for i in off)==result['nonzero_offdiagonal_MQ']==2338 and sum(K[i]!=0 for i in off)==result['nonzero_offdiagonal_KQ']==2338
 checks.append({'name':'sparse_structure_canonical_closure_source_subsets_diagonal_ordinary_symmetry','pass':True,'seeds':128,'cells':134,'modes':Q,'U_entries':len(uv),'Q_entries':len(pairs),'boundary_U_entries':sum(bm),'nonzero_offdiagonal_MQ_KQ_each':2338})
 chosen={}
 for i in off:
  a,b=pairs[i]
  if M[i]==K[i]==0:continue
  category=(ck[5*a]==ck[5*b],ck[5*a+4]==ck[5*b+4])
  chosen.setdefault(category,i)
 selected=list(chosen.values())[:12]
 ui=[]
 for q in (0,Q//2,Q-1):
  entries=[i for i,x in enumerate(uc) if x==q and uv[i]!=0]
  for i in (entries[:1]+entries[-1:]):
   if i not in ui:ui.append(i)
 ui=ui[:6]
 save(stage/'sample-selection.json',{'selection_rule':'first nonzero offdiagonal per same/different normal/tangent class capped12; first/last nonzero U entries in first/middle/last columns capped6','QQ':[{'entry':i,'row':pairs[i][0],'col':pairs[i][1],'key_row':ck[5*pairs[i][0]:5*pairs[i][0]+5],'key_col':ck[5*pairs[i][1]:5*pairs[i][1]+5]} for i in selected],'U':[{'entry':i,'edge':ur[i],'col':uc[i]} for i in ui],'criterion':'128eps*(saved absolute-product scale + independent absolute-product scale); exact zero/finite checks; no fullassembly or source replay'})
 one={(0,0,0):F(1)}
 def mult(a,b):
  out={}
  for ka,va in a.items():
   for kb,vb in b.items():
    k=tuple(x+y for x,y in zip(ka,kb));out[k]=out.get(k,F(0))+va*vb
  return {k:v for k,v in out.items() if v}
 def qpoly(n,t,side):
  def coordinate(j,bit):
   k=tuple(int(a==j) for a in range(3));return {k:F(1)} if bit else {(0,0,0):F(1),k:F(-1)}
  b=3-n-t;poly=mult(coordinate(n,side==0),mult(coordinate(b,True),coordinate(b,False)));return {k:4*v for k,v in poly.items()}
 def curl(poly,t,h):
  out=[{} for _ in range(3)]
  for j in range(3):
   if j==t:continue
   c=3-j-t;sign=1 if (c,j,t) in ((0,1,2),(1,2,0),(2,0,1)) else -1
   out[c]={tuple(k[a]-int(a==j) for a in range(3)):sign*v*k[j]/h[j] for k,v in poly.items() if k[j]}
  return out
 def integrate_pair(a,b,volume):
  terms=[volume*va*vb/math.prod(F(x+y+1) for x,y in zip(ka,kb)) for ka,va in a.items() for kb,vb in b.items()]
  return sum(terms,F(0)),sum(map(abs,terms),F(0))
 def local_integrals(cell,a,ta,b,tb):
  h=[F.from_float(bounds[cell*6+3+j])-F.from_float(bounds[cell*6+j]) for j in range(3)];volume=math.prod(h);m,ms=integrate_pair(a,b,volume) if ta==tb else (F(0),F(0));ca=curl(a,ta,h);cb=curl(b,tb,h);ks=[integrate_pair(x,y,volume) for x,y in zip(ca,cb)];return m,sum((v[0] for v in ks),F(0)),ms,sum((v[1] for v in ks),F(0))
 samples=[]
 for i in selected:
  a,b=pairs[i];shared=set(cc[2*a:2*a+2])&set(cc[2*b:2*b+2]);assert shared;terms=[]
  for cell in sorted(shared):
   sa=cc[2*a:2*a+2].index(cell);sb=cc[2*b:2*b+2].index(cell);na,ta=ck[5*a],ck[5*a+4];nb,tb=ck[5*b],ck[5*b+4];terms.append(local_integrals(cell,qpoly(na,ta,sa),ta,qpoly(nb,tb,sb),tb))
  exact=[sum((v[j] for v in terms),F(0)) for j in range(4)];em,ek,ems,eks=map(float,exact);mb=128*EPS*(Ms[i]+ems);kb=128*EPS*(Ks[i]+eks);me=abs(M[i]-em);ke=abs(K[i]-ek);assert me<=mb and ke<=kb
  samples.append({'entry':i,'row':a,'col':b,'shared_cells':sorted(shared),'M_error':me,'M_bound':mb,'K_error':ke,'K_bound':kb})
 checks.append({'name':'distinct_Fraction_offdiagonal_pair_samples','pass':True,'cases':samples})
 samples=[]
 for i in ui:
  edge,q=ur[i],uc[i];terms=[]
  for side,cell in enumerate(cc[2*q:2*q+2]):
   local=mapping[cell*12:cell*12+12]
   if edge not in local:continue
   slot=local.index(edge);ta=slot//4;transverse=[j for j in range(3) if j!=ta];poly=one
   for j,bit in zip(transverse,(slot%2,(slot//2)%2)):
    k=tuple(int(a==j) for a in range(3));factor={k:F(1)} if bit else {(0,0,0):F(1),k:F(-1)};poly=mult(poly,factor)
   n,t=ck[5*q],ck[5*q+4];terms.append(local_integrals(cell,poly,ta,qpoly(n,t,side),t))
  exact=[sum((v[j] for v in terms),F(0)) for j in range(4)];m,k,ms,ks=map(float,exact);want=k/mu+coeff*m;bound=128*EPS*(us[i]+ks/mu+abs(coeff)*ms);err=abs(uv[i]-want);assert err<=bound;samples.append({'entry':i,'edge':edge,'col':q,'error':err,'bound':bound})
 checks.append({'name':'distinct_Fraction_coarse_bubble_U_samples','pass':True,'cases':samples})
 trace=vec('tQ',(2,Q));trace_scale=vec('tQ_absolute_scale',(2,Q));stats=vec('trace_interval_root_statistics',(2,Q,5));events=read(A/'trace-events.json');assert len(events)==2*Q and not any(trace) and not any(trace_scale)
 assert sum(stats[5*i+1] for i in range(2*Q))==0 and sum(stats[5*i] for i in range(2*Q))==4052
 for i,event in enumerate(events):assert event['receiver']==i//Q and event['column']==i%Q and event['active_intervals']==0 and event['zero_reason']=='no active support interval'
 # A conservative radius-cube bound is independent of trace splitting and of tilt.
 gaps=[];radius=p['Rx_radius_m']
 for rx,center in enumerate(p['Rx_centers_m']):
  separated=[];unproved=[]
  for cell in marked:
   gap=max(max(bounds[cell*6+j]-(center[j]+radius),(center[j]-radius)-bounds[cell*6+3+j]) for j in range(3));separated.append(gap)
   if gap<=0:unproved.append(cell)
  gaps.append({'receiver':rx,'all_marked_cells_outside_radius_cube':not unproved,'minimum_axis_separation_m':min(separated),'cells_not_proved_by_conservative_cube':unproved})
 checks.append({'name':'zero_new_trace_columns_independent_support_separation','pass':True,'zero_columns':2*Q,'split_intervals':4052,'active_intervals':0,'radius_cube_proof':gaps})
 for q in A.iterdir():
  if q.is_file():use(q)
 save(stage/'audit-pins.json',used)
 return {'status':'saved_coupled_assembly_audit_pass','checks':checks,'blocking_findings':[],'actual_result':result,'actual_terminal':terminal,'sample_Q_pairs':len(selected),'sample_U_entries':len(ui),'new_source_field_or_global_operator_or_solver_calls':0,'old_tests_replayed':0,'fullassembly_repeated':False,'physical_accuracy':'unqualified','G03':'not_run','R03':'not_run','all29':'not_run','root_retains':'evidence acceptance and subsequent solve selection'}
