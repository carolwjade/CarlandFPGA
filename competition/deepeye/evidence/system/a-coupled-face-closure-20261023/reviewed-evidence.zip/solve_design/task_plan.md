# Static coupled-solve design

- Completed: lease, role/transfer/H01-H15 verification.
- Completed: exact same-field residual and boundary/source/trace provenance pinned.
- Completed: single prospective solve, full augmented numerical/physical gates and bounded resource/dependency plan.
- Completed: static metadata/hash checks only; no science/tests/arrays decoded.
- Root retains actual coupling acceptance and any new solve selection.
