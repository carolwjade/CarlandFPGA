# One prospective global coupled correction

Recommend **one matrix-free condensed Schur GMRES**, with full coupled D factored once and one **fresh** saved-A0II COLAMD LU used only as a left preconditioner. Root must first accept the actual coupled assembly and final source/output pins; no solve is selected here. m<=804/134cells remain bounds, not measured assembly results. Current product490adb3 is parent-recorded; no Git operation was performed.

This job is static only: no tests, numerical imports, array decoding/reduction, source/operator action, factorization, or solve. The new overlap/block/circle controls belong to the author/reviewer; their static source is cited, not replayed or declared passed.

## Exact reusable inputs

Paths below are relative to repository root. `source-manifest.json` gives every used file's current byte count/SHA256 and verifies known input/manifest pins without decoding arrays.

| Role | Exact saved artifact |
|---|---|
| A0II | `.planning/deepeye-resume-20261018/g03-l5-propagation-z-refinement-20261021/run-01/AII-csc.npz` |
| I | `.planning/deepeye-resume-20261018/g03-s1-cache-path-continuation-20261021/controls-01/interior_indices.npy` |
| B | `.planning/deepeye-resume-20261018/g03-s1-cache-path-continuation-20261021/controls-01/boundary_indices.npy` |
| gB | `.planning/deepeye-resume-20261018/g03-s2-boundary-correction-20261021/run-01/selected_gB_Vpm.npy` |
| trace | `.planning/deepeye-resume-20261018/g03-s1-cache-path-continuation-20261021/controls-01/receiver_trace_m.npy` |
| Ac | `.planning/deepeye-resume-20261018/g03-consistent-solve-20261023/assembly-01/Ac-csr.npz` |
| Eh | `.planning/deepeye-resume-20261018/g03-consistent-candidate-independent-20261023/audit-01/candidate_E4_full_Vpm.npy` |
| rEh4_compensated | `.planning/deepeye-resume-20261018/g03-consistent-candidate-independent-20261023/audit-01/candidate_final_residual_I_Amps.npy` |
| strict_old_correction_residual | `.planning/deepeye-resume-20261018/g03-consistent-solve-20261023/actual-01/true_correction_residual_I_Amps.npy` |
| beff4_compensated | `.planning/deepeye-resume-20261018/g03-consistent-candidate-independent-20261023/audit-01/boundary_adjusted_rhs_compensated.npy` |
| old_Vh_compensated | `.planning/deepeye-resume-20261018/g03-consistent-candidate-independent-20261023/audit-01/V4_compensated_V.npy` |
| high_H_saved | `.planning/deepeye-resume-20261018/g03-consistent-candidate-independent-20261023/audit-01/H_high_reference_V.npy` |
| b8 | `.planning/deepeye-resume-20261018/g03-source8-enrichment-20261023/source-01/b8.npy` |
| delta_b8_minus_b4 | `.planning/deepeye-resume-20261018/g03-source8-enrichment-20261023/source-01/delta_b8_minus_b4.npy` |

F8/ell8 are pinned under g03-source8-enrichment-20261023/source-01/. b8/F8 share accepted saved current and one -i omega source factor. Source8 root decision accepts consistency and negative concentration evidence, not integration. Required future U/MQ/KQ/D/F8_Q/ell8_Q/traceQ arrays and their final filenames/hashes must come from the **actual accepted author manifest**, in canonical closure order. They do not exist as accepted inputs yet; this design does not invent them.

Eh and rEh4 come from the same independent audit: `candidate_audit.py` forms Eh=E3+scatter(old_delta), then compensated real/imaginary CSR sums compute(Ac Eh-b4)_I and save both arrays. The audit reached seven comparisons and30raw arrays, then its JSON report failed on a NumPy boolean. Its raw result/exit1 remain failed. Root's separate metadata recovery documents those arrays and receiver failures; it neither reran science nor changed the failed audit/solve status. These raw arrays are reusable diagnostic inputs despite the failed reporting stage, conditional on exact pins/root disposition.

The strict old residual is instead AII*old_delta+r0, saved by the info3 solve. It is only arithmetically consistent with the rounded full Eh; do not treat it as bit-identical or silently substitute it. Old native job is terminal **failed**,78callbacks; the audit's native review completed while its diagnostic process failed. No factor object was serialized: only the old A0II matrix survives.

## One new correction, no old warm-up

Use compensated rEh4 for the exact saved full Eh:

```
r8 = rEh4_compensated - delta_b8_minus_b4[I]
beff8 = beff4_compensated + delta_b8_minus_b4[I]
fbarQ = F8_Q - U_B.T @ gB
S(v) = Ac_II @ v - U_I @ solve_D(U_I.T @ v)
h = -r8 + U_I @ solve_D(ell8_Q)
S delta = h
alpha = solve_D(ell8_Q - U_I.T @ delta)
e = Eh + scatter_I(delta); e[B] = gB exactly
```

`solve_D` is an actual solve with **all** offdiagonals of D=KQ/mu+i omega zeta0 MQ. Never divide elementwise by its diagonal. Ordinary transpose applies to U and physical blocks; GMRES's internal Arnoldi Hermitian dot products stay unchanged. Full U boundary rows are retained. Boundary RHS is `[b8_I-Ac_IB gB; F8_Q-U_B.T gB]`; zero bubble boundary trace does not imply U_B=0.

Build only AcII and sparse U/D views from saved matrices. No rebuilt mesh/CSR, source/primary/reference evaluation, or Ac@Eh warm-up. Saved r8 reuse is RHS construction, **never** a replacement for the final new equation check. The first new global operator action serves GMRES or final residual verification.

Factor D once with sparse COLAMD LU first; stop on warning/singular/nonfinite factor or exported L+U storage>64MiB. m<=804 bounds factor entries bym(m+1), while temporary workspace remains under the whole-process guard. Then factor the pinned A0II once with COLAMD; no factor cache is claimed. Use its fixed lu.solve as GMRES M. Do not form S or the full augmented CSR, invert D, run a tuning preconditioner solve, or retry.

One complex128 GMRES call: zero start,restart40,maxiter3,rtol1e-12,atol0,callback_type=pr_norm,at most120callbacks. Installed SciPy iterative.py:593,705-725,831-852 confirms the unpreconditioned stopping test is distinct from callback/preconditioned values. Record info, true condensed residual and threshold1e-12||h||2, including undefined/zero-RHS handling; do not infer convergence from callbacks.

## Direct NEW full augmented numerical gate

Using the **actual returned** coarse/bubble candidate, independently accumulate complex products with real/imaginary math.fsum:

```
rI = (Ac @ e - b8)[I] + U_I @ alpha
rQ = U.T @ e + D @ alpha - F8_Q
Baug = [[Ac_II,U_I],[U_I.T,D]]
x = [e_I,alpha]; baug = [beff8,fbarQ]
p_i = sum_j abs(Baug_ij)*abs(x_j) + abs(baug_i)
floor_i = 128*eps*p_i
eta = ||[rI,rQ]||inf / (||Baug||inf*||x||inf + ||baug||inf)
```

For norms, use actual augmented absolute row sums, not preconditioner or Schur norms. Retain full U rows in rQ. Also verify the direct boundary-form residual agrees with Baug*x-baug within declared128eps absolute-product scales; boundary-action scales are pinned and new U_B*gB scales must be retained. This is a new coupled-equation check, not a repeat of the old candidate audit.

Freeze policy **before** any future execution: strict info0 remains strict solver status; independently report the unchanged true condensed screen. A positive info may be called `roundoff_limited_candidate` only when every new full augmented row satisfies abs(r_i)<=floor_i and eta<=128eps, with all fields/scales/norms finite. A zero scale requires exact zero residual; undefined denominator fails except an explicitly all-zero equation/candidate case. This label is not strict convergence. Negative info, failed numerical gate or resources stops. Apply the same full augmented verification to info0 candidates. Original info3 remains failed under its original policy.

## Physical gate and persistence

After candidate/numerical outputs are sealed, compute compensated V=t_coarse@e+traceQ@alpha using unchanged tilted circles and turns already applied exactly once in each trace. Cross-check V against saved Vh+t_coarse[:,I]@delta+traceQ@alpha using128eps absolute-product sums. Read the original high H only for evaluation; both complex errors abs(V_j-H_j)/abs(H_j) must be<=0.01. Denominators H and V must exceed128eps times the full coarse+bubble absolute trace-product sum, else undefined/fail. No amplitude/phase tuning, bias subtraction, mesh/mode reselection or reference-driven RHS. A tiny backward eta proves no receiver accuracy.

On GMRES return, **before post-return JSON or info stop**, save raw returned delta and integer info. Then recover/save raw alpha and full e, compute/save raw new residuals/scales and strict condensed residual; only then serialize numerical verdict. Save nonfinite returned arrays as raw evidence before rejecting them—do not reuse a finite-only save helper that discards them. If recovery/resource failure prevents later arrays, retain what exists and mark exact missing outputs. Callback journals are streamed while the solver runs. Save raw receiver/error arrays before metadata conversion; use exact accepted evidence_json for files/stdout and verify readback. Serializer failure remains failure with arrays preserved, not an invitation to rerun.

## Cost, limits and dependency gate

Old fresh A0 LU took68.172s; its full failed stage took84.281s at3,420,585,984B, with3held handles terminated. No old execution is repeated here. Condensed dimension54418 and41complex vectors require35,698,208B. U<=16080,D<=19296structural entries and m<=804 are bounds. Dense m-square complex storage would be10,342,656B; no dense inverse is used. Added local working allowance128MiB and Dfactor export cap64MiB are ceilings, not measured fill/workspace guarantees.

Propose a **new** one-attempt120s job,4GiB/process,5GiB/job, fresh free physical>=10GiB,3held processes,BLAS1 before/after,256MiBartifacts/2048entries,128KiB per pipe,512MiBfree reserve. Frozen phase caps:5spreflight,5sDfactor,80sfreshA0factor,20sGMRES,10ssave/verification/receivers; exact held guard120s also caps the whole job. This is an explicit proposal for genuinely new equations, not an extension/retry of the old90s failure. The old stage stopped before full receiver verification, so its84.281s is not an end-to-end estimate for this work. A stage/total overrun ends the one attempt; no automatic retry/time increase. Timing/convergence are unproven and root may decline this resource proposal.

Actual coupling acceptance, D conditioning, fill and convergence remain unresolved dependencies. If a concrete review finds Schur cancellation/stability unacceptable, one material alternative is a **separately selected** full-augmented GMRES with upper triangular P=[[A0II,U_I],[0,D]], using one full D factor and one fresh A0 factor. It avoids condensed subtraction and retains exact blocks/gates; it does not remove A0's dominant cost. It is not a fallback or second call in this proposal. If the fresh A0 budget itself is infeasible, report that blocker; no evidence supports a cheaper substitute here.

Root must consume accepted final coupled source/control/output manifest and reviewer disposition, replace pending artifact roles with real hashes, and freeze the new runner/policy/resources before selecting execution. Reuse the author's new overlap,2coarse/2bubble boundary and partial-circle controls; do not duplicate them. This worker selects nothing. Full H01-H15 hash c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 is preserved; derivative1% success would still leave arbitrary3D material/finite-strength/noise/OOD/20Hz/H12/fullG03/R03/all29 requirements unqualified/not_run.
