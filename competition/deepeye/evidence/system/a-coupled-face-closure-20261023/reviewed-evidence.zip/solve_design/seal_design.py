"""Static metadata/hash/design output only; never decode arrays or import science."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
old=P/'g03-consistent-solve-20261023';audit=P/'g03-consistent-candidate-independent-20261023';s8=P/'g03-source8-enrichment-20261023';base=read(old/'input-pins.json')
aliases={k:base['paths'][k] for k in ('A0II','I','B','gB','trace','H','b3')}
aliases.update({
 'Ac':(old/'assembly-01/Ac-csr.npz').relative_to(ROOT).as_posix(),
 'Eh':(audit/'audit-01/candidate_E4_full_Vpm.npy').relative_to(ROOT).as_posix(),
 'rEh4_compensated':(audit/'audit-01/candidate_final_residual_I_Amps.npy').relative_to(ROOT).as_posix(),
 'rEh4_scale':(audit/'audit-01/candidate_final_residual_sum_scale_I.npy').relative_to(ROOT).as_posix(),
 'strict_old_correction_residual':(old/'actual-01/true_correction_residual_I_Amps.npy').relative_to(ROOT).as_posix(),
 'strict_old_delta':(old/'actual-01/returned_GMRES_candidate_delta_I_Vpm.npy').relative_to(ROOT).as_posix(),
 'beff4_compensated':(audit/'audit-01/boundary_adjusted_rhs_compensated.npy').relative_to(ROOT).as_posix(),
 'boundary_action_compensated':(audit/'audit-01/boundary_action_compensated.npy').relative_to(ROOT).as_posix(),
 'old_Vh_compensated':(audit/'audit-01/V4_compensated_V.npy').relative_to(ROOT).as_posix(),
 'high_H_saved':(audit/'audit-01/H_high_reference_V.npy').relative_to(ROOT).as_posix(),
 'b8':(s8/'source-01/b8.npy').relative_to(ROOT).as_posix(),
 'delta_b8_minus_b4':(s8/'source-01/delta_b8_minus_b4.npy').relative_to(ROOT).as_posix(),
 'F8':(s8/'source-01/F8.npy').relative_to(ROOT).as_posix(),
 'ell8':(s8/'source-01/ell8.npy').relative_to(ROOT).as_posix()})
source_files=[
 old/'manifest.json',old/'input-pins.json',old/'solve_stages.py',old/'run_solve.py',old/'report.md',old/'actual-01/terminal.json',old/'actual-01/factorization-complete.json',old/'actual-01/gmres-return.json',old/'actual-01/failure.json',old/'assembly-01/pre-factorization.json',
 audit/'manifest.json',audit/'candidate_audit.py',audit/'audit-01/terminal.json',audit/'audit-01/failure.json',audit/'audit-01/result.json',
 P/'g03-consistent-solve-main-review-20261023/candidate-metadata-recovery.json',P/'g03-consistent-solve-main-review-20261023/original-native-result.json',P/'g03-consistent-solve-main-review-20261023/independent-native-result.json',P/'g03-consistent-solve-main-review-20261023/decision.json',
 P/'g03-source8-main-review-20261023/decision.json',s8/'manifest.json',s8/'input-pins.json',s8/'source8_stage.py',s8/'source-01/worker-evidence.json',
 P/'g03-face-enrichment-20261023/input-pins.json',P/'g03-next-space-design-20261023/design.md',P/'g03-next-space-design-20261023/manifest.json',
 P/'g03-coupled-face-closure-20261023/assignment.md',P/'g03-coupled-face-closure-20261023/design.md',P/'g03-coupled-face-closure-20261023/test_coupled.py',P/'g03-coupled-face-independent-20261023/design-review-notes.md',
 ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py',P/'r02-amd-wheel-acquisition-20261021/win_job.py',P/'r02-amd-wheel-acquisition-20261021/boundary.py',
 ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe',ROOT/'.local/deepeye-fdem-validation-20261020/Lib/site-packages/scipy/sparse/linalg/_isolve/iterative.py',
 ROOT/'.agents/skills/fpga-multi-node/SKILL.md',ROOT/'.agents/skills/fpga-multi-node/skill-role.json',ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json',ROOT/'docs/competition/deepeye-2026/immutable_scope.md',ROOT/'docs/competition/deepeye-2026/immutable_scope.json',D/'assignment.md']
expected=dict(base['files'])
for folder in (old,audit,s8):
 for name,v in read(folder/'manifest.json')['files'].items():expected[(folder/name).relative_to(ROOT).as_posix()]=v
all_paths=set(aliases.values())|{p.relative_to(ROOT).as_posix() for p in source_files}
pins={n:pin(ROOT/n) for n in sorted(all_paths)}
for n,v in pins.items():
 if n in expected:assert v==expected[n],n
assert pins[(s8/'manifest.json').relative_to(ROOT).as_posix()]['sha256']=='1675faac6617b77609ecf9b524c0c3768325a869543227124a16436d77f1059a'
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
requirements=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert requirements=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804' and [r['id'] for r in scope['requirements']]==['H%02d'%i for i in range(1,16)]
assert read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')['status']=='active'
assert read(P/'g03-consistent-solve-main-review-20261023/original-native-result.json')['status']=='failed'
assert read(P/'g03-source8-main-review-20261023/decision.json')['decision']=='ACCEPT_SOURCE8_CONSISTENCY_AND_NEGATIVE_BOUNDED_ENRICHMENT_EVIDENCE'
manifest_record={'work_id':'A-G03-COUPLED-SOLVE-DESIGN-20261023-v1','aliases':aliases,'files':pins,'array_payload_decodes':0,'science_imports':0,'operator_actions':0,'tests':0,'factorizations':0,'solves':0,'requirements_sha256':requirements,'active_author_control_source':'snapshot of static read only; final accepted author/reviewer source/output manifest must be rebound before any solve; no pass claimed'}
(D/'source-manifest.json').write_text(json.dumps(manifest_record,indent=2),encoding='utf-8')
pending={'owner':'g03-coupled-face-closure-20261023','status':'actual assembly not yet accepted at assignment','required_roles':['canonical closure key/index order','full global-row U and absolute scales','full coupled MQ/KQ/D and scales','F8_Q and ell8_Q directly indexed from source8','two receiver traceQ columns and absolute scales','actual m<=804 and cells<=134','passed new coupled/trace controls with exact frozen sources','root selected actual assembly plus independent reviewer disposition and final manifest hashes'],'forbidden':'Do not guess pending output filenames or treat active stub/control source as accepted numerical output.'}
N=54418;M=804
counts={'condensed_unknowns':N,'maximum_augmented_unknowns':N+M,'maximum_modes':M,'old_AII_nnz_recorded':1688730,'full_Ac_nnz_recorded':1969810,'maximum_U_nnz':16080,'maximum_D_nnz':19296,'condensed_41vector_complex128_bytes':N*41*16,'maximum_bubble_factor_LU_nnz_bound':M*(M+1),'bubble_factor_export_cap_bytes':64*1024**2,'dense_m_by_m_complex128_bytes':M*M*16,'additional_local_working_allowance_bytes':128*1024**2}
design={'work_id':manifest_record['work_id'],'job_id':'child-13346d9ec4ca4670a35b4a8c25639779','agent_id':'/root/b_op23_independent_20261022','status':'static prospective design; root selection required','product_head':'490adb3bc7a1190b8f2cf424d29f5c987ec63b42 (parent/author recorded; no Git operation performed)','solver':'one condensed Schur GMRES, full D sparse LU, saved A0II fresh COLAMD LU as fixed left preconditioner','parameters':{'restart':40,'maxiter':3,'rtol':1e-12,'atol':0,'callback_type':'pr_norm','maximum_callbacks':120,'x0':'zero complex128'},'identities':{'r8':'saved rEh4_compensated - delta_b8_minus_b4[I]','beff8':'saved beff4_compensated + delta_b8_minus_b4[I]','fbarQ':'F8_Q-U_B.T@gB','S':'Ac_II-U_I D^-1 U_I.T','correction_rhs':'-r8+U_I D^-1 ell8_Q','recovery':'e=Eh+scatter_I(delta); e[B]=gB; alpha=D^-1(ell8_Q-U_I.T@delta)','bilinear':'ordinary transpose for physical blocks; no conjugation; SciPy GMRES Arnoldi still uses its normal Hermitian dot products'},'warm_start_limit':'Exact saved full Eh and same-field compensated rEh4 are paired. Strict original correction residual is a different arithmetic expression and remains failed info3 evidence. Reuse is only RHS construction, never the new final equation test.','required_new_full_equation_test':{'rI':'(Ac@e-b8)[I]+U_I@alpha','rQ':'U.T@e+D@alpha-F8_Q','Baug':'[[Ac_II,U_I],[U_I.T,D]]','rhs':'[b8_I-Ac_IB*gB, F8_Q-U_B.T*gB]','component_scale':'p=abs(Baug)@abs([e_I,alpha])+abs(rhs); floor=128eps*p; zero scale requires exact zero residual','eta':'norminf(r)/(norminf(Baug)*norminf([e_I,alpha])+norminf(rhs)) using actual augmented absolute row sums','gate':'all finite; every row abs(compensated residual)<=floor and eta<=128eps; same checks apply in both strict and roundoff-limited paths','boundary':'full U boundary rows remain present in rQ; zero bubble boundary trace does not imply U_B=0'},'prospective_status_policy':{'strict':'info0 with unchanged true condensed residual screen; report info and unpreconditioned ratio separately from callback values','roundoff_limited':'positive info may produce a roundoff_limited_candidate only if the independently recomputed new full augmented row floors and eta pass; never relabel strict convergence','failure':'negative info, nonfinite, any row/eta failure, singular/oversized D factor, resource failure or absent accepted assembly stops without retry','old_results':'original info3/native failure and both old receiver failures never change'},'physical_gate':{'V':'compensated ordinary t_coarse@e + traceQ@alpha, receiver turns already included once','cross_check':'saved Vh + t_coarse[:,I]@delta + traceQ@alpha with128eps absolute-product scale','reference':'frozen original high H row; saved high_H_saved is independently pinned counterpart','stability':'abs(H_j) and abs(V_j) exceed128eps total coarse+bubble trace absolute-product scale, else undefined/fail','relative_error':'abs(V_j-H_j)/abs(H_j)<=0.01 for BOTH receivers; no amplitude/phase tuning, bias subtraction or reference-driven coefficient choice','scope':'even a pass is derivative-case intermediate evidence; no finite-strength/noise/OOD/20Hz/G03 acceptance'},'save_order':['flush callback journal while running; no extra callback-only solve','on GMRES return save raw delta and integer info before report serialization or info stop','recover alpha and full e, save their raw arrays before finite/qualification report; if recovery fails retain delta and exact absent-output status','evaluate and save new raw full augmented residuals, scales and true condensed residual before any post-return JSON verdict; nonfinite raw arrays must not be rejected by an old finite-only save helper before persistence','evaluate numerical policy, then physical candidate traces/reference once; save raw traces/errors before strict reporter; free large factors as soon as recovery finishes','any serializer failure retains raw arrays/status and fails; no recovery or second solve unless root creates a separately bounded job'], 'resources':counts,'proposed_guard':{'seconds':120,'process_memory_bytes':4*1024**3,'job_memory_bytes':5*1024**3,'minimum_fresh_available_physical_bytes':10*1024**3,'active_processes':3,'BLAS_threads':1,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':256*1024**2,'tree_entries':2048,'free_reserve_bytes':512*1024**2,'phase_seconds_caps':{'preflight':5,'D_factor':5,'fresh_A0_factor':80,'one_GMRES':20,'save_verify_receivers':10},'interpretation':'new prospective job proposal, not a cap increase/retry of old90s failed attempt; root must explicitly select it; any phase/whole-job overrun stops'},'historical_resources':{'fresh_A0_LU_seconds':68.17199999999866,'whole_old_failed_job_seconds':84.28100000000268,'peak_job_bytes':3420585984,'all3held_terminated':True,'factor_object_persisted':False,'guarantee':'historical only; no walltime, fill or convergence guarantee'},'pending_assembly':pending,'controls':'reuse final accepted author test_coupled.py overlap/block/circle controls and reviewer evidence; no duplicated controls in this task; no current pass claimed','blockers':['actual coupled outputs/shape/order/scales and final acceptance absent','D factor conditioning and sparse fill/time not measured; exported L+U cap64MiB and one attempt only','fresh A0 factorization dominates cost; its matrix is saved, its factor is not;120s plan has finite declared phases but no timing guarantee','Schur cancellation/old preconditioner convergence for new space unproven; direct full augmented verification is mandatory'],'material_alternative':'If future source review identifies Schur cancellation/poor conditioning as a concrete blocker, root may instead select ONE full-augmented GMRES with upper triangular block preconditioner P=[[A0II,U_I],[0,D]], applied with the same full D and fresh A0 LU. This avoids forming/applying a condensed cancellation but retains exact full blocks and both physical gates. It is not an automatic fallback or second call; it does not remove the expensive fresh A0 cost.','requirements_sha256':requirements,'H01_H15':'preserved','physical_accuracy':'unqualified','G03':'not_run','R03':'not_run','all29':'not_run','tests_or_science_executed':False,'implementation_or_solve_selected':False}
(D/'design.json').write_text(json.dumps(design,indent=2,allow_nan=False),encoding='utf-8')
rows='\n'.join(f'| {a} | `{p}` |' for a,p in aliases.items() if a in ('Ac','A0II','Eh','rEh4_compensated','strict_old_correction_residual','I','B','gB','b8','delta_b8_minus_b4','trace','high_H_saved','beff4_compensated','old_Vh_compensated'))
md=f'''# One prospective global coupled correction

Recommend **one matrix-free condensed Schur GMRES**, with full coupled D factored once and one **fresh** saved-A0II COLAMD LU used only as a left preconditioner. Root must first accept the actual coupled assembly and final source/output pins; no solve is selected here. m<=804/134cells remain bounds, not measured assembly results. Current product490adb3 is parent-recorded; no Git operation was performed.

This job is static only: no tests, numerical imports, array decoding/reduction, source/operator action, factorization, or solve. The new overlap/block/circle controls belong to the author/reviewer; their static source is cited, not replayed or declared passed.

## Exact reusable inputs

Paths below are relative to repository root. `source-manifest.json` gives every used file's current byte count/SHA256 and verifies known input/manifest pins without decoding arrays.

| Role | Exact saved artifact |
|---|---|
{rows}

F8/ell8 are pinned under g03-source8-enrichment-20261023/source-01/. b8/F8 share accepted saved current and one -i omega source factor. Source8 root decision accepts consistency and negative concentration evidence, not integration. Required future U/MQ/KQ/D/F8_Q/ell8_Q/traceQ arrays and their final filenames/hashes must come from the **actual accepted author manifest**, in canonical closure order. They do not exist as accepted inputs yet; this design does not invent them.

Eh and rEh4 come from the same independent audit: `candidate_audit.py` forms Eh=E3+scatter(old_delta), then compensated real/imaginary CSR sums compute(Ac Eh-b4)_I and save both arrays. The audit reached seven comparisons and30raw arrays, then its JSON report failed on a NumPy boolean. Its raw result/exit1 remain failed. Root's separate metadata recovery documents those arrays and receiver failures; it neither reran science nor changed the failed audit/solve status. These raw arrays are reusable diagnostic inputs despite the failed reporting stage, conditional on exact pins/root disposition.

The strict old residual is instead AII*old_delta+r0, saved by the info3 solve. It is only arithmetically consistent with the rounded full Eh; do not treat it as bit-identical or silently substitute it. Old native job is terminal **failed**,78callbacks; the audit's native review completed while its diagnostic process failed. No factor object was serialized: only the old A0II matrix survives.

## One new correction, no old warm-up

Use compensated rEh4 for the exact saved full Eh:

```
r8 = rEh4_compensated - delta_b8_minus_b4[I]
beff8 = beff4_compensated + delta_b8_minus_b4[I]
fbarQ = F8_Q - U_B.T @ gB
S(v) = Ac_II @ v - U_I @ solve_D(U_I.T @ v)
h = -r8 + U_I @ solve_D(ell8_Q)
S delta = h
alpha = solve_D(ell8_Q - U_I.T @ delta)
e = Eh + scatter_I(delta); e[B] = gB exactly
```

`solve_D` is an actual solve with **all** offdiagonals of D=KQ/mu+i omega zeta0 MQ. Never divide elementwise by its diagonal. Ordinary transpose applies to U and physical blocks; GMRES's internal Arnoldi Hermitian dot products stay unchanged. Full U boundary rows are retained. Boundary RHS is `[b8_I-Ac_IB gB; F8_Q-U_B.T gB]`; zero bubble boundary trace does not imply U_B=0.

Build only AcII and sparse U/D views from saved matrices. No rebuilt mesh/CSR, source/primary/reference evaluation, or Ac@Eh warm-up. Saved r8 reuse is RHS construction, **never** a replacement for the final new equation check. The first new global operator action serves GMRES or final residual verification.

Factor D once with sparse COLAMD LU first; stop on warning/singular/nonfinite factor or exported L+U storage>64MiB. m<=804 bounds factor entries bym(m+1), while temporary workspace remains under the whole-process guard. Then factor the pinned A0II once with COLAMD; no factor cache is claimed. Use its fixed lu.solve as GMRES M. Do not form S or the full augmented CSR, invert D, run a tuning preconditioner solve, or retry.

One complex128 GMRES call: zero start,restart40,maxiter3,rtol1e-12,atol0,callback_type=pr_norm,at most120callbacks. Installed SciPy iterative.py:593,705-725,831-852 confirms the unpreconditioned stopping test is distinct from callback/preconditioned values. Record info, true condensed residual and threshold1e-12||h||2, including undefined/zero-RHS handling; do not infer convergence from callbacks.

## Direct NEW full augmented numerical gate

Using the **actual returned** coarse/bubble candidate, independently accumulate complex products with real/imaginary math.fsum:

```
rI = (Ac @ e - b8)[I] + U_I @ alpha
rQ = U.T @ e + D @ alpha - F8_Q
Baug = [[Ac_II,U_I],[U_I.T,D]]
x = [e_I,alpha]; baug = [beff8,fbarQ]
p_i = sum_j abs(Baug_ij)*abs(x_j) + abs(baug_i)
floor_i = 128*eps*p_i
eta = ||[rI,rQ]||inf / (||Baug||inf*||x||inf + ||baug||inf)
```

For norms, use actual augmented absolute row sums, not preconditioner or Schur norms. Retain full U rows in rQ. Also verify the direct boundary-form residual agrees with Baug*x-baug within declared128eps absolute-product scales; boundary-action scales are pinned and new U_B*gB scales must be retained. This is a new coupled-equation check, not a repeat of the old candidate audit.

Freeze policy **before** any future execution: strict info0 remains strict solver status; independently report the unchanged true condensed screen. A positive info may be called `roundoff_limited_candidate` only when every new full augmented row satisfies abs(r_i)<=floor_i and eta<=128eps, with all fields/scales/norms finite. A zero scale requires exact zero residual; undefined denominator fails except an explicitly all-zero equation/candidate case. This label is not strict convergence. Negative info, failed numerical gate or resources stops. Apply the same full augmented verification to info0 candidates. Original info3 remains failed under its original policy.

## Physical gate and persistence

After candidate/numerical outputs are sealed, compute compensated V=t_coarse@e+traceQ@alpha using unchanged tilted circles and turns already applied exactly once in each trace. Cross-check V against saved Vh+t_coarse[:,I]@delta+traceQ@alpha using128eps absolute-product sums. Read the original high H only for evaluation; both complex errors abs(V_j-H_j)/abs(H_j) must be<=0.01. Denominators H and V must exceed128eps times the full coarse+bubble absolute trace-product sum, else undefined/fail. No amplitude/phase tuning, bias subtraction, mesh/mode reselection or reference-driven RHS. A tiny backward eta proves no receiver accuracy.

On GMRES return, **before post-return JSON or info stop**, save raw returned delta and integer info. Then recover/save raw alpha and full e, compute/save raw new residuals/scales and strict condensed residual; only then serialize numerical verdict. Save nonfinite returned arrays as raw evidence before rejecting them—do not reuse a finite-only save helper that discards them. If recovery/resource failure prevents later arrays, retain what exists and mark exact missing outputs. Callback journals are streamed while the solver runs. Save raw receiver/error arrays before metadata conversion; use exact accepted evidence_json for files/stdout and verify readback. Serializer failure remains failure with arrays preserved, not an invitation to rerun.

## Cost, limits and dependency gate

Old fresh A0 LU took68.172s; its full failed stage took84.281s at3,420,585,984B, with3held handles terminated. No old execution is repeated here. Condensed dimension54418 and41complex vectors require35,699,?B by the exact formula54418*41*16 (the exact integer is in design.json). U<=16080,D<=19296structural entries and m<=804 are bounds. Dense m-square complex storage would be10,342,656B; no dense inverse is used. Added local working allowance128MiB and Dfactor export cap64MiB are ceilings, not measured fill/workspace guarantees.

Propose a **new** one-attempt120s job,4GiB/process,5GiB/job, fresh free physical>=10GiB,3held processes,BLAS1 before/after,256MiBartifacts/2048entries,128KiB per pipe,512MiBfree reserve. Frozen phase caps:5spreflight,5sDfactor,80sfreshA0factor,20sGMRES,10ssave/verification/receivers; exact held guard120s also caps the whole job. This is an explicit proposal for genuinely new equations, not an extension/retry of the old90s failure. The old stage stopped before full receiver verification, so its84.281s is not an end-to-end estimate for this work. A stage/total overrun ends the one attempt; no automatic retry/time increase. Timing/convergence are unproven and root may decline this resource proposal.

Actual coupling acceptance, D conditioning, fill and convergence remain unresolved dependencies. If a concrete review finds Schur cancellation/stability unacceptable, one material alternative is a **separately selected** full-augmented GMRES with upper triangular P=[[A0II,U_I],[0,D]], using one full D factor and one fresh A0 factor. It avoids condensed subtraction and retains exact blocks/gates; it does not remove A0's dominant cost. It is not a fallback or second call in this proposal. If the fresh A0 budget itself is infeasible, report that blocker; no evidence supports a cheaper substitute here.

Root must consume accepted final coupled source/control/output manifest and reviewer disposition, replace pending artifact roles with real hashes, and freeze the new runner/policy/resources before selecting execution. Reuse the author's new overlap,2coarse/2bubble boundary and partial-circle controls; do not duplicate them. This worker selects nothing. Full H01-H15 hash {requirements} is preserved; derivative1% success would still leave arbitrary3D material/finite-strength/noise/OOD/20Hz/H12/fullG03/R03/all29 requirements unqualified/not_run.
'''
md=md.replace('35,699,?B by the exact formula54418*41*16 (the exact integer is in design.json)',f"{counts['condensed_41vector_complex128_bytes']:,}B")
(D/'design.md').write_text(md,encoding='utf-8')
(D/'next-task-proposal.md').write_text('Propose A-G03-COUPLED-CORRECTION-20261023-v1 only after root accepts actual coupled assembly. Freeze final coupling artifact roles/hashes, exact same-Eh compensated residual, Ac/A0II/source8/boundary/trace/H pins, one fixed condensed GMRES and prospective full-augmented128eps/physical1% policies from design.md. Root must select the new120s/4GiB/5GiB proposal explicitly. No repeated controls, old warm-up operator, source replay, retry or second solver. Emit raw candidate/new augmented residual and actual receiver outcomes before strict reports; preserve original failures.\n',encoding='utf-8')
(D/'task_plan.md').write_text('# Static coupled-solve design\n\n- Completed: lease, role/transfer/H01-H15 verification.\n- Completed: exact same-field residual and boundary/source/trace provenance pinned.\n- Completed: single prospective solve, full augmented numerical/physical gates and bounded resource/dependency plan.\n- Completed: static metadata/hash checks only; no science/tests/arrays decoded.\n- Root retains actual coupling acceptance and any new solve selection.\n',encoding='utf-8')
(D/'findings.md').write_text('Exact same-field compensated residual is candidate_final_residual_I_Amps.npy from failed audit with later root metadata recovery; strict original correction residual is not a bit-identical substitute. No coarse LU factor persisted. Actual coupled assembly outputs remain pending. Full new augmented equations with U boundary rows must be checked after the new candidate, irrespective of warm-start reuse or GMRES status.\n',encoding='utf-8')
(D/'progress.md').write_text('Static design and byte pins sealed. No tests, numerical imports, array decoding/reduction, operators, source, factorization or solve executed. Root selection pending by scope.\n',encoding='utf-8')
public={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ('lease.private.json','manifest.json','native-completion.json')}
manifest={'work_id':design['work_id'],'status':'static_design_for_root_selection','files':public,'tests':0,'science_imports':0,'array_payload_decodes':0,'operator_actions':0,'factorizations':0,'solves':0,'private_tokens_excluded':True,'requirements_sha256':requirements}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
assert all(pin(D/n)==v for n,v in public.items())
print(json.dumps({'status':'static_design_sealed','input_source_pins':len(pins),'public_files':len(public),'manifest_sha256':pin(D/'manifest.json')['sha256'],'array_decodes':0,'numerical_calls':0,'root_selection_required':True}))
