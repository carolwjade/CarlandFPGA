Static design and byte pins sealed. No tests, numerical imports, array decoding/reduction, operators, source, factorization or solve executed. Root selection pending by scope.
