import base64, concurrent.futures, hashlib, json, pathlib, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent
HEAD = '94571d2cd9a68bd030c878c406f19a1be6ec53d7'
SOURCE = 'a489b3dbe1b5d77196a6fc5b7da418f359020818'
OLD = 'cd007dc8190b7c2d911d2be6c1136aabab3518e5'
OP = 'handoffs/b/B-DEEPEYE-SAMPLE-SCAN-TOOLCHECK-20261022-22/'
GH = r'C:\Program Files\GitHub CLI\gh.exe'
def sha(b): return hashlib.sha256(b).hexdigest()
def api(endpoint, name, raw=False):
    argv = [GH, 'api', endpoint]
    if raw: argv += ['-H', 'Accept: application/vnd.github.raw+json']
    dest=ROOT/'transport-run2'/name
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        p = subprocess.run(argv, capture_output=True, timeout=35)
    except subprocess.TimeoutExpired as e:
        dest.with_suffix('.stdout').write_bytes(e.stdout or b'')
        dest.with_suffix('.stderr').write_bytes(e.stderr or b'')
        dest.with_suffix('.process.json').write_text(json.dumps({'argv':argv,'timeout_seconds':35,'error':'TimeoutExpired'},indent=2))
        raise
    dest.with_suffix('.stdout').write_bytes(p.stdout)
    dest.with_suffix('.stderr').write_bytes(p.stderr)
    dest.with_suffix('.process.json').write_text(json.dumps({'argv':argv,'exit':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)},indent=2))
    if p.returncode: raise RuntimeError(f'{endpoint}: exit {p.returncode}')
    return p.stdout
def get(path, ref, label, expected=None):
    endpoint=f'repos/carolwjade/CarlandFPGA/contents/{path}?ref={ref}'
    meta=json.loads(api(endpoint,label))
    data=base64.b64decode(meta['content']) if meta.get('encoding')=='base64' else api(endpoint,label+'-raw',True)
    blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert blob==meta['sha'], (path,'blob mismatch')
    if expected: assert len(data)==expected['size'] and sha(data)==expected['sha256'],(path,'manifest mismatch')
    dest=ROOT/('snapshot' if ref==HEAD else 'references'/pathlib.Path(ref))/path
    dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
    return {'path':path,'ref':ref,'size':len(data),'sha256':sha(data),'git_blob_sha':blob}
def main():
    records=[]; failures=[]
    # Preserve the first remote timeout. Reuse parent's successful fixed-ref API
    # transport for initial input rather than repeatedly retrying that read.
    for i,p in enumerate([OP+'manifest.json',OP+'input.json']):
        parent=ROOT.parent/'b-op22-source-20261022'
        meta=json.loads((parent/f'api-{i}.json').read_bytes())
        data=base64.b64decode(meta['content'])
        blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        assert blob==meta['sha'] and meta['url'].endswith('ref='+HEAD)
        dest=ROOT/'snapshot'/p; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
        records.append({'path':p,'ref':HEAD,'size':len(data),'sha256':sha(data),'git_blob_sha':blob,'origin':'parent saved fixed-ref API, independently decoded and hashed'})
    m=json.loads((ROOT/'snapshot'/OP/'manifest.json').read_bytes())
    assert sha((ROOT/'snapshot'/OP/'manifest.json').read_bytes())=='48fa2b564f85a5db2678918f1ef930559d840e980c2a7452ef6a8a5185d97843'
    assert m['request_hash']==sha(json.dumps(m['request'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())=='b86a1d71eb1b13159c1576828d8050670850f2737e5f71325779dbb0d7e9e99f'
    assert m['request']['code_commit']==SOURCE
    assert set(m['artifacts'])==set(m['files']) and len(m['files'])==88
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        jobs={pool.submit(get,p,HEAD,f'artifact-{i:03}',e):p for i,(p,e) in enumerate(m['files'].items())}
        for future in concurrent.futures.as_completed(jobs):
            try: records.append(future.result())
            except Exception as e: failures.append({'path':jobs[future],'error':repr(e)})
    # Exact source and original runner plus published immutable contract.
    for i,(p,ref) in enumerate([(p,SOURCE) for p in ['competition/deepeye/tools/acquisition/run_sample_scan_capture.py','competition/deepeye/tests/acquisition/test_sample_scan_toolcheck.py']]+[('competition/deepeye/tools/acquisition/run_sample_scan_capture.py',OLD)]+[(f'docs/competition/deepeye-2026/immutable_scope.{ext}',HEAD) for ext in ['json','md']]):
        try: records.append(get(p,ref,f'reference-{i}'))
        except Exception as e: failures.append({'path':p,'ref':ref,'error':repr(e)})
    (ROOT/'source-manifest.json').write_text(json.dumps({'head':HEAD,'source':SOURCE,'old':OLD,'records':records,'failures':failures},indent=2))
    print(json.dumps({'files':len(records),'manifest_artifacts':88,'failures':failures}))
    return bool(failures)
if __name__=='__main__': sys.exit(main())
