import datetime, hashlib, json, pathlib, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
argv=[sys.executable,'-B','-X','utf8',str(root/'verify_evidence.py')]
p=subprocess.run(argv,cwd=root,capture_output=True,timeout=30)
(root/'verification.stdout.bin').write_bytes(p.stdout)
(root/'verification.stderr.bin').write_bytes(p.stderr)
sha=lambda b:hashlib.sha256(b).hexdigest()
record={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'cwd':str(root),'python_version':sys.version,'timeout_seconds':30,'exit':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'checker_sha256':sha((root/'verify_evidence.py').read_bytes()),'scope':'byte/AST/saved-evidence audit; no submitted source imports or test reruns'}
(root/'verification.process.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2));sys.exit(p.returncode)
