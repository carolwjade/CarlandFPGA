import base64, hashlib, json
from retrieve import ROOT, HEAD, OLD, OP, api, sha

manifest=json.loads((ROOT/'snapshot'/OP/'manifest.json').read_bytes())
path=next(p for p in manifest['files'] if p.endswith('original-entry-01.tar.gz'))
meta=json.loads((ROOT/'transport-run2/artifact-023.stdout').read_bytes())
data=json.loads(api(f"repos/carolwjade/CarlandFPGA/git/blobs/{meta['sha']}",'supplement-blob'))
raw=base64.b64decode(data['content'])
expected=manifest['files'][path]
assert sha(raw)==expected['sha256'] and len(raw)==expected['size']
assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==meta['sha']==data['sha']
(ROOT/'snapshot'/path).write_bytes(raw)
report=json.loads((ROOT/'source-manifest.json').read_bytes())
report['records'].append({'path':path,'ref':HEAD,'size':len(raw),'sha256':sha(raw),'git_blob_sha':meta['sha'],'origin':'fixed-head contents metadata followed by Git blob API'})
report['preserved_failures']=report.pop('failures');report['failures']=[]
(ROOT/'source-manifest.json').write_text(json.dumps(report,indent=2))
compare=json.loads(api(f'repos/carolwjade/CarlandFPGA/compare/{OLD}...{HEAD}','supplement-compare'))
(ROOT/'compare.json').write_text(json.dumps(compare,indent=2))
print(json.dumps({'recovered':path,'bytes':len(raw),'compare_files':len(compare.get('files',[])),'status':compare.get('status')}))
