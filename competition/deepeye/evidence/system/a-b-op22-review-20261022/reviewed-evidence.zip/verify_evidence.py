"""Read-only byte, structure and saved-result audit. Never imports submitted code."""
import ast, difflib, hashlib, json, pathlib, tarfile
from retrieve import ROOT, HEAD, SOURCE, OLD, OP, sha

S=ROOT/'snapshot'
E='competition/deepeye/evidence/acquisition/sample-scan-toolcheck-20261022-22/'
M=S/E/'main'
def load(p): return json.loads(p.read_bytes())
def canonical(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def verify():
    manifest=load(S/OP/'manifest.json');inp=load(S/OP/'input.json');source=load(ROOT/'source-manifest.json')
    assert not source['failures']
    assert manifest['request']==inp['request'] and manifest['artifacts']==inp['artifacts'] and manifest['stages']==inp['stages']
    assert sha(canonical(manifest['request']))==manifest['request_hash']=='b86a1d71eb1b13159c1576828d8050670850f2737e5f71325779dbb0d7e9e99f'
    assert sha((S/OP/'manifest.json').read_bytes())=='48fa2b564f85a5db2678918f1ef930559d840e980c2a7452ef6a8a5185d97843'
    records={r['path']:r for r in source['records'] if r['ref']==HEAD}
    for p,entry in manifest['files'].items():
        b=(S/p).read_bytes();assert len(b)==entry['size'] and sha(b)==entry['sha256']
        assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==records[p]['git_blob_sha']
    contract=load(S/'docs/competition/deepeye-2026/immutable_scope.json')
    assert sha(canonical(contract['requirements']))=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    assert [r['id'] for r in contract['requirements']]==[f'H{i:02}' for i in range(1,16)]
    runner='competition/deepeye/tools/acquisition/run_sample_scan_capture.py'
    test='competition/deepeye/tests/acquisition/test_sample_scan_toolcheck.py'
    for p in [runner,test]: assert (ROOT/'references'/SOURCE/p).read_bytes()==(S/p).read_bytes()
    old=(ROOT/'references'/OLD/runner).read_bytes();new=(S/runner).read_bytes()
    ot,nt=ast.parse(old),ast.parse(new)
    funcs=lambda t:{n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    of,nf=funcs(ot),funcs(nt);dump=lambda n:ast.dump(n,include_attributes=False)
    changed=[k for k in of if dump(of[k])!=dump(nf[k])]
    unchanged=[k for k in of if dump(of[k])==dump(nf[k])]
    assert changed==['_tool_version'] and len(unchanged)==27
    assert set(nf)-set(of)=={'_version_failure_reasons','_version_output_bytes'}
    assert [dump(n) for n in ot.body if not isinstance(n,ast.FunctionDef)]==[dump(n) for n in nt.body if not isinstance(n,ast.FunctionDef)]
    for k in unchanged: assert ast.get_source_segment(old.decode(),of[k])==ast.get_source_segment(new.decode(),nf[k])
    (ROOT/'runner.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile=OLD,tofile=HEAD)))
    compare=load(ROOT/'compare.json');assert compare['status']=='ahead' and compare['base_commit']['sha']==OLD
    assert compare['commits'][-1]['sha']==HEAD and SOURCE in [c['sha'] for c in compare['commits']]
    altered=[f['filename'] for f in compare['files'] if f['status']!='added']
    assert altered==[runner] and len(compare['files'])==90
    members={};bundle_summary=[]
    for bundle in load(M/'BUNDLE_MANIFEST.json')['bundles']:
        ap=S/bundle['archive'].replace('\\','/');ip=S/bundle['index'].replace('\\','/')
        assert sha(ap.read_bytes())==bundle['sha256'] and sha(ip.read_bytes())==bundle['index_sha256']
        index=load(ip); assert index['archive_sha256']==sha(ap.read_bytes())
        with tarfile.open(ap,'r:gz') as tf:
            seen=set();total=0
            for member in tf:
                assert member.isfile() and member.name not in seen
                assert not pathlib.PurePosixPath(member.name).is_absolute() and '..' not in pathlib.PurePosixPath(member.name).parts and ':' not in member.name
                b=tf.extractfile(member).read();entry=index['files'][member.name]
                assert member.size==len(b)==entry['bytes'] and sha(b)==entry['sha256']
                assert member.name not in members;members[member.name]=b;seen.add(member.name);total+=len(b)
            assert seen==set(index['files']) and len(seen)==bundle['raw_file_count'] and total==bundle['raw_bytes']
        bundle_summary.append({'archive':ap.name,'members':len(seen),'bytes':total,'sha256':bundle['sha256']})
    j=lambda key:json.loads(members[key])
    invocations=0;entry_processes=0
    for name,b in members.items():
        if not name.startswith(('main/final-direct-01/','main/final-entry-01/')):continue
        if name.endswith('.invocation.json'):
            r=json.loads(b);parent=pathlib.PurePosixPath(name).parent
            for stream in ['stdout','stderr']:
                assert sha(members[str(parent/r[f'{stream}_path'])])==r[f'{stream}_sha256']
            invocations+=1
        if name.startswith('main/final-entry-01/') and name.endswith('.process.json'):
            r=json.loads(b);stem=name[:-len('.process.json')]
            for stream in ['stdout','stderr']:assert sha(members[stem+f'.{stream}.bin'])==r[f'{stream}_sha256']
            entry_processes+=1
    assert invocations==640 and entry_processes==136
    matrix=load(M/'LITERAL_MATRIX.json')['cases'];assert len(matrix)==136
    direct=j('main/final-direct-01/RESULT.json');entry=j('main/final-entry-01/RESULT.json')
    assert direct['cases']==136 and not direct['mismatches'] and not direct['unhandled']
    assert entry['processes']==136 and not entry['mismatches']
    for result in [direct,entry]:assert result['source_sha256']==sha(new)
    assert [r['id'] for r in direct['records']]==[r['id'] for r in matrix]==[r['id'] for r in entry['records']]
    bad_calls=good_calls=0
    for row,dr,er in zip(matrix,direct['records'],entry['records']):
        ident=row['id'];expected=row['expected_ok'];assert dr['actual_ok']==expected and dr['agrees'] and er['agrees']
        summary=j(f'main/final-entry-01/{ident}/results/summary.json')
        assert summary['ok']==expected
        calls=j(f'main/final-entry-01/{ident}/seam_calls.json');casecalls=[c for c in calls if c['kind']=='synthetic-case']
        assert len(casecalls)==(8 if expected else 0)==er['case_calls']
        assert (er['exit']==0)==expected
        if not expected:assert summary['results']=={} and summary['reasons'];bad_calls+=len(casecalls)
        else:good_calls+=len(casecalls)
        inv=j(f"main/final-direct-01/{ident}/tool-check/{row['tool']}.invocation.json")
        for stream in ['stdout','stderr']:
            # The inspected seam raises bare launch OSError/FileNotFoundError:
            # those exceptions have no stdout/stderr. TimeoutExpired has both.
            expected_bytes=b'' if row.get('exception') in ['OSError','FileNotFoundError'] else row[stream].encode()
            assert members[f"main/final-direct-01/{ident}/tool-check/{row['tool']}.{stream}.bin"]==expected_bytes,(ident,stream)
        if row.get('exception'):assert inv['exception_type']==row['exception']
    assert bad_calls==0 and good_calls==96
    original=j('main/original-direct-01/RESULT.json');original_entry=j('main/original-entry-01/RESULT.json')
    assert original['source_sha256']==sha(old) and original_entry['source_sha256']==sha(old)
    assert len(original['mismatches'])==108 and len(original['unhandled'])==6 and len(original_entry['mismatches'])==114
    author=j('author/MANIFEST.json')
    for rec in author['author_evidence_files']:
        rel=rec['path'][len(E):];b=members[rel];assert len(b)==rec['bytes'] and sha(b)==rec['sha256']
    for p in list((M/'main-processes').glob('*.process.json'))+list((M/'real-version-01').glob('*.process.json')):
        r=load(p);stem=p.name[:-len('.process.json')]
        for stream in ['stdout','stderr']:assert sha((p.parent/(stem+f'.{stream}.bin')).read_bytes())==r[f'{stream}_sha256']
        assert r['exit']==0
    unitlog=(M/'main-processes/unit.stderr.bin').read_bytes();assert b'Ran 29 tests' in unitlog and b'OK' in unitlog
    regression=load(M/'regression-01/RESULT.json');assert regression['cases']==43 and not regression['mismatches']
    raw=load(M/'RAW_EVIDENCE_REVIEW.json')
    for rec in raw['persisted_invocations']:assert sha(members['main/'+rec['path']])==rec['sha256']
    report={'scope':'independent saved-evidence and static source audit only; no submitted code/test execution','head':HEAD,'source':SOURCE,'old':OLD,'manifest_artifacts_verified':88,'api_git_blob_verified':88,'request_hash':manifest['request_hash'],'contract_requirements_sha256':contract['requirements_sha256'],'old_functions_unchanged_source_and_AST':unchanged,'changed_old_functions':changed,'added_functions':sorted(set(nf)-set(of)),'old_global_AST_unchanged':True,'compare_files':90,'modified_existing_paths':altered,'source_commit_identical_to_head':True,'bundles':bundle_summary,'total_archive_members':sum(b['members'] for b in bundle_summary),'final_invocation_stream_pairs_verified':invocations,'entry_process_stream_pairs_verified':entry_processes,'saved_direct_cases':136,'saved_entry_cases':136,'saved_matrix_positive':sum(r['expected_ok'] for r in matrix),'saved_matrix_negative':sum(not r['expected_ok'] for r in matrix),'saved_negative_case_calls':bad_calls,'saved_positive_synthetic_case_calls':good_calls,'saved_regression_controls':43,'saved_unit_tests':29,'saved_actual_version_queries':2,'original_false_accepts':108,'original_unhandled_exceptions':6,'original_entry_expectation_failures':114,'new_tests_executed':0,'verification_errors':[]}
    (ROOT/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':verify()
