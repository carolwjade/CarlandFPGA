"""Root: read saved geometry only, without numpy, operator action or test replay."""
import ast
import array
import asyncio
import hashlib
import json
import math
import struct
import sys
import time
from pathlib import Path

D=Path(__file__).resolve().parent; ROOT=D.parents[2]; P=D.parent
sys.path.insert(0,str(ROOT))
from fpga_mesh.child_control import LocalControlFileClient
from fpga_mesh.project_cli import discovery

def save(n,v):
    with (D/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
pins={}
def read_npy(p):
    b=p.read_bytes();pins[p.relative_to(ROOT).as_posix()]=pin(p)
    assert b[:8]==b'\x93NUMPY\x01\x00'
    n=struct.unpack('<H',b[8:10])[0];h=ast.literal_eval(b[10:10+n].decode('latin1'))
    assert h['descr']=='<f8' and not h['fortran_order']
    a=array.array('d');a.frombytes(b[10+n:]);assert len(a)==math.prod(h['shape'])
    return a,h['shape']

job=json.loads((D/'original-native-result.json').read_bytes())
safe={k:job.get(k) for k in ['job_id','work_id','native_agent_id','status','terminal','stale','result','error']}
assert safe['status']=='completed' and safe['terminal'] and not safe['stale']
R=P/'g03-hodge-independent-20261023'
assert pin(R/'manifest-final.json')['sha256']=='79b37d46355edc6af112865e19620b0ab00320462637802ef53cd759ecdf7901'
mf=json.loads((R/'manifest-final.json').read_bytes())
for name,rec in mf['files'].items():assert pin(R/name)==rec,name
assert not (P/'finalize_hodge_review_unused.txt').exists()
started=time.monotonic();L=P/'g03-l5-propagation-z-refinement-20261021'
spec=json.loads((L/'assignment.json').read_bytes()); nominal=[spec['level']['x_nodes_m'],spec['level']['x_nodes_m'],spec['z_nodes_m']]
starts,shape=read_npy(L/'controls-01/edge_starts_m.npy');ends,shape2=read_npy(L/'controls-01/edge_ends_m.npy');assert shape==shape2==(63250,3)
eps=sys.float_info.epsilon;axis_records=[];actual=[]
for axis,ns in enumerate(nominal):
    obs=sorted(set(starts[axis::3])|set(ends[axis::3]));assert len(obs)==len(ns)
    widths=[b-a for a,b in zip(ns,ns[1:])];cs=ns[0];reconstructed=[cs]
    for h in widths:cs+=h;reconstructed.append(cs)
    assert obs==reconstructed,(axis,'not exactly the recorded cumulative width geometry')
    # Difference/subtraction, positive cumulative sum, origin addition. Bound
    # uses eps (twice unit roundoff) and extra operations conservatively.
    n=len(widths)+3;gamma=n*eps/(1-n*eps)
    bound=gamma*(abs(ns[0])+sum(abs(h) for h in widths)+max(abs(v) for v in ns))
    errors=[abs(a-b) for a,b in zip(obs,ns)];mingap=min(widths)
    assert max(errors)<=bound and 2*bound<mingap
    axis_records.append({'axis':axis,'node_count':len(ns),'non_bitwise_node_count':sum(a!=b for a,b in zip(obs,ns)),
        'max_abs_coordinate_difference_m':max(errors),'derived_cumulative_arithmetic_bound_m':bound,
        'minimum_node_gap_m':mingap,'exact_cumulative_reconstruction':True,
        'max_cell_width_difference_m':max(abs((obs[i+1]-obs[i])-widths[i]) for i in range(len(widths))),
        'actual_nodes_m':obs,'nominal_nodes_m':ns})
    actual.append(obs)
# Independent x-fast tensor enumeration; tests all global endpoint identity
# without relying on production cell map or fuzzy coordinate search.
shapes=[(24,25,35),(25,24,35),(25,25,34)];offset=0
for axis,sh in enumerate(shapes):
    for k in range(sh[2]):
        for j in range(sh[1]):
            for i in range(sh[0]):
                ijk=(i,j,k);gid=offset+i+sh[0]*(j+sh[1]*k)
                for d in range(3):
                    assert starts[3*gid+d]==actual[d][ijk[d]]
                    assert ends[3*gid+d]==actual[d][ijk[d]+(d==axis)]
    offset+=math.prod(sh)
assert offset==63250
result={'status':'geometry_discrepancy_explained','method':'stdlib saved NPY reads; exact reconstruction cumsum([origin,*diff(nominal)]); independently enumerated every global edge',
    'axis_records':axis_records,'all_global_edge_endpoints_exact_actual_nodes':True,
    'reason':'Original audit compared TensorMesh cumulative floating nodes bitwise to nominal assignment nodes; stored endpoints match exact cumulative construction.',
    'selected_continuation':'New audit successor uses exact actual mesh node geometry for endpoint/I-B/row selection, keeps nominal bounds for operator polynomial widths. Must quantify gap and preserve exact integer topology checks.',
    'old_tests_rerun':0,'operator_actions':0,'PDE_solves':0,'prior_manifest_files_verified':len(mf['files']),
    'elapsed_seconds':time.monotonic()-started,'inputs':pins}
save('result.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['axis_records','inputs']}))
print(json.dumps([{k:v for k,v in r.items() if not k.endswith('nodes_m')} for r in axis_records]))
