"""Read-only source/evidence verification; no numerical worker or solver."""
import difflib,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent
O=P/'g03-consistent-hodge-action-20261022';S=P/'g03-consistent-hodge-json-continuation-20261023'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(name,x):
    with (D/name).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
sources={}
def verify_table(base,table):
    for n,v in table.items():
        q=base/n;actual=pin(q);assert actual==v,(str(q),'pin mismatch');sources[q.relative_to(ROOT).as_posix()]=actual
    return len(table)
out={}
for folder,expected in [(O,'d0f21a8b11ffce5ad0dc8452345a8ae37203532b57537c089e296f2235273e35'),(S,'7c4d1aa73fe6099fa8416f5744a08ec660b0a9358ee37430635704e37d9bbcb8')]:
    assert pin(folder/'manifest.json')['sha256']==expected
    out[folder.name]={'manifest_entries_verified':verify_table(folder,read(folder/'manifest.json')['files']),
        'input_entries_verified':verify_table(ROOT,read(folder/'input-pins.json')['files']),
        'frozen_entries_verified':verify_table(ROOT,read(folder/'frozen-source-pins.json'))}
    sources[(folder/'manifest.json').relative_to(ROOT).as_posix()]=pin(folder/'manifest.json')
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
h=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804' and len(scope['requirements'])==15
transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
assert transfer['status']=='active' and transfer['director_generation']==2
out['scope']={'requirements_sha256':h,'count':15,'transfer_status':transfer['status'],'director_generation':2}
old=(O/'hodge_action.py').read_text(encoding='utf-8');new=(S/'hodge_action.py').read_text(encoding='utf-8')
assert old.replace("assignment['level']['z_nodes_m']","assignment['z_nodes_m']")==new
out['delta']={'only_normalized_text_change':"assignment['level']['z_nodes_m'] -> assignment['z_nodes_m']",
              'unchanged_reused_sources':[n for n in ['hodge_kernel.py','test_hodge.py','hodge_worker.py'] if pin(O/n)==pin(S/n)]}
assert len(out['delta']['unchanged_reused_sources'])==3
with (D/'verified-scientific-delta.patch').open('x',encoding='utf-8') as f:f.write(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original/hodge_action.py',tofile='successor/hodge_action.py')))
stages=[]
for folder,modes in [(O,['red','controls','action']),(S,['action'])]:
    for mode in modes:
        q=folder/(mode+'-01');t=read(q/'terminal.json');s=read(q/'started.json');rb=read(q/'input-readback.json')
        assert t['all_processes_terminated'] and t['active_processes_final']==0
        assert len(t['held_members'])==3 and all(v['signaled'] and v['wait_result']==0 for v in t['held_members'])
        assert rb['unchanged'] and rb['before']==rb['after']
        for stream in ['stdout','stderr']:assert pin(q/(stream+'.txt'))==t['logs'][stream]
        if (q/'result.json').exists():assert json.loads((q/'stdout.txt').read_text())==read(q/'result.json')
        assert s['budget']['seconds']==30 and s['readback_limits']['process_memory_bytes']==512*1024**2 and s['readback_limits']['job_memory_bytes']==1024**3
        stages.append({'directory':q.relative_to(ROOT).as_posix(),'terminal':t,'budget':s['budget'],'argv':s['argv'],'input_readback_unchanged':True})
out['stages']=stages
assert read(O/'action-01/failure.json')['type']=='KeyError'
assert not list((O/'action-01').glob('*.npy')) and not (O/'action-01/pre-action.json').exists()
out['failed_boundary']={'original_KeyError_z_nodes_m':True,'no_saved_arrays_or_pre_action':True,'source_first_array_load_after_failure':True}
out['checks_reused_not_rerun']={'analytic':len(read(O/'controls-01/result.json')['checks']),'negative':len(read(O/'controls-01/result.json')['negative_cases']),'energy':len(read(O/'controls-01/result.json')['energies'])}
out['new_calculations_in_this_script']=0
save('source-pins.json',sources);save('source-audit.json',out)
print(json.dumps({'verified_source_count':len(sources),'manifests':{k:v for k,v in out.items() if k in (O.name,S.name)},'scope':out['scope'],'reused':out['checks_reused_not_rerun'],'all_four_stages_held_terminal':True}))
