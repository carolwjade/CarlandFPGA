"""One attempt; reuse existing held Win32 guard; no scientific work here."""
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
before={n:pin(ROOT/n) for n in read(D/'source-pins.json')};assert before==read(D/'source-pins.json')
own={n:pin(D/n) for n in ['array_audit.py','run_audit.py','provenance.py','source-pins.json','source-audit.json']};save(D/'audit-source-pins.json',own)
support=D.parent/'r02-amd-wheel-acquisition-20261021';assert pin(support/'win_job.py')['sha256']=='c997e69b7439776fdaf63cd3dc8235e3448ef26556e69a980b2d9e9315610f59'
sys.path.insert(0,str(support));from win_job import run_bounded,process_identity
stage=D/'audit-01';py=ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'
env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),'PATH':'','TEMP':str(stage),'TMP':str(stage),'TMPDIR':str(stage),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',**{k:'1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS']}}
budget={'seconds':30,'active_processes':3,'process_memory_bytes':512*1024**2,'job_memory_bytes':1024**3,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':64*1024**2,'tree_entries':1024,'free_reserve_bytes':512*1024**2}
granted=False
def tick(job,pids):
    global granted
    if (stage/'hello.json').exists() and not granted:
        h=read(stage/'hello.json');assert h['pid'] in pids
        save(stage/'grant.pending.json',{'worker':process_identity(h['pid'],job),'mode':'independent-array-audit'});os.replace(stage/'grant.pending.json',stage/'grant.json');granted=True
argv=[str(py),'-I','-B','-X','utf8',str(D/'array_audit.py'),str(stage)]
r=run_bounded(argv,env,D,stage,budget,[D],on_tick=tick)
after={n:pin(ROOT/n) for n in before};after_own={n:pin(D/n) for n in own}
save(D/'audit-input-readback.json',{'prior_source_pins_unchanged':before==after,'audit_source_pins_unchanged':own==after_own,'before':before,'after':after,'own_before':own,'own_after':after_own})
assert before==after and own==after_own
print(json.dumps({k:r.get(k) for k in ['status','exit_code','stop_reason','seconds','peak_job_memory_bytes','all_processes_terminated','held_members']}))
raise SystemExit(r['exit_code'] if r['exit_code'] is not None else 125)
