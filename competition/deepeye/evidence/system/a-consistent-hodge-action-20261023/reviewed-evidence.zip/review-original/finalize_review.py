"""Add static proposal review; preserve original seal and failure unchanged."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(n,x):
    with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
original=read(D/'manifest.json');assert all(pin(D/n)==v for n,v in original['files'].items())
assert pin(D/'manifest.json')['sha256']=='05cfc570cf515bfccf3c2e9de968b9a2f7aa88c7ad95c06faece9c9eab0d015c'
design=D.parent/'g03-hodge-solve-design-20261023/design_candidate.md'
scipy=ROOT/'.local/deepeye-fdem-validation-20261020/Lib/site-packages/scipy/sparse/linalg/_isolve/iterative.py'
assert pin(scipy)['sha256']=='b467009e4c8853579bd8966002a017b761d4a1979df6eb0b8a62114b3ddab848'
incident=ROOT/'.planning/deepeye-resume-20261018/finalize_hodge_review_unused.txt';assert not incident.exists()
save('review-supplement.json',{'work_id':'A-G03-HODGE-INDEPENDENT-20261023-v1','original_review_and_failure_preserved':True,'original_manifest':pin(D/'manifest.json'),'static_design_reference':{design.relative_to(ROOT).as_posix():pin(design),scipy.relative_to(ROOT).as_posix():pin(scipy)},'addendum':'solve-design-addendum.md','solver_executed':False,'additional_array_audit_executed':False,'new_decisions_made':False,'scope_incident':{'path':incident.relative_to(ROOT).as_posix(),'action':'accidentally created one unused new text file outside ownership; immediately deleted that exact new file','existing_files_modified':False,'final_path_absent':True},'limitations':'Original independent array audit failed and no retry was authorized in this job. Root handles a separate minimal continuation.'})
excluded={'lease.private.json','manifest-final.json','native-completion.json','native-result.txt','final-verification.json'}
files={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in excluded and p.suffix!='.pyc'}
save('manifest-final.json',{'work_id':'A-G03-HODGE-INDEPENDENT-20261023-v1','files':files,'excluded_private_and_post_seal_records':sorted(excluded),'original_manifest_preserved':True})
manifest=read(D/'manifest-final.json');assert all(pin(D/n)==v for n,v in manifest['files'].items())
src=read(D/'source-pins.json');assert all(pin(ROOT/n)==v for n,v in src.items())
save('final-verification.json',{'status':'verified','manifest':pin(D/'manifest-final.json'),'entries':len(files),'original_manifest_entries_unchanged':len(original['files']),'prior_pins_unchanged':len(src),'audit_attempts':1,'audit_exit':read(D/'audit-01/terminal.json')['exit_code'],'all_held_signaled':all(h['signaled'] for h in read(D/'audit-01/terminal.json')['held_members']),'incident_path_absent':not incident.exists()})
print(json.dumps(read(D/'final-verification.json')))
