# Independent saved-array audit continuation passed

Work `A-G03-HODGE-INDEPENDENT-CONTINUATION-20261023-v1`, native job `child-1538fe361ea740fdbd8e2f4637d14c29`, agent `/root/g03_hodge_independent_20261023`. This new lease returned execution_allowed=true before project operations. Only this successor directory was written. Root retains acceptance and any subsequent solve.

The single authorized audit completed all previously unexecuted checks and all twelve selected polynomial-row comparisons. The original failed audit, source review, static solve-design addendum and manifests remain unchanged. No old local control/test, production full-field action or solve was replayed.

## Exact geometry correction and preserved mathematics

Installed `discretize/base/base_tensor_mesh.py` at SHA256 `56fb85078a2b42184d4b17ec57fa484592d35c20beb76ecd339b50db4edb2b00` constructs nodes as `np.r_[origin,h].cumsum()`. The source was read directly at node properties 174/196/218. Reconstructing `h=diff(nominal)` with that operation order gives the saved endpoints exactly. The successor independently reproduced root's exact actual-node arrays. X/Y nodes equal nominal nodes bitwise; two Z nodes differ by at most `3.469446951953614e-18` m. No fuzzy coordinate match or relaxed tolerance was introduced.

`audit-exact-diff.patch` records five targeted coordinate/output substitutions. The exact bounds-vs-nominal assertion remains. Local endpoint geometry, geometric I/B selection and sampled-edge coordinate lookup now use actual cumulative nodes. Polynomial moments still use nominal node differences, exactly matching the production operator's saved nominal bounds. The Fraction polynomial oracle, curls, twelve row locations and predeclared 128eps summation bounds are unchanged. `coordinate-review.md` records inspection of every later coordinate comparison before the attempt. Launcher delta only rebinds its own source pin list to the new directory.

## Actual coverage

* All19,584cell IDs/bounds, positive local orientation, 12local edges/cell and 63,250unique covered global edges match exact integer topology and actual endpoint geometry.
* Geometric tangential-boundary reconstruction exactly matches saved I=54,418 and B=8,832 in saved order. The full S3 field restricted to B equals saved S2 gB bitwise.
* Electric+curl equals combined action, scales add, cancellation arrays match, and all full-to-I restrictions match bitwise.
* Three saved residuals add exactly to the stored old residual; their absolute scales match; old residual plus saved delta[I] and corresponding scales exactly reproduce the saved alternative residual.
* All five published summaries were recomputed from the saved arrays and match exactly. This is saved-array arithmetic, not an old operator action.
* Twelve independent row comparisons passed: IDs `[0, 10500, 900, 20999, 21000, 31512, 21912, 41999, 42000, 52937, 42937, 63249]` across three axes, both boundaries, interior and nonuniform Z regions. Each row uses one or four adjacent cells and12columns/cell, at most48local contributions per component. The script integrates normalized-coordinate monomials exactly with Fractions, physical nominal-width derivatives, and independent face-center lumped values. It imports no production kernel and forms no global matrix/action.

Maximum row discrepancies are electric `2.329490996569391e-21` and curl `2.0884646120675243e-15` A m/s; scale discrepancies are `3.3881317890172014e-21` and `2.842170943040401e-14`. Every individual discrepancy is below its unchanged row-specific explicit-summation bound. Max error/bound ratios are `{'electric': 0.0019478702624529808, 'curl': 0.000693802237086806, 'electric_scale': 0.003621761202185049, 'curl_scale': 0.007529031619537843}`. These comparisons cover twelve deterministic rows, not an exhaustive independent full action.

The independently checked saved combined interior infinity norm is `2.4713203812440533e-4` A m/s; consistent residual is `2.471320380026613e-4` A m/s. The saved operator difference is resolved at its explicit arithmetic scales. It gives no receiver improvement guarantee and no physical1%qualification; no new receiver response was computed.

## Runtime and artifact evidence

The existing unmodified held Win32 guard enforced512MiB/process,1GiB/job,<=3processes,64MiBevidence and a30s sampled threshold. Actual terminal: exit0, no stop reason, `0.656`s guarded elapsed, `48,967,680`B peak job memory. Scientific worker elapsed `0.375`s. BLAS=1 was checked before/after work. All3retained process handles signaled exit0; active job count is0. Stderr is empty; raw stdout parses exactly to result.json. Actual argv/environment, applied limits, interpreter and process identity are in audit-01/started.json/grant.json/terminal.json.

All163prior/input/source pins and the audit's own source pins remained unchanged before/after. All26loaded saved arrays were hash-checked and finite. Source pins include the original failed audit/terminal and manifest, root's geometry diagnosis including failed exploratory records, and the installed node-construction implementation. No prior file or source was edited.

R1 from the original review is now addressed within this bounded coverage: the failure was a coordinate-representation mismatch in that audit, and exact cumulative-node checks pass. The original failure remains factual and preserved. No confirmed product mapping/formula defect was found by these checks. R2 remains: explicit scales and arithmetic identities do not certify upstream residual generation, discretization error, conditioning or physical receiver accuracy. Prior static solve-design/resource considerations remain reference material; no further design review or solver selection was performed here.

H01-H15 remain pinned under `DEEPEYE-HUMAN-LOCK-20261014/revision1`, canonical SHA256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`. The active sole director is generation2 thread `01a13d7e-dcf1-7272-a738-a637dd62ff9d`. G03/R03/all29/finite_tau remain not_run; physical accuracy, training, noise, calibration and OOD remain unqualified. No product, UI, service, board, peer/PR or external publication action occurred. Root retains next-step selection and final acceptance.
