# Coordinate comparison review before the single attempt

The installed base_tensor_mesh.py properties at lines 174,196,218 return `np.r_[origin[axis],h[axis]].cumsum()`. The saved construction uses diff of nominal assignment nodes for h. Actual endpoints therefore use cumulative coordinates, while the consistent operator's saved cell bounds use nominal assignment coordinates. This successor explicitly represents both and never substitutes a fuzzy lookup.

All coordinate comparisons in the inherited audit were inspected before running:

* Bounds-versus-assignment at the initial cell check: keep nominal nodes and exact comparison.
* Local cell-map endpoint reconstruction: use actual cumulative nodes indexed by the same integer cell/side coordinates; exact comparison remains.
* Uniqueness/coverage and positive edge direction: unchanged exact integer/array checks.
* Geometric I/B selection: use actual endpoint extreme nodes; exact comparison remains.
* Sampled edge endpoint lookup: use actual cumulative node coordinates; exact lookup remains.
* Neighbor-cell enumeration: integer topology unchanged. Axis sizes derive from nominal arrays, with identical lengths.
* Polynomial widths and saved bounds in sampled rows: retain nominal node differences, exactly the operator that produced the saved action.
* Stored S3/S2 boundary, saved sums/restrictions/scales/cancellation/residual arithmetic: bitwise checks unchanged.

The existing monomial oracle, curl formula, sampled row set, summation bounds, resource guard and stop rules are unchanged. Row locations (0,0,0), (12,12,17), (12,12,1), and the axis-specific opposite corner fit every axis's edge-grid dimensions. They yield at most four adjacent cells per row and at most 48 local columns per component. No old controls, full actions or solves are permitted here. Any failure ends the attempt and remains recorded.
