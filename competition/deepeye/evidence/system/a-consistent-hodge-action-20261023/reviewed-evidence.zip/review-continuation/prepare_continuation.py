"""Minimal source/path preparation; no numerical worker or test execution."""
import difflib,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent;OLD=P/'g03-hodge-independent-20261023';G=P/'g03-hodge-geometry-diagnosis-20261023'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def write(p,s):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def save(n,x):write(D/n,json.dumps(x,indent=2,allow_nan=False)+'\n')
original=read(G/'original-native-result.json');assert original['status']=='completed' and original['terminal'] and not original['stale']
assert pin(OLD/'manifest-final.json')['sha256']=='79b37d46355edc6af112865e19620b0ab00320462637802ef53cd759ecdf7901'
sources=dict(read(OLD/'source-pins.json'))
for n,v in read(OLD/'manifest-final.json')['files'].items():
    q=OLD/n;assert pin(q)==v;sources[q.relative_to(ROOT).as_posix()]=v
for q in [OLD/'manifest-final.json',OLD/'final-verification.json',OLD/'native-completion.json',D/'assignment.md',D/'reserve-request.json',*sorted(G.glob('*'))]:
    if q.is_file():sources[q.relative_to(ROOT).as_posix()]=pin(q)
base=ROOT/read(G/'source-reference.json')['path'];assert pin(base)['sha256']=='56fb85078a2b42184d4b17ec57fa484592d35c20beb76ecd339b50db4edb2b00'
sources[base.relative_to(ROOT).as_posix()]=pin(base)
dll=Path(read(P/'g03-consistent-hodge-json-continuation-20261023/action-01/worker-evidence.json')['BLAS_before']['path']);expected=read(P/'g03-consistent-hodge-json-continuation-20261023/action-01/worker-evidence.json')['BLAS_before']['sha256'];assert pin(dll)['sha256']==expected
sources[dll.relative_to(ROOT).as_posix()]=pin(dll)
assert all(pin(ROOT/n)==v for n,v in sources.items())
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json');scopehash=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert scopehash=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json');assert transfer['status']=='active' and transfer['director_generation']==2
text=(OLD/'array_audit.py').read_text(encoding='utf-8');old=text
replacements=[
("    ids=a('cell_ids');bounds=a('cell_bounds_m');mapping=a('cell_edge_map')", "    # Actual TensorMesh endpoint coordinates: preserve documented operation order.\n    actual_nodes=[np.r_[v[0],np.diff(v)].cumsum() for v in nodes]\n    geometry_difference=[{'axis':j,'non_bitwise_node_count':int(np.count_nonzero(actual_nodes[j]!=nodes[j])),'max_abs_coordinate_difference_m':float(np.max(abs(actual_nodes[j]-nodes[j])))} for j in range(3)]\n    diagnosed=read(P/'g03-hodge-geometry-diagnosis-20261023/result.json')\n    for j in range(3):assert np.array_equal(actual_nodes[j],np.array(diagnosed['axis_records'][j]['actual_nodes_m']))\n    ids=a('cell_ids');bounds=a('cell_bounds_m');mapping=a('cell_edge_map')"),
("        lo=bounds[:,0].copy();hi=lo.copy();hi[:,axis]=bounds[:,1,axis]\n        for j,b in bits.items():lo[:,j]=hi[:,j]=bounds[:,b,j]", "        lo=np.column_stack([actual_nodes[j][sub[:,j]] for j in range(3)]);hi=lo.copy();hi[:,axis]=actual_nodes[axis][sub[:,axis]+1]\n        for j,b in bits.items():lo[:,j]=hi[:,j]=actual_nodes[j][sub[:,j]+b]"),
("    for j in range(3):boundary|=(axes!=j)&((starts[:,j]==nodes[j][0])|(starts[:,j]==nodes[j][-1]))", "    for j in range(3):boundary|=(axes!=j)&((starts[:,j]==actual_nodes[j][0])|(starts[:,j]==actual_nodes[j][-1]))"),
("            xyz=np.array([nodes[j][location[j]] for j in range(3)]);end=xyz.copy();end[axis]=nodes[axis][location[axis]+1]", "            xyz=np.array([actual_nodes[j][location[j]] for j in range(3)]);end=xyz.copy();end[axis]=actual_nodes[axis][location[axis]+1]"),
("'z_cell_widths_m':list(map(float,np.unique(np.diff(z))))", "'z_cell_widths_m':list(map(float,np.unique(np.diff(z)))),'actual_vs_nominal':geometry_difference,'endpoint_geometry':'exact TensorMesh cumulative nodes','operator_moment_geometry':'unchanged nominal assignment widths'")]
for a,b in replacements:assert text.count(a)==1;text=text.replace(a,b)
write(D/'array_audit.py',text)
write(D/'audit-exact-diff.patch',''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='original/array_audit.py',tofile='continuation/array_audit.py')))
launcher=(OLD/'run_audit.py').read_text(encoding='utf-8');prior=launcher
a="['array_audit.py','run_audit.py','provenance.py','source-pins.json','source-audit.json']";b="['array_audit.py','run_audit.py','prepare_continuation.py','source-pins.json','continuation-source-audit.json','coordinate-review.md','audit-exact-diff.patch','launcher-exact-diff.patch']";assert launcher.count(a)==1;launcher=launcher.replace(a,b)
write(D/'run_audit.py',launcher)
write(D/'launcher-exact-diff.patch',''.join(difflib.unified_diff(prior.splitlines(True),launcher.splitlines(True),fromfile='original/run_audit.py',tofile='continuation/run_audit.py')))
save('source-pins.json',sources)
save('continuation-source-audit.json',{'status':'prepared_without_scientific_execution','prior_pin_count':len(sources),'previous_native_terminal':{k:original[k] for k in ['job_id','status','terminal','stale']},'requirements_sha256':scopehash,'source_delta_count':len(replacements),'oracle_and_scales_unchanged':True,'coordinate_changes':'exact actual nodes for endpoints/boundary/row lookup; nominal bounds and moment widths retained','installed_base_mesh':{base.relative_to(ROOT).as_posix():pin(base)},'original_failure_preserved':True,'new_audit_attempt_limit':1})
print(json.dumps({'source_pins':len(sources),'targeted_replacements':len(replacements),'scopehash':scopehash,'prepared':True}))
