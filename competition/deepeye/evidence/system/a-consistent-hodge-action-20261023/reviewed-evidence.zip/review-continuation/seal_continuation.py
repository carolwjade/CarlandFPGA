"""Seal/reverify existing audit evidence; no numerical rerun."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def write(p,s):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def save(n,x):write(D/n,json.dumps(x,indent=2,allow_nan=False)+'\n')
r=read(D/'audit-01/result.json');t=read(D/'audit-01/terminal.json');rb=read(D/'audit-input-readback.json');started=read(D/'audit-01/started.json');src=read(D/'source-pins.json')
assert r['status']=='independent_saved_array_audit_pass' and t['status']=='success' and t['exit_code']==0 and t['stop_reason'] is None
assert t['all_processes_terminated'] and t['active_processes_final']==0 and len(t['held_members'])==3 and all(h['signaled'] and h['wait_result']==0 and h['exit_code']==0 for h in t['held_members'])
assert r['BLAS']['threads']==1 and started['readback_limits']=={'job_memory_bytes':1024**3,'process_memory_bytes':512*1024**2,'active_processes':3}
assert rb['prior_source_pins_unchanged'] and rb['audit_source_pins_unchanged'] and rb['before']==rb['after'] and rb['own_before']==rb['own_after']
assert all(pin(ROOT/n)==v for n,v in src.items())
for stream in ['stdout','stderr']:assert pin(D/('audit-01/'+stream+'.txt'))==t['logs'][stream]
assert json.loads((D/'audit-01/stdout.txt').read_text(encoding='utf-8'))==r
assert len(r['sampled_rows'])==12 and all(row['passed'] for row in r['sampled_rows'])
assert not (D/'audit-01/failure.json').exists()
errors={key:max(row['absolute_errors'][key] for row in r['sampled_rows']) for key in ['electric','curl','electric_scale','curl_scale']}
ratios={key:max(row['absolute_errors'][key]/row['bounds'][key] for row in r['sampled_rows']) for key in errors}
review={'work_id':'A-G03-HODGE-INDEPENDENT-CONTINUATION-20261023-v1','job_id':'child-1538fe361ea740fdbd8e2f4637d14c29','agent_id':'/root/g03_hodge_independent_20261023','status':'bounded_independent_saved_array_review_pass','formal_acceptance_by_child':False,'source_pins_count':len(src),'loaded_saved_arrays':len(r['loaded_pins']),'geometry':r['geometry'],'all_saved_arithmetic_exact':r['saved_arithmetic_exact'],'sampled_row_count':12,'sampled_row_ids':[row['global_edge'] for row in r['sampled_rows']],'sampled_row_maximum_absolute_errors':errors,'sampled_row_maximum_error_to_bound_ratio':ratios,'summaries':r['summaries'],'terminal':t,'source_readbacks_unchanged':True,'inherited_controls_and_source_review':'reused; no rerun','original_failed_audit':'preserved at g03-hodge-independent-20261023/audit-01; corrected coordinate representation only in new owned successor','resolved_review_finding':'R1 coverage limitation: all previously unexecuted checks and 12 sampled rows now completed with exact cumulative geometry; no mapping defect found','remaining_findings':[{'severity':'low','kind':'interpretation_limit','text':'Arithmetic scales do not certify upstream residual generation, discretization/conditioning or physical receiver accuracy.'}],'limitations':[r['limitations'],'No exhaustive full operator recomputation; only12deterministicrows independentlyintegrated.','Nominal operatorbounds retained; exact cumulative nodes used only for endpoint geometry/I-B/row lookup.'],'old_tests_rerun':0,'full_field_actions_rerun':0,'PDE_solves':0,'product_changes':0,'main_decisions':'Root retains acceptance,nextsolve,integration','scope':{'contract_id':'DEEPEYE-HUMAN-LOCK-20261014/revision1','requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','H01_H15_preserved':True,'director':'01a13d7e-dcf1-7272-a738-a637dd62ff9d','generation':2,'G03':'not_run','R03':'not_run','all29':'not_run','finite_tau':'not_run','physical_accuracy':'unqualified','training_noise_calibration_OOD':'unqualified'}}
save('review.json',review)
report=f'''# Independent saved-array audit continuation passed

Work `A-G03-HODGE-INDEPENDENT-CONTINUATION-20261023-v1`, native job `child-1538fe361ea740fdbd8e2f4637d14c29`, agent `/root/g03_hodge_independent_20261023`. This new lease returned execution_allowed=true before project operations. Only this successor directory was written. Root retains acceptance and any subsequent solve.

The single authorized audit completed all previously unexecuted checks and all twelve selected polynomial-row comparisons. The original failed audit, source review, static solve-design addendum and manifests remain unchanged. No old local control/test, production full-field action or solve was replayed.

## Exact geometry correction and preserved mathematics

Installed `discretize/base/base_tensor_mesh.py` at SHA256 `56fb85078a2b42184d4b17ec57fa484592d35c20beb76ecd339b50db4edb2b00` constructs nodes as `np.r_[origin,h].cumsum()`. The source was read directly at node properties 174/196/218. Reconstructing `h=diff(nominal)` with that operation order gives the saved endpoints exactly. The successor independently reproduced root's exact actual-node arrays. X/Y nodes equal nominal nodes bitwise; two Z nodes differ by at most `3.469446951953614e-18` m. No fuzzy coordinate match or relaxed tolerance was introduced.

`audit-exact-diff.patch` records five targeted coordinate/output substitutions. The exact bounds-vs-nominal assertion remains. Local endpoint geometry, geometric I/B selection and sampled-edge coordinate lookup now use actual cumulative nodes. Polynomial moments still use nominal node differences, exactly matching the production operator's saved nominal bounds. The Fraction polynomial oracle, curls, twelve row locations and predeclared 128eps summation bounds are unchanged. `coordinate-review.md` records inspection of every later coordinate comparison before the attempt. Launcher delta only rebinds its own source pin list to the new directory.

## Actual coverage

* All19,584cell IDs/bounds, positive local orientation, 12local edges/cell and 63,250unique covered global edges match exact integer topology and actual endpoint geometry.
* Geometric tangential-boundary reconstruction exactly matches saved I=54,418 and B=8,832 in saved order. The full S3 field restricted to B equals saved S2 gB bitwise.
* Electric+curl equals combined action, scales add, cancellation arrays match, and all full-to-I restrictions match bitwise.
* Three saved residuals add exactly to the stored old residual; their absolute scales match; old residual plus saved delta[I] and corresponding scales exactly reproduce the saved alternative residual.
* All five published summaries were recomputed from the saved arrays and match exactly. This is saved-array arithmetic, not an old operator action.
* Twelve independent row comparisons passed: IDs `{review['sampled_row_ids']}` across three axes, both boundaries, interior and nonuniform Z regions. Each row uses one or four adjacent cells and12columns/cell, at most48local contributions per component. The script integrates normalized-coordinate monomials exactly with Fractions, physical nominal-width derivatives, and independent face-center lumped values. It imports no production kernel and forms no global matrix/action.

Maximum row discrepancies are electric `{errors['electric']}` and curl `{errors['curl']}` A m/s; scale discrepancies are `{errors['electric_scale']}` and `{errors['curl_scale']}`. Every individual discrepancy is below its unchanged row-specific explicit-summation bound. Max error/bound ratios are `{ratios}`. These comparisons cover twelve deterministic rows, not an exhaustive independent full action.

The independently checked saved combined interior infinity norm is `2.4713203812440533e-4` A m/s; consistent residual is `2.471320380026613e-4` A m/s. The saved operator difference is resolved at its explicit arithmetic scales. It gives no receiver improvement guarantee and no physical1%qualification; no new receiver response was computed.

## Runtime and artifact evidence

The existing unmodified held Win32 guard enforced512MiB/process,1GiB/job,<=3processes,64MiBevidence and a30s sampled threshold. Actual terminal: exit0, no stop reason, `{t['seconds']:.3f}`s guarded elapsed, `{t['peak_job_memory_bytes']:,}`B peak job memory. Scientific worker elapsed `{r['elapsed_seconds']}`s. BLAS=1 was checked before/after work. All3retained process handles signaled exit0; active job count is0. Stderr is empty; raw stdout parses exactly to result.json. Actual argv/environment, applied limits, interpreter and process identity are in audit-01/started.json/grant.json/terminal.json.

All{len(src)}prior/input/source pins and the audit's own source pins remained unchanged before/after. All{len(r['loaded_pins'])}loaded saved arrays were hash-checked and finite. Source pins include the original failed audit/terminal and manifest, root's geometry diagnosis including failed exploratory records, and the installed node-construction implementation. No prior file or source was edited.

R1 from the original review is now addressed within this bounded coverage: the failure was a coordinate-representation mismatch in that audit, and exact cumulative-node checks pass. The original failure remains factual and preserved. No confirmed product mapping/formula defect was found by these checks. R2 remains: explicit scales and arithmetic identities do not certify upstream residual generation, discretization error, conditioning or physical receiver accuracy. Prior static solve-design/resource considerations remain reference material; no further design review or solver selection was performed here.

H01-H15 remain pinned under `DEEPEYE-HUMAN-LOCK-20261014/revision1`, canonical SHA256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`. The active sole director is generation2 thread `01a13d7e-dcf1-7272-a738-a637dd62ff9d`. G03/R03/all29/finite_tau remain not_run; physical accuracy, training, noise, calibration and OOD remain unqualified. No product, UI, service, board, peer/PR or external publication action occurred. Root retains next-step selection and final acceptance.
'''
write(D/'review.md',report)
excluded={'lease.private.json','manifest.json','native-completion.json','final-verification.json'}
files={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in excluded and p.suffix!='.pyc'}
save('manifest.json',{'work_id':review['work_id'],'files':files,'private_and_postseal_records_excluded':sorted(excluded)})
assert all(pin(D/n)==v for n,v in read(D/'manifest.json')['files'].items())
save('final-verification.json',{'status':'verified','manifest':pin(D/'manifest.json'),'entries':len(files),'prior_pins':len(src),'all_inputs_unchanged':True,'audit_exit':t['exit_code'],'all3heldsignaled':True,'sampled_rows_passed':12,'oldtests_fullactions_solves_rerun':0})
print(json.dumps(read(D/'final-verification.json')))
