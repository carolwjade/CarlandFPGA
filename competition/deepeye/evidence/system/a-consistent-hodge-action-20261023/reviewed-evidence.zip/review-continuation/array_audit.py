"""ONE bounded saved-array audit. No production imports or full operator action.

Selected rows: each uses at most four cells and twelve local columns/cell.
Integrate normalized-coordinate polynomials analytically with Fraction moments.
"""
import ctypes as ct,hashlib,itertools,json,math,os,sys,time,traceback
from fractions import Fraction as F
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent;stage=Path(sys.argv[1]).resolve()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
save(stage/'hello.json',{'pid':os.getpid(),'mode':'independent-array-audit','before_scientific_import':True})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('held grant absent')
    time.sleep(.01)
grant=read(stage/'grant.json');assert grant['worker']['pid']==os.getpid()
def audit(event,args):
    if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):raise PermissionError('network/subprocess forbidden')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        q=Path(os.fsdecode(args[0])).resolve();m=args[1];fl=args[2]
        writing=(isinstance(m,str) and any(c in m for c in 'wax+')) or (isinstance(fl,int) and bool(fl&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
        if writing and not q.is_relative_to(stage):raise PermissionError('stage-only writes')
        if not writing and q.suffix=='.npz':raise PermissionError('sparse/global matrix forbidden')
sys.addaudithook(audit);started=time.monotonic()
try:
    import numpy as np
    eps=np.finfo(float).eps
    dlls=list((Path(np.__file__).resolve().parents[1]/'numpy.libs').glob('*openblas*.dll'));assert len(dlls)==1
    win=ct.WinDLL('kernel32',use_last_error=True);win.GetModuleHandleW.argtypes=[ct.c_wchar_p];win.GetModuleHandleW.restype=ct.c_void_p
    handle=win.GetModuleHandleW(str(dlls[0]));assert handle
    get=ct.CDLL(str(dlls[0]),handle=handle).scipy_openblas_get_num_threads64_;get.argtypes=[];get.restype=ct.c_int
    assert get()==1
    blas={'path':str(dlls[0]),'sha256':hashlib.sha256(dlls[0].read_bytes()).hexdigest(),'threads':1}
    S=P/'g03-consistent-hodge-json-continuation-20261023';A=S/'action-01'
    pins=read(D/'source-pins.json')
    loaded={}
    def load(q):
        n=q.relative_to(ROOT).as_posix();b=q.read_bytes();v={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert pins[n]==v
        a=np.load(q,allow_pickle=False);assert np.all(np.isfinite(a));loaded[n]=v;return a
    def a(n):return load(A/(n+'.npy'))
    L=P/'g03-l5-propagation-z-refinement-20261021';S1=P/'g03-s1-cache-path-continuation-20261021';S2=P/'g03-s2-boundary-correction-20261021';S3=P/'g03-s3-json-continuation-20261021'
    assignment=read(L/'assignment.json');x=np.array(assignment['level']['x_nodes_m']);z=np.array(assignment['z_nodes_m']);nodes=[x,x,z]
    # Actual TensorMesh endpoint coordinates: preserve documented operation order.
    actual_nodes=[np.r_[v[0],np.diff(v)].cumsum() for v in nodes]
    geometry_difference=[{'axis':j,'non_bitwise_node_count':int(np.count_nonzero(actual_nodes[j]!=nodes[j])),'max_abs_coordinate_difference_m':float(np.max(abs(actual_nodes[j]-nodes[j])))} for j in range(3)]
    diagnosed=read(P/'g03-hodge-geometry-diagnosis-20261023/result.json')
    for j in range(3):assert np.array_equal(actual_nodes[j],np.array(diagnosed['axis_records'][j]['actual_nodes_m']))
    ids=a('cell_ids');bounds=a('cell_bounds_m');mapping=a('cell_edge_map')
    starts=load(L/'controls-01/edge_starts_m.npy');ends=load(L/'controls-01/edge_ends_m.npy')
    assert np.array_equal(ids,np.arange(19584)) and bounds.shape==(19584,2,3) and mapping.shape==(19584,12)
    sub=np.column_stack((ids%24,(ids//24)%24,ids//576))
    for axis in range(3):
        assert np.array_equal(bounds[:,0,axis],nodes[axis][sub[:,axis]]) and np.array_equal(bounds[:,1,axis],nodes[axis][sub[:,axis]+1])
    assert starts.shape==(63250,3) and ends.shape==starts.shape
    descriptors=[(axis,{t:b for t,b in zip([j for j in range(3) if j!=axis],bits)}) for axis in range(3) for bits in [(0,0),(1,0),(0,1),(1,1)]]
    for slot,(axis,bits) in enumerate(descriptors):
        lo=np.column_stack([actual_nodes[j][sub[:,j]] for j in range(3)]);hi=lo.copy();hi[:,axis]=actual_nodes[axis][sub[:,axis]+1]
        for j,b in bits.items():lo[:,j]=hi[:,j]=actual_nodes[j][sub[:,j]+b]
        assert np.array_equal(starts[mapping[:,slot]],lo) and np.array_equal(ends[mapping[:,slot]],hi)
    assert np.array_equal(np.unique(mapping),np.arange(63250)) and np.all(np.diff(np.sort(mapping,axis=1),axis=1)>0)
    assert len(np.unique(np.concatenate((starts,ends),axis=1),axis=0))==63250
    direction=ends-starts;axes=np.argmax(direction,axis=1)
    assert np.all(np.sum(direction>0,axis=1)==1) and np.all(direction>=0)
    boundary=np.zeros(63250,dtype=bool)
    for j in range(3):boundary|=(axes!=j)&((starts[:,j]==actual_nodes[j][0])|(starts[:,j]==actual_nodes[j][-1]))
    I=load(S1/'controls-01/interior_indices.npy');B=load(S1/'controls-01/boundary_indices.npy')
    assert np.array_equal(np.flatnonzero(boundary),B) and np.array_equal(np.flatnonzero(~boundary),I)
    E=load(S3/'run-01/corrected_derivative_Vpm.npy');gB=load(S2/'run-01/selected_gB_Vpm.npy')
    assert E.shape==(63250,) and np.array_equal(E[B],gB)
    em=a('electric_mass_delta_full_Amps');ck=a('curl_hodge_delta_full_Amps');combined=a('combined_delta_full_Amps')
    sm=a('electric_absolute_sum_scale_full_Amps');sk=a('curl_absolute_sum_scale_full_Amps');sc=a('combined_absolute_sum_scale_full_Amps');cancel=a('electric_curl_cancellation_full_Amps')
    assert np.array_equal(em+ck,combined) and np.array_equal(sm+sk,sc) and np.array_equal(abs(em)+abs(ck)-abs(combined),cancel)
    for full,n in [(em,'electric_delta_I_Amps'),(ck,'curl_delta_I_Amps'),(combined,'combined_delta_I_Amps')]:assert np.array_equal(full[I],a(n))
    residuals=[load(S1/'run-01/residual.npy'),load(S2/'run-01/correction_residual.npy'),load(S3/'run-01/new_source_residual.npy')]
    old=residuals[0]+residuals[1]+residuals[2];oldscale=sum(abs(v) for v in residuals)
    assert np.array_equal(old,a('saved_residual_sum_Amps')) and np.array_equal(oldscale,a('saved_residual_sum_scale_Amps'))
    consistent=a('consistent_operator_residual_I_Amps')
    assert np.array_equal(old+combined[I],consistent) and np.array_equal(oldscale+sc[I],a('consistent_residual_scale_I_Amps'))
    assert np.all(sm>=abs(em)) and np.all(sk>=abs(ck)) and np.all(sc>=abs(combined))
    # Review the published summary arithmetic from saved arrays.
    def summary(v,s):return {'inf_norm':float(np.max(abs(v))),'max_roundoff_sum_bound':float(np.max(128*eps*s)),'sum_absolute':float(np.sum(abs(v))),'sum_scale':float(np.sum(s)),'resolved_entries':int(np.count_nonzero(abs(v)>128*eps*s)),'resolved':bool(np.any(abs(v)>128*eps*s))}
    published=read(A/'result.json');summaries={}
    for key,v,s in [('electric_mass_delta_I',em[I],sm[I]),('curl_hodge_delta_I',ck[I],sk[I]),('combined_delta_I',combined[I],sc[I]),('accumulated_saved_residual',old,oldscale),('consistent_operator_residual_I',consistent,oldscale+sc[I])]:
        summaries[key]=summary(v,s);assert summaries[key]==published[key]
    # Standalone polynomial moments in normalized cell coordinates. Physical
    # curl derivatives divide by observed cell width; integration multiplies V.
    zero=(0,0,0)
    def product(p,q):
        out={}
        for u,c in p.items():
            for v,d in q.items():
                w=tuple(u[j]+v[j] for j in range(3));out[w]=out.get(w,F(0))+c*d
        return {u:c for u,c in out.items() if c}
    def differentiate(p,j,h):
        out={}
        for u,c in p.items():
            if u[j]:v=list(u);v[j]-=1;out[tuple(v)]=c*u[j]/h[j]
        return out
    def moment(p,q,V):return V*sum((c/F(math.prod(v+1 for v in u)) for u,c in product(p,q).items()),F(0))
    def evaluate(p,point):return sum((c*math.prod(point[j]**u[j] for j in range(3)) for u,c in p.items()),F(0))
    def forms(h):
        V=math.prod(h);basis=[];curls=[]
        for axis,bits in descriptors:
            poly={zero:F(1)}
            for j,b in bits.items():
                power=tuple(int(k==j) for k in range(3));poly=product(poly,{power:F(1)} if b else {zero:F(1),power:F(-1)})
            basis.append(poly);cv=[{} for _ in range(3)]
            # epsilon_(curl axis, derivative axis, field axis), independently explicit.
            for c,j,sgn in [(0,1,1),(0,2,-1),(1,2,1),(1,0,-1),(2,0,1),(2,1,-1)]:
                component={(0,1):2,(0,2):1,(1,2):0,(1,0):2,(2,0):1,(2,1):0}[(c,j)]
                if component==axis:cv[c]={u:sgn*v for u,v in differentiate(poly,j,h).items()}
            curls.append(cv)
        return V,basis,curls
    parameters=read(S1/'assignment.json')['inputs'];omega=2*math.pi*parameters['frequency_Hz'];zeta=parameters['sigma_background_Spm']+1j*omega*parameters['epsilon_background_Fpm'];mu=parameters['mu_background_Hpm'];coeff=1j*omega*zeta
    rows=[];selected=[]
    for axis in range(3):
        for location in [(0,0,0),(12,12,17),(12,12,1),(23 if axis==0 else 24,23 if axis==1 else 24,33 if axis==2 else 34)]:
            xyz=np.array([actual_nodes[j][location[j]] for j in range(3)]);end=xyz.copy();end[axis]=actual_nodes[axis][location[axis]+1]
            hits=np.flatnonzero(np.all(starts==xyz,axis=1)&np.all(ends==end,axis=1));assert len(hits)==1;gid=int(hits[0]);selected.append(gid)
            adjacent=[]
            for j in range(3):adjacent.append([location[j]] if j==axis else [v for v in (location[j]-1,location[j]) if 0<=v<len(nodes[j])-1])
            cell_subs=list(itertools.product(*adjacent));assert 1<=len(cell_subs)<=4
            te=[];tk=[];se=[];ss=[];cell_ids=[]
            for cell in cell_subs:
                cid=cell[0]+24*cell[1]+576*cell[2];cell_ids.append(cid)
                h=tuple(F.from_float(float(nodes[j][cell[j]+1]-nodes[j][cell[j]])) for j in range(3));V,basis,curls=forms(h)
                localbits={j:location[j]-cell[j] for j in range(3) if j!=axis};i=descriptors.index((axis,localbits))
                assert mapping[cid,i]==gid
                for j,(colaxis,colbits) in enumerate(descriptors):
                    m=moment(basis[i],basis[j],V) if axis==colaxis else F(0);ml=V/4 if i==j else F(0)
                    k=sum((moment(curls[i][c],curls[j][c],V) for c in range(3)),F(0));kl=F(0)
                    for c in range(3):
                        for side in (0,1):
                            point=[F(1,2)]*3;point[c]=F(side);kl+=V/2*evaluate(curls[i][c],point)*evaluate(curls[j][c],point)
                    e=E[mapping[cid,j]];te.append(coeff*float(m-ml)*e);tk.append(float(k-kl)*e/mu)
                    se.append(abs(coeff)*float(abs(m)+abs(ml))*abs(e));ss.append(float(abs(k)+abs(kl))*abs(e)/mu)
            def cs(v):return complex(math.fsum(q.real for q in v),math.fsum(q.imag for q in v))
            expected_e=cs(te);expected_k=cs(tk);es=math.fsum(se);ks=math.fsum(ss)
            errors={'electric':abs(expected_e-em[gid]),'curl':abs(expected_k-ck[gid]),'electric_scale':abs(es-sm[gid]),'curl_scale':abs(ks-sk[gid])}
            limits={'electric':128*eps*(es+sm[gid]),'curl':128*eps*(ks+sk[gid]),'electric_scale':128*eps*(es+sm[gid]),'curl_scale':128*eps*(ks+sk[gid])}
            assert all(errors[k]<=limits[k] for k in errors),(gid,errors,limits)
            rows.append({'global_edge':gid,'axis':axis,'node_indices':location,'boundary':bool(boundary[gid]),'neighbor_cells':cell_ids,'cells_count':len(cell_subs),'local_columns_per_cell':12,'complex_contributions_per_component':len(te),'cell_widths_m':[[float(v) for v in bounds[c,1]-bounds[c,0]] for c in cell_ids],'absolute_errors':errors,'bounds':limits,'passed':True})
    assert len(set(selected))==12 and get()==1
    result={'status':'independent_saved_array_audit_pass','geometry':{'cells':19584,'edges':63250,'mapping_unique_complete':True,'I':len(I),'B':len(B),'I_B_geometric_reconstruction_exact':True,'full_field_boundary_equals_S2_exact':True,'z_cell_widths_m':list(map(float,np.unique(np.diff(z)))),'actual_vs_nominal':geometry_difference,'endpoint_geometry':'exact TensorMesh cumulative nodes','operator_moment_geometry':'unchanged nominal assignment widths'},'saved_arithmetic_exact':True,'summaries':summaries,'sampled_rows':rows,'sampled_global_rows':12,'maximum_cells_per_row':4,'full_field_operator_actions':0,'old_tests_rerun':0,'PDE_solves':0,'production_kernel_imported':False,'method':'exact Fraction normalized-coordinate monomial moments; face-center lumped counterpart; one row at a time','limitations':'12 deterministic global rows, not exhaustive scatter recomputation; saved residual arithmetic does not validate upstream residual generation or receiver accuracy','BLAS':blas,'elapsed_seconds':time.monotonic()-started,'loaded_pins':loaded}
    save(stage/'result.json',result);print(json.dumps(result),flush=True)
except BaseException as exc:
    save(stage/'failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),'elapsed_seconds':time.monotonic()-started});raise
