"""One granted, stage-confined scientific worker; no network or subprocess."""
import ctypes as ct
import hashlib,json,os,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent
stage=Path(sys.argv[1]).resolve();mode=sys.argv[2]
def save(p,value):
    with p.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
save(stage/'hello.json',{'pid':os.getpid(),'mode':mode,'before_scientific_import':True})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('held worker grant missing')
    time.sleep(.01)
grant=json.loads((stage/'grant.json').read_text(encoding='utf-8'))
assert grant['worker']['pid']==os.getpid() and grant['mode']==mode
def audit(event,args):
    if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):raise PermissionError('no network/subprocess')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).resolve();modes=args[1];flags=args[2]
        writing=(isinstance(modes,str) and any(c in modes for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
        if writing and not path.is_relative_to(stage):raise PermissionError('stage writes only')
        if not writing and path.suffix=='.npz':raise PermissionError('global sparse matrix reads forbidden')
sys.addaudithook(audit);sys.path.insert(0,str(D));started=time.monotonic();before=None
def threads():
    import numpy as np
    k=ct.WinDLL('kernel32',use_last_error=True);k.GetModuleHandleW.argtypes=[ct.c_wchar_p];k.GetModuleHandleW.restype=ct.c_void_p
    paths=list((Path(np.__file__).resolve().parents[1]/'numpy.libs').glob('*openblas*.dll'));assert len(paths)==1
    handle=k.GetModuleHandleW(str(paths[0]));assert handle
    get=ct.CDLL(str(paths[0]),handle=handle).scipy_openblas_get_num_threads64_;get.argtypes=[];get.restype=ct.c_int
    count=get();assert count==1
    return {'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),'threads':count}
try:
    before=threads()
    if mode in ('red','controls'):
        import test_hodge
        result=test_hodge.run(stage)
    elif mode=='action':
        import hodge_action
        result=hodge_action.run(stage)
    else:raise ValueError('unknown mode')
    save(stage/'result.json',result)
    save(stage/'worker-evidence.json',{'elapsed_seconds':time.monotonic()-started,'BLAS_before':before,'BLAS_after':threads()})
    print(json.dumps(result),flush=True)
except BaseException as exc:
    save(stage/'failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),'elapsed_seconds':time.monotonic()-started,'BLAS_before':before})
    raise
