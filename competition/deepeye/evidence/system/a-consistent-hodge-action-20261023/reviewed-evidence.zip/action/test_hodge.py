"""Independent exact physical-coordinate monomial oracle, frozen before RED.

Does not use production matrix formulas, curl incidence, quadrature, or old tests.
"""
from fractions import Fraction as F
import json
import numpy as np

EPS = np.finfo(float).eps
H = (F(3,100), F(5,100), F(7,100))
ZERO = (0,0,0)

def add(a,b):
    out = dict(a)
    for p,c in b.items(): out[p] = out.get(p,F(0)) + c
    return {p:c for p,c in out.items() if c}

def scale(a,c): return {p:v*c for p,v in a.items() if v*c}

def mul(a,b):
    out={}
    for p,c in a.items():
        for q,d in b.items():
            power=tuple(p[i]+q[i] for i in range(3))
            out[power]=out.get(power,F(0))+c*d
    return out

def deriv(a,axis):
    out={}
    for p,c in a.items():
        if p[axis]:
            q=list(p);q[axis]-=1;out[tuple(q)]=c*p[axis]
    return out

def integ(a):
    terms=[c*np_prod([H[i]**(n+1)/F(n+1) for i,n in enumerate(p)]) for p,c in a.items()]
    return sum(terms,F(0)), sum((abs(t) for t in terms),F(0))

def np_prod(values):
    out=F(1)
    for value in values: out*=value
    return out

def dot(a,b):
    out={}
    for x,y in zip(a,b): out=add(out,mul(x,y))
    return out

def curl(v):
    return [add(deriv(v[2],1),scale(deriv(v[1],2),-1)),
            add(deriv(v[0],2),scale(deriv(v[2],0),-1)),
            add(deriv(v[1],0),scale(deriv(v[0],1),-1))]

def fixtures():
    basis=[];starts=[];ends=[]
    for axis in range(3):
        transverse=[i for i in range(3) if i!=axis]
        for second in (0,1):
            for first in (0,1):
                start=[F(0)]*3;end=[F(0)]*3;end[axis]=H[axis]
                for j,bit in zip(transverse,(first,second)):start[j]=end[j]=H[j]*bit
                poly={ZERO:F(1)}
                for j in transverse:
                    power=tuple(int(i==j) for i in range(3))
                    factor={power:1/H[j]} if start[j] else {ZERO:F(1),power:-1/H[j]}
                    poly=mul(poly,factor)
                v=[{}, {}, {}];v[axis]=poly
                basis.append(v);starts.append(start);ends.append(end)
    curls=[curl(v) for v in basis]
    mass=np.empty((12,12));stiff=np.empty_like(mass);ms=np.empty_like(mass);ks=np.empty_like(mass)
    rational={"mass":[],"curl":[]}
    for i in range(12):
        mr=[];kr=[]
        for j in range(12):
            m,mabs=integ(dot(basis[i],basis[j]));k,kabs=integ(dot(curls[i],curls[j]))
            mass[i,j]=float(m);stiff[i,j]=float(k);ms[i,j]=float(mabs);ks[i,j]=float(kabs)
            mr.append(str(m));kr.append(str(k))
        rational['mass'].append(mr);rational['curl'].append(kr)
    return basis,curls,np.array(starts,dtype=float),np.array(ends,dtype=float),mass,stiff,ms,ks,rational

def check(actual,expected,scale_terms,label):
    actual=np.asarray(actual);expected=np.asarray(expected);s=np.asarray(scale_terms)
    if actual.shape!=expected.shape:raise AssertionError(label+" shape")
    bound=128*EPS*(np.abs(actual)+np.abs(expected)+s)
    err=np.abs(actual-expected)
    result={'passed':bool(np.all(err<=bound)), 'max_absolute_error':float(np.max(err)),
            'max_bound':float(np.max(bound)), 'absolute_scale_sum':float(np.sum(np.abs(actual)+np.abs(expected)+s))}
    if not result['passed']:raise AssertionError(label+" exceeds frozen entrywise sum bound")
    return result

def reject(callback):
    try:callback()
    except ValueError:return True
    raise AssertionError('negative fixture did not reject')

def run(stage):
    import hodge_kernel as k
    basis,curls,starts,ends,Mref,Kref,ms,ks,rational=fixtures()
    (stage/'exact-rational-oracle.json').write_text(json.dumps(rational,indent=2)+'\n',encoding='utf-8')
    # First invocation is the genuine missing-kernel RED; no implementation exists.
    M,K,Ml,Kl=k.local_matrices(np.array(H,dtype=float)[None,:])
    M,K,Ml,Kl=(x[0] for x in (M,K,Ml,Kl))
    rows={}
    rows['mass_all_entries']=check(M,Mref,ms,'mass entries')
    rows['curl_all_entries']=check(K,Kref,ks,'curl entries')
    volume=float(np_prod(H))
    # Installed scalar tensor-mesh formula: each cell contributes V/4 to each
    # parallel edge and V/2 to each parallel face. Independently evaluate the
    # polynomial curls at the six face centers to recover the latter rule.
    def evaluate(poly,point):return sum((c*np_prod([point[i]**p[i] for i in range(3)]) for p,c in poly.items()),F(0))
    face_values=[]
    for axis in range(3):
        for side in (0,1):
            point=[h/2 for h in H];point[axis]=H[axis]*side
            face_values.append([float(evaluate(v[axis],point)) for v in curls])
    face_values=np.array(face_values)
    oldK=volume/2*face_values.T@face_values
    rows['lumped_edge_formula']=check(Ml,np.eye(12)*volume/4,np.eye(12)*volume/4,'old mass formula')
    rows['lumped_face_formula']=check(Kl,oldK,volume/2*abs(face_values).T@abs(face_values),'old curl formula')
    rows['mass_symmetry']=check(M,M.T,ms+ms.T,'mass symmetry')
    rows['curl_symmetry']=check(K,K.T,ks+ks.T,'curl symmetry')
    constant=np.repeat([1.,-2.,3.],4)
    rows['constant_mass_delta']=check((M-Ml)@constant,np.zeros(12),(abs(M)+abs(Ml))@abs(constant),'constant mass delta')
    rows['constant_curl']=check(K@constant,np.zeros(12),abs(K)@abs(constant),'constant curl')
    # Representable affine E=(1+2y+3z,-2+5x+7z,3+11x+13y).
    E=[{ZERO:F(1),(0,1,0):F(2),(0,0,1):F(3)},
       {ZERO:F(-2),(1,0,0):F(5),(0,0,1):F(7)},
       {ZERO:F(3),(1,0,0):F(11),(0,1,0):F(13)}]
    edge_values=[]
    for i in range(12):
        midpoint=[F(str(x)) for x in (starts[i]+ends[i])/2]
        edge_values.append(float(evaluate(E[i//4],midpoint)))
    edge_values=np.array(edge_values)
    expected_mass=np.array([float(integ(dot(v,E))[0]) for v in basis])
    expected_curl=np.array([float(integ(dot(v,curl(E)))[0]) for v in curls])
    rows['affine_mass_action']=check(M@edge_values,expected_mass,ms@abs(edge_values),'affine mass')
    rows['affine_curl_action']=check(K@edge_values,expected_curl,ks@abs(edge_values),'affine curl')
    # phi=xy+(2/5)yz+(1/5)zx+xyz; endpoint differences / edge length.
    phi={(1,1,0):F(1),(0,1,1):F(2,5),(1,0,1):F(1,5),(1,1,1):F(1)}
    grad=[]
    for i in range(12):
        a=[F(str(x)) for x in starts[i]];b=[F(str(x)) for x in ends[i]]
        grad.append(float((evaluate(phi,b)-evaluate(phi,a))/H[i//4]))
    grad=np.array(grad)
    rows['gradient_curl']=check(K@grad,np.zeros(12),ks@abs(grad),'gradient curl')
    energies=[]
    for vector in [np.arange(1,13,dtype=float),np.array([1,-2,3,-4,2,-3,4,-5,3,-4,5,-6.])]:
        em=float(vector@M@vector);ek=float(vector@K@vector)
        bound=128*EPS*float(abs(vector)@abs(K)@abs(vector))
        if not em>0 or ek < -bound:raise AssertionError('real geometric energy')
        energies.append({'mass':em,'curl':ek,'curl_roundoff_bound':bound})
    width=np.array(H,dtype=float)
    bounds=np.array([[np.zeros(3),width]])
    ids=np.array([0]);mapping=np.arange(12,dtype=np.int64)[None,:]
    k.validate_cells(bounds,mapping,ids,starts,ends)
    negatives={}
    negatives['duplicate_cell_ids']=reject(lambda:k.validate_cells(np.repeat(bounds,2,axis=0),np.repeat(mapping,2,axis=0),np.array([0,0]),starts,ends))
    wrong=mapping.copy();wrong[0,0]=1
    negatives['wrong_map']=reject(lambda:k.validate_cells(bounds,wrong,ids,starts,ends))
    reverse=starts.copy();reverse[0]=ends[0]
    reverse_end=ends.copy();reverse_end[0]=starts[0]
    negatives['reversed_edge']=reject(lambda:k.validate_cells(bounds,mapping,ids,reverse,reverse_end))
    negatives['negative_width']=reject(lambda:k.local_matrices(np.array([[-.03,.05,.07]])))
    lengths=np.repeat(width,4)
    wrong_scaled=M/lengths[:,None]/lengths[None,:]
    wrong_bound=128*EPS*(abs(wrong_scaled)+abs(Mref)+ms)
    negatives['circulation_scaling_screen']=bool(np.any(abs(wrong_scaled-Mref)>wrong_bound))
    if not negatives['circulation_scaling_screen']:raise AssertionError('wrong scaling undetected')
    for name,value in {'M_consistent_m3':M,'K_consistent_m':K,'M_lumped_m3':Ml,'K_lumped_m':Kl,'M_exact_m3':Mref,'K_exact_m':Kref,'mass_monomial_abs_scale_m3':ms,'curl_monomial_abs_scale_m':ks}.items():
        with (stage/(name+'.npy')).open('xb') as f:np.save(f,value,allow_pickle=False)
    return {'status':'new_local_controls_pass','checks':rows,'energies':energies,'negative_cases':negatives,
        'expected_source':'independent Fraction monomial integrals in physical coordinates',
        'synthetic_widths_m':[.03,.05,.07],'fixed_roundoff_factor':128,'old_tests_repeated':False}
