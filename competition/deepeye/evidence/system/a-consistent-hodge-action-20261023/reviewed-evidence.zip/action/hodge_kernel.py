"""Local edge-average consistent/lumped Hodge forms; no global matrix.

The face-average curl map uses signed physical 1/h derivatives. Faces are
ordered x0,x1,y0,y1,z0,z1. Local edges use transverse first-bit-fast order.
"""
import numpy as np

def local_matrices(widths):
    h=np.asarray(widths,dtype=float)
    if h.ndim!=2 or h.shape[1]!=3 or not len(h) or not np.all(np.isfinite(h)) or np.any(h<=0):
        raise ValueError('positive finite cell widths required')
    count=len(h);volume=np.prod(h,axis=1)
    T=np.array([[1/3,1/6],[1/6,1/3]],dtype=float)
    edge=np.zeros((12,12));face=np.zeros((6,6))
    for axis in range(3):
        edge[4*axis:4*axis+4,4*axis:4*axis+4]=np.kron(T,T)
        face[2*axis:2*axis+2,2*axis:2*axis+2]=T
    C=np.zeros((count,6,12));slot=0
    for axis in range(3):
        transverse=[a for a in range(3) if a!=axis]
        for second in (0,1):
            for first in (0,1):
                bits=dict(zip(transverse,(first,second)))
                for derivative_axis in transverse:
                    curl_axis=next(a for a in range(3) if a not in (axis,derivative_axis))
                    parity=1 if (curl_axis,derivative_axis,axis) in ((0,1,2),(1,2,0),(2,0,1)) else -1
                    C[:,2*curl_axis+bits[curl_axis],slot]=parity*(2*bits[derivative_axis]-1)/h[:,derivative_axis]
                slot+=1
    M=volume[:,None,None]*edge[None,:,:]
    K=volume[:,None,None]*np.einsum('nfi,fg,ngj->nij',C,face,C,optimize=False)
    Ml=volume[:,None,None]*np.eye(12)[None,:,:]/4
    Kl=volume[:,None,None]*np.einsum('nfi,nfj->nij',C,C,optimize=False)/2
    if not all(np.all(np.isfinite(v)) for v in (M,K,Ml,Kl)):raise ValueError('nonfinite local forms')
    return M,K,Ml,Kl

def validate_cells(bounds,mapping,cell_ids,starts,ends):
    bounds=np.asarray(bounds);mapping=np.asarray(mapping);cell_ids=np.asarray(cell_ids)
    starts=np.asarray(starts);ends=np.asarray(ends);count=len(bounds)
    if bounds.shape!=(count,2,3) or mapping.shape!=(count,12) or cell_ids.shape!=(count,):raise ValueError('cell shapes')
    if not np.issubdtype(mapping.dtype,np.integer) or not np.issubdtype(cell_ids.dtype,np.integer):raise ValueError('integer IDs required')
    if len(np.unique(cell_ids))!=count or np.any(cell_ids<0):raise ValueError('duplicate/negative cell IDs')
    if starts.ndim!=2 or starts.shape[1]!=3 or ends.shape!=starts.shape:raise ValueError('edge endpoint shapes')
    if not all(np.all(np.isfinite(v)) for v in (bounds,starts,ends)) or np.any(bounds[:,1]<=bounds[:,0]):raise ValueError('invalid geometry')
    if np.any(mapping<0) or np.any(mapping>=len(starts)) or np.any(np.diff(np.sort(mapping,axis=1),axis=1)==0):raise ValueError('invalid/duplicate local edge map')
    bound=128*np.finfo(float).eps*max(1.,float(np.max(abs(bounds))))
    slot=0
    for axis in range(3):
        transverse=[a for a in range(3) if a!=axis]
        for second in (0,1):
            for first in (0,1):
                begin=bounds[:,0].copy();finish=begin.copy();finish[:,axis]=bounds[:,1,axis]
                for a,bit in zip(transverse,(first,second)):begin[:,a]=finish[:,a]=bounds[:,bit,a]
                if np.any(abs(starts[mapping[:,slot]]-begin)>bound) or np.any(abs(ends[mapping[:,slot]]-finish)>bound):
                    raise ValueError('local map or positive edge orientation mismatch')
                slot+=1

def delta_action(bounds,mapping,field,omega,zeta,mu,chunk=256):
    """Exactly one gather/action/scatter traversal; retain full boundary field."""
    if chunk<1 or chunk>256 or mu<=0 or not np.isfinite(mu) or not np.isfinite(omega) or not np.isfinite(zeta):raise ValueError('invalid action parameters')
    if field.ndim!=1 or not np.all(np.isfinite(field)):raise ValueError('invalid field')
    electric=np.zeros(len(field),dtype=complex);magnetic=np.zeros_like(electric)
    electric_scale=np.zeros(len(field));magnetic_scale=np.zeros(len(field))
    coeff=1j*omega*zeta
    for first in range(0,len(bounds),chunk):
        last=min(first+chunk,len(bounds));ids=mapping[first:last]
        h=bounds[first:last,1]-bounds[first:last,0]
        M,K,Ml,Kl=local_matrices(h);e=field[ids]
        dm=coeff*np.einsum('nij,nj->ni',M-Ml,e,optimize=False)
        dk=np.einsum('nij,nj->ni',K-Kl,e,optimize=False)/mu
        # Include the parent consistent and lumped contributions in the sum
        # scales, so local matrix subtraction cancellation is not hidden.
        sm=abs(coeff)*np.einsum('nij,nj->ni',abs(M)+abs(Ml),abs(e),optimize=False)
        sk=np.einsum('nij,nj->ni',abs(K)+abs(Kl),abs(e),optimize=False)/mu
        for full,local in ((electric,dm),(magnetic,dk),(electric_scale,sm),(magnetic_scale,sk)):
            np.add.at(full,ids.ravel(),local.ravel())
    return electric,magnetic,electric_scale,magnetic_scale
