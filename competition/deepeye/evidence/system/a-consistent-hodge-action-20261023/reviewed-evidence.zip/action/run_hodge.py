"""One-attempt held stage launcher using unmodified reviewed guard bytes."""
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
SUPPORT=D.parent/'r02-amd-wheel-acquisition-20261021'
PY=ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def inputs():
    frozen=read(D/'input-pins.json')['files']
    for name,expected in frozen.items():assert pin(ROOT/name)==expected,name
    scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
    assert hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
    assert transfer['status']=='active' and transfer['director_generation']==2
    names=['assignment.md','selection.json','plan.md','test_hodge.py','hodge_kernel.py','hodge_worker.py','run_hodge.py','input-pins.json']
    if (D/'hodge_action.py').exists():names.append('hodge_action.py')
    return {**frozen,**{(D/n).relative_to(ROOT).as_posix():pin(D/n) for n in names}}
def main():
    mode=sys.argv[1];assert mode=='action'
    before=inputs()
    old=D.parent/'g03-consistent-hodge-action-20261022'
    assert read(old/'controls-01/result.json')['status']=='new_local_controls_pass'
    terminal=read(old/'controls-01/terminal.json')
    assert terminal['status']=='success' and terminal['all_processes_terminated']
    for name in ('hodge_kernel.py','test_hodge.py','hodge_worker.py'):
        assert pin(D/name)==pin(old/name)
    assert read(D/'selection.json')['prior_saved_field_actions']==0
    save(D/'frozen-source-pins.json',before)
    stage=D/'action-01'
    sys.path.insert(0,str(SUPPORT));from win_job import run_bounded,process_identity
    env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),'PATH':'','TEMP':str(stage),'TMP':str(stage),'TMPDIR':str(stage),'MPLCONFIGDIR':str(stage/'mplconfig'),'MPLBACKEND':'Agg','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',**{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS')}}
    budget={'seconds':30,'active_processes':3,'process_memory_bytes':512*1024**2,'job_memory_bytes':1024**3,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':128*1024**2,'tree_entries':2048,'free_reserve_bytes':512*1024**2}
    granted=False
    def tick(job,pids):
        nonlocal granted
        if (stage/'hello.json').exists() and not granted:
            h=read(stage/'hello.json');assert h['pid'] in pids and h['mode']==mode
            save(stage/'grant.pending.json',{'worker':process_identity(h['pid'],job),'mode':mode})
            os.replace(stage/'grant.pending.json',stage/'grant.json');granted=True
    argv=[str(PY),'-I','-B','-X','utf8',str(D/'hodge_worker.py'),str(stage),mode]
    result=run_bounded(argv,env,D,stage,budget,[D],on_tick=tick)
    after=inputs();save(stage/'input-readback.json',{'unchanged':before==after,'before':before,'after':after})
    assert before==after and result['all_processes_terminated']
    if mode=='red':
        assert result['exit_code']==1 and result['stop_reason'] is None
        failure=read(stage/'failure.json')
        assert failure['type']=='NotImplementedError' and failure['message']=='consistent-Hodge action kernel not implemented'
        save(stage/'expected-red.json',{'expected_missing_kernel':True,'original_exit_code':1,'old_tests_repeated':False})
    print(json.dumps({k:result.get(k) for k in ('status','exit_code','seconds','stop_reason','peak_job_memory_bytes','all_processes_terminated','held_members')}),flush=True)
    return 0 if mode=='red' else result['exit_code'] if result['exit_code'] is not None else 125
if __name__=='__main__':raise SystemExit(main())
