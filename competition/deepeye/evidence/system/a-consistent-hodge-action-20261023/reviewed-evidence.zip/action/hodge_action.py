"""One frozen full-field action of the new delta operator; no old A action."""
import hashlib,json,math
from pathlib import Path
import numpy as np
import hodge_kernel as kernel
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def load(path):
    expected=read(D/'input-pins.json')['files'][path.relative_to(ROOT).as_posix()]
    data=path.read_bytes()
    if len(data)!=expected['bytes'] or hashlib.sha256(data).hexdigest()!=expected['sha256']:raise ValueError('action input hash mismatch')
    array=np.load(path,allow_pickle=False)
    if not np.all(np.isfinite(array)):raise ValueError('nonfinite input')
    return array
def save_array(stage,name,a):
    if not np.all(np.isfinite(a)):raise ValueError('nonfinite output '+name)
    with (stage/(name+'.npy')).open('xb') as f:np.save(f,a,allow_pickle=False)
def summary(a,scale):
    bound=128*np.finfo(float).eps*scale
    return {'inf_norm':float(np.max(abs(a))),'max_roundoff_sum_bound':float(np.max(bound)),
        'sum_absolute':float(np.sum(abs(a))),'sum_scale':float(np.sum(scale)),
        'resolved_entries':int(np.count_nonzero(abs(a)>bound)),
        'resolved':bool(np.any(abs(a)>bound))}
def run(stage):
    L5=P/'g03-l5-propagation-z-refinement-20261021'
    S1=P/'g03-s1-cache-path-continuation-20261021';S2=P/'g03-s2-boundary-correction-20261021';S3=P/'g03-s3-json-continuation-20261021'
    assignment=read(L5/'assignment.json');p=read(S1/'assignment.json')['inputs']
    x=np.array(assignment['level']['x_nodes_m']);z=np.array(assignment['z_nodes_m']);nodes=[x,x,z]
    shape=tuple(len(v)-1 for v in nodes)
    if shape!=(24,24,34):raise ValueError('frozen L5 cell shape')
    starts=load(L5/'controls-01/edge_starts_m.npy');ends=load(L5/'controls-01/edge_ends_m.npy')
    if starts.shape!=(63250,3) or ends.shape!=starts.shape:raise ValueError('frozen edge shape')
    ids=np.arange(19584,dtype=np.int64);sub=np.array(np.unravel_index(ids,shape,order='F')).T
    bounds=np.empty((19584,2,3))
    for a in range(3):
        bounds[:,0,a]=nodes[a][sub[:,a]];bounds[:,1,a]=nodes[a][sub[:,a]+1]
    edge_shapes=[(24,25,35),(25,24,35),(25,25,34)];offsets=[0,21000,42000]
    mapping=np.empty((19584,12),dtype=np.int64);slot=0
    for axis in range(3):
        transverse=[a for a in range(3) if a!=axis]
        for second in (0,1):
            for first in (0,1):
                edge=sub.copy()
                for a,bit in zip(transverse,(first,second)):edge[:,a]+=bit
                mapping[:,slot]=offsets[axis]+np.ravel_multi_index(tuple(edge.T),edge_shapes[axis],order='F');slot+=1
    kernel.validate_cells(bounds,mapping,ids,starts,ends)
    if not np.array_equal(np.unique(mapping),np.arange(63250)):raise ValueError('global edge coverage')
    I=load(S1/'controls-01/interior_indices.npy');B=load(S1/'controls-01/boundary_indices.npy')
    if I.shape!=(54418,) or B.shape!=(8832,) or not np.issubdtype(I.dtype,np.integer) or not np.issubdtype(B.dtype,np.integer) or not np.array_equal(np.sort(np.r_[I,B]),np.arange(63250)):raise ValueError('ordered partition')
    field=load(S3/'run-01/corrected_derivative_Vpm.npy');gB=load(S2/'run-01/selected_gB_Vpm.npy')
    if field.shape!=(63250,) or not np.iscomplexobj(field) or gB.shape!=(8832,) or not np.array_equal(field[B],gB):raise ValueError('saved full field/boundary')
    residuals=[load(S1/'run-01/residual.npy'),load(S2/'run-01/correction_residual.npy'),load(S3/'run-01/new_source_residual.npy')]
    if any(a.shape!=(54418,) or not np.iscomplexobj(a) for a in residuals):raise ValueError('saved residual lengths/types')
    omega=2*math.pi*p['frequency_Hz'];zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm'];mu=p['mu_background_Hpm']
    pre={'cells':19584,'edges':63250,'interior':54418,'boundary':8832,'cell_order':'F/x-fast','local_edge_order':'axis then second transverse bit outer, first inner','boundary_exactly_equal_saved_S2':True,'full_field_boundary_included':True,'geometry_tolerance_m':128*np.finfo(float).eps,'chunk_cells':256,'global_sparse_matrices':0,'old_operator_actions':0,'new_field_actions_started':0}
    with (stage/'pre-action.json').open('x',encoding='utf-8') as f:json.dump(pre,f,indent=2);f.write('\n')
    # The sole saved-field action; there is no retry, second field, or solver.
    electric,magnetic,sm,sk=kernel.delta_action(bounds,mapping,field,omega,zeta,mu,chunk=256)
    combined=electric+magnetic;scale=sm+sk
    old_residual=residuals[0]+residuals[1]+residuals[2]
    old_scale=abs(residuals[0])+abs(residuals[1])+abs(residuals[2])
    consistent_residual=old_residual+combined[I]
    total_scale=old_scale+scale[I]
    cancellation=abs(electric)+abs(magnetic)-abs(combined)
    outputs={'cell_ids':ids,'cell_bounds_m':bounds,'cell_edge_map':mapping,
        'electric_mass_delta_full_Amps':electric,'curl_hodge_delta_full_Amps':magnetic,
        'combined_delta_full_Amps':combined,'electric_absolute_sum_scale_full_Amps':sm,
        'curl_absolute_sum_scale_full_Amps':sk,'combined_absolute_sum_scale_full_Amps':scale,
        'electric_curl_cancellation_full_Amps':cancellation,'electric_delta_I_Amps':electric[I],
        'curl_delta_I_Amps':magnetic[I],'combined_delta_I_Amps':combined[I],
        'saved_residual_sum_Amps':old_residual,'saved_residual_sum_scale_Amps':old_scale,
        'consistent_operator_residual_I_Amps':consistent_residual,'consistent_residual_scale_I_Amps':total_scale}
    for name,array in outputs.items():save_array(stage,name,array)
    result={'status':'one_saved_field_action_complete','new_saved_field_actions':1,'cells':19584,'edges':63250,'chunks':math.ceil(19584/256),
        'electric_mass_delta_I':summary(electric[I],sm[I]),'curl_hodge_delta_I':summary(magnetic[I],sk[I]),
        'combined_delta_I':summary(combined[I],scale[I]),'accumulated_saved_residual':summary(old_residual,old_scale),
        'consistent_operator_residual_I':summary(consistent_residual,total_scale),
        'max_electric_curl_cancellation_Amps':float(np.max(cancellation)),
        'source_parameters':{'omega_radps':omega,'zeta_Spm':[zeta.real,zeta.imag],'mu_Hpm':mu},
        'action_units':'A m/s','boundary_included_before_I_restriction':True,'saved_residuals_added_without_old_operator_action':True,
        'PDE_solves':0,'global_sparse_assemblies':0,'old_operator_actions':0,'new_primary_Green_quadrature':0,'old_tests_repeated':False,
        'interpretation':'Resolved defect is a new operator-consistency observation only; no unweighted residual norm certifies receiver improvement or physical accuracy.',
        'fixed_receiver_gate':.01,'physical_accuracy':'unqualified','finite_tau':'not_run','G03':'not_run','all29':'not_run'}
    return result
