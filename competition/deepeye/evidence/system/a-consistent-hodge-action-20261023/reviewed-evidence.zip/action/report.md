# One new consistent-Hodge saved-field action completed

Root selected a separate continuation after original child-78ceaf27bea248d8bfbf10c150a6fad5 ended failed/terminal/result=null. The original action stopped before numerical field loading. All original failures, local-control results and nine stopped process records remain unchanged.

Only scientific-source replacement: `assignment['level']['z_nodes_m']` to `assignment['z_nodes_m']`, confirmed against the frozen L5 JSON. Kernel, independent rational tests and worker bytes are identical. The launcher selects only the unperformed action and binds original successful local controls. No RED, local test, old solver or old field integration was rerun.

The new full-field action completed in 0.7960000000020955s with peak job memory 46522368bytes; all three held processes are signaled, exit0, BLAS1 and exact input readback unchanged. It traversed19584cells/63250edges in77chunks, using the full frozen S3 field including its original boundary, before restricting to54418interior edges.

The electric-mass delta infinity norm is0.00048166618499514074A m/s; curl-Hodge delta0.0002684304517089734A m/s; combined delta0.00024713203812440533A m/s. Adding the three saved residuals gives the alternative consistent-operator residual0.0002471320380026613A m/s. The combined delta exceeds its explicit roundoff sum scale at all54418interior entries; this establishes a resolved operator-action difference, not receiver improvement or physical accuracy.

All component arrays, cancellation and absolute-sum scales, partition and geometry, raw process/worker/guard evidence are retained. No old C/A action, sparse global matrix, Green/primary/quadrature evaluation, PDE solve, product edit, GUI/service/board/peer action occurred. Physical1%receiver gates are unchanged; physical accuracy/training/noise/OOD remain unqualified, G03/R03/all29not_run. H01-H15 requirements SHA256c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 remains fixed.

Independent source and saved-array review is pending. Root retains any later consistent-operator solve selection.
