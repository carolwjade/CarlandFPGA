"""Seal existing stage results without importing or rerunning scientific code."""
import ast,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
stages={name:read(D/name/'terminal.json') for name in ('red-01','controls-01','action-01')}
assert read(D/'red-01/expected-red.json')['expected_missing_kernel']
control=read(D/'controls-01/result.json')
assert control['status']=='new_local_controls_pass' and all(v['passed'] for v in control['checks'].values())
assert all(control['negative_cases'].values())
failure=read(D/'action-01/failure.json')
assert failure['type']=='KeyError' and failure['message']=="'z_nodes_m'"
assert not (D/'action-01/pre-action.json').exists() and not list((D/'action-01').glob('*.npy'))
held=[]
for name,t in stages.items():
 assert t['all_processes_terminated'] and t['stop_reason'] is None
 assert all(row['signaled'] for row in t['held_members'])
 assert read(D/name/'input-readback.json')['unchanged']
 held.extend(t['held_members'])
assert len(held)==9
for name in ('test_hodge.py','hodge_kernel.py','hodge_worker.py','run_hodge.py','hodge_action.py'):
 ast.parse((D/name).read_text(encoding='utf-8'))
red=read(D/'red-source-pins.json');frozen=read(D/'frozen-source-pins.json')
for name in ('test_hodge.py','hodge_worker.py','run_hodge.py'):
 key=(D/name).relative_to(ROOT).as_posix();assert red[key]==frozen[key]==pin(D/name)
assert red[(D/'hodge_kernel.py').relative_to(ROOT).as_posix()]==pin(D/'red-kernel-stub.py')
result={'work_id':'A-G03-CONSISTENT-HODGE-ACTION-20261022-v1','job_id':'child-78ceaf27bea248d8bfbf10c150a6fad5',
 'status':'failed_action_JSON_schema_before_saved_field_load','requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
 'local_kernel_implemented':True,'new_local_controls':control,'stages':stages,'failure':failure,
 'actual_saved_field_actions':0,'action_attempts':1,'action_arrays':0,'pre_action_receipt':False,
 'input_pins':21,'input_readbacks_unchanged':True,'all_held_processes_signaled':9,'retry_count':0,
 'proposed_fix_not_applied':"hodge_action.py:28 assignment['level']['z_nodes_m'] -> assignment['z_nodes_m']",
 'global_action_runtime_validated':False,'old_tests_repeated':False,'PDE_solves':0,'Green_evaluations':0,'global_sparse_assemblies':0,
 'physical_accuracy':'unqualified','finite_tau':'not_run','G03':'not_run','all29':'not_run','H01_H15':'unchanged'}
save(D/'result.json',result)
save(D/'delivery-verification.json',{'status':'passed_failure_evidence_seal','stage_and_source_crosschecks':True,'AST_parsed':True,'science_rerun':False,'all_held_signaled':9})
exclude={'lease.private.json','reserve-request.json','reserve.stderr.txt','dispatch.json','manifest.json'}
files={}
for path in sorted(D.rglob('*')):
 if path.is_file() and path.name not in exclude and 'private' not in path.name:
  files[path.relative_to(D).as_posix()]=pin(path)
save(D/'manifest.json',{'work_id':result['work_id'],'files':files,'private_records_excluded':True})
print(json.dumps({'status':result['status'],'manifest_files':len(files),'manifest_sha256':pin(D/'manifest.json')['sha256'],'result_sha256':pin(D/'result.json')['sha256'],'report_sha256':pin(D/'report.md')['sha256'],'evidence_bytes':sum(v['bytes'] for v in files.values())}))
