"""Bind existing selected inputs and guard bytes; no scientific imports."""
import ast,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
old=P/'g03-s3-error-diagnosis-20261022'
assert pin(old/'diagnosis.md')['sha256']=='40c5933be5d03f8672d5c9c5111db6bca9e0d86c980438190317f868acd1ba8b'
assert pin(old/'proposed-input-pins.json')['sha256']=='b557d4dd2284aba68caa7c457f3160034441038fdd06839a06ed81b9825bf447'
known=read(old/'source-pins.json')['files']
known.update(read(old/'proposed-input-pins.json')['files'])
names=[
 '.planning/deepeye-resume-20261018/g03-s3-error-diagnosis-20261022/diagnosis.md',
 '.planning/deepeye-resume-20261018/g03-s3-error-diagnosis-20261022/proposed-input-pins.json',
 '.planning/deepeye-resume-20261018/g03-consistent-hodge-main-selection-20261022/decision.json',
 '.local/deepeye-fdem-validation-20261020/Scripts/python.exe',
 'docs/competition/deepeye-2026/immutable_scope.md',
 'docs/competition/deepeye-2026/immutable_scope.json',
 '.planning/deepeye-desktop-handoff-20261015/transfer.json']
for folder,files in {
 'r02-amd-wheel-acquisition-20261021':['win_job.py','boundary.py'],
 'g03-l5-propagation-z-refinement-20261021':['assignment.json','controls-01/edge_starts_m.npy','controls-01/edge_ends_m.npy'],
 'g03-s1-cache-path-continuation-20261021':['assignment.json','controls-01/interior_indices.npy','controls-01/boundary_indices.npy','run-01/residual.npy'],
 'g03-s2-boundary-correction-20261021':['run-01/selected_gB_Vpm.npy','run-01/correction_residual.npy'],
 'g03-s3-json-continuation-20261021':['run-01/corrected_derivative_Vpm.npy','run-01/new_source_residual.npy','projection-01/g4_projected_full_RHS.npy']}.items():
 for file in files:names.append((P/folder/file).relative_to(ROOT).as_posix())
files={}
for name in names:
 current=pin(ROOT/name)
 if name in known:assert current==known[name],name
 files[name]=current
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
scope_hash=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert scope_hash=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
for name in ['test_hodge.py','hodge_kernel.py','hodge_worker.py','run_hodge.py']:
 ast.parse((D/name).read_text(encoding='utf-8'))
with (D/'input-pins.json').open('x',encoding='utf-8') as f:
 json.dump({'files':files,'requirements_sha256':scope_hash,'mutable_checkpoint_excluded':True},f,indent=2);f.write('\n')
print(json.dumps({'input_files':len(files),'scope_hash':scope_hash,'source_AST':'parsed','scientific_imports':0}))
