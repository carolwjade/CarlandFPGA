# Consistent-Hodge kernel: local controls passed; action stopped before field loading

Work A-G03-CONSISTENT-HODGE-ACTION-20261022-v1, native job child-78ceaf27bea248d8bfbf10c150a6fad5, worker /root/g03_s3_error_diagnosis_20261022. Only this assigned directory was written. The lease validated execution_allowed=true. The H01–H15 canonical requirements hash is unchanged: c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.

**The assigned job failed in its action-stage JSON input adapter.** The new kernel and local analytic controls completed, but no saved-field action ran and no physical-operator defect was measured. The implementation incorrectly used `assignment['level']['z_nodes_m']` at hodge_action.py:28; the pinned L5 JSON stores z_nodes_m at the top level. This is a worker coding error. It is preserved without repair or retry, as explicitly required by the assignment.

## Implemented local mathematics

hodge_kernel.py builds the dimensionless edge-average mass blocks V*(T tensor T), opposing-face blocks V*T, T=[[1/3,1/6],[1/6,1/3]], and physical signed 1/h local curl map. The old local forms are V/4 edge diagonal and V/2 face diagonal. The kernel exposes matrix-free chunked gather/local action/scatter of `mu^-1 DeltaK e + i omega zeta DeltaM e`, separate electric/curl contributions and explicit absolute-summation scales. No global sparse matrix, old global C/A action, factorization or solve was implemented or executed.

The tests were written and frozen before implementation. Their expected values derive every mass and curl entry independently from rational monomial integration in physical coordinates on h=(0.03,0.05,0.07) m. They do not use production tensor-matrix formulas, production curl incidence, or quadrature. Exact rational expected entries are retained in both RED and controls stages. The missing-kernel stub is preserved in red-kernel-stub.py and bound by red-source-pins.json.

The genuine RED failed with `NotImplementedError: consistent-Hodge action kernel not implemented`. The implementation then passed all 11 new local comparisons using the predeclared entrywise 128eps explicit-sum bounds:

| Check | Maximum absolute discrepancy |
|---|---:|
| All mass entries | 1.6940658945086007e-21 m³ |
| All curl entries | 6.938893903907228e-18 m |
| Lumped edge formula | 3.3881317890172014e-21 m³ |
| Lumped face/curl formula | 6.938893903907228e-18 m |
| Mass symmetry | 0 |
| Curl symmetry | 1.734723475976807e-18 m |
| Constant-field mass delta | 3.3881317890172014e-21 |
| Constant-field curl action | 2.7755575615628914e-17 |
| Representable affine mass action | 1.3552527156068805e-20 |
| Representable affine curl action | 3.9898639947466563e-17 |
| Trilinear nodal-gradient curl action | 4.336808689942018e-19 |

All actual bounds and scales are in controls-01/result.json. Two fixed real vectors passed positive mass and nonnegative curl-energy checks. Five negative checks rejected duplicate cell IDs, wrong local edge mapping, reversed edge orientation, negative cell width and circulation-normalized mass scaling. The affine fixture is explicitly within the lowest-order edge space's representable subspace; it does not claim exact reconstruction of arbitrary axial variation.

The global scatter/action function is implemented but **not runtime validated on the saved field**. Local-control success must not be promoted into global-action verification.

## Actual stages and failure boundary

| Stage | Actual terminal | Guarded elapsed | Peak job memory | Held handles |
|---|---|---:|---:|---:|
| New missing-kernel RED | failed / exit1, expected | 1.047 s | 41,148,416 B | 3/3 signaled |
| New local controls | success / exit0 | 0.437 s | 42,295,296 B | 3/3 signaled |
| Action attempt | failed / exit1, KeyError | 0.360 s | 41,164,800 B | 3/3 signaled |

The guard is the existing unmodified win_job.py/boundary.py. Every stage stayed within the selected 30 s sampled threshold, 512 MiB/process, 1 GiB/job, <=3 process and 128 MiB evidence limits. Actual held-handle evidence confirms all nine observed processes stopped. Sampled elapsed is not a hard wall-time guarantee. NumPy OpenBLAS was checked at one thread before every stage and after successful controls. The failed action retains its before-check, with no extra post-failure scientific probe.

All 21 selected input pins and each stage's own source pins had unchanged before/after readbacks. The test, worker and launcher bytes are unchanged between RED and controls. The guard/controller retained raw stdout, stderr, actual argv/interpreter identity, resource readbacks and process identities. The mutable root checkpoint was excluded from mathematical inputs.

The action failure occurs while reading the pinned L5 assignment, before loading edge arrays, partition arrays, saved full S3 field or residual arrays. There is no pre-action receipt and no action NPY output. Therefore: one action **attempt**, zero saved-field actions; no electric/curl defect or consistent residual result exists. The original failure.json, traceback, stderr and terminal.json remain untouched.

## Narrow possible continuation for root selection

Static JSON inspection confirms `z_nodes_m` is top-level with 35 entries, while `level.x_nodes_m` has 25 and `level.z_nodes_m` is absent. The concrete proposed adapter fix is replacing only `assignment['level']['z_nodes_m']` by `assignment['z_nodes_m']`. **This replacement was not made.** Root must decide whether to create a separate continuation after independently reviewing the frozen kernel/test sources and this failure boundary. Do not resume this failed native job or replay its successful local controls/RED. Any successor must bind their original hashes and outcomes, independently check the exact input schema, and retain the one-action/no-PDE-solve boundary.

Root retains selection and acceptance. No product, service, UI, board, GPU, dependency, provider, peer/PR or other owner's changes occurred. Old tests, Green evaluations, primary integrations, quadrature, sparse assemblies and PDE solves were not repeated. The physical 1% receiver gates remain unchanged; physical_accuracy/noise/calibration/training/OOD remain unqualified, and finite_tau/G03/all29 remain not_run. H01–H15 remain mandatory, including hidden truth, causal sensing, substantive PC AI and both H12 control paths.
