"""RED stub: the selected consistent-Hodge delta action is absent."""
def local_matrices(widths):
    raise NotImplementedError("consistent-Hodge action kernel not implemented")
