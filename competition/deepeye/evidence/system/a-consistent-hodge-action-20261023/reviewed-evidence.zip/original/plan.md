# Selected consistent-Hodge action increment

Implement only the root-selected local DeltaA action. Existing design and decision are inputs, not amended. Freeze independent rational physical-coordinate polynomial integration tests, then one genuine absent-kernel RED, implement the kernel, one controls stage, and only after success one full saved-field action. No unexpected stage failure may be repaired or rerun.

Local order is x edges (y-bit fastest, z-bit outer), y edges (x-bit fastest, z-bit outer), z edges (x-bit fastest, y-bit outer). Positive axial edge-average values are V/m. The independent test builds N functions from physical edge endpoints and integrates monomials with Fraction. The implementation uses local face-average curl incidence and tensor 2x2 hat integrals. All comparisons use 128 eps times explicit absolute contribution scales, fixed before RED. Local mass units m^3, curl Gram units m; physical operator action units A m/s.

One synthetic anisotropic cell h=(.03,.05,.07) m covers every matrix entry, representable affine fields, constants, gradient/curl, symmetry, real geometric energies, edge orientation/scaling and map/duplicate validation. General axial variation is not exactly representable by this lowest-order edge space; the affine fixture is explicitly in its representable subspace.

The action gathers the full saved S3 field, including S2 boundary values, over all 19,584 cells in chunks of at most256. Scatter electric and curl contributions separately, preserve cancellation scales, then restrict I. Accumulate saved S1/S2/S3 residuals without old matrix action and add the new defect. No old C/A construction/action, quadrature, Green field, sparse global assembly, factorization or solve.

Use original win_job.py/boundary.py bytes. Each guarded stage: 30s sampled threshold,512MiB/process,1GiB/job,<=3processes,BLAS1,<=128MiB total evidence. All cache/temp directories are stage-local. Preserve raw stdout/stderr, argv, tool/source pins and held process terminal evidence. A resolved defect is evidence only, with physical_accuracy unqualified and G03/all29 not_run. Root selects any later solve.
