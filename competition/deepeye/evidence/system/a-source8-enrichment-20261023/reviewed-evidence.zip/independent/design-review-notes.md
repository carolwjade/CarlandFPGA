# Source8 design review notes — provisional, pending frozen implementation

Work A-G03-SOURCE8-REVIEW-20261023-v1, native child-12ba29c00a5d4775854fe965c4d80c40, agent /root/g03_hodge_independent_20261023. The new lease validated execution_allowed=true before project work. Only this review folder is writable. No source, test, primary target, quadrature or PDE execution has been performed by the reviewer. Final implementation/control hashes and root-selected actual result are pending.

The previous face stage is failed at F4/F2=0.0012562635425821533>0.001. It selected no patches and did not evaluate concentration for acceptance. Source8 is a distinct new source evaluation with fixed physical parameters and source support, rather than a retry of that stage or an adjustment of its threshold.

## Required physical rule and source consistency

For each fixed source cell [a,b], let h=b-a. An order8 one-dimensional Gauss rule (xi,w) on[-1,1] maps to x=a+h*(xi+1)/2, with physical tensor weights V*w_i*w_j*w_k/8. Tensor order must match target/current flattening, with each current row paired to exactly its physical point and weight. The64cell rule has64*8^3=32,768targets, each strictly inside one cell; fixed256Txpoints give8,388,608target/source interactions. Gauss8 roots are distinct from prior Gauss2/4 roots; the new stage must actually evaluate the primary at these new points and preserve old targets/fields.

The pinned S1 primary implementation is s1_geometry.primary: fixed loop geometry and material parameters, nonoutgoing-branch rejection and explicit filament separation checks. Its current source has an internal target chunk128, so an external256target chunk is an upper-bound orchestration batch, not a change to that old kernel. The largest internal distance block is128*256=32,768pairs, below the proposed65,536outer-batch bound. The original kernel must remain byte-identical; no Tx/source amplitude or reference-based changes are allowed.

For exp(+iomega t), curl(E)=-iomega*mu*H and curl(H)=zeta E+J yield curl(mu^-1curl E)+iomega*zeta E=-iomega*J. Thus the archived/new equivalent current convention J=zeta0*Eprimary gets exactly one further -iomega in both projections. Neither projection may reapply zeta or infer a bubble load from the coarse b4 vector.

Coarse b8_j=-iomega*sum w*N_j(x)*J8(x) and bubble f8_q=-iomega*sum w*q(x)*J8(x) must use the same new points, physical weights and current values. For constant current in direction t, each of four parallel coarse basis functions has cell integral V/4 and a face bubble on one side has integral V/3 (integral lambda=1/2, integral4s(1-s)=2/3). These give a compact independent manufactured same-current/load normalization/sign control. Coarse basis partition of unity further gives sum_parallel b8=-iomega*integral J_t on each cell. This is source projection only, not operator assembly.

Gauss8 is exact for tensor polynomial degrees<=15 per coordinate. A tensor degree7 interpolant of J8 times an old edge basis has degrees<=8, while times the face bubble has degrees<=9. Exactness of those represented currents does not establish physical primary integration error. The new F8/F4 pair remains an engineering consistency screen, not a true-error or receiver bound.

Full b8 and its explicit absolute product scale, plus delta b8-b4, must be saved in the old global edge ordering with fixed source support/boundary convention. A future enriched solve requires b8 alongside f8, rather than f8 with b4. The old field and its saved mass/curl actions remain immutable; no coarse operator or field action is needed here. New ell8 may be formed only after the F8/F4 source gate passes, using saved mass/curl arrays. F8 should be formed only for source-cell/patch incidences, with both sides added when they share a source-bearing face; at most768incidences/480touched probes on this source support. All other F8 entries remain exactly zero.

## Gates, controls and execution checks pending definitive source

Review new rule coordinates, positive physical weights, moments and coarse/bubble same-current projection against independent exact expectations. A missing new order8 kernel RED and wrong-Jacobian/wrong-single-source-factor negatives must be genuine; accepted face and source2/4 tests must not be rerun. Expected polynomial moments must not call the production rule/projector to produce the oracle.

The definitive source must freeze exact original primary/Tx/physics and accepted face geometry/moments/source_action/selection hashes. Review the new rule's target shapes(64,512,3), weights(64,512), current(64,512,3), nominal source bounds, exact fixed source-cell IDs and actual endpoint-vs-nominal geometry convention. Separation checks must precede finite-primary use. No reference H/receiver outcome enters source or selection.

Require strict reporter for files and stdout, pinned immutable held guard, staged raw outputs before metadata and before/after source/DLL/BLAS1 records. Proposed60s/512MiBprocess/1GiBjob/3process/64MiBartifact limits are ceilings, not measured guarantees. Source8 point/weight/current arrays alone are only a few MiB; old maps/library overhead and total working set still need actual records.

Fixed source0.001, resolution10x,24cell-disjoint patch limit,50%concentration and both physical1%gates remain unchanged. A failed source gate stops without selecting/retrying higher order. Passing source consistency may permit exactly one accepted selection on new data; it does not select a solve. Preserve the old failed GMRES and JSON attempts, failed F4/F2stage, source/receiver limitations and H01-H15. Sole director01a13d7e-dcf1-7272-a738-a637dd62ff9d generation2 retains selection and acceptance; G03/R03/all29 and finite-strength/noise/OOD/training stay unqualified/not_run.

## Provisional new support/control observations

The current source8_support.py maps nodes with (x+1)/2 and physical product weights V/8, in ij/x-slow,z-fast tensor order. Its coarse projector uses one normalized transverse endpoint factor per transverse axis, one -iomega, and explicit global scatter/absolute scales. It does not import or modify the old2/4projector. The current synthetic shared-x-face mapping merges precisely the two y and two z shared edges.

The new test obtains unit moments1/(k+1) independently with Fractions, checks each coordinate through degree15, uses explicit P8 polynomial coefficients and the derivative-based weight relation, checks physical volume/layout and a joint current polynomial with powers(3,4,5) for all coarse components and both bubble hats. The physical volume in comparisons is the direct product of the supplied floating widths; exact normalized integrals are independent rational values. Both load calculations use the same synthesized current. Wrong-volume normalization and sign must visibly differ. These are new Gauss8/control cases using the accepted bubble source function, not repeats of accepted face controls.

The test's predeclared comparison factor is2048eps for this new512-point/high-degree rule control. It is distinct from the accepted128eps resolution/source arithmetic terms; no scientific0.001/10x/24/50%/1%gate changes follow. No controls have been rerun by this reviewer, and execution/first-GREEN evidence remains pending.
