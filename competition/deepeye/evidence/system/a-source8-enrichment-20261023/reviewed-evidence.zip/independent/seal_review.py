"""Metadata-only final seal; no science or test replay."""
import hashlib, importlib.util, json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];S=D.parent/'g03-source8-enrichment-20261023'
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
h=ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py';assert pin(h)['sha256']=='a0aabdbf259f7232bf3e1e77a81d130a8f676ad0b87eba39fae99d118f858554'
sp=importlib.util.spec_from_file_location('reporter',h);reporter=importlib.util.module_from_spec(sp);sp.loader.exec_module(reporter)
def save(name,value):reporter.write_new_report(D/name,value)
m=read(S/'manifest.json');assert pin(S/'manifest.json')['sha256']=='1675faac6617b77609ecf9b524c0c3768325a869543227124a16436d77f1059a'
assert len(m['files'])==m['file_count']==72 and sum(v['bytes'] for v in m['files'].values())==m['total_bytes']==15178764
assert all(pin(S/n)==p for n,p in m['files'].items())
native=read(S/'native-completion-receipt.json');assert native['status']=='completed' and native['terminal'] and native['stale'] is False and native['error'] is None
assert native['job_id']=='child-7f506f0f505749f386574e6640e1e2e4'
assert pin(D/'failed-audit-source.txt')==pin(D/'review_saved_source.py')
decision=read(D.parent/'g03-source8-main-review-20261023/independent-continuation-selection.json')
assert decision['original_audit_script']==pin(D/'failed-audit-source.txt') and decision['original_audit_failure']==pin(D/'audit-failure.json')
c=read(D/'continuation-result.json');assert c['status']=='saved_source_continuation_pass' and len(c['checks'])==6
assert read(D/'continuation-stdout.txt')['status']=='saved_source_continuation_pass' and (D/'continuation-stderr.txt').stat().st_size==0
assert pin(D/'review_saved_source_continuation.py')==read(D/'continuation-before.json')['continuation_source']
assert all(pin(ROOT/n)==p for n,p in read(D/'continuation-pins.json').items())
pre=read(D/'preexecution-review.json');assert pre['status']=='definitive_preexecution_review_no_blocking_findings'
r=read(S/'source-01/result.json');t=read(S/'source-01/terminal.json');summary=read(S/'result-summary.json')
assert summary['source_pair_relative_inf']==r['source_pair_relative_inf'] and summary['score_coverage']==r['selected_score_fraction']
save('seal-verification.json',{'status':'metadata_seal_verified','author_manifest':pin(S/'manifest.json'),'author_files_verified':72,'author_bytes':15178764,'author_native_receipt':pin(S/'native-completion-receipt.json'),'author_native_status':native['status'],'author_native_terminal':native['terminal'],'author_native_stale':native['stale'],'original_failed_audit_preserved':True,'continuation_source_unchanged':True,'continuation_all65pins_unchanged':True,'continuation_tool_exit_code':0,'continuation_tool_wall_seconds':2.2470922,'continuation_stdout':pin(D/'continuation-stdout.txt'),'continuation_stderr':pin(D/'continuation-stderr.txt'),'source_result':pin(S/'source-01/result.json'),'source_terminal':pin(S/'source-01/terminal.json')})
save('review.json',{'work_id':'A-G03-SOURCE8-REVIEW-20261023-v1','job_id':'child-12ba29c00a5d4775854fe965c4d80c40','canonical_agent':'/root/g03_hodge_independent_20261023','status':'independent_review_completed','blocking_implementation_findings':[],'scientific_outcome':'bounded_enrichment_not_supported','source_pair':{'pass':True,'reported_relative_inf':r['source_pair_relative_inf'],'independent_scalar_relative_inf':c['checks'][2]['relative_inf'],'gate':.001},'concentration':{'pass':False,'coverage':r['selected_score_fraction'],'gate':.5,'tentative_patches':24,'distinct_cells':48,'resolved_directions':113088,'candidate_defined':False},'new_controls_reviewed_without_replay':111,'source_pin_count':41,'source_pins':pin(S/'source-pins.json'),'saved_current_check':c['checks'][0],'coarse_moment_sample_count':24,'bubble_moment_sample_count':12,'original_reviewer_attempt':'failed_cross_implementation_bit_identity_preserved','root_selected_continuation':'passed_once','source_stage':{'exit_code':0,'seconds':t['seconds'],'peak_job_memory_bytes':t['peak_job_memory_bytes'],'all3held_stopped':True,'BLAS_threads_before_after':1},'continuation':{'exit_code':0,'seconds':c['runtime_seconds'],'peak_working_set_bytes':c['peak_working_set_bytes']},'author_manifest':pin(S/'manifest.json'),'author_native_status':'completed_terminal_nonstale_receipt','no_production_or_old_science_replay':True,'original_GMRES_info':3,'prior_receiver_failures':'unchanged','physical_accuracy':'unqualified','G03':'not_run','R03':'not_run','all29':'not_run','H01_H15_preserved':True,'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','root_retains':'evidence acceptance and next work selection'})
files={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ['lease.private.json','manifest.json','native-completion.json']}
assert not any('private' in n.lower() for n in files)
save('manifest.json',{'work_id':'A-G03-SOURCE8-REVIEW-20261023-v1','file_count':len(files),'total_bytes':sum(p['bytes'] for p in files.values()),'files':files,'excluded':['private lease credential','manifest self','subsequent native completion receipt'],'original_failure_preserved':True,'single_saved_data_continuation':True,'acceptance_owner':'root'})
print(reporter.dumps_report({'status':'review_sealed','manifest':pin(D/'manifest.json'),'review':pin(D/'review.json'),'file_count':len(files),'bytes':sum(p['bytes'] for p in files.values())}),end='')
