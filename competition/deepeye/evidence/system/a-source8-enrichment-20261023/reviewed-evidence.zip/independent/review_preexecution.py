"""Frozen source8/control evidence verification only; no science imports."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];S=D.parent/'g03-source8-enrichment-20261023'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
assert pin(S/'source-pins.json')['sha256']=='5bca4362ede0c889dd57441d65455664bf608ee27d1c1b729d36c49fa2a3b1cc'
assert pin(S/'source8_support.py')['sha256']=='2a43ec1c31cccb0235dad5e006df377e920576deedd1651fcaca668302323d32'
assert pin(S/'source8_stage.py')['sha256']=='cff37033737c13220e53549a02672ce5d56fe7259a7cbebcde4cbf0cc081cc5e'
assert pin(S/'controls-01/result.json')['sha256']=='c90a7c0eae82ad2d17c25724d9a95dd7cf5dd4b0fcea00cf111110b8a19f0506'
assert pin(S/'controls-01/terminal.json')['sha256']=='ed2d39a4c89b8390b38d977e25e725f8e6658838ec53858bf3129f30733b3b56'
frozen=read(S/'source-pins.json');control=read(S/'control-source-pins.json');assert frozen==control and len(frozen)==41
used=dict(frozen);assert all(pin(ROOT/n)==v for n,v in used.items())
inp=read(S/'input-pins.json');assert len(inp['files'])==32 and len(inp['headers'])==20
assert all(pin(ROOT/n)==v for n,v in inp['files'].items())
original=read(S/'red-source-pins.json')
for name in ['test_source8.py','source8_worker.py','run_source8.py']:
 k=(S/name).relative_to(ROOT).as_posix();assert original[k]==frozen[k]
assert pin(S/'red-support-source.txt')==original[(S/'source8_support.py').relative_to(ROOT).as_posix()]
expectations=[];stages=[]
for phase,exit_code in [('red',1),('controls',0)]:
 A=S/(phase+'-01');t=read(A/'terminal.json');rb=read(A/'input-readback.json');start=read(A/'started.json')
 assert t['exit_code']==exit_code and t['stop_reason'] is None and t['all_processes_terminated'] and t['active_processes_final']==0
 assert len(t['held_members'])==3 and all(h['signaled'] and h['wait_result']==0 for h in t['held_members'])
 assert rb['unchanged'] and rb['before']==rb['after']
 for stream in ['stdout','stderr']:assert pin(A/(stream+'.txt'))==t['logs'][stream]
 assert start['budget']['seconds']==60 and start['readback_limits']=={'job_memory_bytes':1024**3,'process_memory_bytes':512*1024**2,'active_processes':3}
 expectations.append(pin(A/'independent-expectations.json'))
 if phase=='red':assert read(A/'failure.json')['message']=='new Gauss8 source support not implemented'
 else:
  r=read(A/'result.json');assert r==json.loads((A/'stdout.txt').read_text()) and r['status']=='new_gauss8_controls_pass' and r['comparison_count']==111 and r['degree15_coordinate_checks']==96
  assert r['wrong_scale_and_sign_rejected'] and r['shared_edge_scatter'] and r['physical_primary_calls']==0 and r['old_tests_replayed']==0
  runtime=read(A/'worker-evidence.json')
  for key in ['runtime_before','runtime_after']:
   assert all(v['threads']==1 for v in runtime[key]['BLAS'])
   for v in runtime[key]['BLAS']:
    q=Path(v['path']);assert pin(q)['sha256']==v['sha256'];used[q.relative_to(ROOT).as_posix()]=pin(q)
 for q in A.iterdir():
  if q.is_file():used[q.relative_to(ROOT).as_posix()]=pin(q)
 stages.append({'phase':phase,'terminal':t,'argv':start['argv'],'budget':start['budget']})
assert expectations[0]==expectations[1]
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json');sh=hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest();assert sh=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json');assert transfer['status']=='active' and transfer['director_generation']==2
for q in [S/'source-pins.json',S/'control-source-pins.json',S/'red-source-pins.json',S/'control-review-handoff.json',S/'red-support-source.txt',ROOT/'docs/competition/deepeye-2026/immutable_scope.md',ROOT/'docs/competition/deepeye-2026/immutable_scope.json',ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json']:
 used[q.relative_to(ROOT).as_posix()]=pin(q)
save('preexecution-source-pins.json',used)
save('preexecution-review.json',{'status':'definitive_preexecution_review_no_blocking_findings','bounded_source8_attempt_acceptable_for_root_selection':True,'attempt_selected_by_reviewer':False,'new_scientific_execution_by_reviewer':0,'source_pins_sha256':pin(S/'source-pins.json')['sha256'],'source_pin_count':41,'used_pin_count':len(used),'controls':r,'expectations_identical_RED_GREEN':expectations[0],'stages':stages,'assessment':{'Gauss8_physical_V_over8_and_ij_layout':True,'unchanged_original_primary_and_256Tx':True,'single_new_32768target_primary_call_in_stage':True,'b8_f8_same_current_and_weights':True,'minus_iomega_once':True,'immutable_F4_and_saved_operator_actions_reused':True,'source_gate_precedes_ell8_and_selection':True,'only768source_incidences_new':True,'no_field_or_old_map_action_rebuilt':True,'no_new_matrix_or_solver':True,'strict_file_and_stdout_reporter':True},'limits':['Quadrature pair is not a physical/source true-error certificate.','No receiver/finite-strength/noise/OOD/training/product qualification.','New local control bound2048eps is distinct from unchanged128eps source-resolution arithmetic.'],'requirements_sha256':sh,'H01_H15_preserved':True,'root_retains':'one source-stage selection, acceptance and subsequent work','actual_result_review_pending':True})
print(json.dumps({'status':'preexecution_no_blocking_findings','used_pins':len(used),'new_controls_comparisons':111,'all6heldsignaled':True,'source_stage_executed_by_reviewer':False,'source_pins_sha256':pin(S/'source-pins.json')['sha256']}))
