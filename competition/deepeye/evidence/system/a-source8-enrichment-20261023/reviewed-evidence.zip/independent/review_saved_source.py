"""Distinct saved-data audit only: stdlib; no primary, quadrature, map or solve replay."""
import ast, hashlib, importlib.util, json, math, struct, sys
from pathlib import Path
D=Path(__file__).resolve().parent; ROOT=D.parents[2]
S=D.parent/'g03-source8-enrichment-20261023'; A=S/'source-01'
EPS=sys.float_info.epsilon; used={}; checks=[]
def pin(p):
 p=Path(p);return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def use(p):
 p=Path(p);used[p.relative_to(ROOT).as_posix()]=pin(p);return p
def read(p):return json.loads(use(p).read_text(encoding='utf-8'),parse_constant=lambda v:(_ for _ in ()).throw(ValueError(v)))
helper=ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py'
assert pin(helper)['sha256']=='a0aabdbf259f7232bf3e1e77a81d130a8f676ad0b87eba39fae99d118f858554'
sp=importlib.util.spec_from_file_location('review_reporter',use(helper));reporter=importlib.util.module_from_spec(sp);sp.loader.exec_module(reporter)
def save(name,value):reporter.write_new_report(D/name,value)
def npy(p):
 raw=use(p).read_bytes();assert raw[:6]==b'\x93NUMPY';major=raw[6]
 assert major in (1,2,3)
 start=10 if major==1 else 12; size=int.from_bytes(raw[8:start],'little')
 h=ast.literal_eval(raw[start:start+size].decode('latin1' if major<3 else 'utf8'))
 assert h['fortran_order'] is False
 data=raw[start+size:];kind=h['descr'];formats={'<f8':('d',8),'<i8':('q',8),'<i4':('i',4),'|b1':('?',1),'<c16':('dd',16)}
 fmt,unit=formats[kind];assert len(data)==math.prod(h['shape'])*unit
 out=[complex(*v) if kind=='<c16' else v[0] for v in struct.iter_unpack('<'+fmt,data)]
 assert all(math.isfinite(v.real) and math.isfinite(v.imag) if isinstance(v,complex) else math.isfinite(v) for v in out)
 return out,tuple(h['shape'])
def vec(name,shape=None):
 v,h=npy(A/(name+'.npy'));assert shape is None or h==shape;return v
inp=read(S/'input-pins.json')
def old(name):return npy(ROOT/inp['aliases'][name])[0]
frozen=read(S/'source-pins.json');assert len(frozen)==41
assert pin(S/'source-pins.json')['sha256']=='5bca4362ede0c889dd57441d65455664bf608ee27d1c1b729d36c49fa2a3b1cc'
assert all(pin(use(ROOT/n))==p for n,p in frozen.items())
rb=read(A/'input-readback.json');assert rb['unchanged'] and rb['before']==rb['after']==frozen
decision=read(D.parent/'g03-source8-main-review-20261023/source-selection.json')
assert decision['source_attempt_selected'] and decision['source_pins_sha256']==pin(S/'source-pins.json')['sha256']
assert decision['independent_preexecution_review']==pin(D/'preexecution-review.json')
assert read(S/'root-source-selection.json')==decision
r=read(A/'result.json');assert read(A/'stdout.txt')==r
t=read(A/'terminal.json');start=read(A/'started.json');runtime=read(A/'worker-evidence.json')
assert t['exit_code']==0 and t['stop_reason'] is None and t['all_processes_terminated'] and t['active_processes_final']==0
assert len(t['held_members'])==3 and all(x['signaled'] and x['wait_result']==0 and x['exit_code']==0 for x in t['held_members'])
assert t['seconds']<60 and t['peak_job_memory_bytes']<1024**3
assert start['readback_limits']=={'job_memory_bytes':1024**3,'process_memory_bytes':512*1024**2,'active_processes':3}
for name in ['stdout','stderr']:assert pin(use(A/(name+'.txt')))==t['logs'][name]
assert (A/'stderr.txt').stat().st_size==0
assert runtime['runtime_before']==runtime['runtime_after']
for dll in runtime['runtime_before']['BLAS']:
 assert dll['threads']==1 and pin(use(Path(dll['path'])))['sha256']==dll['sha256']
before=read(A/'before-source.json')
assert before['new_target_count']==32768 and before['target_source_pairs']==8388608 and before['inner_pairs']==32768
assert before['new_primary_calls_planned']==1 and before['PDE_solves']==before['old_source_calls']==0
assert before['physical_parameters']==read(ROOT/inp['aliases']['S1_assignment'])['inputs']
assert before['support_AABB_gap_m']>0 and before['sample_filament_distance_m']>0
p=before['physical_parameters'];omega=2*math.pi*p['frequency_Hz'];zeta=complex(p['sigma_background_Spm'],omega*p['epsilon_background_Fpm'])
ids=vec('cell_ids',(64,));bounds=vec('cell_bounds_m',(64,2,3));mapping=vec('cell_edge_map',(64,12))
assert ids==old('source_ids') and bounds==old('source_bounds') and mapping==old('source_mapping')
points=vec('new_target_points_m',(64,512,3));weights=vec('new_target_weights_m3',(64,512))
J=vec('equivalent_current_Apm2',(64,512,3));primary=vec('primary_E_Vpm',(64,512,3))
assert J==[zeta*v for v in primary] and min(weights)>0
b=vec('b8',(63250,));bs=vec('b8_absolute_product_scale',(63250,));local=vec('b8_local',(64,12));ls=vec('b8_local_absolute_product_scale',(64,12));delta=vec('delta_b8_minus_b4',(63250,));b4=old('b4')
assert delta==[x-y for x,y in zip(b,b4)]
support=set(old('source_support'));assert len(support)==300 and support==set(mapping)
B=old('B');assert all(b[i]==bs[i]==delta[i]==0 for i in B)
assert all(b[i]==bs[i]==delta[i]==0 for i in range(len(b)) if i not in support)
scatter=[0j]*len(b);scale=[0.]*len(b)
for j,g in enumerate(mapping):scatter[g]+=local[j];scale[g]+=ls[j]
assert scatter==b and scale==bs
checks.append({'name':'saved_coarse_scatter_support_delta_boundary_and_shared_current','pass':True,'source_edges':len(support),'global_edges':len(b),'boundary_edges':len(B)})
F=vec('F8',(113088,));Fs=vec('F8_absolute_product_scale',(113088,));F4=old('F4')
norm=max(map(abs,F));diff=max(abs(x-y) for x,y in zip(F,F4));floor=128*EPS*max(Fs);ratio=diff/norm
assert norm==r['source_high_inf'] and diff==r['source_difference_inf'] and floor==r['source_high_roundoff_threshold'] and ratio==r['source_pair_relative_inf']
assert norm>floor and ratio<=.001 and r['source_pair_gate']==.001 and r['source_pair_pass'] is True
checks.append({'name':'source_pair_from_saved_F8_F4','pass':True,'high_inf':norm,'difference_inf':diff,'roundoff_floor':floor,'relative_inf':ratio,'gate':.001})
def normalized(c,q):
 lo=bounds[c*6:c*6+3];hi=bounds[c*6+3:c*6+6]
 return [(points[(c*512+q)*3+j]-lo[j])/(hi[j]-lo[j]) for j in range(3)]
def csum(terms):return complex(math.fsum(v.real for v in terms),math.fsum(v.imag for v in terms))
coarse=[]
for c in (0,63):
 for a in range(3):
  transverse=[j for j in range(3) if j!=a]
  for second in (0,1):
   for first in (0,1):
    terms=[]
    for q in range(512):
     s=normalized(c,q);shape=1.
     for j,bit in zip(transverse,(first,second)):shape*=s[j] if bit else 1-s[j]
     terms.append(weights[c*512+q]*shape*J[(c*512+q)*3+a])
    value=-1j*omega*csum(terms);scale=omega*math.fsum(map(abs,terms));slot=a*4+2*second+first;k=c*12+slot
    bound=128*EPS*(scale+ls[k]);error=abs(value-local[k]);scale_error=abs(scale-ls[k])
    assert error<=bound and scale_error<=bound
    coarse.append({'source_row':c,'slot':slot,'error':error,'scale_error':scale_error,'bound':bound})
checks.append({'name':'distinct_24_coarse_load_moments_from_saved_J8_points_weights','pass':True,'cases':coarse})
keys=old('keys');cells=old('cells');source_index={v:i for i,v in enumerate(ids)}
sample={};touch=[];incidences=0
for i in range(len(F)):
 count=sum(cells[2*i+j] in source_index for j in (0,1));incidences+=count
 if count:
  touch.append(i);sample.setdefault((keys[5*i],keys[5*i+4],count),i)
 else:assert F[i]==Fs[i]==0
assert incidences==768
bubble=[]
for (n,tangent,count),i in sorted(sample.items()):
 assert count in (1,2);other=3-n-tangent;terms=[]
 for side in (0,1):
  cell=cells[2*i+side]
  if cell not in source_index:continue
  c=source_index[cell]
  for q in range(512):
   s=normalized(c,q);lam=s[n] if side==0 else 1-s[n];shape=lam*(4*s[other]*(1-s[other]))
   terms.append(weights[c*512+q]*shape*J[(c*512+q)*3+tangent])
 value=-1j*omega*csum(terms);scale=omega*math.fsum(map(abs,terms));bound=128*EPS*(scale+Fs[i]);error=abs(value-F[i]);scale_error=abs(scale-Fs[i])
 assert error<=bound and scale_error<=bound
 bubble.append({'index':i,'normal':n,'tangent':tangent,'source_cells':count,'error':error,'scale_error':scale_error,'bound':bound})
assert len(bubble)==12
checks.append({'name':'distinct_12_face_load_moments_from_same_saved_J8_points_weights','pass':True,'incidences':incidences,'touched_directions':len(touch),'cases':bubble})
ell=vec('ell8',(113088,));mass=old('mass');curl=old('curl')
assert ell==[f-m-k for f,m,k in zip(F,mass,curl)]
score=vec('score8',(113088,));resolved=vec('resolved8',(113088,));chosen=vec('tentative_selected_indices',(24,));ck=vec('tentative_selected_keys',(24,5));cc=vec('tentative_selected_cells',(24,2))
assert all(v>=0 for v in score) and all(resolved) and len(set(chosen))==24 and all(resolved[i] for i in chosen)
assert ck==[v for i in chosen for v in keys[i*5:i*5+5]] and cc==[v for i in chosen for v in cells[i*2:i*2+2]] and len(set(cc))==48
total=math.fsum(score[i] for i in range(len(score)) if resolved[i]);picked=math.fsum(score[i] for i in chosen);coverage=picked/total
assert abs(coverage-r['selected_score_fraction'])<=128*EPS*coverage and coverage<.5
assert r['selected_count']==24 and r['concentration_gate']==.5 and r['maximum_patches']==24 and r['resolution_margin_multiple']==10
assert r['candidate_defined'] is False and r['solver_selected'] is False and r['status']=='bounded_enrichment_not_supported'
assert not list(A.glob('selected_*.npy'))
assert r['global_operator_actions']==r['factorizations']==r['PDE_solves']==r['old_tests_replayed']==0 and r['original_GMRES_info']==3
checks.append({'name':'saved_ell_and_tentative_selection_consistency','pass':True,'resolved_probes':sum(resolved),'tentative_patches':len(chosen),'distinct_cells':len(set(cc)),'total_score_fsum':total,'selected_score_fsum':picked,'coverage_fsum':coverage,'reported_coverage':r['selected_score_fraction'],'gate':.5,'candidate_defined':False,'coupling_export_absent':True})
for q in A.iterdir():
 if q.is_file():use(q)
save('actual-source-audit.json',{'status':'saved_source_audit_pass','scientific_outcome':r['status'],'blocking_implementation_findings':[],'checks':checks,'terminal':t,'worker_runtime':runtime,'new_scientific_stages_by_reviewer':0,'distinct_saved_data_checks':'24 coarse and12 bubble moments from stored new points/current; no production imports, primary, quadrature generation, full map/operator or solve replay','controls_replayed':0,'acceptance':'root retained','physical_accuracy':'unqualified','G03':'not_run','R03':'not_run','all29':'not_run'})
save('actual-source-pins.json',used)
print(reporter.dumps_report({'status':'saved_source_audit_pass','checks':len(checks),'source_pair':ratio,'coverage':coverage,'candidate_defined':False,'used_pins':len(used)}),end='')
