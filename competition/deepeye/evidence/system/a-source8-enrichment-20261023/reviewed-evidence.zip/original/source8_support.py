"""New tensor Gauss8 rule and source-only lowest-order weak-load projection."""
import numpy as np
from numpy.polynomial.legendre import leggauss

def quadrature8(bounds):
    bounds=np.asarray(bounds,dtype=float)
    if bounds.ndim!=3 or bounds.shape[1:]!=(2,3) or not np.all(np.isfinite(bounds)):raise ValueError('bounds')
    h=bounds[:,1]-bounds[:,0]
    if np.any(h<=0):raise ValueError('positive widths')
    x,w=leggauss(8)
    unit=np.stack(np.meshgrid((x+1)/2,(x+1)/2,(x+1)/2,indexing='ij'),axis=-1).reshape(512,3)
    wx,wy,wz=np.meshgrid(w,w,w,indexing='ij');weight=(wx*wy*wz).reshape(512)/8
    return bounds[:,None,0]+h[:,None,:]*unit,np.prod(h,axis=1)[:,None]*weight

def project_coarse8(points,weights,current,bounds,mapping,nedges,omega):
    points=np.asarray(points);weights=np.asarray(weights);current=np.asarray(current);bounds=np.asarray(bounds);mapping=np.asarray(mapping)
    C=len(bounds)
    if points.shape!=(C,512,3) or weights.shape!=(C,512) or current.shape!=points.shape or mapping.shape!=(C,12):raise ValueError('Gauss8 source layout')
    if any(not np.all(np.isfinite(a)) for a in (points,weights,current,bounds)) or np.any(weights<=0):raise ValueError('finite positive source samples')
    if not np.issubdtype(mapping.dtype,np.integer) or np.any(mapping<0) or np.any(mapping>=nedges):raise ValueError('edge map')
    h=bounds[:,1]-bounds[:,0]
    if np.any(h<=0) or not np.isfinite(omega) or omega<=0:raise ValueError('physical parameters')
    s=(points-bounds[:,None,0])/h[:,None,:]
    if np.any(s<=0) or np.any(s>=1):raise ValueError('interior Gauss8 targets')
    local=np.empty((C,12),complex);local_scale=np.empty((C,12));slot=0
    for axis in range(3):
        transverse=[j for j in range(3) if j!=axis]
        for second in (0,1):
            for first in (0,1):
                shape=np.ones((C,512))
                for j,bit in zip(transverse,(first,second)):shape*=s[:,:,j] if bit else 1-s[:,:,j]
                terms=weights*shape*current[:,:,axis]
                local[:,slot]=-1j*omega*np.sum(terms,axis=1)
                local_scale[:,slot]=omega*np.sum(abs(terms),axis=1);slot+=1
    rhs=np.zeros(nedges,complex);scale=np.zeros(nedges)
    np.add.at(rhs,mapping.ravel(),local.ravel());np.add.at(scale,mapping.ravel(),local_scale.ravel())
    return rhs,scale,local,local_scale
