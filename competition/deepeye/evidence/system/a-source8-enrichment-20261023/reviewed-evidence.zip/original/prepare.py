"""Inert source/header freeze; no scientific imports or payload decoding."""
import ast,hashlib,json,struct,sys
from pathlib import Path
D=Path(__file__).resolve().parent;P=D.parent;ROOT=D.parents[2]
HELPER=ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py'
sys.path.insert(0,str(HELPER.parent));from evidence_json import write_new_report as save,dumps_report
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def header(p):
 with p.open('rb') as f:
  assert f.read(6)==b'\x93NUMPY';v=tuple(f.read(2));n=struct.unpack('<H' if v==(1,0) else '<I',f.read(2 if v==(1,0) else 4))[0]
  return ast.literal_eval(f.read(n).decode('latin1' if v[0]<3 else 'utf8'))
face=P/'g03-face-enrichment-20261023';s3=P/'g03-s3-json-continuation-20261021';s1=P/'g03-s1-cache-path-continuation-20261021'
assert pin(face/'manifest.json')['sha256']=='be76a5f5fd79c84e4396bea30fd7ce7214c62757c44c46eb63ab90c73ab0781c'
files={};aliases={}
def add(alias,path,expected=None):
 value=pin(path)
 if expected is not None:assert value==expected,(alias,value,expected)
 name=path.relative_to(ROOT).as_posix();files[name]=value
 if alias:aliases[alias]=name
fm=read(face/'manifest.json')['files'];sm=read(s3/'manifest.json')['files']
add(None,face/'manifest.json');add(None,s3/'manifest.json')
for n in ('face_probe_geometry.py','face_probe_moments.py','face_probe_selection.py'):add(None,face/n,fm[n])
for n in ('keys','cells','mass','curl','mass_scale','curl_scale','F4','F4_scale','Mq','Kq'):
 rel='indicator-01/'+n+'.npy';add(n,face/rel,fm[rel])
for alias,n in [('source_ids','cell_ids'),('source_bounds','cell_bounds_m'),('source_mapping','cell_edge_map'),('source_support','potential_edge_support'),('b4','g4_projected_full_RHS')]:
 rel='projection-01/'+n+'.npy';add(alias,s3/rel,sm[rel])
old=read(P/'g03-consistent-solve-20261023/input-pins.json')
for alias in ('bounds','mapping','B','starts','ends','L5_assignment','S1_assignment'):
 n=old['paths'][alias];add(alias,ROOT/n,old['files'][n])
s1pins=read(s1/'manifest.json')['files'];add(None,s1/'s1_geometry.py',s1pins['s1_geometry.py'])
for path in [HELPER,P/'r02-amd-wheel-acquisition-20261021/win_job.py',P/'r02-amd-wheel-acquisition-20261021/boundary.py',ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe']:add(None,path)
assert pin(HELPER)['sha256']=='a0aabdbf259f7232bf3e1e77a81d130a8f676ad0b87eba39fae99d118f858554'
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
assert hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json');assert transfer['status']=='active' and transfer['director_generation']==2
headers={a:header(ROOT/n) for a,n in aliases.items() if n.endswith('.npy')}
assert headers['source_bounds']['shape']==(64,2,3) and headers['source_ids']['shape']==(64,) and headers['source_mapping']['shape']==(64,12)
assert headers['keys']['shape']==(113088,5) and headers['cells']['shape']==(113088,2) and headers['b4']['shape']==(63250,)
save(D/'input-pins.json',{'files':files,'aliases':aliases,'headers':headers,'payloads_decoded':0,'canonical_scope_verified':True,'reporter_byte_exact':True})
print(dumps_report({'status':'inert_preflight_pass','pins':len(files),'headers':len(headers)}),end='')
