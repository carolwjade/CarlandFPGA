"""Only new Gauss8 rule and common coarse/bubble source normalization."""
import math,sys
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from evidence_json import write_new_report as save
import source8_support as support
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'g03-face-enrichment-20261023'))
from face_probe_moments import source_action
EPS=np.finfo(float).eps
def run(stage):
 # Rational tensor moments are independent of any Gaussian node generator.
 expected=[F(1,k+1) for k in range(16)]
 save(stage/'independent-expectations.json',{'unit_monomial_integrals':[str(x) for x in expected],'physical_bounds_rational':[['1/10','-1/5','3/10'],['13/100','-4/25','37/100']],'omega':7,'current_powers':[3,4,5],'coarse_transverse_basis':'first bit fastest','bubble_normal':0,'bubble_tangent':1,'bubble_side':0})
 bounds=np.array([[[.1,-.2,.3],[.13,-.16,.37]],[[.13,-.2,.3],[.18,-.16,.37]]])
 points,weights=support.quadrature8(bounds)
 assert points.shape==(2,512,3) and weights.shape==(2,512) and np.all(weights>0)
 h=bounds[:,1]-bounds[:,0];volume=np.prod(h,axis=1);s=(points-bounds[:,None,0])/h[:,None,:]
 errors=[]
 def check(actual,exact,scale):
  err=float(np.max(abs(np.asarray(actual)-np.asarray(exact)),initial=0));bound=2048*EPS*float(np.max(np.asarray(scale),initial=0))
  assert err<=bound,(err,bound);errors.append(err)
 check(weights.sum(axis=1),volume,volume)
 # x is slowest, z fastest; each marginal matches the independent P8 equation.
 grid=s.reshape(2,8,8,8,3)
 for c in range(2):
  nodes=grid[c,:,0,0,0];assert np.all(np.diff(nodes)>0)
  check(grid[c,:,:,:,0],np.broadcast_to(nodes[:,None,None],(8,8,8)),1)
  check(grid[c,:,:,:,1],np.broadcast_to(nodes[None,:,None],(8,8,8)),1)
  check(grid[c,:,:,:,2],np.broadcast_to(nodes[None,None,:],(8,8,8)),1)
  x=2*nodes-1;terms=np.stack([6435*x**8,-12012*x**6,6930*x**4,-1260*x**2,np.full(8,35.)])/128
  check(terms.sum(axis=0),0,np.sum(abs(terms),axis=0))
  derivative=(51480*x**7-72072*x**5+27720*x**3-2520*x)/128
  marginal=weights[c].reshape(8,8,8).sum(axis=(1,2))/volume[c]
  check(marginal,1/((1-x*x)*derivative**2),1)
  for axis in range(3):
   for k in range(16):check(np.sum(weights[c]*s[c,:,axis]**k),volume[c]*float(expected[k]),volume[c])
 # One manufactured polynomial, integrated by the new physical rule for both loads.
 powers=(3,4,5);amplitudes=np.array([1+2j,-2+.5j,3-1j]);omega=7.
 scalar=np.prod(s**np.array(powers),axis=2);current=scalar[:,:,None]*amplitudes
 # Adjacent x cells share four transverse edges (two y, two z), never x edges.
 mapping=np.arange(24,dtype=np.int32).reshape(2,12)
 for left,right in [(5,4),(7,6),(9,8),(11,10)]:mapping[1,right]=mapping[0,left]
 b8,scales,local,local_scales=support.project_coarse8(points,weights,current,bounds,mapping,24,omega)
 exact=np.zeros((2,12),complex)
 for axis in range(3):
  transverse=[j for j in range(3) if j!=axis]
  for second in (0,1):
   for first in (0,1):
    moment=expected[powers[axis]]
    for j,bit in zip(transverse,(first,second)):
     moment*=F(1,powers[j]+2) if bit else F(1,powers[j]+1)-F(1,powers[j]+2)
    exact[:,4*axis+2*second+first]=-1j*omega*amplitudes[axis]*volume*float(moment)
 check(local,exact,abs(exact));scatter=np.zeros(24,complex);np.add.at(scatter,mapping.ravel(),exact.ravel());check(b8,scatter,abs(scatter))
 assert np.all(scales>=abs(b8)*(1-2048*EPS)) and np.all(local_scales>=abs(local)*(1-2048*EPS))
 bubbles=[]
 for side in (0,1):
  f,fs=source_action(points,weights,current,bounds,0,1,side,omega)
  pn,pt,pb=powers;normal=F(1,pn+2) if side==0 else F(1,pn+1)-F(1,pn+2)
  exactq=-1j*omega*amplitudes[1]*volume*float(normal*F(1,pt+1)*4*(F(1,pb+2)-F(1,pb+3)))
  check(f,exactq,abs(exactq));assert np.all(fs>=abs(f)*(1-2048*EPS));bubbles.append(f)
 # Perturb only new loads: wrong physical Jacobian and wrong source sign must fail.
 assert np.max(abs(local/volume[:,None]-exact))>1e6*EPS*np.max(abs(exact))
 assert np.max(abs(-local-exact))>1e6*EPS*np.max(abs(exact))
 return {'status':'new_gauss8_controls_pass','synthetic_cells':2,'quadrature_points_per_cell':512,'degree15_coordinate_checks':96,'new_manufactured_load_case':1,'coarse_components':3,'shared_edge_scatter':True,'bubble_sides':2,'wrong_scale_and_sign_rejected':True,'comparison_count':len(errors),'maximum_absolute_error':max(errors),'old_tests_replayed':0,'physical_primary_calls':0}
