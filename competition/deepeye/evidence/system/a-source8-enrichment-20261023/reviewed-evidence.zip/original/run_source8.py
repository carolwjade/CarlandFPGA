"""Single-attempt new stages using the unchanged held Win32 guard."""
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];SUPPORT=D.parent/'r02-amd-wheel-acquisition-20261021';PY=ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'
sys.path.insert(0,str(ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools'))
from evidence_json import write_new_report as save,dumps_report
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def pins():
 p=read(D/'input-pins.json')['files'];assert all(pin(ROOT/n)==v for n,v in p.items())
 for f in D.glob('*.py'):p[f.relative_to(ROOT).as_posix()]=pin(f)
 for n in ('input-pins.json','assignment.md','design.md'):p[(D/n).relative_to(ROOT).as_posix()]=pin(D/n)
 return p
def main():
 mode=sys.argv[1];assert mode in ('red','controls','source');before=pins();stage=D/(mode+'-01')
 if mode=='red':save(D/'red-source-pins.json',before)
 elif mode=='controls':
  assert read(D/'red-01/expected-red.json')['expected_missing_gauss8']
  old=read(D/'red-source-pins.json')
  for n in ('source8_worker.py','run_source8.py','test_source8.py'):
   k=(D/n).relative_to(ROOT).as_posix();assert old[k]==before[k]
  save(D/'control-source-pins.json',before)
 else:
  decision=read(D/'root-source-selection.json')
  assert decision['source_attempt_selected'] is True and decision['source_pins_sha256']==pin(D/'source-pins.json')['sha256']
  assert before==read(D/'source-pins.json')==read(D/'control-source-pins.json')
  assert read(D/'controls-01/result.json')['status']=='new_gauss8_controls_pass' and read(D/'controls-01/terminal.json')['status']=='success'
 sys.path.insert(0,str(SUPPORT));from win_job import run_bounded,process_identity
 env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),'PATH':'','TEMP':str(stage),'TMP':str(stage),'TMPDIR':str(stage),'MPLCONFIGDIR':str(stage/'mplconfig'),'MPLBACKEND':'Agg','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',**{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS')}}
 budget={'seconds':60,'active_processes':3,'process_memory_bytes':512*1024**2,'job_memory_bytes':1024**3,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':64*1024**2,'tree_entries':1024,'free_reserve_bytes':512*1024**2}
 granted=False
 def tick(job,pids):
  nonlocal granted
  if (stage/'hello.json').exists() and not granted:
   h=read(stage/'hello.json');assert h['pid'] in pids and h['mode']==mode
   save(stage/'grant.pending.json',{'worker':process_identity(h['pid'],job),'mode':mode});os.replace(stage/'grant.pending.json',stage/'grant.json');granted=True
 result=run_bounded([str(PY),'-I','-B','-X','utf8',str(D/'source8_worker.py'),str(stage),mode],env,D,stage,budget,[D],on_tick=tick)
 after=pins();save(stage/'input-readback.json',{'unchanged':before==after,'before':before,'after':after});assert before==after and result['all_processes_terminated']
 if mode=='red':
  f=read(stage/'failure.json');assert result['exit_code']==1 and result['stop_reason'] is None and f['type']=='NotImplementedError' and f['message']=='new Gauss8 source support not implemented'
  save(stage/'expected-red.json',{'expected_missing_gauss8':True,'original_exit_code':1,'old_tests_repeated':False})
 print(dumps_report({k:result.get(k) for k in ('status','exit_code','seconds','stop_reason','peak_job_memory_bytes','all_processes_terminated','held_members')}),end='',flush=True)
 return 0 if mode=='red' else result['exit_code'] if result['exit_code'] is not None else 125
if __name__=='__main__':raise SystemExit(main())
