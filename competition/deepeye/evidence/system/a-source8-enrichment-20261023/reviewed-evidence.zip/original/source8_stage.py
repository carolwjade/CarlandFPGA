"""One new source-only Gauss8 pass; saved face map/operator actions reused."""
import hashlib,json,math,sys
from pathlib import Path
import numpy as np
from evidence_json import write_new_report as save
import source8_support as support
D=Path(__file__).resolve().parent;P=D.parent;ROOT=D.parents[2];EPS=np.finfo(float).eps
sys.path.insert(0,str(P/'g03-face-enrichment-20261023'))
import face_probe_moments as moments
import face_probe_selection as selection
sys.path.insert(0,str(P/'g03-s1-cache-path-continuation-20261021'))
import s1_geometry
def read(p):return json.loads(p.read_text(encoding='utf8'))
def path(alias):
 spec=read(D/'input-pins.json');name=spec['aliases'][alias];p=ROOT/name;h=hashlib.sha256(p.read_bytes()).hexdigest()
 if h!=spec['files'][name]['sha256'] or p.stat().st_size!=spec['files'][name]['bytes']:raise ValueError('input pin '+alias)
 return p
def load(alias):
 value=np.load(path(alias),allow_pickle=False)
 if not np.all(np.isfinite(value)):raise ValueError('nonfinite input '+alias)
 return value
def array(stage,name,value):
 if not np.all(np.isfinite(value)):raise ValueError('nonfinite output '+name)
 with (stage/(name+'.npy')).open('xb') as f:np.save(f,value,allow_pickle=False)
def source_geometry(ids,bounds,mapping,full_bounds,full_mapping,starts,ends,assignment,p):
 if ids.shape!=(64,) or not np.issubdtype(ids.dtype,np.integer) or len(np.unique(ids))!=64 or np.any(np.diff(ids)<=0):raise ValueError('64 ordered source IDs')
 if bounds.shape!=(64,2,3) or mapping.shape!=(64,12) or not np.array_equal(bounds,full_bounds[ids]) or not np.array_equal(mapping,full_mapping[ids]):raise ValueError('source map/bounds identity')
 nodes=[np.array(assignment['level']['x_nodes_m']),np.array(assignment['level']['x_nodes_m']),np.array(assignment['z_nodes_m'])]
 actual=[np.r_[v[0],np.diff(v)].cumsum() for v in nodes];sub=np.column_stack((ids%24,(ids//24)%24,ids//576))
 for j in range(3):
  if not np.array_equal(bounds[:,0,j],nodes[j][sub[:,j]]) or not np.array_equal(bounds[:,1,j],nodes[j][sub[:,j]+1]):raise ValueError('nominal source bounds')
 slot=0
 for axis in range(3):
  transverse=[j for j in range(3) if j!=axis]
  for second in (0,1):
   for first in (0,1):
    lo=np.column_stack([actual[j][sub[:,j]] for j in range(3)]);hi=lo.copy();hi[:,axis]=actual[axis][sub[:,axis]+1]
    for j,bit in zip(transverse,(first,second)):lo[:,j]=hi[:,j]=actual[j][sub[:,j]+bit]
    if not np.array_equal(starts[mapping[:,slot]],lo) or not np.array_equal(ends[mapping[:,slot]],hi):raise ValueError('actual source edge endpoints')
    slot+=1
 low=np.array(p['contrast_box_min_m']);high=np.array(p['contrast_box_max_m'])
 if not np.array_equal(bounds[:,0].min(axis=0),low) or not np.array_equal(bounds[:,1].max(axis=0),high):raise ValueError('fixed source extent')
 volume=np.prod(bounds[:,1]-bounds[:,0],axis=1).sum()
 if abs(volume-np.prod(high-low))>128*EPS*np.prod(high-low):raise ValueError('source volume')
 return low,high
def run(stage):
 ids=load('source_ids');bounds=load('source_bounds');mapping=load('source_mapping');full_bounds=load('bounds');full_mapping=load('mapping');B=load('B')
 p=read(path('S1_assignment'))['inputs'];low,high=source_geometry(ids,bounds,mapping,full_bounds,full_mapping,load('starts'),load('ends'),read(path('L5_assignment')),p)
 keys=load('keys');cells=load('cells');N=len(keys)
 if keys.shape!=(113088,5) or cells.shape!=(N,2):raise ValueError('saved face layout')
 lookup=np.full(19584,-1,np.int32);lookup[ids]=np.arange(64);incidences=int(np.count_nonzero(lookup[cells]>=0))
 if incidences!=768:raise ValueError('fixed source patch incidences')
 tx,_=s1_geometry.selected_coils(p);gap=s1_geometry.assert_separated_boxes((low,high),tx.bounds())
 omega=2*math.pi*p['frequency_Hz'];zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm'];mu=p['mu_background_Hpm'];coeff=1j*omega*zeta
 points,weights=support.quadrature8(bounds)
 if points.shape!=(64,512,3) or weights.shape!=(64,512):raise ValueError('fixed new target count')
 separation=s1_geometry.assert_nonsingular(points.reshape(-1,3),tx)
 save(stage/'before-source.json',{'new_target_count':32768,'Tx_quadrature_count':256,'target_source_pairs':8388608,'accepted_kernel_target_chunk':128,'inner_pairs':32768,'source_cell_count':64,'source_patch_incidences':incidences,'support_AABB_gap_m':gap,'sample_filament_distance_m':separation,'nominal_bounds_actual_endpoint_identity':True,'physical_parameters':p,'new_primary_calls_planned':1,'old_source_calls':0,'PDE_solves':0})
 primary=s1_geometry.primary(points.reshape(-1,3),tx,p,256).reshape(64,512,3)
 current=zeta*primary
 b8,b8scale,local,local_scale=support.project_coarse8(points,weights,current,bounds,mapping,63250,omega)
 support_ids=load('source_support')
 if len(support_ids)!=300 or not np.array_equal(np.unique(mapping),support_ids):raise ValueError('300-edge source support')
 mask=np.zeros(63250,bool);mask[support_ids]=True
 if np.any(b8[~mask]!=0) or np.any(b8scale[~mask]!=0) or np.any(b8[B]!=0) or np.any(b8scale[B]!=0):raise ValueError('source support or full boundary zero')
 b4=load('b4');delta=b8-b4
 if np.any(delta[~mask]!=0) or np.any(delta[B]!=0):raise ValueError('delta boundary/support')
 F8=np.zeros(N,complex);F8scale=np.zeros(N);visited=0
 for n in range(3):
  for t in range(3):
   if n==t:continue
   for side in (0,1):
    selected=np.flatnonzero((keys[:,0]==n)&(keys[:,4]==t)&(lookup[cells[:,side]]>=0))
    for first in range(0,len(selected),128):
     index=selected[first:first+128];s=lookup[cells[index,side]]
     value,scale=moments.source_action(points[s],weights[s],current[s],bounds[s],n,t,side,omega)
     F8[index]+=value;F8scale[index]+=scale;visited+=len(index)
 if visited!=768:raise ValueError('source incidence accounting')
 # Preserve all new source output before the source gate, ell8, or selection.
 for name,value in {'cell_ids':ids,'cell_bounds_m':bounds,'cell_edge_map':mapping,'new_target_points_m':points,'new_target_weights_m3':weights,'primary_E_Vpm':primary,'equivalent_current_Apm2':current,'b8':b8,'b8_absolute_product_scale':b8scale,'b8_local':local,'b8_local_absolute_product_scale':local_scale,'delta_b8_minus_b4':delta,'F8':F8,'F8_absolute_product_scale':F8scale}.items():array(stage,name,value)
 F4=load('F4');F4scale=load('F4_scale');high_norm=float(np.max(abs(F8)));floor=128*EPS*float(np.max(F8scale));difference=float(np.max(abs(F8-F4)));stable=high_norm>floor;pair=difference/high_norm if stable else None;passed=bool(stable and pair<=.001)
 result={'status':'source_action_unresolved','source_pair_pass':passed,'source_pair_relative_inf':pair,'source_pair_gate':.001,'source_high_inf':high_norm,'source_difference_inf':difference,'source_high_roundoff_threshold':floor,'source_cell_count':64,'new_primary_targets':32768,'new_primary_calls':1,'Tx_quadrature_count':256,'source_patch_incidences':visited,'b8_and_F8_share_current':True,'source_factor':'-i omega exactly once','b8_support_edges':300,'b8_and_delta_boundary_zero':True,'future_coarse_load':'use b8; saved candidate was solved with b4; delta_b8_minus_b4 retained','selection_called':False,'ell8_formed':False,'candidate_defined':False,'selected_count':0,'original_GMRES_info':3,'old_tests_replayed':0,'old_source_targets_reevaluated':0,'full_face_operator_recomputed':False,'global_operator_actions':0,'factorizations':0,'PDE_solves':0,'physical_receiver_gate':.01,'physical_receiver_screens':'not_run','physical_accuracy':'unqualified','finite_tau_noise_OOD_training':'not_run','G03':'not_run','R03':'not_run','all29':'not_run','pair_is_not_true_error_bound':True}
 if not passed:return result
 # Only this passed new source pair authorizes a new residual/selection.
 mass=load('mass');curl=load('curl');Mq=load('Mq');Kq=load('Kq');ell=F8-mass-curl;diag=Kq/mu+coeff*Mq;energy=Kq/mu+abs(coeff)*Mq
 scale=F4scale+F8scale+load('mass_scale')+load('curl_scale')
 out=selection.select(keys,cells,ell,energy,F4,F8,scale,F8scale);chosen=out['selected_indices']
 if not out['result']['source_pair_pass']:raise ArithmeticError('source gate disagreement')
 for name,value in {'ell8':ell,'arithmetic_scale8':scale,'positive_energy_diagonal':energy,'resolution_margin8':out['margin'],'score8':out['score'],'resolved8':out['resolved'],'tentative_selected_indices':chosen,'tentative_selected_keys':keys[chosen],'tentative_selected_cells':cells[chosen]}.items():array(stage,name,value)
 result.update(out['result']);result.update({'selection_called':True,'ell8_formed':True})
 if result['candidate_defined']:
  # Selected local columns only; no field read or operator action is needed.
  Uids=np.empty((len(chosen),20),np.int32);U=np.empty((len(chosen),20),complex)
  for row,index in enumerate(chosen):
   n=int(keys[index,0]);t=int(keys[index,4]);merged={}
   for side in (0,1):
    cell=cells[index,side];bb=full_bounds[cell];lm=moments.local_moments((bb[1]-bb[0])[None,:],n,t,side);values=lm['K'][0]/mu+coeff*lm['M'][0]
    for gid,value in zip(full_mapping[cell],values):merged[int(gid)]=merged.get(int(gid),0j)+value
   ordered=sorted(merged)
   if len(ordered)!=20:raise ValueError('selected two-cell edge union')
   Uids[row]=ordered;U[row]=[merged[j] for j in ordered]
  for name,value in {'selected_U_edge_ids':Uids,'selected_U_values':U,'selected_D':diag[chosen],'selected_fQ8':F8[chosen],'selected_ell8':ell[chosen],'selected_keys':keys[chosen],'selected_cells':cells[chosen]}.items():array(stage,name,value)
  result.update({'selected_coupling_entries':int(U.size),'complex_transpose':'ordinary, no conjugation','boundary_treatment':'bubble tangential trace zero on outer boundary; retain full U edge IDs; future coarse RHS b8_I-A_IB*gB and bubble RHS fQ8-U_B^T*gB require separate consistent boundary adjustments'})
 return result
