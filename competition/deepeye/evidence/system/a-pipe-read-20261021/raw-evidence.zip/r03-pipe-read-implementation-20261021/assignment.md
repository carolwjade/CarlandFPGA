# A-R03-PIPE-READ-IMPLEMENTATION-20261021-v1

Main selects the following local dependency under the existing human task, after
reviewing the 33-source dependency map and original win32.py:268-302 and
actor_owner.py:403-417. This replaces the proposed framing implementation for
this next task. The dependency map remains valid reference material; do not edit it.

Read installed fpga-multi-node skill/node-A role, immutable Markdown/JSON and
active generation-2 transfer. Verify DEEPEYE-HUMAN-LOCK-20261014/revision1 hash
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
H01-H15 are unchanged. Native validate this new job before work.

## Main-selected design and ownership

Existing `win32.available_output()` returns b'' both for an open empty anonymous
pipe and ERROR_BROKEN_PIPE. That behavior is intentional enough for discarded
cleanup diagnostics, but cannot supply explicit EOF to a future persistent
completion pump. A new private framing protocol would require actual producer
agreement that is not yet available. Choose a small typed native read component
first, using the existing Windows API bindings and no new IPC byte protocol.

Own this task evidence directory and exactly three NEW product-relative files:

- competition/deepeye/simulation/isolation/pipe_read.py
- competition/deepeye/tests/simulation/test_pipe_read.py
- competition/deepeye/docs/pipe_read_boundary.md

Main checks these are absent when reserving. Do not edit existing win32 helpers,
ActorOwner, READY/EXIT, authority/completion/mailbox, C, host/wire ABI, UI or factories.
No production call site imports the new component in this task. No commit/push.
No board/service/driver/OS changes, model/vendor invocation, network or peer sends.
All software and process launches remain hidden; do not use the human's display.

Provide `poll_output(handle, max_bytes=8192)` with a small immutable result
containing an explicit state (data, empty, eof) and bytes. Diagnostic result
construction grants no ownership/authentication/liveness or completion authority.
Exact non-bool positive int handle, exact int max_bytes in 1..8192, reject invalid
arguments before any native call. It reads from a caller-owned original anonymous
pipe read endpoint; it does not reopen by PID/name or adopt/mint a capability.

One PeekNamedPipe call and at most one ReadFile call per invocation. A successful
zero-available peek returns empty without ReadFile. Positive available data reads
at most min(available,max_bytes); never write or wait for more data. Actual bytes
must be nonempty and no longer than requested. A broken-pipe error (109) from
peek or the following read returns eof; other native errors remain errors.
Do not silently turn invalid handle/access/unexpected zero read into empty/health.
Use the existing bindings or narrowly factored code without changing old functions.

Document that this distinguishes observed native pipe states under one original
reader; it is not a hard elapsed-time/cancellation guarantee. Native calls still
have OS scheduling behavior, single-reader use is a caller obligation, and empty
or data does not prove responsive/valid inference. Concurrent other readers and
arbitrary endpoint claims are not legitimized. Future EOF must retire its own
provider/owner epoch before any admission, but this leaf performs no teardown,
authority calls, timestamping or lifecycle transitions.

## Verification

Use focused tests and retain genuine RED before implementation. Review relevant
installed testing/debugging skills. Prefer a small test class with decisive
controls rather than a broad old suite rerun.

1. Native-call controls distinguish empty/data/eof, enforce max read size and
   at most one peek/read, reject input types/limits before native calls.
2. Verify native errors other than109 propagate, a 109 read race maps to eof,
   and unexpected zero/oversized/type-invalid read results fail explicitly.
3. A hidden owned test process creates real local anonymous pipes, keeps original
   handles, observes open-empty, writes a bounded payload smaller than pipe
   capacity, reads exact data in bounded pieces, closes the last write endpoint,
   then observes eof. Ensure writer close and read ordering are explicit and all
   actual handle cleanup is recorded. Use no unbounded synchronous write.
   A ~9000-byte payload under the existing 16384-byte pipe capacity can exercise
   the8192 ceiling; a smaller payload with max_bytes3 is also sufficient.
4. Test an actually invalid/closed read handle as an error without confusing
   native handle reuse; mocked error controls are separate from native evidence.
5. New module outputs plain diagnostic state/bytes and has no authority/model/
   clock imports or production wiring. Rehash adopted owner/factory/runtime/
   executor and existing native helpers before/after; existing source bytes must
   remain unchanged.

Use an already reviewed hidden bounded runner copied into this task directory,
fixed modest stdout/stderr/files/process/time limits, exact interpreter/source
pins, and held-object process closure. The test runner may own only test-created
pipes/processes. Do not run the real actor/model, connect existing endpoints,
relax the runner, create a parallel executor or terminate unrelated processes.
Any failure/unknown side effect is retained without blind replay. If native
verification needs a source-level adjustment, explain it and keep exact versions.

Deliver report.md, source pins, raw results/receipts, public non-secret manifest,
and exact final-result.txt. Complete the original job with native_lease_guard
only after work is frozen, then stop writing. Main obtains independent review
and decides integration/publication. All real completion IPC, original dispatch,
BOOT/source/clock/slot, PC_DIRECT/HIL/UI and formal R03/all29 remain not_run.
