# Selected typed anonymous-pipe read leaf

Implement only the three new product files assigned by main. Preserve all
existing helpers, actor/authority/factory/ABI/READY bytes. Main selected native
state observation before framing; no new message format or completion verifier.

API: frozen `PipeReadResult(state: str, data: bytes)` and
`poll_output(handle, max_bytes=8192)`. Validate exact positive int handle fitting
the current unsigned native pointer width (avoid ctypes truncation); exact int
max_bytes1..8192. Invalid inputs cannot load/call native bindings. Lazy-load the
existing win32 module only after argument checks. One PeekNamedPipe; zero bytes
means empty without reading. Otherwise call existing read once for
min(available,max_bytes); accept only nonempty exact bytes no longer than request.
Only OSError.winerror109 maps to eof at either native operation; other errors
propagate unchanged. Unexpected zero/invalid native data refuses explicitly.

The result grants no ownership/authentication/life/completion authority. Calls
assume a caller-owned original endpoint and sole reader. No hard elapsed-time or
cancellation claim; a concurrent reader can invalidate the peek/read assumption.
No close, write, timestamp, wait, teardown or authority call occurs in this leaf.

TDD: retain a focused RED suite before module creation. Same exact test source
then runs controls for argument checks, call/size limits, error mapping and
invalid results, plus actual owned anonymous pipes with small bounded writes,
explicit write-close/read ordering, data/empty/eof and immediately closed handle
error6. Save original handle cleanup results and process held-handle termination.
Use exact reviewed hidden bounded runner; do not retry unknown effects.

After GREEN, rehash baseline dependencies and tested imports, statically check
no production consumer, document residual limits, freeze manifest, complete the
original job once/read back exact terminal, then stop writes. Main independently
reviews before integration. All completion/provider/H12/formal layers not_run.
