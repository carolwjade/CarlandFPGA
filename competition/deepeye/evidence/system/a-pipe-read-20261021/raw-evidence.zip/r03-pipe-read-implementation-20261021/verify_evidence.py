import ast,difflib,hashlib,json,marshal
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=ROOT/'.local/deepeye-implementation-a/competition/deepeye'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def save(n,v):(D/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
inputs=load(D/'input-pins.json')
for n,pin in inputs['existing_product_sources'].items():assert sha(P/n)==pin['sha256'],n
for n,h in inputs['mandatory'].items():assert sha(ROOT/n)==h,n
new={n:{'bytes':(P/n).stat().st_size,'sha256':sha(P/n)} for n in inputs['new_owned_product_paths']}
runs={}
for label in ['red-01','green-01','green-02']:
 r=load(D/label/'terminal.json');assert r['all_processes_terminated'] and r['active_processes_final']==0
 assert len(r['held_members'])==3 and all(x['signaled'] and x['wait_result']==0 for x in r['held_members'])
 runs[label]=r
red=load(D/'red-01/test-result.json');green=load(D/'green-02/test-result.json')
assert red['testsRun']==12 and len(red['failures'])==12 and not red['errors']
assert green['testsRun']==12 and green['successful'] and not any(green[n] for n in ['failures','errors','skipped','prohibited_attempts'])
assert runs['red-01']['exit_code']==1 and runs['green-01']['exit_code']==1 and runs['green-02']['exit_code']==0
assert not (D/'green-01/test-result.json').exists()
err=(D/'green-01/process/stderr.txt').read_text(encoding='utf-8');assert 'Ran 12 tests' in err and 'OK' in err and 'c_void_p is not JSON serializable' in err
assert len(green['native_pipe_evidence'])==3
closes=0
for row in green['native_pipe_evidence']:
 assert row['cleanup_complete']
 created={e['created']:e['original_handle'] for e in row['events'] if 'created' in e}
 closed={e['closed']:e for e in row['events'] if 'closed' in e}
 assert set(created)==set(closed)=={'read','write'}
 assert all(e['success'] and e['original_handle']==created[k] for k,e in closed.items());closes+=len(closed)
native=json.dumps(green['native_pipe_evidence'])
assert 'closed_read_error' in native
def tree(p):return ast.parse(p.read_bytes())
def methods(p):
 c=next(n for n in tree(p).body if isinstance(n,ast.ClassDef) and n.name=='PipeReadTests')
 return {n.name:ast.dump(n,include_attributes=False) for n in c.body if isinstance(n,ast.FunctionDef)}
n='tests/simulation/test_pipe_read.py';old=methods(D/'red-01/source-snapshots'/n);current=methods(P/n)
names=[n for n in old if n.startswith('test_')];assert len(names)==12
assert all(old[n]==current[n] for n in names)
assert {n for n in old if old[n]!=current[n]}=={'open_pipe'}
for n in inputs['new_owned_product_paths']:
 assert sha(P/n)==sha(D/'green-02/source-snapshots'/n)
assert sha(P/'simulation/isolation/pipe_read.py')==sha(D/'green-01/source-snapshots/simulation/isolation/pipe_read.py')
diff=''.join(difflib.unified_diff((D/'green-01/source-snapshots/tests/simulation/test_pipe_read.py').read_text(encoding='utf-8').splitlines(True),(P/'tests/simulation/test_pipe_read.py').read_text(encoding='utf-8').splitlines(True),fromfile='green-01/test_pipe_read.py',tofile='green-02/test_pipe_read.py'))
(D/'fixture-correction.diff').write_text(diff,encoding='utf-8')
pycs={}
for name,pin in green['imports_and_reads'].items():
 p=Path(name);assert sha(p)==pin['sha256'] and p.stat().st_size==pin['bytes'],name
 if p.suffix=='.pyc':
  code=marshal.loads(p.read_bytes()[16:]);src=Path(code.co_filename)
  if src.is_file():
   assert code==compile(src.read_bytes(),code.co_filename,'exec',dont_inherit=True,optimize=0)
   pycs[name]={'source':str(src),'source_sha256':sha(src),'cached_code_equals_source':True}
module=tree(P/'simulation/isolation/pipe_read.py')
imports=[ast.unparse(n) for n in ast.walk(module) if isinstance(n,(ast.Import,ast.ImportFrom))]
assert imports==['from dataclasses import dataclass','import struct','from . import win32']
poll=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='poll_output')
assert not any(isinstance(n,(ast.For,ast.While,ast.AsyncFor)) for n in ast.walk(poll))
assert sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='PeekNamedPipe' for n in ast.walk(poll))==1
assert sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='read' for n in ast.walk(poll))==1
consumers=[]
for area in ['simulation/isolation','simulation/authority','integration','tools','ai_pc']:
 for p in (P/area).rglob('*.py'):
  if p.name.startswith('test_') or p.name=='pipe_read.py':continue
  if 'pipe_read' in p.read_text(encoding='utf-8'):consumers.append(str(p.relative_to(P)))
assert not consumers
save('source-pins.json',{'existing_product_sources':inputs['existing_product_sources'],'existing33_unchanged':True,'new_product_files':new,'verified_test_snapshot':'green-02/source-snapshots','implementation_identical_green01_green02':True,'12_test_methods_AST_identical_RED_GREEN':True,'only_test_helper_changed':'open_pipe: original ctypes handle normalized to exact int for native evidence JSON','imports':imports,'production_consumer_matches':consumers,'cached_code_checks':pycs})
save('verification.json',{'red':{'tests':12,'failures':12,'errors':0,'native_pipes_created':0},'green01':{'test_stderr':'12 tests OK','process_exit':1,'structured_receipt':False,'reason':'fixture ctypes handle JSON serialization failure','implementation_changed_for_retry':False},'green02':{'tests':12,'failures':0,'errors':0,'skips':0,'prohibited_attempts':[],'exit':0,'native_pipes':3,'native_endpoints_closed_successfully':closes,'native_pipe_evidence':green['native_pipe_evidence']},'process_runs':runs,'held_process_records':9,'existing_sources_unchanged':33,'production_consumer_matches':[],'R03':'not_run','full_H12':'not_run','all29':'not_run'})
print(json.dumps({'tests':12,'exit':0,'real_pipes':3,'endpoints_closed':closes,'all9_held_records_signaled':True,'existing_sources_unchanged':33,'implementation_sha256':new['simulation/isolation/pipe_read.py']['sha256']}))
