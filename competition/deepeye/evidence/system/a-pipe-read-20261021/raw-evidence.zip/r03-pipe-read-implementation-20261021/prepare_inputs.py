import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=ROOT/'.local/deepeye-implementation-a/competition/deepeye'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
mandatory=['.agents/skills/fpga-multi-node/SKILL.md','.agents/skills/fpga-multi-node/skill-role.json','docs/competition/deepeye-2026/immutable_scope.md','docs/competition/deepeye-2026/immutable_scope.json','.planning/deepeye-desktop-handoff-20261015/transfer.json']
for n in mandatory:(ROOT/n).read_text(encoding='utf-8')
s=json.loads((ROOT/mandatory[3]).read_bytes());h=hashlib.sha256(json.dumps(s['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
t=json.loads((ROOT/mandatory[4]).read_bytes());assert t['director_generation']==2 and t['status']=='active'
new=['simulation/isolation/pipe_read.py','tests/simulation/test_pipe_read.py','docs/pipe_read_boundary.md']
assert all(not (P/n).exists() for n in new)
prior=json.loads((D.parent/'r03-provider-dependency-design-20261021/source-pins.json').read_bytes())
pins=prior['product_sources']
for n,pin in pins.items():assert sha(P/n)==pin['sha256'],n
(D/'input-pins.json').write_text(json.dumps({'requirements_sha256':h,'generation':2,'existing_product_sources':pins,'new_owned_product_paths':new,'mandatory':{n:sha(ROOT/n) for n in mandatory}},indent=2)+'\n',encoding='utf-8')
support=D/'runner-support';support.mkdir()
v=D.parent/'r02-transient-quota-fix-20261021'
for n,expected in {'win_job.py':'80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d','boundary.py':'04cf7d53f3dbf1fca66aab05fe497ae193aab94a56ab4e0d36e81d1eb0a040fe'}.items():
 assert sha(v/n)==expected;(support/n).write_bytes((v/n).read_bytes())
print(json.dumps({'scope_verified':True,'generation':2,'existing_pins':len(pins),'new_paths_absent':3,'reviewed_runner_copied':True}))
