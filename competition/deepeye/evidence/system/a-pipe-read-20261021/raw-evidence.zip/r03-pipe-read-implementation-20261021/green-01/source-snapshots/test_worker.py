import hashlib,json,os,sys,unittest
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];PRODUCT=ROOT/'.local/deepeye-implementation-a'
RUN=Path(sys.argv[1]).resolve();assert RUN.is_relative_to(D)
sys.path.insert(0,str(PRODUCT))
READS=set();ATTEMPTS=[]
def audit(event,args):
 if event in {'subprocess.Popen','os.system','os.startfile','os.startfile/2','socket.connect','socket.bind','socket.sendto','socket.getaddrinfo'}:
  ATTEMPTS.append(event);raise RuntimeError('external execution/network forbidden')
 if event=='open' and not isinstance(args[0],int):
  p=Path(args[0]).resolve();mode,flags=args[1:3]
  writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
  if writing and not p.is_relative_to(RUN):ATTEMPTS.append('unowned_write');raise RuntimeError('unowned write')
  if not writing:
   if '.private.' in p.name:raise RuntimeError('private read forbidden')
   READS.add(str(p))
sys.addaudithook(audit)
suite=unittest.defaultTestLoader.loadTestsFromName('competition.deepeye.tests.simulation.test_pipe_read.PipeReadTests')
result=unittest.TextTestRunner(verbosity=2).run(suite)
module=sys.modules.get('competition.deepeye.tests.simulation.test_pipe_read')
reads={}
for name in tuple(READS):
 p=Path(name)
 if p.is_file() and (p.is_relative_to(PRODUCT) or p.is_relative_to(D)):
  raw=p.read_bytes();reads[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
out={'testsRun':result.testsRun,'successful':result.wasSuccessful(),'failures':[{'test':str(t),'traceback':s} for t,s in result.failures],'errors':[{'test':str(t),'traceback':s} for t,s in result.errors],'skipped':[(str(t),s) for t,s in result.skipped],'prohibited_attempts':ATTEMPTS,'imports_and_reads':reads,'native_pipe_evidence':getattr(module,'NATIVE_EVIDENCE',[]),'scope':'local owned anonymous pipes and native-call controls only; no actor/provider'}
(RUN/'test-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
raise SystemExit(0 if result.wasSuccessful() and not ATTEMPTS else 1)
