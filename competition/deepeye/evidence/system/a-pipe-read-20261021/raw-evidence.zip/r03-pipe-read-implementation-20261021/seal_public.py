import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=ROOT/'.local/deepeye-implementation-a/competition/deepeye'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(D/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
s=json.loads((D/'source-pins.json').read_bytes());v=json.loads((D/'verification.json').read_bytes())
for n,pin in s['existing_product_sources'].items():assert sha(P/n)==pin['sha256']
for n,pin in s['new_product_files'].items():assert sha(P/n)==pin['sha256']
assert v['green02']['tests']==12 and v['green02']['exit']==0 and v['green02']['native_endpoints_closed_successfully']==6
assert v['held_process_records']==9
save('result.json',{'work_id':'A-R03-PIPE-READ-IMPLEMENTATION-20261021-v1','job_id':'child-d0981a47801240d8b289804acb5209ca','new_product_files':s['new_product_files'],'final_tests':12,'final_exit':0,'native_pipe_cases':3,'pipe_endpoints_closed':6,'all9_process_held_records_signaled':True,'existing_sources_unchanged':33,'green01_evidence_failure_preserved':True,'production_consumers':0,'main_independent_review':'pending','requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','generation':2,'R03':'not_run','full_H12':'not_run','all29':'not_run'})
excluded={'artifact-manifest.json','seal-result.json','native-complete-response.json','reserve-request.json','reserve-response.json'}
files={p.relative_to(D).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(D.rglob('*')) if p.is_file() and '.private.' not in p.name and p.name not in excluded}
save('artifact-manifest.json',{'work_id':'A-R03-PIPE-READ-IMPLEMENTATION-20261021-v1','job_id':'child-d0981a47801240d8b289804acb5209ca','files':files,'public_file_count':len(files),'product_files':s['new_product_files'],'excluded':['private lease/reservation','manifest itself','seal receipt','later native completion response']})
for n,pin in files.items():assert sha(D/n)==pin['sha256']
seal={'public_files':len(files),'manifest_sha256':sha(D/'artifact-manifest.json'),'final_result_sha256':sha(D/'final-result.txt'),'product_files':s['new_product_files'],'tests':12,'frozen':True}
save('seal-result.json',seal);print(json.dumps(seal))
