"""Read the original persisted job after completion; no filesystem writes."""
import asyncio
import hashlib
import json
import sys
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
sys.path.insert(0, str(ROOT))
from fpga_mesh.child_control import LocalControlFileClient


async def read():
    client = LocalControlFileClient(ROOT / ".local/deployment/node-a/.local/node-a/main-control.json")
    return await client.call("job", {"job_id": "child-e84f7e2fa1c74fa2ad45983fa5fc5953"})


result = asyncio.run(read())
text = (D / "final-result.txt").read_text(encoding="utf-8")
assert result["status"] == "completed" and result["terminal"] is True and not result["stale"]
assert result["native_agent_id"] == "/root/pipe_read_review_20261021"
assert result["result"]["text"] == text
print(json.dumps({
    "job_id": result["job_id"], "status": result["status"], "terminal": result["terminal"],
    "stale": result["stale"], "native_agent_id": result["native_agent_id"],
    "exact_persisted_result": True, "result_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
}))
