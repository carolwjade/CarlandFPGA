"""Seal a public nonsecret review bundle before native completion."""
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parent


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save_new(name, value):
    with (D / name).open("x", encoding="utf-8") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


verified = json.loads((D / "verification.json").read_bytes())
assert verified["verification"] == "pass" and verified["native_endpoint_closes"] == 4
assert verified["before_after_inputs_identical"]
report_sha = digest((D / "report.md").read_bytes())
result = (
    "A-R03-PIPE-READ-INDEPENDENT-20261021-v1\n"
    "Job child-e84f7e2fa1c74fa2ad45983fa5fc5953; agent /root/pipe_read_review_20261021.\n"
    "Independent bounded review complete: no blocking defect found in the inactive typed pipe-read leaf. "
    "One informational coverage detail: author default8192 control explicitly passed 8192; actual default "
    "is now covered by independent native 9000-byte input -> 8192/808 -> EOF.\n"
    "Author manifest50, old sources33/new files3, exact original completion, all9 retained held-process "
    "terminal records and six final native endpoint closures were verified. RED12 and failed GREEN01 "
    "serialization remain preserved; GREEN02 was 12/12. No author class or broad suite rerun.\n"
    "Independent hidden run: two native controls pass, two original simultaneous pipes, ten polls, "
    "four successful original endpoint closes, three held process objects signaled/wait0, exit0, "
    "active0. Closing A left B live and able to accept a fresh write. Exact pinned source compiled "
    "directly, zero project pyc reads. Product HEAD68814fc6963f8ad8e774aa25f598bbd94c34acc1, "
    "36 source files, HEAD/ref and index unchanged before/after.\n"
    "Only assigned review folder written; no product changes, actor/model, GUI, board, external/network "
    "test, peer communication, service/driver/OS change or new delegation.\n"
    "Report SHA256 " + report_sha + ". Public artifact-manifest.json is sealed before native completion. "
    "Main owns acceptance; genuine IPC/dispatch/BOOT/source/clock/slot, full H12/R03/all29 remain not_run.\n"
    "DEEPEYE-HUMAN-LOCK-20261014/revision1 H01-H15 SHA256 "
    "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804; active director generation2 fixed.\n"
)
with (D / "final-result.txt").open("x", encoding="utf-8") as f:
    f.write(result)
excluded = {
    "lease.private.json", "reserve-request.json", "native-validate-response.json",
    "native-complete-response.json", "artifact-manifest.json", "seal-result.json",
}
private = json.loads((D / "lease.private.json").read_bytes())
token = private["lease_token"].encode()
assert private["job_id"] == "child-e84f7e2fa1c74fa2ad45983fa5fc5953"
files = {}
for p in sorted(D.rglob("*")):
    if not p.is_file():
        continue
    name = p.relative_to(D).as_posix()
    if name in excluded or ".private." in p.name or "__pycache__" in p.parts:
        continue
    raw = p.read_bytes()
    assert token not in raw, "private token in public artifact"
    files[name] = {"bytes": len(raw), "sha256": digest(raw)}
save_new("artifact-manifest.json", {
    "work_id": "A-R03-PIPE-READ-INDEPENDENT-20261021-v1",
    "job_id": private["job_id"], "files": files, "public_file_count": len(files),
    "excluded": sorted(excluded),
    "scope": "bounded inactive leaf review only; main decides acceptance",
})
for name, expected in files.items():
    raw = (D / name).read_bytes()
    assert expected == {"bytes": len(raw), "sha256": digest(raw)}
sealed = {
    "public_file_count": len(files),
    "manifest_sha256": digest((D / "artifact-manifest.json").read_bytes()),
    "report_sha256": report_sha,
    "final_result_sha256": digest((D / "final-result.txt").read_bytes()),
    "public_bytes_rechecked": True, "private_token_absent": True,
}
save_new("seal-result.json", sealed)
print(json.dumps(sealed))
