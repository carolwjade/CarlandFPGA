"""One fresh hidden job, copied reviewed runner, no retries."""
import hashlib
import json
import os
import sys
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
AUTHOR = D.parent / "r03-pipe-read-implementation-20261021"
PRODUCT = ROOT / ".local/deepeye-implementation-a"
SUPPORT = D / "runner-support"
PINS = {
    "win_job.py": "80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d",
    "boundary.py": "04cf7d53f3dbf1fca66aab05fe497ae193aab94a56ab4e0d36e81d1eb0a040fe",
}
assert not SUPPORT.exists()
SUPPORT.mkdir()
for name, expected in PINS.items():
    raw = (AUTHOR / "runner-support" / name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected
    with (SUPPORT / name).open("xb") as out:
        out.write(raw)
sys.path.insert(0, str(SUPPORT))
from win_job import run_bounded
from boundary import save_new

audit = json.loads((D / "author-audit-before.json").read_bytes())
project = {}
for name, value in {**audit["old_product_files"], **audit["new_product_files"]}.items():
    project["competition/deepeye/" + name] = value
for name in ("competition", "competition/deepeye", "competition/deepeye/simulation",
             "competition/deepeye/simulation/isolation"):
    source = PRODUCT / name / "__init__.py"
    if source.is_file():
        raw = source.read_bytes()
        project[name + "/__init__.py"] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
interpreter = ROOT / ".local/venv/Scripts/python.exe"
interpreter_pin = hashlib.sha256(interpreter.read_bytes()).hexdigest()
inputs = {"project_source_files": project, "interpreter": str(interpreter),
          "interpreter_sha256": interpreter_pin, "runner_sources": PINS,
          "author_manifest_sha256": audit["author_manifest_sha256"],
          "requirements_sha256": audit["contract"]["requirements_sha256"],
          "product_HEAD": audit["git"]["head"]}
save_new(D / "input-pins.json", inputs)
run = D / "independent-01"
assert not run.exists()
run.mkdir()
snap = run / "source-snapshots"
snap.mkdir()
for name in ("run_independent.py", "independent_worker.py", "input-pins.json"):
    with (snap / name).open("xb") as out:
        out.write((D / name).read_bytes())
for name in ("simulation/isolation/pipe_read.py", "simulation/isolation/win32.py"):
    target = snap / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as out:
        out.write((PRODUCT / "competition/deepeye" / name).read_bytes())
env = {k: v for k, v in os.environ.items() if k.upper() in ("SYSTEMROOT", "WINDIR")}
env.update(PATH="", TEMP=str(run), TMP=str(run), PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
budget = {"seconds": 30, "job_memory_bytes": 512 * 1024**2, "process_memory_bytes": 256 * 1024**2,
          "active_processes": 4, "stdout_bytes": 256 * 1024, "stderr_bytes": 512 * 1024,
          "tree_bytes": 16 * 1024**2, "tree_entries": 300, "free_reserve_bytes": 512 * 1024**2}
argv = [str(interpreter), "-I", "-S", "-B", "-X", "utf8", str(D / "independent_worker.py"), str(run)]
save_new(run / "started.json", {"argv": argv, "budget": budget, "environment": env, "cwd": str(D)})
result = run_bounded(argv, env, D, run / "process", budget, [run])
save_new(run / "terminal.json", result)
assert result["all_processes_terminated"] and result["active_processes_final"] == 0
assert result["held_members"] and all(x["signaled"] and x["wait_result"] == 0 for x in result["held_members"])
print(json.dumps({k: result[k] for k in ("exit_code", "seconds", "all_processes_terminated",
                                       "active_processes_final", "held_members", "stop_reason")}))
raise SystemExit(0 if result["exit_code"] == 0 and not result["stop_reason"] else 1)
