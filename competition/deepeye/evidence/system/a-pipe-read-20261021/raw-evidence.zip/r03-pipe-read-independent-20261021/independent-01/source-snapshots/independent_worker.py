"""Two decisive local native pipe controls; no author unittest execution."""
import hashlib
import importlib.machinery
import importlib.util
import json
import os
import sys
import traceback
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
PRODUCT = ROOT / ".local/deepeye-implementation-a"
RUN = Path(sys.argv[1]).resolve()
assert RUN.is_relative_to(D) and RUN.name == "independent-01"
PINS = json.loads((D / "input-pins.json").read_bytes())
LOADED = {}
READS = set()
ATTEMPTS = []


def audit(event, args):
    if event.startswith("socket.") or event in {
        "subprocess.Popen", "os.system", "os.startfile", "os.startfile/2",
        "os.posix_spawn", "os.exec", "os.spawn", "os.fork", "os.symlink", "os.link",
    }:
        ATTEMPTS.append(event)
        raise RuntimeError("unapproved execution/network/filesystem operation")
    if event == "open" and not isinstance(args[0], int):
        p = Path(args[0]).resolve()
        mode, flags = args[1:3]
        writing = ((isinstance(mode, str) and any(c in mode for c in "wax+")) or
                   (isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC)))
        if writing and not p.is_relative_to(RUN):
            ATTEMPTS.append("unowned_write")
            raise RuntimeError("write outside run directory")
        if ".private." in p.name:
            ATTEMPTS.append("private_read")
            raise RuntimeError("private files forbidden")
        if not writing:
            READS.add(str(p))


class ExactSourceLoader(importlib.machinery.SourceFileLoader):
    def get_code(self, fullname):
        path = Path(self.path).resolve()
        relative = path.relative_to(PRODUCT).as_posix()
        raw = self.get_data(self.path)
        actual = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        assert actual == PINS["project_source_files"][relative], relative
        LOADED[fullname] = {"path": str(path), **actual, "mode": "compile exact source bytes; no pyc"}
        return compile(raw, str(path), "exec", dont_inherit=True, optimize=0)


class ExactSourceFinder:
    allowed = {
        "competition", "competition.deepeye", "competition.deepeye.simulation",
        "competition.deepeye.simulation.isolation",
        "competition.deepeye.simulation.isolation.pipe_read",
        "competition.deepeye.simulation.isolation.win32",
    }

    def find_spec(self, fullname, path=None, target=None):
        if fullname != "competition" and not fullname.startswith("competition."):
            return None
        assert fullname in self.allowed, fullname
        stem = PRODUCT.joinpath(*fullname.split("."))
        if stem.is_dir():
            init = stem / "__init__.py"
            if not init.is_file():
                spec = importlib.machinery.ModuleSpec(fullname, loader=None, is_package=True)
                spec.submodule_search_locations = [str(stem)]
                return spec
            return importlib.util.spec_from_file_location(fullname, init, loader=ExactSourceLoader(fullname, str(init)),
                                                         submodule_search_locations=[str(stem)])
        source = stem.with_suffix(".py")
        return importlib.util.spec_from_file_location(fullname, source, loader=ExactSourceLoader(fullname, str(source)))


sys.addaudithook(audit)
sys.meta_path.insert(0, ExactSourceFinder())
from competition.deepeye.simulation.isolation import pipe_read as pr
from competition.deepeye.simulation.isolation import win32 as w

EVENTS = []
LIVE = {}
ATTEMPTED_CLOSES = set()
CONTROLS = []
FAILURES = []
journal = (RUN / "events.jsonl").open("x", encoding="utf-8")


def event(**value):
    row = {"sequence": len(EVENTS), **value}
    EVENTS.append(row)
    journal.write(json.dumps(row) + "\n")
    journal.flush()
    os.fsync(journal.fileno())


def create(label):
    reader, writer = w.W.HANDLE(), w.W.HANDLE()
    security = w.SA(w.C.sizeof(w.SA), None, False)
    event(operation="CreatePipe", pipe=label, phase="attempt", requested_capacity=16384)
    okay = bool(w.CreatePipe(w.C.byref(reader), w.C.byref(writer), w.C.byref(security), 16384))
    error = None if okay else w.C.get_last_error()
    if okay:
        for endpoint, value in (("read", reader.value), ("write", writer.value)):
            assert type(value) is int and value > 0 and value not in LIVE.values()
            LIVE[(label, endpoint)] = value
        event(operation="CreatePipe", pipe=label, phase="result", success=True,
              original_read=reader.value, original_write=writer.value, requested_capacity=16384)
    else:
        event(operation="CreatePipe", pipe=label, phase="result", success=False, winerror=error)
        raise w.C.WinError(error, "CreatePipe")
    return reader.value, writer.value


def close(label, endpoint):
    key = (label, endpoint)
    assert key in LIVE and key not in ATTEMPTED_CLOSES
    ATTEMPTED_CLOSES.add(key)
    handle = LIVE[key]
    event(operation="CloseHandle", pipe=label, endpoint=endpoint, original_handle=handle, phase="attempt")
    okay = bool(w.CloseHandle(handle))
    error = None if okay else w.C.get_last_error()
    event(operation="CloseHandle", pipe=label, endpoint=endpoint, original_handle=handle,
          phase="result", success=okay, winerror=error)
    if not okay:
        raise w.C.WinError(error, "CloseHandle")
    del LIVE[key]


def write(label, value):
    assert type(value) is bytes and 0 < len(value) <= 9000 < 16384
    handle = LIVE[(label, "write")]
    count = w.W.DWORD()
    event(operation="WriteFile", pipe=label, original_handle=handle, phase="attempt",
          requested_bytes=len(value), payload_sha256=hashlib.sha256(value).hexdigest())
    okay = bool(w.WriteFile(handle, value, len(value), w.C.byref(count), None))
    error = None if okay else w.C.get_last_error()
    event(operation="WriteFile", pipe=label, original_handle=handle, phase="result",
          success=okay, actual_bytes=count.value, winerror=error)
    if not okay:
        raise w.C.WinError(error, "WriteFile")
    assert count.value == len(value), "No retry on incomplete write"


def poll(label, *, maximum=None, expected_state, expected_data):
    original_peek, original_read = w.PeekNamedPipe, w.ReadFile
    peek_calls, read_calls = [], []

    def peek(*args):
        result = original_peek(*args)
        peek_calls.append({"success": bool(result)})
        return result

    def read(*args):
        result = original_read(*args)
        read_calls.append({"success": bool(result), "requested_bytes": args[2]})
        return result

    handle = LIVE[(label, "read")]
    w.PeekNamedPipe, w.ReadFile = peek, read
    try:
        result = pr.poll_output(handle) if maximum is None else pr.poll_output(handle, maximum)
    finally:
        w.PeekNamedPipe, w.ReadFile = original_peek, original_read
    event(operation="poll_output", pipe=label, original_handle=handle, used_default=maximum is None,
          maximum=maximum, state=result.state, data_bytes=len(result.data),
          data_sha256=hashlib.sha256(result.data).hexdigest(), peek_calls=peek_calls, read_calls=read_calls)
    assert result.state == expected_state and result.data == expected_data
    assert len(peek_calls) == 1 and len(read_calls) == (1 if result.state == "data" else 0)
    if read_calls:
        assert read_calls[0]["requested_bytes"] == len(expected_data)
    return result


try:
    ar, aw = create("A")
    br, bw = create("B")
    assert len({ar, aw, br, bw}) == 4
    poll("A", expected_state="empty", expected_data=b"")
    poll("B", expected_state="empty", expected_data=b"")
    large = bytes((i * 37 + 11) % 256 for i in range(9000))
    small = b"independent-pipe-B"
    write("A", large)
    write("B", small)
    a_first = poll("A", expected_state="data", expected_data=large[:8192])
    b_first = poll("B", maximum=4, expected_state="data", expected_data=small[:4])
    close("A", "write")
    a_last = poll("A", expected_state="data", expected_data=large[8192:])
    assert a_first.data + a_last.data == large
    poll("A", expected_state="eof", expected_data=b"")
    CONTROLS.append({"id": "native_default_8192_boundary", "status": "pass", "payload_bytes": 9000,
                     "pieces": [len(a_first.data), len(a_last.data)], "full_payload_matches": True,
                     "writer_closed_before_second_piece": True, "eof_after_drain": True})
    close("A", "read")
    b_last = poll("B", expected_state="data", expected_data=small[4:])
    assert b_first.data + b_last.data == small
    poll("B", expected_state="empty", expected_data=b"")
    still_live = b"still-owned-B"
    write("B", still_live)
    poll("B", expected_state="data", expected_data=still_live)
    close("B", "write")
    poll("B", expected_state="eof", expected_data=b"")
    CONTROLS.append({"id": "two_original_pipes_independent", "status": "pass",
                     "simultaneous_unique_endpoints": 4, "B_survives_A_writer_and_reader_close": True,
                     "B_accepts_new_write_after_A_closed": True, "cross_pipe_payload_mix": False})
except BaseException as exc:
    FAILURES.append({"phase": "control", "type": type(exc).__name__, "traceback": traceback.format_exc()})
finally:
    for label, endpoint in tuple(LIVE):
        if (label, endpoint) in ATTEMPTED_CLOSES:
            continue
        try:
            close(label, endpoint)
        except BaseException as exc:
            FAILURES.append({"phase": "cleanup", "type": type(exc).__name__, "traceback": traceback.format_exc()})
    event(operation="cleanup", complete=not LIVE and not FAILURES,
          unclosed=[{"pipe": k[0], "endpoint": k[1], "original_handle": v} for k, v in LIVE.items()])
    journal.close()

project_cache_reads = [p for p in READS if Path(p).is_relative_to(PRODUCT) and p.endswith(".pyc")]
assert not project_cache_reads
assert len(LOADED) >= 2
assert not ATTEMPTS
out = {
    "scope": "two local anonymous pipes; diagnostic leaf only", "controls": CONTROLS, "failures": FAILURES,
    "success": len(CONTROLS) == 2 and not FAILURES and not LIVE and not ATTEMPTS,
    "events": EVENTS, "prohibited_attempts": ATTEMPTS, "project_source_loads": LOADED,
    "project_pyc_reads": project_cache_reads, "source_import_policy": "exact pinned source compiled directly",
    "project_reads": sorted(p for p in READS if Path(p).is_relative_to(PRODUCT)),
    "R03": "not_run", "full_H12": "not_run", "all29": "not_run",
}
with (RUN / "control-result.json").open("x", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
    f.write("\n")
print(json.dumps({"controls_passed": len(CONTROLS), "failures": len(FAILURES),
                  "created_pipes": 2, "endpoint_closes": len(ATTEMPTED_CLOSES),
                  "source_loads": len(LOADED), "project_pyc_reads": len(project_cache_reads)}))
raise SystemExit(0 if out["success"] else 1)
