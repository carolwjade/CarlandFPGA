"""Independent read-only author evidence audit; writes only this task folder."""
import ast
import hashlib
import json
import marshal
import sys
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
A = D.parent / "r03-pipe-read-implementation-20261021"
PRODUCT = ROOT / ".local/deepeye-implementation-a"
P = PRODUCT / "competition/deepeye"
EXPECTED_HEAD = "68814fc6963f8ad8e774aa25f598bbd94c34acc1"
EXPECTED_MANIFEST = "a9cf431593a8edfbc4c3d5717f0634244b55535f91a882488074d75e8d48861f"
CONTRACT = "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
NEW = {
    "simulation/isolation/pipe_read.py": "08186c9c6132a04b33ef90f3d015cfed7a6634f2fc1094241b361d347bca3785",
    "tests/simulation/test_pipe_read.py": "daa5cc3c5180ec0a1e7d8a19b361f16d03e6ad2470a24d89c963b56c4dc36eea",
    "docs/pipe_read_boundary.md": "2453ee137cb07e39421c4900f76d936ce9f480ab3a9ea815c8dc0a2fe9ff024f",
}


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load(p):
    return json.loads(p.read_bytes())


def pin(p):
    return {"bytes": p.stat().st_size, "sha256": sha(p)}


def save_new(name, value):
    with (D / name).open("x", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def verify():
    scope = load(ROOT / "docs/competition/deepeye-2026/immutable_scope.json")
    canonical = json.dumps(scope["requirements"], sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    assert hashlib.sha256(canonical).hexdigest() == CONTRACT
    assert [r["id"] for r in scope["requirements"]] == [f"H{i:02d}" for i in range(1, 16)]
    transfer = load(ROOT / ".planning/deepeye-desktop-handoff-20261015/transfer.json")
    assert transfer["status"] == "active" and transfer["director_generation"] == 2
    assert transfer["new_director_thread_id"] == "01a13d7e-dcf1-7272-a738-a637dd62ff9d"
    gitfile = (PRODUCT / ".git").read_text().strip()
    assert gitfile.startswith("gitdir: ")
    gitdir = (PRODUCT / gitfile[8:]).resolve()
    common = (gitdir / (gitdir / "commondir").read_text().strip()).resolve()
    headtext = (gitdir / "HEAD").read_text().strip()
    if headtext.startswith("ref: "):
        ref = headtext[5:]
        refpath = common / ref
        if refpath.exists():
            head = refpath.read_text().strip()
        else:
            head = next(line.split()[0] for line in (common / "packed-refs").read_text().splitlines()
                        if line and not line.startswith(("#", "^")) and line.split()[1] == ref)
    else:
        ref, head = None, headtext
    assert head == EXPECTED_HEAD
    git_state = {"head": head, "ref": ref, "index": pin(gitdir / "index"), "HEAD_file": pin(gitdir / "HEAD")}
    assert sha(A / "artifact-manifest.json") == EXPECTED_MANIFEST
    manifest = load(A / "artifact-manifest.json")
    assert manifest["public_file_count"] == len(manifest["files"]) == 50
    for name, expected in manifest["files"].items():
        p = (A / name).resolve()
        assert p.is_relative_to(A) and ".private." not in name
        assert pin(p) == expected, name
    inputs = load(A / "input-pins.json")
    assert len(inputs["existing_product_sources"]) == 33
    for name, expected in inputs["existing_product_sources"].items():
        assert pin(P / name) == expected, name
    for name, expected in inputs["mandatory"].items():
        assert sha(ROOT / name) == expected, name
    for name, expected in NEW.items():
        assert sha(P / name) == expected, name
        assert sha(A / "green-02/source-snapshots" / name) == expected
    complete = load(A / "native-complete-response.json")
    assert complete["job_id"] == "child-d0981a47801240d8b289804acb5209ca"
    assert complete["terminal"] is True and complete["status"] == "completed" and not complete["stale"]
    assert complete["result"]["text"] == (A / "final-result.txt").read_text(encoding="utf-8")
    runs = {}
    held = []
    caches = []
    imports = {}
    for label, exit_code in (("red-01", 1), ("green-01", 1), ("green-02", 0)):
        r = load(A / label / "terminal.json")
        assert r == load(A / label / "process/terminal.json")
        assert r["exit_code"] == exit_code and r["active_processes_final"] == 0
        assert r["all_processes_terminated"] is True and r["stop_reason"] is None
        assert len(r["held_members"]) == 3 and not r["absent_before_handle_open"]
        assert all(x["signaled"] is True and x["wait_result"] == 0 and x["creation_filetime"] > 0
                   for x in r["held_members"])
        assert {x["pid"] for x in r["held_members"]} == set(r["observed_job_pids"])
        for stream, expected in r["logs"].items():
            assert pin(A / label / "process" / (stream + ".txt")) == expected
        start = load(A / label / "process/started.json")
        assert start["hidden"] and start["private_job"] and start["assigned_before_resume"]
        assert start["budget"]["seconds"] == 30 and start["priority"] == "below_normal"
        assert start["argv"][1:6] == ["-I", "-S", "-B", "-X", "utf8"]
        assert sha(Path(start["launcher"]["image"])) == start["launcher"]["image_sha256"]
        held.extend({"run": label, **x} for x in r["held_members"])
        runs[label] = r
        result = A / label / "test-result.json"
        if not result.exists():
            assert label == "green-01"
            err = (A / label / "process/stderr.txt").read_text(encoding="utf-8")
            assert "Ran 12 tests" in err and "\nOK\n" in err
            assert "c_void_p is not JSON serializable" in err
            continue
        result = load(result)
        assert not result["errors"] and not result["skipped"] and not result["prohibited_attempts"]
        assert result["testsRun"] == 12
        if label == "red-01":
            assert len(result["failures"]) == 12 and not result["native_pipe_evidence"]
            assert all("typed pipe-read component is absent" in x["traceback"] for x in result["failures"])
        else:
            assert result["successful"] and not result["failures"]
        records = []
        for path, expected in result["imports_and_reads"].items():
            original = Path(path)
            candidate = original
            if original.is_relative_to(P):
                snapshot = A / label / "source-snapshots" / original.relative_to(P)
                if snapshot.is_file():
                    candidate = snapshot
            assert pin(candidate) == expected, (label, path)
            records.append({"reported_path": path, "verified_bytes": str(candidate), **expected})
            if candidate.suffix == ".pyc":
                raw = candidate.read_bytes()
                code = marshal.loads(raw[16:])
                source = Path(code.co_filename)
                assert source.is_file(), source
                assert code == compile(source.read_bytes(), code.co_filename, "exec", dont_inherit=True, optimize=0)
                caches.append({"run": label, "pyc": str(candidate), "source": str(source),
                               "source_sha256": sha(source), "code_matches_source": True})
        imports[label] = records
    native = load(A / "green-02/test-result.json")["native_pipe_evidence"]
    assert len(native) == 3
    closures = []
    for pipe in native:
        assert pipe["cleanup_complete"] is True
        create = [x for x in pipe["events"] if "created" in x]
        close = [x for x in pipe["events"] if "closed" in x]
        assert len(create) == len(close) == 2
        assert {x["created"] for x in create} == {"read", "write"}
        assert {x["closed"] for x in close} == {"read", "write"}
        created = {x["created"]: x["original_handle"] for x in create}
        for row in close:
            assert row["success"] is True and row["original_handle"] == created[row["closed"]]
        closures.append({"test": pipe["test"], "created": create, "closed": close})
    first, second, third = native
    # unittest sorts method names; inspect names rather than assume evidence order.
    by_name = {x["test"].rsplit(".", 1)[-1]: x["events"] for x in native}
    events = by_name["test_real_pipe_empty_exact_partial_data_then_last_writer_close_eof"]
    polls = [e for e in events if "state" in e]
    assert [e["state"] for e in polls] == ["empty"] + ["data"] * 4 + ["empty", "eof"]
    assert b"".join(bytes.fromhex(e["data_hex"]) for e in polls) == b"abcdefghij"
    assert all(e["peek_calls"] == 1 and e["read_calls"] == (1 if e["state"] == "data" else 0) for e in polls)
    writer_close = next(i for i, e in enumerate(events) if e.get("closed") == "write")
    assert events[writer_close + 1]["state"] == "eof"
    buffered = by_name["test_real_pipe_buffered_data_precedes_eof_after_writer_close"]
    assert [e["state"] for e in buffered if "state" in e] == ["data", "eof"]
    assert next(e["data_hex"] for e in buffered if e.get("state") == "data") == "7879"
    closed = by_name["test_real_closed_read_handle_is_error6_without_handle_reuse"]
    assert any(e.get("closed_read_error") == 6 and e["no_intervening_handle_creation"] for e in closed)
    test_name = "tests/simulation/test_pipe_read.py"
    def methods(p):
        tree = ast.parse(p.read_bytes())
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "PipeReadTests")
        return {n.name: ast.dump(n, include_attributes=False) for n in cls.body if isinstance(n, ast.FunctionDef)}
    old, new = methods(A / "red-01/source-snapshots" / test_name), methods(P / test_name)
    assert len([n for n in old if n.startswith("test_")]) == 12
    assert set(old) == set(new) and {n for n in old if old[n] != new[n]} == {"open_pipe"}
    assert sha(A / "green-01/source-snapshots/simulation/isolation/pipe_read.py") == NEW["simulation/isolation/pipe_read.py"]
    consumers = []
    for p in P.rglob("*.py"):
        rel = p.relative_to(P)
        if "tests" in rel.parts or p.name.startswith("test_") or p.name == "pipe_read.py":
            continue
        if "pipe_read" in p.read_text(encoding="utf-8"):
            consumers.append(rel.as_posix())
    assert not consumers
    return {
        "contract": {"id": "DEEPEYE-HUMAN-LOCK-20261014/revision1", "requirements_sha256": CONTRACT,
                     "H01_H15_verified": True, "director_generation": 2, "transfer_status": "active"},
        "git": git_state, "author_manifest_sha256": EXPECTED_MANIFEST, "author_public_files_verified": 50,
        "old_product_files": inputs["existing_product_sources"], "old_sources_verified": 33,
        "new_product_files": {n: pin(P / n) for n in NEW},
        "author_terminal": {"job_id": complete["job_id"], "status": "completed", "terminal": True,
                            "exact_final_result_matches": True, "receipt_sha256": sha(A / "native-complete-response.json")},
        "author_runs": runs, "held_process_records": held, "author_pipe_endpoint_closures": closures,
        "author_imports": imports, "author_cached_code_equivalence": caches,
        "test_AST_difference": ["open_pipe"], "implementation_identical_GREEN01_GREEN02": True,
        "production_consumer_matches": consumers,
        "green01_preserved_failure": "12 assertions passed, evidence JSON serialization failed, process exit 1",
        "R03": "not_run", "full_H12": "not_run", "all29": "not_run",
    }


if __name__ == "__main__":
    phase = sys.argv[1]
    assert phase in {"before", "after"}
    try:
        out = verify()
        if phase == "after":
            before = load(D / "author-audit-before.json")
            assert out == before, "Inputs or retained author evidence changed during independent review"
        save_new(f"author-audit-{phase}.json", out)
        print(json.dumps({"phase": phase, "author_public_files_verified": 50, "old_sources_verified": 33,
                          "new_sources_verified": 3, "author_held_records_signaled": 9,
                          "cached_code_equivalence_checks": len(out["author_cached_code_equivalence"]),
                          "H01_H15": "fixed", "product_head": out["git"]["head"]}))
    except BaseException as exc:
        save_new(f"author-audit-{phase}-failure.json", {"type": type(exc).__name__, "message": str(exc)})
        raise
