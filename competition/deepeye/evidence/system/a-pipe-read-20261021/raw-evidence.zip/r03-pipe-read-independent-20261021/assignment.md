# A-R03-PIPE-READ-INDEPENDENT-20261021-v1

You are an independent code reviewer for this completed implementation. Read
mandatory project fpga-multi-node skill/node-A role and immutable scope md/json,
active generation2 transfer; verify requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
H01-H15 remain mandatory. User authorizes independent review/parallel workers.
Use existing native_lease_guard_20261020.py validate/complete for this NEW job.
Own only this evidence directory. Product, index, branch, original evidence and
other workers' files are read-only; no fixes, commits or checkout changes.

## Implementation and original requirement

Read ../r03-pipe-read-implementation-20261021/assignment.md, report.md and sources.
New typed poll_output returns data/empty/eof without production wiring. Existing
available_output still serves discarded cleanup diagnostics and is unchanged.
Purpose is a truthful native pipe-state leaf for later transport; not a complete
IPC provider. Original reader ownership/single-reader usage are caller obligations.
No native acquisition, credentials, model readiness, timestamps, authority or
hard cancellation guarantee may be inferred.

Base product HEAD68814fc6963f8ad8e774aa25f598bbd94c34acc1. Three NEW uncommitted
files in .local/deepeye-implementation-a/competition/deepeye:
- simulation/isolation/pipe_read.py SHA08186c9c6132a04b33ef90f3d015cfed7a6634f2fc1094241b361d347bca3785
- tests/simulation/test_pipe_read.py SHAdaa5cc3c5180ec0a1e7d8a19b361f16d03e6ad2470a24d89c963b56c4dc36eea
- docs/pipe_read_boundary.md SHA2453ee137cb07e39421c4900f76d936ce9f480ab3a9ea815c8dc0a2fe9ff024f

Author manifest50 SHAa9cf431593a8edfbc4c3d5717f0634244b55535f91a882488074d75e8d48861f.
Original job child-d0981a47801240d8b289804acb5209ca completed; main verifies exact
terminal before reserving. Recheck all50 evidence files/current hashes, 33 unchanged
sources, test versions, all original held-object terminal records and actual pipe
creation/use/close records. Author RED12 absent-component failures, GREEN01
assertions passed but evidence serialization failed, final GREEN02 12/12 passed.
Do not promote first GREEN or erase failures; only fixture handle normalization
changed between GREEN tests, not production implementation.

## Review

Check plan alignment, native error semantics and ctypes handle width; exact type/
limit validation before native access; one Peek/at most one ReadFile; max8192 and
available-size enforcement; zero/invalid read refusal; error109 versus other errors;
one-reader/EOF/leftover data semantics; no implicit retries or teardown/authority.
Review tests for misleading native versus mocked claims, closure and source binding.
Assess cached code equivalence if imported; -B alone does not prove source choice.

Add only minimal decisive independent controls under an existing reviewed copied
hidden bounded runner (<=30s, modest output/memory/file limits), with exact pins
and all held-object closure. Useful uncovered cases include actual default8192
boundary on a <=9000-byte payload below requested16384 pipe capacity, two original
local pipes not sharing state/closing each other, or a concrete counterexample
you identify. Avoid merely re-running the author's class or mirroring code.
No writes exceeding local pipe capacity; any uncertainty is bounded by the owned
test JobObject and is retained. Never touch external/production endpoints or
kill unrelated processes. Do not run the real actor/model or old broad suites.

All software tests background. No display/GUI/input, board/service/driver/OS
changes, network/install/vendor/peer messages. Only local test-created anonymous
pipes and owned test processes may be used. Do not manufacture a trusted actor.

Return report.md with concrete findings/severity/file lines and readiness limited
to this inactive leaf, evidence/limitations, independent results, public nonsecret
manifest and final-result.txt. No request for per-step human approval. Complete
original job once with exact result, verify terminal and stop writes. Main owns
acceptance/publication. Genuine IPC/dispatch/BOOT/source/clock/slot, full H12 and
R03/all29 remain not_run.
