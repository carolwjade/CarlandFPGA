"""Verify persisted native observations and exact input/runner/source binding."""
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
PRODUCT = ROOT / ".local/deepeye-implementation-a"
RUN = D / "independent-01"


def load(p):
    return json.loads(p.read_bytes())


def pin(p):
    raw = p.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


before = load(D / "author-audit-before.json")
after = load(D / "author-audit-after.json")
assert before == after
inputs = load(D / "input-pins.json")
for name, expected in inputs["project_source_files"].items():
    assert pin(PRODUCT / name) == expected, name
for name, expected in inputs["runner_sources"].items():
    assert pin(D / "runner-support" / name)["sha256"] == expected
assert pin(Path(inputs["interpreter"]))["sha256"] == inputs["interpreter_sha256"]
for name in ("run_independent.py", "independent_worker.py", "input-pins.json"):
    assert pin(D / name) == pin(RUN / "source-snapshots" / name)
for name in ("simulation/isolation/pipe_read.py", "simulation/isolation/win32.py"):
    assert pin(PRODUCT / "competition/deepeye" / name) == pin(RUN / "source-snapshots" / name)
terminal = load(RUN / "terminal.json")
assert terminal == load(RUN / "process/terminal.json")
assert terminal["status"] == "success" and terminal["exit_code"] == 0 and terminal["stop_reason"] is None
assert terminal["all_processes_terminated"] is True and terminal["active_processes_final"] == 0
assert not terminal["faults"] and not terminal["absent_before_handle_open"]
assert len(terminal["held_members"]) == terminal["total_job_processes"] == 3
assert {h["pid"] for h in terminal["held_members"]} == set(terminal["observed_job_pids"])
assert all(h["signaled"] is True and h["wait_result"] == 0 and h["exit_code"] == 0
           and h["creation_filetime"] > 0 for h in terminal["held_members"])
for name, expected in terminal["logs"].items():
    assert pin(RUN / "process" / (name + ".txt")) == expected
    assert terminal["outputs"][name]["persisted_bytes"] == expected["bytes"]
started = load(RUN / "process/started.json")
assert started["hidden"] and started["assigned_before_resume"] and started["private_job"]
assert started["priority"] == "below_normal"
assert started["argv"][1:6] == ["-I", "-S", "-B", "-X", "utf8"]
assert started["budget"]["seconds"] == 30
assert started["readback_limits"] == {
    "job_memory_bytes": 512 * 1024**2, "process_memory_bytes": 256 * 1024**2, "active_processes": 4,
}
assert pin(Path(started["launcher"]["image"]))["sha256"] == started["launcher"]["image_sha256"]
result = load(RUN / "control-result.json")
assert result["success"] and not result["failures"] and not result["prohibited_attempts"]
assert len(result["controls"]) == 2 and all(x["status"] == "pass" for x in result["controls"])
events = result["events"]
journal = [json.loads(line) for line in (RUN / "events.jsonl").read_text(encoding="utf-8").splitlines()]
assert events == journal and [e["sequence"] for e in events] == list(range(len(events)))
created = {}
closed = {}
writes = []
for i, e in enumerate(events):
    if e.get("phase") == "attempt":
        following = events[i + 1]
        assert following["operation"] == e["operation"] and following["phase"] == "result"
        assert following["pipe"] == e["pipe"] and following["success"] is True
    if e["operation"] == "CreatePipe" and e["phase"] == "result":
        assert e["requested_capacity"] == 16384 and e["pipe"] not in created
        created[e["pipe"]] = {"read": e["original_read"], "write": e["original_write"]}
    if e["operation"] == "CloseHandle" and e["phase"] == "result":
        key = (e["pipe"], e["endpoint"])
        assert key not in closed and e["original_handle"] == created[e["pipe"]][e["endpoint"]]
        assert e["success"] is True and e["winerror"] is None
        closed[key] = e["sequence"]
    if e["operation"] == "WriteFile" and e["phase"] == "attempt":
        assert e["original_handle"] == created[e["pipe"]]["write"]
        assert 0 < e["requested_bytes"] <= 9000 < 16384
        assert events[i + 1]["actual_bytes"] == e["requested_bytes"]
        writes.append(e)
assert set(created) == {"A", "B"} and len({h for p in created.values() for h in p.values()}) == 4
assert len(closed) == 4 and len(writes) == 3
assert events[-1] == {"sequence": 28, "operation": "cleanup", "complete": True, "unclosed": []}
large = bytes((i * 37 + 11) % 256 for i in range(9000))
small = b"independent-pipe-B"
new_B = b"still-owned-B"
expected = [
    ("A", "empty", b"", None), ("B", "empty", b"", None),
    ("A", "data", large[:8192], None), ("B", "data", small[:4], 4),
    ("A", "data", large[8192:], None), ("A", "eof", b"", None),
    ("B", "data", small[4:], None), ("B", "empty", b"", None),
    ("B", "data", new_B, None), ("B", "eof", b"", None),
]
polls = [e for e in events if e["operation"] == "poll_output"]
assert len(polls) == len(expected) == 10
for e, (pipe, state, data, maximum) in zip(polls, expected):
    assert (e["pipe"], e["state"], e["maximum"]) == (pipe, state, maximum)
    assert e["data_bytes"] == len(data) and e["data_sha256"] == digest(data)
    assert e["original_handle"] == created[pipe]["read"]
    assert e["used_default"] is (maximum is None)
    assert len(e["peek_calls"]) == 1
    assert e["peek_calls"][0]["success"] is (state != "eof")
    assert len(e["read_calls"]) == (1 if state == "data" else 0)
    if state == "data":
        assert e["read_calls"] == [{"success": True, "requested_bytes": len(data)}]
assert closed[("A", "write")] < polls[4]["sequence"]
assert closed[("A", "read")] < polls[6]["sequence"] < writes[2]["sequence"]
assert closed[("B", "write")] < polls[9]["sequence"]
assert [(e["pipe"], e["requested_bytes"], e["payload_sha256"]) for e in writes] == [
    ("A", 9000, digest(large)), ("B", len(small), digest(small)), ("B", len(new_B), digest(new_B)),
]
assert not result["project_pyc_reads"]
assert len(result["project_source_loads"]) == 3
for name, source in result["project_source_loads"].items():
    source_path = Path(source["path"])
    assert pin(source_path) == {k: source[k] for k in ("bytes", "sha256")}
    assert inputs["project_source_files"][source_path.relative_to(PRODUCT).as_posix()] == pin(source_path)
    assert source["mode"] == "compile exact source bytes; no pyc"
out = {
    "verification": "pass", "author_public_files": 50, "existing_sources": 33, "new_sources": 3,
    "before_after_inputs_identical": True, "author_held_process_records": 9,
    "independent_controls": result["controls"], "native_pipes": 2, "native_endpoint_closes": 4,
    "polls": 10, "all_one_peek_at_most_one_read": True, "events_match_fsynced_journal": True,
    "independent_terminal": terminal, "exact_source_loads": result["project_source_loads"],
    "project_cache_reads": 0, "author_cache_reads": 0, "independent_failures": [],
    "scope": "inactive native pipe-read leaf; main owns acceptance", "R03": "not_run",
    "full_H12": "not_run", "all29": "not_run",
}
with (D / "verification.json").open("x", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
    f.write("\n")
print(json.dumps({"verification": "pass", "controls": 2, "native_pipes": 2, "successful_endpoint_closes": 4,
                  "polls": 10, "held_process_records_signaled": 3, "unchanged_current_sources": 36}))
