import asyncio
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
OUT = D.parent
PRODUCT = ROOT / ".local/deepeye-implementation-a"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
GROUPS = {
    "r03-pipe-read-implementation-20261021": (
        "a9cf431593a8edfbc4c3d5717f0634244b55535f91a882488074d75e8d48861f",
        50, "child-d0981a47801240d8b289804acb5209ca"),
    "r03-pipe-read-independent-20261021": (
        "e1805621459103becabd8cad259f50904cfdbb6b6b08d3754cebce1a5b5e4285",
        28, "child-e84f7e2fa1c74fa2ad45983fa5fc5953"),
}
NEW = [
    "simulation/isolation/pipe_read.py",
    "tests/simulation/test_pipe_read.py",
    "docs/pipe_read_boundary.md",
]


def save(name, obj):
    with (D / name).open("x", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def safe_pin(base, rel, pin):
    r = PurePosixPath(rel)
    assert not r.is_absolute() and ".." not in r.parts and "\\" not in rel
    p = base / rel
    st = p.lstat()
    assert p.resolve().is_relative_to(base.resolve()) and stat.S_ISREG(st.st_mode)
    assert not getattr(st, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT
    assert st.st_size == pin["bytes"] and sha(p) == pin["sha256"], rel


async def main():
    assert not (D / "main-verification.json").exists()
    scope = json.loads((ROOT / "docs/competition/deepeye-2026/immutable_scope.json").read_bytes())
    req = hashlib.sha256(json.dumps(
        scope["requirements"], ensure_ascii=False, sort_keys=True,
        separators=(",", ":")).encode()).hexdigest()
    assert req == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
    transfer = json.loads((ROOT / ".planning/deepeye-desktop-handoff-20261015/transfer.json").read_bytes())
    assert transfer['status'] == 'active' and transfer['director_generation'] == 2
    assert transfer['new_director_thread_id'] == '01a13d7e-dcf1-7272-a738-a637dd62ff9d'
    save("transfer-observed.json", transfer)
    sys.path.insert(0, str(ROOT))
    from fpga_mesh.child_control import LocalControlFileClient
    client = LocalControlFileClient(ROOT / ".local/deployment/node-a/.local/node-a/main-control.json")
    groups = {}
    for name, (expected, count, job_id) in GROUPS.items():
        folder = OUT / name
        assert sha(folder / "artifact-manifest.json") == expected
        rows = json.loads((folder / "artifact-manifest.json").read_bytes())["files"]
        assert len(rows) == count
        for rel, pin in rows.items():
            safe_pin(folder, rel, pin)
        job = await client.call("job", {"job_id": job_id})
        assert job["status"] == "completed" and job["terminal"] and not job.get("stale", False)
        assert job["result"]["text"] == (folder / "final-result.txt").read_text(encoding="utf-8")
        groups[name] = dict(manifest_sha256=expected, files=count, job_id=job_id,
                            completed=True, terminal=True, exact_result_text=True)
    review = OUT / "r03-pipe-read-independent-20261021"
    inputs = json.loads((review / "input-pins.json").read_bytes())["project_source_files"]
    assert len(inputs) == 37
    for rel, pin in inputs.items():
        safe_pin(PRODUCT, rel, pin)
    v = json.loads((review / "verification.json").read_bytes())
    assert v["verification"] == "pass" and not v["independent_failures"]
    assert len(v["independent_controls"]) == 2
    assert all(x["status"] == "pass" for x in v["independent_controls"])
    native = v["independent_terminal"]
    assert native["status"] == "success" and native["exit_code"] == 0
    assert native["active_processes_final"] == 0 and native["all_processes_terminated"]
    assert len(native["held_members"]) == 3
    assert all(x["signaled"] and x["wait_result"] == 0 for x in native["held_members"])
    assert v["native_endpoint_closes"] == 4 and v["project_cache_reads"] == 0
    protected = json.loads((OUT / "r03-mailbox-stop-main-review-20261020/application.json").read_bytes())["protected_files"]
    for rel, expected in protected.items():
        assert sha(PRODUCT / rel) == expected, rel
    head = subprocess.run(
        ["git", "-c", "core.longpaths=true", "-C", str(PRODUCT), "rev-parse", "HEAD"],
        capture_output=True, check=True, timeout=10,
        creationflags=subprocess.CREATE_NO_WINDOW).stdout.decode().strip()
    assert head == "68814fc6963f8ad8e774aa25f598bbd94c34acc1"
    proof = dict(
        utc=datetime.now(timezone.utc).isoformat(), product_head=head,
        source_groups=groups, rehashed_product_inputs=len(inputs),
        product_files={rel: inputs["competition/deepeye/" + rel] for rel in NEW},
        requirements_sha256=req, independent_controls=2,
        native_endpoint_closes=4, independent_held_processes_signaled=3,
        protected_files_unchanged=True, author_final="12/12; prior RED and failed GREEN preserved",
        production_consumer="none", production_factory="closed",
        R03="not_run", full_H12="not_run", all29="not_run")
    save("main-verification.json", proof)
    print(json.dumps(dict(files=78, current_sources=37, original_terminals=2,
                          independent_controls=2, verified=True)))


asyncio.run(main())
