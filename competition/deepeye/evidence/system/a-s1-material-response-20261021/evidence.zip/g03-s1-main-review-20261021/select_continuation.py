"""Review the sealed import failure and select a separate harness-only continuation."""
import datetime, hashlib, json
from pathlib import Path
D=Path(__file__).resolve().parent; OUT=D.parent; ROOT=OUT.parents[1]
OLD=OUT/'g03-s1-off-axis-contrast-20261021'
NEW=OUT/'g03-s1-cache-path-continuation-20261021'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x',encoding='utf-8') as f: json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False); f.write('\n')
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
assert hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
t=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
assert t['status']=='active' and t['director_generation']==2 and t['new_director_thread_id']=='01a13d7e-dcf1-7272-a738-a637dd62ff9d'
manifest=read(OLD/'manifest.json')
for name,pin in manifest['files'].items():
    p=OLD/name
    assert p.stat().st_size==pin['bytes'] and digest(p)==pin['sha256'], name
pins=read(OLD/'frozen-source-pins.json')
for name,pin in pins.items():
    p=ROOT/name
    assert p.stat().st_size==pin['bytes'] and digest(p)==pin['sha256'], name
terminals={n:read(OLD/n/'terminal.json') for n in ('author-red-01','controls-01')}
assert all(v['all_processes_terminated'] and v['active_processes_final']==0 for v in terminals.values())
assert terminals['controls-01']['exit_code']==1
failure=read(OLD/'controls-01/failure.json')
assert failure['type']=='OSError' and 'Matplotlib requires access to a writable cache directory' in failure['message']
assert all(v==0 for v in failure['counts'].values())
assert not (OLD/'oracle-01').exists() and not (OLD/'run-01').exists()
response=read(OLD/'native-complete-response.json')
if 'content' in response: response=json.loads(next(c['text'] for c in response['content'] if c.get('type')=='text'))
save(D/'original-native-response-observation.json',response)
NEW.mkdir(exist_ok=False)
a=read(OLD/'assignment.json')
a['work_id']='A-G03-S1-CACHE-PATH-CONTINUATION-20261021-v1'
a['ownership']=[NEW.relative_to(ROOT).as_posix()]
a['predecessor']={'work_id':manifest['work_id'],'native_job_id':'child-584c780568294d39974150f2613846f2','manifest':(OLD/'manifest.json').relative_to(ROOT).as_posix(),'manifest_sha256':digest(OLD/'manifest.json'),'status':'failed before numerical controls; preserve immutable evidence'}
a['selected_scope']='Separate harness-only continuation of the unchanged selected S1 physics, after the sealed pre-controls cache-path import failure. No old passed tests or RED replay.'
a['implementation_constraint']='Copy the six frozen Python files from predecessor. Keep s1_geometry.py, s1_model.py, s1_oracle.py, s1_worker.py and test_controls.py byte-identical. In run_s1.py change only this work ID and stage-specific TEMP/TMP/TMPDIR/MPLCONFIGDIR plus MPLBACKEND=Agg; create/read inputs only within this new ownership. Pin all source changes and original source hashes. No dependency modifications or scientific tolerance changes.'
a['selected_execution']='Reuse predecessor actual RED and import-failure evidence. Execute newly unrun controls once with fixed stage cache path; only on success run the selected oracle once, then only on success one actual new RHS solve. No additional retry after new process or numerical failure; report original held handle terminals immediately. Original failed native job cannot resume; use this new reservation.'
save(NEW/'assignment.json',a)
save(NEW/'reserve-request.json',{'task_id':a['task_id'],'task_version':a['task_version'],'work_id':a['work_id'],'ownership':a['ownership'],'reason':'Correct the independently identified stage cache environment without replaying completed tests or changing S1 science.','text':json.dumps(a,ensure_ascii=False)})
review={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACCEPT_SEALED_PRE_CONTROL_IMPORT_FAILURE; SELECT_HARNESS_ONLY_CONTINUATION','verified_manifest_files':len(manifest['files']),'verified_source_pins':len(pins),'original_manifest_sha256':digest(OLD/'manifest.json'),'source_pins_sha256':digest(OLD/'frozen-source-pins.json'),'native_response_sha256':digest(OLD/'native-complete-response.json'),'failure':'Stage-only write audit rejects task-parent TEMP; unconditional Geoana import reaches Matplotlib cache configuration before test_controls.run.','root_cause_source':'run_s1.py assigns TEMP/TMP/TMPDIR to D; s1_worker.py permits writes only below stage.','new_selection':a['work_id'],'no_old_test_or_solve_replay':True,'numerical_oracle_and_actual_not_run':True,'static_review':'Fixed selected source equations, complex admittivity derivative, three-component oriented trace, independent H-flux oracle and saved-AII reuse agree with selected S1 design. No source change is needed for the observed import failure.','limitations':['Selected fixed valid poses only; generic pose parser acceptance absent.','Near-cancellation relative interpretation requires actual voltage observation; no floor or tolerance relaxation.','Read isolation is in-process audit evidence, not operating-system sandbox proof.','Timer thresholds are sampled, not hard wall-time bounds.','Physical and formal G03 acceptance remain unqualified.']}
save(D/'pre-control-review.json',review)
print(json.dumps(review,ensure_ascii=False))
print(str(NEW/'reserve-request.json'))
