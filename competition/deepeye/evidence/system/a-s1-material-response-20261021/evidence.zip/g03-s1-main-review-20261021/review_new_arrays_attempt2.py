"""Independently review new saved S1 arrays. No Green evaluation or LU replay."""
import json,math,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;OUT=D.parent;ROOT=OUT.parents[1]
S=OUT/'g03-s1-cache-path-continuation-20261021';C=S/'controls-01';O=S/'oracle-01';A=S/'run-01'
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.startfile','socket.connect','socket.bind','socket.getaddrinfo'):
        raise RuntimeError('review forbids new processes, network and UI')
    if event=='open' and not isinstance(args[0],int):
        mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writing and not Path(args[0]).resolve().is_relative_to(D):raise RuntimeError('unowned write')
sys.addaudithook(audit)
import numpy as np
from scipy.sparse import csc_matrix
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def load(p):return np.load(p,allow_pickle=False)
def csum(x):
    x=np.asarray(x).ravel()
    return complex(math.fsum(float(t.real) for t in x),math.fsum(float(t.imag) for t in x))
def pairs(x):return [[float(v.real),float(v.imag)] for v in x]
def equal_roundoff(a,b,scale):
    assert np.all(np.isfinite(a)) and np.all(np.isfinite(b))
    assert np.all(np.abs(a-b)<=eps*np.asarray(scale))
eps=128*np.finfo(float).eps
p=read(S/'assignment.json')['inputs'];omega=2*math.pi*p['frequency_Hz'];mu=p['mu_background_Hpm'];turns=p['turns']
normal=np.asarray(p['Rx_normal_unnormalized'],dtype=float);normal/=np.linalg.norm(normal)
zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm']
oracle=read(O/'result.json');assert oracle['status']=='oracle_pass'
born=load(O/'Born_derivative_V.npy');flux=load(O/'primary_flux_V.npy');line=load(O/'primary_line_V.npy')
flux_records=[];near_cancellation=[]
for li,label in enumerate(('low','high')):
    E=load(O/f'{label}_primary_at_volume_Vpm.npy');dv=load(O/f'{label}_volume_weights_m3.npy');mom=load(O/f'{label}_equivalent_current_moments_Am.npy')
    reconstructed=(p['sigma_background_Spm']*E+1j*omega*p['epsilon_background_Fpm']*E)*dv[:,None]
    equal_roundoff(reconstructed,mom,np.abs(zeta*E)*dv[:,None])
    for ri in range(2):
        weights=load(O/f'{label}_rx{ri+1}_receiver_disk_weights_m2.npy')
        for field,expected in [('born',born[li,ri]),('primary',flux[li,ri])]:
            H=load(O/f'{label}_rx{ri+1}_{field}_H_Apm.npy')
            terms=H*normal[None,:]*weights[:,None]
            observed=-1j*omega*mu*turns*csum(terms)
            absolute_sum=omega*mu*turns*float(np.sum(np.abs(terms)))
            equal_roundoff(observed,expected,absolute_sum)
            flag=abs(observed)<=eps*absolute_sum
            near_cancellation.append(flag)
            flux_records.append({'level':label,'receiver':ri+1,'field':field,'independent_fsum_V':pairs([observed])[0],'absolute_difference_V':float(abs(observed-expected)),'roundoff_bound_V':eps*absolute_sum,'sum_absolute_terms_V':absolute_sum,'roundoff_near_cancellation':bool(flag)})
assert np.all(np.abs(born[1])>0) and not any(near_cancellation),'relative result needs undefined-cancellation treatment'
screens={'primary_line_pair':abs(line[0]-line[1])/abs(line[1]),'primary_flux_pair':abs(flux[0]-flux[1])/abs(flux[1]),'primary_line_vs_H_flux':abs(line[1]-flux[1])/abs(flux[1]),'Born_quadrature_pair':abs(born[0]-born[1])/abs(born[1])}
for name,values in screens.items():
    assert np.all(values<=.001)
    equal_roundoff(values,np.asarray(oracle['relative_screens'][name]),np.maximum(values,np.asarray(oracle['relative_screens'][name])))
actual=read(A/'result.json');I=load(C/'interior_indices.npy');B=load(C/'boundary_indices.npy');d=load(C/'delta_mass_diag_Sm2.npy');support=load(C/'primary_support_indices.npy');primary=load(C/'primary_support_high_Vpm.npy')
assert np.array_equal(np.sort(np.r_[I,B]),np.arange(len(d)))
new_rhs=np.zeros(len(d),dtype=complex)
new_rhs[support]=omega*d[support].imag*primary-1j*omega*d[support].real*primary
stored_rhs=load(A/'new_derivative_RHS.npy');equal_roundoff(new_rhs,stored_rhs,omega*np.abs(d)*np.abs(load(A/'primary_on_contrast_only_Vpm.npy')))
assert np.array_equal(load(A/'new_reduced_RHS.npy'),stored_rhs[I]) and np.all(stored_rhs[B]==0) and np.any(stored_rhs!=0)
x=load(A/'interior_derivative_Vpm.npy');field=load(A/'full_derivative_Vpm.npy')
assert np.array_equal(field[I],x) and np.all(field[B]==0) and np.all(np.isfinite(field))
with load(OUT/'g03-l5-propagation-z-refinement-20261021/run-01/AII-csc.npz') as z:
    system=csc_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape'])).tocsr()
rhs=stored_rhs[I];residual=system.dot(x)-rhs
scale=float(np.max(np.asarray(abs(system).sum(axis=1)).ravel()))*float(np.max(abs(x)))+float(np.max(abs(rhs)))
eta=float(np.max(abs(residual)))/scale
assert math.isfinite(eta) and eta<=eps
roundoff_scale=abs(system).dot(abs(x))+abs(rhs)
equal_roundoff(residual,load(A/'residual.npy'),roundoff_scale)
traces=load(C/'receiver_trace_m.npy');voltage=[];voltage_scales=[]
for row in traces:
    terms=row[row!=0]*field[row!=0];voltage.append(csum(terms));voltage_scales.append(float(np.sum(abs(terms))))
voltage=np.asarray(voltage);stored_voltage=load(A/'derivative_voltage_V.npy');equal_roundoff(voltage,stored_voltage,voltage_scales)
assert np.array_equal(load(A/'independent_Born_voltage_V.npy'),born[1])
relative=abs(voltage-born[1])/abs(born[1]);reported=np.asarray(actual['relative_error'])
equal_roundoff(relative,reported,relative+reported)
passed=eta<=eps and bool(np.all(relative<=.01))
assert actual['status']==('one_new_derivative_solve_screens_pass' if passed else 'one_new_derivative_solve_screen_failed')
result={'status':'ACCEPT_NEW_S1_EVIDENCE_ONLY','new_screens_pass':passed,'independent_residual_eta':eta,'eta_gate':eps,'independent_trace_V':pairs(voltage),'independent_Born_flux_reduction':flux_records,'oracle_relative_screens':{k:v.tolist() for k,v in screens.items()},'relative_derivative_errors':relative.tolist(),'absolute_derivative_errors_V':abs(voltage-born[1]).tolist(),'derivative_relative_gate':.01,'trace_fsum_vs_stored_absolute_V':abs(voltage-stored_voltage).tolist(),'factorizations':0,'matrix_assemblies':0,'Green_evaluations':0,'old_tests_repeated':False,'near_cancellation':'not observed at the component reduction roundoff bound; no artificial denominator floor','physical_accuracy':'unqualified','finite_tau':'not_run','G03':'not_run','R03':'not_run','all29':'not_run'}
with (D/'array-review.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(result))
