"""Independent homogeneous Green H/volume/flux reference; no mesh/operator imports."""
import math
import numpy as np
from geoana.em.fdem import ElectricDipoleWholeSpace
import s1_geometry as g
def unit_H(observations,source,axis,p):
    orientation=np.eye(3)[axis]
    dip=ElectricDipoleWholeSpace(frequency=p['frequency_Hz'],quasistatic=False,location=source,orientation=orientation,current=1.,length=1.,sigma=p['sigma_background_Spm'],mu=p['mu_background_Hpm'],epsilon=p['epsilon_background_Fpm'])
    return np.asarray(dip.magnetic_field(observations)).reshape(-1,3)
def sum_H(observations,sources,moments,p):
    out=np.zeros((len(observations),3),dtype=complex)
    for i in range(0,len(observations),2048):
        x=observations[i:i+2048];part=np.zeros((len(x),3),dtype=complex)
        for source,moment in zip(sources,moments):
            for axis in range(3):
                if moment[axis]!=0:part+=moment[axis]*unit_H(x,source,axis,p)
        out[i:i+2048]=part
    return out
def flux_voltage(rx,sources,moments,p,nr,nt):
    x,w=rx.disk(nr,nt);H=sum_H(x,sources,moments,p)
    value=-1j*(2*math.pi*p['frequency_Hz'])*p['mu_background_Hpm']*p['turns']*np.sum((H@rx.n)*w)
    return value,x,w,H
def run(stage,p):
    tx,rxs=g.selected_coils(p);omega=2*math.pi*p['frequency_Hz']
    zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm']
    line=[];primary_flux=[];born=[]
    for label,nt,nv,nr,na in [('low',128,4,8,64),('high',256,8,16,128)]:
        sources,volume=g.box_quadrature(p,nv);E=g.primary(sources,tx,p,nt)
        moments=zeta*E*volume[:,None]
        wire,dl=tx.line(nt);wire_moments=p['Tx_current_A']*p['turns']*dl
        current_line=[];current_primary=[];current_born=[]
        for i,rx in enumerate(rxs):
            g.assert_separated_boxes(rx.bounds(),(np.array(p['contrast_box_min_m']),np.array(p['contrast_box_max_m'])))
            V,x,w,H=flux_voltage(rx,sources,moments,p,nr,na)
            P,_,_,HP=flux_voltage(rx,wire,wire_moments,p,nr,na)
            current_born.append(V);current_primary.append(P);current_line.append(g.primary_line_voltage(rx,tx,p,nt))
            for name,array in {'receiver_disk_points_m':x,'receiver_disk_weights_m2':w,'born_H_Apm':H,'primary_H_Apm':HP}.items():g.save_array(stage/f'{label}_rx{i+1}_{name}.npy',array)
        for name,array in {'volume_points_m':sources,'volume_weights_m3':volume,'primary_at_volume_Vpm':E,'equivalent_current_moments_Am':moments}.items():g.save_array(stage/f'{label}_{name}.npy',array)
        line.append(current_line);primary_flux.append(current_primary);born.append(current_born)
    line=np.array(line);primary_flux=np.array(primary_flux);born=np.array(born)
    screens={'primary_line_pair':g.relative_pair(line[0],line[1]).tolist(),'primary_flux_pair':g.relative_pair(primary_flux[0],primary_flux[1]).tolist(),
        'primary_line_vs_H_flux':g.relative_pair(line[1],primary_flux[1]).tolist(),'Born_quadrature_pair':g.relative_pair(born[0],born[1]).tolist()}
    for name,array in {'primary_line_V':line,'primary_flux_V':primary_flux,'Born_derivative_V':born,'Born_pair_absolute_difference_V':abs(born[1]-born[0])}.items():g.save_array(stage/(name+'.npy'),array)
    passed=all(v<=.001 for values in screens.values() for v in values)
    return {'status':'oracle_pass' if passed else 'oracle_screen_failed','relative_screens':screens,'fixed_gate':.001,'primary_line_high_V':g.pairs(line[1]),'primary_flux_high_V':g.pairs(primary_flux[1]),'Born_high_derivative_V':g.pairs(born[1]),'Born_pair_absolute_difference_V':abs(born[1]-born[0]).tolist(),
        'reference_scope':'exact first derivative at zero strength, infinite homogeneous background; not finite tau','grid_operator_or_solved_field_reads':0,'excluded_E_and_current_density_calls':0}
