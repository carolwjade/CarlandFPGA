"""One held, granted S1 controls/oracle/actual process; no automatic continuation."""
import hashlib,json,math,os,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
stage=Path(sys.argv[1]).resolve();mode=sys.argv[2]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,value):
    with p.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
save(stage/'hello.json',{'pid':os.getpid(),'mode':mode,'before_scientific_import':True})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('no held science grant')
    time.sleep(.01)
grant=read(stage/'grant.json');assert grant['worker']['pid']==os.getpid() and grant['mode']==mode
p=read(D/'assignment.json')['inputs']
sys.path.insert(0,str(D))
site=(ROOT/'.local/deepeye-fdem-validation-20261020/Lib/site-packages').resolve()
denied=[]
def audit(event,args):
    if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):
        raise PermissionError('S1 worker prohibits network/subprocess effects')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).resolve()
        modes=args[1] if len(args)>1 else None
        flags=args[2] if len(args)>2 else 0
        writing=(isinstance(modes,str) and any(c in modes for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
        if writing and not path.is_relative_to(stage):raise PermissionError('write outside owned stage')
        if mode=='oracle' and not writing and path.is_relative_to(ROOT):
            allowed=(path.is_relative_to(site) or path.is_relative_to(stage) or path in [D/n for n in ('s1_geometry.py','s1_oracle.py','s1_worker.py')])
            if not allowed:
                denied.append(str(path));raise PermissionError('oracle cannot read grid/mass/RHS/fields or other project data')
sys.addaudithook(audit)
started=time.monotonic();counts={'C_constructions':0,'A_assemblies':0,'factorizations':0,'RHS_columns':0}
def threads():
    import ctypes as ct
    import numpy as np
    import scipy.linalg
    kernel=ct.WinDLL('kernel32',use_last_error=True)
    kernel.GetModuleHandleW.argtypes=[ct.c_wchar_p];kernel.GetModuleHandleW.restype=ct.c_void_p
    rows=[]
    for folder,symbol in [('numpy.libs','scipy_openblas_get_num_threads64_'),('scipy.libs','scipy_openblas_get_num_threads')]:
        paths=list((Path(np.__file__).resolve().parents[1]/folder).glob('*openblas*.dll'))
        assert len(paths)==1
        handle=kernel.GetModuleHandleW(str(paths[0]));assert handle
        getter=getattr(ct.CDLL(str(paths[0]),handle=handle),symbol);getter.argtypes=[];getter.restype=ct.c_int
        count=getter();assert count==1
        rows.append({'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),'threads':count})
    return rows
try:
    before=threads()
    import numpy as np
    import s1_geometry as g
    if mode=='controls':
        import test_controls
        result=test_controls.run(stage,p)
    elif mode=='oracle':
        blocked=False
        try:
            (D.parent/'g03-l5-propagation-z-refinement-20261021/run-01/AII-csc.npz').open('rb')
        except PermissionError:blocked=True
        if not blocked:raise AssertionError('oracle read isolation failed')
        import s1_oracle
        result=s1_oracle.run(stage,p)
        result['forbidden_old_operator_open_rejected']=blocked
        result['denied_reads']=denied
    elif mode=='actual':
        from scipy import sparse
        from scipy.sparse.linalg import splu
        import gc,warnings
        control=D/'controls-01'
        def load(name):return np.load(control/(name+'.npy'),allow_pickle=False)
        I=load('interior_indices');B=load('boundary_indices');d=load('delta_mass_diag_Sm2');support=load('primary_support_indices');ep=load('primary_support_high_Vpm');trace=load('receiver_trace_m')
        L5=D.parent/'g03-l5-propagation-z-refinement-20261021'
        oldI=np.load(L5/'controls-01/interior_indices.npy',allow_pickle=False)
        oldB=np.load(L5/'controls-01/boundary_indices.npy',allow_pickle=False)
        if not np.array_equal(I,oldI) or not np.array_equal(B,oldB):raise ValueError('L5 ordering differs')
        full_primary=np.zeros(len(d),dtype=complex);full_primary[support]=ep
        rhs=-1j*(2*math.pi*p['frequency_Hz'])*d*full_primary
        counts['RHS_columns']=1
        if not np.all(np.isfinite(rhs)) or not np.any(rhs!=0) or np.any(rhs[B]!=0):raise ArithmeticError('invalid new contrast forcing')
        reduced=rhs[I]
        for name,array in {'primary_on_contrast_only_Vpm':full_primary,'new_derivative_RHS':rhs,'new_reduced_RHS':reduced}.items():g.save_array(stage/(name+'.npy'),array)
        with np.load(L5/'run-01/AII-csc.npz',allow_pickle=False) as z:
            A=sparse.csc_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
        if A.shape!=(54418,54418) or not np.all(np.isfinite(A.data)):raise ValueError('saved AII shape/data')
        save(stage/'pre-factorization.json',{'status':'new_RHS_persisted','RHS_columns':1,'A_shape':A.shape,'A_nnz':int(A.nnz),'factorization_ordering':'COLAMD','factorization_started':False,'C_constructions':0,'A_assemblies':0,'boundary_secondary_E':'zero approximation; not exact radiation','RHS_nonzero':int(np.count_nonzero(rhs))})
        with warnings.catch_warnings():
            warnings.simplefilter('error')
            lu=splu(A,permc_spec='COLAMD');counts['factorizations']=1
            x=lu.solve(reduced)
        del lu;gc.collect()
        residual=A@x-reduced
        normA=float(np.max(np.asarray(abs(A).sum(axis=1)).ravel()))
        denominator=normA*float(np.max(abs(x)))+float(np.max(abs(reduced)))
        eta=float(np.max(abs(residual))/denominator)
        E=np.zeros(len(d),dtype=complex);E[I]=x
        V=trace@E
        reference=np.load(D/'oracle-01/Born_derivative_V.npy',allow_pickle=False)[1]
        difference=V-reference;absolute=np.abs(difference);relative=g.relative_pair(V,reference)
        for name,array in {'interior_derivative_Vpm':x,'full_derivative_Vpm':E,'residual':residual,'derivative_voltage_V':V,'independent_Born_voltage_V':reference,'difference_V':difference,'absolute_error_V':absolute,'relative_error':relative}.items():g.save_array(stage/(name+'.npy'),array)
        passed=eta<=128*np.finfo(float).eps and np.all(relative<=.01)
        result={'status':'one_new_derivative_solve_screens_pass' if passed else 'one_new_derivative_solve_screen_failed','counts':counts,'backward_eta':eta,'backward_eta_gate':128*np.finfo(float).eps,
            'derivative_V':g.pairs(V),'independent_Born_V':g.pairs(reference),'difference_V':g.pairs(difference),'absolute_error_V':absolute.tolist(),'relative_error':relative.tolist(),'relative_gate':.01,'physical_accuracy':'unqualified','noise_gate':'unqualified_missing_sourced_budget','finite_tau':'not_run','G03':'not_run','all29_formal':'not_run'}
    else:raise ValueError('mode')
    result['worker_elapsed_seconds']=time.monotonic()-started
    result['BLAS_before']=before;result['BLAS_after']=threads()
    save(stage/'result.json',result)
    print(json.dumps(result),flush=True)
    if result['status'] in ('oracle_screen_failed','one_new_derivative_solve_screen_failed'):raise SystemExit(2)
except BaseException as error:
    if not (stage/'failure.json').exists():save(stage/'failure.json',{'type':type(error).__name__,'message':str(error),'counts':counts,'elapsed_seconds':time.monotonic()-started,'traceback':traceback.format_exc()})
    raise
