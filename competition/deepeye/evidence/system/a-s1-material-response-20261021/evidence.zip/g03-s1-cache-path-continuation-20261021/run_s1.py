"""Frozen stage launcher: one RED, one controls, one oracle, at most one new RHS."""
import ctypes as ct
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent; ROOT=D.parents[2]
SUPPORT=D.parent/'r02-amd-wheel-acquisition-20261021'
L5=D.parent/'g03-l5-propagation-z-refinement-20261021'
PY=ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def selected_pins(mode):
    a=read(D/'assignment.json'); scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
    assert a['owner']=='/root/r02_amd_acquisition_20261021'
    assert a['work_id']=='A-G03-S1-CACHE-PATH-CONTINUATION-20261021-v1'
    assert hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==a['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
    assert transfer['status']=='active' and transfer['director_generation']==2 and transfer['new_director_thread_id']==a['director_thread_id']
    assert sha(ROOT/a['selected_design'])==a['design_sha256']
    assert sha(L5/'public-manifest.json')==a['background_manifest_sha256']
    manifest=read(L5/'public-manifest.json')
    old=['assignment.json','run-01/AII-csc.npz','controls-01/interior_indices.npy','controls-01/boundary_indices.npy']
    files=[D/'assignment.json',D/'run_s1.py',D/'test_controls.py',ROOT/a['selected_design'],L5/'public-manifest.json',PY]
    files += [SUPPORT/n for n in ('win_job.py','boundary.py')]
    for n in old:
        assert sha(L5/n)==manifest['files'][n]['sha256']
        files.append(L5/n)
    if mode!='red':
        files += [D/n for n in ('s1_geometry.py','s1_model.py','s1_oracle.py','s1_worker.py')]
        sp=ROOT/'.local/deepeye-fdem-validation-20261020/Lib/site-packages'
        for rel in ('geoana/em/fdem/wholespace.py','geoana/em/fdem/base.py','discretize/base/base_tensor_mesh.py','discretize/operators/inner_products.py'):
            files.append(sp/rel)
    return {p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files}
def memory():
    class MS(ct.Structure):
        _fields_=[('length',ct.c_uint32),('load',ct.c_uint32)]+[(n,ct.c_uint64) for n in ('total_physical','available_physical','total_page_file','available_page_file','total_virtual','available_virtual','extended_virtual')]
    s=MS();s.length=ct.sizeof(s)
    if not ct.windll.kernel32.GlobalMemoryStatusEx(ct.byref(s)):raise OSError('GlobalMemoryStatusEx')
    return {'available_physical_bytes':s.available_physical,'minimum_required_bytes':10*1024**3,'sufficient':s.available_physical>=10*1024**3}
def main():
    mode=sys.argv[1];assert mode in ('red','controls','oracle','actual')
    pins=selected_pins(mode); pinfile=D/('red-source-pins.json' if mode=='red' else 'frozen-source-pins.json')
    if not pinfile.exists():save(pinfile,pins)
    else:assert read(pinfile)==pins
    if mode=='red':
        assert not (D/'s1_model.py').exists()
    if mode=='oracle':
        assert read(D/'controls-01/result.json')['status']=='controls_pass'
        assert read(D/'controls-01/terminal.json')['all_processes_terminated']
    if mode=='actual':
        for folder,expected in [('controls-01','controls_pass'),('oracle-01','oracle_pass')]:
            assert read(D/folder/'result.json')['status']==expected
            t=read(D/folder/'terminal.json');assert t['status']=='success' and t['all_processes_terminated']
        observation=memory();save(D/'actual-memory-preflight.json',observation)
        if not observation['sufficient']:raise RuntimeError('fresh physical memory gate failed')
    sys.path.insert(0,str(SUPPORT));from win_job import run_bounded,process_identity
    stage=D/({'red':'author-red-01','controls':'controls-01','oracle':'oracle-01','actual':'run-01'}[mode]);granted=False
    env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),'PATH':'','TEMP':str(stage),'TMP':str(stage),'TMPDIR':str(stage),'MPLCONFIGDIR':str(stage/'mplconfig'),'MPLBACKEND':'Agg','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',**{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','VECLIB_MAXIMUM_THREADS')}}
    budget={'seconds':90 if mode=='actual' else 60,'active_processes':4,'process_memory_bytes':4*1024**3 if mode=='actual' else 512*1024**2,'job_memory_bytes':5*1024**3 if mode=='actual' else 1024**3,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':128*1024**2,'tree_entries':2048,'free_reserve_bytes':512*1024**2,'components':[{'path':str(stage),'bytes':128*1024**2,'entries':2048}]}
    def tick(job,pids):
        nonlocal granted
        if mode!='red' and (stage/'hello.json').exists() and not granted:
            h=read(stage/'hello.json');assert h['pid'] in pids and h['mode']==mode
            save(stage/'grant.pending.json',{'worker':process_identity(h['pid'],job),'mode':mode,'source_pins':pins})
            os.replace(stage/'grant.pending.json',stage/'grant.json');granted=True
    script=D/('test_controls.py' if mode=='red' else 's1_worker.py')
    args=[str(PY),'-I','-B','-X','utf8',str(script),str(stage),mode]
    if mode=='red':
        args=[str(PY),'-I','-B','-X','utf8','-c',"import sys; sys.path.insert(0,sys.argv[1]); import test_controls",str(D)]
    result=run_bounded(args,env,D,stage,budget,[D],on_tick=tick)
    after=selected_pins(mode);save(stage/'input-readback.json',{'unchanged':pins==after,'before':pins,'after':after})
    assert result['all_processes_terminated'] and pins==after
    if mode=='red':
        stderr=(stage/'stderr.txt').read_text(encoding='utf-8')
        assert result['exit_code']==1 and "No module named 's1_model'" in stderr
        save(stage/'author-red.json',{'status':'expected_absent_implementation_RED','actual_exit_code':1,'actual_process_status':result['status'],'all_processes_terminated':True,'note':'Control specification import fails because s1_model implementation is absent, before scientific imports.'})
    print(json.dumps({k:result.get(k) for k in ('status','exit_code','seconds','stop_reason','all_processes_terminated','held_members')}),flush=True)
    raise SystemExit(0 if mode=='red' else (result['exit_code'] if result['exit_code'] is not None else 125))
if __name__=='__main__':main()
