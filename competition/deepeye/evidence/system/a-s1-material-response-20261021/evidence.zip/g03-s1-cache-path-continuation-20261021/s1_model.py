"""New contrast mass/support and true-circle compatible trace. No curl/A assembly."""
import json, math
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss
from discretize import TensorMesh
import s1_geometry as g
D=Path(__file__).resolve().parent
def mesh_selected():
    a=json.loads((D.parent/'g03-l5-propagation-z-refinement-20261021/assignment.json').read_text(encoding='utf-8'))
    x=np.array(a['level']['x_nodes_m']);z=np.array(a['z_nodes_m'])
    mesh=TensorMesh([np.diff(x),np.diff(x),np.diff(z)],origin=[x[0],x[0],z[0]])
    if mesh.shape_cells!=(24,24,34):raise ValueError('selected mesh geometry')
    return mesh
def edge_geometry(mesh):
    mid=np.asarray(mesh.edges);axes=np.repeat(np.arange(3),[mesh.n_edges_x,mesh.n_edges_y,mesh.n_edges_z])
    delta=np.zeros_like(mid);delta[np.arange(len(mid)),axes]=mesh.edge_lengths/2
    return mid-delta,mid+delta,axes
def trace(mesh,rx,order):
    nodes=[mesh.nodes_x,mesh.nodes_y,mesh.nodes_z];breaks=[0.,2*math.pi]
    for axis in range(3):
        amp=rx.a*math.hypot(rx.u[axis],rx.v[axis])
        if amp<=1e-15:continue
        phase=math.atan2(rx.v[axis],rx.u[axis])
        for point in nodes[axis]:
            c=(point-rx.c[axis])/amp
            if -1<c<1:
                t=math.acos(c)
                breaks.extend([(phase-t)%(2*math.pi),(phase+t)%(2*math.pi)])
    breaks.sort();unique=[breaks[0]]
    for b in breaks[1:]:
        if b-unique[-1]>1e-12:unique.append(b)
    if unique[-1]<2*math.pi-1e-12:unique.append(2*math.pi)
    q,w=leggauss(order);weights=np.zeros(mesh.n_edges)
    offsets=[0,mesh.n_edges_x,mesh.n_edges_x+mesh.n_edges_y]
    shapes=[mesh.shape_edges_x,mesh.shape_edges_y,mesh.shape_edges_z]
    for lower,upper in zip(unique[:-1],unique[1:]):
        theta=(lower+upper)/2+(upper-lower)*q/2
        x,dl=rx.at(theta);dl=dl*(w*(upper-lower)/2)[:,None]
        cell=[np.searchsorted(nodes[j],x[:,j],side='right')-1 for j in range(3)]
        if any(np.any((cell[j]<0)|(cell[j]>=len(nodes[j])-1)) for j in range(3)):raise ValueError('receiver outside mesh')
        frac=[(x[:,j]-nodes[j][cell[j]])/(nodes[j][cell[j]+1]-nodes[j][cell[j]]) for j in range(3)]
        for axis in range(3):
            transverse=[j for j in range(3) if j!=axis]
            for aa in (0,1):
                for bb in (0,1):
                    sub=[v.copy() for v in cell];shapeweight=np.ones(len(q))
                    for j,offset in zip(transverse,(aa,bb)):
                        sub[j]+=offset;shapeweight*=frac[j] if offset else (1-frac[j])
                    ind=offsets[axis]+np.ravel_multi_index(tuple(sub),shapes[axis],order='F')
                    np.add.at(weights,ind,dl[:,axis]*shapeweight)
    return weights
def prepare(mesh,p):
    tx,rxs=g.selected_coils(p);low=np.array(p['contrast_box_min_m']);high=np.array(p['contrast_box_max_m'])
    nodes=[mesh.nodes_x,mesh.nodes_y,mesh.nodes_z]
    if any(np.min(abs(nodes[j]-low[j]))>1e-12 or np.min(abs(nodes[j]-high[j]))>1e-12 for j in range(3)):raise ValueError('contrast boundary not aligned')
    inside=np.all((mesh.cell_centers>low)&(mesh.cell_centers<high),axis=1)
    omega=2*math.pi*p['frequency_Hz'];sig=p['sigma_background_Spm'];eps=p['epsilon_background_Fpm']
    d=mesh.get_edge_inner_product((sig+1j*omega*eps)*inside).diagonal()
    separate=mesh.get_edge_inner_product(sig*inside).diagonal()+1j*omega*mesh.get_edge_inner_product(eps*inside).diagonal()
    relative=float(np.max(abs(d-separate))/np.max(abs(d)))
    support=np.flatnonzero(d!=0);starts,ends,axes=edge_geometry(mesh)
    if not len(support):raise ValueError('empty contrast support')
    support_bounds=(np.minimum(starts[support].min(axis=0),ends[support].min(axis=0)),np.maximum(starts[support].max(axis=0),ends[support].max(axis=0)))
    gap=g.assert_separated_boxes(tx.bounds(),support_bounds)
    gaps=[g.assert_separated_boxes(rx.bounds(),(low,high)) for rx in rxs]
    primary=[]
    for nt,ne in ((128,8),(256,16)):
        q,w=leggauss(ne);x=(starts[support,None,:]+ends[support,None,:])/2+(ends[support,None,:]-starts[support,None,:])*q[None,:,None]/2
        E=g.primary(x.reshape(-1,3),tx,p,nt).reshape(len(support),ne,3)
        component=np.take_along_axis(E,axes[support,None,None],axis=2)[:,:,0]
        primary.append(component@(w/2))
    epair=float(np.max(abs(primary[1]-primary[0]))/np.max(abs(primary[1])))
    traces=np.array([trace(mesh,rx,16) for rx in rxs])
    B=np.sort(mesh.project_edge_to_boundary_edge.indices);mask=np.ones(mesh.n_edges,dtype=bool);mask[B]=False;I=np.flatnonzero(mask)
    bundle={'delta_mass_diag_Sm2':d,'primary_support_indices':support,'primary_support_low_Vpm':primary[0],'primary_support_high_Vpm':primary[1],
        'receiver_trace_m':traces,'interior_indices':I,'boundary_indices':B,'contrast_cell_indices':np.flatnonzero(inside),'support_starts_m':starts[support],'support_ends_m':ends[support]}
    return bundle,{'complex_mass_relative_difference':relative,'primary_support_relative_pair':epair,'contrast_cells':int(np.count_nonzero(inside)),'supported_edges':len(support),
        'wire_support_AABB_separation_lower_m':gap,'Rx_contrast_AABB_separation_lower_m':gaps,'mu_contrast':0,'epsilon_contrast_retained':True}
