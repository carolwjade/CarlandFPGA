"""S1-specific acceptance controls, written before implementation."""
import s1_model as m
import s1_geometry as g
import s1_oracle as oracle
import numpy as np
import math

def check(condition, message):
    if not condition:
        raise AssertionError(message)

def run(stage, p):
    mesh = m.mesh_selected()
    tx, rxs = g.selected_coils(p)
    rows = []
    for rx in rxs:
        check(np.max(abs(np.column_stack((rx.u, rx.v, rx.n)).T @ np.column_stack((rx.u, rx.v, rx.n))-np.eye(3))) < 32*np.finfo(float).eps, 'pose orthonormal')
        check(np.linalg.det(np.column_stack((rx.u, rx.v, rx.n))) > 0, 'proper pose')
        lo, hi = m.trace(mesh, rx, 8), m.trace(mesh, rx, 16)
        rev = m.trace(mesh, g.Circle(rx.c, rx.a, -rx.n), 16)
        starts, ends, axes = m.edge_geometry(mesh)
        mid = .5*(starts+ends)
        const = np.array([.7, -.3, .2])[axes]
        curl = np.array([.4, -.2, .7])
        vector = .5*np.cross(np.broadcast_to(curl, mid.shape), mid)
        field = vector[np.arange(len(axes)), axes]
        expected = math.pi*rx.a**2*np.dot(curl, rx.n)
        bound = 128*np.finfo(float).eps*max(np.sum(abs(hi))*np.max(abs(field)), abs(expected))
        check(abs(hi@const) <= 128*np.finfo(float).eps*np.sum(abs(hi))*np.max(abs(const)), 'constant field circulation')
        check(abs(hi@field-expected) <= bound, 'known curl circulation')
        check(np.max(abs(hi+rev)) <= 128*np.finfo(float).eps*np.sum(abs(hi)), 'reversed winding sign')
        check(all(np.any(hi[axes==a] != 0) for a in range(3)), 'all three components in tilted trace')
        check(np.max(abs(hi-lo)) <= 128*np.finfo(float).eps*np.sum(abs(hi)), 'arc quadrature pair')
        rows.append({'known_curl_expected_V': float(expected), 'observed_V': float(hi@field), 'absolute_error_V': float(abs(hi@field-expected)), 'trace_nonzero_per_component': [int(np.count_nonzero(hi[axes==a])) for a in range(3)]})
    wire, _ = tx.line(128)
    rejected = False
    try:
        g.assert_nonsingular(wire[:1], tx)
    except ValueError:
        rejected = True
    check(rejected, 'wire point must really reject')
    rejected = False
    try:
        g.assert_separated_boxes(tx.bounds(), tx.bounds())
    except ValueError:
        rejected = True
    check(rejected, 'intersecting support must really reject')
    bundle, material = m.prepare(mesh, p)
    check(material['complex_mass_relative_difference'] < 128*np.finfo(float).eps, 'sigma + i omega epsilon linear mass')
    d = bundle['delta_mass_diag_Sm2']
    omega = 2*math.pi*p['frequency_Hz']
    term = 1j*omega*d[d!=0]
    check(np.all(term.real < 0) and np.all(term.imag > 0), 'displacement stiffness negative real; conduction positive imag')
    check(np.any(bundle['primary_support_high_Vpm'] != 0), 'nonzero primary on contrast support')
    check(material['primary_support_relative_pair'] <= .001, 'fixed primary support quadrature screen')
    H_test = oracle.unit_H(np.array([[.2,.1,.3]]), np.zeros(3), 0, p)
    point = np.array([.2,.1,.3]); r = np.linalg.norm(point); k = np.sqrt(omega**2*p['mu_background_Hpm']*p['epsilon_background_Fpm']-1j*omega*p['mu_background_Hpm']*p['sigma_background_Spm'])
    expected = (1+1j*k*r)*np.exp(-1j*k*r)/(4*math.pi*r*r)*np.cross([1.,0,0],point/r)
    check(np.max(abs(H_test[0]-expected)) <= 128*np.finfo(float).eps*np.max(abs(expected)), 'selected Geoana H full-wave expression')
    q = np.sqrt(1j*omega*p['mu_background_Hpm']*(p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm']))
    check(abs(q-1j*k) < 128*np.finfo(float).eps*abs(q), 'outgoing q=i*k branch')
    for name, array in bundle.items():
        g.save_array(stage/(name+'.npy'), array)
    return {'status': 'controls_pass', 'trace_controls': rows, 'singular_wire_rejected': True, 'overlapping_support_rejected': True, 'Geoana_H_expression_pass': True, 'complex_mass': material, 'RHS_constructed': False, 'C_constructed': False, 'A_constructed': False}

if __name__ == '__main__':
    raise RuntimeError('Use the held worker; standalone import is only the author RED.')
