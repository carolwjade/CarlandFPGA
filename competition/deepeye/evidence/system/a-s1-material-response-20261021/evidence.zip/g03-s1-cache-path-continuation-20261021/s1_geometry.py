"""S1 coil geometry and homogeneous finite-loop Green primary, no mesh dependencies."""
import json, math
import numpy as np
from numpy.polynomial.legendre import leggauss

def save_json(path, value):
    with path.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
def save_array(path, value):
    with path.open('xb') as f:np.save(f,value,allow_pickle=False)
def pairs(value):return [[float(complex(v).real),float(complex(v).imag)] for v in value]
def relative_pair(low,high):
    den=np.abs(high)
    if np.any(den==0) or not np.all(np.isfinite(high)):raise ArithmeticError('undefined relative comparison')
    return np.abs(high-low)/den
class Circle:
    def __init__(self, center, radius, normal):
        self.c=np.asarray(center,dtype=float);self.a=float(radius)
        self.n=np.asarray(normal,dtype=float);self.n=self.n/np.linalg.norm(self.n)
        seed=np.array([1.,0.,0.]);u=seed-self.n*self.n[0]
        if np.linalg.norm(u)<=1e-12:raise ValueError('selected normal parallel to seed')
        self.u=u/np.linalg.norm(u);self.v=np.cross(self.n,self.u)
        if not self.a>0 or not np.all(np.isfinite(self.c)):raise ValueError('invalid circle')
    def at(self,t):
        t=np.asarray(t)
        x=self.c+self.a*(np.cos(t)[...,None]*self.u+np.sin(t)[...,None]*self.v)
        dl=self.a*(-np.sin(t)[...,None]*self.u+np.cos(t)[...,None]*self.v)
        return x,dl
    def line(self,n):
        x,dl=self.at((np.arange(n)+.5)*(2*math.pi/n));return x,dl*(2*math.pi/n)
    def disk(self,nr,nt):
        q,w=leggauss(nr);r=self.a*(q+1)/2;rw=w*(self.a/2)*r
        t=(np.arange(nt)+.5)*(2*math.pi/nt)
        x=self.c+r[:,None,None]*(np.cos(t)[None,:,None]*self.u+np.sin(t)[None,:,None]*self.v)
        weights=np.broadcast_to(rw[:,None]*(2*math.pi/nt),(nr,nt))
        return x.reshape(-1,3),weights.ravel()
    def bounds(self):
        extent=self.a*np.sqrt(self.u**2+self.v**2);return self.c-extent,self.c+extent
def selected_coils(p):
    tx=Circle(p['Tx_center_m'],p['Tx_radius_m'],p['Tx_normal_unnormalized'])
    return tx,[Circle(c,p['Rx_radius_m'],p['Rx_normal_unnormalized']) for c in p['Rx_centers_m']]
def assert_nonsingular(points,tx):
    d=np.asarray(points)-tx.c;h=d@tx.n;radial=d-h[:,None]*tx.n
    distance=np.hypot(np.linalg.norm(radial,axis=1)-tx.a,h)
    if not np.all(np.isfinite(distance)) or np.any(distance<=1e-12):raise ValueError('point on or unresolved at filament support')
    return float(np.min(distance))
def assert_separated_boxes(a,b):
    gap=np.maximum(np.maximum(np.asarray(a[0])-b[1],np.asarray(b[0])-a[1]),0.)
    lower=float(np.linalg.norm(gap))
    if lower<=1e-12:raise ValueError('support AABBs overlap or touch')
    return lower
def primary(points,tx,p,nt):
    points=np.asarray(points);assert_nonsingular(points,tx)
    source,dl=tx.line(nt);omega=2*math.pi*p['frequency_Hz']
    zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm']
    q=np.sqrt(1j*omega*p['mu_background_Hpm']*zeta)
    if q.real<0:raise ValueError('nonoutgoing branch')
    result=np.empty((len(points),3),dtype=complex)
    for i in range(0,len(points),128):
        distance=np.linalg.norm(points[i:i+128,None,:]-source[None,:,:],axis=2)
        if np.any(distance<=1e-12):raise ValueError('filament singular quadrature')
        result[i:i+128]=np.einsum('ij,jk->ik',np.exp(-q*distance)/distance,dl)
    return -1j*omega*p['mu_background_Hpm']*p['Tx_current_A']*p['turns']/(4*math.pi)*result
def primary_line_voltage(rx,tx,p,nt):
    x,dl=rx.line(nt)
    return p['turns']*np.sum(primary(x,tx,p,nt)*dl)
def box_quadrature(p,n):
    low=np.array(p['contrast_box_min_m']);high=np.array(p['contrast_box_max_m'])
    q,w=leggauss(n);axes=[low[j]+(high[j]-low[j])*(q+1)/2 for j in range(3)]
    wa=[w*(high[j]-low[j])/2 for j in range(3)]
    x=np.stack(np.meshgrid(*axes,indexing='ij'),axis=-1).reshape(-1,3)
    weights=(wa[0][:,None,None]*wa[1][None,:,None]*wa[2][None,None,:]).ravel()
    return x,weights
