# S1 executed: new controls/oracle passed; one derivative solve failed the 1% screen

This new job repaired only the selected launcher environment. The five scientific/worker/control files are byte-identical to the failed predecessor; `run_s1.py` changes only the work ID and stage-local TEMP/TMP/TMPDIR/MPLCONFIGDIR plus `MPLBACKEND=Agg`. `exact-source-diff.patch`, `origin-source-map.json` and `frozen-source-pins.json` retain the exact mapping. The old failed job, old directory and original RED were not changed or replayed.

| New stage | Actual terminal | Elapsed | Peak job memory | Original held handles |
|---|---|---:|---:|---:|
| controls-01 | success, exit 0 | 2.141 s | 150,007,808 B | 3/3 signaled |
| oracle-01 | success, exit 0 | 2.734 s | 127,205,376 B | 3/3 signaled |
| run-01 | failed, exit 2: derivative comparison screen | 55.547 s | 3,346,661,376 B | 3/3 signaled |

These are measured sampled-guard elapsed values, not claims of hard wall-time enforcement. The solve preflight observed 13,426,733,056 B available physical memory against the unchanged 10,737,418,240 B gate. BLAS was observed at one thread before and after each stage. All three original process trees are stopped, all nine retained handles are signaled, no guard faults or sampled timeout stops occurred, and every stage's source readback is unchanged.

## New evidence

The selected arbitrary finite Tx/Rx coil poses, background sigma/epsilon/mu, frequency, contrast box and quadrature levels were unchanged. Controls used three-component compatible receiver traces (Ex/Ey/Ez nonzero counts 80/72/56 for each Rx). Constant-field, known-curl and winding-reversal controls passed. Known-curl absolute errors were 1.0842e-19 / 5.4210e-19 V. Deliberate wire-singularity and overlapping-support inputs really rejected. The 64-cell compact contrast supported 300 edges; the transmitter/support AABB distance lower bound was 0.1878732187 m. The mass retained complex sigma+i*omega*epsilon: independent construction difference 1.23793e-16, and supported-primary two-level relative difference 4.54675e-15.

The independent oracle used only installed Geoana current-dipole **H**, new geometry and homogeneous finite-loop primary, box volume quadrature and receiver disk flux. It did not use Geoana E/current-density, C/A/mass/RHS or solved-field data. A deliberate old-AII open was actually denied by the oracle audit; rejected Python bytecode-cache reads also appear in the raw denial list and are not matrix accesses. Full-wave branch/H expression and primary E-circumference versus H-flux checks passed. Primary cross-representation relative differences were 1.08048e-15 / 5.90034e-15. Fixed Born quadrature-pair differences were 3.40651534e-5 / 5.51796009e-8, below 0.001; absolute changes were 5.65748664e-15 / 3.65037533e-19 V.

Only after those gates passed, the worker formed the one nonzero derivative RHS, persisted it, loaded the exact pinned saved L5 AII and performed one COLAMD factorization and one RHS solve. There were zero old C constructions, zero old A assemblies, no old source or reference calculations, and no additional solve or retry. The zero-secondary boundary remains an explicitly approximate finite-domain condition.

## Numerical result

All values are complex volts per unit dimensionless contrast strength tau at zero; these are secondary derivatives, not total primary voltages or finite-strength heterogeneous fields.

| Receiver | Solved derivative V | Infinite-background independent derivative V | Absolute discrepancy V | Complex relative discrepancy |
|---|---|---|---:|---:|
| Rx1 | 3.1953266595378744e-11 + i 1.4198336219652273e-10 | 3.646216110528519e-11 + i 1.6202638781380794e-10 | 2.0543928679700378e-11 | **12.3700173947%** |
| Rx2 | -1.1292620076291921e-12 - i 5.017193934598469e-12 | -1.454243405659734e-12 - i 6.4536244832770134e-12 | 1.4727340663686812e-12 | **22.2620609458%** |

Backward eta = 2.228706729227798e-18 passed the fixed 2.842170943040401e-14 algebraic screen. Both receiver discrepancies failed the fixed **1%** physical comparison screen. The process intentionally exited 2 after persisting the arrays and result; its original failed terminal and `SystemExit(2)` evidence are retained. No tolerance, quadrature level, grid, factorization ordering or scientific source was changed after this observation.

The experiment establishes a nonzero off-axis 3D admittivity-contrast derivative and exposes a remaining discrepancy. It does not identify a unique cause: finite boundary/domain error, mesh/material-source/trace discretization and common physical assumptions remain to be assessed by the main. Algebraic eta and two-level quadrature agreement are not physical error certificates. No further numerical diagnosis was run in this task.

Physical accuracy and the sourced noise/calibration budget remain **unqualified**; finite tau, strong heterogeneous independent validation, G03 and all29 formal acceptance remain `not_run`. H01–H15 and SHA `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` remain intact. No product, dependency, ROCm, GPU, board, UI, service, peer or network operations were performed.

Raw arrays, before-factorization RHS, all stage results/failures/terminals, source pins and input readbacks are in this directory's manifest. The actual native completion response is saved separately; for a failed native completion its returned `result` is null and the error is the persisted native outcome. `final-result.txt` retains the exact text supplied with that completion.
