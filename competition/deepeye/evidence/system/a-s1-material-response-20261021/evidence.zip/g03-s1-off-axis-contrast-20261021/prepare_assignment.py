import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent;ROOT=O.parents[1]
design=O/'g03-secondary-field-design-20261021/design.md'
assert hashlib.sha256(design.read_bytes()).hexdigest()=='07cfae8e50869a2d87fc8613a4887ce828f3070963950c60f10eb578c13d8bd7'
assert json.loads((O/'g03-secondary-field-main-review-20261021/review.json').read_bytes())['status']=='SELECT_S1_NONZERO_OFF_AXIS_DERIVATIVE_DESIGN'
a={'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'A-G03-S1-OFF-AXIS-CONTRAST-20261021-v1',
   'owner':'/root/r02_amd_acquisition_20261021','ownership':[D.relative_to(ROOT).as_posix()],
   'director_thread_id':'01a13d7e-dcf1-7272-a738-a637dd62ff9d','director_generation':2,
   'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
   'selected_design':design.relative_to(ROOT).as_posix(),'design_sha256':hashlib.sha256(design.read_bytes()).hexdigest(),
   'selected_scope':'Implement and execute exactly the proposed nonzero off-axis 3D admittivity-contrast derivative S1, with a separately computed magnetic-field volume/receiver-flux reference. No full finite-strength heterogeneous or product acceptance.',
   'inputs':{'frequency_Hz':2e6,'sigma_background_Spm':.0005,'epsilon_background_Fpm':1.77083756256e-10,'mu_background_Hpm':1.2566370614359173e-6,
     'Tx_center_m':[0,0,-.25],'Tx_radius_m':.05,'Tx_normal_unnormalized':[0,1,4],'Tx_current_A':1,'turns':1,
     'Rx_centers_m':[[.025,-.0125,.05],[-.0125,.025,.25]],'Rx_radius_m':.02,'Rx_normal_unnormalized':[1,2,3],
     'contrast_box_min_m':[.025,.025,-.05],'contrast_box_max_m':[.05,.05,.025],
     'contrast_derivative':'(sigma_background + i*omega*epsilon_background)*indicator(box), fixed mu, derivative at tau=0'},
   'background_operator':'g03-l5-propagation-z-refinement-20261021/run-01/AII-csc.npz',
   'background_manifest_sha256':'521022089175583b344c45cbb6a2ca88e1198845a9f14f0ea347421e10fb9730',
   'budgets':{'new_controls_oracle_each':{'seconds_threshold':60,'process_memory_bytes':536870912,'job_memory_bytes':1073741824},
       'one_new_RHS_solve':{'seconds_threshold':90,'process_memory_bytes':4294967296,'job_memory_bytes':5368709120,'minimum_free_physical_bytes':10737418240},
       'active_processes':4,'BLAS_threads':1,'timing_note':'Sampled timeout thresholds, not guaranteed hard wall-time. Record actual elapsed and every retained handle terminal; preserve overruns.'},
   'new_engineering_screens':{'backward_eta':2.842170943040401e-14,'quadrature_relative_pair':.001,'derivative_vs_oracle_relative':.01,
       'qualification':'New diagnostic screens only. Preserve absolute voltages, near-cancellation undefined relative cases and all failures; no tolerance relaxation or formal noise claim.'},
   'required_outputs':['separate author/control RED and new GREEN when implementation is absent','selected-source pins','geometric support and separation checks','new primary and oracle quadrature arrays','mass/primary-support/RHS arrays before solve','one actual solved derivative if controls qualify','voltages and independent reference/differences','raw failures','actual process terminals and held-object evidence','public manifest','exact native completion'],
   'no_repeat':'No previous grid/reference/ROCm/board/R03 test reruns. Reload saved background AII; only a new derivative RHS is solved. No old C/A construction. Reconstruct mesh only for new material mass and tilted receiver trace.',
   'limitations':['Nonzero tau derivative is not finite-strength heterogeneity.','Approximate zero secondary boundary is not exact radiation.','Do not add b-Ap*ep wire residual or substitute total-field solution.','Do not use excluded Geoana electric_field or current_density branch.','Noise/calibration/strong heterogeneous independent accuracy and all29 remain open.'],
   'control_rules':'Follow the selected design new pose/trace/complex contrast/Faraday/Geoana H controls and fixed quadrature pairs. Keep oracle isolated from C/A/mass/RHS/solved fields. No automatic extra grid, alternate solver, extra quadrature levels or retry after an actual process failure. Preserve a numerical screen failure as a result, never label physical acceptance.',
   'forbidden_effects':['product changes','installed dependency changes','GPU/C model execution','board programming','UI/display or browser interaction','service changes','peer/group messages','new subagents']}
for name,value in [('assignment.json',a),('reserve-request.json',{'task_id':a['task_id'],'task_version':1,'work_id':a['work_id'],
    'ownership':a['ownership'],'reason':'Advance true off-axis 3D material response with a new nonzero RHS and independent H-flux oracle; reuse completed baselines.',
    'text':json.dumps(a,ensure_ascii=False)})]:
    with (D/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps({'work_id':a['work_id'],'design_selected':True,'old_tests_repeated':False}))
