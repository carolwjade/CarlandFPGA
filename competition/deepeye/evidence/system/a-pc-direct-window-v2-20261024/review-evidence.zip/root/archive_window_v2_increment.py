"""Root pinned v2 review/archive. Does not rerun tests or the clock observation."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,zipfile
P=Path(__file__).resolve().parent;R=P.parents[2];O=P.parent;W=R/'.local/deepeye-implementation-a'
A=O/'pc-direct-window-v2-20261024';V=O/'pc-direct-window-v2-independent-20261024';D=O/'live-slot-window-design-20261024'
BASE='88f7214eeb4770106933b9062445152a520ce4fc';H='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
GIT=r'C:\Users\CarlJade\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def git(*args):return subprocess.check_output([GIT,'--no-optional-locks','-C',str(W),*args])
assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--cached','--name-only').strip()
protected=read(O/'r03-mailbox-stop-main-review-20261020/application.json')['protected_files']
assert all(sha((W/n).read_bytes())==h for n,h in protected.items())
scope=read(R/'docs/competition/deepeye-2026/immutable_scope.json')
assert sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==H
sources=read(P/'v2-phase2-candidate.json')['source_files'];assert len(sources)==7
for name,row in sources.items():
 raw=(W/name).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
for name,row in read(A/'source-pins.json')['source'].items():
 assert sha((W/name).read_bytes())==row['sha256']
 if row['same_as_base']:assert git('show',BASE+':'+name)==(W/name).read_bytes()
manifest_counts={}
for label,folder in [('author',A),('review',V)]:
 m=read(folder/'artifact-manifest.json');manifest_counts[label]=len(m['files'])
 for name,row in m['files'].items():
  raw=(folder/name).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
assert manifest_counts=={'author':29,'review':45}
for file,folder,mapping in [('window-author-terminal.json',A,{'report_sha256':'report.md','result_sha256':'result.json','source_pins_sha256':'source-pins.json','artifact_manifest_sha256':'artifact-manifest.json'}),('window-review-terminal.json',V,{'report_sha256':'report.md','result_sha256':'result.json','manifest_sha256':'artifact-manifest.json'})]:
 rows=read(P/file);assert len(rows)==1;job=rows[0]
 assert job['status']=='completed' and job['terminal'] and not job['stale']
 result=json.loads(job['result']['text'])
 for key,name in mapping.items():assert result[key]==sha((folder/name).read_bytes())
author=read(A/'result.json');review=read(V/'result.json');focused=read(A/'focused-result.json');controls=read(V/'controls-result.json');execution=read(V/'independent-controls-execution.json')
assert focused['success'] and focused['tests_run']==25 and not focused['errors'] and not focused['failures'] and not focused['old_test_cases_executed']
assert controls['tests_run']==9 and controls['failures']==controls['errors']==0 and controls['real_clock_observation'] is None
assert review['focused_tests']=={'methods':9,'failures':0,'errors':0,'exit_code':0,'runs':1} and not review['independent_product_findings']
assert execution['exit_code']==0 and not execution['author_suite_run'] and not execution['old_testcase_discovery'] and not execution['real_clock_observation_run']
for stream in ['stdout','stderr']:assert sha((V/('independent-controls-'+stream+'.log')).read_bytes())==execution[stream+'_sha256']
log=(V/'independent-controls-stderr.log').read_text();assert log.count(' ... ok')==9 and 'Ran 9 tests' in log and log.rstrip().endswith('OK')
assert sha((V/'independent_controls.py').read_bytes())==execution['frozen_harness_sha256']=='72d766ebf5f0ee180ddf5c51a32b6f1f6f52d5facc3f94a7fbbdc9e60e836db4'
mono=read(A/'monotonic-once.json');assert mono['attempts']==1 and not mono['consumed'] and mono['wake_lateness_ns']==-7000000 and mono['snapshot']['pending_candidate_id']==1
assert mono['actual_now_ns']-mono['nominal_slot_ns']==mono['wake_lateness_ns'] and not mono['measured_scheduler_bound']
caps=read(P/'host-clock-capabilities-20261024.json');assert caps['monotonic']['implementation']=='GetTickCount64()' and caps['perf_counter']['implementation']=='QueryPerformanceCounter()'
decision={'schema':1,'utc':datetime.now(timezone.utc).isoformat(),'owner':'A/root 01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3','disposition':'ACCEPT_PC_DIRECT_V2_STATEFUL_SOFTWARE_CONTROLS_ONLY','base':BASE,'source_files':sources,'requirements_sha256':H,'H01_H15_preserved':True,'author_new_methods':25,'author_new_subcontrols':32,'independent_frozen_new_groups':9,'independent_runs':1,'author_manifest_members':29,'review_manifest_members':45,'original_deadlines_legacy_HIL_and_closed_production_gate_preserved':True,'unchanged_dependency_files':15,'protected_files_unchanged':4,'actual_monotonic_attempts':1,'reported_monotonic_lateness_ns':-7000000,'actual_window_consumed':False,'actual_10ms_availability':'not_established','policy_ns':10000000,'policy_is_measurement':False,'source_provenance_established':False,'upstream_native_clock_model_board':'synthetic except one pure-policy local clock observation','real_board_run':False,'formal_acceptance':False,'original_failures_preserved':True,'G03':'not_run','R03':'not_run','all29':'not_run','next':'single-domain high-resolution clock design and original B/C packages; no timestamp epoch mixing, fabricated uncertainty or gate relaxation'}
destination=W/'competition/deepeye/evidence/system/a-pc-direct-window-v2-20261024';assert not destination.exists()
secrets=[read(p/'lease.private.json')['lease_token'].encode() for p in [A,V,D]]
members={}
for label,folder in [('author',A),('independent',V),('design',D)]:
 for file in folder.rglob('*'):
  if file.is_file() and 'private' not in file.name and '__pycache__' not in file.parts:
   raw=file.read_bytes();assert not any(secret in raw for secret in secrets),(label,file.name,'private credential')
   members[label+'/'+file.relative_to(folder).as_posix()]=raw
for name in ['window-author-terminal.json','window-review-terminal.json','v2-root-static-diff.json','v2-phase2-candidate.json','pc-direct-window-v2-decision.json','host-clock-capabilities-20261024.json','live-slot-design-root-binding.json','live-slot-design-root-binding-attempt-01-error.json']:
 members['root/'+name]=(P/name).read_bytes()
members['root/archive_window_v2_increment.py']=Path(__file__).read_bytes()
destination.mkdir(parents=True)
zp=destination/'review-evidence.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(members.items()):z.writestr(name,raw)
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None and len(z.namelist())==len(members)
 for name,raw in members.items():assert z.read(name)==raw
save(destination/'manifest.json',{'schema':1,'zip_sha256':sha(zp.read_bytes()),'zip_bytes':zp.stat().st_size,'member_count':len(members),'members':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())],'credentials_excluded':True})
save(destination/'decision.json',decision)
(destination/'README.md').write_text('Root accepts only explicit PC_DIRECT v2 stateful software controls: author25 methods/32 subcontrols and independent9 frozen groups passed. Exact7 source files preserve legacy/HIL, original deadlines and the closed production gate. The only actual monotonic attempt reported7ms before the nominal slot and did not consume; 10ms real availability remains unproven. Current Python clock resolution/epoch limits are retained. No real upstream provenance, inference, PL, ADC, board, deadline-stop or formal acceptance follows. H01-H15 unchanged; G03/R03/all29=not_run.\n\nSee decision.json, exact archive hashes in manifest.json and original failures in review-evidence.zip.\n',encoding='utf-8',newline='\n')
files={n:x['sha256'] for n,x in sources.items()}
files.update({f.relative_to(W).as_posix():sha(f.read_bytes()) for f in destination.iterdir()})
save(P/'window-v2-root-decision.json',decision)
save(P/'window-v2-publication.json',{'expected_head':BASE,'message':'Add explicit bounded PC_DIRECT v2 candidate consumption window','files':files})
assert all(sha((W/n).read_bytes())==h for n,h in protected.items())
print(json.dumps({'prepared_files':len(files),'archive_members':len(members),'zip_sha256':sha(zp.read_bytes()),'C4_unchanged':True}))
