"""One fixed-origin, actual-monotonic pure-policy attempt; never a timing bound."""
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
PRODUCT = ROOT/'.local/deepeye-implementation-a'
sys.path[:0] = [str(PRODUCT),str(ROOT/'.local/deepeye-host-deps'),
               str(PRODUCT/'competition/deepeye/integration')]
from competition.deepeye.integration import boot_profile as boot, candidate_mailbox as m
from test_host_envelope import encode, CONTEXT, telem_document, candidate_document

document = boot.load_document(PRODUCT/'competition/deepeye/docs/boot_profiles.json')
context = dict(CONTEXT,topology_id=2,boot_sha256=boot.canonical_sha256(document).hex())
owner, source, domain = m.LatestCompletedMailbox(document), object(), object()
origin = time.monotonic_ns()  # Fixed exactly once; no retries or origin resets.
owner.activate(encode(context),generation=1,slot_origin_ns=origin,source=source,
    clock_domain=domain,bounds=m.TransferBounds(10_000_000,5_000_000),
    now_ns=time.monotonic_ns(),pc_direct_window_v2=m.PcDirectWindowV2(10_000_000))
sample = time.monotonic_ns()
raw = encode(telem_document(context=context,count=50,seq=9,tick=9,
    receipt=dict(lower_ns=sample,upper_ns=sample),
    adc_last=dict(lower_ns=sample,upper_ns=sample)))
owner.observe(raw,sample_lower_ns=sample,now_ns=time.monotonic_ns())
dispatch = time.monotonic_ns()
lower = time.monotonic_ns()
candidate = encode(candidate_document(context=context,candidate_id=1,
    observation=dict(context=context,observed_seq=9),completed=lower))
upper = time.monotonic_ns()
deadline = lower+2_000_000_000  # Explicit synthetic pure-policy completion bound.
owner.complete(m.Completion(1,source,domain,candidate,1,dispatch,lower,upper,deadline),
               now_ns=time.monotonic_ns())
start, close = origin+210_000_000, origin+220_000_000
before_wait = time.monotonic_ns()
delay = max(0,(start-before_wait)/1_000_000_000)
time.sleep(delay)  # One ordinary bounded wait, never a freeze or spin/retry.
actual_now = time.monotonic_ns()
selected = owner.consume_pc_direct_v2(actual_now,grant=m.SlotGrant(1,0))  # Only attempt.
result = dict(schema=1,attempts=1,clock='time.monotonic_ns',origin_ns=origin,
    nominal_slot_ns=start,window_close_ns=close,policy_width_ns=10_000_000,
    ready_ns=upper+15_000_000,original_deadline_ns=min(deadline,sample+1_500_000_000),
    before_wait_ns=before_wait,requested_wait_seconds=delay,actual_now_ns=actual_now,
    wake_lateness_ns=actual_now-start,consumed=selected is not None,
    consumed_at_ns=None if selected is None else selected.consumed_at_ns,
    snapshot=owner.snapshot(),upstream='synthetic source/completion/transfer/slot records',
    native_model_board=False,measured_scheduler_bound=False,
    G03='not_run',R03='not_run',all29='not_run')
path = Path(__file__).with_name('monotonic-once.json')
if path.exists(): raise RuntimeError('single-shot evidence already exists; refuse overwrite/replay')
path.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,sort_keys=True))
