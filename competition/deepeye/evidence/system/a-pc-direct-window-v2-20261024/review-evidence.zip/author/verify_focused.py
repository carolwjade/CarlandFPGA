"""Freeze/read back the authorized increment and run only its new controls."""
import ast
import hashlib
import importlib
import json
from pathlib import Path
import subprocess
import sys
import unittest

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCT = ROOT/'.local/deepeye-implementation-a'
BASE = '88f7214eeb4770106933b9062445152a520ce4fc'
sys.path[:0] = [str(PRODUCT),str(ROOT/'.local/deepeye-host-deps')]
OWNED = [
    'competition/deepeye/integration/candidate_mailbox.py',
    'competition/deepeye/simulation/authority/candidate_owner.py',
    'competition/deepeye/simulation/authority/actor_composition.py',
    'competition/deepeye/integration/test_pc_direct_window_v2.py',
    'competition/deepeye/tests/simulation/test_pc_direct_window_v2.py',
    'competition/deepeye/docs/pc_direct_window_v2.md',
    'competition/deepeye/docs/actor_composition.md']
DEPENDENCIES = [
    'competition/deepeye/docs/boot_profiles.json',
    'competition/deepeye/integration/boot_profile.py',
    'competition/deepeye/integration/host_envelope.py',
    'competition/deepeye/integration/pc_direct_watchdog.py',
    'competition/deepeye/integration/wire.py',
    'competition/deepeye/simulation/authority/pc_direct_runtime.py',
    'competition/deepeye/simulation/authority/motion_executor.py',
    'competition/deepeye/simulation/isolation/actor_owner.py',
    'competition/deepeye/tests/simulation/test_candidate_owner.py',
    'competition/deepeye/tests/simulation/test_actor_composition.py',
    'competition/deepeye/tests/simulation/test_actor_owner.py',
    'competition/deepeye/tests/simulation/test_pc_direct_runtime.py',
    'competition/deepeye/tests/simulation/test_motion_executor.py',
    'competition/deepeye/integration/test_host_envelope.py',
    'competition/deepeye/integration/test_pc_direct_watchdog.py']

def sha(raw): return hashlib.sha256(raw).hexdigest()
def save(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def git(*args):
    return subprocess.run(['git',*args],cwd=PRODUCT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
def pin(path):
    raw = (PRODUCT/path).read_bytes()
    original = git('show',BASE+':'+path)
    return dict(bytes=len(raw),sha256=sha(raw),
                base_sha256=sha(original.stdout) if original.returncode==0 else None,
                same_as_base=original.returncode==0 and original.stdout==raw)

scope = json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
requirements = sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,
                             separators=(',',':')).encode('utf-8'))
assert requirements == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
pins = {path:pin(path) for path in OWNED+DEPENDENCIES}
assert all(pins[path]['same_as_base'] for path in DEPENDENCIES)
protected = json.loads((ROOT/'.planning/deepeye-resume-20261018/r03-mailbox-stop-main-review-20261020/application.json').read_text(encoding='utf-8'))['protected_files']
protected_readback = {path:dict(expected_sha256=expected,actual_sha256=sha((PRODUCT/path).read_bytes()))
                      for path,expected in protected.items()}
assert all(v['expected_sha256']==v['actual_sha256'] for v in protected_readback.values())
for path in OWNED:
    if path.endswith('.py'): ast.parse((PRODUCT/path).read_text(encoding='utf-8'),filename=path)
diff_check = git('diff','--check','--',*OWNED)
assert diff_check.returncode == 0, diff_check.stderr.decode('utf-8')
save('source-pins.json',dict(base_commit=BASE,head_readback=git('rev-parse','HEAD').stdout.decode().strip(),
    requirements_sha256=requirements,source=pins,protected_files=protected_readback,
    owned_python_ast='passed',owned_diff_check_exit=diff_check.returncode))
(OUT/'owned.diff').write_bytes(git('diff','--',*OWNED).stdout)
(OUT/'git-status.txt').write_bytes(git('status','--short').stdout)

names = ['competition.deepeye.integration.test_pc_direct_window_v2',
         'competition.deepeye.tests.simulation.test_pc_direct_window_v2']
suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(name))
                           for name in names)
def cases(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite): yield from cases(item)
        else: yield item
ids = [case.id() for case in cases(suite)]
assert len(ids)==25 and all('.test_pc_direct_window_v2.' in name for name in ids)
class Results(unittest.TextTestResult):
    def __init__(self,*args): super().__init__(*args); self.subtests=[]
    def addSubTest(self,test,subtest,error):
        self.subtests.append(dict(test=test.id(),parameters=str(subtest),success=error is None))
        super().addSubTest(test,subtest,error)
with (OUT/'focused-green.log').open('w',encoding='utf-8') as log:
    result = unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Results).run(suite)
summary = dict(executed_test_ids=ids,tests_run=result.testsRun,success=result.wasSuccessful(),
    failures=len(result.failures),errors=len(result.errors),subtests=result.subtests,
    old_test_cases_executed=0,old_software_group_PDE_384_executed=False,
    upstream_native_clock='fixtures, no authentication or board evidence',
    source_pins_sha256=sha((OUT/'source-pins.json').read_bytes()))
save('focused-result.json',summary)
# Re-read bytes after controls: no own/dependency/protected file may change.
assert all(sha((PRODUCT/path).read_bytes())==value['sha256'] for path,value in pins.items())
assert all(sha((PRODUCT/path).read_bytes())==value['actual_sha256']
           for path,value in protected_readback.items())
print(json.dumps(dict(tests_run=result.testsRun,success=result.wasSuccessful(),
    failures=len(result.failures),errors=len(result.errors),subtest_count=len(result.subtests),
    requirements_sha256=requirements,protected_files_unchanged=True,
    dependencies_equal_base=True,owned_ast_and_diff_check='passed'),sort_keys=True))
sys.exit(0 if result.wasSuccessful() else 1)
