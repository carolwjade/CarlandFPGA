"""Freeze exact source and evidence after the new focused run; no tests or replay."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCT = ROOT/'.local/deepeye-implementation-a'
BASE = '88f7214eeb4770106933b9062445152a520ce4fc'
OWNED = [
    'competition/deepeye/integration/candidate_mailbox.py',
    'competition/deepeye/simulation/authority/candidate_owner.py',
    'competition/deepeye/simulation/authority/actor_composition.py',
    'competition/deepeye/integration/test_pc_direct_window_v2.py',
    'competition/deepeye/tests/simulation/test_pc_direct_window_v2.py',
    'competition/deepeye/docs/pc_direct_window_v2.md',
    'competition/deepeye/docs/actor_composition.md']
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(name): return json.loads((OUT/name).read_text(encoding='utf-8'))
def save(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
pins = read('source-pins.json')
for path,record in pins['source'].items():
    assert sha((PRODUCT/path).read_bytes()) == record['sha256']
for path,record in pins['protected_files'].items():
    assert sha((PRODUCT/path).read_bytes()) == record['actual_sha256']

# Static equality is narrower than behavioral verification, and does not run old tests.
targets = {
    OWNED[0]: ['_plan','complete','observe','stop','_time'],
    OWNED[1]: ['_CandidateOwner.offer','_CandidateOwner.commit','_CandidateOwner.duplicate_proof',
               '_CandidateOwner.observe','_CandidateOwner.retire'],
    OWNED[2]: ['_production_channels','_ProgressGate','_Dependencies','_entry',
               'ActorComposition.step','ActorComposition._progress_time']}
def subtree(source,target):
    # Mailbox helpers live under the mailbox class; other top-level targets are direct.
    nodes = ast.parse(source).body
    parts = target.split('.')
    if len(parts)==1 and target in targets[OWNED[0]]:
        nodes = next(node for node in nodes if isinstance(node,ast.ClassDef)
                     and node.name=='LatestCompletedMailbox').body
    for part in parts:
        selected = next(node for node in nodes if isinstance(node,(ast.FunctionDef,ast.ClassDef))
                        and node.name==part)
        nodes = selected.body
    return ast.dump(selected,include_attributes=False)
unchanged = {}
for path,names in targets.items():
    base = subprocess.run(['git','show',BASE+':'+path],cwd=PRODUCT,
                          stdout=subprocess.PIPE,check=True).stdout.decode('utf-8')
    actual = (PRODUCT/path).read_text(encoding='utf-8')
    for name in names:
        unchanged[path+':'+name] = subtree(base,name)==subtree(actual,name)
assert all(unchanged.values())
save('unchanged-gates.json',dict(method_ast_equal_base=unchanged,
    runtime_executor_watchdog_ABI_profile_bytes_equal_base=True,
    no_behavioral_claim_from_static_comparison=True))
for path in OWNED:
    destination = OUT/'source-snapshot'/path
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(PRODUCT/path,destination)
    assert sha(destination.read_bytes()) == pins['source'][path]['sha256']

clock_note = dict(source='A/root message to /root/pc_direct_window during this lease',
    independently_reproduced_by_child=False,python_version='3.12.14',
    monotonic_implementation='GetTickCount64',monotonic_resolution_seconds=0.015625,
    perf_counter_implementation='QueryPerformanceCounter',perf_counter_resolution_seconds=1e-7,
    domains_have_different_epoch=True,domain_mixing_allowed=False,
    decision='Preserve the original single-shot miss. No retry, origin/W/deadline change, clock substitution or freeze. Root owns later unified high-resolution source clock design.')
save('root-clock-observation-note.json',clock_note)
save('execution-notes.json',dict(
    initial_command_error='Product cwd had no .local/venv; corrected executable to ../../.local/venv. This was shell setup, not functional RED.',
    jsonschema_error='Initial venv import lacked jsonschema. Reused existing .local/deepeye-host-deps through PYTHONPATH, no installation or service changes.',
    composition_helper_error='Calling old setUp on a non-subtype hit super(type,obj). Replaced with explicit construction helper setup; no old test method executed.',
    stop_helper_error='First composition GREEN attempt called missing fixture owner.command. Built explicit upstream STOP VerifiedEnvelope and retested new controls.',
    failed_patch_attempts='Two apply_patch context mismatches made no changes; corrected exact doc context.',
    original_failures_preserved=True,old_tests_PDE_384_executed=False,
    source_writes='Exactly seven owned product files; no stage/commit, network, board, serial, UI, service, PR or additional delegation.'))
focused = read('focused-result.json')
observation = read('monotonic-once.json')
assert focused['success'] and focused['tests_run']==25 and observation['attempts']==1
result = dict(schema=1,status='implemented_focused_software_controls_passed',
    task_id='DEEPEYE-IMPLEMENTATION-20261014',task_version=1,
    work_id='A-PC-DIRECT-WINDOW-V2-IMPLEMENT-20261024-v1',
    job_id='child-3fc6b4fd3a8d4c7fa7a8a65f5ad19f0b',agent_id='/root/pc_direct_window',
    director='01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3',base_commit=BASE,
    requirements_sha256=pins['requirements_sha256'],H01_H15_preserved=True,
    policy_width_ns=10_000_000,width_is_policy_not_measured_bound=True,
    source_files={path:pins['source'][path] for path in OWNED},
    focused_tests=dict(methods=25,subtests=len(focused['subtests']),failures=0,errors=0,
        old_test_cases_executed=0,upstream_native_clock='synthetic'),
    one_shot_observation=dict(attempts=1,consumed=observation['consumed'],
        wake_lateness_ns=observation['wake_lateness_ns'],availability='not_established',
        actual_clock='time.monotonic_ns; root reports GetTickCount64 15.625ms resolution',
        native_model_board=False),
    preserved=dict(original_deadlines=True,legacy_exact_consume=True,HIL=True,
        production_unconditionally_unavailable=True,original_proof_once_consume=True,
        original_progress_gate=True,final_callback_to_CAS=True,protected_four_files=True),
    raw_manifest='artifact-manifest.json',source_pins_sha256=sha((OUT/'source-pins.json').read_bytes()),
    focused_result_sha256=sha((OUT/'focused-result.json').read_bytes()),
    monotonic_result_sha256=sha((OUT/'monotonic-once.json').read_bytes()),
    G03='not_run',R03='not_run',all29='not_run',formal_acceptance=False)
save('result.json',result)
table = '\n'.join('| `'+path+'` | `'+pins['source'][path]['sha256']+'` |' for path in OWNED)
report = '''# PC_DIRECT v2 limited implementation evidence

Implemented explicit opt-in fixed-anchor PC_DIRECT consumption-window v2 in the
original stateful owner. This is a software increment for root review; it does
not grant production, board or formal acceptance. Task
DEEPEYE-IMPLEMENTATION-20261014/v1; work
A-PC-DIRECT-WINDOW-V2-IMPLEMENT-20261024-v1; canonical agent
/root/pc_direct_window; validated mesh job
child-3fc6b4fd3a8d4c7fa7a8a65f5ad19f0b returned execution_allowed=true.
Director: 01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3. Source base and HEAD
readback: 88f7214eeb4770106933b9062445152a520ce4fc. No stage or commit performed.

Read ROOT AGENTS, project multi-node/A-role/protocol and single-node/A-role,
immutable scope md/json, active transfer/current handoff and selected design /
root policy decision. Canonical requirements UTF-8 (ensure_ascii=False,
sort_keys=True, compact separators) was recomputed as
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
DEEPEYE-HUMAN-LOCK-20261014/revision1 and every H01-H15 remain unchanged.
A/root alone operates the board; no physical access occurred here.

## Result and retained limits

The new policy freezes O/F/P/W at original activation and derives S/E only from
the original grant k. It requires R<=S and S<=refreshed actual now<min(E,original
D), with strict integer/overflow/W<P checks. W=10 ms is root-selected policy,
never a measured scheduler bound. Legacy exact consumption is default and HIL
is unchanged. Policy/entry mixing stops. The stateful owner retains the original
completion proof, consumes once, never restores pending after downstream failure,
and does not renew original deadlines. The production gate still rejects
unconditionally; no provider/flag bypass was added.

Only seven owned product files changed. Fifteen read dependencies (including
runtime, executor, watchdog, ABI wire and BOOT profile) equal base bytes. The
four C-protected files exactly match the earlier application hashes. Static AST
comparisons separately confirm unchanged original mailbox lifecycle/legacy plan,
owner offer/commit/duplicate handling, entire ProgressGate and Dependencies,
composition entry guards, step and clock refresh. This static check is not a
behavioral substitute. No new work is inserted in final callback-to-CAS.

## New focused controls actually run

Final command (from repository root):
`$env:PYTHONDONTWRITEBYTECODE='1'; & .local/venv/Scripts/python.exe -X utf8 .planning/deepeye-resume-20261018/pc-direct-window-v2-20261024/verify_focused.py`

The runner uses the existing .local/deepeye-host-deps jsonschema path and loads
only the two new modules. Final: **25 test methods, 32 recorded subtests, zero
failures/errors**, plus owned Python AST parse / git diff --check success. The
full executed IDs and subtest outcomes are retained in focused-result.json;
focused-green.log is the raw test output. No old TestCase was inherited or
discovered. Existing fixture setup/construction methods supply synthetic
upstream/native/clock records; original old test methods were not executed.
Mailbox, composition, runtime, numerical full geometry and executor CAS are real
software. There is no real AI, model inference, authenticated source or board.

Nine new policy methods cover literal S-1/S+1ns/E/E+1 and D-1/D/D+1 boundaries;
ready=S vs S+1; fixed grant index and later original window; duplicate completion
and irreversible consume; newer late pending without old fallback; policy/entry
mixing; default legacy exact success/late refusal for both modes; invalid
width/type/topology/index/overflow; missing original evidence; bad generation,
clock rollback and STOP; ready/sample-deadline sum bounds.

Sixteen composition methods cover original proof and S+1ns positive pose CAS;
actual slot-verifier refresh reaching E; exact committed duplicate after E with
no new consume or renewal; changed target/new seq refusing without rollback;
wrong completion source; original progress expiry at final callback and HANDLE
sample; whole dt end equal deadline refusal and one ns before success; broker
STOP without grant; reentry and foreign-thread veto; post-CAS veto retaining
positive commit; malformed policy before gate/acquisition; W=P retiring original
activation rather than fallback. TTL/sample/heartbeat/lifetime logic was not
modified; only the named new deadline controls were run, not exhaustive old gates.

## RED and failures preserved

red.log records the expected missing explicit policy assertion before production
implementation; composition-red.log records the expected missing config-field
assertion before owner/config integration. These are API-missing RED controls,
not a claim that preimplementation numerical v2 was exercised. The first pure
GREEN passed 9 methods. The first composition GREEN passed 12/13 with one
fixture STOP helper error; the corrected/new controls passed 16 methods and the
final combined 25-method run passed. All intermediate logs remain.

Initial command cwd lookup failed before execution; initial import lacked
jsonschema (environment-missing-jsonschema.log). A borrowed setUp initially hit
super(type,obj) (composition-fixture-super-error.log). Initial STOP fixture lacked
owner.command (composition-green-attempt1.log); explicit STOP envelope corrected
the test fixture. execution-notes.json records these and two atomic patch-context
failures. No environment install, policy loosening or old suite replay was used.
Prior project failures remain unchanged; old software groups, PDE and 384 board
tests were not run.

## One actual monotonic observation: early, no consume

observe_monotonic_once.py performed exactly one fixed-origin attempt: origin
129467453000000 ns, S 129467663000000, E 129467673000000, actual now
129467656000000, ready 129467468000000. One ordinary requested sleep of 0.21 s
returned with reported wake_lateness **-7000000 ns**. The policy correctly
returned None before S; pending remained unconsumed. No retry, clock freezing,
origin reset, W change or deadline adjustment occurred. monotonic-once.json/log
are the original raw results. **Actual availability of the 10 ms window is not
established.** This observation is pure policy with synthetic upstream and no
native actor, model, board or simulator motion.

Root subsequently supplied a current local clock inquiry: this Python 3.12.14
time.monotonic_ns uses GetTickCount64 at reported resolution 0.015625 s, whereas
perf_counter_ns uses QueryPerformanceCounter at 1e-7 s. This is root-provided
现场信息, not a second child observation; root-clock-observation-note.json retains
that attribution. These clocks have different epoch/domain and cannot be mixed.
No clock substitution is made here. Root owns a separate later unified
high-resolution source-clock design. The coarse clock and early wake are
explicit limits; no scheduler or realtime bound is claimed.

## Exact final source pins

Source raw bytes are copied to source-snapshot/, and source-pins.json records
base/current hashes plus unchanged dependencies/protected bytes.

| Product-relative file | SHA256 |
|---|---|
'''+table+'''

artifact-manifest.json freezes all non-secret raw artifacts, reports, scripts and
source copies, excluding itself, freeze.json and post-freeze native completion
request/receipt files to avoid circular hashes. lease.private.json is excluded
and must not be published. freeze.json independently re-reads every manifest
member before native completion. Native persisted receipt is recorded separately.

Production activation and real provenance remain unavailable. This increment
does not establish the 10 ms window's actual availability, useful AI, H09,
either complete H12 path, real-board/headless integration, G03/R03 or all29.
G03=not_run, R03=not_run, all29=not_run; formal acceptance belongs to root.
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
excluded = {'lease.private.json','artifact-manifest.json','freeze.json',
            'native-complete-request.json','native-complete-receipt.json'}
files = {path.relative_to(OUT).as_posix():dict(bytes=path.stat().st_size,sha256=sha(path.read_bytes()))
         for path in sorted(OUT.rglob('*')) if path.is_file() and path.name not in excluded}
save('artifact-manifest.json',dict(schema=1,files=files,excluded=sorted(excluded),
    lease_private_publish=False))
assert all((OUT/path).stat().st_size==value['bytes'] and sha((OUT/path).read_bytes())==value['sha256']
           for path,value in files.items())
freeze = dict(schema=1,frozen=True,member_count=len(files),all_members_readback_match=True,
    artifact_manifest_sha256=sha((OUT/'artifact-manifest.json').read_bytes()),
    report_sha256=sha((OUT/'report.md').read_bytes()),result_sha256=sha((OUT/'result.json').read_bytes()),
    source_pins_sha256=sha((OUT/'source-pins.json').read_bytes()),
    no_product_writes_after_freeze=True)
save('freeze.json',freeze)
print(json.dumps(freeze,sort_keys=True))
