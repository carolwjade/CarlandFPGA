# PC_DIRECT v2 limited implementation evidence

Implemented explicit opt-in fixed-anchor PC_DIRECT consumption-window v2 in the
original stateful owner. This is a software increment for root review; it does
not grant production, board or formal acceptance. Task
DEEPEYE-IMPLEMENTATION-20261014/v1; work
A-PC-DIRECT-WINDOW-V2-IMPLEMENT-20261024-v1; canonical agent
/root/pc_direct_window; validated mesh job
child-3fc6b4fd3a8d4c7fa7a8a65f5ad19f0b returned execution_allowed=true.
Director: 01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3. Source base and HEAD
readback: 88f7214eeb4770106933b9062445152a520ce4fc. No stage or commit performed.

Read ROOT AGENTS, project multi-node/A-role/protocol and single-node/A-role,
immutable scope md/json, active transfer/current handoff and selected design /
root policy decision. Canonical requirements UTF-8 (ensure_ascii=False,
sort_keys=True, compact separators) was recomputed as
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
DEEPEYE-HUMAN-LOCK-20261014/revision1 and every H01-H15 remain unchanged.
A/root alone operates the board; no physical access occurred here.

## Result and retained limits

The new policy freezes O/F/P/W at original activation and derives S/E only from
the original grant k. It requires R<=S and S<=refreshed actual now<min(E,original
D), with strict integer/overflow/W<P checks. W=10 ms is root-selected policy,
never a measured scheduler bound. Legacy exact consumption is default and HIL
is unchanged. Policy/entry mixing stops. The stateful owner retains the original
completion proof, consumes once, never restores pending after downstream failure,
and does not renew original deadlines. The production gate still rejects
unconditionally; no provider/flag bypass was added.

Only seven owned product files changed. Fifteen read dependencies (including
runtime, executor, watchdog, ABI wire and BOOT profile) equal base bytes. The
four C-protected files exactly match the earlier application hashes. Static AST
comparisons separately confirm unchanged original mailbox lifecycle/legacy plan,
owner offer/commit/duplicate handling, entire ProgressGate and Dependencies,
composition entry guards, step and clock refresh. This static check is not a
behavioral substitute. No new work is inserted in final callback-to-CAS.

## New focused controls actually run

Final command (from repository root):
`$env:PYTHONDONTWRITEBYTECODE='1'; & .local/venv/Scripts/python.exe -X utf8 .planning/deepeye-resume-20261018/pc-direct-window-v2-20261024/verify_focused.py`

The runner uses the existing .local/deepeye-host-deps jsonschema path and loads
only the two new modules. Final: **25 test methods, 32 recorded subtests, zero
failures/errors**, plus owned Python AST parse / git diff --check success. The
full executed IDs and subtest outcomes are retained in focused-result.json;
focused-green.log is the raw test output. No old TestCase was inherited or
discovered. Existing fixture setup/construction methods supply synthetic
upstream/native/clock records; original old test methods were not executed.
Mailbox, composition, runtime, numerical full geometry and executor CAS are real
software. There is no real AI, model inference, authenticated source or board.

Nine new policy methods cover literal S-1/S+1ns/E/E+1 and D-1/D/D+1 boundaries;
ready=S vs S+1; fixed grant index and later original window; duplicate completion
and irreversible consume; newer late pending without old fallback; policy/entry
mixing; default legacy exact success/late refusal for both modes; invalid
width/type/topology/index/overflow; missing original evidence; bad generation,
clock rollback and STOP; ready/sample-deadline sum bounds.

Sixteen composition methods cover original proof and S+1ns positive pose CAS;
actual slot-verifier refresh reaching E; exact committed duplicate after E with
no new consume or renewal; changed target/new seq refusing without rollback;
wrong completion source; original progress expiry at final callback and HANDLE
sample; whole dt end equal deadline refusal and one ns before success; broker
STOP without grant; reentry and foreign-thread veto; post-CAS veto retaining
positive commit; malformed policy before gate/acquisition; W=P retiring original
activation rather than fallback. TTL/sample/heartbeat/lifetime logic was not
modified; only the named new deadline controls were run, not exhaustive old gates.

## RED and failures preserved

red.log records the expected missing explicit policy assertion before production
implementation; composition-red.log records the expected missing config-field
assertion before owner/config integration. These are API-missing RED controls,
not a claim that preimplementation numerical v2 was exercised. The first pure
GREEN passed 9 methods. The first composition GREEN passed 12/13 with one
fixture STOP helper error; the corrected/new controls passed 16 methods and the
final combined 25-method run passed. All intermediate logs remain.

Initial command cwd lookup failed before execution; initial import lacked
jsonschema (environment-missing-jsonschema.log). A borrowed setUp initially hit
super(type,obj) (composition-fixture-super-error.log). Initial STOP fixture lacked
owner.command (composition-green-attempt1.log); explicit STOP envelope corrected
the test fixture. execution-notes.json records these and two atomic patch-context
failures. No environment install, policy loosening or old suite replay was used.
Prior project failures remain unchanged; old software groups, PDE and 384 board
tests were not run.

## One actual monotonic observation: early, no consume

observe_monotonic_once.py performed exactly one fixed-origin attempt: origin
129467453000000 ns, S 129467663000000, E 129467673000000, actual now
129467656000000, ready 129467468000000. One ordinary requested sleep of 0.21 s
returned with reported wake_lateness **-7000000 ns**. The policy correctly
returned None before S; pending remained unconsumed. No retry, clock freezing,
origin reset, W change or deadline adjustment occurred. monotonic-once.json/log
are the original raw results. **Actual availability of the 10 ms window is not
established.** This observation is pure policy with synthetic upstream and no
native actor, model, board or simulator motion.

Root subsequently supplied a current local clock inquiry: this Python 3.12.14
time.monotonic_ns uses GetTickCount64 at reported resolution 0.015625 s, whereas
perf_counter_ns uses QueryPerformanceCounter at 1e-7 s. This is root-provided
现场信息, not a second child observation; root-clock-observation-note.json retains
that attribution. These clocks have different epoch/domain and cannot be mixed.
No clock substitution is made here. Root owns a separate later unified
high-resolution source-clock design. The coarse clock and early wake are
explicit limits; no scheduler or realtime bound is claimed.

## Exact final source pins

Source raw bytes are copied to source-snapshot/, and source-pins.json records
base/current hashes plus unchanged dependencies/protected bytes.

| Product-relative file | SHA256 |
|---|---|
| `competition/deepeye/integration/candidate_mailbox.py` | `ab43c3cdb5dac00256a5436d31acbd3e2a729c3ead1a6d647e9e493464d4cf59` |
| `competition/deepeye/simulation/authority/candidate_owner.py` | `64d6a1e7cf68650e9e603da51816bce9dd84921efd0ece62ceb53bfcceb2eec5` |
| `competition/deepeye/simulation/authority/actor_composition.py` | `c13452d1e2bf4b60eb5e89cd09c93abe70a0b3396371cf87aa7f12b42d0e4868` |
| `competition/deepeye/integration/test_pc_direct_window_v2.py` | `59faae2809bf4c9598cacf074a07e65384dcffe680e4d43caf16b1286f8a51c9` |
| `competition/deepeye/tests/simulation/test_pc_direct_window_v2.py` | `bc360a4225070addfb676a0a1f5349612bf7ea5e661b802af5f756536b71c7fa` |
| `competition/deepeye/docs/pc_direct_window_v2.md` | `0d9565e116669b2f9c54515a5ab72bf912e44606a18ce9897b1076253372ac9e` |
| `competition/deepeye/docs/actor_composition.md` | `c9fb8c1a70c0f296c11867ae3d62cca532a7c2138c666273f98f332f8a99aa69` |

artifact-manifest.json freezes all non-secret raw artifacts, reports, scripts and
source copies, excluding itself, freeze.json and post-freeze native completion
request/receipt files to avoid circular hashes. lease.private.json is excluded
and must not be published. freeze.json independently re-reads every manifest
member before native completion. Native persisted receipt is recorded separately.

Production activation and real provenance remain unavailable. This increment
does not establish the 10 ms window's actual availability, useful AI, H09,
either complete H12 path, real-board/headless integration, G03/R03 or all29.
G03=not_run, R03=not_run, all29=not_run; formal acceptance belongs to root.
