# PC_DIRECT 固定锚点有界消费窗 v2 设计

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，工作 `A-LIVE-SLOT-WINDOW-DESIGN-20261024-v1`。子代理 `/root/live_slot_design`，native job `child-8f20327ed57d40bc8d07558ad6144a1f` 已以 canonical agent_id 验证，返回 `execution_allowed=true`。仅本目录可写，全部产品只读。主会话为 Desktop `01a16988-bdcb-70e1-ae10-1304b5cf7875` / generation3；transfer 实读 active；现有 node 配置实读 A / fpga-main。

本报告选定一个供 root 审定的 **PC_DIRECT 主机决策策略新版本**，不修改旧 exact-slot 策略，不建立生产准入。已读根 AGENTS、两项项目技能/A role、协作协议、当前交接、immutable_scope md/json 和 live-provider-prep 报告。requirements canonical JSON 实算 SHA256 为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，15 项 H01–H15 全部保留。A 独占实板；显示器不占用。

## 选择与原因

选择 **A：固定锚点、真实 monotonic、有限迟到消费窗**。原候选必须在名义时点之前就绪；主机 owner 可以在该时点后的一个有限窗口消费。首个实现建议显式选 `consume_window_ns=10_000_000`，无默认值。这是主会话可审定的 10 ms 主机准入策略，不是实测调度上界、传输余量或实时保证。若真实 owner 错过它，应拒绝本窗，保留失败，不能扩大窗口以追认过去的操作。

| 方案 | 正确性条件与代价 | 本次决定 |
|---|---|---|
| A：有界真实时间窗 | 固定 origin/index；原 ready 不晚于名义时点；actual now 落在半开窗且仍早于原期限；保留完整 stateful owner。只增加策略与显式选择。 | 采用，限定 PC_DIRECT。 |
| B：离散 slot token | token 必须来自原 source/clock/BOOT，至多消费一次，还必须用实际时钟验证有限有效区间。单独的 ordinal/token 不能证明“当前”，进程延迟后持有 token 仍会过期。 | 暂不采用；若省略时间检查不正确，若保留则相当于 A 再加 token registry。现有 `_VerifiedSlot` 已有索引关联，无需再造凭据。 |
| C：lower-level 诊断 authority | `PcDirectRuntime` + `OwnedMotionExecutor` 可复用；但运动前仍须实现原 actor HANDLE、完成/候选一次消费、原 progress/观测/心跳期限与全几何，等于另造一套 owner 集成。 | 此时只适合明确的采集/BOOT诊断。不能因生产门关闭而绕过 stateful owner 去做声称合格的运动；不作为本次最小调度修复。 |

## 源码发现

产品实读基准 HEAD `353aa3a540576e92e023eaa62c68487a8a1d00d6`。下列行号均相对 `.local/deepeye-implementation-a/competition/deepeye/`，具体字节固定在 `source-pins.json`。

1. `integration/candidate_mailbox.py:271–299` 当前 `_plan` 用 `max(now, ready)` 调 `late_candidate_action`，所以 `now=S+1ns` 会先向后求下一个名义 slot；随后 `:306–313` 又要求 `now == selected.slot_start_ns`。**仅把 equality 改成范围仍无法修复该问题。**
2. `simulation/authority/actor_composition.py:269–274` 在原 slot verifier 返回后重新取得实际 owner 时钟，再交给 stateful owner。保留这个刷新，不能用 verifier 记录的旧 now 代替。
3. `_CandidateOwner` 已保存原 completion proof，内部使用 mailbox 的 generation/source/clock、观察保留、完成顺序/指纹、一次消费和 STOP 状态；`:142` 在消费后不可逆移除 pending proof，`:149–151` 再交未改的 ProgressGate 核请求关联。不要以无状态 raw-bytes helper 替换它。
4. frozen `boot_profiles.json` 的 PC_DIRECT 正常模式只传 EVENT/TELEM/STATE，不传 CONTROL/ACK；`boot_profile.py:1310–1321` 也明确此模式无 motion TX。因此新主机决策消费窗不代表 HIL 串口延后发送许可。fast/stress 名义决策锚点分别为 210/2050 ms，周期为 500/8000 ms。
5. `actor_composition.py:162–164,561` 生产 channels gate 仍无条件拒绝，并先于 registry/native acquisition。调度策略不能实现缺失的来源认证、provider 或真实 CPU 模型。

## 确定语义

固定单次 activation 的 `O=slot_origin_ns`、profile、周期 `P`、首名义偏移 `F`、显式策略 `W`。所有值在原 BOOT/activation 时冻结，整数及和/积均须处于现有 0..2**63−1 范围，严格排除 bool 和 int 子类；`0 < W < P`。不移动 origin，不按收件时刻重新开窗，不改冻结 BOOT 文档/hash。

原已验证 grant 给定 `k>=0`，直接由该索引计算 `S=O+F+k*P`、`E=S+W`。不再由 `max(now,ready)` 反推一个“当前可命中的”索引。`k` 必须大于 `_last_slot`，且 generation、source、clock、BOOT 都与本 owner 完全相同；原 slot provider 仍须核实事件关联。记录类型及 Python identity 只是进程内关联，不是认证。

令 `R=original completion_upper + original usb_upper + original packing_upper`，保持原显式、保守 transfer bounds，不为 PC_DIRECT 自动填零。令 `D=min(original completion deadline, original sample_lower+profile age_cap)`，其中 completion deadline 仍由原 `completion_lower+progress_max_age` 产生，绝不能从到达、slot、issue 或 now 重算。

仅当以下条件全部成立时，v2 才消费：

```text
active PC_DIRECT v2, retained original pending completion/observation
known original source/clock/bounds/sample time
R <= S
S <= actual_now < E
actual_now < D
grant.k > last_consumed_window
```

`R>S` 的候选不能追认在本窗就绪；只能在另一个原验证 grant 的后续固定窗重新检查，且所有原期限仍有效。若后续 `S>=D`，无可消费窗。过早/过晚或没有可用 pending 返回 None；坏形状、时钟回退、身份冲突沿用原 `_entry` 的 fail-closed 停止。已完成的较新候选可替换 pending；若它对本窗过晚，不回退拾取已被替换的旧候选。按新契约可用性有损，但来源与顺序不降级。

消费成功在同一个串行 owner 方法内先更新 `_last_slot=k`、清空 pending，返回原 candidate bytes/invocation/generation/context 的 selection，并记录实际消费时刻及 S/E。后续 raw request 不匹配、ProgressGate/runtime/executor 拒绝或异常，都不能重新插入候选或重试该消费。完全相同的已提交 command bytes 仍仅复用原 committed proof，不重新 consume，也不更新原期限。改 seq 重用已消费 candidate 仍拒绝。

**窗口只限制新候选消费时点。** 它不续租、不是 motion TTL，也不声称命令/几何/CAS 必须在 E 前完成。消费后动作可否执行，继续由原命令 TTL、原 sample age、原 completion progress、原 actor lifetime 和原心跳的最小期限决定。10 ms 窗不增加这些原期限，也不替代它们。任何延迟后的整段 dt 仍必须由最终实际时钟检查覆盖。

## 最小 API 与准确文件范围

以下是下一次实施任务建议归属，本子任务未修改它们。

1. `integration/candidate_mailbox.py`：新增 frozen `PcDirectWindowV2(consume_window_ns)`；为 `LatestCompletedMailbox.activate(..., pc_direct_window_v2=None)` 增加显式、冻结的策略关联，None 保留 legacy。新增 `consume_pc_direct_v2(now_ns, *, grant)`，按上述原 grant 索引公式计算；返回新增 frozen `PcDirectWindowSelection`（继承现有 Selection 字段，再含 `consumed_at_ns`、`window_close_ns`）。本次不必增加 v2 的 plan API。v2 activation 仅允许 PC_DIRECT；legacy `consume` 不接受 v2 activation，v2 方法不接受 legacy activation，避免混用。原 exact-slot `consume` 的 equality 与 legacy `_plan` 算法不变。
2. `simulation/authority/candidate_owner.py`：为私有 `_CandidateOwner(..., activation, now, *, pc_direct_window_v2=None)` 增加已固定策略；交给原 mailbox activation。`select` 仅按该固定策略调用 legacy 或 v2 consume；不从 command/event 选择策略或窗口宽度。不替换 `_CompletedInference` 原对象，不改 offer/duplicate_proof/commit 的不变量；可将 selection 的 S/E/actual 消费记录留在 authority 私有诊断中，不能回传 controller 当运动 grant。
3. `simulation/authority/actor_composition.py`：给 `AuthorityConfig` 末尾增加 `pc_direct_window_v2: PcDirectWindowV2 | None = None`，新选择是显式值，旧 config 仍用 legacy。factory 在原 production gate 之前检查严格 policy 形状/数值；activation 看到原 BOOT profile/topology 后检查 W<P 与 PC_DIRECT，失败先退休而不是降为 legacy；传给 `_CandidateOwner`。原 verifier→checkpoint→actual `_progress_time()`→checkpoint→select 顺序不变。`_production_channels` 的 unconditional rejection、factory ownership、actor target、executor target及所有原门保持原样；没有公开 provider/flag 绕过。
4. 新 `integration/test_pc_direct_window_v2.py`、新 `tests/simulation/test_pc_direct_window_v2.py`：仅新增 focused controls，不调用旧 TestCase discover 或原完整测试组。可借现有 fixtures 的构造 helper，但报告明确 upstream/native/clock 模拟范围。
5. 新 `docs/pc_direct_window_v2.md`，并在 `docs/actor_composition.md` 增加短的可选 v2 段，清晰保留旧 exact-slot 契约和生产 unavailable 事实。冻结 ABI/profile JSON、runtime、watchdog、motion executor、actor lifetime 和几何文件均不在实施写入范围。

如果 root 希望先将纯 policy 与 owner 集成分为两次提交，也可按 1→2/3 顺序执行；只实现 policy 不得宣称完整 composition 可实跑。

## 始终不变的 owner / fence / 停止链

沿用原 composition 单线程、busy/reentry 与 foreign-thread veto，原 BOOT generation/source/clock、原 actor实例/HANDLE与原 approved CPU model关联。观测先获 runtime 接受，再把同一个原 record 提供给 mailbox；完成先有原 IPC/时序 verifier，再 offer，不能从 command 倒推 completion。新窗口方法没有 transport、native 调用或模型调用。

原 `ProgressGate` 仍检查 `activation<=dispatch<=completion_lower<=claimed<=completion_upper<=issue<=actual_now`、完整 candidate/observation/target equality 和严格增加的 IDs。EMPTY 初始期限、当前 completion_lower+固定 age cap 不因等待下一窗而延长；不为通过新窗口而放宽旧 5/100 ms 策略。心跳不续旧动作、完成 receipt 不续 progress、duplicate 不续任何时间。

沿用 runtime→executor admission 的原 bytes；step 仍由原 executor 准备全体积/历史/几何，再唯一 final callback，再原 root CAS。实际 HANDLE sample 与最终 refreshed clock、原最小期限及 executor 严格 `step_end < deadline` 保持原样。final callback 到 CAS 之间不增加日志、hash、时钟、I/O、timer/token检查或 callback。正 CAS 后的 veto 只停止未来准入，保留已提交事实；未知结果必须只读对账，绝不自动重放。

正常错过消费窗本身不制造运动。composition 当前 select(None) 会使这一 activation 退休，保留该可用性代价；不顺手加重试/复活路径。若未来 owner loop 想先 wait 而非提交过早 command，使用普通有界 timer 等到 S 后，仍传真实 now；timer 唤醒不是保证。动作到期的实际 stop/readback仍需真实 owner loop/监督者；策略库没有后台 timer，也不证明 owner 挂起时的停止时限。

## 少量新增验证与结论层级

本设计回合未运行以下测试，也未运行旧测试/旧 PDE/384 板测。后续实施只需新建的少量分组：

1. **边界与关键反例**：固定 R<S、grant k，`S−1` 拒绝，`S+1ns` 成功；E/原D 的等号及晚一纳秒拒绝。R=S 成功、R=S+1 不消费本窗。独立预期直接使用固定常数，不调用被测 `_plan` 生成答案。此组同时证明 legacy 晚 1ns 仍拒绝，未暗改旧 equality。
2. **索引与冻结策略**：错过本窗不可重设 origin 或让 grant 随 now 移动；后续原 grant 只在原期限尚有效时接受。PC_DIRECT外模式、缺来源/测时/bounds、错误 BOOT/source/clock/generation、W=0/W>=P/bool/overflow与时钟回退拒绝；原 profile hash 不变。
3. **一次消费与关联**：原 proof 原 bytes 成功一次；copy/foreign proof、改 request/target、改 seq 重用 consumed candidate 及 exact duplicate 续期均拒绝/不续期。消费后下游失败不可复活 pending；新较晚候选替换旧候选时不回捞旧候选。
4. **真实刷新而非旧 token 时间**：slot verifier 回调前在窗内、回调后实际 owner clock 已到 E，必须拒绝；用定点旧 now/token 编造当前不能成为有效路径。STOP/reentry/foreign veto 在新路径仍退休。
5. **原期限到最终 CAS**：新窗消费后在 geometry/HANDLE sample 中越过原 TTL/progress/sample/heartbeat/lifetime 任一期限，拒绝整段 dt；正 CAS 后 veto 保留正 receipt。只增加针对新路径的最小反例，不跑旧系统组；不改既有 executor。
6. **单次本机真实时钟观察**：在新 pure-policy harness 中固定一次实际 origin，用普通 bounded wait 等名义 S，再传 `time.monotonic_ns()`，保留实际唤醒/消费迟到量。无冻结时钟、无重设 origin、无循环直到成功。错过 10ms 窗如实记录 availability 未证实；即使成功也只是本机软件调度观察，upstream fixture/无板/无模型，不代表实时上界或生产可行。

新策略通过的最高结论只能是“PC_DIRECT v2 stateful 调度软件在指定新 controls 中符合约束”。它不认证 BOOT/完成事件/端点、不建立真实 PL/ADC或来源测时，不替代 C 固定CPU包与因果broker，不开放生产门。root 的下一次真实链路仍须绑定新 operation/request、同次 build/bit/HWH、真实板观测、原样本/完成/命令时序、实际 headless CAS与原期限停止；software_fixture 经真实 PL 的最早诊断与 H09/ADC/最终模型验收继续分开。H12 两条完整路径、H01–H15、G03/R03/all29 均不因此验收通过。

## 本次冻结与自查

`source-pins.json` 固定所读产品 source/doc 的字节与起始 head；`result.json` 固定本报告、身份、合同及实施建议。`verification.json` 再读核对 source pins 和本目录工件；11 个所读产品文件均与基准提交一致，本子任务命令没有产品写入。主会话并行只增 BOOT/CRC 相关增量，若 HEAD 变化按准确源码 pin 而非过时 HEAD assertion 判断本设计适用性。没有派工、产品或外部 peer 网络请求、外部消息、服务、UI、实板或 product test effects；仅执行已授权的 native 租约 validate/complete 控制调用。

自查：方案 A/B/C 均有明确取舍；ready 与 now 分开，固定 grant 锚点避免旧 ceil(now) 缺陷；半开边界与整数溢出明确；消费窗不续 motion/progress；新 API 有版本、冻结期与 PC_DIRECT 限制；原 owner/once-consume/最终 fence/CAS 保持；生产门与旧失败证据保留。最终采用和实施由 root 审定，不向人类重复申请逐项许可。
