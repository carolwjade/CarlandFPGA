"""Read-only committed baseline capture for the assigned independent review."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PRODUCT = ROOT / '.local/deepeye-implementation-a'
GIT = Path('C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe')
PIN = '88f7214eeb4770106933b9062445152a520ce4fc'

def git(*args):
    return subprocess.check_output([str(GIT), '-C', str(PRODUCT), *args])

if git('rev-parse', 'HEAD').decode().strip() != PIN:
    raise SystemExit('Committed baseline HEAD changed; await root pins')

files = [
    'competition/deepeye/integration/candidate_mailbox.py',
    'competition/deepeye/simulation/authority/candidate_owner.py',
    'competition/deepeye/simulation/authority/actor_composition.py',
    'competition/deepeye/simulation/authority/pc_direct_runtime.py',
    'competition/deepeye/simulation/authority/motion_executor.py',
    'competition/deepeye/integration/pc_direct_watchdog.py',
    'competition/deepeye/simulation/isolation/actor_owner.py',
    'competition/deepeye/integration/test_host_envelope.py',
    'competition/deepeye/tests/simulation/test_actor_composition.py',
    'competition/deepeye/docs/actor_composition.md',
    'competition/deepeye/docs/boot_profiles.json',
]
pins = []
for name in files:
    data = git('show', 'HEAD:' + name)
    target = OUT / 'baseline' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    pins.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})

scope = json.loads((ROOT / 'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
canonical = json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
digest = hashlib.sha256(canonical).hexdigest()
if digest != 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804':
    raise SystemExit('Immutable requirements hash mismatch')
if git('rev-parse', 'HEAD').decode().strip() != PIN:
    raise SystemExit('HEAD changed during capture; retained files are not an authorized snapshot')

inputs = []
for rel in [
    '.planning/deepeye-resume-20261018/live-slot-window-design-20261024/report.md',
    '.planning/deepeye-resume-20261018/gen3-live-integration-20261024/pc-direct-window-v2-decision.json',
    '.planning/deepeye-desktop-handoff-20261015/transfer.json',
    'docs/competition/deepeye-2026/immutable_scope.md',
    'docs/competition/deepeye-2026/immutable_scope.json',
]:
    data = (ROOT / rel).read_bytes()
    inputs.append({'path': rel, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
record = {'schema': 1, 'phase': 1, 'job_id': 'child-97afe43bdbe44bdd93eed7eeed874cd1',
          'work_id': 'A-PC-DIRECT-WINDOW-V2-REVIEW-20261024-v1',
          'agent_id': '/root/pc_direct_window_review', 'baseline_head': PIN,
          'requirements_sha256': digest, 'requirement_ids': [r['id'] for r in scope['requirements']],
          'product_source_reads': 'git show HEAD:path only; no author current new source or tests read',
          'baseline_files': pins, 'input_files': inputs, 'tests_run': False,
          'product_writes': False, 'board_access': False, 'native_complete_called': False}
(OUT / 'phase1-source-pins.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'requirements_sha256': digest, 'baseline_head': PIN, 'captured_files': len(pins), 'tests_run': False}))
