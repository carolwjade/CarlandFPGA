"""Final hash readback and artifact freeze; never reruns controls or clocks."""
import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PRODUCT=ROOT/'.local/deepeye-implementation-a'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(data):return hashlib.sha256(data).hexdigest()
def readj(path):return json.loads(path.read_text(encoding='utf-8'))
audit=readj(OUT/'phase2-sourcehashes.json')
for field in ['candidate_sources','unchanged_dependencies','protected_files']:
    for name,pin in audit[field].items():assert sha((PRODUCT/name).read_bytes())==pin['sha256'],name
for item in readj(OUT/'phase1-manifest.json')['files']:
    assert sha((OUT/item['path']).read_bytes())==item['sha256'],item['path']
assert readj(OUT/'controls-result.json')==dict(tests_run=9,failures=0,errors=0,
    real_clock_observation=None,synthetic_upstream=True,board_access=False,G03='not_run',R03='not_run',all29='not_run')
assert readj(OUT/'independent-controls-execution.json')['exit_code']==0
assert subprocess.check_output([GIT,'-C',str(PRODUCT),'rev-parse','HEAD']).decode().strip()==audit['base_head']
check=subprocess.run([GIT,'-C',str(PRODUCT),'diff','--check','--',*audit['candidate_sources']],capture_output=True)
(OUT/'owned-diff-check-stdout.log').write_bytes(check.stdout)
(OUT/'owned-diff-check-stderr.log').write_bytes(check.stderr)
assert check.returncode==0
result={'schema':1,'status':'independent_review_controls_passed_scope_limited',
    'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,
    'work_id':'A-PC-DIRECT-WINDOW-V2-REVIEW-20261024-v1','agent_id':'/root/pc_direct_window_review',
    'job_id':'child-97afe43bdbe44bdd93eed7eeed874cd1',
    'director':'01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3',
    'base_head':audit['base_head'],'requirements_sha256':audit['requirements_sha256'],
    'H01_H15_preserved':True,'focused_tests':{'methods':9,'failures':0,'errors':0,'exit_code':0,'runs':1},
    'candidate_source_count':7,'author_manifest_files_count':29,'author_manifest_itself_counted':False,
    'unchanged_dependencies':15,'protected_files':4,'unchanged_ast_objects':41,
    'frozen_harness_sha256':readj(OUT/'independent-controls-execution.json')['frozen_harness_sha256'],
    'sourcehashes_sha256':sha((OUT/'phase2-sourcehashes.json').read_bytes()),
    'report_sha256':sha((OUT/'report.md').read_bytes()),'owned_diff_check_exit_code':check.returncode,
    'independent_product_findings':[],
    'audit_attempt1':{'exit_code':1,'product_finding':False,'reason':'review static expected-set error; retained'},
    'audit_attempt2':{'exit_code':0,'product_modified':False},
    'author_clock_observation':{'attempts':1,'reported_lateness_ns':-7000000,'consumed':False,
        'repeated_by_reviewer':False,'actual_window_availability':'not_established'},
    'current_clock_capability_source':'root saved query, not rerun',
    'current_monotonic':'GetTickCount64; reported resolution 15.625ms',
    'current_perf_counter':'QueryPerformanceCounter; reported resolution 100ns; different epoch/domain',
    'synthetic_upstream':True,'production_available':False,'provenance_established':False,
    'formal_acceptance':False,'acceptance_owner':'A/root',
    'author_suite_run':False,'old_testcases_run':False,'PDE_384_exhaustive_run':False,
    'product_writes':False,'stage_commit':False,'board_access':False,'service_UI_network_messages':False,
    'G03':'not_run','R03':'not_run','all29':'not_run'}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
excluded={'lease.private.json','artifact-manifest.json','freeze.json','native-complete-request.json','native-complete-receipt.json'}
files={}
for p in sorted(OUT.rglob('*')):
    if not p.is_file() or p.name in excluded:continue
    data=p.read_bytes();files[p.relative_to(OUT).as_posix()]={'sha256':sha(data),'bytes':len(data)}
manifest={'schema':1,'files':files,'excluded':sorted(excluded),'lease_private_publish':False}
(OUT/'artifact-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name,pin in files.items():
    data=(OUT/name).read_bytes();assert sha(data)==pin['sha256'] and len(data)==pin['bytes'],name
freeze={'schema':1,'manifest_sha256':sha((OUT/'artifact-manifest.json').read_bytes()),
        'result_sha256':sha((OUT/'result.json').read_bytes()),'report_sha256':result['report_sha256'],
        'member_count':len(files),'all_members_readback_verified':True,'source_pins_rechecked':True,
        'phase1_frozen_members_unchanged':True,'tests_rerun':False,'real_clock_repeated':False,
        'native_complete_not_yet_called':True}
(OUT/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n',encoding='utf-8')
print(json.dumps(freeze))
