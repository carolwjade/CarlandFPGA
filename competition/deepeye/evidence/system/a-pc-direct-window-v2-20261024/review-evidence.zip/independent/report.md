# PC_DIRECT v2 独立限定复核

本轮精确候选在冻结的 **9 组独立 controls 中全部通过**：9 tests、0 failures、0 errors、exit 0。结合准确 diff 与静态保留核对，本轮未发现指定 v2 消费窗改动违反已选契约的产品反例。该结论仅覆盖本报告的有限软件控制；是否接收/集成由 A/root 决定。

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，work `A-PC-DIRECT-WINDOW-V2-REVIEW-20261024-v1`，agent `/root/pc_direct_window_review`，job `child-97afe43bdbe44bdd93eed7eeed874cd1`。parent 提供租约以 canonical agent 实际验证，`execution_allowed=true`；token 未进入报告或清单。主为 Desktop `01a16988-bdcb-70e1-ae10-1304b5cf7875` / generation3。既有 node 配置为 A / fpga-main；A/root 独占实板，本子任务无板、串口、UI、服务、actor/native进程启动或外部网络消息。

已读 ROOT AGENTS、两项项目技能/A role、协作协议、transfer/current handoff、immutable scope md/json、设计和 root 决定。requirements 按 UTF-8、`ensure_ascii=False`、`sort_keys=True`、compact separators 两阶段实算为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，保留合同 `DEEPEYE-HUMAN-LOCK-20261014/revision1`、H01–H15 和原29卡。

## 版本与独立性

第一阶段仅以 `git show HEAD:path` 读取提交 `88f7214eeb4770106933b9062445152a520ce4fc`，未读作者实时新源/新测试。计划、字面常量预期与 harness 在作者候选解封前冻结：`phase1-manifest.json` SHA256 `81e0f3c13337e4e1405dcfbcefdc25853202ac591498556663cc84e379a33cde`。本轮实际执行的 `independent_controls.py` 仍为原 SHA256 `72d766ebf5f0ee180ddf5c51a32b6f1f6f52d5facc3f94a7fbbdc9e60e836db4`，第二阶段未改 harness 或预期。

root 在确认作者 completed/terminal 后提供 `v2-phase2-candidate.json`。本子任务实算核对作者 `source-pins.json` SHA256 `5b2004e96e49f76e0afb69ce1079144c8379b24852d6be941a46b0c1630d5a78`、`artifact-manifest.json` SHA256 `6d3a246049b63366fd96ec5135a01b3d89a6b0af3ee5db76c774ffae0517f8cf`，以及其全部 **29 个 files 成员**；manifest 自身不算成员。此前给 root 的消息曾写30，是复核者计数笔误，此处以实际 `len(files)=29` 更正，不修改作者工件。

7 个当前产品文件逐字节符合 root pins 和作者 source-snapshot；准确副本在本目录 `candidate-snapshot/`。三源、两新测试、两文档的全部 diff 在 `candidate.diff`。HEAD 仍为基线，七文件未提交。15 个依赖逐字节等于该 committed base，4 个原受保护文件符合原保护哈希。独立保留核验有41个原 AST 对象（含整个 ProgressGate、Dependencies、production gate、旧 `_plan`、owner offer/commit/duplicate、composition guards/step/刷新时钟）相同。具体哈希与对象清单见 `phase2-sourcehashes.json`。

本轮读审作者两新测试及其 runner/记录，未运行作者25组、未 discover/执行旧 TestCase、旧整组、PDE、384 或 exhaustive。本轮 harness 只导入被测产品模块，使用自建 fixture，不导入旧或作者测试模块。

## 实际新增控制

执行命令由 `run_frozen_controls.py` 保存为参数数组：现有 `.local/venv/Scripts/python.exe -B -X utf8 independent_controls.py --phase2-authorized`。只在子进程设现有 `.local/deepeye-host-deps` 的 PYTHONPATH 和禁写 bytecode；未安装依赖。准确 stdout/stderr/exit code 见 `independent-controls-stdout.log`、`independent-controls-stderr.log` 和 `independent-controls-execution.json`。

| 组 | 实际检验与结果 |
|---|---|
| C01 | 独立字面 O=17ms、S=227ms、E=237ms；S−1拒绝，S/S+1/E−1成功，E/E+1拒绝；原 D−1成功、D拒绝。通过。|
| C02 | R=S成功、R=S+1不追认；grant索引不可随 now 跳；错过原窗不移动锚点，后续窗仍受原D；v2 在旧 `_plan` 抛错 spy 下仍成功。通过。|
| C03 | W=0/bool/int子类/P/overflow、HIL opt-in、未知 source/clock/bounds/sample、错generation、index overflow和clock回退拒绝。通过。|
| C04 | 默认 legacy PC_DIRECT/HIL 在S成功、晚1ns拒绝；policy/entry混用拒绝。通过。|
| C05 | 同候选一次消费；重复完成不重装pending；同窗新候选不可二次消费；新较晚候选替换后不捞回旧候选。通过。|
| C06 | 真实 CandidateOwner 保留 offer 原proof对象；后续请求target不匹配由原 ProgressGate 拒绝，已消费pending保持空，重复offer/再选不复活；错BOOT/source/clock proof拒绝。通过。|
| C07 | slot verifier进入时S+1，返回前推进时钟到E；真实 Dependencies 刷新 now 后拒绝，窗口未消费。通过。|
| C08 | 已commit完全相同bytes复用原proof，不再调用slot verifier；原progress deadline和generation不变；改seq不能重用已消费候选；独立fresh seam在原D拒绝。通过。|
| C09 | 不替换生产gate，带v2配置仍 ActivationUnavailable，registry spy零调用。通过。|

C06–C08 是真实 CandidateOwner/ProgressGate/Dependencies 方法加轻量私有验证 seam；不启动完整 actor/native 进程，不把 seam 当生产来源认证。全体上游 BOOT/完成/观测/slot/source/clock 均 synthetic。C10/C11 以准确 diff、依赖字节、原 AST 与文档审读完成；未新增旧系统行为执行。C12 已被 root 后续明确禁止，本子任务没有进行真实时钟观察。

## 源码与文档审查结论

新窗只由原 grant k、冻结 O/F/P/W 计算S/E；`R<=S` 与 `S<=refreshed_now<min(E,D)` 在消费前检查，ready/deadline求和和slot乘加均有严格整数/溢出约束。没有调用旧 ceil(now) planner，没有从 receipt/issue/now 开新窗；W=10ms维持为 root 选择的显式策略。

mailbox 先更新last-slot并清pending；owner随后清原pending，再交未改ProgressGate。下游拒绝无重新插入路径；已提交完全重复bytes仅取原proof。原 TTL/sample/progress/AI heartbeat/actor lifetime 门及全几何/executor/final-fence-CAS 实现未变；本轮只新增上述必要检查，**不以静态相同声称每个旧门重新行为验证**。final callback到CAS间未新增工作。

public legacy plan/consume新增v2混用拒绝，原 `_plan` 及无策略consume核心保持；HIL不可opt-in。factory检查策略形状后仍先遇到无条件production拒绝，BOOT activation才检查profile相关 W<P；失败沿用原composition退休链。文档明确默认legacy、explicit opt-in、10ms policy、消费窗不等于TTL、错过拒绝、原proof/期限、生产不可用及fixture证据限制。

## 唯一真实时钟记录的边界

本轮只审读并复制作者原 `monotonic-once.json/log` 和 root 的 `host-clock-capabilities-20261024.json`，未执行观察脚本或另一轮sleep/消费。作者记录 origin=129467453000000、S=129467663000000、E=129467673000000、reported actual now=129467656000000，即记录的 monotonic 时间戳比S早7ms；ready=129467468000000。`consumed=false`、last-window=−1、pending保留，与半开窗拒绝一致。它不建立10ms窗实际可用性，也不能据此推断物理sleep早唤醒上界。

root保存的当前能力查询说明 Python3.12.14 的monotonic使用 GetTickCount64、报告resolution15.625ms；perf_counter使用QPC、报告resolution100ns。该文件是root原查询，本子任务未重测；两者epoch/domain不能混用，名义resolution不提供转换关系或调度保证。本轮未更换时钟、宽度、source/domain、origin或原门，也未追试获得pass。

## 保留的审计失败与最终边界

静态审计首次错误要求 mailbox `__init__` 和public `plan` 逐AST保持，因预期policy初始化先触发exit1。保存原脚本 `audit_phase2-attempt1.py`、tool原traceback转录和exit metadata。读准确diff确认这些是授权新增字段/guard后，仅修正审计对象集；未改冻结harness、预期或产品。修正后的静态审计exit0。没有独立行为control失败，9组仅执行一次。

作者25测试、早7ms观测及先前失败保留为作者证据，本轮没有重放。新增fixture不证明BOOT/AI/clock/PL/ADC provenance、真实deadline停止、模型收益、真实板卡/模拟器联动或生产可运行。H09、两条完整H12、完整3D/UI及原29卡继续由root依真实证据逐卡验收；`G03=not_run`、`R03=not_run`、`all29=not_run`，本次不作最终验收。

最终 report/result/sourcehashes/manifest 在原native_complete前冻结；receipt另存以避免循环hash。所有写入仅位于本分配目录，无产品编辑、stage/commit、再派工、外部消息、服务/UI或实板操作。
