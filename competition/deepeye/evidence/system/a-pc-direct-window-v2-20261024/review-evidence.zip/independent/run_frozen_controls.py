"""Run only the frozen nine independent groups and preserve exact output."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
manifest=json.loads((OUT/'phase1-manifest.json').read_text(encoding='utf-8'))
expected=next(x['sha256'] for x in manifest['files'] if x['path']=='independent_controls.py')
actual=hashlib.sha256((OUT/'independent_controls.py').read_bytes()).hexdigest()
assert actual==expected
command=[str(ROOT/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',
         str(OUT/'independent_controls.py'),'--phase2-authorized']
child_env=dict(os.environ,PYTHONPATH=str(ROOT/'.local/deepeye-host-deps'),PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run(command,cwd=ROOT,env=child_env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(OUT/'independent-controls-stdout.log').write_bytes(run.stdout)
(OUT/'independent-controls-stderr.log').write_bytes(run.stderr)
metadata={'command':command,'cwd':str(ROOT),'exit_code':run.returncode,
    'frozen_harness_sha256':actual,'stdout_sha256':hashlib.sha256(run.stdout).hexdigest(),
    'stderr_sha256':hashlib.sha256(run.stderr).hexdigest(),
    'new_groups_requested':9,'author_suite_run':False,'old_testcase_discovery':False,
    'real_clock_observation_run':False,'env_override':{'PYTHONPATH':'.local/deepeye-host-deps','PYTHONDONTWRITEBYTECODE':'1'}}
(OUT/'independent-controls-execution.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
print(run.stderr.decode('utf-8',errors='replace'))
print(run.stdout.decode('utf-8',errors='replace'))
print(json.dumps({'exit_code':run.returncode,'harness_sha256':actual,'real_clock_observation_run':False}))
raise SystemExit(run.returncode)
