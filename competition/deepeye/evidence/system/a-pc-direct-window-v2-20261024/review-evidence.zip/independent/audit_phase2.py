"""Pin verification and static preservation audit, no product imports/effects."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PRODUCT=ROOT/'.local/deepeye-implementation-a'
AUTHOR=OUT.parent/'pc-direct-window-v2-20261024'
INTEGRATION=OUT.parent/'gen3-live-integration-20261024'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
PIN='88f7214eeb4770106933b9062445152a520ce4fc'

def sha(data):return hashlib.sha256(data).hexdigest()
def readj(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def git(*args):return subprocess.check_output([GIT,'-C',str(PRODUCT),*args])

candidate=readj(INTEGRATION/'v2-phase2-candidate.json')
assert candidate['base']==PIN and git('rev-parse','HEAD').decode().strip()==PIN
assert sha((AUTHOR/'source-pins.json').read_bytes())==candidate['author_source_pins_sha256']=='5b2004e96e49f76e0afb69ce1079144c8379b24852d6be941a46b0c1630d5a78'
assert sha((AUTHOR/'artifact-manifest.json').read_bytes())==candidate['author_artifact_manifest_sha256']=='6d3a246049b63366fd96ec5135a01b3d89a6b0af3ee5db76c774ffae0517f8cf'
frozen=readj(OUT/'phase1-manifest.json')
for f in frozen['files']:
    assert sha((OUT/f['path']).read_bytes())==f['sha256'],f['path']
author_manifest=readj(AUTHOR/'artifact-manifest.json')
for name,pin in author_manifest['files'].items():
    data=(AUTHOR/name).read_bytes()
    assert sha(data)==pin['sha256'] and len(data)==pin['bytes'],name
sourcehashes={}
diffs=[]
for name,pin in candidate['source_files'].items():
    data=(PRODUCT/name).read_bytes()
    assert sha(data)==pin['sha256'] and len(data)==pin['bytes'],name
    assert data==(AUTHOR/'source-snapshot'/name).read_bytes(),name
    destination=OUT/'candidate-snapshot'/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(data)
    baseline=OUT/'baseline'/name
    old=baseline.read_bytes() if baseline.exists() else b''
    assert (sha(old) if baseline.exists() else None)==pin['base_sha256'],name
    diffs.extend(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),
                                    fromfile='base/'+name,tofile='candidate/'+name))
    sourcehashes[name]={'sha256':sha(data),'bytes':len(data),'base_sha256':pin['base_sha256']}
(OUT/'candidate.diff').write_text(''.join(diffs),encoding='utf-8')

author_pins=readj(AUTHOR/'source-pins.json')
unchanged={}
for name,pin in author_pins['source'].items():
    if not pin['same_as_base']:continue
    data=(PRODUCT/name).read_bytes()
    base=git('show','HEAD:'+name)
    assert sha(data)==pin['sha256']==sha(base),name
    unchanged[name]={'sha256':sha(data),'bytes':len(data),'equals_committed_base':True}
protected={}
for name,pin in author_pins['protected_files'].items():
    digest=sha((PRODUCT/name).read_bytes())
    assert digest==pin['expected_sha256']==pin['actual_sha256'],name
    protected[name]={'sha256':digest,'matches_original_protected_pin':True}

def objects(path):
    def visit(items,prefix=''):
        result={}
        for n in items:
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                name=prefix+n.name
                result[name]=ast.dump(n,include_attributes=False)
                if isinstance(n,ast.ClassDef):result.update(visit(n.body,name+'.'))
        return result
    return visit(ast.parse(path.read_text(encoding='utf-8')) .body)

ast_preserved={}
checks={
 'integration/candidate_mailbox.py':['_integer','_entry','TransferBounds','Completion','SlotGrant','Selection',
    'LatestCompletedMailbox._halt','LatestCompletedMailbox._time',
    'LatestCompletedMailbox._active','LatestCompletedMailbox.observe','LatestCompletedMailbox.complete',
    'LatestCompletedMailbox._plan','LatestCompletedMailbox.stop','LatestCompletedMailbox.snapshot'],
 'simulation/authority/candidate_owner.py':['_bounded','_CompletedInference','_MailboxActivation','_VerifiedSlot','_InputTransaction',
    '_CandidateOwner._active','_CandidateOwner.retire','_CandidateOwner.observe','_CandidateOwner.offer',
    '_CandidateOwner.duplicate_proof','_CandidateOwner.commit'],
 'simulation/authority/actor_composition.py':['_ProgressGate','_Dependencies','_production_channels','_entry',
    'ActorComposition._checkpoint','ActorComposition._active','ActorComposition._retire','ActorComposition._cleanup',
    'ActorComposition._progress_time','ActorComposition.accept_observation','ActorComposition.accept_completion',
    'ActorComposition.accept_command','ActorComposition.step','ActorComposition.poll','ActorComposition.stop','ActorComposition.close'],
}
for rel,names in checks.items():
    name='competition/deepeye/'+rel
    old,new=objects(OUT/'baseline'/name),objects(PRODUCT/name)
    for item in names:
        same=old[item]==new[item]
        ast_preserved[rel+':'+item]=same
        assert same,(name,item)

scope=readj(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
req=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
assert req=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
for name,source in [('author-monotonic-once.json',AUTHOR/'monotonic-once.json'),
                    ('author-monotonic-once.log',AUTHOR/'monotonic-once.log'),
                    ('root-host-clock-capabilities.json',INTEGRATION/'host-clock-capabilities-20261024.json'),
                    ('root-phase2-candidate.json',INTEGRATION/'v2-phase2-candidate.json')]:
    (OUT/name).write_bytes(source.read_bytes())
record={'schema':1,'base_head':PIN,'candidate_sources':sourcehashes,'unchanged_dependencies':unchanged,
        'protected_files':protected,'ast_preserved':ast_preserved,'requirements_sha256':req,
        'phase1_frozen_members_verified':len(frozen['files']),
        'author_manifest_members_verified':len(author_manifest['files']),
        'author_source_pins_sha256':candidate['author_source_pins_sha256'],
        'author_artifact_manifest_sha256':candidate['author_artifact_manifest_sha256'],
        'root_phase2_candidate_sha256':sha((INTEGRATION/'v2-phase2-candidate.json').read_bytes()),
        'root_host_clock_capabilities_sha256':sha((INTEGRATION/'host-clock-capabilities-20261024.json').read_bytes()),
        'product_writes':False,'tests_run_by_this_script':False,'real_clock_observation_repeated':False}
(OUT/'phase2-sourcehashes.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'candidate_files_verified':len(sourcehashes),'unchanged_dependencies':len(unchanged),
    'protected_files':len(protected),'unchanged_ast_objects':len(ast_preserved),
    'author_manifest_members_verified':len(author_manifest['files']),'requirements_sha256':req}))
