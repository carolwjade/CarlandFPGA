# 独立复核第一阶段冻结计划

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`；work `A-PC-DIRECT-WINDOW-V2-REVIEW-20261024-v1`；agent `/root/pc_direct_window_review`。负责主为 Desktop `01a16988-bdcb-70e1-ae10-1304b5cf7875` / generation3。已用 parent 提供的 job/token 验证 canonical agent，`execution_allowed=true`；token 不进入报告或清单。仅此目录写入，产品只读。

已读根 AGENTS、两项项目技能/A role、协作协议、transfer/current handoff、immutable scope md/json、设计报告与 root 决定。既有配置只读核实为 A / fpga-main。requirements 按 UTF-8、`ensure_ascii=False`、`sort_keys=True`、compact separators 实算为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，H01–H15 保留。A/root 独占实板。

只使用提交 `88f7214eeb4770106933b9062445152a520ce4fc` 的 `git show HEAD:path` 基线；未读作者当前新源/新测试。基线快照和输入哈希见 `phase1-source-pins.json`。本阶段不运行产品测试、不 native_complete；冻结后结束回合，等待 root 发准确候选 pins。

## 独立预期

root 选 `W=10,000,000 ns` 为策略；不是实测上界。固定常量 `O=17,000,000`、`F=210,000,000`、`P=500,000,000`、`k=0`，直接预期 `S=227,000,000`、`E=237,000,000`。测试 oracle 不调用 `_plan`、`late_candidate_action` 或被测 slot 计算。只在 `R<=S`、`S<=actual_now<min(E,D)` 时消费。测试使用 fresh owner，以免时钟高水位影响边界独立性。

| 控制 | 预先冻结的刺激与预期 |
|---|---|
| C01 半开边界 | `S-1` 拒绝、`S`/`S+1`/`E-1` 成功、`E`/`E+1` 拒绝；独立 `D=S+5ms` 时 `D-1` 成功、`D` 拒绝。|
| C02 固定锚点/ready | `R=S` 成功、`R=S+1` 本窗拒绝；grant k=1 不能在 k=0 窗借 now 命中；错过 k=0 后不能移动其 S，后续原 k=1 只有原 D 仍有效才可消费。用 `_plan` 抛错 spy 验证 v2 不调用旧 ceil(now) 算法。|
| C03 策略/身份拒绝 | W=0/bool/int子类/P/overflow 拒绝；v2+HIL 拒绝；未知 source/clock/bounds/sample 无选择；错误 generation 无选择；错误 owner source/clock/BOOT proof 拒绝；整数溢出/时钟回退 fail closed。|
| C04 legacy/HIL | 无策略的 legacy PC_DIRECT 和 HIL 在 S 成功，晚 1ns 拒绝；两 API 不能混用并成功。冻结 BOOT/profile 文档无改动。|
| C05 一次消费 | 同候选仅一次；原完成重复 receipt 返回 false、不 rearm；同窗新候选不能二次消费；较新 late-ready 候选替换旧 pending 后不可回捞旧候选。|
| C06 原 proof/下游失败 | 真实 `_CandidateOwner` 配上小型私有 verifier seam；selection 保留 offer 的原 `_CompletedInference` 对象。消费后 request target 不匹配由原 ProgressGate 拒绝，pending 保持清空，重复 offer/再选不得复活。|
| C07 回调后刷新 | 进入 slot verifier 时钟在 S+1；verifier 返回前推进到 E；真实 `_Dependencies.verify_command` 必须刷新 now、拒绝消费，不能使用先前时刻。|
| C08 duplicate 不续期 | 第一次通过后 commit 原 bytes/proof；完全相同 request 只复用原 proof、slot verifier 不再消费，原 progress deadline 与 generation 不变；改 seq 重用已消费 candidate 拒绝；原 D 到达时仍拒绝。|
| C09 生产门 | 无 patch `_production_channels` 的有效类型配置仍拒绝，registry 构造 spy 必须零调用；新 policy 不开放 production。|
| C10 期限/final fence 保持 | 对三源/文档语义 diff；原 ProgressGate、runtime、watchdog、executor、actor lifetime、geometry/CAS 路径须与基线一致。新增路径最小检查原 completion deadline、request association 与刷新时钟；复用已完成旧验证，不重跑旧系统组。若 diff 影响原 gate，先报告 root，不补改或以新 fixture 假冒旧门已验证。|
| C11 文档/ABI | 只改已声明7文件；新文档清楚说明 opt-in、10ms policy、消费窗不是TTL、错过失败、production unavailable、fixture非来源证明；旧 exact-slot 与 HIL 不被暗改。|
| C12 单次真实时钟观察 | 可运行一次固定 `time.monotonic_ns()` origin、一次 bounded wait、一次消费；不得冻结/重设 origin 或循环等成功。输出真实迟到量及 selected/missed。成功仅本机软件唤醒观察；错过不重试，保留 availability 未证实。|

## 执行形状与限制

`independent_controls.py` 仅在 phase2 候选 pins 核实后执行；使用自建小 fixture，wire frame 编码可调用原 serializer，预期数值来自上述字面常量。composition 检查仅绑定真实 CandidateOwner/ProgressGate/Dependencies 方法的轻量私有 seam，不启动 registry/进程/服务/网络/板/UI；所有 BOOT、上游完成、clock source 和观测均明确 synthetic。不会 discover 或运行旧 TestCase，也不会运行作者新 suite、旧整组、PDE、384 或 exhaustive。

phase2 先保存精确候选 diff/source hashes，检查三源 + 两新测试 + 两文档与 root pins；作者测试只读审查，不运行。执行本目录新增 focused controls，保存 stdout/stderr/exit code，保留首次失败及后续有明确必要的新尝试，不能改产品。最后冻结 report/result/sourcehashes/manifest，再用原租约 native_complete 并回传持久结果。

本任务最多给出指定新 controls 下的 stateful v2 调度软件证据。新 fixture 不证明 BOOT/AI/clock/PL/ADC provenance、真实 deadline stop、实板链路或生产可运行；`G03/R03/all29=not_run`，H12 两条完整路径与原29卡仍由 root 逐项验收。

记忆仅用于提醒旧证据不可当 oracle、保留失败和准确归属；本轮身份/合同/基线均已现场重验。参考 MEMORY.md:354-355,399-400,624-632。
