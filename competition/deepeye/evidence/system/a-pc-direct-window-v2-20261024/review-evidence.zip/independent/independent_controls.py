"""Frozen phase-1 adversarial controls. Execute only after root's phase-2 pins.

All upstream BOOT/AI/clock/observation values here are synthetic fixtures.
No old or author TestCase is imported/discovered. No provider is authenticated.
"""
import argparse
from dataclasses import replace
import importlib
import json
from pathlib import Path
import struct
import sys
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCT = ROOT / '.local/deepeye-implementation-a'
O, S, E, P, W = 17_000_000, 227_000_000, 237_000_000, 500_000_000, 10_000_000
MODEL = 'b' * 64

def encode(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')

def context(doc, topology=2):
    return dict(session=7, config_epoch=2, boot_sha256=boot.canonical_sha256(doc).hex(),
                transport_profile_id=1, source_id=3, topology_id=topology,
                acquisition_profile_id=1)

def target():
    return dict(action=1, yaw_q=0, pitch_q=0, speed_code=5, duration_ms=1000)

def observation(ctx, sample, seq=9):
    frame = wire.encode(wire.Frame(1, ctx['config_epoch'], seq, seq,
        struct.pack('<4H4HH', 1, 2, 3, 4, 5, 6, 7, 8, 3)))
    return encode(dict(schema_version=1, context=ctx, kind='telem_observation',
        observed_seq=seq, tick_ms_raw=seq, receipt_interval_ns=dict(lower_ns=sample, upper_ns=sample),
        adc_last_interval_ns=dict(lower_ns=sample, upper_ns=sample), adc_first_interval_ns=None,
        native_em_interval_ns=None, sample_count=50, mean_counts=[1,2,3,4],
        range_counts=[5,6,7,8], quality_flags=3, wire_frame_hex=frame.hex()))

def candidate(ctx, completed, candidate_id=1):
    return encode(dict(schema_version=1, context=ctx, kind='model_candidate',
        candidate_id=candidate_id, model_sha256=MODEL,
        observation=dict(context=ctx, observed_seq=9),
        completed_monotonic_ns=completed, target=target()))

def request(ctx, issue, *, seq=3, changed=False):
    t = target()
    if changed: t['yaw_q'] = 1
    return encode(dict(schema_version=1, context=ctx, kind='motion_request',
        candidate_id=1, command_seq=seq, observation=dict(context=ctx, observed_seq=9),
        host_issue_monotonic_ns=issue, target=t))

def box(*, completed=167_000_000, deadline=1_017_000_000, topology=2,
        policy=True, source=True, clock=True, bounds=True, mapped=True, width=W):
    doc = boot.load_document(PRODUCT / 'competition/deepeye/docs/boot_profiles.json')
    ctx = context(doc, topology)
    src, domain = object() if source else None, object() if clock else None
    owner = mb.LatestCompletedMailbox(doc)
    kw = dict(generation=1, slot_origin_ns=O, source=src, clock_domain=domain,
              bounds=mb.TransferBounds(10_000_000,5_000_000) if bounds else None, now_ns=O)
    if policy: kw['pc_direct_window_v2'] = mb.PcDirectWindowV2(width)
    owner.activate(encode(ctx), **kw)
    owner.observe(observation(ctx,O), sample_lower_ns=O if mapped else None, now_ns=O)
    proof = mb.Completion(1,src,domain,candidate(ctx,completed),1,O,completed,completed,deadline)
    owner.complete(proof,now_ns=completed)
    return owner, proof, ctx

def consume(owner, now, k=0, generation=1):
    return owner.consume_pc_direct_v2(now,grant=mb.SlotGrant(generation,k))

class CoreControls(unittest.TestCase):
    def test_C01_half_open_literals(self):
        for now, expected in [(S-1,False),(S,True),(S+1,True),(E-1,True),(E,False),(E+1,False)]:
            with self.subTest(now=now):
                owner,proof,_ = box()
                selected = consume(owner,now)
                self.assertEqual(selected is not None,expected)
                if selected is not None:
                    self.assertEqual((selected.slot_start_ns,selected.window_close_ns,selected.consumed_at_ns),(S,E,now))
                    self.assertEqual(selected.candidate_raw,proof.candidate_raw)
        for now,expected in [(S+4_999_999,True),(S+5_000_000,False)]:
            owner,_,_ = box(deadline=S+5_000_000)
            self.assertEqual(consume(owner,now) is not None,expected)

    def test_C02_fixed_anchor_and_ready(self):
        owner,_,_ = box(completed=S-15_000_000)
        self.assertIsNotNone(consume(owner,S+1))
        owner,_,_ = box(completed=S-15_000_000+1)
        self.assertIsNone(consume(owner,S+1))
        owner,_,_ = box()
        with patch.object(owner,'_plan',side_effect=AssertionError('v2 used old ceil(now) planner')):
            self.assertIsNone(consume(owner,S+1,k=1))
            self.assertIsNotNone(consume(owner,S+2,k=0))
        owner,_,_ = box()
        self.assertIsNone(consume(owner,E,k=0))
        self.assertIsNone(consume(owner,S+P+1,k=0))
        self.assertIsNotNone(consume(owner,S+P+2,k=1))
        owner,_,_ = box(deadline=S+P)
        self.assertIsNone(consume(owner,S+P+1,k=1))

    def test_C03_strict_policy_and_identity(self):
        class IntChild(int): pass
        for width in [0,True,IntChild(1),P,(1<<63)]:
            with self.subTest(width=repr(width)), self.assertRaises(ValueError):
                box(width=width)
        with self.assertRaises(ValueError): box(topology=1)
        for unknown in ['source','clock','bounds','mapped']:
            owner,_,_ = box(**{unknown:False})
            self.assertIsNone(consume(owner,S+1))
        owner,_,_ = box()
        self.assertIsNone(consume(owner,S+1,generation=2))
        self.assertIsNotNone(consume(owner,S+2))
        owner,_,_ = box()
        with self.assertRaises(ValueError): consume(owner,S+1,k=(1<<63)-1)
        self.assertTrue(owner.snapshot()['stopped'])
        owner,_,_ = box()
        self.assertIsNone(consume(owner,S-1))
        with self.assertRaises(ValueError): consume(owner,S-2)
        self.assertTrue(owner.snapshot()['stopped'])

    def test_C04_legacy_and_hil_remain_exact(self):
        for topology in (1,2):
            owner,_,_ = box(policy=False,topology=topology)
            self.assertIsNone(owner.consume(S+1,grant=mb.SlotGrant(1,0)))
            owner,_,_ = box(policy=False,topology=topology)
            self.assertIsNotNone(owner.consume(S,grant=mb.SlotGrant(1,0)))
        owner,_,_ = box(policy=False)
        with self.assertRaises(ValueError): consume(owner,S+1)
        owner,_,_ = box()
        with self.assertRaises(ValueError): owner.consume(S,grant=mb.SlotGrant(1,0))

    def test_C05_consumption_and_no_old_fallback(self):
        owner,proof,ctx = box()
        self.assertIsNotNone(consume(owner,S+1))
        self.assertFalse(owner.complete(proof,now_ns=S+2))
        self.assertIsNone(consume(owner,S+3))
        newer = replace(proof,candidate_raw=candidate(ctx,S-1,2),invocation_id=2,
                        completion_lower_ns=S-1,completion_upper_ns=S-1)
        self.assertTrue(owner.complete(newer,now_ns=S+4))
        self.assertIsNone(consume(owner,S+5))
        owner,proof,ctx = box()
        newer = replace(proof,candidate_raw=candidate(ctx,S-1,2),invocation_id=2,
                        completion_lower_ns=S-1,completion_upper_ns=S-1)
        owner.complete(newer,now_ns=S-1)
        self.assertIsNone(consume(owner,S+1))
        self.assertEqual(owner.snapshot()['pending_candidate_id'],2)

class Clock:
    def __init__(self,value): self.value=value
    def __call__(self): return self.value

def seam():
    """Real owner/progress/Dependencies, synthetic upstream and no actor/native."""
    doc=boot.load_document(PRODUCT/'competition/deepeye/docs/boot_profiles.json')
    ctx=context(doc)
    binding=SimpleNamespace(context_json=encode(ctx),generation=1)
    clock=Clock(O+180_000_000)
    channels=SimpleNamespace(slot_calls=0,slot_hook=None)
    def verify_slot(event,binding_arg):
        channels.slot_calls+=1
        if channels.slot_hook: channels.slot_hook()
        return co._VerifiedSlot(binding,channels,clock,0)
    channels.verify_slot=verify_slot
    activation=co._MailboxActivation(binding,channels,clock,O,10_000_000,5_000_000)
    candidates=co._CandidateOwner(binding,channels,clock,MODEL,100_000_000,clock(),
        activation,clock(),pc_direct_window_v2=mb.PcDirectWindowV2(W))
    candidates.observe(SimpleNamespace(boot=binding,raw=observation(ctx,clock()),
                                      sample_lower_ns=clock()),clock())
    progress=ac._ProgressGate(binding,channels,clock,MODEL,100_000_000,clock())
    clock.value=O+195_000_000
    proof=co._CompletedInference(binding,channels,clock,candidate(ctx,clock()),1,
                                O+180_000_000,clock(),clock())
    candidates.offer(proof,clock())
    owner=SimpleNamespace(_veto=0,_channels=channels,_clock=clock,_progress=progress,
        _candidates=candidates,_input_transaction=co._InputTransaction('command',slot_event=object()),
        _command_record=None,_checkpoint=lambda epoch=None:None)
    owner._progress_time=lambda:progress.observe_time(clock())
    dep=ac._Dependencies(owner)
    dep._verify=lambda name,event,binding_arg,kind:event
    clock.value=S+1
    return SimpleNamespace(ctx=ctx,binding=binding,clock=clock,channels=channels,
        candidates=candidates,progress=progress,proof=proof,owner=owner,dep=dep)

def verify(f,raw):
    return f.dep.verify_command(SimpleNamespace(raw=raw),f.binding)

class SeamControls(unittest.TestCase):
    def test_C06_original_proof_and_downstream_failure(self):
        f=seam();raw=request(f.ctx,S+1)
        verify(f,raw)
        self.assertIs(f.owner._input_transaction.selected_proof,f.proof)
        f=seam()
        with self.assertRaises(ValueError):verify(f,request(f.ctx,S+1,changed=True))
        self.assertIsNone(f.candidates._pending)
        self.assertIsNone(f.candidates._mailbox.snapshot()['pending_candidate_id'])
        self.assertFalse(f.candidates.offer(f.proof,S+2))
        with self.assertRaises(ValueError):
            f.candidates.select(request(f.ctx,S+2),co._VerifiedSlot(f.binding,f.channels,f.clock,0),S+2)
        for field in ['boot','source','clock_domain']:
            f=seam()
            with self.assertRaises(ValueError):
                f.candidates.offer(replace(f.proof,**{field:object()}),S+1)

    def test_C07_refresh_after_verifier(self):
        f=seam();f.channels.slot_hook=lambda:setattr(f.clock,'value',E)
        with self.assertRaises(ValueError):verify(f,request(f.ctx,S+1))
        self.assertEqual(f.channels.slot_calls,1)
        self.assertEqual(f.candidates._mailbox.snapshot()['host_time_high_water_ns'],E)
        self.assertEqual(f.candidates._mailbox.snapshot()['last_consumed_window'],-1)

    def test_C08_duplicate_never_renews(self):
        f=seam();raw=request(f.ctx,S+1)
        verify(f,raw)
        f.candidates.commit(raw,f.owner._input_transaction.selected_proof)
        old=f.progress.bound;generation=f.progress.generation
        f.clock.value=S+2
        verify(f,raw)
        self.assertIs(f.owner._input_transaction.selected_proof,f.proof)
        self.assertIs(f.progress.bound,old)
        self.assertEqual(f.progress.generation,generation)
        self.assertEqual(f.channels.slot_calls,1)
        self.assertEqual(old.deadline_ns,O+295_000_000)
        with self.assertRaises(ValueError):verify(f,request(f.ctx,S+2,seq=4))
        self.assertIs(f.progress.bound,old)
        f=seam();raw=request(f.ctx,S+1)
        verify(f,raw)
        f.candidates.commit(raw,f.owner._input_transaction.selected_proof)
        f.clock.value=O+295_000_000
        with self.assertRaises(ValueError):verify(f,raw)

    def test_C09_unconditional_production_gate(self):
        # No actor policy fields are read before the unavailable production gate.
        policy=object.__new__(ac.ActorPolicy)
        config=ac.AuthorityConfig(policy,object(),object(),object(),object(),
            500_000_000,16,100_000_000,MODEL,pc_direct_window_v2=mb.PcDirectWindowV2(W))
        with patch.object(ac,'ActorRegistry',side_effect=AssertionError('registry acquired')) as registry:
            with self.assertRaises(ac.ActivationUnavailable):ac.create_authority(config)
            registry.assert_not_called()

def real_clock_once():
    """One bounded wait and one selection; missed availability is retained."""
    origin=time.monotonic_ns()
    doc=boot.load_document(PRODUCT/'competition/deepeye/docs/boot_profiles.json')
    ctx=context(doc);source,domain=object(),object()
    owner=mb.LatestCompletedMailbox(doc)
    owner.activate(encode(ctx),generation=1,slot_origin_ns=origin,source=source,
        clock_domain=domain,bounds=mb.TransferBounds(10_000_000,5_000_000),
        now_ns=time.monotonic_ns(),pc_direct_window_v2=mb.PcDirectWindowV2(W))
    owner.observe(observation(ctx,origin),sample_lower_ns=origin,now_ns=time.monotonic_ns())
    now=time.monotonic_ns()
    proof=mb.Completion(1,source,domain,candidate(ctx,now),1,origin,now,now,origin+1_000_000_000)
    owner.complete(proof,now_ns=time.monotonic_ns())
    slot=origin+210_000_000
    remaining=(slot-time.monotonic_ns())/1_000_000_000
    if remaining>0:time.sleep(remaining)
    actual=time.monotonic_ns()
    selected=owner.consume_pc_direct_v2(actual,grant=mb.SlotGrant(1,0))
    return dict(origin_ns=origin,nominal_slot_ns=slot,window_close_ns=slot+W,
        actual_ns=actual,lateness_ns=actual-slot,selected=selected is not None,
        wait_count=1 if remaining>0 else 0,consume_count=1,
        meaning='single host scheduling observation with upstream fixtures; no provenance/real-time guarantee')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase2-authorized',action='store_true',required=True)
    parser.add_argument('--real-clock-once',action='store_true')
    args=parser.parse_args()
    sys.path.insert(0,str(PRODUCT))
    mb=importlib.import_module('competition.deepeye.integration.candidate_mailbox')
    boot=importlib.import_module('competition.deepeye.integration.boot_profile')
    wire=importlib.import_module('competition.deepeye.integration.wire')
    co=importlib.import_module('competition.deepeye.simulation.authority.candidate_owner')
    ac=importlib.import_module('competition.deepeye.simulation.authority.actor_composition')
    suite=unittest.TestSuite()
    for cls in [CoreControls,SeamControls]:
        suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    observation_result=real_clock_once() if args.real_clock_once else None
    payload=dict(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
        real_clock_observation=observation_result,synthetic_upstream=True,board_access=False,
        G03='not_run',R03='not_run',all29='not_run')
    (OUT/'controls-result.json').write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(payload))
    raise SystemExit(0 if result.wasSuccessful() else 1)
