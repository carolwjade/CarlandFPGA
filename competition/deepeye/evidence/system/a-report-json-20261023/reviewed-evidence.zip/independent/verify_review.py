"""Hash/raw-record review only. Do not import helper, NumPy, or test modules."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent/'g03-report-json-20261023';W=ROOT/'.local/deepeye-implementation-a'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
pins=read(P/'source-pins.json')
for n,v in pins.items():assert pin(ROOT/n)==v,n
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
sh=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert sh=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json');assert transfer['status']=='active' and transfer['director_generation']==2 and transfer['new_director_thread_id']=='01a13d7e-dcf1-7272-a738-a637dd62ff9d'
record=read(P/'result.json');stages=[]
for phase,code in [('red',1),('green',0)]:
 t=read(P/phase/'terminal.json');s=read(P/phase/'started.json');raw=(P/phase/'stderr.txt').read_text(encoding='utf-8')
 assert t==record[phase] and t['exit_code']==code and t['stop_reason'] is None and t['all_processes_terminated'] and t['active_processes_final']==0
 assert len(t['held_members'])==3 and all(v['signaled'] and v['wait_result']==0 for v in t['held_members'])
 for stream in ['stdout','stderr']:assert pin(P/phase/(stream+'.txt'))==t['logs'][stream]
 assert s['hidden'] and s['assigned_before_resume'] and s['readback_limits']=={'job_memory_bytes':1024**3,'process_memory_bytes':512*1024**2,'active_processes':3}
 assert s['budget']['seconds']==30 and s['argv'][-1]==str(W/'competition/deepeye/tests/test_evidence_json.py')
 if phase=='red':
  assert s['environment']['DEEPEYE_REPORT_HELPER']==str(P/'legacy_writer.py') and 'FAILED (failures=10, errors=2)' in raw and 'Object of type bool is not JSON serializable' in raw
 else:
  assert 'DEEPEYE_REPORT_HELPER' not in s['environment'] and 'Ran 4 tests' in raw and raw.rstrip().endswith('OK') and 'skip' not in raw.lower()
 stages.append({'phase':phase,'terminal':t,'argv':s['argv'],'budget':s['budget'],'NumPy_real_fixture_executed_no_skip':phase=='green'})
for n,h in record['protected_files'].items():assert pin(W/n)['sha256']==h,n
extra=[P/'source-pins.json',P/'result.json',ROOT/'docs/competition/deepeye-2026/immutable_scope.md',ROOT/'docs/competition/deepeye-2026/immutable_scope.json',ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json',ROOT/'.agents/skills/fpga-multi-node/SKILL.md',ROOT/'.agents/skills/fpga-multi-node/skill-role.json',ROOT/'.planning/deepeye-resume-20261018/r02-amd-wheel-acquisition-20261021/win_job.py']
for q in extra:pins[q.relative_to(ROOT).as_posix()]=pin(q)
product_keys=[n for n in pins if n.endswith('/tools/evidence_json.py') or n.endswith('/tests/test_evidence_json.py')]
report={'work_id':'A-G03-REPORT-JSON-REVIEW-20261023-v1','job_id':'child-948a0298559141b48085d17d68410c32','agent_id':'/root/g03_hodge_independent_20261023','status':'independent_static_review_no_blocking_findings','formal_acceptance_by_child':False,'source_hashes':{n:pins[n] for n in product_keys},'all_supplied_pins_verified':13,'verified_pin_count':len(pins),'red_green_evidence':stages,'recorded_new_tests':4,'green_skips':0,'old_tests_or_numerics_replayed_by_review':0,'additional_fixture_executed':False,'blocking_findings':[],'assessment':{'numpy_is_optional_no_import':True,'basic_scalar_conversion_only':True,'unsupported_arrays_complex_datetime_rejected':True,'nonfinite_rejected':True,'serialize_and_utf8_encode_before_open':True,'exclusive_creation_preserves_existing_evidence':True,'IO_failure_partial_file_limitation_documented':True},'limitations':['Current source hashes are checked against root post-run source-pins; stage logs do not independently attest the helper/test file hashes from inside each test process.','Four recorded fixtures cover the selected regression, not every NumPy dtype, I/O failure or power-loss condition.','No atomic replacement/fsync guarantee is claimed; actual write failure can leave a partial newly created file.','No old audit is retroactively repaired; no numerical/product physics qualification.'],'scope':{'contract':'DEEPEYE-HUMAN-LOCK-20261014/revision1','requirements_sha256':sh,'H01_H15_preserved':True,'director':transfer['new_director_thread_id'],'generation':2,'G03':'not_run','R03':'not_run','all29':'not_run','physical_accuracy':'unqualified'},'root_retains':'integration, publishing and acceptance'}
save('source-pins.json',pins);save('review.json',report)
print(json.dumps({'status':report['status'],'pins_verified':len(pins),'supplied_pins':13,'recorded_tests':4,'green_skips':0,'all6heldsignaled':True,'additional_execution':False}))
