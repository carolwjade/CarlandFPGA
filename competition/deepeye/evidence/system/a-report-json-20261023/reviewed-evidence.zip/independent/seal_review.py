"""Seal read-only review and verify artifact hashes; no test/helper imports."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
pins=read(D/'source-pins.json');assert all(pin(ROOT/n)==v for n,v in pins.items())
r=read(D/'review.json');assert r['blocking_findings']==[] and r['additional_fixture_executed'] is False and r['old_tests_or_numerics_replayed_by_review']==0
excluded={'lease.private.json','manifest.json','native-completion.json','final-verification.json'}
files={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in excluded and p.suffix!='.pyc'}
save('manifest.json',{'work_id':r['work_id'],'files':files,'private_and_postseal_records_excluded':sorted(excluded)})
assert all(pin(D/n)==v for n,v in read(D/'manifest.json')['files'].items())
save('final-verification.json',{'status':'verified','source_pins_unchanged':len(pins),'manifest':pin(D/'manifest.json'),'manifest_entries':len(files),'reviewed_recorded_tests':4,'test_or_helper_executions_by_review':0,'all6recorded_held_processes_signaled':True,'blocking_findings':0})
print(json.dumps(read(D/'final-verification.json')))
