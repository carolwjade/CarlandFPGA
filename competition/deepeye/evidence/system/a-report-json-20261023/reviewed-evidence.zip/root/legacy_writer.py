"""Frozen baseline of the failing json.dump-before-close pattern."""
import json


def write_new_report(path, value):
    with path.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
