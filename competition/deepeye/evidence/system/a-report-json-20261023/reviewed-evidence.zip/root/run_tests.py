"""One new regression attempt per named phase, under the existing held guard."""
import hashlib
import json
import os
from pathlib import Path
import sys

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
SUPPORT = D.parent / "r02-amd-wheel-acquisition-20261021"
assert hashlib.sha256((SUPPORT / "win_job.py").read_bytes()).hexdigest() == "c997e69b7439776fdaf63cd3dc8235e3448ef26556e69a980b2d9e9315610f59"
sys.path.insert(0, str(SUPPORT))
from win_job import run_bounded

phase = sys.argv[1]
assert phase in ("red", "green")
scratch = D / (phase + "-scratch")
scratch.mkdir()
env = {k: v for k, v in os.environ.items() if k.upper() in
       {"SYSTEMROOT", "WINDIR", "COMSPEC", "SYSTEMDRIVE"}}
env.update(TEMP=str(scratch), TMP=str(scratch),
           DEEPEYE_REPORT_TEST_ROOT=str(scratch),
           OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
if phase == "red":
    env["DEEPEYE_REPORT_HELPER"] = str(D / "legacy_writer.py")
product = ROOT / ".local/deepeye-implementation-a"
argv = [str(ROOT / ".local/deepeye-fdem-validation-20261020/Scripts/python.exe"),
        "-I", "-B", "-X", "utf8",
        str(product / "competition/deepeye/tests/test_evidence_json.py")]
budget = dict(seconds=30, active_processes=3, process_memory_bytes=512*1024**2,
              job_memory_bytes=1024**3, free_reserve_bytes=2*1024**3,
              tree_bytes=10*1024**2, tree_entries=200,
              stdout_bytes=65536, stderr_bytes=65536)
result = run_bounded(argv, env, product, D / phase, budget, [scratch])
print(json.dumps(result, ensure_ascii=False))
assert result["all_processes_terminated"]
assert result["stop_reason"] is None
assert result["exit_code"] == (1 if phase == "red" else 0)
