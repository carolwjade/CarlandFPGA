# Serialize scientific reports before opening a new output

Human authorizes continued background implementation, new-work verification only, H01-H15 unchanged. Root owns only the new tools/evidence_json.py and tests/test_evidence_json.py in the product worktree and this evidence directory. Protected C bytes remain untouched.

The existing candidate audit completed its calculations then failed while writing a NumPy boolean. The original attempt and partial report remain immutable. This increment adds a small standard-library report helper; it never replays that computation.

Design: serialize strict UTF-8 JSON fully in memory before opening the target with exclusive creation. Convert only supported scalar types from an already loaded NumPy module; do not import NumPy, convert arrays, stringify unknown types, accept nonfinite numbers or replace an existing file. Disk write failures may still leave a partial new file: this is not a power-loss atomic writer. No numerical acceptance semantics are changed.

1. Run four new regression fixtures once against a faithful legacy JSON writer (expected RED).
2. Implement the two-function helper and run only those fixtures once (GREEN). The actual scientific venv supplies NumPy, with a hidden private Windows job and 30-second/512-MiB process bound.
3. Independent source/raw evidence review, scoped correction if needed, then publish only owned files and evidence. No old model/solver/board/UI test replay.
