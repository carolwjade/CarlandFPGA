"""One granted hidden S2 scientific stage with stage-only writes and no network."""
import hashlib,json,os,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
stage=Path(sys.argv[1]).resolve();mode=sys.argv[2]
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
save(stage/'hello.json',{'pid':os.getpid(),'mode':mode,'before_scientific_import':True})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('no held science grant')
    time.sleep(.01)
grant=json.loads((stage/'grant.json').read_text(encoding='utf-8'));assert grant['worker']['pid']==os.getpid() and grant['mode']==mode
def audit(event,args):
    if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):raise PermissionError('S2 worker prohibits network/subprocess effects')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).resolve();modes=args[1] if len(args)>1 else None;flags=args[2] if len(args)>2 else 0
        writing=(isinstance(modes,str) and any(c in modes for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
        if writing and not path.is_relative_to(stage):raise PermissionError('S2 writes confined to owned stage')
        if not writing and mode!='actual' and path.suffix=='.npz' and path.is_relative_to(ROOT):raise PermissionError('no old matrix data before conditional actual stage')
sys.addaudithook(audit);sys.path.insert(0,str(D));started=time.monotonic()
def threads():
    import ctypes as ct
    import numpy as np
    import scipy.linalg
    k=ct.WinDLL('kernel32',use_last_error=True);k.GetModuleHandleW.argtypes=[ct.c_wchar_p];k.GetModuleHandleW.restype=ct.c_void_p;rows=[]
    for folder,symbol in [('numpy.libs','scipy_openblas_get_num_threads64_'),('scipy.libs','scipy_openblas_get_num_threads')]:
        paths=list((Path(np.__file__).resolve().parents[1]/folder).glob('*openblas*.dll'));assert len(paths)==1
        handle=k.GetModuleHandleW(str(paths[0]));assert handle
        getter=getattr(ct.CDLL(str(paths[0]),handle=handle),symbol);getter.argtypes=[];getter.restype=ct.c_int
        count=getter();assert count==1
        rows.append({'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),'threads':count})
    return rows
before=None
try:
    before=threads()
    import s2_stages
    assignment=json.loads((D/'assignment.json').read_text(encoding='utf-8'))
    result=getattr(s2_stages,mode)(stage,assignment)
    save(stage/'worker-evidence.json',{'elapsed_seconds':time.monotonic()-started,'BLAS_before':before,'BLAS_after':threads(),'no_new_primary_or_H_integration':True})
    print(json.dumps(result),flush=True)
except BaseException as error:
    save(stage/'failure.json',{'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc(),'elapsed_seconds':time.monotonic()-started,'BLAS_before':before})
    raise
