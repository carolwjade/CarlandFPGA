"""Explicit full-wave electric current dyad, +i omega t, no vendor E calls."""
import math
import numpy as np
MIN_DISTANCE_M=math.inf
def field(points,sources,moments,parameters):
    global MIN_DISTANCE_M
    p=parameters;points=np.asarray(points,dtype=float);sources=np.asarray(sources,dtype=float);moments=np.asarray(moments,dtype=complex)
    if points.ndim!=2 or points.shape[1]!=3 or sources.ndim!=2 or sources.shape[1]!=3 or moments.shape!=sources.shape:raise ValueError('dyad shape')
    if not 0<len(sources)<=512 or not all(np.all(np.isfinite(v)) for v in (points,sources,moments)):raise ValueError('dyad finite source/count')
    omega=2*math.pi*p['frequency_Hz'];zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm']
    if zeta==0:raise ValueError('zero admittivity')
    q=np.sqrt(1j*omega*p['mu_background_Hpm']*zeta)
    if q.real<0:raise ValueError('nonoutgoing branch')
    output=np.empty((len(points),3),dtype=complex);absolute_sum=np.empty((len(points),3))
    for i in range(0,len(points),128):
        delta=points[i:i+128,None,:]-sources[None,:,:];radius=np.linalg.norm(delta,axis=2)
        minimum=float(radius.min());MIN_DISTANCE_M=min(MIN_DISTANCE_M,minimum)
        if minimum<=1e-12:raise ValueError('singular or unresolved dyadic E target/source')
        unit=delta/radius[:,:,None];qr=q*radius
        a=3+3*qr+qr*qr;b=1+qr+qr*qr
        dot=np.sum(unit*moments[None,:,:],axis=2)
        factor=np.exp(-qr)/(4*math.pi*zeta*radius**3)
        contribution=factor[:,:,None]*(a[:,:,None]*unit*dot[:,:,None]-b[:,:,None]*moments[None,:,:])
        output[i:i+128]=np.sum(contribution,axis=1)
        dot_sum=np.sum(abs(unit*moments[None,:,:]),axis=2)
        absolute_sum[i:i+128]=np.sum(abs(factor)[:,:,None]*(abs(a)[:,:,None]*abs(unit)*dot_sum[:,:,None]+abs(b)[:,:,None]*abs(moments)[None,:,:]),axis=1)
    if not np.all(np.isfinite(output)) or not np.all(np.isfinite(absolute_sum)):raise ArithmeticError('nonfinite E dyad')
    return output,absolute_sum
