"""New fixed non-axis curl-E/H control, specified before the E implementation."""
import math
import numpy as np
import s2_electric as e
def point_control(assignment):
    p=assignment['inputs'];c=assignment['fixed_new_point_control']
    source=np.array(c['source_m']);point=np.array(c['observation_m'])
    m=np.array([complex(*v) for v in c['complex_moment_Am_pairs']])
    omega=2*math.pi*p['frequency_Hz'];mu=p['mu_background_Hpm']
    zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm']
    q=np.sqrt(1j*omega*mu*zeta);delta=point-source;r=np.linalg.norm(delta);unit=delta/r
    H=np.exp(-q*r)*(1+q*r)/(4*math.pi*r*r)*np.cross(m,unit)
    target=-1j*omega*mu*H;curls=[];rows=[]
    for fraction in (.001,.0005):
        h=fraction*r;grad=np.empty((3,3),dtype=complex)
        for axis in range(3):
            direction=np.eye(3)[axis]*h
            points=np.array([point+2*direction,point+direction,point-direction,point-2*direction])
            E,_=e.field(points,source[None,:],m[None,:],p)
            grad[axis]=(-E[0]+8*E[1]-8*E[2]+E[3])/(12*h)
        curl=np.array([grad[1,2]-grad[2,1],grad[2,0]-grad[0,2],grad[0,1]-grad[1,0]])
        absolute=float(np.max(abs(curl-target)));relative=absolute/float(np.max(abs(target)))
        curls.append(curl);rows.append({'step_m':float(h),'relative_inf':relative,'absolute_inf':absolute,'curl_E':[[float(v.real),float(v.imag)] for v in curl]})
    pair=float(np.max(abs(curls[1]-curls[0]))/np.max(abs(target)))
    if not all(row['relative_inf']<=1e-5 for row in rows) or pair>1e-5:raise AssertionError('fixed new curl E/H or step-pair gate failed')
    return {'status':'point_control_pass','rows':rows,'step_pair_relative_inf':pair,'fixed_gate':1e-5,'target_minus_iomega_mu_H':[[float(v.real),float(v.imag)] for v in target]}
if __name__=='__main__':
    import json
    from pathlib import Path
    point_control(json.loads((Path(__file__).resolve().parent/'assignment.json').read_text(encoding='utf-8')))
