"""Held single-attempt S2 stages; reused guard without timeout claims or changes."""
import ctypes as ct
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
SUPPORT=D.parent/'r02-amd-wheel-acquisition-20261021'
PY=ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def selected_pins(mode):
    a=read(D/'assignment.json');assert a['owner']=='/root/r02_amd_acquisition_20261021' and a['work_id']=='A-G03-S2-BOUNDARY-CORRECTION-20261021-v1'
    scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
    assert hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==a['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
    assert transfer['status']=='active' and transfer['director_generation']==2 and transfer['new_director_thread_id']==a['director_thread_id']
    for path,key in [('selected_design','design_sha256'),('source_pins','source_pins_sha256'),('predecessor_manifest','predecessor_manifest_sha256')]:assert sha(ROOT/a[path])==a[key]
    design_pins=read(ROOT/a['source_pins'])['files']
    for path,pin in design_pins.items():assert sha(ROOT/path)==pin['sha256'] and (ROOT/path).stat().st_size==pin['bytes']
    files=[D/n for n in ('assignment.json','run_s2.py','test_point.py','s2_electric.py')]
    if mode!='red':files += [D/n for n in ('s2_math.py','s2_stages.py','s2_worker.py')]
    files += [ROOT/a['selected_design'],ROOT/a['source_pins'],PY,SUPPORT/'win_job.py',SUPPORT/'boundary.py']
    pins={path:pin for path,pin in design_pins.items()}
    for p in files:pins[p.relative_to(ROOT).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p)}
    return pins
def memory():
    class MS(ct.Structure):
        _fields_=[('length',ct.c_uint32),('load',ct.c_uint32)]+[(n,ct.c_uint64) for n in ('total_physical','available_physical','total_page_file','available_page_file','total_virtual','available_virtual','extended_virtual')]
    s=MS();s.length=ct.sizeof(s)
    if not ct.windll.kernel32.GlobalMemoryStatusEx(ct.byref(s)):raise OSError('GlobalMemoryStatusEx')
    return {'available_physical_bytes':s.available_physical,'minimum_required_bytes':10*1024**3,'sufficient':s.available_physical>=10*1024**3}
def main():
    mode=sys.argv[1];assert mode in ('red','controls','boundary','actual')
    before=selected_pins(mode);pinfile=D/('red-source-pins.json' if mode=='red' else 'frozen-source-pins.json')
    if not pinfile.exists():save(pinfile,before)
    else:assert read(pinfile)==before
    if mode in ('boundary','actual'):
        required=[('controls-01','controls_pass')]
        if mode=='actual':required.append(('boundary-01','boundary_pass'))
        for folder,expected in required:
            assert read(D/folder/'result.json')['status']==expected
            t=read(D/folder/'terminal.json');assert t['status']=='success' and t['all_processes_terminated']
    if mode=='actual':
        observation=memory();save(D/'actual-memory-preflight.json',observation)
        if not observation['sufficient']:raise RuntimeError('fresh physical-memory preflight failed')
    stage=D/({'red':'author-red-01','controls':'controls-01','boundary':'boundary-01','actual':'run-01'}[mode])
    sys.path.insert(0,str(SUPPORT));from win_job import run_bounded,process_identity
    env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),'PATH':'','TEMP':str(stage),'TMP':str(stage),'TMPDIR':str(stage),'MPLCONFIGDIR':str(stage/'mplconfig'),'MPLBACKEND':'Agg','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',**{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','VECLIB_MAXIMUM_THREADS')}}
    budget={'seconds':90,'active_processes':4,'process_memory_bytes':4*1024**3 if mode=='actual' else 512*1024**2,'job_memory_bytes':5*1024**3 if mode=='actual' else 1024**3,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':128*1024**2,'tree_entries':2048,'free_reserve_bytes':512*1024**2,'components':[{'path':str(stage),'bytes':128*1024**2,'entries':2048}]}
    granted=False
    def tick(job,pids):
        nonlocal granted
        if mode!='red' and (stage/'hello.json').exists() and not granted:
            h=read(stage/'hello.json');assert h['pid'] in pids and h['mode']==mode
            save(stage/'grant.pending.json',{'worker':process_identity(h['pid'],job),'mode':mode,'source_pins':before})
            os.replace(stage/'grant.pending.json',stage/'grant.json');granted=True
    if mode=='red':
        args=[str(PY),'-I','-B','-X','utf8','-c',"import sys,json,pathlib; sys.path.insert(0,sys.argv[1]); import test_point; test_point.point_control(json.loads((pathlib.Path(sys.argv[1])/'assignment.json').read_text(encoding='utf-8')))",str(D)]
    else:args=[str(PY),'-I','-B','-X','utf8',str(D/'s2_worker.py'),str(stage),mode]
    result=run_bounded(args,env,D,stage,budget,[D],on_tick=tick)
    after=selected_pins(mode);save(stage/'input-readback.json',{'unchanged':before==after,'before':before,'after':after})
    assert before==after and result['all_processes_terminated']
    if mode=='red':
        assert result['exit_code']==1 and 'NotImplementedError: S2 dyadic E not implemented' in (stage/'stderr.txt').read_text(encoding='utf-8')
        save(stage/'author-red.json',{'status':'new_point_curl_control_RED_missing_dyadic_E','original_exit_code':1,'all_processes_terminated':True,'old_RED_or_test_repeated':False})
    print(json.dumps({k:result.get(k) for k in ('status','exit_code','seconds','stop_reason','all_processes_terminated','held_members')}),flush=True)
    raise SystemExit(0 if mode=='red' else (result['exit_code'] if result['exit_code'] is not None else 125))
if __name__=='__main__':main()
