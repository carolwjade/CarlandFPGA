"""S2-only fixture loading, contour/edge integration and diagnostic summation gates."""
import hashlib,json,math
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss
import s2_electric as e
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
S1=D.parent/'g03-s1-cache-path-continuation-20261021';L5=D.parent/'g03-l5-propagation-z-refinement-20261021'
EPS=np.finfo(float).eps
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def save(path,value):
    with path.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
def array(path,value):
    with path.open('xb') as f:np.save(f,value,allow_pickle=False)
def pairs(value):return [[float(complex(v).real),float(complex(v).imag)] for v in np.asarray(value).ravel()]
def load_old(path):
    a=read(D/'assignment.json');pin=read(ROOT/a['source_pins'])['files'][path.relative_to(ROOT).as_posix()]
    if hashlib.sha256(path.read_bytes()).hexdigest()!=pin['sha256'] or path.stat().st_size!=pin['bytes']:raise ValueError('old input hash mismatch')
    value=np.load(path,allow_pickle=False)
    if not np.all(np.isfinite(value)):raise ValueError('nonfinite frozen array')
    return value
def old_data():
    starts=load_old(L5/'controls-01/edge_starts_m.npy');ends=load_old(L5/'controls-01/edge_ends_m.npy')
    I=load_old(S1/'controls-01/interior_indices.npy');B=load_old(S1/'controls-01/boundary_indices.npy')
    if starts.shape!=(63250,3) or ends.shape!=starts.shape or I.shape!=(54418,) or B.shape!=(8832,):raise ValueError('frozen shape')
    for name,current in [('interior_indices',I),('boundary_indices',B)]:
        if not np.array_equal(current,load_old(L5/f'controls-01/{name}.npy')):raise ValueError('ordered S1/L5 partition differs')
    if not np.array_equal(np.sort(np.r_[I,B]),np.arange(63250)):raise ValueError('partition not disjoint complement')
    delta=ends-starts;axes=np.argmax(abs(delta),axis=1);lengths=np.linalg.norm(delta,axis=1)
    if np.any(lengths<=0) or not np.all(np.sum(delta!=0,axis=1)==1) or not np.all(delta[np.arange(len(delta)),axes]>0):raise ValueError('nonpositive/nonaxis edge geometry')
    trace=load_old(S1/'controls-01/receiver_trace_m.npy')
    if trace.shape!=(2,63250) or not np.isrealobj(trace):raise ValueError('receiver trace shape/dtype')
    moments=[]
    for label,count in [('low',64),('high',512)]:
        source=load_old(S1/f'oracle-01/{label}_volume_points_m.npy');moment=load_old(S1/f'oracle-01/{label}_equivalent_current_moments_Am.npy')
        if source.shape!=(count,3) or moment.shape!=source.shape or not np.iscomplexobj(moment):raise ValueError('saved moment shape/dtype')
        moments.append((source,moment))
    H=load_old(S1/'oracle-01/Born_derivative_V.npy')
    if H.shape!=(2,2):raise ValueError('saved H voltage shape')
    return starts,ends,axes,lengths,I,B,trace,moments,H
def sum_bound(scale):return 128*EPS*np.asarray(scale)
def screen(low,high,low_scale,high_scale,tolerance):
    low=np.asarray(low);high=np.asarray(high);low_scale=np.asarray(low_scale);high_scale=np.asarray(high_scale)
    bounds_low=sum_bound(low_scale);bounds_high=sum_bound(high_scale)
    stable=(abs(low)>bounds_low)&(abs(high)>bounds_high)&np.isfinite(low)&np.isfinite(high)
    relative=[float(abs(hi-lo)/abs(hi)) if ok else None for lo,hi,ok in zip(low.ravel(),high.ravel(),stable.ravel())]
    return {'passed':bool(np.all(stable) and all(v is not None and v<=tolerance for v in relative)),
        'relative':relative,'absolute_difference':abs(high-low).ravel().tolist(),'difference':pairs(high-low),
        'low_magnitude':abs(low).ravel().tolist(),'high_magnitude':abs(high).ravel().tolist(),
        'low_roundoff_sum_threshold':np.broadcast_to(bounds_low,low.shape).ravel().tolist(),'high_roundoff_sum_threshold':np.broadcast_to(bounds_high,high.shape).ravel().tolist(),
        'tolerance':tolerance,'note':'128eps times explicit absolute summation scale is a denominator-stability diagnostic, not a global physical error bound.'}
def circle_points(center,radius,normal,n):
    normal=np.asarray(normal,dtype=float);normal=normal/np.linalg.norm(normal)
    u=np.array([1.,0.,0.])-normal*normal[0];u=u/np.linalg.norm(u);v=np.cross(normal,u)
    theta=(np.arange(n)+.5)*2*math.pi/n
    x=np.asarray(center)+radius*(np.cos(theta)[:,None]*u+np.sin(theta)[:,None]*v)
    dl=radius*(-np.sin(theta)[:,None]*u+np.cos(theta)[:,None]*v)*(2*math.pi/n)
    return x,dl
def contour(center,radius,normal,n,sources,moments,p):
    x,dl=circle_points(center,radius,normal,n)
    E,bound=e.field(x,sources,moments,p)
    value=p['turns']*np.sum(E*dl);scale=p['turns']*np.sum(bound*abs(dl))
    return value,float(scale),x,dl,E
def edge_average(starts,ends,axes,sources,moments,p,order):
    q,w=leggauss(order)
    x=(starts[:,None,:]+ends[:,None,:])/2+(ends[:,None,:]-starts[:,None,:])*q[None,:,None]/2
    E,bound=e.field(x.reshape(-1,3),sources,moments,p)
    E=E.reshape(len(starts),order,3);bound=bound.reshape(len(starts),order,3)
    component=np.take_along_axis(E,axes[:,None,None],axis=2)[:,:,0]
    absolute=np.take_along_axis(bound,axes[:,None,None],axis=2)[:,:,0]
    return component@(w/2),absolute@(w/2)
def closure(starts,ends,lengths,trace):
    a=read(L5/'assignment.json');x=np.array(a['level']['x_nodes_m']);z=np.array(a['z_nodes_m'])
    shapes=[(24,25,35),(25,24,35),(25,25,34)];nodes_shape=(25,25,35)
    XYZ=np.stack(np.meshgrid(x,x,z,indexing='ij'),axis=-1).reshape(-1,3,order='F')
    tails=[];heads=[]
    for axis,shape in enumerate(shapes):
        sub=list(np.unravel_index(np.arange(math.prod(shape)),shape,order='F'))
        tails.append(np.ravel_multi_index(tuple(sub),nodes_shape,order='F'))
        sub[axis]=sub[axis]+1;heads.append(np.ravel_multi_index(tuple(sub),nodes_shape,order='F'))
    tail=np.concatenate(tails);head=np.concatenate(heads)
    if np.max(abs(XYZ[tail]-starts))>128*EPS or np.max(abs(XYZ[head]-ends))>128*EPS:raise ValueError('edge/node ordering geometry mismatch')
    phi=XYZ[:,0]*XYZ[:,1]+.4*XYZ[:,1]*XYZ[:,2]+.2*XYZ[:,2]*XYZ[:,0]+XYZ.prod(axis=1)+.3*XYZ[:,0]**2
    gradient=(phi[head]-phi[tail])/lengths
    incidence=np.zeros((2,len(XYZ)));rows=[]
    for r in range(2):
        weights=trace[r]/lengths
        np.add.at(incidence[r],head,weights);np.add.at(incidence[r],tail,-weights)
        scale=float(np.sum(abs(weights)));observed=float(np.max(abs(incidence[r])));value=trace[r]@gradient
        sanity_scale=float(np.sum(abs(trace[r]*gradient)))
        passed=observed<=1e-10*scale and abs(value)<=max(1e-10*scale*float(np.max(abs(phi))),128*EPS*sanity_scale)
        rows.append({'passed':bool(passed),'incidence_inf':observed,'incidence_sum_scale':scale,'relative_incidence':observed/scale,'gate_relative':1e-10,'mixed_phi_circulation_V':float(value),'mixed_phi_sum_scale_V':sanity_scale})
    return rows,incidence
