# S2 executed: controls and boundary pairs passed; corrected response still fails 1%

The selected S2 experiment is complete. Its physical comparison screen failed; no retry, extra grid, ordering, quadrature level, tolerance or dependency change followed. The original two failed S1 native jobs and their prior controls/oracles/results remain unchanged. This new job did not rerun old primary/H integration, old C/A assembly, the original contrast RHS solve, ROCm, board or R03 tests.

## New E implementation and controls

The new explicit electric-current dyad uses `exp(+i omega t)`, full complex `zeta=sigma+i omega epsilon`, and the selected `1/zeta` denominator. It does not call vendor E/current-density code. Source/target evaluation is chunked to 128 targets and at most 512 saved volume moments. The saved moments already include source strength and volume; no new primary or H-flux oracle was generated.

The genuinely new author RED invoked the fixed non-axis point curl control before the E implementation existed, and failed with `NotImplementedError: S2 dyadic E not implemented`. Its source stub, input pins, original failed/exit1 terminal and three signaled held handles are preserved. The new implementation then passed:

* Gradient incidence closure, checked before Born E evaluation: relative rows 7.4564e-17 and 1.0149e-16 against 1e-10; mixed-coordinate potential circulation 5.4210e-20 and -3.2526e-19 V.
* Five-point centered curl E against independently expressed `-i omega mu H` at the selected non-axis point: relative infinity errors 5.6247e-9 and 2.6263e-10 for steps 0.001r and 0.0005r; step-pair change 5.3658e-9, all below the fixed 1e-5 gate. Absolute differences and complex vectors are retained.
* New singular-input rejection and actual reversed receiver E-contour orientation. The diagnostic minimum distance **including that expected singular negative control is zero**; it is not a minimum distance claim about successful integrations.
* E-contour versus the already saved H-flux derivative: high-level relative differences 1.4835e-11 / 3.6635e-12, with fixed low/high E-contour pair 3.4065e-5 / 5.5183e-8; all below 0.001. No H integration was rerun.

Near-cancellation checks use the explicit `128*float64_eps*absolute_sum_scale` threshold, retain both voltage magnitudes and absolute differences, and insert no denominator floor. This is a local denominator-stability diagnostic, not a global field-error certificate.

## Receiver functional diagnosis

On only the saved trace's nonzero support, new Born E edge averages used the fixed Gauss 8/16 pair. Their receiver-voltage pair changes were 2.4145e-11 / 5.9894e-12. The saved trace applied to the saved S1 field reproduced the saved S1 voltages exactly in this readback.

For the smooth Born reference field, the high-order compatible-trace voltage minus direct E-contour voltage was:

| Rx | Complex functional bias V | Absolute V | Relative to direct E-contour |
|---|---|---:|---:|
| 1 | 1.220789337820853e-13 + i 5.42630848282415e-13 | 5.561937644212348e-13 | 0.3348982879% |
| 2 | -3.0139495485216132e-15 - i 1.3393752385205538e-14 | 1.3728674183519423e-14 | 0.2075246226% |

This measures the functional's bias for this smooth reference field, not an isolated error component of the actual solved field.

## Boundary and one correction solve

All 8,832 tangential boundary edges were sampled as Born E edge averages. The g8/g16 relative infinity difference was 3.7790023e-13; low/high saved-moment difference at g16 was 9.3115753e-9, below the unchanged 0.001 gate. The fine boundary infinity norm was 1.9040859728318847e-6 V/m. Successful boundary integration had minimum evaluated source/target distance 0.3264892865 m and geometric separation lower bound 0.325 m, without a negative-control point in that stage.

Only after those gates passed, the worker loaded the pinned saved full A and AII, verified the exact sparse ordered `A[I,I] == AII` partition, and formed one new `-AIB*gB` RHS (AIB 54,418 by 8,832 with 24,880 nonzeros). The full A was released before one COLAMD factorization and one solve. No original contrast RHS, wire residual or new total-field assembly was added.

New correction backward eta was **1.3842626285787516e-15**, below the unchanged 2.842170943040401e-14 gate. The corrected full-field trace and `V0+deltaV_B` agreed within the recorded floating summation threshold.

| Rx | Measured boundary delta V | Corrected derivative V | Corrected minus saved H V | Absolute discrepancy V | Relative discrepancy |
|---|---|---|---|---:|---:|
| 1 | -1.1199420620569927e-13 - i 4.967493960270086e-13 | 3.184127238917305e-11 + i 1.4148661280049572e-10 | -4.620888716112146e-12 - i 2.0539775013312225e-11 | 2.1053146323630057e-11 | **12.6766301761%** |
| 2 | -3.884146785440858e-13 - i 1.7185300251044788e-12 | -1.517676686173278e-12 - i 6.7357239597029475e-12 | -6.343328051354404e-14 - i 2.8209947642593405e-13 | 2.891433825569869e-13 | **4.3707331497%** |

Both fail the fixed **1%** diagnostic. Original S1 relative errors 12.3700173947% / 22.2620609458% remain preserved; S2 improves Rx2 and slightly worsens Rx1. The correction measures the effect of this chosen discrete boundary replacement. It is not a unique decomposition of mesh, source, receiver, finite-domain or model error, and does not become a transparent boundary for generic finite-strength heterogeneity.

## Process and acceptance evidence

Measured elapsed values: new RED 0.187 s, controls 2.343 s, boundary 32.015 s, correction 57.438 s. These are sampled-guard observations, not hard wall-time guarantees. Fresh free physical memory was 13,332,934,656 B against 10,737,418,240 B. Correction peak job memory was 3,347,566,592 B. The original correction process intentionally failed/exit2 after saving its numerical result; this is a comparison-screen failure, not a hidden rerun. All four process trees have all 12 original held handles signaled. All before/after input pins remain unchanged.

BLAS was bound to one thread and checked before each scientific stage and after the successful controls/boundary stages. The comparison-failed correction has the preserved before-check in its failure evidence; no extra after-failure runtime probe was run.

Physical accuracy, noise/calibration qualification, finite-strength heterogeneous validation, G03 and all29 remain open (`unqualified` / `not_run` as recorded). H01–H15 and requirements SHA `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` remain unchanged. There were no product, dependency, UI, GPU, board, service or network changes.

The manifest binds raw controls, boundary averages/pairs, new RHS/correction vectors, original failure/terminal evidence, source pins and this report. Native completion is recorded as failed with the actual `result=null` API semantics; the exact supplied text and actual response are saved separately.
