"""New S2 E/receiver diagnosis, Born-boundary averages, one conditional correction."""
import gc,math,warnings
import numpy as np
import s2_math as m
import s2_electric as e
def separated_edges(starts,ends,p):
    low=np.array(p['contrast_box_min_m']);high=np.array(p['contrast_box_max_m'])
    gap=np.maximum(np.maximum(low-np.maximum(starts,ends),np.minimum(starts,ends)-high),0.)
    distance=np.linalg.norm(gap,axis=1)
    if np.any(distance<=1e-12):raise ValueError('requested edge intersects contrast closure')
    return float(np.min(distance))
def controls(stage,a):
    p=a['inputs'];starts,ends,axes,lengths,I,B,t,moments,H=m.old_data()
    rows,incidence=m.closure(starts,ends,lengths,t)
    m.save(stage/'closure-result.json',{'rows':rows});m.array(stage/'gradient_incidence.npy',incidence)
    if not all(r['passed'] for r in rows):raise AssertionError('new gradient closure failed')
    from test_point import point_control
    point=point_control(a);m.save(stage/'point-control.json',point)
    # New singular-input rejection for this E implementation.
    rejected=False
    try:e.field(moments[1][0][:1],moments[1][0],moments[1][1],p)
    except ValueError:rejected=True
    if not rejected:raise AssertionError('dyadic E singular target not rejected')
    voltages=[];scales=[];reversals=[];rx_separation=[]
    normal=np.array(p['Rx_normal_unnormalized'],dtype=float);normal/=np.linalg.norm(normal)
    u=np.array([1.,0.,0.])-normal*normal[0];u/=np.linalg.norm(u);v=np.cross(normal,u)
    extent=p['Rx_radius_m']*np.sqrt(u*u+v*v)
    for center in p['Rx_centers_m']:
        rx_separation.append(separated_edges((np.array(center)-extent)[None,:],(np.array(center)+extent)[None,:],p))
    for label,n,pair in [('low',128,moments[0]),('high',256,moments[1])]:
        values=[];absolute_scales=[]
        for r,center in enumerate(p['Rx_centers_m']):
            value,scale,x,dl,E=m.contour(center,p['Rx_radius_m'],normal,n,*pair,p)
            values.append(value);absolute_scales.append(scale)
            for name,array in {'contour_points_m':x,'contour_dl_m':dl,'Born_E_Vpm':E}.items():m.array(stage/f'{label}_rx{r+1}_{name}.npy',array)
            if label=='high':
                reversed_value,reversed_scale,_,_,_=m.contour(center,p['Rx_radius_m'],-normal,n,*pair,p)
                difference=abs(reversed_value+value);bound=float(m.sum_bound(scale+reversed_scale))
                reversals.append({'passed':bool(difference<=bound),'reversed_V':m.pairs([reversed_value]),'sign_absolute_error_V':float(difference),'roundoff_sum_threshold_V':bound})
        voltages.append(values);scales.append(absolute_scales)
    VE=np.array(voltages);scales=np.array(scales)
    screen={'E_pair':m.screen(VE[0],VE[1],scales[0],scales[1],.001),
        'low_E_vs_saved_H':m.screen(VE[0],H[0],scales[0],scales[0],.001),
        'high_E_vs_saved_H':m.screen(VE[1],H[1],scales[1],scales[1],.001)}
    m.array(stage/'E_line_V.npy',VE);m.array(stage/'E_line_absolute_sum_scale_V.npy',scales)
    m.save(stage/'E-line-control.json',{'screens':screen,'reversed_winding':reversals,'E_line_V':m.pairs(VE),'saved_H_V':m.pairs(H),'singular_target_rejected':True})
    if not all(s['passed'] for s in screen.values()) or not all(r['passed'] for r in reversals):raise AssertionError('new E-line/saved-H or reversal screen failed')
    support=np.flatnonzero(np.any(t!=0,axis=0));separation=separated_edges(starts[support],ends[support],p)
    reference=[];ref_scales=[]
    for order in (8,16):
        avg,scale=m.edge_average(starts[support],ends[support],axes[support],*moments[1],p,order)
        values=t[:,support]@avg;sums=np.sum(abs(t[:,support])*scale[None,:],axis=1)
        reference.append(values);ref_scales.append(sums)
        m.array(stage/f'Born_E_receiver_edge_average_g{order}_Vpm.npy',avg)
        m.array(stage/f'Born_E_receiver_edge_absolute_sum_g{order}_Vpm.npy',scale)
    reference=np.array(reference);ref_scales=np.array(ref_scales)
    edge_screen=m.screen(reference[0],reference[1],ref_scales[0],ref_scales[1],.001)
    field=m.load_old(m.S1/'run-01/full_derivative_Vpm.npy');V0=m.load_old(m.S1/'run-01/derivative_voltage_V.npy')
    if field.shape!=(63250,) or V0.shape!=(2,):raise ValueError('frozen S1 field/voltage shape')
    reproduced=t@field;readback_bound=m.sum_bound(np.sum(abs(t*field[None,:]),axis=1));readback_abs=abs(reproduced-V0)
    if np.any(readback_abs>readback_bound):raise AssertionError('saved S1 trace/field/voltage readback differs beyond roundoff')
    difference=reference[1]-VE[1]
    stable=np.all(abs(reference[1])>m.sum_bound(ref_scales[1])) and np.all(abs(VE[1])>m.sum_bound(scales[1]))
    for name,array in {'receiver_support_indices':support,'receiver_reference_trace_V':reference,'functional_bias_V':difference,'S1_V0_reproduced_V':reproduced}.items():m.array(stage/(name+'.npy'),array)
    result={'status':'controls_pass' if edge_screen['passed'] and stable else 'controls_screen_failed','closure':rows,'point_control':point,'new_E_singular_rejected':True,'E_line_screens':screen,
        'receiver_edge_order_screen':edge_screen,'receiver_trace_reference_V':m.pairs(reference),'functional_bias_V':m.pairs(difference),'functional_bias_absolute_V':abs(difference).tolist(),
        'functional_bias_relative':[float(abs(difference[r])/abs(VE[1,r])) if stable else None for r in range(2)],'S1_trace_readback_absolute_V':readback_abs.tolist(),'S1_trace_readback_roundoff_bound_V':readback_bound.tolist(),
        'Rx_contrast_separation_lower_m':rx_separation,'receiver_support_separation_lower_m':separation,'minimum_evaluated_point_source_distance_m':e.MIN_DISTANCE_M,
        'gradient_closure_before_Born_E':True,'new_primary_or_H_integrations':0,'matrix_loads':0,'C_or_A_assemblies':0,'old_RHS_solves':0}
    # The deliberate singular point has min distance zero; it is retained separately.
    result['minimum_evaluated_point_source_distance_m_including_expected_negative_control']=result.pop('minimum_evaluated_point_source_distance_m')
    m.save(stage/'result.json',result)
    if result['status']!='controls_pass':raise SystemExit(2)
    return result
def boundary(stage,a):
    p=a['inputs'];starts,ends,axes,lengths,I,B,t,moments,H=m.old_data()
    separation=separated_edges(starts[B],ends[B],p)
    values={};scales={}
    for label,pair,order in [('high_g8',moments[1],8),('high_g16',moments[1],16),('low_g16',moments[0],16)]:
        avg,scale=m.edge_average(starts[B],ends[B],axes[B],*pair,p,order)
        values[label]=avg;scales[label]=scale
        m.array(stage/f'gB_{label}_Vpm.npy',avg);m.array(stage/f'gB_absolute_sum_{label}_Vpm.npy',scale)
    fine=values['high_g16'];den=float(np.max(abs(fine)));roundoff=float(m.sum_bound(np.max(scales['high_g16'])))
    pairrows={}
    for name,coarse in [('edge_order',values['high_g8']),('source_moments',values['low_g16'])]:
        absolute=float(np.max(abs(fine-coarse)));relative=absolute/den if den>roundoff else None
        pairrows[name]={'max_absolute_difference_Vpm':absolute,'fine_inf_Vpm':den,'coarse_inf_Vpm':float(np.max(abs(coarse))),'roundoff_sum_threshold_Vpm':roundoff,'relative_inf':relative,'passed':relative is not None and relative<=.001,'gate':.001}
    result={'status':'boundary_pass' if all(r['passed'] for r in pairrows.values()) else 'boundary_screen_failed','boundary_edges':len(B),'pair_screens':pairrows,
        'boundary_contrast_separation_lower_m':separation,'minimum_evaluated_point_source_distance_m':e.MIN_DISTANCE_M,'new_primary_or_H_integrations':0,'matrix_loads':0,'C_or_A_assemblies':0,'RHS_constructed':False}
    m.save(stage/'result.json',result)
    if result['status']!='boundary_pass':raise SystemExit(2)
    return result
def actual(stage,a):
    from scipy import sparse
    from scipy.sparse.linalg import splu
    starts,ends,axes,lengths,I,B,t,moments,H=m.old_data()
    g=np.load(m.D/'boundary-01/gB_high_g16_Vpm.npy',allow_pickle=False)
    if g.shape!=(8832,) or not np.all(np.isfinite(g)):raise ValueError('new boundary shape/finite')
    def load_matrix(name,kind):
        path=m.L5/f'run-01/{name}.npz';pin=m.read(m.ROOT/a['source_pins'])['files'][path.relative_to(m.ROOT).as_posix()]
        import hashlib
        if hashlib.sha256(path.read_bytes()).hexdigest()!=pin['sha256']:raise ValueError('saved matrix pin')
        with np.load(path,allow_pickle=False) as z:matrix=kind((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
        if not np.all(np.isfinite(matrix.data)):raise ValueError('nonfinite matrix')
        return matrix
    A=load_matrix('A-csr',sparse.csr_matrix);AII=load_matrix('AII-csc',sparse.csc_matrix)
    partition=A[I,:][:,I].tocsc()
    if partition.shape!=AII.shape or not all(np.array_equal(getattr(partition,n),getattr(AII,n)) for n in ('indptr','indices','data')):raise ValueError('saved A_II exact ordered partition mismatch')
    AIB=A[I,:][:,B].tocsr();rhs=-(AIB@g)
    if rhs.shape!=(54418,) or not np.all(np.isfinite(rhs)) or not np.any(rhs!=0):raise ValueError('new boundary RHS invalid')
    for name,array in {'new_boundary_correction_RHS':rhs,'selected_gB_Vpm':g}.items():m.array(stage/(name+'.npy'),array)
    m.save(stage/'pre-factorization.json',{'status':'new_minus_AIB_gB_persisted','saved_A_partition_exact':True,'AIB_shape':AIB.shape,'AIB_nnz':int(AIB.nnz),'AII_shape':AII.shape,'AII_nnz':int(AII.nnz),'new_RHS_columns':1,'factorization_started':False,'factorization_ordering':'COLAMD','C_constructions':0,'A_assemblies':0,'old_contrast_RHS_recomputed':False})
    del A,AIB,partition;gc.collect()
    with warnings.catch_warnings():
        warnings.simplefilter('error');lu=splu(AII,permc_spec='COLAMD');x=lu.solve(rhs)
    del lu;gc.collect()
    residual=AII@x-rhs;normA=float(np.max(np.asarray(abs(AII).sum(axis=1)).ravel()))
    eta=float(np.max(abs(residual))/(normA*float(np.max(abs(x)))+float(np.max(abs(rhs)))))
    field=m.load_old(m.S1/'run-01/full_derivative_Vpm.npy');V0=m.load_old(m.S1/'run-01/derivative_voltage_V.npy')
    correction=np.empty_like(field);correction[I]=x;correction[B]=g;corrected=field+correction
    deltaV=t[:,I]@x+t[:,B]@g;Vcorr=V0+deltaV;from_field=t@corrected
    roundoff=m.sum_bound(np.sum(abs(t*corrected[None,:]),axis=1)+abs(V0)+abs(deltaV))
    if np.any(abs(from_field-Vcorr)>roundoff):raise ArithmeticError('corrected voltage identity beyond roundoff')
    comparison=m.screen(Vcorr,H[1],np.sum(abs(t*corrected[None,:]),axis=1),abs(H[1]),.01)
    R0=V0-H[1];Rcorr=Vcorr-H[1]
    for name,array in {'interior_correction_Vpm':x,'full_correction_Vpm':correction,'corrected_derivative_Vpm':corrected,'correction_residual':residual,'V0_V':V0,'boundary_delta_V':deltaV,'V_corrected_V':Vcorr,'V_corrected_from_field_V':from_field,'R0_V':R0,'R_corrected_V':Rcorr}.items():m.array(stage/(name+'.npy'),array)
    passed=math.isfinite(eta) and eta<=128*m.EPS and comparison['passed']
    result={'status':'one_correction_solve_screens_pass' if passed else 'one_correction_solve_screen_failed','new_RHS_columns':1,'factorizations':1,'C_constructions':0,'A_assemblies':0,'old_contrast_RHS_recomputed':False,
        'backward_eta':eta,'backward_eta_gate':128*m.EPS,'V0_V':m.pairs(V0),'delta_boundary_V':m.pairs(deltaV),'V_corrected_V':m.pairs(Vcorr),'saved_H_V':m.pairs(H[1]),'R0_V':m.pairs(R0),'R_corrected_V':m.pairs(Rcorr),
        'comparison':comparison,'corrected_voltage_identity_absolute_V':abs(from_field-Vcorr).tolist(),'corrected_voltage_identity_roundoff_V':roundoff.tolist(),
        'physical_accuracy':'unqualified','noise_gate':'unqualified_missing_sourced_budget','finite_tau':'not_run','G03':'not_run','all29_formal':'not_run'}
    m.save(stage/'result.json',result)
    if not passed:raise SystemExit(2)
    return result
