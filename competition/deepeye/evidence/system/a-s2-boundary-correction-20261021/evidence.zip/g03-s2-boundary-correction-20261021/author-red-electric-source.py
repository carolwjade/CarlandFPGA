"""Author RED stub for the newly selected S2 electric dyad."""
def field(points, sources, moments, parameters):
    raise NotImplementedError('S2 dyadic E not implemented')
