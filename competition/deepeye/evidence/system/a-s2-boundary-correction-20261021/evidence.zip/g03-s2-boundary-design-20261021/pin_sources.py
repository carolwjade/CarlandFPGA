"""Byte-pin only read-only S2 design inputs; no numerical array loads or solver."""
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
BASE = Path('.planning/deepeye-resume-20261018')
S1 = BASE / 'g03-s1-cache-path-continuation-20261021'
L5 = BASE / 'g03-l5-propagation-z-refinement-20261021'


def pin(rel):
    raw = (ROOT / rel).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


assignment = json.loads((D / 'assignment.json').read_text(encoding='utf-8'))
scope = json.loads((ROOT / 'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
canonical = json.dumps(scope['requirements'], ensure_ascii=False, sort_keys=True,
                       separators=(',', ':')).encode('utf-8')
scope_hash = hashlib.sha256(canonical).hexdigest()
assert scope_hash == assignment['requirements_sha256'] == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
assert [r['id'] for r in scope['requirements']] == [f'H{i:02d}' for i in range(1, 16)]
transfer = json.loads((ROOT / '.planning/deepeye-desktop-handoff-20261015/transfer.json').read_text(encoding='utf-8'))
assert transfer['status'] == 'active' and transfer['director_generation'] == 2
assert transfer['new_director_thread_id'] == assignment['director_thread_id']
assert transfer['requirements_sha256'] == scope_hash
assert pin(S1 / 'manifest.json')['sha256'] == assignment['frozen_S1']['manifest_sha256']
s1_manifest = json.loads((ROOT / S1 / 'manifest.json').read_text(encoding='utf-8'))
assert s1_manifest['file_count'] == assignment['frozen_S1']['manifest_files'] == 94
l5_manifest = json.loads((ROOT / L5 / 'public-manifest.json').read_text(encoding='utf-8'))
s1_assignment = json.loads((ROOT / S1 / 'assignment.json').read_text(encoding='utf-8'))
assert pin(L5 / 'public-manifest.json')['sha256'] == s1_assignment['background_manifest_sha256']

names = [
    Path('.agents/skills/fpga-multi-node/SKILL.md'),
    Path('.agents/skills/fpga-multi-node/skill-role.json'),
    Path('docs/competition/deepeye-2026/immutable_scope.md'),
    Path('docs/competition/deepeye-2026/immutable_scope.json'),
    Path('.planning/deepeye-desktop-handoff-20261015/transfer.json'),
    D.relative_to(ROOT) / 'assignment.json',
    BASE / 'g03-s1-main-review-20261021/review.json',
    BASE / 'g03-secondary-field-design-20261021/design.md',
    S1 / 'manifest.json', S1 / 'assignment.json', S1 / 'report.md', S1 / 'result.json',
    S1 / 's1_geometry.py', S1 / 's1_model.py', S1 / 's1_oracle.py', S1 / 's1_worker.py',
    S1 / 'controls-01/result.json', S1 / 'oracle-01/result.json', S1 / 'run-01/result.json',
    L5 / 'public-manifest.json', L5 / 'assignment.json', L5 / 'grid_worker.py',
]
s1_arrays = [
    'controls-01/boundary_indices.npy', 'controls-01/interior_indices.npy',
    'controls-01/receiver_trace_m.npy',
    'oracle-01/low_volume_points_m.npy', 'oracle-01/low_equivalent_current_moments_Am.npy',
    'oracle-01/high_volume_points_m.npy', 'oracle-01/high_equivalent_current_moments_Am.npy',
    'oracle-01/Born_derivative_V.npy',
    'run-01/full_derivative_Vpm.npy', 'run-01/new_derivative_RHS.npy',
    'run-01/derivative_voltage_V.npy',
]
l5_arrays = [
    'controls-01/edge_starts_m.npy', 'controls-01/edge_ends_m.npy',
    'controls-01/boundary_indices.npy', 'controls-01/interior_indices.npy',
    'run-01/A-csr.npz', 'run-01/AII-csc.npz',
]
for name in s1_arrays:
    assert pin(S1 / name) == s1_manifest['files'][name], name
    names.append(S1 / name)
for name in l5_arrays:
    assert pin(L5 / name) == l5_manifest['files'][name], name
    names.append(L5 / name)
out = {'work_id': assignment['work_id'], 'requirements_sha256': scope_hash,
       'S1_manifest_sha256': pin(S1 / 'manifest.json')['sha256'],
       'L5_manifest_sha256': pin(L5 / 'public-manifest.json')['sha256'],
       'arrays_loaded_numerically': False,
       'files': {p.as_posix(): pin(p) for p in names}}
with (D / 'source-pins.json').open('x', encoding='utf-8') as stream:
    json.dump(out, stream, indent=2, ensure_ascii=False)
    stream.write('\n')
