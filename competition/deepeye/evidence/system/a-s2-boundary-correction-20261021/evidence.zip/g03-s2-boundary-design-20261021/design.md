# S2: receiver functional first, then one Born boundary correction

Work `A-G03-S2-BOUNDARY-DESIGN-20261021-v1`. This is an independent **static design** for the next separately assigned experiment. No Green function, array arithmetic, numerical test, solver, product edit, service, UI, network, or board operation was executed here. The active Desktop director is generation 2. `DEEPEYE-HUMAN-LOCK-20261014/revision1`, H01–H15 and canonical requirements SHA-256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` remain fixed. G03, H12, full R03 and all 29 product cards remain open.

## Decision and evidence boundary

The sealed S1 continuation completed **one** nonzero derivative solve, with backward residual `2.228706729227798e-18`, but failed its unchanged 1% complex-voltage comparison: Rx1 `0.12370017394714687`, Rx2 `0.22262060945800732`. Its independent H-flux Born oracle and two-level controls passed. The original exit 2, failed native terminal and nine signaled held handles are preserved. This design does not repair or replay them. The discrepancy is not yet attributable uniquely to zero secondary boundary, source discretization, mesh propagation, or receiver interpolation.

Choose a conditional S2 increment using **only** the frozen S1 first-derivative source moments and field, and saved L5 matrices. First evaluate a separately derived electric dipole field on the selected receiver contour and on only the saved receiver-trace support edges. This checks the E/H voltage representation and measures a receiver-functional bias for a known smooth Born field. If these checks qualify, sample the same Born E field as tangential boundary edge averages; form `-A_IB g_B` from saved full `A` and solve saved `A_II` **once**. Compare the corrected derivative with the same frozen H-flux oracle and keep the complex difference. This is a diagnostic decomposition for the fixed case, not a promise of 1% success or a general exterior boundary condition.

The saved source and operator bytes actually read for this design are in `source-pins.json`. In a future executable S2 job, verify that file and the original S1 94-file manifest (`32a48180c41027fdbd10fdaa419dc118c480f153d7cff472e48f41d1699cbe06`) and L5 manifest (`521022089175583b344c45cbb6a2ca88e1198845a9f14f0ea347421e10fb9730`) again **before** loading numerical data. Stop on any mismatch. A future worker gets new disjoint ownership; it does not write in S1 or L5.

## Dyadic field derivation, signs, units

Use the existing physical convention `Re{E exp(+i omega t)}`, `omega=2*pi*2e6 s^-1`, `zeta=sigma_0+i*omega*epsilon_0` [S/m], `mu=mu_0` [H/m], and `q=sqrt(i*omega*mu*zeta)` [m^-1] with `Re(q)>=0`. Here `zeta != 0` is mandatory. Define `G(r)=exp(-q*r)/(4*pi*r)` [m^-1], `r=x-s`, `rhat=r/r`; require `r>0` and a target separated from source quadrature points. An electric-current point moment `m` has units A m, because `J=m*delta(x-s)`.

From `curl E=-i*omega*mu*H`, `curl H=J+zeta E`, one obtains

```
(curl curl + q^2) E = -i*omega*mu*J,      q^2=i*omega*mu*zeta.
(nabla^2-q^2)G = -delta.
E(x;m) = -i*omega*mu*[G I - q^-2 grad grad G] m
       = -i*omega*mu*G*m + zeta^-1*(grad grad G)*m.
```

For nonzero separation, `G'/r=-G*(q/r+1/r^2)` and `G''-G'/r=G*(q^2+3q/r+3/r^2)`. Thus the proposed explicit field is correct:

```
E(x;m) = exp(-q*r)/(4*pi*zeta*r^3)
         * [(3+3*q*r+(q*r)^2)*rhat*(rhat dot m)
            -(1+q*r+(q*r)^2)*m].
```

No extra `-i*omega` or `mu` multiplier is applied to this explicit formula. The `1/zeta` factor is essential; replacing it with `1/sigma` silently drops displacement current. `zeta^-1 grad grad G*m` and `omega*mu*G*m` both have V/m. Taking the curl gives `H=grad G cross m = exp(-q*r)*(1+q*r)/(4*pi*r^2)*(m cross rhat)` [A/m]. With the same oriented receiver normal and winding, `V=N integral E dot dl = -i*omega*mu*N integral H dot n dS` [V]. The saved Geoana H branch uses `k^2=omega^2*mu*epsilon-i*omega*mu*sigma`, so `q=i*k` on the consistent outgoing branch and `exp(-i*k*r)=exp(-q*r)`.

At `tau=0`, the perturbation is `delta_zeta=zeta*1_D`; the saved moments are `m_i=delta_zeta*E_p(s_i)*w_i` [A m]. They are the same physical equivalent current used by the H oracle, without reading its excluded Geoana E/current-density path or constructing C/mass/RHS as an oracle. The S1 discrete derivative obeys `A_0 e_dot = -i*omega*M_e(delta_zeta)e_p`; its RHS sign agrees with the point-current Maxwell equation above. No sign change is inserted for a coil voltage. A reversed receiver winding reverses both E-line and H-flux voltages.

For the later matrix correction, partition edge unknowns by the saved ordered `I` and `B`:

```
A_II e_I + A_IB g_B = b_I,
e_I^0 = A_II^-1 b_I,  e_B^0=0,
delta e_I = A_II^-1(-A_IB g_B),  delta e_B=g_B.
```

The saved receiver trace `t` is complex-linear: `V=t^T e`, with **ordinary transpose, no Hermitian conjugation**. Hence `delta V=t_I^T delta e_I+t_B^T g_B`. If expressed as an adjoint identity only, `lambda=A_II^-T t_I` and `delta V=t_B^T g_B-lambda^T A_IB g_B`; this confirms the minus sign. S2 should perform the one direct correction solve, not an additional adjoint solve. Existing L5 code saves `A-csr.npz` and `AII-csc.npz`; `A_IB=A[I,:][:,B]` is a slice of that same saved full matrix, never a newly assembled operator. The old L5 primary boundary array belongs to another source/pose and is not `g_B` here.

## Exact read-only inputs for a future executable increment

All paths below are under `.planning/deepeye-resume-20261018/`, unless noted. Their byte hashes are in `source-pins.json`; that file also pins the design's role/scope/transfer and source review files.

| Purpose | Frozen input |
|---|---|
| Physics, coil/box pose and source construction | `g03-s1-cache-path-continuation-20261021/assignment.json`, `s1_geometry.py`, `s1_model.py`, `s1_oracle.py`, `report.md`, `result.json` |
| No new primary integration | S1 `oracle-01/{low,high}_volume_points_m.npy` and `{low,high}_equivalent_current_moments_Am.npy`; the latter already include `delta_zeta*E_p*dV` |
| Independent fixed H voltage | S1 `oracle-01/Born_derivative_V.npy` (low/high, both Rx) and `oracle-01/result.json`; do not recompute H flux |
| Frozen zero-boundary solution/source | S1 `run-01/full_derivative_Vpm.npy`, `new_derivative_RHS.npy`, `derivative_voltage_V.npy`, `run-01/result.json` |
| Receiver and boundary geometry | S1 `controls-01/receiver_trace_m.npy`, `boundary_indices.npy`, `interior_indices.npy`; L5 `controls-01/edge_starts_m.npy`, `edge_ends_m.npy`, `boundary_indices.npy`, `interior_indices.npy` |
| Operator for one correction | L5 `run-01/A-csr.npz`, `AII-csc.npz`, `assignment.json`, `grid_worker.py`, `public-manifest.json` |

Check array shape, dtype, finite values, units and ordered indices after hash verification. Expected counts from the frozen L5 assignment are 63,250 edges, 54,418 interior edges and 8,832 boundary edges; `I` and `B` must be disjoint complements in the exact saved order and exactly equal across S1/L5. Reconstruct only geometry from the pinned L5 node vectors when needed for the selected coil path; this does not reassemble C or A. Check every requested E evaluation target against every saved volume source for positive finite distance, and receiver/contrast and boundary/contrast geometric separation. A singular or near-unresolved target stops before any matrix load or solve.

## Staged, no-repeat experiment for a separately assigned worker

1. **New trace-closure and source/formula controls, no matrix or solver.** Before evaluating the Born E field, use the pinned L5 node/edge geometry and the frozen receiver trace `t` to form the oriented node incidence row `c_n=sum_j (t_j/length_j)*(1_{head(j)=n}-1_{tail(j)=n})`. It must annihilate a discrete gradient: for any nodal scalar potential `phi` [V], edge-average `e_grad,j=(phi_head-phi_tail)/length_j` [V/m] gives `t^T e_grad=c^T phi=0` around the closed loop. Check the full incidence row with the predeclared dimensionless gate `||c||_inf <= 1e-10*sum_j |t_j|/length_j`, and record a nonconstant mixed-coordinate nodal-potential example as a sanity check. This is a new gauge/closure control; S1's constant-field and known-curl controls need no replay. Then use the unchanged saved low (4^3 volume/128 transmitter) and high (8^3/256 transmitter) source positions and moments. Evaluate the explicit E dyad in bounded blocks on each true Rx contour at the same fixed 128/256 point levels. Form `V_E=N sum E(x_k) dot dl_k`. Compare each low/high result with the corresponding saved H-flux `Born_derivative_V.npy` and check low/high E-line pair. The inherited S1 representation/quadrature screen is 0.001 complex relative for each nonzero receiver value; record absolute complex differences and both denominator magnitudes, and leave relative undefined on exact zero or unstable cancellation. Add a selected non-axis point identity check against the derived H expression and a receiver winding reversal sign check. Any closure failure, wrong sign, branch, nonfinite value, failed geometry, E/H discrepancy, or failed pair stops before boundary sampling or solve. The H route is independent code but shares the same Green physics, primary and saved moments; this control does not certify the source model.

2. **Receiver-functional diagnosis before boundary work.** On only the nonzero support of the frozen `receiver_trace_m.npy`, sample the same high Born E as **edge-average components** using the L5 start/end points and fixed Gauss 8/16 along each edge. Let `e_ref,j=(1/length_j) integral_edge E_Born dot tangent_j ds` [V/m]. Compute `V_trace_ref=t^T e_ref` and compare it as a complex voltage with the direct high E-line `V_E`. Save `Delta_functional=V_trace_ref-V_E`, its absolute magnitude and its ratio to `|V_E|` when defined, plus both edge-order values. This measures receiver interpolation/trace bias **for this smooth Born field**, not the actual solved field's isolated error. The already saved `t^T e^0` must reproduce the saved S1 `derivative_voltage_V.npy` within explicit floating summation roundoff; if it does not, stop. A large `Delta_functional` is evidence to report, not permission to retune the grid or cancel it against a boundary term. If edge-order change is >0.001 relative or cancellation makes the diagnostic undefined, stop before solve and retain the raw values.

3. **Boundary sampling, still no matrix or solve.** At all 8,832 saved tangential boundary edges, sample `g_B` as the high-moment Born E edge-average tangential component [V/m], with the same fixed Gauss 8/16 edge pair. Also form a low/high **source-moment** pair at the high edge order. Save full complex `g_B`, the max absolute pair differences and `||g_high-g_low||_inf/||g_high||_inf` where nonzero; require each predeclared pair <=0.001 before factorization. Keep target blocks <=128 points and <=512 source moments per high block; never allocate an all-boundary-edge × all-source tensor. No midpoint substitution, zero filling, displacement-denominator patch, or new quadrature level follows a failure.

4. **One genuinely new correction RHS and one solve, conditional on prior controls.** Load the pinned sparse full `A` and `AII` only now. Verify `A[I,:][:,I]` equals saved `AII` in shape, sparse entries and ordered indices; verify finite data. Slice `A_IB`, then release full `A` before factorization. Form and persist `r_B=-A_IB@g_B`, `g_B`, hash readbacks, and pre-factorization receipt. Factor saved `AII` once with the frozen `COLAMD` setting, solve `AII delta e_I=r_B` once, and save the complex vector/residual. Require the unchanged algebraic backward-eta screen `<=128*float64_eps` (`2.842170943040401e-14`). Add the correction to the frozen S1 field: `e_corr[I]=e_S1[I]+delta e_I`, `e_corr[B]=g_B`; no new contrast RHS, no total-field residual or original-source correction is added.

5. **Report the separation without promoting acceptance.** For each Rx retain `V_0` from S1, `V_H` from the frozen high H-flux oracle, `V_E`, `V_trace_ref`, `delta V_B=t_I^T delta e_I+t_B^T g_B`, and `V_corr=V_0+delta V_B`. Report the complex residuals `R_0=V_0-V_H` and `R_corr=V_corr-V_H`, their absolute values and relative values against `|V_H|` if defined. `delta V_B` is the measured influence of replacing the **chosen discrete zero boundary** by the sampled Born boundary. `R_corr` still combines mesh/source/receiver and boundary sampling/model errors; subtraction does not prove a unique causal allocation. Compare to the unchanged 1% S1 screen for diagnostic status only, with no threshold change or automatic grid/solver retry. Persist an original terminal and every held-process outcome even on failure.

For the source/receiver and boundary stages, keep one hidden held process per stage, <=90 s sampled threshold, <=512 MiB/process, <=1 GiB/job, <=4 active processes, BLAS threads=1 and stage-local cache/TEMP. For the single correction stage use the S1 selected ceiling: <=90 s sampled threshold, <=4 GiB/process, <=5 GiB/job, <=4 active processes, BLAS threads=1, and >=10 GiB observed free physical memory before factorization. These are sampled guards, **not hard cancellation guarantees**. If memory/clock/handle limits fail, preserve the original terminal and do not retry. Persist finite complex arrays with both real and imaginary parts, dimensions, units, input hashes and full observed resource/exit evidence; avoid dense 63,250² arrays.

## What this can and cannot establish

For a compact derivative source in the homogeneous infinite background, the volume-moment E field supplies the continuous first-Born boundary trace. Prescribing that trace on the finite box is exact for the **continuous first-derivative Born boundary problem** if the source moments/integration are exact. In this experiment the moments, edge averages, trace and mesh operator are discretized, so the observed correction is a measured finite-discrete boundary diagnostic. It is not a transparent boundary for a generic heterogeneous finite-strength medium: there the equivalent current contains the unknown total field, can change outside the fixed box, and demands a separately derived exterior coupling or accepted approximation. It is also not a finite-tau accuracy certificate.

The E-line/H-flux agreement checks the dyadic expression, orientation and Faraday sign with independent H code, while sharing the selected homogeneous Green physics and saved primary/moments. The receiver reference-edge comparison targets interpolation error for that reference field, not every possible field. If any source hash, geometry, E/H identity, quadrature pair, trace readback, A/AII partition, resource preflight or retained-handle check fails, the next worker stops at that gate and reports the original evidence. The actual board, sensor source/noise/calibration, hidden-truth interface, game UI, PC AI and both H12 control routes remain `not_run`; no 1% or product acceptance is claimed by this design.
