"""Verify S2 design pins and seal public files, excluding private lease material."""
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
pins = json.loads((D / 'source-pins.json').read_text(encoding='utf-8'))
for name, expected in pins['files'].items():
    raw = (ROOT / name).read_bytes()
    actual = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    assert actual == expected, name
names = ('assignment.json', 'pin_sources.py', 'source-pins.json', 'design.md',
         'result.json', 'final-result.txt', 'seal.py', 'native-complete-response.json')
files = {}
for name in names:
    raw = (D / name).read_bytes()
    files[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
out = {'work_id': 'A-G03-S2-BOUNDARY-DESIGN-20261021-v1',
       'status': 'static_design_delivered', 'file_count': len(files), 'files': files,
       'source_pin_count': len(pins['files']),
       'requirements_sha256': pins['requirements_sha256']}
with (D / 'manifest.json').open('w', encoding='utf-8') as stream:
    json.dump(out, stream, indent=2, ensure_ascii=False)
    stream.write('\n')
