import json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];mode=sys.argv[1];assert mode in ('controls','actual')
sys.path.insert(0,str(D.parent/'r02-transient-quota-fix-20261021'))
from win_job import run_bounded
env={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR')}
env.update(PATH='',TEMP=str(D),TMP=str(D),PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
budget={'seconds':30,'active_processes':4,'process_memory_bytes':512*1024**2,'job_memory_bytes':768*1024**2,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':16*1024**2,'tree_entries':256,'free_reserve_bytes':512*1024**2}
r=run_bounded([str(ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'),'-I','-B','-X','utf8',str(D/'review_arrays.py'),mode],env,D,D/(mode+'-review-run-01'),budget,[D])
assert r['exit_code']==0 and r['all_processes_terminated'] and r['active_processes_final']==0
print(json.dumps({'mode':mode,**{k:r[k] for k in ('exit_code','seconds','all_processes_terminated','peak_job_memory_bytes')}}))
