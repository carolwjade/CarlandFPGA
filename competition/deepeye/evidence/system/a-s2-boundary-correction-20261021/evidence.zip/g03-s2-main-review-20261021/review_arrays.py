"""New S2 saved-array review only: no E/H evaluation, assembly or solve."""
import datetime,hashlib,json,math,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent;S=O/'g03-s2-boundary-correction-20261021';S1=O/'g03-s1-cache-path-continuation-20261021';L5=O/'g03-l5-propagation-z-refinement-20261021'
def audit(event,args):
    if event in ('socket.connect','socket.bind','socket.getaddrinfo','subprocess.Popen','os.system','os.startfile'):raise RuntimeError('read-only numerical review forbids external effects')
    if event=='open' and not isinstance(args[0],int):
        mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writing and not Path(args[0]).resolve().is_relative_to(D):raise RuntimeError('review output outside owner')
sys.addaudithook(audit)
import numpy as np
EPS=128*np.finfo(float).eps;used={}
def pin(p):
    b=p.read_bytes();used[str(p)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):pin(p);return json.loads(p.read_bytes())
def load(p):pin(p);return np.load(p,allow_pickle=False)
def csum(v):
    v=np.asarray(v).ravel();return complex(math.fsum(float(x.real) for x in v),math.fsum(float(x.imag) for x in v))
def pair(v):return [[float(x.real),float(x.imag)] for x in np.asarray(v).ravel()]
def equal(a,b,scale):
    a=np.asarray(a);b=np.asarray(b)
    assert np.all(np.isfinite(a)) and np.all(np.isfinite(b))
    assert np.all(abs(a-b)<=EPS*np.asarray(scale))
def terminal(folder,exit_code=None):
    t=read(folder/'terminal.json');assert t['all_processes_terminated'] and t['active_processes_final']==0 and all(h['signaled'] for h in t['held_members'])
    if exit_code is not None:assert t['exit_code']==exit_code
    return t
def write_result(name,result):
    for p,record in used.items():
        raw=Path(p).read_bytes();assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256'],p
    result.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),old_tests_repeated=False,E_or_H_evaluations=0,matrix_assemblies=0,factorizations=0,physical_accuracy='unqualified',finite_tau='not_run',G03='not_run',R03='not_run',all29='not_run',inputs=used)
    with (D/name).open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k!='inputs'}))
def controls_boundary():
    C=S/'controls-01';B=S/'boundary-01';terminal(C,0);terminal(B,0)
    cr=read(C/'result.json');br=read(B/'result.json');assert cr['status']=='controls_pass' and br['status']=='boundary_pass'
    inc=load(C/'gradient_incidence.npy');assert inc.shape==(2,21875)
    t=load(S1/'controls-01/receiver_trace_m.npy');starts=load(L5/'controls-01/edge_starts_m.npy');ends=load(L5/'controls-01/edge_ends_m.npy')
    length=np.linalg.norm(ends-starts,axis=1);incscale=np.sum(abs(t/length[None,:]),axis=1)
    observed=np.max(abs(inc),axis=1);assert np.all(observed<=1e-10*incscale)
    assert np.array_equal(observed,np.array([r['incidence_inf'] for r in cr['closure']]))
    point=read(C/'point-control.json');target=np.array([complex(*v) for v in point['target_minus_iomega_mu_H']]);curlrows=[]
    for row in point['rows']:
        curl=np.array([complex(*v) for v in row['curl_E']]);curlrows.append(curl)
        error=float(np.max(abs(curl-target)));assert error/float(np.max(abs(target)))<=1e-5 and error==row['absolute_inf']
    assert float(np.max(abs(curlrows[1]-curlrows[0]))/np.max(abs(target)))<=1e-5
    a=read(S/'assignment.json');turns=a['inputs']['turns'];line=load(C/'E_line_V.npy');scale=load(C/'E_line_absolute_sum_scale_V.npy');independent_line=np.empty((2,2),dtype=complex)
    for li,label in enumerate(('low','high')):
        for ri in range(2):
            E=load(C/f'{label}_rx{ri+1}_Born_E_Vpm.npy');dl=load(C/f'{label}_rx{ri+1}_contour_dl_m.npy')
            independent_line[li,ri]=turns*csum(E*dl)
    equal(independent_line,line,scale)
    H=load(S1/'oracle-01/Born_derivative_V.npy')
    assert np.all(abs(independent_line)>EPS*scale)
    EH=abs(independent_line-H)/abs(H);linepair=abs(independent_line[1]-independent_line[0])/abs(independent_line[1])
    assert np.all(EH<=.001) and np.all(linepair<=.001)
    support=load(C/'receiver_support_indices.npy');assert np.array_equal(support,np.flatnonzero(np.any(t!=0,axis=0)))
    refs=[];refsums=[]
    for order in (8,16):
        edge=load(C/f'Born_E_receiver_edge_average_g{order}_Vpm.npy');abssum=load(C/f'Born_E_receiver_edge_absolute_sum_g{order}_Vpm.npy')
        refs.append([csum(row[support]*edge) for row in t]);refsums.append(np.sum(abs(t[:,support])*abssum[None,:],axis=1))
    refs=np.array(refs);refsums=np.array(refsums);savedrefs=load(C/'receiver_reference_trace_V.npy');equal(refs,savedrefs,refsums)
    assert np.all(abs(refs[1]-refs[0])/abs(refs[1])<=.001)
    bias=refs[1]-independent_line[1];savedbias=load(C/'functional_bias_V.npy');equal(bias,savedbias,refsums[1]+scale[1])
    fine=load(B/'gB_high_g16_Vpm.npy');lowedge=load(B/'gB_high_g8_Vpm.npy');lowsource=load(B/'gB_low_g16_Vpm.npy')
    assert fine.shape==lowedge.shape==lowsource.shape==(8832,)
    pairerrors={'edge_order':float(np.max(abs(fine-lowedge))/np.max(abs(fine))),'source_moments':float(np.max(abs(fine-lowsource))/np.max(abs(fine)))}
    assert all(v<=.001 for v in pairerrors.values())
    for key,value in pairerrors.items():assert value==br['pair_screens'][key]['relative_inf']
    write_result('controls-boundary-review.json',{'status':'ACCEPT_NEW_S2_CONTROLS_AND_BOUNDARY_ARRAYS','gradient_incidence_relative':(observed/incscale).tolist(),'independent_E_line_V':pair(independent_line),'independent_E_vs_saved_H_relative':EH.tolist(),'independent_E_line_pair':linepair.tolist(),'receiver_functional_bias_V':pair(bias),'receiver_functional_bias_relative':(abs(bias)/abs(independent_line[1])).tolist(),'boundary_relative_pairs':pairerrors,'boundary_inf_Vpm':float(np.max(abs(fine))),'role_of_bias':'Reference-field functional diagnosis only, not solved-field unique error attribution.'})
def actual():
    A=S/'run-01';ar=read(A/'result.json');tr=terminal(A)
    from scipy.sparse import csr_matrix,csc_matrix
    def matrix(p,kind):
        with load(p) as z:return kind((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
    I=load(S1/'controls-01/interior_indices.npy');B=load(S1/'controls-01/boundary_indices.npy')
    full=matrix(L5/'run-01/A-csr.npz',csr_matrix);system=matrix(L5/'run-01/AII-csc.npz',csc_matrix).tocsr()
    g=load(A/'selected_gB_Vpm.npy');assert np.array_equal(g,load(S/'boundary-01/gB_high_g16_Vpm.npy'))
    lift=np.zeros(full.shape[0],dtype=complex);lift[B]=g
    rhs=load(A/'new_boundary_correction_RHS.npy');independent_rhs=-(full.dot(lift))[I]
    equal(independent_rhs,rhs,(abs(full).dot(abs(lift)))[I])
    x=load(A/'interior_correction_Vpm.npy');correction=load(A/'full_correction_Vpm.npy');corrected=load(A/'corrected_derivative_Vpm.npy');old=load(S1/'run-01/full_derivative_Vpm.npy')
    assert np.array_equal(correction[I],x) and np.array_equal(correction[B],g)
    assert np.array_equal(corrected,old+correction) and np.all(old[B]==0)
    residual=system.dot(x)-rhs;storedres=load(A/'correction_residual.npy')
    equal(residual,storedres,abs(system).dot(abs(x))+abs(rhs))
    eta=float(np.max(abs(residual)))/(float(np.max(np.asarray(abs(system).sum(axis=1)).ravel()))*float(np.max(abs(x)))+float(np.max(abs(rhs))))
    assert math.isfinite(eta) and eta<=EPS
    full_residual=full.dot(correction)[I];equal(full_residual,residual,(abs(full).dot(abs(correction)))[I]+abs(rhs))
    t=load(S1/'controls-01/receiver_trace_m.npy');V0=load(S1/'run-01/derivative_voltage_V.npy');H=load(S1/'oracle-01/Born_derivative_V.npy')[1]
    dc=np.array([csum(row*correction) for row in t]);vc=np.array([csum(row*corrected) for row in t])
    dcscale=np.sum(abs(t*correction[None,:]),axis=1);vcscale=np.sum(abs(t*corrected[None,:]),axis=1)
    equaldc=load(A/'boundary_delta_V.npy');savedvc=load(A/'V_corrected_V.npy')
    equal(dc,equaldc,dcscale);equal(vc,savedvc,vcscale+abs(V0)+dcscale)
    equal(V0+dc,vc,vcscale+abs(V0)+dcscale)
    r0=V0-H;rc=vc-H
    equal(rc,load(A/'R_corrected_V.npy'),vcscale+abs(V0)+dcscale+abs(H))
    assert np.array_equal(r0,load(A/'R0_V.npy'))
    relative=abs(rc)/abs(H);reported=np.asarray(ar['comparison']['relative'])
    propagated=EPS*((vcscale+abs(V0)+dcscale)/abs(H)+relative+reported)
    assert np.all(abs(relative-reported)<=propagated)
    passed=bool(np.all(relative<=.01));assert ar['status']==('one_correction_solve_screens_pass' if passed else 'one_correction_solve_screen_failed')
    assert tr['exit_code']==(0 if passed else 2)
    write_result('actual-array-review.json',{'status':'ACCEPT_NEW_S2_CORRECTION_EVIDENCE_ONLY','new1percent_screen_pass':passed,'independent_eta':eta,'eta_gate':EPS,'independent_boundary_delta_V':pair(dc),'independent_corrected_V':pair(vc),'independent_corrected_relative_errors':relative.tolist(),'independent_corrected_absolute_errors_V':abs(rc).tolist(),'relative_metric_difference':abs(relative-reported).tolist(),'propagated_relative_roundoff_bound':propagated.tolist(),'new_correction_residual_full_operator_verified':True,'role_of_correction':'Measured change from zero to sampled Born boundary for this derivative; no generic exterior boundary model.'})
if __name__=='__main__':{'controls':controls_boundary,'actual':actual}[sys.argv[1]]()
