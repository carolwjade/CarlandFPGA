"""Seal original S2 terminal evidence after independent source and array review."""
import asyncio
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

D = Path(__file__).resolve().parent
O = D.parent
ROOT = O.parents[1]
sys.path.insert(0, str(ROOT))
from fpga_mesh.child_control import LocalControlFileClient
from fpga_mesh.project_cli import discovery


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def unwrap(v):
    if 'content' in v:
        return json.loads(next(x['text'] for x in v['content'] if x['type'] == 'text'))
    return v


def save(p, v):
    with p.open('x', encoding='utf-8') as f:
        json.dump(v, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')


S = O / 'g03-s2-boundary-correction-20261021'
expected_manifest = '0e8e9644eb2a9050add8759d11ccb67954433a478162906ca237de9c9c661cf0'
assert sha(S / 'manifest.json') == expected_manifest
manifest = read(S / 'manifest.json')
for rel, pin in manifest['files'].items():
    p = S / rel
    assert p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256'], rel
pins = read(S / 'frozen-source-pins.json')
for rel, pin in pins.items():
    p = ROOT / rel
    assert p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256'], rel
native = unwrap(read(S / 'native-complete-response.json'))
assert native['job_id'] == 'child-25b4c7d06a4f4856a2b8ad9bff610cfd'
actual_raw = asyncio.run(LocalControlFileClient(discovery(ROOT)).call('job', {'job_id': native['job_id']}))
actual = unwrap(actual_raw)
save(D / 'original-native-job-readback.json', actual_raw)
for value in (native, actual):
    assert value['status'] == 'failed' and value['terminal'] and not value['stale']
    assert value['result'] is None and value['error'] == native['error']
    assert value['native_agent_id'] == '/root/r02_amd_acquisition_20261021'
terminal = read(S / 'terminal-evidence.json')
assert terminal['all_original_held_signaled'] == 12
for rel, pin in terminal['files'].items():
    p = S / rel
    assert p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256']
ar = read(D / 'actual-array-review.json')
assert ar['status'] == 'ACCEPT_NEW_S2_CORRECTION_EVIDENCE_ONLY'
assert not ar['new1percent_screen_pass']
assert ar['new_correction_residual_full_operator_verified']
result = {
    'utc': datetime.now(timezone.utc).isoformat(),
    'status': 'ACCEPT_NEW_S2_EVIDENCE_ONLY',
    'new_corrected_accuracy_screen_pass': False,
    'design_review': read(D / 'design-review.json'),
    'source_review': read(D / 'source-review.json'),
    'controls_boundary_review': read(D / 'controls-boundary-review.json'),
    'actual_array_review': ar,
    'sealed': [{
        'folder': S.name, 'manifest_sha256': expected_manifest,
        'manifest_files': len(manifest['files']), 'source_pins': len(pins),
        'native_job': native['job_id'], 'native_status': native['status'],
        'native_error': native['error'], 'actual_native_terminal_readback': True,
        'held_processes_signaled': 12,
        'final_text_sha256': sha(S / 'final-result.txt'),
    }],
    'old_tests_repeated': False, 'main_factorizations': 0,
    'main_matrix_assemblies': 0, 'main_Green_evaluations': 0,
    'requirements_sha256': 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    'physical_accuracy': 'unqualified', 'finite_tau': 'not_run',
    'noise_gate': 'not_run', 'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run',
}
save(D / 'review.json', result)
print(json.dumps({'status': result['status'], 'manifest_files': len(manifest['files']),
                  'source_pins': len(pins), 'actual_native_failed_terminal': True,
                  'held_signaled': 12, 'accuracy_screen_pass': False}))
