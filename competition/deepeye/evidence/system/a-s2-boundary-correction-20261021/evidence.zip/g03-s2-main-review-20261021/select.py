import datetime,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent;ROOT=O.parents[1];S=O/'g03-s2-boundary-design-20261021'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
m=read(S/'manifest.json');assert sha(S/'manifest.json')=='ee292eb12768f79f0863ff6d013b315be3f3ca8c5eae06414a427d258a3f580c'
for n,pin in m['files'].items():
    p=S/n;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],n
pins=read(S/'source-pins.json')['files']
for n,pin in pins.items():
    p=ROOT/n;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],n
native=read(S/'native-complete-response.json')
assert native['status']=='completed' and native['terminal'] and not native['stale']
assert native['result']['text'].encode('utf-8')==(S/'final-result.txt').read_bytes()
save(D/'design-review.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACCEPT_TARGETED_S2_DESIGN_FOR_ONE_DIAGNOSTIC_INCREMENT','manifest_files':len(m['files']),'source_pins':len(pins),'design_sha256':sha(S/'design.md'),'native_job':native['job_id'],'native_actual_text_bytes_exact':True,'independent_derivation':'For q^2=i*omega*mu*zeta and (Laplacian-q^2)G=-delta, E=(Hessian-q^2 I)G*m/zeta yields the -i*omega*mu*m delta source and curl E=-i*omega*mu*(grad G cross m). This expands to the stated dyadic coefficients; no sigma-only E branch is called. Partition AII eI+AIB gB=bI gives new correction -AIB*gB. The complex receiver is ordinary linear, not conjugate linear.','selected_sequence':['New discrete-gradient closure and new E/H representation controls using frozen source moments','New Born-field receiver-functional diagnosis on frozen trace support','New tangential Born boundary edge integration with fixed moment/edge pairs','Only if controls qualify, one new boundary correction RHS and saved-AII solve'],'no_old_test_replay':True,'physical_accuracy':'unqualified','generic_heterogeneous_boundary':'not_supplied','finite_tau':'not_run','all29':'not_run'})
N=O/'g03-s2-boundary-correction-20261021';N.mkdir(exist_ok=False)
a=read(O/'g03-s1-cache-path-continuation-20261021/assignment.json')
for k in ('predecessor','implementation_constraint','selected_execution'):a.pop(k,None)
a.update(work_id='A-G03-S2-BOUNDARY-CORRECTION-20261021-v1',ownership=[N.relative_to(ROOT).as_posix()],selected_design=(S/'design.md').relative_to(ROOT).as_posix(),design_sha256=sha(S/'design.md'),selected_scope='Implement the independently reviewed S2 receiver/zero-boundary diagnosis using frozen S1 moments, fields and L5 operators; one conditional new correction solve.',source_pins=(S/'source-pins.json').relative_to(ROOT).as_posix(),source_pins_sha256=sha(S/'source-pins.json'),predecessor_manifest='.planning/deepeye-resume-20261018/g03-s1-cache-path-continuation-20261021/manifest.json',predecessor_manifest_sha256='32a48180c41027fdbd10fdaa419dc118c480f153d7cff472e48f41d1699cbe06')
a['budgets']['new_controls_oracle_each']['seconds_threshold']=90
a['new_engineering_screens']['gradient_closure_relative']=1e-10
a['new_engineering_screens']['point_curl_H_relative']=1e-5
a['fixed_new_point_control']={'source_m':[0,0,0],'observation_m':[.4,-.3,.2],'complex_moment_Am_pairs':[[1,2],[-.5,.7],[.3,-.2]],'curl_method':'five-point centered finite differences along each coordinate of the new explicit E; evaluate steps 0.001*r and 0.0005*r only','comparison':'curl(E) against -i*omega*mu times the independently expressed H for the same complex moment; relative infinity norm, fixed1e-5 gate and fixed step-pair1e-5 gate. Diagnostic only; absolute differences required.'}
a['implementation_constraint']='Create new local source and meaningful new controls for the explicit E dyad, gradient-closure and E-line/H-flux representation. Reuse frozen S1 saved moments/trace/fields/voltages and old controls evidence; no old primary/H/source integration or C/A reconstruction. Do not call excluded Geoana E/current_density or patch dependencies. Guard stage cache/TEMP paths inside each stage and use nonvisible Agg. Keep science inputs immutable and audit stage-only writes; no new network/subprocess effects from science worker. Source pins before/after every stage.'
a['selected_execution']='Only new E/receiver controls and boundary integration stages once each, each90s threshold512MiBproc1GiBjob. If all selected gates pass, persist -AIB*gB then one actual COLAMD correction solve90s threshold4GiBproc5GiBjob/freshfree>=10GiB/BLAS1. No automatic retry, extra grid/ordering/quad on failure. Distinguish process exit, diagnostic screen, new residual and physical acceptance. Preserve old failed S1 result; do not convert it to success.'
a['no_repeat']='No old RED, controls, primary Green, H-flux oracle, old RHS solve, grid assembly, ROCm, board or R03 baseline repeated. The new E implementation requires its own genuine RED before implementation; that is new coverage. No adjacent generic feature work.'
a['control_rules']='Follow selected S2 design, exact E dyad and parameter pairs. Include fixed point control above and meaningful reversed receiver E-line sign. Preserve near-cancellation cases as undefined using an explicit roundoff sum-bound check; no floor. Geometry and all exact source/manifest/ordered index checks before effects. Record observed absolute/relative values even on1% failure. Immediately send stage terminal events; stop on new failure without automatic retries.'
a['limitations']=['S2 uses known Born-source boundary for this one derivative; no general heterogeneous transparent boundary.','S1 physical screen failed and remains immutable; corrected1% outcome still only diagnostic.','No source noise/calibration qualification or finite-strength heterogeneity.','No new product sensing, control activation, C model, hardware acceptance or all29 closure.']
save(N/'assignment.json',a)
save(N/'reserve-request.json',{'task_id':a['task_id'],'task_version':1,'work_id':a['work_id'],'ownership':a['ownership'],'reason':'Implement a targeted receiver/boundary correction from frozen S1 evidence, without repeating passed baselines.','text':json.dumps(a,ensure_ascii=False)})
print(json.dumps({'design_reviewed_files':len(m['files']),'source_pins':len(pins),'native_text_exact':True,'selected':a['work_id']}))
