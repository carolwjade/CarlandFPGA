"""Accept the bounded static candidate; retain source conflicts and raw evidence."""
import asyncio
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

D = Path(__file__).resolve().parent
O = D.parent
ROOT = O.parents[1]
sys.path.insert(0, str(ROOT))
from fpga_mesh.child_control import LocalControlFileClient
from fpga_mesh.project_cli import discovery

read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def save(p, value):
    with p.open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')

S = O / 'r02-io-map-revision-20261021'
P = O / 'r02-io-map-design-20261021'
m = read(S / 'manifest.json')
for pin in m['files']:
    p = S / pin['path']
    assert p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256']
assert sha(P / 'manifest.json') == m['predecessor_manifest_sha256']
sources = read(S / 'source-pins.json')
for key, pin in sources.items():
    if isinstance(pin, dict) and 'file' in pin:
        p = S / pin['file']
        assert sha(p) == pin['sha256'], key
        if 'bytes' in pin:
            assert p.stat().st_size == pin['bytes'], key
native = read(S / 'native-completion.json')
assert native['status'] == 'completed' and native['terminal'] and not native['stale']
assert native['result']['text'].encode('utf-8') == (S / 'final-text.txt').read_bytes()
actual = asyncio.run(LocalControlFileClient(discovery(ROOT)).call('job', {'job_id': native['job_id']}))
save(D / 'revised-native-job-readback.json', actual)
if 'content' in actual:
    actual = json.loads(next(x['text'] for x in actual['content'] if x['type'] == 'text'))
assert actual['status'] == 'completed' and actual['terminal'] and not actual['stale']
assert actual['result'] == native['result']
candidate = read(S / 'candidate-pinmap.json')
before = read(P / 'candidate-pinmap.json')
assert len(candidate['digital_signals']) == 15
assert candidate['analog_signals'] == before['analog_signals']
for old, new in zip(before['digital_signals'], candidate['digital_signals']):
    if not old['port'].startswith('dac_'):
        assert old == new
    else:
        assert new['position'] is None and new['physical_position_status'] == 'UNRESOLVED_SOURCE_CONFLICT'
        assert old['package_pin'] == new['package_pin']
        assert set(new['position_candidates'].values()) == {9, 10}
assert read(S / 'conflict-check.json')['passed'] == 13

# Two editorial provenance corrections, without another author-suite execution.
# Raw author bytes stay in the predecessor archive and manifest.
A = D / 'accepted'
A.mkdir(exist_ok=False)
changes = []
names = ['design.md', 'candidate-pinmap.json', 'candidate.xdc', 'source-pins.json',
         'conflict-check.json', 'revision-delta.json']
for name in names:
    raw = (S / name).read_bytes()
    text = raw.decode('utf-8')
    text = text.replace('PDF p. 50', 'PDF p. 51 (zero-based index 50)')
    text = text.replace('PDF p.50', 'PDF p.51 (zero-based index50)')
    text = text.replace('Human-reviewed', 'Agent-reviewed').replace('human-reviewed', 'agent-reviewed')
    updated = text.encode('utf-8')
    (A / name).write_bytes(updated)
    if updated != raw:
        changes.append({'path': name, 'original_sha256': hashlib.sha256(raw).hexdigest(),
                        'accepted_sha256': hashlib.sha256(updated).hexdigest()})
assert '===== PDF PAGE 51 =====' in (P / 'sources/microchip_mcp4728_ds22187e.txt').read_text(encoding='utf-8')
summary = {
    'utc': datetime.now(timezone.utc).isoformat(),
    'status': 'ACCEPT_STATIC_PACKAGE_CANDIDATE_WITH_PHYSICAL_J3_HOLD',
    'predecessor_manifest_sha256': sha(P / 'manifest.json'),
    'revision_manifest_sha256': sha(S / 'manifest.json'),
    'original_files': 23, 'revised_files_verified': len(m['files']),
    'native_completion_text_exact': True, 'original_job_terminal_readback': True,
    'substantive_findings': 'All three addressed; J3 contact conflict remains explicitly unresolved, onboard2.2k pullups accounted for, A0 designators corrected.',
    'independent_primary_review': 'Main directly inspected the pinned manual and sheet4 pixels, package XDC, and MCP4728 section7.1 text. No actual human review is claimed.',
    'editorial_corrections': changes,
    'editorial_reason': 'The actual physical PDF page is51, index50. Author conflict-check wording incorrectly said human-reviewed; review was by agents. Corrected accepted derivatives retain original raw hashes.',
    'digital_package_pins': 15, 'physical_J3_positions_unresolved': 2,
    'new_author_conflict_checks': 13, 'old44_checks_repeated': False,
    'board_effects': False, 'build_or_bitstream': 'not_run',
    'R02': 'not_run', 'R03': 'not_run', 'all29': 'not_run',
    'requirements_sha256': 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
}
save(D / 'review-final.json', summary)
save(A / 'manifest.json', {'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
                                    for p in sorted(A.iterdir())}})
print(json.dumps({'status': summary['status'], 'revised_files': len(m['files']),
                  'editorial_derivatives': len(changes), 'physical_J3_unresolved': 2}))
