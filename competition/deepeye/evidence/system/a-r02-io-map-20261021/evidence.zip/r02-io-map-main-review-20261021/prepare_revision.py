from pathlib import Path
import sys
import asyncio
from datetime import datetime, timezone
import hashlib
import json

D = Path(__file__).resolve().parent
O = D.parent
ROOT = O.parents[1]
sys.path.insert(0, str(ROOT))
from fpga_mesh.child_control import LocalControlFileClient
from fpga_mesh.project_cli import discovery

S = O / 'r02-io-map-design-20261021'
N = O / 'r02-io-map-revision-20261021'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())

def save(p, v):
    with p.open('x', encoding='utf-8') as f:
        json.dump(v, f, ensure_ascii=False, indent=2)
        f.write('\n')

m = read(S / 'manifest.json')
for pin in m['files']:
    p = S / pin['path']
    assert p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256']
raw = asyncio.run(LocalControlFileClient(discovery(ROOT)).call('job', {'job_id': 'child-82606ad92b9547a09679ea2d0795d647'}))
n = raw
if 'content' in n:
    n = json.loads(next(x['text'] for x in n['content'] if x['type'] == 'text'))
assert n['status'] == 'completed' and n['terminal'] and not n['stale']
findings = [
    {'id': 'P1-I2C-HEADER-CONFLICT',
     'finding': 'TUL manual Table16 says J3 pin9 AR_SDA and pin10 AR_SCL; retained schematic sheet4 rendered image says pin10 AR_SDA and pin9 AR_SCL. Candidate asserts manual positions without the contradictory primary evidence. Package P16 SDA/P15 SCL mapping is separately supported by XDC.',
     'required': 'Keep both source-specific header candidates, mark physical header position unresolved pending revision/net-continuity evidence. Package-only XDC may remain with explicit conflicting-header comments. Do not claim all15 physical connector positions qualified.'},
    {'id': 'P2-ONBOARD-PULLUPS',
     'finding': 'Schematic sheet4 shows R49/R50 2.2k from AR_SCL/SDA to VCC3V3. Candidate requires external pullups without counting board/module resistors.',
     'required': 'Record existing board pullups, no blind extra resistor set; compute effective combined value once module is known. Preserve open-drain design. Pin exact datasheet section for any suggested resistor range.'},
    {'id': 'P2-ADC-REFERENCE-DESIGNATORS',
     'finding': 'A0 is R71 2.32k/R105 1k/R72 140ohm/R73 845ohm/C3, not R74/R85.',
     'required': 'Correct the designators. Divider arithmetic and nominal header range remain supported.'},
]
save(D / 'original-native-job-readback.json', raw)
(D / 'original-native-result.txt').write_bytes(n['result']['text'].encode('utf-8'))
review = {'utc': datetime.now(timezone.utc).isoformat(),
          'status': 'REVISION_REQUIRED_BEFORE_WIRING_ADOPTION',
          'manifest_files_verified': len(m['files']), 'manifest_sha256': sha(S / 'manifest.json'),
          'native_completed_verified': True, 'findings': findings,
          'method': 'Independent rendered schematic/manual and official XDC review; original author44-check suite not repeated.',
          'board_effects': False, 'old_tests_repeated': False, 'all29': 'not_run'}
save(D / 'review-initial.json', review)
N.mkdir(exist_ok=False)
a = read(S / 'assignment.json')
a.update(work_id='A-R02-IO-MAP-REVISION-20261021-v1', ownership=[N.relative_to(ROOT).as_posix()],
         scope='Correct three main findings in a new successor candidate; preserve original sealed design. No board effects or repeated44-check suite.',
         main_review=(D / 'review-initial.json').relative_to(ROOT).as_posix(), review_findings=findings)
a['deliverables'] = ['Revised design.md, candidate-pinmap.json and package-only candidate.xdc; no uncertain connector position presented as certain',
    'revision-delta.json with exact evidence and each finding disposition; one new conflict-aware static check only',
    'source-pins.json, manifest.json, actual native validation/completion and exact final text; no printed lease tokens']
save(N / 'assignment.json', a)
save(N / 'reserve-request.json', {'task_id': a['task_id'], 'task_version': 1, 'work_id': a['work_id'],
    'ownership': a['ownership'], 'reason': 'Resolve primary-source header/pullup conflicts without board or old-test replay.',
    'text': json.dumps(a, ensure_ascii=False)})
print(json.dumps({'status': review['status'], 'manifest_files': len(m['files']), 'new_work': a['work_id']}))
