"""Record public owned-artifact hashes; exclude private lease and reservation input."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
excluded = {"assignment.json", "lease.private.json", "reserve-request.json", "reserve.stderr.txt", "manifest.json"}
files = []
for path in sorted(root.rglob("*")):
    if not path.is_file() or path.name in excluded:
        continue
    data = path.read_bytes()
    files.append({"path": path.relative_to(root).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
manifest = {
    "work_id": "A-R02-IO-MAP-DESIGN-20261021-v1",
    "owner": "/root/r03_ipc_framing_review_20261021",
    "scope": "Static candidate design only; no board, build, or formal R02 acceptance",
    "requirements_sha256": "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804",
    "static_check": "44/44 pass in static-check.json; one run",
    "files": files,
}
(root / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"files": len(files), "bytes": sum(f["bytes"] for f in files)}))
