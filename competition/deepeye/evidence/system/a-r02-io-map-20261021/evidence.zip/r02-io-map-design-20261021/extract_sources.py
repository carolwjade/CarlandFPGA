from pathlib import Path
import pypdfium2 as pdfium
root = Path(__file__).resolve().parent / "sources"
for pdf in root.glob("*.pdf"):
    try:
        reader = pdfium.PdfDocument(pdf.read_bytes())
    except Exception as exc:
        print(pdf.name, "FAILED", exc)
        continue
    text = []
    for index, page in enumerate(reader, 1):
        text.append(f"\n===== PDF PAGE {index} =====\n" + page.get_textpage().get_text_range())
    pdf.with_suffix(".txt").write_text("\n".join(text), encoding="utf-8")
    print(pdf.name, len(reader), sum(len(x) for x in text))
