from pathlib import Path
import pypdfium2 as pdfium
root = Path(__file__).resolve().parent / "sources"
for name, page_number in [("tul_pynq_z2_schematic_r12.pdf", 4), ("tul_pynq_z2_user_manual_v1_1.pdf", 28)]:
    src = root / name
    pdf = pdfium.PdfDocument(src.read_bytes())
    page = pdf[page_number - 1]
    out = root / f"{src.stem}-page{page_number}.png"
    page.render(scale=1.8).to_pil().save(out)
    print(out.name, out.stat().st_size)
