"""Build a source-pinned static candidate and perform one mapping consistency check."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "sources"
def digest(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
def put_json(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

source_definitions = [
    ("tul_manual", "tul_pynq_z2_user_manual_v1_1.pdf", "https://dpoauwgwqsy2x.cloudfront.net/Download/PYNQ_Z2_User_Manual_v1.1.pdf", "TUL PYNQ-Z2 Reference Manual v1.1, 28 Oct 2019", "PDF pp. 6, 19, 20-25; Tables 13-20, Figure 1"),
    ("tul_schematic", "tul_pynq_z2_schematic_r12.pdf", "https://dpoauwgwqsy2x.cloudfront.net/Download/TUL_PYNQ_Schematic_R12.pdf", "TUL download named R12; title block internally says PYNQ-Z2 R10, Jan 9 2018", "PDF sheets 3, 4, 11; Arduino A0-A5 divider R66-R71 2.32k, R100-R105 1k, 140/845-ohm XADC leg"),
    ("pynq_base_xdc", "pynq_z2_base_3_1_1.xdc", "https://raw.githubusercontent.com/Xilinx/PYNQ/3.1.1/boards/Pynq-Z2/base/vivado/constraints/base.xdc", "Xilinx/PYNQ release tag 3.1.1", "lines 56-68, 70-116"),
    ("tul_board_xml", "tul_pynq_z2_board_a0.xml", "https://raw.githubusercontent.com/Xilinx/XilinxBoardStore/master/boards/TUL/pynq-z2/A.0/board.xml", "XilinxBoardStore TUL pynq-z2 A.0 retrieved 2026-10-21; branch mutable, retained bytes pinned", "part identity only; not used as pin authority"),
    ("mcp6s21", "microchip_mcp6s21_ds21117b.pdf", "https://ww1.microchip.com/downloads/en/DeviceDoc/21117B.pdf", "Microchip DS21117B, 2012", "PDF pp. 1, 18-20: 8-pin pinout, SPI, gain register"),
    ("mcp4728", "microchip_mcp4728_ds22187e.pdf", "https://ww1.microchip.com/downloads/en/DeviceDoc/22187E.pdf", "Microchip DS22187E, 2010", "PDF pp. 1, 20-21, 50-51: supply, I2C pins/address and external pullups"),
    ("thvd1450", "ti_thvd1450.pdf", "https://www.ti.com/lit/ds/symlink/thvd1450.pdf", "TI SLLSEY3E Rev E, May 2019", "PDF pp. 1, 3-4, 21-22: 3-5.5V, R/D/DE/RE, half-duplex bus"),
]
sources = {key: {"file": "sources/" + name, "url": url, "revision": revision, "evidence": evidence, **digest(SRC / name)} for key, name, url, revision, evidence in source_definitions}
sources["notes"] = ["All retained PDF hashes are of complete locally parseable documents; the TUL manual local hash equals the publisher's x-amz-meta-sha256 header.", "TUL schematic filename says R12 while its PDF title blocks say R10; treat board revision compatibility as an unverified physical gate."]
put_json("source-pins.json", sources)

digital = [
    ("yaw_pwm_o", "PMODB", 1, "JB1_P", "W14", 34, "out", "yaw capture jumper to PMODB pin 7"),
    ("pitch_pwm_o", "PMODB", 2, "JB1_N", "Y14", 34, "out", "pitch capture jumper to PMODB pin 8"),
    ("speed_pwm_o", "PMODB", 3, "JB2_P", "T11", 34, "out", "speed capture jumper to PMODB pin 9"),
    ("yaw_capture_i", "PMODB", 7, "JB3_P", "V16", 34, "in", "external jumper from PMODB pin 1"),
    ("pitch_capture_i", "PMODB", 8, "JB3_N", "W16", 34, "in", "external jumper from PMODB pin 2"),
    ("speed_capture_i", "PMODB", 9, "JB4_P", "V12", 34, "in", "external jumper from PMODB pin 3"),
    ("pga_cs_n_o", "ARDUINO_SPI", 5, "AR_SS", "F16", 35, "out", "MCP6S21 CS, active low"),
    ("pga_sck_o", "ARDUINO_SPI", 3, "AR_SCK", "H15", 35, "out", "MCP6S21 SCK"),
    ("pga_sdi_o", "ARDUINO_SPI", 4, "AR_MOSI", "T12", 34, "out", "MCP6S21 SI; MISO unused"),
    ("dac_scl_io", "ARDUINO_J3", 10, "AR_SCL", "P15", 34, "bidir_open_drain", "MCP4728 SCL; external pullup to 3.3V"),
    ("dac_sda_io", "ARDUINO_J3", 9, "AR_SDA", "P16", 34, "bidir_open_drain", "MCP4728 SDA; external pullup to 3.3V"),
    ("rs485_tx_o", "ARDUINO_J4", 5, "AR4", "V15", 34, "out", "THVD1450 D/DI"),
    ("rs485_rx_i", "ARDUINO_J4", 6, "AR5", "T15", 34, "in", "THVD1450 R/RO"),
    ("rs485_de_o", "ARDUINO_J4", 7, "AR6", "R16", 34, "out", "THVD1450 DE; external 10k pull-down candidate"),
    ("rs485_re_n_o", "ARDUINO_J4", 8, "AR7", "U17", 34, "out", "THVD1450 /RE; external 10k pull-down candidate"),
]
signals = [{"port": port, "connector": connector, "position": position, "board_net": net, "package_pin": pin, "bank": bank, "iostandard": "LVCMOS33", "direction": direction, "external_connection": external, "source_refs": ["tul_manual", "tul_schematic", "pynq_base_xdc"]} for port, connector, position, net, pin, bank, direction, external in digital]
analog = [
    ("A0", 6, "VAUX1", "E17", "D18", "PGA VOUT after gain"),
    ("A1", 5, "VAUX9", "E18", "E19", "DAC B or pressure stimulus"),
    ("A2", 4, "VAUX6", "K14", "J14", "DAC C or obstacle stimulus"),
    ("A3", 3, "VAUX15", "K16", "J16", "same pre-PGA source as PGA CH0; reference ratio"),
]
analog_signals = [{"header": "ARDUINO_J1", "label": label, "position": position, "xadc_channel": channel, "xadc_package_p": p, "xadc_package_n": n, "bank": 35, "header_input_range_v": [0.0, 3.3], "xadc_pair_nominal_range_v": [0.0, 1.0], "front_end": "2.32k upper / 1k lower divider; 140 ohm P and 845 ohm N series; 1nF P-N filter; no board clamp identified", "role": role, "digital_tap_not_used": True, "source_refs": ["tul_manual", "tul_schematic", "pynq_base_xdc"]} for label, position, channel, p, n, role in analog]
candidate = {
    "status": "A-proposed static R02 candidate; pending main review, integrated-top adoption and physical board/wiring checks",
    "board_assumption": "TUL PYNQ-Z2 XC7Z020-1CLG400C with schematic-compatible expansion headers; actual board PCB revision not inspected",
    "requirements_sha256": "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804",
    "digital_signals": signals,
    "analog_signals": analog_signals,
    "reserved": {"PMODB": {"4": "T10 spare", "5": "GND", "6": "3.3V", "10": "W13 spare", "11": "GND", "12": "3.3V"}, "ARDUINO_SPI": {"1": "MISO W15 unused", "2": "3.3V", "6": "GND"}},
    "jumper_pairs": [{"axis": axis, "output_pmodb_pin": output, "capture_pmodb_pin": capture, "physical_external_jumper_required": True} for axis, output, capture in [("yaw", 1, 7), ("pitch", 2, 8), ("speed", 3, 9)]],
    "clock_reset": {"clock": "100 MHz PS FCLK0 generated by Zynq PS from 50 MHz PS_CLK; no external PL package-pin XDC line. Board also exposes a distinct 125 MHz PL Ethernet-PHY reference on H16, not the selected 100 MHz source.", "reset": "PS FCLK_RESET0_N through processor_system_reset, synchronous deassertion in 100 MHz domain; no Arduino J7 AR_RST/PS MIO12 as PL reset pin", "integration_gate": "BD/top clock frequency and reset polarity must be proven by Vivado generated constraints and HWH before implementation"},
    "external_devices": {"pga": "proposed MCP6S21 at 3.3V; SPI CS/SCK/SI only, no SO; VSS and VREF to GND for unipolar stimulus; CH0 from same source tapped to A3; VOUT to A0. Gain write then verify measured A0/A3 ratio within unsaturated range; no register echo", "dac": "proposed MCP4728 at 3.3V, 4 channels and I2C open-drain; external SDA/SCL pullups to 3.3V, 1-10k selected by bus capacitance/speed; 7-bit address depends on EEPROM bits and must be read on actual module; DAC A feeds PGA CH0 and A3, B->A1, C->A2, D spare/controlled stimulus", "rs485": "proposed TI THVD1450 at 3.3V half-duplex; D/RO/DE and active-low /RE connect to PL; transceiver A/B differential pair to PC-side RS485 adapter, common reference/termination/bias per cable topology; never wire A/B to PL GPIO"},
    "source_keys": list(sources.keys())[:-1]
}
put_json("candidate-pinmap.json", candidate)

xdc = ["# A R02 proposed package constraints only; names must match a future integrated top.", "# PYNQ-Z2: TUL manual v1.1 Tables 14,16,17,19; Xilinx/PYNQ 3.1.1 base.xdc.", "# DO NOT concatenate with base.xdc for the same ports; use one allocation."]
for row in signals:
    xdc.append(f"set_property -dict {{PACKAGE_PIN {row['package_pin']} IOSTANDARD LVCMOS33}} [get_ports {{{row['port']}}}]  ;# {row['connector']} pin {row['position']} {row['board_net']}")
xdc += ["", "# VAUX1/9/6/15 analog pins are intentionally absent here: instantiate/configure XADC", "# against A0-A3 with bank-35 VAUX P/N pairs; do not drive their Arduino digital taps.", "# PS FCLK0 100 MHz and FCLK_RESET0_N are generated BD nets, not package pins.", "# Add timing/reset constraints only after integrated BD/top and generated clocks are inspected.", "# I2C requires IOBUF/open-drain RTL and real external 3.3 V pullups; XDC alone is insufficient."]
(ROOT / "candidate.xdc").write_text("\n".join(xdc) + "\n", encoding="utf-8")

# One focused static consistency check against retained official pin tables.
base = (SRC / "pynq_z2_base_3_1_1.xdc").read_text(encoding="utf-8")
sch = (SRC / "tul_pynq_z2_schematic_r12.txt").read_text(encoding="utf-8")
checks = []
def check(name, condition, detail=""):
    checks.append({"check": name, "pass": bool(condition), "detail": detail})
check("digital_port_unique", len({r["port"] for r in signals}) == len(signals))
check("digital_package_pin_unique", len({r["package_pin"] for r in signals}) == len(signals))
check("digital_connector_position_unique", len({(r["connector"], r["position"]) for r in signals}) == len(signals))
check("six_independent_pwm_capture", len([r for r in signals if "pwm_o" in r["port"]]) == 3 and len([r for r in signals if "capture_i" in r["port"]]) == 3 and len({x for row in candidate["jumper_pairs"] for x in (row["output_pmodb_pin"], row["capture_pmodb_pin"])}) == 6)
check("power_ground_not_allocated", not any(r["connector"] == "PMODB" and r["position"] in {5,6,11,12} for r in signals))
for row in signals:
    pin = row["package_pin"]
    check(f"xdc_{row['port']}", bool(re.search(rf"PACKAGE_PIN\s+{pin}\s+IOSTANDARD\s+LVCMOS33", base)), pin)
    check(f"bank_{row['port']}", bool(re.search(rf"IO_[A-Z0-9_]+_{row['bank']}\s+{pin}\b", sch)), f"{pin} bank {row['bank']}")
for row in analog_signals:
    for polarity, pin in [("P", row["xadc_package_p"]), ("N", row["xadc_package_n"])]:
        check(f"analog_{row['label']}_{polarity}", bool(re.search(rf"PACKAGE_PIN\s+{pin}\s+IOSTANDARD", base)) and bool(re.search(rf"IO_[A-Z0-9_]+AD\d+{polarity}_35\s+{pin}\b", sch)), pin)
check("all_sources_parseable", all((SRC / name).stat().st_size > 1000 for _, name, *_ in source_definitions))
result = {"scope": "one new static allocation check; no toolchain, board or old test run", "checks": checks, "pass_count": sum(x["pass"] for x in checks), "fail_count": sum(not x["pass"] for x in checks)}
put_json("static-check.json", result)
print(json.dumps({"digital": len(signals), "analog": len(analog_signals), "checks": len(checks), "pass": result["pass_count"], "fail": result["fail_count"]}))
