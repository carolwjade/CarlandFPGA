"""Archive owned design/review, keeping vendor originals in the pinned local cache."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

D = Path(__file__).resolve().parent
O = D.parent
ROOT = O.parents[1]
PRODUCT = ROOT / '.local/deepeye-implementation-a'
R = O / 'r02-io-map-main-review-20261021'
A = R / 'accepted'
T = PRODUCT / 'competition/deepeye/evidence/system/a-r02-io-map-20261021'
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda v: (json.dumps(v, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()

def write(p, raw):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(raw)

review = read(R / 'review-final.json')
assert review['status'] == 'ACCEPT_STATIC_PACKAGE_CANDIDATE_WITH_PHYSICAL_J3_HOLD'
members = {}
omitted = {}
tokens = []
for folder in ('r02-io-map-design-20261021', 'r02-io-map-revision-20261021'):
    value = read(O / folder / 'lease.private.json')
    if 'content' in value:
        value = json.loads(next(x['text'] for x in value['content'] if x['type'] == 'text'))
    tokens.append(value['lease_token'].encode())

def add(p):
    raw = p.read_bytes()
    name = p.relative_to(O).as_posix()
    assert name not in members and not any(token in raw for token in tokens), name
    assert 'private' not in p.name and p.name != 'reserve-request.json'
    members[name] = raw

for folder in ('r02-io-map-design-20261021', 'r02-io-map-revision-20261021'):
    S = O / folder
    for pin in read(S / 'manifest.json')['files']:
        p = S / pin['path']
        raw = p.read_bytes()
        assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256']
        if pin['path'].startswith('sources/'):
            omitted[p.relative_to(O).as_posix()] = pin
        else:
            add(p)
    add(S / 'manifest.json')
for p in sorted(R.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts:
        add(p)
for name, pin in read(A / 'manifest.json')['files'].items():
    raw = (A / name).read_bytes()
    assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256']
catalog = {k: {key: value for key, value in pin.items() if key != 'file'}
           for k, pin in read(A / 'source-pins.json').items()
           if isinstance(pin, dict) and 'url' in pin}
summary = {'utc': datetime.now(timezone.utc).isoformat(), 'review': review,
           'original_vendor_files_retained_locally': omitted,
           'source_catalog': catalog,
           'old_tests_repeated': False, 'board_effects': False,
           'physical_wiring': 'not_verified', 'R02': 'not_run', 'R03': 'not_run', 'all29': 'not_run'}
members['main/summary.json'] = encode(summary)
members['main/prepare.py'] = Path(__file__).read_bytes()
T.mkdir(parents=True, exist_ok=False)
with zipfile.ZipFile(T / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(members.items()):
        info = zipfile.ZipInfo(name, (2026, 10, 21, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, raw)
with zipfile.ZipFile(T / 'evidence.zip') as z:
    assert z.testzip() is None and set(z.namelist()) == set(members)
    for name, raw in members.items():
        assert z.read(name) == raw
write(T / '.gitattributes', b'* -text -eol -filter\n')
write(T / 'archive-index.json', encode({n: {'bytes': len(v), 'sha256': sha(v)} for n, v in sorted(members.items())}))
write(T / 'summary.json', encode(summary))
write(T / 'sources.json', encode(catalog))
for name in ('design.md', 'candidate-pinmap.json', 'candidate.xdc'):
    write(T / name, (A / name).read_bytes())
write(T / 'README.md', (D / 'README-source.md').read_bytes())
write(T / 'manifest.json', encode({'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                                            for p in sorted(T.iterdir())},
                                  'archive_members': len(members), 'exact_member_bytes_and_crc_checked': True}))
guide = PRODUCT / 'competition/deepeye/docs/pynq_z2_io_candidate_20261021.md'
write(guide, b'# PYNQ-Z2 package and electrical integration candidate\n\n'
      b'See the [reviewed R02 candidate](../evidence/system/a-r02-io-map-20261021/README.md).\n'
      b'Fifteen package pins, four ADC channels and three external PWM/capture pairs\n'
      b'are documented for the future custom top. The J3 I2C contact numbers conflict\n'
      b'in primary sources and must be resolved on the actual PCB before wiring.\n'
      b'No physical, bitstream or full R02/R03 acceptance is claimed.\n')
paths = [*sorted(T.iterdir()), guide]
files = {p.relative_to(PRODUCT).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in paths}
write(D / 'publication-files.json', encode(files))
write(D / 'owned-paths.nul', b''.join(name.encode() + b'\0' for name in files))
result = {'files': len(files), 'archive_members': len(members),
          'archive_bytes': (T / 'evidence.zip').stat().st_size,
          'archive_sha256': sha((T / 'evidence.zip').read_bytes()), 'local_vendor_files_omitted': len(omitted)}
write(D / 'package-summary.json', encode(result))
print(json.dumps(result))
