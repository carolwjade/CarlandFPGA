"""Run once: focused source-conflict checks for only the three review findings."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent
old = root.parent / "r02-io-map-design-20261021"
candidate = json.loads((root / "candidate-pinmap.json").read_text(encoding="utf-8"))
sources = json.loads((root / "source-pins.json").read_text(encoding="utf-8"))
delta = json.loads((root / "revision-delta.json").read_text(encoding="utf-8"))
manual = (old / "sources/tul_pynq_z2_user_manual_v1_1.txt").read_text(encoding="utf-8")
schematic = (old / "sources/tul_pynq_z2_schematic_r12.txt").read_text(encoding="utf-8")
base_xdc = (old / "sources/pynq_z2_base_3_1_1.xdc").read_text(encoding="utf-8")
design = (root / "design.md").read_text(encoding="utf-8")
xdc = (root / "candidate.xdc").read_text(encoding="utf-8")
rows = {r["port"]: r for r in candidate["digital_signals"]}
checks = []

def record(name, passed, evidence):
    checks.append({"name": name, "pass": bool(passed), "evidence": evidence})

record("manual_J3_alternatives", "AR_SDA SDA 9 P16" in manual and "AR_SCL SCL 10 P15" in manual, "TUL manual v1.1 Table 16 text, original PDF pinned in source-pins.json")
record("schematic_primary_visual_identity", hashlib.sha256((old / "sources/tul_pynq_z2_schematic_r12-page4.png").read_bytes()).hexdigest() == "275ffff468b2b1b35fa4ffbb8e25f0a60377be34c3824cdbd8ca35d5ba102886", "Human-reviewed TUL schematic sheet 4 image: J3 10 SDA / 9 SCL; original retained PNG hash")
record("both_I2C_positions_unresolved", all(rows[p]["position"] is None and rows[p]["physical_position_status"] == "UNRESOLVED_SOURCE_CONFLICT" for p in ("dac_scl_io", "dac_sda_io")), "Successor JSON physical position null for both lines")
record("both_source_candidates_kept", rows["dac_scl_io"]["position_candidates"] == {"TUL_manual_v1_1_table16": 10, "TUL_schematic_download_R12_internal_title_R10_sheet4": 9} and rows["dac_sda_io"]["position_candidates"] == {"TUL_manual_v1_1_table16": 9, "TUL_schematic_download_R12_internal_title_R10_sheet4": 10}, "Source-specific contact numbers preserved")
record("package_P15_P16_still_supported", bool(re.search(r"PACKAGE_PIN P15 IOSTANDARD LVCMOS33.*arduino_direct_iic_scl_io", base_xdc)) and bool(re.search(r"PACKAGE_PIN P16 IOSTANDARD LVCMOS33.*arduino_direct_iic_sda_io", base_xdc)) and "PACKAGE_PIN P15" in xdc and "PACKAGE_PIN P16" in xdc, "Xilinx/PYNQ 3.1.1 base.xdc lines 93-94 and successor package-only XDC")
record("XDC_warns_no_physical_contact_claim", "physical contact UNRESOLVED" in xdc and "manual 10; schematic 9" in xdc and "manual 9; schematic 10" in xdc, "No certain J3 position in I2C constraint comments")
record("board_pullup_parts_in_primary_text", all(re.search(rf"{part}\s+2\.2K\s+1%", schematic) for part in ("R49", "R50")), "TUL schematic sheet 4 component text; visual inspection establishes connection to VCC3V3")
record("no_unconditional_extra_pullup", "before adding a resistor" in design and "do not add blindly" in xdc and "external pull-ups to 3.3 V" not in design, "Open-drain preserved; onboard/module network must be checked")
record("parallel_example", abs(1 / (1 / 2200 + 1 / 10000) - 1803.2786885245903) < 0.01 and "1.803 kΩ" in design, "Single board 2.2k plus one module 10k: ~1.803k; actual module unverified")
record("A0_parts_present_in_primary", all(re.search(rf"{part}\s+{value}", schematic) for part, value in [("R71", "2.32K"), ("R105", "1K"), ("R72", "140"), ("R73", "845"), ("C3", "1000pF")]), "TUL schematic sheet 4 text and human-reviewed image")
record("A0_designators_corrected", "R71 2.32 kΩ" in design and "R105 1 kΩ" in design and "R72 140 Ω" in design and "R73 845 Ω" in design and "C3 1 nF" in design and "R74/R85" not in design, "Successor design names corrected A0 components")
record("datasheet_section_pinned", "section 7.1" in sources["mcp4728"]["evidence"] and "DS22187E §7.1" in design, "Microchip MCP4728 DS22187E §7.1 printed p.51/PDF p.50")
record("review_finding_coverage", {f["id"] for f in delta["findings"]} == {"P1-I2C-HEADER-CONFLICT", "P2-ONBOARD-PULLUPS", "P2-ADC-REFERENCE-DESIGNATORS"}, "Only the three assigned findings")

result = {"scope": "Only successor revision findings; predecessor 44 checks not rerun", "source_visual_limit": "Schematic connectivity and contact order were visually read from the pinned rendered official sheet; regex checks only verify text/component presence and cannot prove topology.", "checks": checks, "passed": sum(x["pass"] for x in checks), "failed": sum(not x["pass"] for x in checks)}
(root / "conflict-check.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"checks": len(checks), "passed": result["passed"], "failed": result["failed"]}))
