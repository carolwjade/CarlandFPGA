"""Create the public successor manifest from owned files only."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
excluded = {"assignment.json", "lease.private.json", "reserve-request.json", "reserve.stderr.txt", "manifest.json"}
files = []
for file in sorted(root.rglob("*")):
    if file.is_file() and file.name not in excluded:
        data = file.read_bytes()
        files.append({"path": file.relative_to(root).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
manifest = {
    "work_id": "A-R02-IO-MAP-REVISION-20261021-v1",
    "owner": "/root/r03_ipc_framing_review_20261021",
    "scope": "Successor static design correction only; J3 physical I2C contact positions unresolved",
    "predecessor_manifest_sha256": "09dd6f3133b6e468ec9beb8dfc9533e2c3bad9c8b8a5d47cea6943bf43540c84",
    "requirements_sha256": "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804",
    "new_conflict_check": "13/13 pass once; predecessor 44 not rerun",
    "files": files,
}
(root / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"files": len(files), "bytes": sum(f["bytes"] for f in files)}))
