"""Apply only the three accepted review corrections to a successor copy."""
from pathlib import Path
import json

root = Path(__file__).resolve().parent

pinmap_path = root / "candidate-pinmap.json"
pinmap = json.loads(pinmap_path.read_text(encoding="utf-8"))
pinmap["status"] = "A-proposed revised static R02 candidate; I2C J3 contact positions unresolved pending actual board revision/net continuity; main review and integrated-top adoption pending"
for row in pinmap["digital_signals"]:
    if row["port"] in {"dac_scl_io", "dac_sda_io"}:
        scl = row["port"] == "dac_scl_io"
        row["position"] = None
        row["physical_position_status"] = "UNRESOLVED_SOURCE_CONFLICT"
        row["position_candidates"] = {
            "TUL_manual_v1_1_table16": 10 if scl else 9,
            "TUL_schematic_download_R12_internal_title_R10_sheet4": 9 if scl else 10,
        }
        row["external_connection"] = "MCP4728 " + ("SCL" if scl else "SDA") + "; open drain; board schematic R49/R50 already show 2.2k pullups to VCC3V3; verify fitted board and module pullup parallel value before adding any resistor"
        row["source_conflict"] = "Package pin and board net remain supported by Xilinx/PYNQ XDC; physical J3 contact number cannot be selected from conflicting TUL primary documents."
pinmap["external_devices"]["dac"] = "Proposed MCP4728 at 3.3V, 4 channels and I2C open-drain. TUL schematic sheet4 shows board R49/R50 nominal 2.2k pullups from AR_SCL/AR_SDA to VCC3V3; confirm fitted PCB and every module/adapter pullup before adding any external resistor; parallel equivalent is 1/(1/2200 + sum(1/Rmodule_i)) ohms. Microchip DS22187E section 7.1 describes typically 1-10k for standard/fast modes, with its Fig 7-1 showing 5-10k for 100-400kHz example; actual rise time and sink current depend on total bus capacitance. 7-bit address depends on EEPROM bits and actual module. DAC A feeds PGA CH0 and A3; B->A1; C->A2; D spare. J3 SCL/SDA physical contact numbers unresolved owing to manual/schematic conflict."
pinmap["physical_wiring_gate"] = "Resolve J3 SCL/SDA contact numbers on the actual PCB/revision with authoritative as-built documentation or de-energized continuity before attaching the DAC; do not use the manual or schematic number alone."
pinmap_path.write_text(json.dumps(pinmap, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

xdc_path = root / "candidate.xdc"
xdc = xdc_path.read_text(encoding="utf-8")
xdc = xdc.replace("# PYNQ-Z2: TUL manual v1.1 Tables 14,16,17,19; Xilinx/PYNQ 3.1.1 base.xdc.", "# PYNQ-Z2: TUL manual v1.1 and schematic, Xilinx/PYNQ 3.1.1 base.xdc.\n# WARNING: J3 I2C physical positions CONFLICT: manual Table16 SCL=10/SDA=9,\n# schematic sheet4 SCL=9/SDA=10. P15/P16 package nets remain XDC-supported;\n# resolve actual PCB revision/net continuity before connecting any I2C cable.")
xdc = xdc.replace(";# ARDUINO_J3 pin 10 AR_SCL", ";# AR_SCL, J3 physical contact UNRESOLVED (manual 10; schematic 9)")
xdc = xdc.replace(";# ARDUINO_J3 pin 9 AR_SDA", ";# AR_SDA, J3 physical contact UNRESOLVED (manual 9; schematic 10)")
xdc = xdc.replace("# I2C requires IOBUF/open-drain RTL and real external 3.3 V pullups; XDC alone is insufficient.", "# I2C requires IOBUF/open-drain RTL; schematic R49/R50 show 2.2k to 3.3 V.\n# Verify actual board/module pullups and parallel value; do not add blindly.")
xdc_path.write_text(xdc, encoding="utf-8")

design_path = root / "design.md"
design = design_path.read_text(encoding="utf-8")
design = design.replace("TUL manual v1.1 Tables 14, 16, 17 and 19 give connector positions.", "TUL manual v1.1 Tables 14, 17 and 19 support the PMODB, J4 and SPI positions. Manual Table 16 and schematic sheet 4 conflict on J3 I2C contact numbers; those two positions remain unresolved.")
design = design.replace("| `dac_scl_io` | Arduino J3:10 AR_SCL | P15 / 34 | open-drain I2C SCL |", "| `dac_scl_io` | Arduino J3: **unresolved** AR_SCL (manual:10; schematic:9) | P15 / 34 | open-drain I2C SCL |")
design = design.replace("| `dac_sda_io` | Arduino J3:9 AR_SDA | P16 / 34 | open-drain I2C SDA |", "| `dac_sda_io` | Arduino J3: **unresolved** AR_SDA (manual:9; schematic:10) | P16 / 34 | open-drain I2C SDA |")
design = design.replace("(for A0, R71/R105/R74/R85 and C3)", "(for A0, upper R71 2.32 kΩ, lower R105 1 kΩ, positive-series R72 140 Ω, negative-series R73 845 Ω, and C3 1 nF)")
design = design.replace("Both I2C lines must be open-drain via PL IOBUF with external pull-ups to 3.3 V (datasheet typical 1–10 kΩ at standard/fast rate; final values depend on capacitance and clock).", "Both I2C lines must be open-drain via PL IOBUF. TUL schematic sheet 4 already depicts R49/R50, each 2.2 kΩ from AR_SCL/AR_SDA to VCC3V3; inspect actual fitted PCB and any DAC-module/adapter pull-ups before adding a resistor. If fitted, total bus pull-up is `R_eq = 1/(1/2200 + Σ_i 1/R_module_i)` Ω. For example, one additional 10 kΩ to the same 3.3 V rail would give approximately 1.803 kΩ, not 10 kΩ. Microchip DS22187E §7.1 (printed p. 51, PDF p. 50) describes a typical 1–10 kΩ range for standard/fast modes and Fig. 7-1 illustrates 5–10 kΩ for 100–400 kHz; choose against actual capacitance, rise time and sink current, not an unverified extra resistor set. J3 physical contact numbers are conflicting: manual v1.1 Table 16 assigns SCL=10/SDA=9, while downloaded TUL schematic sheet 4 assigns SCL=9/SDA=10. The P15 SCL/P16 SDA package-net assignments agree with the pinned Xilinx/PYNQ 3.1.1 XDC. Resolve the physical contacts from actual PCB revision or de-energized continuity before connecting a module; do not treat either document alone as proof of contact position.")
design = design.replace("The new `static-check.json` records one 44/44 static consistency pass: unique ports/pins/connector positions, six distinct PMODB PWM/capture contacts, power/GND avoidance, official XDC package-pin matches, schematic bank/pin matches, and XADC pair matches. This proves only candidate internal consistency.", "The predecessor's 44/44 static check remains historical evidence for the first draft; it did not detect the J3 primary-source conflict or the board pull-ups. The successor's `conflict-check.json` checks only the three changed issues and requires both J3 alternatives to remain unresolved. Neither check proves actual contact placement or electrical behavior.")
design = design.replace("Source bytes, hashes and page/table pins are in `source-pins.json`; retained originals are under `sources/`.", "Source URLs, bytes, hashes and page/table pins are in `source-pins.json`; this successor references the predecessor's sealed retained originals without modifying them.")
design = design.replace("# A R02 future-overlay pin and electrical candidate — static only", "# A R02 revised future-overlay pin and electrical candidate — static only")
design = design.replace("## Digital allocation", "## Digital allocation\n\n**Wiring hold:** J3 I2C SCL/SDA physical contact positions are unresolved. The package-only constraints below do not license a physical J3 cable assignment.")
design_path.write_text(design, encoding="utf-8")

sources_path = root / "source-pins.json"
sources = json.loads(sources_path.read_text(encoding="utf-8"))
for value in sources.values():
    if isinstance(value, dict) and value.get("file", "").startswith("sources/"):
        value["file"] = "../r02-io-map-design-20261021/" + value["file"]
sources["tul_manual"]["evidence"] += "; Table 16 says J3 pin 9 SDA, pin 10 SCL"
sources["tul_schematic"]["evidence"] += "; sheet 4 draws J3 pin 10 SDA, pin 9 SCL, R49/R50 each 2.2k to VCC3V3, and A0 R71/R105/R72/R73/C3"
sources["pynq_base_xdc"]["evidence"] += "; lines 93-94 bind package P15=SCL and P16=SDA independent of J3 physical position"
sources["mcp4728"]["evidence"] += "; section 7.1 printed p. 51/PDF p. 50 pull-up sizing"
sources["predecessor_manifest"] = {"file": "../r02-io-map-design-20261021/manifest.json", "sha256": "09dd6f3133b6e468ec9beb8dfc9533e2c3bad9c8b8a5d47cea6943bf43540c84", "verified_by_main": True}
sources_path.write_text(json.dumps(sources, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

delta = {
    "predecessor_work_id": "A-R02-IO-MAP-DESIGN-20261021-v1",
    "successor_work_id": "A-R02-IO-MAP-REVISION-20261021-v1",
    "predecessor_manifest_sha256": "09dd6f3133b6e468ec9beb8dfc9533e2c3bad9c8b8a5d47cea6943bf43540c84",
    "review_status": "REVISION_REQUIRED_BEFORE_WIRING_ADOPTION",
    "findings": [
        {"id": "P1-I2C-HEADER-CONFLICT", "disposition": "Accepted; J3 physical positions null/unresolved in JSON, both primary candidates retained, package-only XDC comments explicitly warn", "manual": {"SCL": 10, "SDA": 9}, "schematic": {"SCL": 9, "SDA": 10}, "package": {"SCL": "P15", "SDA": "P16"}, "remaining_gate": "actual board revision or de-energized net continuity before I2C wiring"},
        {"id": "P2-ONBOARD-PULLUPS", "disposition": "Accepted; schematic R49/R50 nominal 2.2k to VCC3V3 recorded, no unconditional added set", "equivalent_formula_ohm": "1/(1/2200 + sum(1/Rmodule_i))", "datasheet": "Microchip MCP4728 DS22187E section 7.1, printed p.51/PDF p.50; 1-10k typical standard/fast, Figure 7-1 5-10k at 100-400kHz", "remaining_gate": "inspect actual fitted board and module pullups, calculate net equivalent and rise/sink margins"},
        {"id": "P2-ADC-REFERENCE-DESIGNATORS", "disposition": "Accepted; A0 designators corrected", "A0": {"upper_2320_ohm": "R71", "lower_1000_ohm": "R105", "p_series_140_ohm": "R72", "n_series_845_ohm": "R73", "filter_1nF": "C3"}},
    ],
    "unchanged_scope": "All other proposed digital package pins, PMODB external pairs, analog channel allocation, device proposals and clock/reset concept remain static, unadopted candidates; original sealed bytes unchanged.",
    "acceptance": "No physical board/wiring, XDC integration, toolchain or formal R02/R03/all29 evidence."
}
(root / "revision-delta.json").write_text(json.dumps(delta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("revised successor design, pinmap, XDC, sources and delta")
