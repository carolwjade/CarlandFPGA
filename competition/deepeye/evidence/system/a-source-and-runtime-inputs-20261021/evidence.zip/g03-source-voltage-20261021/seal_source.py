"""Stdlib seal of new evidence; never recompute a scientific result."""
from datetime import datetime,timezone
import hashlib,json
from pathlib import Path
import sys
D=Path(__file__).resolve().parent;ROOT=D.parents[2];sys.path.insert(0,str(D))
from run_source import inputs
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')

assert inputs()==read(D/'input-pins.json')
for p in D.glob('*.py'):compile(p.read_text(encoding='utf-8'),str(p),'exec')
stages=[]
for label,exitcode in (('controls-red-01',1),('controls-01',0),('run-01',0)):
    t=read(D/label/'terminal.json')
    assert t['exit_code']==exitcode and t['all_processes_terminated'] and t['active_processes_final']==0
    assert not t['absent_before_handle_open'] and all(m['signaled'] and m['wait_result']==0 for m in t['held_members'])
    stages.append({'stage':label,'exit_code':t['exit_code'],'seconds':t['seconds'],'held_members':t['held_members'],
                   'raw_terminal_sha256':sha(D/label/'terminal.json')})
control=read(D/'controls-01/control-result.json');assert control['success'] and control['tests']==2 and control['old_tests_repeated']==0
for label in ('controls-red-01','controls-01','run-01'):
    identity=read(D/label/'worker-identity.json')
    assert not identity['simpeg_loaded']
    assert all(r['num_threads']==1 for r in identity['blas_before']+identity['blas_after'])
    assert read(D/label/'input-readback.json')['unchanged']
result=read(D/'run-01/source-voltage-result.json')
assert result['interior_source_exact_zero'] and result['counts']['RHS_columns']==1
assert result['counts']['A_assemblies']==result['counts']['C_constructions']==result['counts']['old_sampler_calls']==0
assert result['backward_residual']['eta']<=result['backward_residual']['gate']
sources={
 'simpeg/electromagnetics/utils/current_utils.py':[(7,41),(55,109)],
 'simpeg/electromagnetics/frequency_domain/sources.py':[(1318,1336),(1393,1411)],
 'simpeg/electromagnetics/frequency_domain/simulation.py':[(635,655),(806,839)],
 'discretize/operators/differential_operators.py':[(2170,2181)]}
site=ROOT/'.local/deepeye-fdem-validation-20261020/Lib/site-packages';evidence=[]
for name,ranges in sources.items():
    path=site/name;lines=path.read_text(encoding='utf-8').splitlines()
    evidence.append({'repo_path':path.relative_to(ROOT).as_posix(),'sha256':sha(path),
                     'excerpts':[{'start_line':a,'end_line':b,'text':'\n'.join(lines[a-1:b])} for a,b in ranges]})
save(D/'source-evidence.json',{'scope':'read-only installed EB source conventions; not source execution','sources':evidence})
summary={'utc':datetime.now(timezone.utc).isoformat(),'work_id':'A-G03-SOURCE-VOLTAGE-20261021-v1',
 'job_id':'child-0e26dec9138446ab9b8591ecf2dcb5c9','requirements_sha256':read(D/'assignment.json')['requirements_sha256'],
 'new_source_control_groups':2,'old_tests_repeated':0,'new_actual_fixed_runs':1,'stages':stages,
 'source_interior_exact_zero':True,'absolute_voltage_relative_difference':result['relative_difference'],
 'counts':result['counts'],'receiver_accuracy_qualification':'open','main_independent_acceptance':'pending',
 'G03':'not_run','R03':'not_run','H12':'not_run','all29':'not_run','input_bytes_unchanged':True}
save(D/'result.json',summary)
text=('New source/absolute-voltage diagnostic completed for A-G03-SOURCE-VOLTAGE-20261021-v1; job child-0e26dec9138446ab9b8591ecf2dcb5c9.\n'
      'Two new source-control groups passed once. Old tests repeated: 0. One actual cached-operator run, exit 0; one weak-source projection, one 6x6 LU, one solve/one RHS column, 384 Green evaluations for the two receivers at 64/128 orders. New A/C assembly and old sampler/SimPEG calls: 0.\n'
      'Compatible source proof is restricted to the fixed symmetric circle and installed bilinear edge basis. Independent line-integral, moment, divergence, sign/phase and refusal controls passed. All six interior weak-source entries are exactly zero; source support is entirely on eight prescribed boundary edges. Therefore this coarse interior solve is boundary-driven and does not demonstrate resolved local source forcing.\n'
      'Finite/reference relative differences are 0.934164478734929 and 0.7874690186755858. Backward residual eta=1.4124006246694593e-16, unchanged gate=2.842170943040401e-14. Reference 128-minus-64 magnitudes are 1.2735417772833305e-15 and 7.696236351192624e-16 V; observed convergence only, no rigorous physical error certificate.\n'
      'Actual run whole-tree time 1.328s, peak job memory 128630784 bytes, all three original held objects signaled exit 0. Across the three new stages all nine held process objects signaled; RED absence failure retained. BLAS1 before/after; inputs unchanged. All writes in assigned directory; no UI/network/board/product/service/provider/credential/group/peer actions.\n'
      'Delivered exact source/input/public pins, raw arrays/logs/process terminals, restricted basis derivation, separate coaxial reference and unselected successor mesh suggestions. G03/R03/H12/all29 remain not_run, receiver qualification open, main acceptance pending. H01-H15 preserved; requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.\n')
with (D/'final-result.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
files=[]
exclude={'lease.private.json','reserve-request.json','native-owner.json','public-manifest.json','native-complete-response.json'}
for p in sorted(D.rglob('*')):
    if p.is_file() and p.name not in exclude and '.private.' not in p.name:
        files.append({'path':p.relative_to(D).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
save(D/'public-manifest.json',{'files':files,'exclusions':sorted(exclude)+['*.private.*'],
 'input_pins_sha256':sha(D/'input-pins.json'),'source_voltage_result_sha256':sha(D/'run-01/source-voltage-result.json'),
 'source_code_pins':{p.name:sha(p) for p in sorted(D.glob('*.py'))}})
print(json.dumps({'files':len(files),'result_sha256':sha(D/'result.json'),
 'science_result_sha256':sha(D/'run-01/source-voltage-result.json'),'public_manifest_sha256':sha(D/'public-manifest.json')}))
