"""Granted worker: new source controls or one selected cached-operator solve."""
import importlib.util,json,math,os
from pathlib import Path
import sys,time,unittest
D=Path(__file__).resolve().parent
stage=Path(sys.argv[1]);mode=sys.argv[2]
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
save(stage/'hello.json',{'pid':os.getpid(),'before_scientific_import':True})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('no science grant')
    time.sleep(.01)
grant=json.loads((stage/'grant.json').read_text());assert grant['worker']['pid']==os.getpid()
assert grant['mode']==('actual_source_voltage' if mode=='actual' else 'new_source_controls')
def audit(event,args):
    if event=='import' and args[0].split('.')[0]=='simpeg':raise RuntimeError('No SimPEG execution in cached-operator job')
sys.addaudithook(audit)
import numpy as np
from scipy import linalg,sparse
sys.path.insert(0,str(D))
old=D.parent/'g03-finite-coil-transfer-preparation-20261021'
spec=importlib.util.spec_from_file_location('previous_driver_identity_only',old/'fixed_transfer_driver.py')
identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
before=identity.actual_threads()
metrics={}

class SourceControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        global api
        if not (D/'source_voltage.py').exists():raise AssertionError('new source projection implementation absent; expected RED')
        import source_voltage
        api=source_voltage

    def test_compatible_stokes_line_oracle_and_moment(self):
        # C transpose or interpolation-basis mistake breaks independent line sum.
        C=api.load_cached_curl()
        nodes=api.saved_nodes()
        s,w=api.project_source(C,nodes)
        line,absolute_integral=api.independent_line_oracle(nodes,16)
        api.compare(s,line,np.abs(s)+absolute_integral)
        starts,ends,lengths,G=api.edges_and_gradient(nodes)
        div=np.asarray(G.T@s).ravel();scale=np.asarray(abs(G.T)@abs(s)).ravel()
        api.compare(div,np.zeros(27),scale)
        centers=(starts+ends)/2
        rotational=np.zeros(54)
        rotational[:18]=-centers[:18,1]/2
        rotational[18:36]=centers[18:36,0]/2
        area=math.pi*.05**2
        moment=np.dot(s,rotational)
        api.compare(np.array([moment]),np.array([area]),np.array([abs(s)@abs(rotational)+area]))
        for axis,block in enumerate((slice(0,18),slice(18,36),slice(36,54))):
            constant=np.zeros(54);constant[block]=1
            api.compare(np.array([s@constant]),np.zeros(1),np.array([abs(s)@constant]))
        interior=np.load(D.parent/'g03-fixed-transfer-main-20261021/run-01/interior_indices.npy',allow_pickle=False)
        self.assertTrue(np.array_equal(s[interior],np.zeros(6)))
        metrics['source_control']={'line_oracle_max_difference_Am':float(max(abs(s-line))),
            'source_nonzero_global_edges':np.flatnonzero(s).tolist(),'interior_source_exact_zero':True,
            'moment_Am2':float(moment.real),'expected_moment_Am2':area,'divergence_max_A':float(max(abs(div)))}

    def test_sign_amplitude_phase_and_rejections(self):
        C=api.load_cached_curl();nodes=api.saved_nodes()
        s,_=api.project_source(C,nodes)
        drive=2*complex(math.cos(.7),math.sin(.7))
        shifted,_=api.project_source(C,nodes,current=drive,orientation=-1)
        api.compare(shifted,-drive*s,np.abs(shifted)+abs(drive)*np.abs(s))
        rhs=api.electric_rhs(s,2e6)
        # Bottom x edge has +area/(4h) CCW circulation, hence negative imaginary RHS.
        want=-1j*(2*math.pi*2e6)*math.pi*.05**2/(4*.6)
        api.compare(np.array([rhs[6]]),np.array([want]),np.array([abs(rhs[6])+abs(want)]))
        for kwargs in ({'radius':.06},{'center':(0,0,-.24)},{'center':(.01,0,-.25)},
                       {'orientation':0},{'current':complex(float('nan'),0)}):
            with self.assertRaises((ValueError,TypeError)):api.project_source(C,nodes,**kwargs)
        with self.assertRaises(ValueError):api.project_source(C[:35,:],nodes)
        with self.assertRaises(ValueError):api.electric_rhs(np.ones(53),2e6)
        metrics['sign_phase']={'drive_real_imag':[drive.real,drive.imag],'orientation':-1,'literal_rhs_edge_6':[want.real,want.imag]}

error=None
try:
    if mode=='controls':
        suite=unittest.defaultTestLoader.loadTestsFromTestCase(SourceControls)
        result=unittest.TextTestRunner(verbosity=2).run(suite)
        save(stage/'control-result.json',{'success':result.wasSuccessful(),'tests':result.testsRun,
            'failures':len(result.failures),'errors':len(result.errors),'metrics':metrics,
            'old_tests_repeated':0,'actual_new_model_solves':0})
        if not result.wasSuccessful():raise SystemExit(1)
    else:
        import source_voltage as api
        from actual_voltage import run
        run(stage)
except BaseException as exc:
    error={'type':type(exc).__name__,'message':str(exc)}
    raise
finally:
    save(stage/'worker-identity.json',{'pid':os.getpid(),'mode':mode,'blas_before':before,'blas_after':identity.actual_threads(),
         'error':error,'simpeg_loaded':any(n=='simpeg' or n.startswith('simpeg.') for n in sys.modules)})
