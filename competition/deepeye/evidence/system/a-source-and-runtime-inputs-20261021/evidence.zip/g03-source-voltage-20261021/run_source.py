"""Fresh source/voltage job; unchanged reviewed Windows quota/handle guard."""
import hashlib,json,os
from pathlib import Path
import sys

D=Path(__file__).resolve().parent;ROOT=D.parents[2]
PREP=D.parent/'g03-finite-coil-transfer-preparation-20261021'
SUPPORT=D.parent/'r02-transient-quota-fix-20261021'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')

def inputs():
    assignment=read(D/'assignment.json')
    assert sha(D/'design-plan.md')==assignment['design_sha256']
    scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
    digest=hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    assert digest==assignment['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
    assert transfer['status']=='active' and transfer['director_generation']==2
    assert transfer['new_director_thread_id']==assignment['selected_by']
    files=[D/'assignment.json',D/'design-plan.md',SUPPORT/'win_job.py',SUPPORT/'boundary.py',
           PREP/'finite_coil_transfer.py',PREP/'runtime-pins.json',PREP/'design.json',
           ROOT/'docs/competition/deepeye-2026/immutable_scope.json',
           ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json',
           D.parent/'g03-fixed-transfer-main-20261021/main-result-adoption.json',
           D.parent/'g03-fixed-transfer-main-20261021/run-01/output-manifest.json',
           D.parent/'g03-boundary-sampler-controls-20261020/geometry.npz',
           D.parent/'g03-boundary-sampler-controls-20261020/cases.json',
           D.parent/'g03-boundary-sampler-controls-20261020/runs/batch-03/g.npy']
    run=D.parent/'g03-fixed-transfer-main-20261021/run-01'
    for name in ('A_II.npy','A_IB.npy','C-canonical-csr.npz','W_B.npy','boundary_indices.npy','interior_indices.npy'):
        files.append(run/name)
        row=read(run/'output-manifest.json')['files'][name]
        assert sha(run/name)==row['sha256']
    site=ROOT/'.local/deepeye-fdem-validation-20261020/Lib/site-packages'
    for name in ('simpeg/electromagnetics/utils/current_utils.py',
                 'simpeg/electromagnetics/frequency_domain/sources.py',
                 'simpeg/electromagnetics/frequency_domain/simulation.py',
                 'discretize/operators/differential_operators.py'):
        files.append(site/name)
    assert sha(SUPPORT/'win_job.py')=='80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d'
    assert sha(files[13])=='f1bea7e56f7abc833a9a203eeb192386c48f01c3fb37f3082cdce96264c24afe'
    for name,digest in read(PREP/'runtime-pins.json')['pins'].items():
        assert sha(Path(name))==digest
    return {'pins':{p.relative_to(ROOT).as_posix():sha(p) for p in files},'requirements_sha256':assignment['requirements_sha256']}

def main():
    label=sys.argv[1];assert label in ('controls-red-01','controls-01','run-01')
    pins=inputs()
    if not (D/'input-pins.json').exists():save(D/'input-pins.json',pins)
    else:assert read(D/'input-pins.json')==pins
    save(D/(label+'-source-pins.json'),{p.name:sha(p) for p in sorted(D.glob('*.py'))})
    sys.path.insert(0,str(SUPPORT))
    from win_job import run_bounded,process_identity
    env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),
         'PATH':'','TEMP':str(D),'TMP':str(D),'TMPDIR':str(D),'PYTHONDONTWRITEBYTECODE':'1',
         'PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',
         **{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','VECLIB_MAXIMUM_THREADS')}}
    budget={'seconds':50,'active_processes':4,'process_memory_bytes':384*1024**2,'job_memory_bytes':512*1024**2,
            'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':16*1024**2,'tree_entries':256,'free_reserve_bytes':512*1024**2}
    stage=D/label;granted=False
    def tick(job,pids):
        nonlocal granted
        if (stage/'hello.json').exists() and not granted:
            hello=read(stage/'hello.json');assert hello['pid'] in pids
            save(stage/'grant.json',{'worker':process_identity(hello['pid'],job),'scientific_import_allowed':True,
                                    'mode':'actual_source_voltage' if label=='run-01' else 'new_source_controls'})
            granted=True
    result=run_bounded([str(ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'),'-I','-B','-X','utf8',
                        str(D/'source_job.py'),str(stage),'actual' if label=='run-01' else 'controls'],
                        env,D,stage,budget,[D],on_tick=tick)
    after=inputs();save(stage/'input-readback.json',{'unchanged':pins==after,**after});assert pins==after
    assert result['all_processes_terminated'],'unresolved original process handles; no replay'
    print(json.dumps({k:result.get(k) for k in ('status','exit_code','seconds','stop_reason','all_processes_terminated','held_members')}))
    raise SystemExit(result['exit_code'] if result['exit_code'] is not None else 125)

if __name__=='__main__':main()
