"""One selected fresh source/absolute-voltage solve; saved operators only."""
import hashlib,json,math
from pathlib import Path
import sys,time,warnings
import numpy as np
from scipy import linalg
import source_voltage as source
from coaxial_reference import receive_voltages
D=Path(__file__).resolve().parent;RUN=D.parent/'g03-fixed-transfer-main-20261021/run-01'
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def pair(a):return [[complex(v).real,complex(v).imag] for v in a]

def run(output):
    if not json.loads((D/'assignment.json').read_text())['one_new_fixed_science_run_selected']:raise RuntimeError('not selected')
    counts={'A_assemblies':0,'C_constructions':0,'weak_source_projections':0,'LU_factorizations':0,
            'linear_solve_calls':0,'RHS_columns':0,'reference_orders':[],'Green_evaluations':0,
            'old_sampler_calls':0,'SimPEG_calls':0}
    start=time.monotonic();error=None;records=[]
    def profile(frame,event,arg):
        if event!='call':return
        if time.monotonic()-start>45:raise RuntimeError('45s cooperative stop; no replay')
        name=frame.f_code.co_name;file=frame.f_code.co_filename.replace('\\','/').casefold()
        if name=='lu_factor' and file.endswith('/scipy/linalg/_decomp_lu.py'):
            counts['LU_factorizations']+=1
            if counts['LU_factorizations']>1:raise RuntimeError('one factorization cap')
        if name=='lu_solve' and file.endswith('/scipy/linalg/_decomp_lu.py'):
            counts['linear_solve_calls']+=1
            b=frame.f_locals['b'];counts['RHS_columns']+=1 if b.ndim==1 else b.shape[1]
            if counts['linear_solve_calls']>1 or counts['RHS_columns']>2:raise RuntimeError('selected solve budget')
        if name in ('getA','getRHS','fields','sample_boundary','_physical_electric','_physical_green_kernel','edge_curl'):
            raise RuntimeError('old/forbidden scientific entry: '+file+':'+name)
    sys.setprofile(profile)
    try:
        C=source.load_cached_curl();nodes=source.saved_nodes()
        s,w=source.project_source(C,nodes);counts['weak_source_projections']+=1
        rhs=source.electric_rhs(s,2e6)
        AII=np.load(RUN/'A_II.npy',allow_pickle=False);AIB=np.load(RUN/'A_IB.npy',allow_pickle=False)
        W=np.load(RUN/'W_B.npy',allow_pickle=False)
        B=np.load(RUN/'boundary_indices.npy',allow_pickle=False);I=np.load(RUN/'interior_indices.npy',allow_pickle=False)
        g=np.load(D.parent/'g03-boundary-sampler-controls-20261020/runs/batch-03/g.npy',allow_pickle=False)
        if AII.shape!=(6,6) or AIB.shape!=(6,48) or W.shape!=(2,36) or B.shape!=(48,) or I.shape!=(6,) or g.shape!=(48,):
            raise ValueError('saved shape/order expansion')
        for name,a in (('AII',AII),('AIB',AIB),('W',W),('g',g)):source.numeric(a,name)
        reduced=rhs[I]-AIB@g
        with warnings.catch_warnings(record=True) as records:
            warnings.simplefilter('error',linalg.LinAlgWarning)
            lu=linalg.lu_factor(AII.copy(),check_finite=True)
            solution=linalg.lu_solve(lu,reduced,check_finite=True)
        source.numeric(solution,'interior field')
        residual=AII@solution-reduced
        denominator=np.linalg.norm(AII,np.inf)*np.linalg.norm(solution,np.inf)+np.linalg.norm(reduced,np.inf)
        eta=float(np.linalg.norm(residual,np.inf)/denominator) if denominator else (0. if np.all(residual==0) else math.inf)
        if not math.isfinite(eta) or eta>source.GATE:raise ArithmeticError('fixed backward residual gate failed')
        E=np.empty(54,dtype=complex);E[B]=g;E[I]=solution
        omega=2*math.pi*2e6
        magnetic=-C@E/(1j*omega)
        V=-1j*omega*(W@magnetic)
        independent_cancellation=W@(C@E)
        source.compare(V,independent_cancellation,np.abs(W)@(abs(C)@np.abs(E))+np.abs(V))
        references={};diagnostics={}
        for order in (64,128):
            ref,diag=receive_voltages(order=order)
            references[order]=ref;diagnostics[order]=diag
            counts['reference_orders'].append(order);counts['Green_evaluations']+=diag['Green_evaluations']
        diff=V-references[128];quad=references[128]-references[64]
        for name,array in {'w_Tx_m2':w,'s_e_Am':s,'raw_rhs':rhs,'reduced_rhs':reduced,'E_V_per_m':E,
                           'B_T':magnetic,'V_finite_V':V,'V_reference64_V':references[64],'V_reference128_V':references[128],
                           'signed_complex_difference_V':diff}.items():
            with (output/(name+'.npy')).open('xb') as f:np.save(f,array,allow_pickle=False)
        if counts['LU_factorizations']!=1 or counts['linear_solve_calls']!=1 or counts['RHS_columns']!=1:
            raise RuntimeError('actual one-solve counters differ')
        result={'scope':'new fixed circular weak-source / absolute finite-coil voltage diagnostic',
            'source':{'center_m':[0,0,-.25],'radius_m':.05,'current_peak_A':[1,0],'orientation':'+Z CCW','turns':1},
            'source_support_edges':np.flatnonzero(s).tolist(),'interior_indices':I.tolist(),
            's_e_interior_Am':pair(s[I]),'interior_source_exact_zero':bool(np.array_equal(s[I],np.zeros(6))),
            'explanation':'projected source is entirely on prescribed boundary edges for this coarse mesh; interior solve is driven by saved g, not resolved local source forcing',
            'V_finite_V':pair(V),'V_reference64_V':pair(references[64]),'V_reference128_V':pair(references[128]),
            'signed_finite_minus_reference_V':pair(diff),'absolute_difference_V':abs(diff).tolist(),
            'relative_difference':(abs(diff)/abs(references[128])).tolist(),
            'reference_128_minus_64_V':pair(quad),'reference_pair_absolute_difference_V':abs(quad).tolist(),
            'reference_pair_relative_difference':(abs(quad)/abs(references[128])).tolist(),
            'reference_metadata':diagnostics,'backward_residual':{'eta':eta,'gate':source.GATE,
                'norm_inf':float(np.linalg.norm(residual,np.inf)),'denominator':float(denominator)},
            'counts':counts,'receiver_accuracy_qualification':'open; quadrature consistency is not a rigorous error bound',
            'G03':'not_run','R03':'not_run','H12':'not_run','all29':'not_run'}
        save(output/'source-voltage-result.json',result)
        print(json.dumps(result))
    except BaseException as exc:
        error={'type':type(exc).__name__,'message':str(exc)}
        raise
    finally:
        sys.setprofile(None)
        save(output/'execution.json',{'counts':counts,'error':error,'seconds':time.monotonic()-start,
                                    'warnings':[str(w.message) for w in records]})
