"""Compatible weak projection of the one selected circular current.

This uses the piecewise edge/face finite-element basis, not arbitrary point
interpolation. The derivation is restricted to the fixed symmetric disk.
"""
import math
from pathlib import Path
import numpy as np
from scipy import sparse
D=Path(__file__).resolve().parent
RUN=D.parent/'g03-fixed-transfer-main-20261021/run-01'
GATE=128*np.finfo(float).eps

def numeric(x,name):
    a=np.asarray(x)
    if a.dtype.kind not in 'iufc' or not np.all(np.isfinite(a)):raise ValueError(name+': finite numeric values required')
    return a

def compare(got,want,scale):
    g,w,s=numeric(got,'got'),numeric(want,'want'),numeric(scale,'scale')
    if g.shape!=w.shape or s.shape!=g.shape or np.any(s<0):raise ValueError('scale or shape mismatch')
    with np.errstate(over='raise',invalid='raise'):
        if not np.all(np.abs(g-w)<=GATE*s):raise ArithmeticError('frozen 128eps scale check failed')

def load_cached_curl():
    with np.load(RUN/'C-canonical-csr.npz',allow_pickle=False) as f:
        return sparse.csr_matrix((f['data'].copy(),f['indices'].copy(),f['indptr'].copy()),shape=tuple(f['shape']))

def saved_nodes():
    with np.load(D.parent/'g03-boundary-sampler-controls-20261020/geometry.npz',allow_pickle=False) as f:
        points=np.vstack((f['starts'],f['ends']))
    nodes=tuple(np.unique(points[:,d]) for d in range(3))
    expected=([-0.6,0.,0.6],[-0.6,0.,0.6],[-0.85,-0.25,0.35])
    if any(not np.array_equal(n,e) for n,e in zip(nodes,expected)):raise ValueError('saved fixed binary geometry changed')
    return nodes

def project_source(C,nodes,*,current=1+0j,orientation=1,radius=.05,center=(0.,0.,-.25)):
    if not sparse.issparse(C) or C.shape!=(36,54):raise ValueError('accepted 36x54 sparse C required')
    numeric(C.data,'C')
    if len(nodes)!=3 or any(not np.array_equal(n,e) for n,e in zip(nodes,([-0.6,0.,0.6],[-0.6,0.,0.6],[-0.85,-0.25,0.35]))):
        raise ValueError('only the fixed saved grid is justified')
    if radius!=.05 or not math.isfinite(radius) or not np.array_equal(numeric(center,'center'),[0.,0.,-.25]):
        raise ValueError('only the selected centered .05m disk on the interior z face is justified')
    if orientation not in (-1,1) or isinstance(orientation,bool):raise ValueError('orientation must be +1 or -1')
    drive=numeric(current,'current')
    if drive.shape!=():raise ValueError('scalar peak current required')
    # RT face basis is constant transversely, linear normally in each cell.
    # At the interior z node, each of four disk quadrants contributes area/4.
    w=np.zeros(36)
    w[28:32]=orientation*math.pi*radius**2/4
    return numeric(complex(current)*(C.T@w),'weak source'),w

def electric_rhs(source,frequency):
    s=numeric(source,'source')
    if s.shape!=(54,) or not math.isfinite(frequency) or frequency!=2e6:raise ValueError('fixed frequency and source[54] required')
    return numeric(-1j*(2*math.pi*frequency)*s,'electric source RHS')

def edges_and_gradient(nodes):
    starts,ends=[],[];row=[];col=[];data=[]
    for axis,shape in enumerate(((2,3,3),(3,2,3),(3,3,2))):
        for local in range(18):
            ijk=np.unravel_index(local,shape,order='F')
            other=list(ijk);other[axis]+=1
            start=[nodes[d][ijk[d]] for d in range(3)]
            end=[nodes[d][other[d]] for d in range(3)]
            length=end[axis]-start[axis];edge=len(starts)
            starts.append(start);ends.append(end)
            row.extend((edge,edge));col.extend((np.ravel_multi_index(ijk,(3,3,3),order='F'),np.ravel_multi_index(tuple(other),(3,3,3),order='F')))
            data.extend((-1/length,1/length))
    starts,ends=np.asarray(starts),np.asarray(ends)
    return starts,ends,np.linalg.norm(ends-starts,axis=1),sparse.csr_matrix((data,(row,col)),shape=(54,27))

def independent_line_oracle(nodes,order):
    """Integrate dimensionless local bilinear edge tests along the actual circle.

    Independent of C and w; each quadrant is a smooth trig integral. z=-.25
    is a nodal plane, so only its tangential edge traces have nonzero weights.
    """
    if order!=16:raise ValueError('fixed 16 Gauss nodes per quadrant control')
    q,weights=np.polynomial.legendre.leggauss(order)
    answer=np.zeros(54);absolute=np.zeros(54)
    for quadrant in range(4):
        angles=quadrant*math.pi/2+(q+1)*math.pi/4
        for theta,weight in zip(angles,weights*math.pi/4):
            x,y=.05*math.cos(theta),.05*math.sin(theta)
            ix,iy=int(x>0),int(y>0)
            tx=(x-nodes[0][ix])/(nodes[0][ix+1]-nodes[0][ix])
            ty=(y-nodes[1][iy])/(nodes[1][iy+1]-nodes[1][iy])
            dx,dy=-.05*math.sin(theta),.05*math.cos(theta)
            for side in (0,1):
                edge_x=ix+2*(iy+side)+6
                edge_y=18+(ix+side)+3*iy+6
                vx=weight*dx*(1-ty,ty)[side]
                vy=weight*dy*(1-tx,tx)[side]
                answer[edge_x]+=vx;answer[edge_y]+=vy
                absolute[edge_x]+=abs(vx);absolute[edge_y]+=abs(vy)
    return answer,absolute
