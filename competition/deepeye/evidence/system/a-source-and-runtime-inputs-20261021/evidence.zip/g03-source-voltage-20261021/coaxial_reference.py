"""Independent homogeneous Green-vector-potential circular-line reference.

No mesh, projection, cached operator, previous sampler or FDEM source imports.
The 64/128 pair gives observed quadrature consistency, not a rigorous bound.
"""
import cmath,math
import numpy as np

def receive_voltages(*,order,frequency=2e6,mu=1.2566370614359173e-6,
                     sigma=.0005,epsilon=1.77083756256e-10,current=1+0j):
    if order not in (64,128):raise ValueError('selected fixed 64/128 pair only')
    omega=2*math.pi*frequency
    q=cmath.sqrt(1j*omega*mu*(sigma+1j*omega*epsilon))
    if q.real<0:q=-q
    if q.real<0 or q.imag<0:raise ArithmeticError('wrong outgoing Green branch')
    t,w=np.polynomial.legendre.leggauss(order)
    phi=math.pi*(t+1);weights=math.pi*w
    a=.05;r=.02
    z=np.asarray([.05,.25])
    R=np.sqrt(a*a+r*r-2*a*r*np.cos(phi)[None,:]+(z[:,None]+.25)**2)
    if not np.all(np.isfinite(R)) or np.any(R<=0):raise ArithmeticError('nonpositive Green distance')
    with np.errstate(over='raise',invalid='raise',divide='raise'):
        kernel=np.exp(-q*R)/R
        integral=np.sum(weights[None,:]*np.cos(phi)[None,:]*kernel,axis=1)
        Aphi=mu*complex(current)*a/(4*math.pi)*integral
        V=-1j*omega*(2*math.pi*r)*Aphi
    if not np.all(np.isfinite(V)):raise ArithmeticError('nonfinite reference')
    return V,{'q_per_m':[q.real,q.imag],'order':order,'Green_evaluations':2*order,
              'A_phi_complex_Wb_per_m':[[v.real,v.imag] for v in Aphi],
              'convention':'peak exp(+i omega t), +Z normals, CCW Tx viewed from +Z'}
