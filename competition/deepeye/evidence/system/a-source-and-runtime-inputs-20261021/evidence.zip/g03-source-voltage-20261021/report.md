# Fixed circular source and absolute-voltage diagnostic

Work `A-G03-SOURCE-VOLTAGE-20261021-v1`, worker
`/root/g03_finite_coil_prep_20261021`, native job
`child-0e26dec9138446ab9b8591ecf2dcb5c9`. The current director selected this
new actual diagnostic. It is complete as a bounded worker result, pending
independent main review; it is not G03/R03/H12/all29 acceptance.

Contract `DEEPEYE-HUMAN-LOCK-20261014/revision1`, H01-H15 canonical SHA256
`c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`
was recomputed and matched, the generation-2 transfer was active, and the
selected design-plan SHA256 matched assignment.json. Inputs remain unchanged.

## Result

The compatible weak source is justified for the selected symmetric disk,
but **all six interior source entries are exactly zero**. The eight nonzero
entries are global edges `[6,7,10,11,24,26,27,29]`, all prescribed boundary
edges. At I=`[8,9,25,28,40,49]`, both s_e and -i omega s_e are exactly zero.
The actual interior equation is consequently
`A_II E_I = -A_IB g`: this grid's interior field is driven by cached boundary
data, not a resolved local circular-current forcing. Boundary reactions are
not solved because E_B is prescribed. An algebraically compatible source does
not establish physical source resolution.

Values below use peak phasors and microvolts; the reference column is the
independent 128-point circular Green-line integral. Arrays preserve full
binary64 complex values and signed differences.

| Rx z (m) | Finite voltage (microvolt) | Reference voltage (microvolt) | Absolute difference (microvolt) | Relative difference |
|---|---|---|---:|---:|
| .05 | -0.177507441 - 57.778843260 i | -0.374198074 - 877.624921586 i | 819.846101921 | 93.4164479% |
| .25 | -0.165233248 - 41.632356128 i | -0.247257858 - 195.888886150 i | 154.256551830 | 78.7469019% |

The signed finite-minus-reference differences in volts are
`1.9669063290393817e-7 + 8.198460783266720e-4 i` and
`8.202460974505228e-8 + 1.5425653002187263e-4 i`.
No fitting, threshold change, material change or correction was applied.
These large differences leave the receiver accuracy qualification open.

Observed 128-minus-64 reference differences are 1.2735417772833305e-15 V and
7.696236351192624e-16 V in magnitude (relative 1.4511229458012105e-12 and
3.928875380058569e-12). The pair measures numerical consistency, not a rigorous
physical error bound. The outgoing branch was q=0.02092981466870352 +
0.18862287234387104 i per m, retaining the selected complex permittivity.

The one fresh 6x6 factorization and one RHS-column solve gave normalized
backward residual 1.4124006246694593e-16, below the unchanged
128 eps64 = 2.842170943040401e-14 guard. Backward stability does not qualify
source resolution, physical coil accuracy, material validity or convergence.

## Source, basis and independent new controls

`basis-derivation.md` gives the restricted derivation and units. Local installed
EB source code explicitly integrates dimensionless bilinear edge tests against
line current. Their compatible curls use a face basis constant transversely
and linear normally, while C already contains edge lengths and inverse face
areas. On this exact z=-.25 nodal plane, each disk quadrant contributes
pi a^2/4. Hence s_e=I C.T w_Tx has units A m, with no extra edge or mass
factor. Stokes is applied to this piecewise compatible basis, rather than
assuming the existing smooth Fz point interpolant is compatible.

The raw electric RHS is -i omega s_e, consistent with installed executable
getRHS for s_m=0 and peak exp(+i omega t). The computed total field gives
B=-C E/(i omega) and V=-i omega W_B B=W_B C E. No source class, primary-field
substitution, getA, getRHS, fields or previous physical sampler was executed.

Only the new source controls ran:

- A separate circular line integral of local edge traces, 16 Gauss points
  per quadrant, agreed with C.T w_Tx within the frozen scaled arithmetic
  guard. Maximum component difference was 8.023096076392733e-18 A m.
- The rotational test circulation gave 0.007853981633974482 A m^2 against
  pi*.05^2=0.007853981633974483 A m^2; constant tests closed, and the weak
  nodal divergence G.T s_e was exactly zero in binary arithmetic.
- Independent bottom-edge sign, current amplitude/phase, reversed orientation,
  dimensional shape and unsupported-geometry/nonfinite refusals passed.
  Source geometry is restricted to the justified fixed disk, not generalized.

`controls-red-01` preserves the expected pre-implementation absence failure.
`controls-01` ran the two new control groups once, exit 0. No previously
passed W_B, A/C, boundary, transfer, full48 or old manufactured suite was rerun.
The reference implementation is separate from the mesh projection and old
sampler: it evaluates A_phi from the 1D circular Green integral and uses
V=-i omega 2pi r_Rx A_phi. Its only physical evaluations are the selected
64/128 pair for the two receivers in `run-01` (384 Green point evaluations).

## Reused data and execution evidence

The saved accepted A_II/A_IB/C/W_B/order arrays and batch-03 g were reused
byte-for-byte. g file SHA256 is
`f1bea7e56f7abc833a9a203eeb192386c48f01c3fb37f3082cdce96264c24afe`.
It remains a numerical boundary approximation, not exact boundary truth.
The actual counters are one weak source projection, one LU, one solve/one
column, zero new A/C constructions, zero old sampler or SimPEG calls.

Every stage used the unchanged reviewed win_job.py with hidden below-normal
suspended assignment, a verified held worker before scientific import, a 50 s
tree cap, 4 processes, 384 MiB/process, 512 MiB/job, 128 KiB/stream,
16 MiB/256 entries and 512 MiB free reserve. Actual NumPy/SciPy BLAS getters
read 1 before and after. `run-01` finished in 1.328 s with peak job memory
128630784 bytes. All three original held process objects were signaled with
exit 0; the job's final active process count was zero. Both control stages'
original held objects were also signaled. Raw logs, process identities,
source pins and post-terminal input readback are retained separately.

All writes were confined to this assigned directory. No network/UI, board,
product, service, provider/credential, group or peer action occurred. The
prior completed preparation job and all old evidence remain unchanged.

## Unselected successor geometry for director review

`successor-grids.draft.json` records two nested nonuniform levels, identical
domain/material/2 MHz/1 A and the exact reusable 128-point reference hash.
Both Rx planes .05/.25 and the Tx plane -.25 are interior z nodes. The finer
level adds x/y nodes to the coarser level; no old full48 or reference replay
is selected. Two-level agreement alone cannot qualify the 5e-11 V budget.

A small candidate that first adds internal source-circle resolution uses
x=y nodes `[-.6,-.15,-.05,-.025,0,.025,.05,.15,.6]` (8 cells each) and
z nodes `[-.85,-.4,-.3,-.275,-.25,-.225,-.2,-.05,.025,.05,.075,.225,.25,.275,.35]`
(14 cells). This is 896 cells, 3294 edges, 2976 faces, 1215 nodes, with
2142 interior and 1152 tangential-boundary edges. Its central .025 m cells
put four cells across the Tx diameter and about 1.6 across the Rx diameter.
That is a first geometric-resolution diagnostic, not an accuracy prescription.
For three-plus cells across the Rx diameter, subdivide the central x/y
[-.05,.05] span into .0125 m cells: 12x12x14 gives 2016 cells, 7046 edges,
6528 faces, 2535 nodes, 5126 interior and 1920 boundary edges. Neither grid
has been selected, constructed or executed in this job; main owns that choice.

Required new inputs are exact mesh/order/geometry pins, new A/C/material arrays,
new boundary samples in the new order, source disk/cell overlap or independently
integrated compatible edge projection, and a new finite-Rx functional crossing
the new interpolation partitions. Existing 54-edge matrices, 48-entry g,
four-equal-quadrant shortcut and area-times-one-center W_B cannot be ported
unchanged. Existing same-geometry Green reference arrays can be reused as
reference inputs; no repeat of old full48 data is needed. Main must select a
fresh job and resource envelope, then assess nonzero interior forcing and
receiver error without post-result tuning. Domain/mesh convergence and a
receiver error budget still require their own evidence.

G03, R03, H12, all29 and the receiver accuracy gate remain unqualified/not_run.
