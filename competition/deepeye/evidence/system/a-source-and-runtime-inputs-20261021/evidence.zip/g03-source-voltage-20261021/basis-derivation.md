# Restricted compatible circular weak source

The local installed `simpeg/electromagnetics/utils/current_utils.py`, lines
7-41 and 55-109, explicitly defines the twelve dimensionless local bilinear
edge basis functions and the integral `int(W . J dx^3)` for a unit line
current. `frequency_domain/sources.py`, lines 1318-1336 and 1393-1411, returns
this integrated current vector for the EB source. This job does not import or
execute those source classes/functions.

For a rectangular cell of dimensions hx,hy,hz, the x-edge test basis is
e_x times one linear hat in y and one linear hat in z, constant in x;
y/z follow cyclically. Its coefficient is the normalized tangential edge
average E_e (V/m). Therefore the basis is dimensionless, and
s_e,e = integral N_e dot J dVolume = I integral_loop N_e dot dl has units A m.
No extra Me, edge-length multiplication or division is applied to s_e.

The curl of this compatible edge expansion is represented by the face basis
that is constant in the two transverse directions and linear in the face
normal direction, with coefficient the normal face-average curl in V/m^2.
This is not the smooth componentwise Fz point interpolant. Installed
`discretize/operators/differential_operators.py`, lines 2170-2181, constructs
C as inverse face area times oriented edge incidence times edge length,
so it maps the normalized edge values to those face-average curls.

The selected Tx disk lies exactly at the shared z=-.25 nodal plane, centered
at the shared x=y=0 vertex. Its radius .05m is smaller than the distance to
every outer x/y node. In each of the four xy cells its +Z face basis trace
is constant. Each quadrant area is exactly pi a^2/4. Thus the compatible
disk functional has w[28:32]=pi a^2/4 and all other entries zero.
For every edge coefficient vector e, the piecewise Stokes theorem gives

```
integral_loop E_h dot dl = integral_disk curl(E_h) dot +Z dS = w.T C e
s_e = I C.T w
```

There is no complex conjugation in this forward bilinear identity. Reversing
orientation reverses w and s_e; a complex peak current multiplies s_e linearly.
The independent control integrates the edge test traces around four smooth
circular quadrants using 16 Gauss points each, without using C or w. The
rotational test E=(-y/2,x/2,0) has exact circulation pi a^2; constant/gradient
tests have zero circulation. Nodal weak divergence is G.T s_e (A), where the
normalized edge gradient has endpoint differences divided by edge length.

Installed electric-field getRHS executable code in `simulation.py`, lines
806-839, is `C.T*(MfMui*s_m) - i omega s_e`. With no magnetic current s_m=0,
raw RHS is -i omega s_e. The old A uses the same sigma+i omega epsilon under
peak exp(+i omega t). This is a total-field source, with no magnetostatic
primary substitution. Faraday gives B=-C E/(i omega), hence the finite coil
voltage -i omega W_B B = W_B C E. Units are tesla, webers and volts respectively.

For the homogeneous infinite-medium reference the closed circular current is
divergence-free. A(r)=mu I/(4pi) integral exp(-q R)/R dl', with
q^2=i omega mu (sigma+i omega epsilon) and outgoing Re(q),Im(q)>=0.
At observation (r_Rx,0,z), its azimuthal component is

```
A_phi = mu I a/(4pi) integral_0^(2pi) cos(phi) exp(-q R)/R dphi
R^2 = a^2+r_Rx^2-2 a r_Rx cos(phi)+(z-z_Tx)^2
V = -i omega 2pi r_Rx A_phi
```

This reference is implemented separately from the mesh/source projection and
old boundary sampler. The 64/128 Gauss-Legendre pair reports observed numerical
convergence only. Coarse source resolution, material validity, domain/mesh
convergence and receiver accuracy remain separate from algebraic correctness.
The equal quadrant source weights cancel at all six interior edges of this
8-cell grid; that loss of interior forcing is reported rather than hidden.
