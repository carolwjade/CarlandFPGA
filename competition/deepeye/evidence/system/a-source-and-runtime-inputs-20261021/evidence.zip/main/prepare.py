from datetime import datetime, timezone
import hashlib, json, zipfile
from pathlib import Path

D=Path(__file__).resolve().parent; O=D.parent; ROOT=O.parents[1]
P=ROOT/'.local/deepeye-implementation-a'
T=P/'competition/deepeye/evidence/system/a-source-and-runtime-inputs-20261021'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def enc(j):return (json.dumps(j,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(p,b):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(b)
tokens=[]
for name in ('g03-source-voltage-20261021','r02-remaining-amd-20261021'):
    tokens.append(load(O/name/'lease.private.json')['lease_token'].encode())
members={};derived=[]
def clean(j):
    if isinstance(j,list):return [clean(v) for v in j]
    if isinstance(j,dict):return {k:clean(v) for k,v in j.items() if k not in ('environment','env')}
    return j
def add(p):
    if 'private' in p.name.casefold() or p.name=='reserve-request.json':return
    raw=p.read_bytes();name=p.relative_to(O).as_posix()
    if p.suffix=='.json':
        j=load(p);c=clean(j)
        if c!=j:
            name=name.removesuffix('.json')+'-public.json'
            c['original_environment_omitted']=True;c['original_local_sha256']=sha(raw)
            derived.append({'published_path':name,'original_sha256':sha(raw)})
            raw=enc(c)
    assert name not in members and not any(t in raw for t in tokens)
    members[name]=raw
g=O/'g03-source-voltage-20261021'; gm=load(g/'public-manifest.json')
for row in gm['files']:
    p=g/row['path'];assert p.stat().st_size==row['bytes'] and sha(p.read_bytes())==row['sha256'];add(p)
for name in ('public-manifest.json','native-complete-response.json'):add(g/name)
r=O/'r02-remaining-amd-20261021';rm=load(r/'manifest.json')
for name,row in rm['files'].items():
    p=r/name;assert p.stat().st_size==row['bytes'] and sha(p.read_bytes())==row['sha256'];add(p)
for name in ('manifest.json','native-complete-response.json','final-result.txt'):add(r/name)
for name in ('g03-source-voltage-main-review-20261021/review.json','r02-remaining-main-review-20261021/review.json',
             'g03-internal-source-grid-20261021/main-stop-evidence.json','g03-internal-source-grid-20261021/native-failed-response.json'):
    add(O/name)
summary={'utc':datetime.now(timezone.utc).isoformat(),'G03':load(O/'g03-source-voltage-main-review-20261021/review.json'),
         'R02':load(O/'r02-remaining-main-review-20261021/review.json'),'runtime_installation':'pending_separate_assignment',
         'new_mesh':'pending_separate_assignment','public_derivatives':derived,
         'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
         'old_tests_repeated':False,'formal_R03':'not_run','full_H12':'not_run','all29':'not_run'}
members['main/summary.json']=enc(summary);members['main/prepare.py']=Path(__file__).read_bytes()
T.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(T/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()):
        zi=zipfile.ZipInfo(name,(2026,10,21,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16;z.writestr(zi,raw)
with zipfile.ZipFile(T/'evidence.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for name,raw in members.items():assert z.read(name)==raw
write(T/'.gitattributes',b'* -text -eol -filter\n')
write(T/'archive-index.json',enc({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())}))
write(T/'summary.json',enc(summary))
readme='''# Actual source diagnostic and complete runtime inputs

The new G03 source/voltage implementation uses the installed compatible edge
basis, a discrete Stokes source projection, and an independently implemented
homogeneous conductive/displacement Green-loop reference. Two new control groups
passed. One actual 8-cell solve reused the accepted A/C/W_B and boundary vectors;
no old full48 sampling or control suite was repeated. All nine held process
objects across the retained failed preparation and successful stages terminated.

The diagnostic identifies a real inadequacy: all six interior source entries
are exactly zero on this grid. The eight nonzero projected entries lie on the
prescribed boundary, so the interior solve is boundary-driven. Near/far receiver
voltages differ from the independently calculated reference by 93.4164479% and
78.7469019%. The 1.4124006246694593e-16 backward residual passes its unchanged
128eps gate, but physical accuracy fails. Reference 64/128 differences are
1.27354e-15 / 7.69624e-16 V; this is observed quadrature consistency, not a
rigorous physical error bound. The 56-file author manifest and source/basis
review preserve that distinction. A new internally resolved grid is separate.

All 17 selected runtime wheels are now complete. The last five AMD objects
(gfx110x, core, gfx1103 device SDK, libraries and torch) total 1,287,395,534 bytes.
Each succeeded in one HTTPS GET and one current whole-archive streaming check.
This round needed no tail reconstruction or retry. Their CRC/RECORD/member size,
METADATA and platform tags matched; main independently rehashed the five files
and 101 evidence/source records. All 25 held objects across ten stages stopped.
These newly computed full hashes are not published vendor digests. Twelve prior
successful package records were reused; the earlier gfx1103 curl56 failure and
its separately completed same-object reconstruction retain their original states.

An offline isolated installation and one actual AMD backend check are selected
in a separate task. This checkpoint records complete inputs, not an installation,
GPU kernel, supported-8845H, project CNN or performance result. No driver, global
environment, board or production process changed in the archived operations.

The first new-grid worker hit provider capacity before writing implementation or
running science. Its native job is failed/terminal with zero owned processes;
a separately leased gpt-6-sol worker continues in another directory. The failure
is preserved and is not a completed numerical job.

Public archives exclude vendor wheels, private leases and full environments.
Environment-removed records carry original local hashes; every ZIP member's bytes
and CRC were checked during packaging. H01-H15 and canonical requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 are unchanged.
Formal R03, complete H12 and all29 task cards remain not_run.
'''
write(T/'README.md',readme.encode())
write(T/'manifest.json',enc({'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(T.iterdir())},'archive_members':len(members),'exact_member_bytes_and_crc_checked':True}))
guide=P/'competition/deepeye/docs/source_voltage_and_runtime_inputs_20261021.md'
write(guide,('''# Source and runtime dependency progress

The [new source diagnostic](../evidence/system/a-source-and-runtime-inputs-20261021/README.md)
quantifies why the 8-cell field model is insufficient, using actual absolute
receive voltages and a separate Green-loop reference. Its compatible source code
and controls are archived. The next selected grid resolves internal source edges
and reuses these reference values.

All 17 runtime input wheels are complete and reviewed. Installation and actual
device/kernel testing are separate next steps; the project CNN remains a C-owned
dependency. The physical base-BRAM and prior PC_DIRECT/R03 software evidence are
reused without rerunning them. Product acceptance remains governed by H01-H15.
''').encode())
files={p.relative_to(P).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in [*sorted(T.iterdir()),guide]}
write(D/'publication-files.json',enc(files));write(D/'owned-paths.nul',b''.join(n.encode()+b'\0' for n in files))
result={'files':len(files),'archive_members':len(members),'archive_bytes':(T/'evidence.zip').stat().st_size,'archive_sha256':sha((T/'evidence.zip').read_bytes()),'environment_derivatives':len(derived)}
write(D/'package-summary.json',enc(result));print(json.dumps(result))
