"""Five serial single GETs; exact response identity; preserve every terminal."""
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import shutil
import sys
import traceback
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import D,S,load,pin,save,closed,check_pins,headers

prepared=load(D/'prepared.json')
check_pins(prepared)
sys.path.insert(0,str(S))
from win_job import run_bounded,process_identity
from boundary import check_no_links
assert not list((D/'requests').iterdir()) and not list((D/'runs').iterdir())
free_reserve=10*1024**3
total=prepared['budgets']['artifact_total_bytes']
assert total==2*sum(n['compressed_bytes'] for n in prepared['files'])==2574791068
assert shutil.disk_usage(D).free-total-24*1024**2>=free_reserve
for p in (D,D/'raw',D/'full',D/'requests',D/'runs',Path(prepared['curl'])): check_no_links(p)
budget={'seconds':660,'active_processes':4,'process_memory_bytes':256*1024**2,'job_memory_bytes':512*1024**2,
    'stdout_bytes':65536,'stderr_bytes':65536,'tree_bytes':total+24*1024**2,'tree_entries':500,
    'free_reserve_bytes':free_reserve,'components':[
        {'path':str(D/'raw'),'bytes':total//2,'entries':5},
        {'path':str(D/'full'),'bytes':total//2,'entries':5},
        {'path':str(D/'requests'),'bytes':16*1024**2,'entries':200},
        {'path':str(D/'runs'),'bytes':8*1024**2,'entries':200}]}
result={'status':'running','work_id':'A-R02-REMAINING-AMD-20261021-v1','job_id':'child-5e001877de794370a2dd03fdb42bedba',
    'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    'started_utc':datetime.now(timezone.utc).isoformat(),'prepared_pin':pin(D/'prepared.json'),
    'requests':[],'new_full_GET_attempts':0,'new_tail_GETs':0,'retries':0,'installations':0,'vendor_imports':0}
save(D/'round-started.json',result)
try:
    for n in prepared['files']:
        check_pins(prepared)
        Q=D/'requests'/n['id']
        Q.mkdir()
        save(Q/'request.json',n)
        print(json.dumps({'event':'request_started','id':n['id'],'bytes':n['compressed_bytes']}),flush=True)
        env={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR')}
        env.update(PATH='',TEMP=str(Q),TMP=str(Q),PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
        raw=Path(n['raw_path'])
        assert not raw.exists() and not Path(n['reconstructed_path']).exists()
        argv=[prepared['curl'],'-q','--http1.1','--silent','--show-error','--fail','--proto','=https',
            '--connect-timeout','10','--max-time','600','--retry','0','--max-redirs','0',
            '--max-filesize',str(n['compressed_bytes']),'--dump-header',str(Q/'headers.txt'),
            '--output',str(raw),'--write-out','%{json}','--header','Accept-Encoding: identity',
            '--header','If-Match: '+n['etag'],'--header','User-Agent: DeepEye-A-selected-remaining-AMD-20261021',
            '--url',n['artifact_url']]
        curl_dir=D/'runs'/(n['id']+'-curl')
        save(Q/'download-started.json',{'argv':argv,'prepared':pin(D/'prepared.json'),'request':pin(Q/'request.json')})
        def curl_tick(job,pids):
            assert len(pids)<=4
            started=load(curl_dir/'started.json')
            assert started['launcher']['image_sha256']=='73d24149ff289afc49ec41f08918ef9faa727d39ad993e929757dc2ddafab805'
            if raw.exists():
                check_no_links(raw)
                assert raw.stat().st_size<=n['compressed_bytes']
            if (Q/'headers.txt').exists(): assert (Q/'headers.txt').stat().st_size<=65536
        download={'outcome':'failed_stopped','request':n,'attempts':1,'retries':0}
        result['new_full_GET_attempts']+=1
        try:
            terminal=run_bounded(argv,env,D,curl_dir,budget,[D/'raw',D/'full',D/'requests',D/'runs'],on_tick=curl_tick)
            download['terminal']=terminal
            closed(terminal)
            assert terminal['stop_reason'] is None
            status,h=headers(Q/'headers.txt')
            meta=load(curl_dir/'stdout.txt')
            download.update(status_line=status,response_headers=h,curl_metadata=meta,
                curl_error=(curl_dir/'stderr.txt').read_text(encoding='utf-8'))
            assert meta['http_code']==200 and status=='HTTP/1.1 200 OK'
            assert meta['url_effective']==n['artifact_url'] and meta['scheme']=='https' and meta['method']=='GET'
            assert meta['ssl_verify_result']==meta['num_redirects']==meta['num_retries']==0
            assert h['content-length']==str(n['compressed_bytes']) and 'content-range' not in h and h.get('content-encoding','identity')=='identity'
            assert h['etag']==n['etag'] and h['x-amz-version-id']==n['version_id']
            actual=pin(raw)
            assert actual['bytes']==int(meta['size_download'])
            download['body']=actual
            if terminal['exit_code']==meta['exitcode']==0 and actual['bytes']==n['compressed_bytes']:
                assert terminal['status']=='success'
                download['outcome']='success'
            elif terminal['exit_code']==meta['exitcode']==56 and 0<actual['bytes']<n['compressed_bytes']:
                assert terminal['status']=='failed'
                download['outcome']='failed_curl56_partial'
            else:
                raise AssertionError('unselected transport/size outcome; stop')
        except BaseException:
            download.update(outcome='failed_stopped',error=traceback.format_exc())
        finally:
            download.update(ended_utc=datetime.now(timezone.utc).isoformat(),body=pin(raw) if raw.exists() else None)
            save(Q/'download-result.json',download)
        assert download['outcome'] in ('success','failed_curl56_partial'),'download failed; stop without retry'
        check_pins(prepared)
        verify_dir=D/'runs'/(n['id']+'-verify')
        def verify_tick(job,pids):
            ready=Q/'worker-ready.json'
            release=Q/'worker-release.json'
            if ready.exists() and not release.exists():
                identity=load(ready)
                assert identity['pid'] in pids
                actual=process_identity(identity['pid'],job)
                assert Path(actual['image'])==Path(identity['base_executable']) and actual['image_sha256']==prepared['worker_image_sha256']
                save(release,actual)
        vt=run_bounded([prepared['python'],'-I','-S','-B','-X','utf8',str(D/'verify_current.py'),n['id']],
            env,D,verify_dir,{**budget,'stdout_bytes':1024*1024,'stderr_bytes':1024*1024},
            [D/'raw',D/'full',D/'requests',D/'runs'],on_tick=verify_tick)
        closed(vt)
        assert vt['status']=='success' and vt['exit_code']==0,'current wheel verification failed; stop'
        verified=load(Q/'verification-result.json')
        image=load(Q/'worker-release.json')
        assert verified['status']=='success' and image['pid'] in [m['pid'] for m in vt['held_members']]
        check_pins(prepared)
        closeout={'status':'complete','name':n['name'],'id':n['id'],'artifact':verified['artifact'],
            'origin':verified['origin'],'download_outcome_preserved':download['outcome'],
            'members':verified['members'],'record_hash_count':verified['record_hash_count'],
            'download_result':pin(Q/'download-result.json'),'verification_result':pin(Q/'verification-result.json'),
            'curl_terminal':pin(curl_dir/'terminal.json'),'verify_terminal':pin(verify_dir/'terminal.json'),
            'all_original_handles_signaled':True}
        save(Q/'closeout.json',closeout)
        result['requests'].append(closeout)
        print(json.dumps({'event':'request_complete',**closeout}),flush=True)
    result['status']='success'
except BaseException:
    result.update(status='failed_stopped',error=traceback.format_exc())
finally:
    result.update(ended_utc=datetime.now(timezone.utc).isoformat(),disk_free_bytes=shutil.disk_usage(D).free,
        R02='not_run',C03='not_run',all29='not_run')
    save(D/'result.json',result)
print(json.dumps({'event':'round_ended','status':result['status'],'complete':len(result['requests'])}),flush=True)
raise SystemExit(0 if result['status']=='success' else 1)
