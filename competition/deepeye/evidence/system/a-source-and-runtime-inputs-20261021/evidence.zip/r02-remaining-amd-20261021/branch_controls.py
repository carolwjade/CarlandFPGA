"""New identity/range/overlap branch controls only; no old controls repeated."""
import copy
import json
from pathlib import Path
import sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D))
try:
    from same_object import continuation_plan,require_overlap
except ImportError:
    print('RED: new continuation branch missing')
    raise SystemExit(1)
expected={'url':'https://repo.amd.com/a.whl','etag':'"same"','version':'v1','total':100}
prefix={'url':expected['url'],'etag':'"same"','version':'v1','total':100,'bytes':95,'status':200,'exit':56}
tail={'url':expected['url'],'etag':'"same"','version':'v1','range':'bytes 90-99/100','bytes':10,'complete':True,'status':206}
rows=[]
for kind in ('valid','url','etag','version','range','gap','no-overlap','tail-size','tail-failed','prefix-other-error','total','overlap-bytes'):
    p,t=copy.deepcopy(prefix),copy.deepcopy(tail)
    overlap=b'abcde'
    right=b'abcde'
    if kind in ('url','etag','version'): t[kind]='other'
    if kind=='range': t['range']='bytes 90-100/100'
    if kind=='gap': p['bytes']=89
    if kind=='no-overlap': p['bytes']=90
    if kind=='tail-size': t['bytes']=9
    if kind=='tail-failed': t['complete']=False
    if kind=='prefix-other-error': p['exit']=28
    if kind=='total': p['total']=101
    if kind=='overlap-bytes': right=b'abcdf'
    try:
        plan=continuation_plan(expected,p,t)
        require_overlap(overlap,right,plan['overlap_bytes'])
        accepted=True
        reason=None
    except AssertionError as e:
        accepted=False
        reason=str(e)
    rows.append({'case':kind,'accepted':accepted,'expected':kind=='valid','pass':accepted==(kind=='valid'),'reason':reason})
result={'status':'success' if all(r['pass'] for r in rows) else 'failed','controls':rows,
    'old_controls_repeated':False,'network_requests':0}
with (D/'branch-controls-result.json').open('x',encoding='utf-8') as f: json.dump(result,f,indent=2)
print(json.dumps(result))
raise SystemExit(0 if result['status']=='success' else 1)
