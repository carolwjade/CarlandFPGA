"""Seal actual outcomes and existing availability references, no old retest."""
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import D,load,pin,save,closed,check_pins

prepared=load(D/'prepared.json')
check_pins(prepared)
result=load(D/'result.json')
new=[]
downloads=[]
terminals=[]
for n in prepared['files']:
    Q=D/'requests'/n['id']
    if not Q.exists(): continue
    dr=load(Q/'download-result.json') if (Q/'download-result.json').exists() else None
    downloads.append({'id':n['id'],'name':n['name'],'outcome':dr['outcome'] if dr else 'unknown',
        'raw_path':n['raw_path'],'raw':dr.get('body') if dr else None,
        'http_status_line':dr.get('status_line') if dr else None,
        'response_headers':dr.get('response_headers') if dr else None,
        'curl_error':dr.get('curl_error') if dr else None,
        'curl_fields':{k:dr['curl_metadata'].get(k) for k in ('exitcode','http_code','size_download','num_redirects','num_retries','ssl_verify_result','url_effective')} if dr and 'curl_metadata' in dr else None,
        'download_result':pin(Q/'download-result.json') if dr else None})
    for stage in ('curl','verify'):
        p=D/'runs'/(n['id']+'-'+stage)/'terminal.json'
        if p.exists():
            t=load(p)
            closed(t)
            terminals.append({'id':n['id'],'stage':stage,'path':str(p),**pin(p),
                'status':t['status'],'exit':t['exit_code'],'held_members':len(t['held_members']),
                'all_original_handles_signaled':True,'peak_job_memory_bytes':t['peak_job_memory_bytes']})
    if not (Q/'closeout.json').exists(): continue
    closeout=load(Q/'closeout.json')
    v=load(Q/'verification-result.json')
    assert closeout['status']=='complete' and v['status']=='success'
    assert closeout['artifact']==v['artifact'] and v['prohibited_attempts']==[] and v['accepted_metadata_bytes_equal']
    assert pin(Q/'archive-review.json')==v['archive_review']
    artifact=Path(v['artifact']['path'])
    assert artifact.is_file() and artifact.stat().st_size==n['compressed_bytes']==v['artifact']['bytes']
    new.append({**closeout,'tags':v['tags'],'declared_expanded_bytes':v['declared_expanded_bytes'],
        'publisher_full_hash_available':False,'closeout_path':str(Q/'closeout.json')})
prior_root=D.parent/'r02-amd-wheel-acquisition-20261021'
prior=load(prior_root/'acquisition-result.json')
existing=prior['existing_available_references']
assert len(existing)==11
first_root=D.parent/'r02-same-object-continuation-20261021'
first=load(first_root/'result.json')
assert first['status']=='success'
existing.append({'name':'amd-torch-device-gfx1103',**first['worker_result']['artifact'],
    'review_path':str(first_root/'result.json'),'review_hash':pin(first_root/'result.json'),
    'evidence_scope':'already main-accepted same-version local reconstruction; no retest'})
assert len(existing)==12
summary={'status':result['status'],'work_id':result['work_id'],'job_id':result['job_id'],
    'requirements_sha256':result['requirements_sha256'],'new_complete_count':len(new),'new_complete':new,
    'new_complete_compressed_bytes':sum(n['artifact']['bytes'] for n in new),'GETs':downloads,
    'new_full_GET_attempts':result['new_full_GET_attempts'],
    'successful_full_GETs':sum(r['outcome']=='success' for r in downloads),
    'failed_curl56_preserved':sum(r['outcome']=='failed_curl56_partial' for r in downloads),
    'local_reconstructions_verified':sum('reconstruction' in r['origin'] for r in new),
    'new_tail_requests':0,'retries':0,'installations':0,'vendor_imports':0,'extractions':0,
    'existing_complete_references':existing,'existing_reference_count':12,'old_artifacts_retested':False,
    'all_complete_available_references_count':12+len(new),'terminals':terminals,
    'all_new_original_handles_signaled':True,'source_pins_unchanged':True,
    'uncompleted_AMD_packages':[n['name'] for n in prepared['files'] if n['name'] not in {r['name'] for r in new}],
    'round_result':{'path':str(D/'result.json'),**pin(D/'result.json')},'error':result.get('error'),
    'R02':'not_run','C03':'not_run','all29':'not_run'}
save(D/'summary.json',summary)
manifest={str(p.relative_to(D)):pin(p) for p in D.rglob('*') if p.is_file() and p.name!='lease.private.json' and 'raw' not in p.parts and 'full' not in p.parts}
save(D/'manifest.json',{'files':manifest,'full_artifacts':[r['artifact'] for r in new],
    'raw_downloads':[{'path':r['raw_path'],'body':r['raw'],'outcome':r['outcome']} for r in downloads],
    'artifact_hash_scope':'new full observed or locally reconstructed SHA; publisher full hash unavailable',
    'artifact_hash_evidence':'download/worker streaming pins; no extra complete-wheel retests'})
lines=[f"R02 remaining AMD: {summary['status']}; {len(new)}/5 newly complete.",
       f"Full GET attempts={summary['new_full_GET_attempts']}; successful full GETs={summary['successful_full_GETs']}; preserved curl56 failures={summary['failed_curl56_preserved']}; verified local reconstructions={summary['local_reconstructions_verified']}.",
       'Existing 12 packages are references to already accepted evidence; no old tests repeated.',
       'No tail requests, retries, installation, vendor import, extraction, board/UI/service/product changes.',
       'Every launched original held process handle is signaled; R02/C03/all29 remain not_run.']
for r in new:
    lines.append(f"{r['name']}: {r['artifact']['bytes']} bytes; SHA256 {r['artifact']['sha256']}; members={r['members']}; origin={r['origin']}")
lines.append('Remaining: '+(', '.join(summary['uncompleted_AMD_packages']) or 'none among the fixed five'))
lines.append(f"summary.json {pin(D/'summary.json')}; manifest.json {pin(D/'manifest.json')}")
if result.get('error'): lines.append('Failure: '+result['error'])
with (D/'final-result.txt').open('x',encoding='utf-8',newline='\n') as f: f.write('\n'.join(lines)+'\n')
print(json.dumps({'status':summary['status'],'new_complete':len(new),'all_available_references':12+len(new),
    'summary':pin(D/'summary.json'),'manifest':pin(D/'manifest.json'),'final_result':pin(D/'final-result.txt')}))
