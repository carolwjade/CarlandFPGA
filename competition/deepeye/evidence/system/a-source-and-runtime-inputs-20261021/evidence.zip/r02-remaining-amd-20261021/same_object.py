"""Pure fail-closed authorization of the newly selected local continuation."""
import re

def continuation_plan(expected,prefix,tail):
    assert prefix['status']==200 and prefix['exit']==56,'requires failed HTTP200/curl56 prefix'
    assert tail['status']==206 and tail['complete'] is True,'requires previously complete HTTP206 tail'
    for key in ('url','etag','version'):
        assert prefix[key]==tail[key]==expected[key],'same-object '+key
    assert expected['url'].startswith('https://repo.amd.com/'),'exact HTTPS AMD object'
    assert prefix['total']==expected['total'],'prefix total differs'
    match=re.fullmatch(r'bytes ([0-9]+)-([0-9]+)/([0-9]+)',tail['range'])
    assert match,'invalid tail Content-Range'
    start,end,total=map(int,match.groups())
    assert total==expected['total'] and 0<=start<=end and end+1==total,'tail must end at exact object EOF'
    assert tail['bytes']==end-start+1,'tail actual/declared range size'
    assert start<prefix['bytes']<total,'nonempty overlap, no gap, genuinely partial prefix'
    overlap=prefix['bytes']-start
    assert 0<overlap<tail['bytes'],'overlap bounds'
    return {'tail_start':start,'tail_end':end,'total':total,'overlap_bytes':overlap,
            'append_bytes':total-prefix['bytes']}

def require_overlap(prefix_end,tail_start,count):
    assert len(prefix_end)==len(tail_start)==count and prefix_end==tail_start,'overlap bytes differ'
