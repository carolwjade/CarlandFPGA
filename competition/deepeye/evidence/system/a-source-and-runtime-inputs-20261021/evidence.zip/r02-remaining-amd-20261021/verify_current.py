"""One current-wheel streaming validation; optional preselected offline assembly."""
from datetime import datetime,timezone
import hashlib
import os
from pathlib import Path
import struct
import sys
import time
import traceback
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import D,S,load,pin,save,check_pins,tail_info
from same_object import continuation_plan,require_overlap
prepared=load(D/'prepared.json')
check_pins(prepared)
sys.path.insert(0,str(S))
from streaming_zip import verify_stream
Q=D/'requests'/sys.argv[1]
assert Q.parent==D/'requests'
events=[]
def audit(event,args):
    if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.startfile','os.startfile/2','ctypes.dlopen','os.symlink','os.link'}:
        events.append(event)
        raise RuntimeError('offline verifier external/native effect denied')
    if event=='import' and args[0].split('.')[0] in {'torch','rocm','rocm_sdk','rocm_bootstrap','setuptools','pip','filelock','fsspec','jinja2','mpmath','networkx','sympy'}:
        events.append('vendor_import:'+args[0])
        raise RuntimeError('vendor import denied')
    if event=='open' and not isinstance(args[0],int):
        p=Path(args[0]).resolve()
        if 'private' in p.name.lower(): raise RuntimeError('private file denied')
        mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writing and not (p.is_relative_to(Q) or p.is_relative_to(D/'full')):
            events.append('unowned_write')
            raise RuntimeError('unowned write denied')
    if event=='exec' and any(x in args[0].co_filename.casefold() for x in ('\\raw\\','\\full\\','/raw/','/full/')):
        events.append('artifact_execution')
        raise RuntimeError('artifact is data')
sys.addaudithook(audit)
try:
    assert sys.implementation.name=='cpython' and sys.version_info[:2]==(3,12) and struct.calcsize('P')==8
    n=load(Q/'request.json')
    downloaded=load(Q/'download-result.json')
    assert downloaded['outcome'] in ('success','failed_curl56_partial')
    save(Q/'worker-ready.json',{'pid':os.getpid(),'base_executable':sys._base_executable})
    deadline=time.monotonic()+15
    while not (Q/'worker-release.json').exists():
        assert time.monotonic()<deadline
        time.sleep(.02)
    image=load(Q/'worker-release.json')
    assert image['pid']==os.getpid() and image['image_sha256']==pin(sys._base_executable)['sha256']==prepared['worker_image_sha256']
    raw=Path(n['raw_path'])
    if downloaded['outcome']=='success':
        artifact=raw
        actual=pin(raw)
        assert actual==downloaded['body'] and actual['bytes']==n['compressed_bytes']
        origin='successful single new full GET'
        reconstruction=None
    else:
        meta=downloaded['curl_metadata']
        h=downloaded['response_headers']
        tail=tail_info(n['tail'])
        expected={'url':n['artifact_url'],'etag':n['etag'],'version':n['version_id'],'total':n['compressed_bytes']}
        prefix={'url':meta['url_effective'],'etag':h['etag'],'version':h['x-amz-version-id'],
            'total':int(h['content-length']),'bytes':downloaded['body']['bytes'],'status':meta['http_code'],'exit':meta['exitcode']}
        plan=continuation_plan(expected,prefix,tail)
        tail_raw=Path(n['tail']['body']['path']).read_bytes()
        tail_actual={'bytes':len(tail_raw),'sha256':hashlib.sha256(tail_raw).hexdigest()}
        assert tail_actual=={k:n['tail']['body'][k] for k in ('bytes','sha256')}
        artifact=Path(n['reconstructed_path'])
        hs,hfull=hashlib.sha256(),hashlib.sha256()
        size=0
        last=b''
        with raw.open('rb') as src,artifact.open('xb') as out:
            for block in iter(lambda:src.read(128*1024),b''):
                size+=len(block)
                assert size<=prefix['bytes']
                hs.update(block)
                hfull.update(block)
                last=(last+block)[-plan['overlap_bytes']:]
                out.write(block)
            assert {'bytes':size,'sha256':hs.hexdigest()}==downloaded['body'],'prefix changed while copying'
            require_overlap(last,tail_raw[:plan['overlap_bytes']],plan['overlap_bytes'])
            append=tail_raw[plan['overlap_bytes']:]
            assert len(append)==plan['append_bytes']
            out.write(append)
            hfull.update(append)
            out.flush()
            os.fsync(out.fileno())
        actual={'bytes':artifact.stat().st_size,'sha256':hfull.hexdigest()}
        assert actual['bytes']==n['compressed_bytes']
        reconstruction={'status':'success','plan':plan,'tail_identity':tail,'tail':tail_actual,
            'prefix':downloaded['body'],'overlap_equal':True,'overlap_sha256':hashlib.sha256(last).hexdigest(),
            'full':actual,'old_GET_still_failed':True,'new_network_requests':0}
        save(Q/'reconstruction.json',reconstruction)
        origin='local same-object/version range reconstruction; original GET remains failed'
    accepted=n['accepted_metadata']
    assert pin(accepted['path'])=={k:accepted[k] for k in ('bytes','sha256')}
    review=verify_stream(artifact,n,Path(accepted['path']).read_bytes())
    assert pin(artifact)==actual
    check_pins(prepared)
    assert not events
    review.update(artifact={'path':str(artifact),**actual},origin=origin,
        publisher_full_hash_available=False,independent_image_binding=image,prohibited_attempts=events,
        python={'pid':os.getpid(),'ppid':os.getppid(),'base_executable':sys._base_executable,
            'version':sys.version,'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode})
    assert review['python']['isolated']==review['python']['no_site']==1 and review['python']['dont_write_bytecode']
    save(Q/'archive-review.json',review)
    save(Q/'verification-result.json',{'status':'success','artifact':review['artifact'],'origin':origin,
        'members':review['member_count'],'record_hash_count':review['record_hash_count'],
        'declared_expanded_bytes':review['declared_uncompressed_bytes'],'accepted_metadata_bytes_equal':True,
        'tags':review['tags'],'archive_review':pin(Q/'archive-review.json'),
        'reconstruction':pin(Q/'reconstruction.json') if reconstruction else None,'vendor_imports':0,
        'installations':0,'extractions':0,'prohibited_attempts':events,'R02':'not_run','C03':'not_run','all29':'not_run'})
    print(__import__('json').dumps({'status':'success','id':n['id'],'artifact':review['artifact'],'origin':origin}))
except BaseException:
    save(Q/'verification-failure.json',{'status':'failed','error':traceback.format_exc(),'prohibited_attempts':events})
    traceback.print_exc()
    raise
