"""Trusted small data/pin/terminal helpers for the remaining-five scope."""
import email.parser
import hashlib
import json
from pathlib import Path
import re
D=Path(__file__).resolve().parent
S=D.parent/'r02-amd-wheel-acquisition-20261021'
def load(p): return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p)
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(128*1024),b''): h.update(b)
    return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def save(p,v):
    p=Path(p)
    assert p.resolve().is_relative_to(D)
    with p.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(v,f,indent=2,ensure_ascii=False)
        f.write('\n')
def closed(t):
    assert t['all_processes_terminated'] is True and not t['faults']
    assert t['active_processes_final']==0
    assert t['held_members'] and all(m['signaled'] is True and m['wait_result']==0 for m in t['held_members'])
def check_pins(prepared):
    for p,value in prepared['pins'].items(): assert pin(p)==value,p
def headers(p):
    raw=Path(p).read_bytes()
    assert len(raw)<=65536
    blocks=[b for b in re.split(br'\r?\n\r?\n',raw) if b.startswith(b'HTTP/')]
    assert len(blocks)==1
    status,fields=blocks[0].split(b'\n',1)
    parsed=email.parser.BytesHeaderParser().parsebytes(fields)
    for key in ('content-length','content-range','etag','x-amz-version-id','content-encoding'):
        assert len(parsed.get_all(key,[]))<=1
    return status.strip().decode(),{k.lower():v.strip() for k,v in parsed.items()}
def tail_info(record):
    receipt=load(record['receipt']['path'])
    assert pin(record['receipt']['path'])=={k:record['receipt'][k] for k in ('bytes','sha256')}
    if record['kind']=='original_torch_range_ledger':
        rows=[r for r in receipt['requests'] if r.get('method')=='GET' and r.get('start')==record['requested_start'] and r.get('outcome')=='complete']
        assert len(rows)==1
        row=rows[0]
        h={k.lower():v for k,v in row['headers'].items()}
        assert row['final_url']==row['url'] and row['received_bytes']==record['body']['bytes']
        assert row['sha256']==record['body']['sha256'] and row['status']==206
        assert row['request_headers']['If-Match']==h['etag']
        url=row['url']
        complete=row['outcome']=='complete'
        transport={'client':'historical Python HTTPS','TLS_result_field':'not_reported','transport_exit':'not_applicable'}
    else:
        h=receipt['response_headers']
        meta=receipt['curl_metadata']
        assert receipt['outcome']=='complete' and receipt['exit_code']==meta['exitcode']==0
        assert receipt['received_bytes']==meta['size_download']==record['body']['bytes']
        assert receipt['body_sha256']==record['body']['sha256'] and meta['http_code']==206
        assert meta['ssl_verify_result']==meta['num_redirects']==meta['num_retries']==0
        assert meta['scheme']=='https' and meta['method']=='GET' and meta['url_effective']==receipt['request']['url']
        url=receipt['request']['url']
        complete=True
        transport={k:meta[k] for k in ('ssl_verify_result','num_redirects','num_retries','exitcode')}
    assert h['content-length']==str(record['body']['bytes'])
    return {'url':url,'etag':h['etag'],'version':h['x-amz-version-id'],'range':h['content-range'],
        'bytes':record['body']['bytes'],'status':206,'complete':complete,'transport':transport}
