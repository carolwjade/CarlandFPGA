"""Freeze new code/runtime/object selections before the five new GETs."""
import ast
import hashlib
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import D,S,load,pin,save,tail_info

assignment=load(D/'assignment.json')
assert assignment['work_id']=='A-R02-REMAINING-AMD-20261021-v1' and len(assignment['files'])==5
assert assignment['owner']=='/root/r02_amd_acquisition_20261021'
assert [r['id'] for r in assignment['files']]==['002-amd-torch-device-gfx110x','003-rocm-sdk-core','004-rocm-sdk-device-gfx1103','005-rocm-sdk-libraries','006-torch']
root=D.parents[2]
contract=load(root/'docs/competition/deepeye-2026/immutable_scope.json')
import json
assert hashlib.sha256(json.dumps(contract['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==assignment['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=load(root/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
assert transfer['status']=='active' and transfer['director_generation']==2 and transfer['new_director_thread_id']==assignment['selected_by']
assert pin(S/'incoming-pins.json')=={'bytes':37595,'sha256':'fcffad05c4345da2ab83aa362e1aaef99b327e9d17b941f792ab7f62ff8ffa7d'}
oldpins=load(S/'incoming-pins.json')['files']
pins={}
for name in ('streaming_zip.py','win_job.py','boundary.py','main-runtime-selection.json','runtime-input-observation.json'):
    path=S/name
    assert pin(path)==oldpins[str(path)]
    pins[str(path)]=pin(path)
runtime=load(S/'main-runtime-selection.json')
assert runtime['status']=='selected_by_main_for_data_only_acquisition_validation'
pins.update(runtime['selected_stdlib_files'])
for row in load(S/'runtime-input-observation.json')['inputs']:
    assert pin(row['path'])==row['observed']
    pins[row['path']]=row['observed']
ledger_path=D.parent/'r02-wheel-postrun-independent-20261021/audit-03/missing-wheels.json'
assert pin(ledger_path)=={'bytes':77346,'sha256':'ef183fffa85631e9ff89e5dc2eb56c278fafadef661f3e5dfc6c74d402122ef5'}
ledger=load(ledger_path)
files=[]
for n in assignment['files']:
    e=next(e for e in ledger['entries'] if e['name']==n['name'])
    assert all(n[k]==e[k] for k in ('artifact_url','compressed_bytes','declared_expanded_bytes','version','tags'))
    tails=[r for r in e['retained_partial_records'] if r.get('http_status')==206 and r.get('original_outcome') in ('complete','complete_same_object_range')
        and ((r.get('content_range') or '').endswith(str(n['compressed_bytes']-1)+'/'+str(n['compressed_bytes'])) or r.get('requested_start')==n['compressed_bytes']-65557)]
    assert len(tails)==1
    tail=tails[0]
    normalized=tail_info(tail)
    assert normalized['url']==n['artifact_url'] and normalized['etag']==n['etag'] and normalized['version']==n['version_id']
    assert normalized['range']==f'bytes {n["compressed_bytes"]-65557}-{n["compressed_bytes"]-1}/{n["compressed_bytes"]}'
    pins[tail['receipt']['path']]=pin(tail['receipt']['path'])
    meta=n['accepted_metadata']
    assert pin(meta['path'])=={k:meta[k] for k in ('bytes','sha256')}
    pins[meta['path']]=pin(meta['path'])
    files.append({**n,'raw_path':str(D/'raw'/(n['filename']+'.part')),
        'reconstructed_path':str(D/'full'/n['filename']),'tail':tail,'tail_identity':normalized})
oldsel=load(S/'selection.json')
curl=Path(oldsel['curl'])
assert pin(curl)['sha256']=='73d24149ff289afc49ec41f08918ef9faa727d39ad993e929757dc2ddafab805'
pins[str(curl)]=pin(curl)
assert load(D/'branch-controls-result.json')['status']=='success'
for p in D.glob('*.py'):
    ast.parse(p.read_text(encoding='utf-8'))
    pins[str(p)]=pin(p)
for p in (D/'assignment.json',D/'plan.txt',D/'branch-controls-result.json',ledger_path,root/'docs/competition/deepeye-2026/immutable_scope.json',root/'docs/competition/deepeye-2026/immutable_scope.md',root/'.planning/deepeye-desktop-handoff-20261015/transfer.json'):
    pins[str(p)]=pin(p)
for p,value in pins.items(): assert pin(p)==value,p
for name in ('raw','full','requests','runs'): (D/name).mkdir()
save(D/'prepared.json',{'files':files,'pins':pins,'curl':str(curl),'python':oldsel['python'],
    'worker_image_sha256':oldsel['worker_image_sha256'],'budgets':assignment['budgets'],
    'new_network_GETs_selected':5,'code_frozen_before_network':True,
    'new_download_bytes':sum(n['compressed_bytes'] for n in files),'new_branch_controls':12,'old_controls_repeated':False})
print(json.dumps({'status':'prepared','five_GET_bytes':sum(n['compressed_bytes'] for n in files),'pins':len(pins)}))
