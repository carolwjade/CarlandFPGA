"""Single granted scientific stage, writes confined to that stage."""
import ctypes as ct
import hashlib,json,os,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;stage=Path(sys.argv[1]).resolve();mode=sys.argv[2]
def save(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
save(stage/'hello.json',{'pid':os.getpid(),'mode':mode,'before_scientific_import':True})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
 if time.monotonic()>deadline:raise RuntimeError('no held worker grant')
 time.sleep(.01)
grant=json.loads((stage/'grant.json').read_text(encoding='utf-8'));assert grant['worker']['pid']==os.getpid() and grant['mode']==mode
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):raise PermissionError('no network/subprocess')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).resolve();modes=args[1];flags=args[2]
  writing=(isinstance(modes,str) and any(c in modes for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if writing and not path.is_relative_to(stage):raise PermissionError('writes outside owned stage')
  if not writing and mode in ('red','controls') and path.suffix=='.npz':raise PermissionError('old global matrices forbidden in controls')
sys.addaudithook(audit);sys.path.insert(0,str(D));started=time.monotonic();before=None
def threads():
 import numpy as np
 import scipy.linalg
 import scipy
 k=ct.WinDLL('kernel32',use_last_error=True);k.GetModuleHandleW.argtypes=[ct.c_wchar_p];k.GetModuleHandleW.restype=ct.c_void_p
 rows=[]
 for folder,symbol in [('numpy.libs','scipy_openblas_get_num_threads64_'),('scipy.libs','scipy_openblas_get_num_threads')]:
  paths=list((Path(np.__file__).resolve().parents[1]/folder).glob('*openblas*.dll'));assert len(paths)==1
  handle=k.GetModuleHandleW(str(paths[0]));assert handle
  getter=getattr(ct.CDLL(str(paths[0]),handle=handle),symbol);getter.argtypes=[];getter.restype=ct.c_int;count=getter();assert count==1
  rows.append({'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),'threads':count})
 return {'numpy':np.__version__,'scipy':scipy.__version__,'BLAS':rows}
try:
 before=threads()
 if mode in ('red','controls'):
  import test_assembly
  result=test_assembly.run(stage)
 else:
  import solve_stages
  result=getattr(solve_stages,mode)(stage)
 save(stage/'result.json',result)
 save(stage/'worker-evidence.json',{'elapsed_seconds':time.monotonic()-started,'runtime_before':before,'runtime_after':threads()})
 print(json.dumps(result),flush=True)
 if result.get('selected_screens_pass') is False:raise SystemExit(2)
except BaseException as exc:
 save(stage/'failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),'elapsed_seconds':time.monotonic()-started,'runtime_before':before})
 raise
