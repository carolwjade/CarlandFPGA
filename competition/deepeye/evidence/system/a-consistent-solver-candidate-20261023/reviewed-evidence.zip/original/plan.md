# Fixed consistent-system correction

Root-selected work A-G03-CONSISTENT-SOLVE-20261023-v1. Freeze exact accepted kernel bytes and 2 new assembly fixtures before RED. Reuse old local controls and saved action without execution. Stages: missing-assembler RED; two scatter controls; one full consistent CSR assembly/residual-identity stage; only if those pass and fresh available physical memory>=10GiB, one fixed old-LU-preconditioned GMRES correction.

The new assembler preallocates complex128 values and int32 row/column arrays for at most19584*144 entries, chunk<=256. It uses nominal saved bounds and exact saved map. Actual endpoint checks use np.r_[origin,diff(nominal)].cumsum(), following the accepted independent review. Full boundary is included before I restriction. No old matrix reconstruction or old tests.

New fixture1: two anisotropic cells sharing a face, independent rational polynomial selected entries and global row sums. New fixture2: eight cells, trilinear nodal-gradient curl-null plus constant electric mass normalization, with nonzero boundary contribution explicitly checked. One assembled matrix per fixture. No old local matrix suite. All arithmetic comparisons use128eps times recorded explicit sums, not physical tolerances.

Full CSR assembly is compared to the accepted saved alternative residual using separate assembly row bounds, new CSR dot-product scales and saved parent scales. Persist only Ac CSR, no COO/II/IB copies. This arithmetic bound is never substituted for the actual CSR II infinity norm in the final backward-error denominator.

Actual correction: one COLAMD factorization of unchanged saved A0_II as a left preconditioner; GMRES Ac_II delta=-r0I,complex128,x0zero,rtol1e-12,atol0,restart40,maxiter3,pr_norm callback<=120. No retry/repair/alternate ordering/solver/tolerance. Preserve callback journal and info. Save final full-field and correction residuals, eta<=128eps, same S2boundary, source b3, S1receiver trace/high H-reference and both fixed1%gates. Physics remains derivative at tau=0; no product acceptance.

Original reviewed held guard unchanged. RED/controls/assembly each30s sampled,512MiBprocess/1GiBjob; actual90s,4GiBprocess/5GiBjob; <=3heldprocesses,BLAS1,256MiB total evidence. One unexpected failure stops all later stages and preserves originals. Background only, root retains acceptance.
