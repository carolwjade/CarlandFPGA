"""Inert schema/header/pin checks before scientific stages; copy accepted kernel."""
import ast,hashlib,json,struct
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def header(p):
 with p.open('rb') as f:
  assert f.read(6)==b'\x93NUMPY';version=tuple(f.read(2));length=struct.unpack('<H' if version==(1,0) else '<I',f.read(2 if version==(1,0) else 4))[0]
  return ast.literal_eval(f.read(length).decode('latin1'))
S=P/'g03-consistent-hodge-json-continuation-20261023';S1=P/'g03-s1-cache-path-continuation-20261021';S2=P/'g03-s2-boundary-correction-20261021';S3=P/'g03-s3-json-continuation-20261021';L5=P/'g03-l5-propagation-z-refinement-20261021'
known=read(S/'input-pins.json')['files'];known.update(read(S/'frozen-source-pins.json'));known.update(read(S3/'frozen-source-pins.json'))
for folder in (S,S1,S2,S3):
 manifest=read(folder/'manifest.json')['files']
 if isinstance(manifest,dict):
  for n,r in manifest.items():known[(folder/n).relative_to(ROOT).as_posix()]={k:r[k] for k in ('bytes','sha256')}
review=P/'g03-hodge-independent-continuation-20261023'
assert pin(review/'manifest.json')['sha256']=='3f941ae0ddf56f9f57507d487ed9835fb9b877a614278b2026d58b7feb946322'
decision=read(P/'g03-hodge-main-acceptance-20261023/decision.json');assert decision['decision']=='ACCEPT_BOUNDED_CONSISTENT_HODGE_KERNEL_AND_SAVED_ACTION'
key=(S/'hodge_kernel.py').relative_to(ROOT).as_posix();assert pin(S/'hodge_kernel.py')==known[key]
with (D/'hodge_kernel.py').open('xb') as f:f.write((S/'hodge_kernel.py').read_bytes())
names={
 'bounds':S/'action-01/cell_bounds_m.npy','mapping':S/'action-01/cell_edge_map.npy','cell_ids':S/'action-01/cell_ids.npy',
 'saved_consistent_residual':S/'action-01/consistent_operator_residual_I_Amps.npy',
 'saved_consistent_scale':S/'action-01/consistent_residual_scale_I_Amps.npy',
 'field':S3/'run-01/corrected_derivative_Vpm.npy',
 'b3':S3/'projection-01/g4_projected_full_RHS.npy','V3':S3/'run-01/V_S3_V.npy',
 'trace':S1/'controls-01/receiver_trace_m.npy','H':S1/'oracle-01/Born_derivative_V.npy',
 'I':S1/'controls-01/interior_indices.npy','B':S1/'controls-01/boundary_indices.npy','gB':S2/'run-01/selected_gB_Vpm.npy',
 'starts':L5/'controls-01/edge_starts_m.npy','ends':L5/'controls-01/edge_ends_m.npy',
 'A0II':L5/'run-01/AII-csc.npz','L5_assignment':L5/'assignment.json','S1_assignment':S1/'assignment.json'}
expected_shapes={'bounds':(19584,2,3),'mapping':(19584,12),'cell_ids':(19584,), 'saved_consistent_residual':(54418,), 'saved_consistent_scale':(54418,), 'field':(63250,), 'b3':(63250,), 'V3':(2,), 'trace':(2,63250),'H':(2,2),'I':(54418,),'B':(8832,),'gB':(8832,),'starts':(63250,3),'ends':(63250,3)}
paths=list(names.values())+[S/'hodge_kernel.py',S/'manifest.json',P/'g03-hodge-main-acceptance-20261023/decision.json',P/'g03-hodge-solve-design-20261023/design_candidate.md',P/'g03-hodge-independent-20261023/solve-design-addendum.md',review/'manifest.json',review/'review.md',P/'g03-hodge-geometry-diagnosis-20261023/result.json',P/'r02-amd-wheel-acquisition-20261021/win_job.py',P/'r02-amd-wheel-acquisition-20261021/boundary.py',ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe',ROOT/'.local/deepeye-fdem-validation-20261020/Lib/site-packages/scipy/sparse/linalg/_isolve/iterative.py',ROOT/'docs/competition/deepeye-2026/immutable_scope.md',ROOT/'docs/competition/deepeye-2026/immutable_scope.json',ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json']
files={}
for p in paths:
 name=p.relative_to(ROOT).as_posix();value=pin(p)
 if name in known:assert value==known[name],name
 files[name]=value
headers={}
for alias,shape in expected_shapes.items():
 h=header(names[alias]);assert h['shape']==shape and h['descr'] not in ('O','|O'),alias;headers[alias]=h
l5=read(names['L5_assignment']);assert len(l5['z_nodes_m'])==35 and len(l5['level']['x_nodes_m'])==25 and 'z_nodes_m' not in l5['level']
s1=read(names['S1_assignment'])['inputs'];assert s1['turns']==1 and s1['frequency_Hz']==2e6
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json');h=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
t=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json');assert t['status']=='active' and t['director_generation']==2 and t['new_director_thread_id']=='01a13d7e-dcf1-7272-a738-a637dd62ff9d'
with (D/'input-pins.json').open('x',encoding='utf-8') as f:json.dump({'files':files,'paths':{k:p.relative_to(ROOT).as_posix() for k,p in names.items()},'headers':headers,'requirements_sha256':h,'no_numeric_arrays_loaded':True},f,indent=2);f.write('\n')
print(json.dumps({'input_pins':len(files),'headers_checked':len(headers),'kernel_copy_sha256':pin(D/'hodge_kernel.py')['sha256'],'schema':'top-level z_nodes_m and level.x_nodes_m verified','scope_hash':h}))
