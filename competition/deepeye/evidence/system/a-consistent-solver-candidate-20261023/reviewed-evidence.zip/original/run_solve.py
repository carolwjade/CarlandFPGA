"""Single-attempt staged runner; unchanged original held Windows guard."""
import ctypes as ct
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];SUPPORT=D.parent/'r02-amd-wheel-acquisition-20261021';PY=ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def save(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def pins():
 data=read(D/'input-pins.json');allpins=dict(data['files'])
 for n,p in allpins.items():assert pin(ROOT/n)==p,n
 assert pin(D/'hodge_kernel.py')==allpins[(D.parent/'g03-consistent-hodge-json-continuation-20261023/hodge_kernel.py').relative_to(ROOT).as_posix()]
 for n in ('assignment.md','plan.md','input-pins.json','test_assembly.py','consistent_assembler.py','hodge_kernel.py','solve_worker.py','run_solve.py','solve_stages.py'):
  if (D/n).exists():allpins[(D/n).relative_to(ROOT).as_posix()]=pin(D/n)
 return allpins
def memory():
 class MS(ct.Structure):
  _fields_=[('length',ct.c_uint32),('load',ct.c_uint32)]+[(n,ct.c_uint64) for n in ('total_physical','available_physical','total_page_file','available_page_file','total_virtual','available_virtual','extended_virtual')]
 s=MS();s.length=ct.sizeof(s)
 if not ct.windll.kernel32.GlobalMemoryStatusEx(ct.byref(s)):raise OSError('physical memory read')
 return {'available_physical_bytes':s.available_physical,'minimum_bytes':10*1024**3,'sufficient':s.available_physical>=10*1024**3}
def main():
 mode=sys.argv[1];assert mode in ('red','controls','assembly','actual');before=pins()
 if mode=='red':save(D/'red-source-pins.json',before)
 elif mode=='controls':
  assert read(D/'red-01/expected-red.json')['expected_missing_assembler']
  red=read(D/'red-source-pins.json')
  for n in ('test_assembly.py','solve_worker.py','run_solve.py'):
   key=(D/n).relative_to(ROOT).as_posix();assert red[key]==before[key]
  save(D/'frozen-source-pins.json',before)
 else:
  assert before==read(D/'frozen-source-pins.json')
  for folder,status in [('controls-01','two_new_assembly_fixtures_pass')]+([('assembly-01','consistent_assembly_identity_pass')] if mode=='actual' else []):
   assert read(D/folder/'result.json')['status']==status
   t=read(D/folder/'terminal.json');assert t['status']=='success' and t['all_processes_terminated']
 if mode=='actual':
  observed=memory();save(D/'actual-memory-preflight.json',observed)
  if not observed['sufficient']:raise RuntimeError('fresh physical memory below 10GiB; no solve launched')
 stage=D/({'red':'red-01','controls':'controls-01','assembly':'assembly-01','actual':'actual-01'}[mode])
 sys.path.insert(0,str(SUPPORT));from win_job import run_bounded,process_identity
 env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),'PATH':'','TEMP':str(stage),'TMP':str(stage),'TMPDIR':str(stage),'MPLCONFIGDIR':str(stage/'mplconfig'),'MPLBACKEND':'Agg','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',**{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS')}}
 budget={'seconds':90 if mode=='actual' else 30,'active_processes':3,'process_memory_bytes':4*1024**3 if mode=='actual' else 512*1024**2,'job_memory_bytes':5*1024**3 if mode=='actual' else 1024**3,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':256*1024**2,'tree_entries':2048,'free_reserve_bytes':512*1024**2}
 granted=False
 def tick(job,pids):
  nonlocal granted
  if (stage/'hello.json').exists() and not granted:
   h=read(stage/'hello.json');assert h['pid'] in pids and h['mode']==mode
   save(stage/'grant.pending.json',{'worker':process_identity(h['pid'],job),'mode':mode})
   os.replace(stage/'grant.pending.json',stage/'grant.json');granted=True
 result=run_bounded([str(PY),'-I','-B','-X','utf8',str(D/'solve_worker.py'),str(stage),mode],env,D,stage,budget,[D],on_tick=tick)
 after=pins();save(stage/'input-readback.json',{'unchanged':before==after,'before':before,'after':after})
 assert before==after and result['all_processes_terminated']
 if mode=='red':
  fail=read(stage/'failure.json');assert result['exit_code']==1 and result['stop_reason'] is None and fail['type']=='NotImplementedError' and fail['message']=='consistent CSR assembler not implemented'
  save(stage/'expected-red.json',{'expected_missing_assembler':True,'original_exit_code':1,'old_tests_repeated':False})
 print(json.dumps({k:result.get(k) for k in ('status','exit_code','seconds','stop_reason','peak_job_memory_bytes','all_processes_terminated','held_members')}),flush=True)
 return 0 if mode=='red' else result['exit_code'] if result['exit_code'] is not None else 125
if __name__=='__main__':raise SystemExit(main())
