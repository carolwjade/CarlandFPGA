# Consistent CSR assembly passed; selected GMRES correction failed

The original attempt stopped on GMRES info=3 after 78 inner callbacks. The finite returned candidate and true correction residual were saved before raising the stop. There was one factorization, one GMRES call, and no retry or repair. E4 construction, final full-field backward error, receiver trace identity and both unchanged 1% screens were not run after this stop. This is not a completed physical-accuracy screen.

Exactly two new assembly fixtures passed once after the recorded missing-assembler RED. Independent physical-coordinate rational expectations cover anisotropic shared-edge entries and row sums, the global gradient curl-null property, constant electric mass normalization and nonzero boundary inclusion. Old local kernel controls and the accepted saved action were reused without execution. The accepted kernel is byte-exact.

The single actual assembly produced a 63,250-square complex128 CSR with 1,969,810 entries and int32 indices. Exact actual endpoint geometry and unchanged nominal widths were checked. The exact S3 source and full S2 boundary were included before restricting to I. Ordinary-transpose symmetry passed. Agreement with the accepted saved consistent residual had maximum absolute difference 1.6684303565323341e-13 and maximum per-row error/bound ratio 0.0011000534410071548 using recorded assembly, CSR-dot and parent rounding scales. These arithmetic bounds are separate from backward error.

Fresh available memory was 16,613,638,144 bytes. The one unchanged saved A0II COLAMD factorization, used only as preconditioner, took 68.172 seconds. GMRES used the fixed complex128 zero start, rtol=1e-12, atol=0, restart=40, maxiter=3 and pr_norm callbacks. It returned info=3. The last callback was 5.722353007927609e-17; this preconditioned metric is not the true residual or evidence of convergence. The preserved true correction residual has infinity norm 3.7303494204107704e-14 and normwise correction backward eta 3.0175299991820747e-19 against the actual AcII infinity norm 22,104,298.128108893. A small correction backward error does not override nonzero info, nor establish final field/receiver accuracy.

The held actual stage ended normally as a failed worker at 84.281 seconds, peak job memory 3,420,585,984 bytes, with no resource stop. All three held processes were signaled and zero remained active. RED, controls and assembly also have complete raw commands, stdout/stderr, terminal receipts and unchanged source readbacks. NumPy 2.5.4 and SciPy 1.18.1 plus exact DLL hashes and one-thread counts were recorded before actual execution. The exception path did not record an after-runtime DLL readback; no such evidence is claimed.

Frozen-source-pins SHA256: 2fb51bf5bfe905cc761064040017a41ce67a397557951aa992240f317e41a820.
Assembler SHA256: 552268dff0977e43c5b28449250ca3a92aefe8acb0623cfa10556be562d0ea7e.
Solve stages SHA256: a26fc7c78542927429bde1581b5e91485dd289ad52f037580ad3da5a5b661b1f.
Two-fixture source SHA256: 7e088dcfd4654a01ab0c1332f47038c67c381d352d2070263a9511ce35e54a41.
Ac CSR SHA256: a61536db754948c36b4ae60f61135aa71766e02c40e67decdea54eda8df78f2e.
Exact S3 b3 SHA256: afc63e891dabb1a375ace341346392ae62ae0a2319c8b4cdb94fa6d3a0841ce5.

Root retains review and selection authority. The frozen candidate and residual can support a separately authorized saved-result diagnosis without repeating this attempt. No next solve or changed setting is selected here. Finite tau, noise, calibration, training, OOD, physical accuracy, G03, R03 and all29 remain unqualified/not_run. H01-H15 and DEEPEYE-HUMAN-LOCK-20261014/revision1 remain preserved. All writes were confined to this assigned evidence folder; no product, UI, service, board, Git or peer changes were made.
