"""Exactly two NEW global scatter fixtures, independent rational expectations.

No production kernel imports for expectations, quadrature, or old local tests.
"""
from fractions import Fraction as F
from itertools import product
import json
import numpy as np
EPS=np.finfo(float).eps
ZERO=(0,0,0)
def plus(a,b):
    c=dict(a)
    for p,v in b.items():c[p]=c.get(p,F(0))+v
    return {p:v for p,v in c.items() if v}
def mult(a,b):
    c={}
    for p,x in a.items():
        for q,y in b.items():
            r=tuple(p[i]+q[i] for i in range(3));c[r]=c.get(r,F(0))+x*y
    return c
def negative(a):return {p:-v for p,v in a.items()}
def diff(a,i):
    c={}
    for p,v in a.items():
        if p[i]:q=list(p);q[i]-=1;c[tuple(q)]=v*p[i]
    return c
def curl(v):return [plus(diff(v[2],1),negative(diff(v[1],2))),plus(diff(v[0],2),negative(diff(v[2],0))),plus(diff(v[1],0),negative(diff(v[0],1)))]
def dot(a,b):
    c={}
    for x,y in zip(a,b):c=plus(c,mult(x,y))
    return c
def integral(poly,lo,hi):
    total=F(0);scale=F(0)
    for powers,c in poly.items():
        value=c
        for j,power in enumerate(powers):value*=(hi[j]**(power+1)-lo[j]**(power+1))/F(power+1)
        total+=value;scale+=abs(value)
    return total,scale
def evaluate(poly,x):
    total=F(0)
    for powers,c in poly.items():
        for j,power in enumerate(powers):c*=x[j]**power
        total+=c
    return total
def fixture(nodes):
    nodes=[[F(v) for v in axis] for axis in nodes];shape=[len(a)-1 for a in nodes]
    edges=[];lookup={}
    for axis in range(3):
        limits=[shape[j]+int(j!=axis) for j in range(3)]
        for k,j,i in product(range(limits[2]),range(limits[1]),range(limits[0])):
            index=(i,j,k);lo=[nodes[t][index[t]] for t in range(3)];hi=list(lo);hi[axis]=nodes[axis][index[axis]+1]
            lookup[(axis,tuple(lo))]=len(edges);edges.append((axis,tuple(lo),tuple(hi)))
    bounds=[];mapping=[];bases=[]
    for k,j,i in product(range(shape[2]),range(shape[1]),range(shape[0])):
        sub=(i,j,k);lo=tuple(nodes[a][sub[a]] for a in range(3));hi=tuple(nodes[a][sub[a]+1] for a in range(3))
        local=[];basis=[]
        for axis in range(3):
            transverse=[a for a in range(3) if a!=axis]
            for second,first in product((0,1),repeat=2):
                start=list(lo);poly={ZERO:F(1)}
                for a,bit in zip(transverse,(first,second)):
                    start[a]=hi[a] if bit else lo[a];power=tuple(int(t==a) for t in range(3));h=hi[a]-lo[a]
                    factor={power:1/h,ZERO:-lo[a]/h} if bit else {ZERO:hi[a]/h,power:-1/h}
                    poly=mult(poly,factor)
                local.append(lookup[(axis,tuple(start))]);v=[{}, {}, {}];v[axis]=poly;basis.append(v)
        bounds.append((lo,hi));mapping.append(local);bases.append(basis)
    return nodes,edges,bounds,np.array(mapping,dtype=np.int32),bases
def check(actual,expected,scale,label):
    actual=np.asarray(actual);expected=np.asarray(expected);scale=np.asarray(scale)
    bound=128*EPS*(abs(actual)+abs(expected)+scale)
    error=abs(actual-expected)
    if actual.shape!=expected.shape or not np.all(error<=bound):raise AssertionError(label+' failed fixed sum bound')
    return {'passed':True,'max_error':float(np.max(error)),'max_bound':float(np.max(bound)),'scale_sum':float(np.sum(abs(actual)+abs(expected)+scale))}
def array(stage,name,a):
    with (stage/(name+'.npy')).open('xb') as f:np.save(f,np.asarray(a),allow_pickle=False)
def run(stage):
    import consistent_assembler as production
    # Fixture1: exactly two nonuniform anisotropic cells,20 unique global edges.
    nodes,edges,bounds,mapping,bases=fixture([['0','.03','.08'],['0','.04'],['0','.06']])
    n=len(edges);expected=np.zeros((n,n),dtype=complex);scale=np.zeros((n,n));mu=2.;omega=3.;zeta=complex(4,5);coeff=1j*omega*zeta
    rational=[]
    for cell,(lo,hi) in enumerate(bounds):
        curls=[curl(v) for v in bases[cell]]
        for i,gi in enumerate(mapping[cell]):
            for j,gj in enumerate(mapping[cell]):
                m,ms=integral(dot(bases[cell][i],bases[cell][j]),lo,hi);k,ks=integral(dot(curls[i],curls[j]),lo,hi)
                expected[gi,gj]+=float(k)/mu+coeff*float(m);scale[gi,gj]+=float(ks)/mu+abs(coeff)*float(ms)
                rational.append([int(gi),int(gj),str(m),str(k)])
    (stage/'fixture1-rational-expectations.json').write_text(json.dumps(rational)+'\n',encoding='utf-8')
    # RED must fail here for the missing assembler, after expectations exist.
    A,row_bound=production.assemble(np.array(bounds,dtype=float),mapping,n,mu,omega,zeta)
    shared=next(i for i,(axis,lo,hi) in enumerate(edges) if axis==1 and lo==(F(3,100),F(0),F(0)))
    selected=sorted(set([(i,i) for i in range(n)]+[(shared,j) for j in range(n)]+[(j,shared) for j in range(n)]))
    rr=np.array([v[0] for v in selected]);cc=np.array([v[1] for v in selected]);actual=np.asarray(A[rr,cc]).ravel()
    fixture1={'status':'pass','cells':2,'edges':n,'shared_edge_row':shared,
        'selected_entries':check(actual,expected[rr,cc],scale[rr,cc],'shared selected entries'),
        'row_sums':check(np.asarray(A.sum(axis=1)).ravel(),np.sum(expected,axis=1),np.sum(scale,axis=1),'global row sums')}
    array(stage,'fixture1_selected_rows',rr);array(stage,'fixture1_selected_cols',cc);array(stage,'fixture1_expected_entries',expected[rr,cc]);array(stage,'fixture1_actual_entries',actual)
    # Fixture2: eight cells,54 edges,nonzero boundary and true interior edges.
    nodes,edges,bounds,mapping,bases=fixture([['0','.02','.05'],['0','.03','.07'],['0','.04','.09']])
    n=len(edges);phi={(1,1,0):F(1),(0,1,1):F(2,5),(1,0,1):F(1,5),(1,1,1):F(1)};grad=[diff(phi,a) for a in range(3)]
    gradient=np.array([float((evaluate(phi,hi)-evaluate(phi,lo))/(hi[axis]-lo[axis])) for axis,lo,hi in edges])
    constant=np.array([[1.,-2.,3.][axis] for axis,lo,hi in edges])
    mass_gradient=np.zeros(n);mass_gradient_scale=np.zeros(n);mass_constant=np.zeros(n)
    for cell,(lo,hi) in enumerate(bounds):
        volume=float((hi[0]-lo[0])*(hi[1]-lo[1])*(hi[2]-lo[2]))
        for slot,gid in enumerate(mapping[cell]):
            val,vs=integral(dot(bases[cell][slot],grad),lo,hi);mass_gradient[gid]+=float(val);mass_gradient_scale[gid]+=float(vs)
            mass_constant[gid]+=volume/4*constant[gid]
    mu=2.;omega=3.;zeta=complex(4,5);coeff=1j*omega*zeta
    A,row_bound=production.assemble(np.array(bounds,dtype=float),mapping,n,mu,omega,zeta)
    grad_actual=A@gradient;const_actual=A@constant
    grad_scale=abs(A)@abs(gradient)+abs(coeff)*mass_gradient_scale
    const_scale=abs(A)@abs(constant)+abs(coeff)*abs(mass_constant)
    I=np.array([i for i,(axis,lo,hi) in enumerate(edges) if all(lo[j] not in (nodes[j][0],nodes[j][-1]) for j in range(3) if j!=axis)],dtype=np.int32)
    B=np.array([i for i in range(n) if i not in set(I)],dtype=np.int32)
    boundary=A[I,:][:,B]@gradient[B];without_boundary=A[I,:][:,I]@gradient[I]
    miss=abs(without_boundary-coeff*mass_gradient[I]);missbound=128*EPS*(grad_scale[I]+abs(without_boundary)+abs(coeff*mass_gradient[I]))
    if not np.any(abs(gradient[B])>0) or not np.any(miss>missbound):raise AssertionError('nonzero-boundary omission fixture insensitive')
    fixture2={'status':'pass','cells':8,'edges':n,'interior_edges':len(I),'boundary_edges':len(B),
        'global_gradient_curl_null_after_exact_mass':check(grad_actual,coeff*mass_gradient,grad_scale,'gradient with electric term'),
        'constant_mass_normalization':check(const_actual,coeff*mass_constant,const_scale,'constant mass normalization'),
        'interior_with_boundary':check(without_boundary+boundary,coeff*mass_gradient[I],grad_scale[I],'nonzero boundary'),
        'boundary_omission_rejected':True,'max_omission_error':float(np.max(miss))}
    for name,a in {'gradient':gradient,'constant':constant,'I':I,'B':B,'mass_gradient_expected':mass_gradient,'mass_constant_expected':mass_constant,'gradient_actual':grad_actual,'constant_actual':const_actual,'boundary_contribution':boundary}.items():array(stage,'fixture2_'+name,a)
    return {'status':'two_new_assembly_fixtures_pass','fixtures':[fixture1,fixture2],'new_fixture_count':2,'old_tests_rerun':0,'roundoff_factor':128,'expected_source':'independent physical-coordinate Fraction monomial integrals'}
