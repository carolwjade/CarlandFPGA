"""Preallocated numeric COO scatter into one consistent complex128 CSR."""
import numpy as np
from scipy import sparse
import hodge_kernel

def assemble(bounds,mapping,n_edges,mu,omega,zeta,chunk=256):
    bounds=np.asarray(bounds);mapping=np.asarray(mapping);cells=len(bounds)
    if bounds.shape!=(cells,2,3) or mapping.shape!=(cells,12) or not 0<cells<=19584:raise ValueError('cell bounds/map shape')
    if not np.issubdtype(mapping.dtype,np.integer) or not 0<n_edges<=63250:raise ValueError('edge indexing')
    if np.any(mapping<0) or np.any(mapping>=n_edges) or np.any(np.diff(np.sort(mapping,axis=1),axis=1)==0):raise ValueError('invalid local map')
    if not np.all(np.isfinite(bounds)) or np.any(bounds[:,1]<=bounds[:,0]):raise ValueError('invalid nominal bounds')
    if not (0<chunk<=256 and mu>0 and np.isfinite(mu) and np.isfinite(omega) and np.isfinite(zeta)):raise ValueError('physical/chunk parameters')
    entries=cells*144
    rows=np.empty(entries,dtype=np.int32);cols=np.empty(entries,dtype=np.int32);values=np.empty(entries,dtype=np.complex128)
    row_absolute_bound=np.zeros(n_edges,dtype=float);coefficient=1j*omega*zeta
    for first in range(0,cells,chunk):
        last=min(first+chunk,cells);ids=mapping[first:last]
        M,K,Ml,Kl=hodge_kernel.local_matrices(bounds[first:last,1]-bounds[first:last,0])
        local=K/mu+coefficient*M
        absolute=abs(K)/mu+abs(coefficient)*abs(M)
        section=slice(first*144,last*144)
        rows[section]=np.broadcast_to(ids[:,:,None],(last-first,12,12)).reshape(-1)
        cols[section]=np.broadcast_to(ids[:,None,:],(last-first,12,12)).reshape(-1)
        values[section]=local.reshape(-1)
        np.add.at(row_absolute_bound,ids.reshape(-1),np.sum(absolute,axis=2).reshape(-1))
    A=sparse.coo_matrix((values,(rows,cols)),shape=(n_edges,n_edges),dtype=np.complex128).tocsr()
    A.sum_duplicates();A.sort_indices()
    if not np.all(np.isfinite(A.data)) or not np.all(np.isfinite(row_absolute_bound)):raise ValueError('nonfinite assembled operator')
    return A,row_absolute_bound
