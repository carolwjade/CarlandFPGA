"""One new assembly and conditionally one fixed preconditioned correction."""
import gc,hashlib,json,math,time,warnings
from pathlib import Path
import numpy as np
from scipy import sparse
D=Path(__file__).resolve().parent;ROOT=D.parents[2];EPS=np.finfo(float).eps
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def pin(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def input_path(alias):
    spec=read(D/'input-pins.json');path=ROOT/spec['paths'][alias]
    if pin(path)!=spec['files'][spec['paths'][alias]]:raise ValueError('input pin '+alias)
    return path
def load(alias):
    value=np.load(input_path(alias),allow_pickle=False)
    if not np.all(np.isfinite(value)):raise ValueError('nonfinite input '+alias)
    return value
def arr(stage,name,a):
    if not np.all(np.isfinite(a)):raise ValueError('nonfinite output '+name)
    with (stage/(name+'.npy')).open('xb') as f:np.save(f,a,allow_pickle=False)
def pairs(a):return [[float(complex(x).real),float(complex(x).imag)] for x in np.asarray(a).reshape(-1)]
def geometry():
    bounds=load('bounds');mapping=load('mapping');ids=load('cell_ids');starts=load('starts');ends=load('ends')
    a=read(input_path('L5_assignment'));x=np.array(a['level']['x_nodes_m']);z=np.array(a['z_nodes_m']);nodes=[x,x,z]
    actual=[np.r_[n[0],np.diff(n)].cumsum() for n in nodes]
    if not np.array_equal(ids,np.arange(19584)) or bounds.shape!=(19584,2,3) or mapping.shape!=(19584,12):raise ValueError('frozen cell identity')
    sub=np.column_stack((ids%24,(ids//24)%24,ids//576))
    for axis in range(3):
        if not np.array_equal(bounds[:,0,axis],nodes[axis][sub[:,axis]]) or not np.array_equal(bounds[:,1,axis],nodes[axis][sub[:,axis]+1]):raise ValueError('nominal bounds changed')
    slot=0
    for axis in range(3):
        transverse=[j for j in range(3) if j!=axis]
        for second in (0,1):
            for first in (0,1):
                lo=np.column_stack([actual[j][sub[:,j]] for j in range(3)]);hi=lo.copy();hi[:,axis]=actual[axis][sub[:,axis]+1]
                for j,bit in zip(transverse,(first,second)):lo[:,j]=hi[:,j]=actual[j][sub[:,j]+bit]
                if not np.array_equal(starts[mapping[:,slot]],lo) or not np.array_equal(ends[mapping[:,slot]],hi):raise ValueError('exact actual endpoint mapping')
                slot+=1
    if not np.array_equal(np.unique(mapping),np.arange(63250)):raise ValueError('edge coverage')
    axes=np.argmax(ends-starts,axis=1);boundary=np.zeros(63250,dtype=bool)
    for axis in range(3):boundary|=(axes!=axis)&((starts[:,axis]==actual[axis][0])|(starts[:,axis]==actual[axis][-1]))
    I=load('I');B=load('B')
    if not np.array_equal(np.flatnonzero(boundary),B) or not np.array_equal(np.flatnonzero(~boundary),I):raise ValueError('geometric I/B')
    return bounds,mapping,I,B
def fixed_fields():
    I=load('I');B=load('B');E=load('field');g=load('gB');b=load('b3')
    if I.shape!=(54418,) or B.shape!=(8832,) or not np.array_equal(np.sort(np.r_[I,B]),np.arange(63250)):raise ValueError('partition')
    if E.shape!=(63250,) or b.shape!=(63250,) or g.shape!=(8832,) or E.dtype!=np.complex128 or b.dtype!=np.complex128:raise ValueError('field/source type or shape')
    if not np.array_equal(E[B],g) or np.any(b[B]!=0):raise ValueError('fixed field boundary or source B')
    return I,B,E,g,b
def csr_write(path,A):
    with path.open('xb') as f:np.savez(f,shape=np.asarray(A.shape),data=A.data,indices=A.indices,indptr=A.indptr)
def csr_read(path):
    with np.load(path,allow_pickle=False) as z:A=sparse.csr_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
    if not np.all(np.isfinite(A.data)) or not A.has_sorted_indices or not A.has_canonical_format:raise ValueError('invalid saved CSR')
    return A
def assembly(stage):
    import consistent_assembler
    bounds,mapping,I,B=geometry();I2,B2,E,g,b=fixed_fields()
    if not np.array_equal(I,I2) or not np.array_equal(B,B2):raise ValueError('partition readback')
    p=read(input_path('S1_assignment'))['inputs'];omega=2*math.pi*p['frequency_Hz'];zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm'];mu=p['mu_background_Hpm']
    save(stage/'before-assembly.json',{'new_CSR_assemblies_started':0,'cells':19584,'edges':63250,'maximum_triplets':2820096,'chunk_cells':256,'field_boundary_exact':True,'geometry':'exact actual cumulative endpoints and unchanged nominal widths','source_input':str(input_path('b3')),'source_pin':pin(input_path('b3'))})
    A,row_bound=consistent_assembler.assemble(bounds,mapping,63250,mu,omega,zeta,chunk=256)
    del bounds,mapping;gc.collect()
    if A.shape!=(63250,63250) or A.dtype!=np.complex128 or not A.has_canonical_format or not A.has_sorted_indices:raise ValueError('CSR format')
    actual_rows=np.asarray(abs(A).sum(axis=1)).ravel()
    sym=A-A.T;error_rows=np.asarray(abs(sym).sum(axis=1)).ravel();del sym;gc.collect()
    sym_bound=128*EPS*(2*row_bound+2*actual_rows)
    symmetry={'passed':bool(np.all(error_rows<=sym_bound)),'max_absolute_row_sum':float(np.max(error_rows)),'max_roundoff_bound':float(np.max(sym_bound))}
    save(stage/'symmetry.json',symmetry)
    if not symmetry['passed']:raise ArithmeticError('ordinary transpose symmetry')
    csr_write(stage/'Ac-csr.npz',A)
    rfull=A@E-b;rI=rfull[I]
    saved=load('saved_consistent_residual');parent=load('saved_consistent_scale')
    if saved.shape!=(54418,) or parent.shape!=(54418,) or np.any(parent<0):raise ValueError('saved residual identity inputs')
    dot_scale=abs(A)@abs(E)+abs(b)
    # Row assembly bound times full-field infinity norm is a declared upper
    # bound for coefficient accumulation error, distinct from actual ||AII||.
    assembly_scale=row_bound*float(np.max(abs(E)))
    identity_scale=assembly_scale[I]+dot_scale[I]+parent+abs(saved)
    identity_bound=128*EPS*identity_scale;identity_error=abs(rI-saved)
    identity={'passed':bool(np.all(identity_error<=identity_bound)),'max_absolute_difference':float(np.max(identity_error)),
        'max_roundoff_bound':float(np.max(identity_bound)),'scale_sum':float(np.sum(identity_scale)),
        'max_error_bound_ratio':float(np.max(np.divide(identity_error,identity_bound,out=np.zeros_like(identity_error),where=identity_bound>0))),
        'bound_scope':'arithmetic assembly/dot/parent scales only; not backward error or physical tolerance'}
    for name,value in {'r0_full_Amps':rfull,'r0_I_Amps':rI,'assembly_row_absolute_bound':row_bound,'assembly_dot_error_scale':assembly_scale,'CSR_dot_absolute_scale':dot_scale,'residual_identity_bound_I':identity_bound,'residual_identity_difference_I':rI-saved,'CSR_actual_absolute_row_sums':actual_rows}.items():arr(stage,name,value)
    save(stage/'residual-identity.json',identity)
    if not identity['passed']:raise ArithmeticError('new CSR residual disagrees with accepted saved action')
    receipt={'status':'consistent_assembly_identity_pass','factorization_started':False,'CSR':pin(stage/'Ac-csr.npz'),'r0_I':pin(stage/'r0_I_Amps.npy'),
        'used_input_pins':{alias:pin(input_path(alias)) for alias in ('field','gB','b3','I','B','saved_consistent_residual','saved_consistent_scale')},
        'Ac_shape':A.shape,'Ac_nnz':int(A.nnz),'actual_CSR_index_dtype':str(A.indices.dtype),'symmetry':symmetry,'residual_identity':identity,
        'new_full_CSR_assemblies':1,'old_A_C_assemblies':0,'PDE_solves':0,'source_changed':False,'boundary_included_before_I':True,
        'next_solve':'conditional one fixed GMRES using one saved A0II LU preconditioner','physical_accuracy':'unqualified','G03':'not_run'}
    save(stage/'pre-factorization.json',receipt)
    return receipt
def actual(stage):
    from scipy.sparse.linalg import LinearOperator,gmres,splu
    prior=D/'assembly-01';receipt=read(prior/'pre-factorization.json')
    if receipt['status']!='consistent_assembly_identity_pass' or pin(prior/'Ac-csr.npz')!=receipt['CSR'] or pin(prior/'r0_I_Amps.npy')!=receipt['r0_I']:raise ValueError('new assembly pins')
    A=csr_read(prior/'Ac-csr.npz');I,B,E,g,b=fixed_fields();r0=np.load(prior/'r0_I_Amps.npy',allow_pickle=False)
    if r0.shape!=(54418,) or not np.all(np.isfinite(r0)):raise ValueError('r0')
    AII=A[I,:][:,I].tocsr();AII.sum_duplicates();AII.sort_indices()
    normA=float(np.max(np.asarray(abs(AII).sum(axis=1)).ravel()))
    boundary_field=np.zeros(63250,dtype=complex);boundary_field[B]=g
    boundary_action=(A@boundary_field)[I];effective_rhs=b[I]-boundary_action
    if not normA>0 or not np.all(np.isfinite(effective_rhs)):raise ValueError('actual norm/effective rhs')
    arr(stage,'boundary_adjusted_rhs_I_Amps',effective_rhs);arr(stage,'boundary_operator_action_I_Amps',boundary_action)
    old_path=input_path('A0II')
    with np.load(old_path,allow_pickle=False) as z:A0=sparse.csc_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
    if A0.shape!=(54418,54418) or not np.all(np.isfinite(A0.data)):raise ValueError('old preconditioner matrix')
    save(stage/'before-factorization.json',{'factorizations_started':0,'selected_preconditioner':'one unchanged saved L5 A0II COLAMD LU','A0II_pin':pin(old_path),'Ac_pin':receipt['CSR'],'new_target_AII_nnz':int(AII.nnz),'actual_target_AII_inf_norm':normA,'rtol':1e-12,'atol':0,'restart':40,'maxiter':3,'callback_type':'pr_norm','maximum_callbacks':120,'x0':'zero complex128','full_boundary_preserved':True})
    began=time.monotonic()
    with warnings.catch_warnings():
        warnings.simplefilter('error');lu=splu(A0,permc_spec='COLAMD')
    save(stage/'factorization-complete.json',{'factorizations':1,'seconds':time.monotonic()-began,'matrix':'saved A0II only','ordering':'COLAMD'})
    del A0;gc.collect()
    M=LinearOperator(AII.shape,matvec=lu.solve,dtype=np.complex128);history=[]
    with (stage/'gmres-callbacks.jsonl').open('x',encoding='utf-8') as log:
        def callback(value):
            value=float(value)
            if not math.isfinite(value) or len(history)>=120:raise ArithmeticError('callback nonfinite or selected limit')
            history.append(value);log.write(json.dumps({'inner_iteration':len(history),'preconditioned_relative_residual':value})+'\n');log.flush()
        with warnings.catch_warnings():
            warnings.simplefilter('error')
            delta,info=gmres(AII,-r0,x0=np.zeros(54418,dtype=np.complex128),rtol=1e-12,atol=0.,restart=40,maxiter=3,M=M,callback=callback,callback_type='pr_norm')
    # Preserve candidate and true correction residual even when info!=0.
    finite=bool(np.all(np.isfinite(delta)))
    save(stage/'gmres-return.json',{'info':int(info),'callbacks':len(history),'history':history,'candidate_finite':finite,'factorizations':1,'GMRES_calls':1})
    if not finite:raise ArithmeticError('GMRES nonfinite candidate')
    correction_residual=AII@delta+r0
    arr(stage,'returned_GMRES_candidate_delta_I_Vpm',delta);arr(stage,'true_correction_residual_I_Amps',correction_residual)
    corrden=normA*float(np.max(abs(delta)))+float(np.max(abs(r0)))
    correction_eta=float(np.max(abs(correction_residual))/corrden) if corrden else None
    save(stage/'correction-residual.json',{'info':int(info),'actual_AII_inf_norm':normA,'residual_inf':float(np.max(abs(correction_residual))),'eta':correction_eta,'callback_metric_is_not_true_residual':True})
    del lu,M;gc.collect()
    if info!=0:raise RuntimeError('GMRES nonzero info; candidate and true correction residual preserved; no retry')
    full_delta=np.zeros(63250,dtype=complex);full_delta[I]=delta;E4=E+full_delta
    if not np.array_equal(E4[B],g):raise ValueError('boundary changed')
    final_full_residual=A@E4-b;final_I=final_full_residual[I]
    den=normA*float(np.max(abs(E4[I])))+float(np.max(abs(effective_rhs)))
    if not den>0 or not math.isfinite(den):raise ArithmeticError('undefined final backward denominator')
    eta=float(np.max(abs(final_I))/den)
    trace=load('trace');V3=load('V3');H=load('H')[1]
    if trace.shape!=(2,63250) or V3.shape!=(2,) or H.shape!=(2,):raise ValueError('receiver/reference shapes')
    deltaV=trace[:,I]@delta;V4=trace@E4;updated=V3+deltaV
    trace_scale=np.sum(abs(trace*E4[None,:]),axis=1)+abs(V3)+np.sum(abs(trace[:,I]*delta[None,:]),axis=1)
    trace_bound=128*EPS*trace_scale;trace_error=abs(V4-updated)
    if np.any(trace_error>trace_bound):raise ArithmeticError('new full trace versus saved V3 plus correction')
    roundoff=128*EPS*np.sum(abs(trace*E4[None,:]),axis=1)
    stable=(abs(H)>roundoff)&(abs(V4)>roundoff)
    absolute=abs(V4-H);relative=[float(absolute[r]/abs(H[r])) if stable[r] else None for r in range(2)]
    for name,value in {'delta_full_Vpm':full_delta,'E4_full_Vpm':E4,'final_residual_full_Amps':final_full_residual,'final_residual_I_Amps':final_I,'V4_full_trace_V':V4,'V4_update_V':updated,'delta_V':deltaV,'V4_minus_H_V':V4-H,'receiver_trace_roundoff_bound_V':trace_bound}.items():arr(stage,name,value)
    passed=math.isfinite(eta) and eta<=128*EPS and all(x is not None and x<=.01 for x in relative)
    return {'status':'consistent_correction_screens_pass' if passed else 'consistent_correction_completed_failed_screen','selected_screens_pass':passed,
        'factorizations':1,'GMRES_calls':1,'GMRES_info':int(info),'inner_callbacks':len(history),'actual_Ac_II_inf_norm':normA,
        'boundary_adjusted_rhs_inf':float(np.max(abs(effective_rhs))),'final_field_interior_inf':float(np.max(abs(E4[I]))),
        'final_residual_I_inf':float(np.max(abs(final_I))),'backward_eta':eta,'backward_eta_gate':128*EPS,'correction_backward_eta':correction_eta,
        'V3_V':pairs(V3),'delta_V':pairs(deltaV),'V4_V':pairs(V4),'H_reference_V':pairs(H),'absolute_error_V':absolute.tolist(),'relative_error':relative,
        'fixed_relative_gate':.01,'roundoff_denominator_threshold_V':roundoff.tolist(),'trace_identity_error_V':trace_error.tolist(),'trace_identity_bound_V':trace_bound.tolist(),
        'gB_exactly_preserved':True,'source_b3_pin':pin(input_path('b3')),'Ac_pin':receipt['CSR'],'old_test_replays':0,'physical_accuracy':'unqualified','finite_tau':'not_run','noise_calibration_training_OOD':'unqualified','G03':'not_run','R03':'not_run','all29':'not_run'}
