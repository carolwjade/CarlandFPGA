"""RED stub for the new global CSR scatter implementation."""
def assemble(bounds,mapping,n_edges,mu,omega,zeta,chunk=256):
    raise NotImplementedError('consistent CSR assembler not implemented')
