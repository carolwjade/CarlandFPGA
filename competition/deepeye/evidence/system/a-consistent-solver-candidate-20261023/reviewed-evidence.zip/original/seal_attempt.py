"""Inert receipt and byte-integrity sealing; never imports numerical packages."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent; ROOT=D.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def write(p,s):
    with p.open('x',encoding='utf-8') as f:f.write(s)
frozen=read(D/'frozen-source-pins.json')
assert all(pin(ROOT/n)==p for n,p in frozen.items())
stages={}
for name in ('red-01','controls-01','assembly-01','actual-01'):
    t=read(D/name/'terminal.json');r=read(D/name/'input-readback.json')
    assert t['all_processes_terminated'] and t['active_processes_final']==0
    assert len(t['held_members'])==3 and all(x['signaled'] for x in t['held_members'])
    assert r['unchanged'] and r['before']==r['after']
    stages[name]={k:t[k] for k in ('status','exit_code','seconds','stop_reason','peak_job_memory_bytes','all_processes_terminated','held_members')}
assert read(D/'red-01/expected-red.json')['expected_missing_assembler']
assert read(D/'controls-01/result.json')['status']=='two_new_assembly_fixtures_pass'
a=read(D/'assembly-01/result.json'); assert a['status']=='consistent_assembly_identity_pass'
g=read(D/'actual-01/gmres-return.json');c=read(D/'actual-01/correction-residual.json');f=read(D/'actual-01/failure.json')
assert g['info']==3 and g['callbacks']==78 and g['candidate_finite']
assert f['type']=='RuntimeError' and 'nonzero info' in f['message']
assert stages['actual-01']['status']=='failed' and stages['actual-01']['stop_reason'] is None
assert not (D/'actual-01/result.json').exists() and not (D/'actual-01/E4_full_Vpm.npy').exists()
assert len((D/'actual-01/gmres-callbacks.jsonl').read_text().splitlines())==g['callbacks']
summary={'work_id':'A-G03-CONSISTENT-SOLVE-20261023-v1','job_id':'child-abd114fb46834bb5b74894d281122564',
 'status':'failed_GMRES_nonconvergence_no_retry','contract':'DEEPEYE-HUMAN-LOCK-20261014/revision1',
 'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','H01_H15':'preserved',
 'source_freeze':pin(D/'frozen-source-pins.json'),'stages':stages,'assembly':a,'gmres':g,'true_correction_residual':c,
 'candidate':pin(D/'actual-01/returned_GMRES_candidate_delta_I_Vpm.npy'),
 'correction_residual_array':pin(D/'actual-01/true_correction_residual_I_Amps.npy'),
 'new_assembly_fixture_count':2,'full_CSR_assemblies':1,'factorizations':1,'GMRES_calls':1,'old_test_replays':0,'retries':0,
 'E4_final_full_field':'not_run_after_stop','final_full_field_backward_error':'not_run_after_stop',
 'receiver_trace_identity':'not_run_after_stop','both_unchanged_1percent_screens':'not_run_after_stop',
 'physical_accuracy':'unqualified','finite_tau_noise_calibration_training_OOD':'not_run','G03':'not_run','R03':'not_run','all29':'not_run',
 'actual_runtime_after':'not_recorded_after_exception; before runtime identities and one-thread counts are retained',
 'acceptance_owner':'root','no_product_UI_service_board_Git_peer_changes':True}
save(D/'summary.json',summary)
report='''# Consistent CSR assembly passed; selected GMRES correction failed

The original attempt stopped on GMRES info=3 after 78 inner callbacks. The finite returned candidate and true correction residual were saved before raising the stop. There was one factorization, one GMRES call, and no retry or repair. E4 construction, final full-field backward error, receiver trace identity and both unchanged 1% screens were not run after this stop. This is not a completed physical-accuracy screen.

Exactly two new assembly fixtures passed once after the recorded missing-assembler RED. Independent physical-coordinate rational expectations cover anisotropic shared-edge entries and row sums, the global gradient curl-null property, constant electric mass normalization and nonzero boundary inclusion. Old local kernel controls and the accepted saved action were reused without execution. The accepted kernel is byte-exact.

The single actual assembly produced a 63,250-square complex128 CSR with 1,969,810 entries and int32 indices. Exact actual endpoint geometry and unchanged nominal widths were checked. The exact S3 source and full S2 boundary were included before restricting to I. Ordinary-transpose symmetry passed. Agreement with the accepted saved consistent residual had maximum absolute difference 1.6684303565323341e-13 and maximum per-row error/bound ratio 0.0011000534410071548 using recorded assembly, CSR-dot and parent rounding scales. These arithmetic bounds are separate from backward error.

Fresh available memory was 16,613,638,144 bytes. The one unchanged saved A0II COLAMD factorization, used only as preconditioner, took 68.172 seconds. GMRES used the fixed complex128 zero start, rtol=1e-12, atol=0, restart=40, maxiter=3 and pr_norm callbacks. It returned info=3. The last callback was 5.722353007927609e-17; this preconditioned metric is not the true residual or evidence of convergence. The preserved true correction residual has infinity norm 3.7303494204107704e-14 and normwise correction backward eta 3.0175299991820747e-19 against the actual AcII infinity norm 22,104,298.128108893. A small correction backward error does not override nonzero info, nor establish final field/receiver accuracy.

The held actual stage ended normally as a failed worker at 84.281 seconds, peak job memory 3,420,585,984 bytes, with no resource stop. All three held processes were signaled and zero remained active. RED, controls and assembly also have complete raw commands, stdout/stderr, terminal receipts and unchanged source readbacks. NumPy 2.5.4 and SciPy 1.18.1 plus exact DLL hashes and one-thread counts were recorded before actual execution. The exception path did not record an after-runtime DLL readback; no such evidence is claimed.

Frozen-source-pins SHA256: 2fb51bf5bfe905cc761064040017a41ce67a397557951aa992240f317e41a820.
Assembler SHA256: 552268dff0977e43c5b28449250ca3a92aefe8acb0623cfa10556be562d0ea7e.
Solve stages SHA256: a26fc7c78542927429bde1581b5e91485dd289ad52f037580ad3da5a5b661b1f.
Two-fixture source SHA256: 7e088dcfd4654a01ab0c1332f47038c67c381d352d2070263a9511ce35e54a41.
Ac CSR SHA256: a61536db754948c36b4ae60f61135aa71766e02c40e67decdea54eda8df78f2e.
Exact S3 b3 SHA256: afc63e891dabb1a375ace341346392ae62ae0a2319c8b4cdb94fa6d3a0841ce5.

Root retains review and selection authority. The frozen candidate and residual can support a separately authorized saved-result diagnosis without repeating this attempt. No next solve or changed setting is selected here. Finite tau, noise, calibration, training, OOD, physical accuracy, G03, R03 and all29 remain unqualified/not_run. H01-H15 and DEEPEYE-HUMAN-LOCK-20261014/revision1 remain preserved. All writes were confined to this assigned evidence folder; no product, UI, service, board, Git or peer changes were made.
'''
write(D/'report.md',report)
private={'lease.private.json','reserve-request.json','reserve.stderr.txt'}
files={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in private}
assert sum(x['bytes'] for x in files.values())<256*1024**2
save(D/'manifest.json',{'files':files,'total_bytes':sum(x['bytes'] for x in files.values()),'excludes':'private lease and reservation records; manifest itself and final completion text'})
m=pin(D/'manifest.json')
text=f"A-G03-CONSISTENT-SOLVE-20261023-v1 failed and stopped without retry: one fixed GMRES returned info=3 after 78 callbacks. Both new assembly fixtures and the one full consistent CSR/residual identity stage passed. One old-A0II COLAMD LU and one GMRES call only. The finite candidate and true correction residual are preserved; residual infinity 3.7303494204107704e-14, correction backward eta 3.0175299991820747e-19. No E4/final full-field eta/receiver screen after stop; G03/R03/all29 remain not_run. Actual stage 84.281 s, peak job 3420585984 B, no resource stop, all three held processes terminated. All source pins unchanged, old tests not replayed, H01-H15 preserved. Evidence: .planning/deepeye-resume-20261018/g03-consistent-solve-20261023/report.md and summary.json. Manifest SHA256 {m['sha256']}; {len(files)} files, {sum(x['bytes'] for x in files.values())} bytes. Root owns acceptance."
write(D/'native-final.txt',text+'\n')
assert all(pin(D/n)==p for n,p in files.items())
print(json.dumps({'status':summary['status'],'manifest':m,'files':len(files),'bytes':sum(x['bytes'] for x in files.values()),'candidate':summary['candidate'],'residual':summary['correction_residual_array']}))
