"""Recorded source and process evidence review, no scientific execution."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent;S=P/'g03-consistent-solve-20261023';R=P/'g03-consistent-solve-main-review-20261023'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
assert pin(S/'manifest.json')['sha256']=='7526ecfb910f6cd85c3d57e66633fd2805a6a6b1ec7de2d57c7007de655f5ca6'
assert pin(S/'summary.json')['sha256']=='3dfde2cc58d7fc7e211418e113c0a4c47da03b25a9abd29ec521b51064b47347'
sources={}
def verify(base,table):
 for n,v in table.items():
  q=base/n;assert pin(q)==v,str(q);sources[q.relative_to(ROOT).as_posix()]=v
 return len(table)
mf=verify(S,read(S/'manifest.json')['files']);inputs=read(S/'input-pins.json');ic=verify(ROOT,inputs['files']);fc=verify(ROOT,read(S/'frozen-source-pins.json'))
prior=read(R/'original-native-result.json');assert prior['status']=='failed' and prior['terminal'] and not prior['stale'] and prior['result'] is None
verify(S,read(R/'pre-execution-source-review.json')['files'])
for q in [S/'manifest.json',R/'original-native-result.json',R/'pre-execution-source-review.json']:
 sources[q.relative_to(ROOT).as_posix()]=pin(q)
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json');sh=hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest();assert sh=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json');assert transfer['status']=='active' and transfer['director_generation']==2
stages=[]
for mode in ['red','controls','assembly','actual']:
 q=S/(mode+'-01');t=read(q/'terminal.json');rb=read(q/'input-readback.json');start=read(q/'started.json')
 assert t['all_processes_terminated'] and t['active_processes_final']==0 and len(t['held_members'])==3 and all(h['signaled'] and h['wait_result']==0 for h in t['held_members'])
 assert rb['unchanged'] and rb['before']==rb['after']
 for stream in ['stdout','stderr']:assert pin(q/(stream+'.txt'))==t['logs'][stream]
 if (q/'result.json').exists():assert read(q/'result.json')==json.loads((q/'stdout.txt').read_text())
 runtime=read(q/'worker-evidence.json') if (q/'worker-evidence.json').exists() else read(q/'failure.json')
 before=runtime.get('runtime_before');assert before and all(v['threads']==1 for v in before['BLAS'])
 if runtime.get('runtime_after'):assert all(v['threads']==1 for v in runtime['runtime_after']['BLAS'])
 for v in before['BLAS']:
  path=Path(v['path']);assert pin(path)['sha256']==v['sha256'];sources[path.relative_to(ROOT).as_posix()]=pin(path)
 stages.append({'mode':mode,'terminal':t,'budget':start['budget'],'runtime_after_recorded':'runtime_after' in runtime})
assert [v['terminal']['exit_code'] for v in stages]==[1,0,0,1]
g=read(S/'actual-01/gmres-return.json');cb=[json.loads(line) for line in (S/'actual-01/gmres-callbacks.jsonl').read_text().splitlines()]
assert g['info']==3 and len(cb)==g['callbacks']==78 and [v['preconditioned_relative_residual'] for v in cb]==g['history'] and [v['inner_iteration'] for v in cb]==list(range(1,79))
assert 'GMRES nonzero info' in read(S/'actual-01/failure.json')['message'] and not (S/'actual-01/result.json').exists()
assert not (S/'actual-01/E4_full_Vpm.npy').exists() and not (S/'actual-01/worker-evidence.json').exists()
save('source-pins.json',sources);save('audit-paths.json',{'original_inputs':inputs['paths'],'Ac':(S/'assembly-01/Ac-csr.npz').relative_to(ROOT).as_posix(),'candidate':(S/'actual-01/returned_GMRES_candidate_delta_I_Vpm.npy').relative_to(ROOT).as_posix(),'correction_residual':(S/'actual-01/true_correction_residual_I_Amps.npy').relative_to(ROOT).as_posix(),'r0':(S/'assembly-01/r0_I_Amps.npy').relative_to(ROOT).as_posix(),'beff':(S/'actual-01/boundary_adjusted_rhs_I_Amps.npy').relative_to(ROOT).as_posix(),'boundary_action':(S/'actual-01/boundary_operator_action_I_Amps.npy').relative_to(ROOT).as_posix(),'old_dot_scale':(S/'assembly-01/CSR_dot_absolute_scale.npy').relative_to(ROOT).as_posix()})
save('source-audit.json',{'status':'recorded_evidence_verified','manifest_entries':mf,'input_entries':ic,'frozen_entries':fc,'source_count':len(sources),'requirements_sha256':sh,'original_native':prior,'stages':stages,'GMRES_info':3,'callbacks_verified':78,'solver_status':'failed_nonzero_info','after_runtime_absent_due_exception':True,'controls_reused':read(S/'controls-01/result.json'),'assembly_reused':read(S/'assembly-01/result.json'),'source_input_b3':inputs['paths']['b3'],'no_scientific_execution':True})
print(json.dumps({'manifest_entries':mf,'input_entries':ic,'frozen_entries':fc,'pins':len(sources),'all12heldterminated':True,'selected_solve_failed':True,'callbacks':len(cb)}))
