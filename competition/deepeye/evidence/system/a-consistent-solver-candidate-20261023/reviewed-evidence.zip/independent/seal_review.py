"""Preserve failed diagnostic and review evidence, no numerical recovery."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
src=read(D/'source-pins.json');assert all(pin(ROOT/n)==v for n,v in src.items())
t=read(D/'audit-01/terminal.json');failure=read(D/'audit-01/failure.json');rb=read(D/'audit-input-readback.json')
assert t['exit_code']==1 and t['stop_reason'] is None and t['all_processes_terminated'] and t['active_processes_final']==0
assert len(t['held_members'])==3 and all(h['signaled'] and h['wait_result']==0 for h in t['held_members'])
assert rb['prior_source_pins_unchanged'] and rb['audit_source_pins_unchanged'] and rb['before']==rb['after'] and rb['own_before']==rb['own_after']
assert failure['type']=='TypeError' and failure['message']=='Object of type bool is not JSON serializable'
partial=D/'audit-01/result.json'
try:read(partial)
except json.JSONDecodeError:malformed=True
else:malformed=False
assert malformed
for stream in ['stdout','stderr']:assert pin(D/('audit-01/'+stream+'.txt'))==t['logs'][stream]
outputs={p.name:pin(p) for p in sorted((D/'audit-01').glob('*.npy'))}
review={'work_id':'A-G03-CONSISTENT-CANDIDATE-INDEPENDENT-20261023-v1','job_id':'child-296f363637e348b9b77ef917e295d61f','agent_id':'/root/g03_hodge_independent_20261023','status':'source_review_complete_candidate_diagnostic_failed_serialization','selected_solve_status':'failed_nonzero_info','original_GMRES_info':3,'candidate_evaluation':'diagnostic_only','integration_allowed':False,'formal_acceptance_by_child':False,'source_pins_verified':len(src),'original_manifest_entries_verified':89,'original_four_stages_all12held_confirmed':True,'one_new_audit_attempt':True,'audit_terminal':t,'audit_failure':failure,'result_json_malformed':True,'partial_result_pin':pin(partial),'raw_arrays_written_before_failure':outputs,'comparison_coverage_observation':'Seven comparison branches reached and persisted error/bound arrays; final metadata write failed afterward. No completed diagnostic result exists.','numeric_observations':'See review.md for exact scalar fields visibly persisted in partial JSON prefix; no receiver-screen metadata was recovered.','findings':[{'id':'F1','severity':'medium','text':'Original fixed GMRES failed its true relative2norm convergence test; preserve info3 despite small backward error.'},{'id':'F2','severity':'medium','text':'Independent audit left NumPy boolean in metadata and failed final serialization; partial JSON invalid; raw outputs preserved without retry/recovery.'},{'id':'F3','severity':'low','text':'Saved operator/candidate arithmetic does not certify physical receiver accuracy or product acceptance.'}],'scope':{'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','H01_H15_preserved':True,'G03':'not_run','R03':'not_run','all29':'not_run','finite_tau':'not_run','physical_accuracy':'unqualified','noise_calibration_training_OOD':'unqualified'},'old_tests_controls_assemblies_LU_GMRES_Green_replayed':0,'new_PDE_solves':0,'repair_retry_or_metadata_recovery_after_failure':False,'source_readbacks_unchanged':True,'root_retains':'metadata recovery selection, numerical next step, acceptance, integration'}
save('review.json',review)
excluded={'lease.private.json','manifest.json','native-completion.json','final-verification.json'}
files={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in excluded and p.suffix!='.pyc'}
save('manifest.json',{'work_id':review['work_id'],'files':files,'private_and_postseal_records_excluded':sorted(excluded),'failed_audit_preserved':True})
assert all(pin(D/n)==v for n,v in read(D/'manifest.json')['files'].items())
save('final-verification.json',{'status':'review_artifacts_verified','manifest':pin(D/'manifest.json'),'entries':len(files),'prior_pins_unchanged':len(src),'audit_exit':1,'result_json_malformed':True,'all3heldsignaled':True,'raw_array_count':len(outputs),'no_retry':True})
print(json.dumps(read(D/'final-verification.json')))
