"""Bind existing held launcher to this independent candidate-only script."""
import difflib
from pathlib import Path
D=Path(__file__).resolve().parent;P=D.parent
old=(P/'g03-hodge-independent-continuation-20261023/run_audit.py').read_text(encoding='utf-8');new=old
changes=[("['array_audit.py','run_audit.py','prepare_continuation.py','source-pins.json','continuation-source-audit.json','coordinate-review.md','audit-exact-diff.patch','launcher-exact-diff.patch']","['candidate_audit.py','run_audit.py','prepare_runner.py','provenance.py','source-pins.json','source-audit.json','audit-paths.json','pre-execution-review.md']"),("'tree_bytes':64*1024**2","'tree_bytes':128*1024**2"),("'mode':'independent-array-audit'","'mode':'candidate_diagnostic'"),("str(D/'array_audit.py')","str(D/'candidate_audit.py')")]
for a,b in changes:assert new.count(a)==1;new=new.replace(a,b)
with (D/'run_audit.py').open('x',encoding='utf-8',newline='\n') as f:f.write(new)
with (D/'launcher-diff.patch').open('x',encoding='utf-8') as f:f.write(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='reviewed-held-launcher',tofile='candidate-launcher')))
