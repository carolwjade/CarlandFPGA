"""One saved-CSR/candidate diagnostic. No assembler, LU or GMRES imports/calls."""
import ctypes as ct,hashlib,json,math,os,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];stage=Path(sys.argv[1]).resolve()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
save(stage/'hello.json',{'pid':os.getpid(),'mode':'candidate_diagnostic','before_scientific_import':True})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
 if time.monotonic()>deadline:raise RuntimeError('held worker grant missing')
 time.sleep(.01)
assert read(stage/'grant.json')['worker']['pid']==os.getpid()
paths=read(D/'audit-paths.json');allowed_npz=(ROOT/paths['Ac']).resolve()
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):raise PermissionError('no network/subprocess')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).resolve();mode=args[1];flags=args[2]
  writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if writing and not p.is_relative_to(stage):raise PermissionError('stage writes only')
  if not writing and p.suffix=='.npz' and p!=allowed_npz:raise PermissionError('only saved Ac CSR allowed')
sys.addaudithook(audit);began=time.monotonic();runtime_before=None
try:
 import numpy as np
 import scipy,scipy.linalg
 from scipy import sparse
 eps=np.finfo(float).eps
 def runtime():
  win=ct.WinDLL('kernel32',use_last_error=True);win.GetModuleHandleW.argtypes=[ct.c_wchar_p];win.GetModuleHandleW.restype=ct.c_void_p;out=[]
  for folder,symbol in [('numpy.libs','scipy_openblas_get_num_threads64_'),('scipy.libs','scipy_openblas_get_num_threads')]:
   dll=list((Path(np.__file__).resolve().parents[1]/folder).glob('*openblas*.dll'));assert len(dll)==1
   handle=win.GetModuleHandleW(str(dll[0]));assert handle
   getter=getattr(ct.CDLL(str(dll[0]),handle=handle),symbol);getter.argtypes=[];getter.restype=ct.c_int;assert getter()==1
   out.append({'path':str(dll[0]),'sha256':hashlib.sha256(dll[0].read_bytes()).hexdigest(),'threads':1})
  return {'numpy':np.__version__,'scipy':scipy.__version__,'BLAS':out}
 runtime_before=runtime();pins=read(D/'source-pins.json');loaded={}
 def checked(q):
  n=q.relative_to(ROOT).as_posix();h=hashlib.sha256()
  with q.open('rb') as f:
   for block in iter(lambda:f.read(1024**2),b''):h.update(block)
  p={'bytes':q.stat().st_size,'sha256':h.hexdigest()};assert p==pins[n],n;loaded[n]=p;return q
 def load(alias):
  name=paths.get(alias,paths['original_inputs'].get(alias));a=np.load(checked(ROOT/name),allow_pickle=False);assert np.all(np.isfinite(a)),alias;return a
 def arr(n,a):
  assert np.all(np.isfinite(a)),n
  with (stage/(n+'.npy')).open('xb') as f:np.save(f,a,allow_pickle=False)
 def pairs(v):return [[float(complex(x).real),float(complex(x).imag)] for x in v]
 with np.load(checked(allowed_npz),allow_pickle=False) as z:
  assert set(z.files)=={'shape','data','indices','indptr'};A=sparse.csr_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
 assert A.shape==(63250,63250) and A.nnz==1969810 and A.dtype==np.complex128 and np.all(np.isfinite(A.data)) and A.has_canonical_format and A.has_sorted_indices
 I=load('I');B=load('B');E3=load('field');g=load('gB');b=load('b3');delta=load('candidate');r0=load('r0');savedcorr=load('correction_residual');savedbeff=load('beff');savedboundary=load('boundary_action');oldscale=load('old_dot_scale')
 assert I.shape==(54418,) and B.shape==(8832,) and np.array_equal(np.sort(np.r_[I,B]),np.arange(63250))
 assert E3.shape==b.shape==(63250,) and delta.shape==r0.shape==savedcorr.shape==(54418,) and np.array_equal(E3[B],g) and np.all(b[B]==0)
 AII=A[I,:][:,I].tocsr();AIB=A[I,:][:,B].tocsr()
 # Independently compensated complex CSR sums; matrices are loaded, never rebuilt.
 def apply(M,x):
  value=np.empty(M.shape[0],dtype=np.complex128);scale=np.empty(M.shape[0])
  for row in range(M.shape[0]):
   lo,hi=M.indptr[row:row+2];prod=M.data[lo:hi]*x[M.indices[lo:hi]]
   value[row]=complex(math.fsum(map(float,prod.real)),math.fsum(map(float,prod.imag)))
   scale[row]=math.fsum(map(float,abs(M.data[lo:hi])*abs(x[M.indices[lo:hi]])))
  return value,scale
 checks={}
 def compare(name,left,right,scale):
  error=abs(left-right);bound=128*eps*(np.asarray(scale)+abs(left)+abs(right))
  ok=bool(np.all(error<=bound));checks[name]={'passed':ok,'max_error':float(np.max(error)),'max_bound':float(np.max(bound))}
  arr(name+'_error',error);arr(name+'_bound',bound)
  if not ok:raise ArithmeticError(name+' arithmetic comparison failed')
 boundary,bs=apply(AIB,g);beff=b[I]-boundary
 compare('boundary_action',boundary,savedboundary,bs)
 compare('boundary_adjusted_rhs',beff,savedbeff,abs(b[I])+bs)
 corr_action,cs=apply(AII,delta);corr=corr_action+r0
 compare('correction_residual_compensated',corr,savedcorr,cs+abs(r0))
 standardcorr=AII@delta+r0
 compare('correction_residual_standard',standardcorr,savedcorr,cs+abs(r0))
 full_delta=np.zeros(63250,dtype=np.complex128);full_delta[I]=delta;E4=E3+full_delta
 assert np.array_equal(full_delta[B],np.zeros(len(B))) and np.array_equal(E4[B],g)
 final_action,fs=apply(A,E4);final_full=final_action-b;final=final_full[I]
 compare('final_vs_saved_correction',final,savedcorr,fs[I]+abs(b[I])+cs+abs(r0)+oldscale[I])
 rownorm=np.empty(len(I))
 for row in range(len(I)):
  lo,hi=AII.indptr[row:row+2];rownorm[row]=math.fsum(map(float,abs(AII.data[lo:hi])))
 normA=float(np.max(rownorm));prior_norm=read(ROOT/'.planning/deepeye-resume-20261018/g03-consistent-solve-20261023/actual-01/correction-residual.json')['actual_AII_inf_norm']
 assert abs(normA-prior_norm)<=128*eps*(normA+prior_norm)
 def norm2(a):return math.sqrt(math.fsum(float(abs(v))**2 for v in a))
 r0norm=norm2(r0);fixedtol=1e-12*r0norm
 norm_saved=norm2(savedcorr);norm_standard=norm2(standardcorr);norm_comp=norm2(corr)
 denominator=normA*float(np.max(abs(E4[I])))+float(np.max(abs(beff)));assert denominator>0
 eta=float(np.max(abs(final)))/denominator
 trace=load('trace');V3=load('V3');Hfull=load('H');assert trace.shape==(2,63250) and V3.shape==(2,) and Hfull.shape==(2,2);H=Hfull[1]
 def compensated_trace(field):
  values=[];scales=[]
  for row in trace:
   prod=row*field;values.append(complex(math.fsum(map(float,prod.real)),math.fsum(map(float,prod.imag))));scales.append(math.fsum(map(float,abs(prod))))
  return np.array(values),np.array(scales)
 V4,vscale=compensated_trace(E4);dV,dscale=compensated_trace(full_delta);oldV,oldvscale=compensated_trace(E3);updated=V3+dV
 compare('saved_V3_trace',oldV,V3,oldvscale)
 compare('V4_trace_update',V4,updated,vscale+dscale+oldvscale+abs(V3))
 receiver_roundoff=128*eps*vscale;stable=(abs(H)>receiver_roundoff)&(abs(V4)>receiver_roundoff)
 relative=[float(abs(V4[j]-H[j])/abs(H[j])) if stable[j] else None for j in range(2)]
 receiverpass=all(v is not None and v<=.01 for v in relative);etapass=math.isfinite(eta) and eta<=128*eps
 for n,v in {'candidate_delta_full_Vpm':full_delta,'candidate_E4_full_Vpm':E4,'true_correction_residual_compensated':corr,'true_correction_residual_standard':standardcorr,'candidate_final_residual_full_Amps':final_full,'candidate_final_residual_I_Amps':final,'candidate_final_residual_sum_scale_I':fs[I]+abs(b[I]),'actual_AII_absolute_row_sums':rownorm,'boundary_adjusted_rhs_compensated':beff,'boundary_action_compensated':boundary,'V4_compensated_V':V4,'delta_V_compensated':dV,'V4_from_saved_V3_plus_delta_V':updated,'H_high_reference_V':H,'V4_minus_H_V':V4-H,'receiver_roundoff_bound_V':receiver_roundoff}.items():arr(n,v)
 result={'status':'saved_candidate_diagnostic_complete','selected_solve_status':'failed_nonzero_info','GMRES_info':3,'candidate_evaluation':'diagnostic_only','integration_allowed':False,'checks':checks,'CSR':{'shape':A.shape,'nnz':A.nnz,'AII_nnz':AII.nnz,'canonical_sorted':True},'fixed_GMRES_gate':{'rtol':1e-12,'atol':0,'r0_2norm':r0norm,'absolute_2norm_threshold':fixedtol,'saved_true_correction_residual_2norm':norm_saved,'standard_true_correction_residual_2norm':norm_standard,'compensated_true_correction_residual_2norm':norm_comp,'saved_residual_to_threshold_ratio':norm_saved/fixedtol,'standard_residual_to_threshold_ratio':norm_standard/fixedtol,'compensated_residual_to_threshold_ratio':norm_comp/fixedtol,'original_callback_metric_separate':True,'interpretation':'Original nonzero info remains failure; direct summation variants expose floating reduction effects without changing settings.'},'candidate_backward_error':{'actual_AII_infinity_norm':normA,'saved_normA_difference':normA-prior_norm,'boundary_adjusted_rhs_inf':float(np.max(abs(beff))),'candidate_field_interior_inf':float(np.max(abs(E4[I]))),'denominator':denominator,'final_residual_inf':float(np.max(abs(final))),'eta':eta,'fixed_eta_gate':128*eps,'screen_pass':etapass,'gB_exactly_preserved':True},'candidate_receivers':{'V3_V':pairs(V3),'delta_V':pairs(dV),'V4_V':pairs(V4),'H_high_reference_V':pairs(H),'absolute_error_V':list(map(float,abs(V4-H))),'complex_relative_error':relative,'fixed_gate':.01,'receiver_denominators_stable':list(map(bool,stable)),'screen_pass':receiverpass,'summation':'independent math.fsum for real/imaginary complex products; ordinary trace, no conjugation'},'candidate_all_screens_pass':etapass and receiverpass,'source_and_arrays_loaded':loaded,'runtime_before':runtime_before,'runtime_after':runtime(),'elapsed_seconds':time.monotonic()-began,'old_tests_controls_assemblies_LU_GMRES_Green_replayed':0,'PDE_solves':0,'physical_accuracy':'unqualified','finite_tau':'not_run','noise_calibration_training_OOD':'unqualified','G03':'not_run','R03':'not_run','all29':'not_run','limitations':'Saved CSR/candidate evaluation only; no solver acceptance or physical qualification. Assembly source/control evidence reused.'}
 save(stage/'result.json',result);print(json.dumps(result),flush=True)
except BaseException as exc:
 save(stage/'failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),'elapsed_seconds':time.monotonic()-began,'runtime_before':runtime_before});raise
