"""Root metadata-only recovery from a preserved partial JSON and tiny arrays.

No scientific imports, CSR reads, field/operator evaluation or solver execution.
The original audit and solve remain failed; only the report is completed here.
"""
import ast,asyncio,hashlib,json,math,struct,sys
from pathlib import Path
from datetime import datetime,timezone
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent
sys.path.insert(0,str(ROOT))
from fpga_mesh.child_control import LocalControlFileClient
from fpga_mesh.project_cli import discovery
R=P/'g03-consistent-candidate-independent-20261023';A=R/'audit-01'
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def read(p):return json.loads(p.read_bytes())
def save(n,v):
    with (D/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
job=asyncio.run(LocalControlFileClient(discovery(ROOT)).call('job',{'job_id':'child-296f363637e348b9b77ef917e295d61f'}))
native={k:job.get(k) for k in ['job_id','work_id','native_agent_id','status','terminal','stale','result','error']}
assert native['status']=='completed' and native['terminal'] and not native['stale'];save('independent-native-result.json',native)
assert pin(R/'manifest.json')['sha256']=='a657acd73a59d16f7ae85d38d3befa3af97e98af8e4f84e720c4c243ada25cd2'
manifest=read(R/'manifest.json')
for name,v in manifest['files'].items():assert pin(R/name)==v,name
t=read(A/'terminal.json');assert t['exit_code']==1 and t['all_processes_terminated'] and len(t['held_members'])==3 and all(h['signaled'] for h in t['held_members'])
for name in ['stdout','stderr']:
    q=pin(A/(name+'.txt'));assert q==t['logs'][name]
prefix=(A/'result.json').read_text(encoding='utf-8')
assert prefix.rstrip().endswith('"screen_pass":')
# Complete the unfinished value as NULL for parsing only, then derive its
# native bool from the already persisted scalar eta and fixed bound.
partial=json.loads(prefix+'null}}')
assert partial['status']=='saved_candidate_diagnostic_complete' and partial['GMRES_info']==3
assert all(v['passed'] for v in partial['checks'].values()) and len(partial['checks'])==7
back=partial['candidate_backward_error'];assert back['screen_pass'] is None
back['screen_pass']=bool(math.isfinite(back['eta']) and back['eta']<=back['fixed_eta_gate'])
inputs={}
def tiny_npy(p,complex_values=True):
    raw=p.read_bytes();assert len(raw)<=512 and raw[:8]==b'\x93NUMPY\x01\x00'
    n=struct.unpack('<H',raw[8:10])[0];header=ast.literal_eval(raw[10:10+n].decode('latin1'))
    assert header=={'descr':'<c16' if complex_values else '<f8','fortran_order':False,'shape':(2,)}
    v=struct.unpack('<4d' if complex_values else '<2d',raw[10+n:]);assert all(math.isfinite(x) for x in v)
    inputs[p.relative_to(ROOT).as_posix()]=pin(p)
    return [complex(v[0],v[1]),complex(v[2],v[3])] if complex_values else list(v)
v4=tiny_npy(A/'V4_compensated_V.npy');href=tiny_npy(A/'H_high_reference_V.npy');dv=tiny_npy(A/'delta_V_compensated.npy')
updated=tiny_npy(A/'V4_from_saved_V3_plus_delta_V.npy');difference=tiny_npy(A/'V4_minus_H_V.npy');bound=tiny_npy(A/'receiver_roundoff_bound_V.npy',False)
trace_error=tiny_npy(A/'V4_trace_update_error.npy',False);trace_bound=tiny_npy(A/'V4_trace_update_bound.npy',False)
assert all(difference[j]==v4[j]-href[j] for j in range(2))
assert all(trace_error[j]<=trace_bound[j] for j in range(2))
stable=[abs(href[j])>bound[j] and abs(v4[j])>bound[j] for j in range(2)]
relative=[abs(difference[j])/abs(href[j]) if stable[j] else None for j in range(2)]
pair=lambda values:[[v.real,v.imag] for v in values]
receiver={'V4_V':pair(v4),'delta_V':pair(dv),'V4_from_saved_V3_plus_delta_V':pair(updated),'H_high_reference_V':pair(href),
    'absolute_error_V':[abs(v) for v in difference],'complex_relative_error':relative,'fixed_gate':.01,
    'receiver_denominators_stable':stable,'screen_pass':all(v is not None and v<=.01 for v in relative),
    'trace_update_error_V':trace_error,'trace_update_bound_V':trace_bound,'source':'previously computed independent compensated trace arrays; stdlib two-scalar metadata reduction only'}
record={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'metadata_recovered_from_saved_diagnostic_outputs',
    'original_selected_solve_status':'failed_nonzero_info','GMRES_info':3,'original_independent_audit_exit_code':1,
    'original_audit_failure':'NumPy bool serialization after arrays and seven arithmetic comparisons were completed',
    'original_partial_json_pin':pin(A/'result.json'),'independent_manifest_sha256':pin(R/'manifest.json')['sha256'],
    'manifest_members_verified':len(manifest['files']),'preserved_partial_result':partial,'candidate_receivers':receiver,
    'candidate_all_screens_pass':bool(back['screen_pass'] and receiver['screen_pass']),
    'candidate_evaluation':'diagnostic_only','integration_allowed':False,'metadata_inputs':inputs,
    'scientific_imports':0,'matrix_or_field_reads':0,'operator_actions':0,'factorizations':0,'solves':0,'old_tests_replayed':0,
    'original_failed_sources_logs_and_arrays_unchanged':True,'runtime_after_claimed':False,
    'physical_accuracy':'unqualified','G03':'not_run','R03':'not_run','finite_tau':'not_run','all29':'not_run',
    'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'}
for name,v in manifest['files'].items():assert pin(R/name)==v,name
save('candidate-metadata-recovery.json',record)
print(json.dumps({'status':record['status'],'eta':back['eta'],'receiver_relative_error':relative,'candidate_all_screens_pass':record['candidate_all_screens_pass'],'original_info':3,'old_tests_replayed':0}))
