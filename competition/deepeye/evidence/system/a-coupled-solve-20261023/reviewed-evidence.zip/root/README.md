# Coupled face solve: reviewed experiment

One global GMRES solve converged (info0, 47 callbacks, 70.984s), but receiver errors 5.8587% and 3.5278% fail the unchanged 1% screens. The candidate is retained for diagnosis and is not installed as a qualified runtime model.

A separate 0.640s stdlib audit independently checked eleven fixed equation rows, saved residual identities, exact boundary/update and both receiver reductions. Full augmented norm and full direct/reduced boolean remain dependencies on the reviewed producer.

The archive retains the original Schur sign control failure, its selected correction, the bounded preconditioner allocation change, the raw-NPZ preflight failure, the narrow CSR/CSC loader repair, new controls and exact source/output identities. No prior passed test group or scientific solve was replayed.

H01-H15 remain fixed at requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804. G03/R03/all29 remain not_run. Next work prioritizes new real-board/simulator integration alongside a separately justified G03 approximation change.
