"""Unselected production path. No import triggers a numerical operation."""
import numpy as np
from scipy import sparse
from selection_gate import require_format_selection,ROOT
from raw_sparse import load_raw
import coupled_core as core,numerical_policy as policy,raw_outputs as raw
def run(stage,phase):
 spec,selection=require_format_selection();aliases=spec['aliases']
 def load(name):return np.load(ROOT/aliases[name],allow_pickle=False)
 def coupled(name):return load('coupled_'+name)
 A=load_raw(ROOT/aliases['Ac'],'csr',(63250,63250));A0=load_raw(ROOT/aliases['A0II'],'csc',(54418,54418))
 I=load('I');B=load('B');gB=load('gB');Eh=load('Eh');ids=coupled('closure_indices');m=len(ids)
 assert A.shape==(len(Eh),len(Eh)) and len(I)+len(B)==len(Eh) and len(np.unique(np.concatenate((I,B))))==len(Eh)
 assert np.array_equal(Eh[B],gB) and 0<m<=804
 D=sparse.coo_matrix((coupled('D'),(coupled('Q_rows'),coupled('Q_cols'))),shape=(m,m)).tocsr()
 U=sparse.coo_matrix((coupled('U'),(coupled('U_rows'),coupled('U_cols'))),shape=(len(Eh),m)).tocsr()
 b8=load('b8');db=load('delta_b8_minus_b4');r4=load('rEh4_compensated');F8=coupled('F8_Q');ell=coupled('ell8_Q')
 assert np.array_equal(F8,load('F8')[ids]) and np.array_equal(ell,load('ell8')[ids])
 beff8=load('beff4_compensated')+db[I]
 raw.require_finite(gB,b8,beff8,F8)
 got=core.run_condensed(A,U,D,I,Eh,r4,db,ell,A0,stage,phase)
 augmented=policy.augmented(A,U,D,I,B,got['e'],got['alpha'],b8,F8,beff8,gB)
 raw.arrays(stage,augmented.pop('arrays'))
 verdict=policy.status(got['info'],got['strict_pass'],augmented)
 numerical=verdict in ('strict_converged_candidate','roundoff_limited_candidate')
 metadata={k:v for k,v in got.items() if k not in ('e','alpha','delta')}
 metadata.update(status=verdict,augmented=augmented,physical_screens='not_run',selected_screens_pass=False,actual_global_GMRES_calls=1,old_tests_replayed=0,G03='not_run',R03='not_run',all29='not_run',H01_H15_preserved=True,requirements_sha256=spec['requirements_sha256'])
 if numerical:
  # Original high reference is first decoded only here, after new numerical gate.
  trace=load('trace');tQ=coupled('tQ');H=load('high_H_saved');oldV=load('old_Vh_compensated')
  physical=policy.receiver(trace,tQ,got['e'],got['alpha'],H,oldV,I,got['delta'])
  raw.arrays(stage,physical.pop('arrays'));metadata.update(physical_screens=physical,selected_screens_pass=physical['passed'])
 return metadata
