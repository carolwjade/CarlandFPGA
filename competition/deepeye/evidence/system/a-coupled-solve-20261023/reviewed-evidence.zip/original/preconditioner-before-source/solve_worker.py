"""Held-grant worker; controls cannot read production arrays or matrices."""
import ctypes as ct,hashlib,json,os,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];stage=Path(sys.argv[1]).resolve();mode=sys.argv[2]
sys.path.insert(0,str(ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools'))
from evidence_json import write_new_report as save,dumps_report
save(stage/'hello.json',{'pid':os.getpid(),'mode':mode,'before_scientific_import':True})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
 if time.monotonic()>deadline:raise RuntimeError('no held grant')
 time.sleep(.01)
assert json.loads((stage/'grant.json').read_bytes())['worker']['pid']==os.getpid()
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):raise PermissionError('no network/subprocess')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).resolve();m=args[1];flags=args[2]
  writing=(isinstance(m,str) and any(c in m for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if writing and not p.is_relative_to(stage):raise PermissionError('stage-only writes')
  if not writing and p.suffix in ('.npy','.npz') and mode!='actual' and not p.is_relative_to(stage):raise PermissionError('no production arrays in controls')
sys.addaudithook(audit);sys.path.insert(0,str(D));seq=0
def phase(name):
 global seq
 row={'phase':name,'started_monotonic':time.monotonic(),'sequence':seq};save(stage/f'phase-{seq:02d}.json',row);save(stage/'phase.pending.json',row);os.replace(stage/'phase.pending.json',stage/'phase.current.json');seq+=1
def runtime():
 import numpy as np
 import scipy,scipy.linalg
 k=ct.WinDLL('kernel32',use_last_error=True);k.GetModuleHandleW.argtypes=[ct.c_wchar_p];k.GetModuleHandleW.restype=ct.c_void_p;rows=[]
 for folder,symbol in [('numpy.libs','scipy_openblas_get_num_threads64_'),('scipy.libs','scipy_openblas_get_num_threads')]:
  paths=list((Path(np.__file__).resolve().parents[1]/folder).glob('*openblas*.dll'));assert len(paths)==1;handle=k.GetModuleHandleW(str(paths[0]));assert handle
  getter=getattr(ct.CDLL(str(paths[0]),handle=handle),symbol);getter.argtypes=[];getter.restype=ct.c_int;assert getter()==1
  rows.append({'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),'threads':1})
 return {'numpy':np.__version__,'scipy':scipy.__version__,'BLAS':rows}
before=None;after=None;after_attempted=False;began=time.monotonic()
try:
 phase('preflight');before=runtime();expected=json.loads((D/'input-pins.json').read_bytes())['runtime'];assert before==expected
 if mode in ('red','controls','corrected-controls'):
  import test_solver_controls
  result=test_solver_controls.run(stage)
 else:
  import actual_stage
  result=actual_stage.run(stage,phase)
 after_attempted=True;after=runtime();assert before==after;save(stage/'worker-evidence.json',{'runtime_before':before,'runtime_after':after,'elapsed_seconds':time.monotonic()-began})
 save(stage/'result.json',result);print(dumps_report(result),end='',flush=True)
 if result.get('selected_screens_pass') is False:raise SystemExit(2)
except BaseException as exc:
 original={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()};after_failure=None
 if before is not None and not after_attempted:
  after_attempted=True
  try:after=runtime()
  except BaseException as runtime_exc:after_failure={'type':type(runtime_exc).__name__,'message':str(runtime_exc),'traceback':traceback.format_exc()}
 elif before is None:after_failure={'status':'not_attempted','reason':'initial scientific runtime failed; imports are not retried'}
 elif after is None:after_failure={'status':'already_attempted_failed','reason':'original exception records after-runtime failure; it is not retried'}
 try:save(stage/'failure.json',{**original,'runtime_before':before,'runtime_after':after,'runtime_after_diagnostic':after_failure,'elapsed_seconds':time.monotonic()-began})
 except BaseException as report_exc:
  print('failure metadata diagnostic: '+type(report_exc).__name__+': '+str(report_exc),file=sys.stderr,flush=True)
 raise
