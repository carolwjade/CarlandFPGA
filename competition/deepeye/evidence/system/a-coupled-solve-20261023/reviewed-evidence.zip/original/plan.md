# Coupled correction implementation plan

> Inline execution of the root-selected design. No subagents, Git or product writes.

**Goal:** implement one gated new coupled correction and its genuinely new solver/output/policy controls.
**Architecture:** coupled_core.py owns full-D Schur GMRES; numerical_policy.py owns independent full augmented and physical checks; raw_outputs.py owns exclusive raw-before-verdict persistence. actual_stage.py consumes accepted explicit aliases only. solve_worker.py/run_solve.py reuse the exact held guard/runtime helper.
**Stack:** pinned Python/NumPy/SciPy, BLAS1; unchanged evidence_json and win_job.

## Constraints

- Write only this folder. Preserve all failed evidence and H01-H15 SHA c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
- No production numerical arrays in controls, old tests/source/operator replay or automatic actual solve.
- Actual requires accepted coupled manifest/reviewer disposition and a separate exact-pin root selection.
- One controls group, fixed RED then first GREEN; genuine failure stops for root disposition, no retry/capraise.

## Steps

- [ ] freeze_fixture.py: independent Fraction complex literal matrix/solution/load/current/boundary/trace expectations, no implementation imports.
- [ ] test_solver_controls.py: real tiny Schur GMRES known-solution integration; synthetic status-policy branches; raw-nonfinite-before-rejection and strict report failure persistence.
- [ ] Freeze fixture/test/runner/worker before RED; stub run_condensed raises NotImplementedError; bounded expected RED.
- [ ] Implement coupled_core.py, numerical_policy.py and raw_outputs.py against frozen expectations; no production reads.
- [ ] Implement actual_stage.py with pending acceptance aliases and no automatic selection; source-review to root/reviewer.
- [ ] First GREEN under unchanged held guard: 15s/512MiBprocess/1GiBjob/3held/16MiBtree, BLAS1 before/after.
- [ ] Seal source/control handoff, raw terminal/after pins and pending actual stage. Await root final selection; no global execution in this authorization.

Exact interfaces: run_condensed(A,U,D,I,Eh,r4,db,ell,A0,stage,phase); augmented(A,U,D,I,B,e,alpha,b8,F8,beff8,gB); status(info,strict_pass,augmented_result); receiver(trace,tQ,e,alpha,H,oldV,I,delta); raw_outputs.persist_return(stage,delta,info), publish(stage,payload).
