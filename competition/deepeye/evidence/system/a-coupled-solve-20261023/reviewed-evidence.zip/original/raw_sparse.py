"""Read this project's four-component archives without changing their values."""
import numpy as np
from scipy import sparse
def load_raw(path,kind,expected_shape):
 if kind not in ('csr','csc'):raise ValueError('explicit csr/csc role required')
 with np.load(path,allow_pickle=False) as archive:
  if set(archive.files)!={'shape','data','indices','indptr'}:raise ValueError('raw sparse archive members')
  shape=archive['shape'];data=archive['data'];indices=archive['indices'];indptr=archive['indptr']
 if shape.shape!=(2,) or shape.dtype.kind!='i':raise ValueError('raw sparse shape vector')
 dimensions=tuple(int(v) for v in shape)
 if dimensions!=tuple(expected_shape) or any(v<=0 for v in dimensions):raise ValueError('raw sparse dimensions')
 if data.ndim!=1 or data.dtype!=np.complex128 or indices.ndim!=1 or indptr.ndim!=1 or indices.dtype.kind!='i' or indptr.dtype.kind!='i':raise ValueError('raw sparse component dimensions/dtypes')
 major,minor=dimensions if kind=='csr' else dimensions[::-1]
 if len(data)!=len(indices) or len(indptr)!=major+1:raise ValueError('raw sparse component lengths')
 if indptr[0]!=0 or indptr[-1]!=len(data) or np.any(indptr<0) or np.any(indptr>len(data)) or np.any(indptr[1:]<indptr[:-1]):raise ValueError('raw sparse pointers')
 if np.any(indices<0) or np.any(indices>=minor):raise ValueError('raw sparse index bounds')
 if not np.all(np.isfinite(data)):raise ValueError('raw sparse nonfinite data')
 cls=sparse.csr_matrix if kind=='csr' else sparse.csc_matrix
 matrix=cls((data,indices,indptr),shape=dimensions)
 if not matrix.has_sorted_indices or not matrix.has_canonical_format:raise ValueError('raw sparse must already be sorted/canonical')
 return matrix
