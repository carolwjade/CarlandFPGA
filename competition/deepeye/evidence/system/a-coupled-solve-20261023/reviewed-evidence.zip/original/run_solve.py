"""Separate one-shot controls and root-gated actual stages; exact held guard."""
import ctypes as ct,hashlib,json,os,sys,time
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
sys.path.insert(0,str(ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools'))
from evidence_json import write_new_report as save,dumps_report
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def pins():
 spec=read(D/'input-pins.json');p={n:pin(ROOT/n) for n in spec['files']};assert p==spec['files']
 for f in D.glob('*.py'):p[f.relative_to(ROOT).as_posix()]=pin(f)
 for n in ('fixture.json','plan.md','assignment.md','input-pins.json'):p[(D/n).relative_to(ROOT).as_posix()]=pin(D/n)
 if (D/'correction-record.json').exists():p[(D/'correction-record.json').relative_to(ROOT).as_posix()]=pin(D/'correction-record.json')
 if (D/'preconditioner-delta-record.json').exists():p[(D/'preconditioner-delta-record.json').relative_to(ROOT).as_posix()]=pin(D/'preconditioner-delta-record.json')
 for n in ('format-fixture.json','format-delta-record.json'):
  if (D/n).exists():p[(D/n).relative_to(ROOT).as_posix()]=pin(D/n)
 return p
def free_memory():
 class MS(ct.Structure):_fields_=[('length',ct.c_uint32),('load',ct.c_uint32)]+[(n,ct.c_uint64) for n in ('total','available','page_total','page_available','virtual_total','virtual_available','extended')]
 s=MS();s.length=ct.sizeof(s)
 if not ct.windll.kernel32.GlobalMemoryStatusEx(ct.byref(s)):raise OSError('memory query')
 return s.available
def main():
 mode=sys.argv[1];assert mode in ('red','controls','corrected-controls','preconditioner-controls','format-red','format-controls','format-actual','actual');before=pins();spec=read(D/'input-pins.json');stage=D/(mode+'-01')
 if mode=='red':save(D/'red-source-pins.json',before)
 elif mode=='controls':
  assert read(D/'red-01/expected-red.json')['expected_missing_solver'];old=read(D/'red-source-pins.json')
  for n in ('test_solver_controls.py','fixture.json','input-pins.json'):
   key=(D/n).relative_to(ROOT).as_posix();assert old[key]==before[key]
  revision=read(D/'pre-green-revision.json');assert revision['root_selection']==pin(D.parent/'g03-coupled-solve-main-review-20261023/pre-green-worker-revision-selection.json')
  for n in ('solve_worker.py','run_solve.py'):
   key=(D/n).relative_to(ROOT).as_posix();assert revision['before'][n]==old[key] and revision['after'][n]==before[key]
  save(D/'control-source-pins.json',before)
 elif mode=='corrected-controls':
  correction=read(D/'correction-record.json');selection=read(D.parent/'g03-coupled-solve-main-review-20261023/schur-rhs-correction-selection.json')
  assert selection['correction_selected'] and selection['one_corrected_control_group_selected'] and not selection['global_solve_selected']
  assert correction['root_selection']==pin(D.parent/'g03-coupled-solve-main-review-20261023/schur-rhs-correction-selection.json')
  assert selection['original_failed_terminal']==pin(D/'controls-01/terminal.json') and selection['original_failed_source_pins']==pin(D/'control-source-pins.json')
  failed=read(D/'control-source-pins.json')
  for n in ('fixture.json','test_solver_controls.py','input-pins.json'):
   key=(D/n).relative_to(ROOT).as_posix();assert before[key]==failed[key]
  for name,value in correction['after'].items():assert pin(D/name)==value
  for name,value in correction['snapshot'].items():assert pin(D/'failed-green-source'/name)==value
  save(D/'corrected-control-source-pins.json',before)
 elif mode=='preconditioner-controls':
  delta=read(D/'preconditioner-delta-record.json');selected=read(D.parent/'g03-coupled-solve-main-review-20261023/preconditioner-output-delta-selection.json')
  assert selected['delta_implementation_and_targeted_control_selected'] and not selected['actual_global_solve_selected']
  assert delta['root_selection']==pin(D.parent/'g03-coupled-solve-main-review-20261023/preconditioner-output-delta-selection.json')
  assert selected['previous_successful_control_pins']==pin(D/'corrected-control-source-pins.json') and selected['previous_successful_control_terminal']==pin(D/'corrected-controls-01/terminal.json')
  for name,value in delta['after'].items():assert pin(D/name)==value
  for name,value in delta['snapshot'].items():assert pin(D/'preconditioner-before-source'/name)==value
  save(D/'preconditioner-control-source-pins.json',before)
 elif mode=='format-red':
  selected=read(D.parent/'g03-coupled-solve-main-review-20261023/sparse-format-correction-selection.json');delta=read(D/'format-delta-record.json')
  assert selected['implementation_selected'] and not selected['new_actual_selected']
  assert delta['root_selection']==pin(D.parent/'g03-coupled-solve-main-review-20261023/sparse-format-correction-selection.json')
  assert selected['original_terminal']==pin(D/'actual-01/terminal.json') and selected['original_final_manifest']==pin(D/'actual-final-manifest.json')
  for name,value in delta['snapshot'].items():assert pin(D/'format-before-source'/name)==value
  for name,value in delta['pre_RED_framework'].items():assert pin(D/name)==value
  save(D/'format-red-source-pins.json',before)
 elif mode=='format-controls':
  assert read(D/'format-red-01/expected-red.json')['expected_missing_raw_loader']
  old=read(D/'format-red-source-pins.json');allowed=(D/'raw_sparse.py').relative_to(ROOT).as_posix()
  assert set(before)==set(old) and all(v==before[k] for k,v in old.items() if k!=allowed)
  save(D/'format-source-pins.json',before)
 elif mode=='format-actual':
  from selection_gate import require_format_selection
  spec,selection=require_format_selection();assert before==read(D/'format-source-pins.json')
  available=free_memory();save(D/'format-actual-memory-preflight.json',{'available_physical_bytes':available,'minimum_bytes':10*1024**3});assert available>=10*1024**3
 else:
  selection=read(ROOT/spec['root_actual_selection_path'])
  assert selection['actual_solve_selected'] is True and selection['assembly_accepted'] is True
  from selection_gate import require_selection
  require_selection()
  assert selection['control_stage']=='corrected-controls-01' and selection['source_pins_sha256']==pin(D/'preconditioner-control-source-pins.json')['sha256'] and before==read(D/'preconditioner-control-source-pins.json')
  assert read(D/'corrected-controls-01/terminal.json')['status']=='success' and read(D/'corrected-controls-01/result.json')['status']=='new_solver_policy_output_controls_pass'
  available=free_memory();save(D/'actual-memory-preflight.json',{'available_physical_bytes':available,'minimum_bytes':10*1024**3});assert available>=10*1024**3
 sys.path.insert(0,str(D.parent/'r02-amd-wheel-acquisition-20261021'));from win_job import run_bounded,process_identity
 env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),'PATH':'','TEMP':str(stage),'TMP':str(stage),'TMPDIR':str(stage),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',**{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS')}}
 budget={k:spec['actual_budgets'][k] for k in ('seconds','active_processes','process_memory_bytes','job_memory_bytes','stdout_bytes','stderr_bytes','tree_bytes','tree_entries','free_reserve_bytes')}
 if mode not in ('actual','format-actual'):budget.update(seconds=15,process_memory_bytes=512*1024**2,job_memory_bytes=1024**3,tree_bytes=16*1024**2,tree_entries=1024)
 granted=False
 def tick(job,pids):
  nonlocal granted
  if (stage/'hello.json').exists() and not granted:
   h=read(stage/'hello.json');assert h['pid'] in pids and h['mode']==mode;save(stage/'grant.pending.json',{'worker':process_identity(h['pid'],job)});os.replace(stage/'grant.pending.json',stage/'grant.json');granted=True
  if mode in ('actual','format-actual') and (stage/'phase.current.json').exists():
   p=read(stage/'phase.current.json');cap=spec['actual_budgets']['phase_seconds_caps'][p['phase']]
   if time.monotonic()-p['started_monotonic']>cap:raise RuntimeError('selected phase deadline '+p['phase'])
 result=run_bounded([str(ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'),'-I','-B','-P','-X','utf8',str(D/'solve_worker.py'),str(stage),mode],env,D,stage,budget,[D],on_tick=tick)
 after=pins();save(stage/'input-readback.json',{'unchanged':before==after,'before':before,'after':after});assert before==after and result['all_processes_terminated']
 if mode=='red':
  f=read(stage/'failure.json');assert result['exit_code']==1 and result['stop_reason'] is None and f['type']=='NotImplementedError' and f['message']=='new coupled solver integration not implemented';save(stage/'expected-red.json',{'expected_missing_solver':True,'original_exit_code':1,'old_tests_replayed':0})
 if mode=='format-red':
  f=read(stage/'failure.json');assert result['exit_code']==1 and result['stop_reason'] is None and f['type']=='NotImplementedError' and f['message']=='raw sparse loader not implemented';save(stage/'expected-red.json',{'expected_missing_raw_loader':True,'original_exit_code':1,'old_tests_replayed':0})
 print(dumps_report({k:result.get(k) for k in ('status','exit_code','seconds','stop_reason','peak_job_memory_bytes','all_processes_terminated','held_members')}),end='',flush=True)
 return 0 if mode in ('red','format-red') else result['exit_code'] if result['exit_code'] is not None else 125
if __name__=='__main__':raise SystemExit(main())
