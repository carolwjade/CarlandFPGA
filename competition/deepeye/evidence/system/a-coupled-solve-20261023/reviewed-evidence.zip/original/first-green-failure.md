The first new controls execution failed at the immutable literal returned-field expectation (`test_solver_controls.py:20`). The expected RED remains separate and unchanged. No retry or global stage was executed.

The held terminal records exit1, 0.875s, 95,473,664 bytes peak job memory, no resource stop and all three held processes terminated. Input/source readback is unchanged. Available manufactured raw arrays are returned_delta/info/alpha/e, new_r8/h and true_condensed_residual; callback journal is retained. Policy/output/receiver assertions after line20 were not reached and are not claimed passed.

The selected worker revision recorded actual matching before/after NumPy2.5.4/SciPy1.18.1 and both single-thread BLAS DLL pins while preserving the original AssertionError. No failed scientific imports were retried.

Static algebra points to a sign error inherited from the completed design: AII*delta+UI*alpha=-r8 and UI.T*delta+D*alpha=ell imply h=-r8-UI*solve_D(ell). The saved design and live core instead use plus. This is a proposed correction only; root selection is required before source change or another bounded control attempt. The independent reviewer and root were notified.

The actual stage remains unselected and blocked by failed controls. Prior assembly acceptance is distinct. Old info3 and old24 concentration failures remain unchanged. H01-H15 preserved; fullG03/R03/all29 not_run.
