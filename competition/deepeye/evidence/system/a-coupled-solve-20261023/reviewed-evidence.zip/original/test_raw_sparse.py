"""Only new raw-component archive loader controls; independent literal values."""
import hashlib,json
from pathlib import Path
import numpy as np
import raw_sparse
D=Path(__file__).resolve().parent
def run(stage):
 fixture=json.loads((D/'format-fixture.json').read_bytes());expected=np.asarray(fixture['expected_real'])+1j*np.asarray(fixture['expected_imag']);cases={};passes=[]
 def write(name,parts):
  p=stage/(name+'.npz')
  with p.open('xb') as f:np.savez(f,**parts)
  return p
 for kind in ('CSR','CSC'):
  row=fixture[kind];parts={'shape':np.asarray(row['shape'],dtype=np.int64),'data':np.asarray(row['data_real'])+1j*np.asarray(row['data_imag']),'indices':np.asarray(row['indices'],dtype=np.int32),'indptr':np.asarray(row['indptr'],dtype=np.int32)};cases[kind]=parts
  p=write(kind,parts);before=hashlib.sha256(p.read_bytes()).hexdigest();got=raw_sparse.load_raw(p,kind.lower(),(2,3))
  assert got.format==kind.lower() and got.shape==(2,3) and got.dtype==np.complex128 and np.array_equal(got.toarray(),expected)
  assert all(np.array_equal(getattr(got,n),parts[n]) for n in ('data','indices','indptr'))
  assert hashlib.sha256(p.read_bytes()).hexdigest()==before and got.has_sorted_indices and got.has_canonical_format
  # A closed file can be renamed and restored on Windows; raw archive survives unchanged.
  moved=p.with_suffix('.closed');p.rename(moved);moved.rename(p);passes.append(kind)
 bad=[('missing_indptr',{'indptr':None}),('shape_mismatch',{'shape':np.array([3,2])}),('pointer_length',{'indptr':np.array([0,1,2,4])}),('pointer_start',{'indptr':np.array([1,2,4])}),('pointer_end',{'indptr':np.array([0,2,3])}),('pointer_order',{'indptr':np.array([0,4,3])}),('negative_index',{'indices':np.array([0,2,-1,2])}),('out_of_range_index',{'indices':np.array([0,3,1,2])}),('noninteger_index',{'indices':np.array([0.,2.,1.,2.])}),('nonfinite_data',{'data':np.array([1+2j,complex(float('nan'),0),-2+.5j,4+0j])}),('unsorted',{'indices':np.array([2,0,1,2])}),('duplicate',{'indices':np.array([0,0,1,2])})]
 rejected=[]
 for name,changes in bad:
  parts={k:v.copy() for k,v in cases['CSR'].items()}
  for key,value in changes.items():
   if value is None:del parts[key]
   else:parts[key]=value
  p=write(name,parts);before=hashlib.sha256(p.read_bytes()).hexdigest()
  try:raw_sparse.load_raw(p,'csr',(2,3))
  except (ValueError,TypeError):rejected.append(name)
  else:raise AssertionError('malformed raw archive accepted: '+name)
  assert hashlib.sha256(p.read_bytes()).hexdigest()==before
  moved=p.with_suffix('.closed');p.rename(moved);moved.rename(p)
 assert passes==['CSR','CSC'] and len(rejected)==len(bad)
 return {'status':'new_raw_sparse_loader_controls_pass','literal_complex_nonsymmetric_rectangular_orientations':passes,'malformed_cases_rejected':rejected,'input_values_and_archive_bytes_unchanged':True,'archive_context_closed':True,'production_arrays_loaded':0,'LU_calls':0,'GMRES_calls':0,'old_control_groups_replayed':0}
