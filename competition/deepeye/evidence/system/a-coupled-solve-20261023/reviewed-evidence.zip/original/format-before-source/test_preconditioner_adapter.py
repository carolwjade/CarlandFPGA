"""Only new synthetic adapter behavior; no real LU/GMRES or old control calls."""
import numpy as np
from coupled_core import finite_preconditioner
class FakeLU:
 def __init__(self,out):self.out=out;self.calls=0;self.input=None
 @property
 def L(self):raise AssertionError('factor export L accessed')
 @property
 def U(self):raise AssertionError('factor export U accessed')
 def solve(self,value):self.calls+=1;self.input=value;return self.out
def run(stage):
 # Independent literal finite/nonfinite expected behavior, not a solver result.
 requested=np.array([1+2j,-3+.5j]);expected=np.array([7-.25j,0j]);finite=FakeLU(expected)
 got=finite_preconditioner(finite)(requested)
 assert got is expected and finite.calls==1 and finite.input is requested and np.array_equal(got,np.array([7-.25j,0j]))
 rejected=[]
 for name,value in [('nan',complex(float('nan'),0)),('infinity',complex(0,float('inf')))]:
  fake=FakeLU(np.array([value]));argument=np.array([2+1j])
  try:finite_preconditioner(fake)(argument)
  except ArithmeticError:rejected.append(name)
  else:raise AssertionError('nonfinite preconditioner output accepted')
  assert fake.calls==1 and fake.input is argument
 assert rejected==['nan','infinity']
 return {'status':'new_preconditioner_adapter_controls_pass','synthetic_only':True,'finite_return_identity_preserved':True,'one_solve_per_request':True,'factor_exports_accessed':0,'nonfinite_returns_rejected':rejected,'actual_factorizations':0,'actual_GMRES_calls':0,'old_control_groups_replayed':0}
