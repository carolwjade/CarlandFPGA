The archived completed design remains immutable. Its stated Schur RHS sign was wrong. Root selected this erratum in schur-rhs-correction-selection.json after the failed independent manufactured expectation and a distinct static review.

Starting from AII*delta+UI*alpha=-r8 and UI.T*delta+D*alpha=ell8, substitute alpha=solve_D(ell8-UI.T*delta). The condensed equation is (AII-UI*solve_D*UI.T)*delta=-r8-UI*solve_D(ell8). Thus the corrected implementation uses h=-r8-UI@solve_D(ell8). No load, boundary, fixture, threshold, transpose or D treatment changes.

The original RED, failed first GREEN and every failed-GREEN source byte are preserved. Only one newly selected corrected control group may run in corrected-controls-01; the exact actual gate can accept only that successful selected group. No global solve is selected.
