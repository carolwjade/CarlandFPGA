"""Static metadata freeze for the separately selected raw format correction."""
import ast,difflib,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
sys.path.insert(0,str(ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools'))
from evidence_json import write_new_report as save
from selection_gate import pin,read
def main():
 for p in D.glob('*.py'):ast.parse(p.read_text(encoding='utf8'),filename=str(p))
 if sys.argv[1]=='pre-red':
  selected=D.parent/'g03-coupled-solve-main-review-20261023/sparse-format-correction-selection.json'
  assert pin(selected)=={'bytes':1481,'sha256':'4578d2f347ee2f4c7c77a25db6054b048b7cd8c5498305247a853fa1cce01e6e'}
  old=read(D/'preconditioner-control-source-pins.json');snapshot={p.name:pin(p) for p in (D/'format-before-source').glob('*.py')};after={p.name:pin(p) for p in D.glob('*.py')}
  assert snapshot and all(v==old[(D/n).relative_to(ROOT).as_posix()] for n,v in snapshot.items())
  allowed={'actual_stage.py','solve_worker.py','run_solve.py','selection_gate.py','raw_sparse.py','test_raw_sparse.py','format_seal.py'}
  assert all(n in allowed or snapshot.get(n)==v for n,v in after.items())
  for n in ('fixture.json','test_solver_controls.py','input-pins.json','coupled_core.py','numerical_policy.py','raw_outputs.py','test_preconditioner_adapter.py'):
   assert pin(D/n)==old[(D/n).relative_to(ROOT).as_posix()]
  with (D/'format-red-loader.txt').open('xb') as f:f.write((D/'raw_sparse.py').read_bytes())
  save(D/'format-delta-record.json',{'root_selection':pin(selected),'snapshot':snapshot,'pre_RED_framework':after,'format_fixture':pin(D/'format-fixture.json'),'original_actual_terminal':pin(D/'actual-01/terminal.json'),'original_actual_manifest':pin(D/'actual-final-manifest.json'),'reused_integration_pins':pin(D/'corrected-control-source-pins.json'),'reused_preconditioner_pins':pin(D/'preconditioner-control-source-pins.json'),'new_RED':'format-red-01','new_GREEN':'format-controls-01','future_actual':'format-actual-01','frozen_scientific_core_policy_inputs_unchanged':True,'new_actual_selected':False})
 else:
  delta=''
  for p in D.glob('*.py'):
   old=D/'format-before-source'/p.name
   if not old.exists() or pin(p)!=pin(old):delta+=''.join(difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],p.read_text().splitlines(True),fromfile='format-before-source/'+p.name,tofile=p.name))
  with (D/'format-delta.diff').open('x',encoding='utf8',newline='') as f:f.write(delta)
if __name__=='__main__':main()
