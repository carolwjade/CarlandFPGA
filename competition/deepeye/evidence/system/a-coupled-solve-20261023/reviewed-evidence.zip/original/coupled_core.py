"""One fixed coupled Schur correction; no reference or receiver access."""
import gc,math,warnings
import numpy as np
from scipy.sparse.linalg import LinearOperator,gmres,splu
import raw_outputs as raw
def norm2(x):return math.sqrt(math.fsum(float(abs(v))**2 for v in x))
def finite_preconditioner(lu):
 def solve(v):
  out=lu.solve(v);raw.require_finite(out);return out
 return solve
def run_condensed(A,U,D,I,Eh,r4,db,ell,A0,stage,phase):
 raw.require_finite(A.data,U.data,D.data,Eh,r4,db,ell,A0.data)
 assert A.shape==(len(Eh),len(Eh)) and U.shape==(len(Eh),D.shape[0]) and D.shape[0]==D.shape[1] and 0<D.shape[0]<=804
 assert r4.shape==(len(I),) and ell.shape==(D.shape[0],) and db.shape==Eh.shape and A0.shape==(len(I),len(I))
 AII=A[I,:][:,I].tocsr();UI=U[I,:].tocsr();UT=UI.T.tocsr()
 phase('D_factor')
 with warnings.catch_warnings():
  warnings.simplefilter('error');luD=splu(D.tocsc(),permc_spec='COLAMD')
 raw.require_finite(luD.L.data,luD.U.data)
 factor_bytes=sum(a.nbytes for q in (luD.L,luD.U) for a in (q.data,q.indices,q.indptr))+luD.perm_r.nbytes+luD.perm_c.nbytes
 if factor_bytes>64*1024**2:raise MemoryError('D exported factor cap')
 r8=r4-db[I];h=-r8-UI@luD.solve(ell);raw.require_finite(r8,h)
 phase('fresh_A0_factor')
 with warnings.catch_warnings():
  warnings.simplefilter('error');lu0=splu(A0.tocsc(),permc_spec='COLAMD')
 def action(v):return AII@v-UI@luD.solve(UT@v)
 S=LinearOperator(AII.shape,matvec=action,dtype=np.complex128);M=LinearOperator(AII.shape,matvec=finite_preconditioner(lu0),dtype=np.complex128)
 phase('one_GMRES');count=0
 with (stage/'callbacks.txt').open('x',encoding='ascii') as log:
  def callback(value):
   nonlocal count
   count+=1;log.write(str(count)+' '+repr(float(value))+'\n');log.flush()
   if count>120 or not math.isfinite(float(value)):raise ArithmeticError('invalid callback')
  delta,info=gmres(S,h,x0=np.zeros(len(I),dtype=complex),M=M,restart=40,maxiter=3,rtol=1e-12,atol=0.,callback=callback,callback_type='pr_norm')
 raw.persist_return(stage,delta,info)
 phase('save_verify_receivers');del M,lu0;gc.collect();raw.require_finite(delta)
 alpha=luD.solve(ell-UT@delta);e=Eh.copy();e[I]+=delta
 raw.arrays(stage,{'returned_alpha':alpha,'returned_e':e,'new_r8':r8,'new_h':h});raw.require_finite(alpha,e)
 residual=action(delta)-h;raw.arrays(stage,{'true_condensed_residual':residual});raw.require_finite(residual)
 rn=norm2(residual);hn=norm2(h);threshold=1e-12*hn
 del S,luD;gc.collect()
 return {'e':e,'alpha':alpha,'delta':delta,'info':int(info),'callbacks':count,'true_condensed_norm':rn,'condensed_rhs_norm':hn,'strict_threshold':threshold,'strict_pass':bool(rn<=threshold),'D_exported_factor_bytes':factor_bytes,'GMRES_calls':1,'fresh_A0_factor_calls':1,'D_factor_calls':1}
