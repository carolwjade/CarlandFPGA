"""Exact-pin dependency gate, called by controller and worker before arrays."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def require_selection():
 spec=read(D/'input-pins.json');selection=read(ROOT/spec['root_actual_selection_path'])
 assert selection['actual_solve_selected'] is True and selection['assembly_accepted'] is True
 assert selection['control_stage']=='corrected-controls-01' and selection['integration_source_pins_sha256']==pin(D/'corrected-control-source-pins.json')['sha256']
 assert selection['target_control_stage']=='preconditioner-controls-01' and selection['source_pins_sha256']==pin(D/'preconditioner-control-source-pins.json')['sha256']
 assert selection['preconditioner_delta_record']==pin(D/'preconditioner-delta-record.json')
 assert read(D/'corrected-controls-01/terminal.json')['status']=='success' and read(D/'corrected-controls-01/result.json')['status']=='new_solver_policy_output_controls_pass'
 assert read(D/'preconditioner-controls-01/terminal.json')['status']=='success' and read(D/'preconditioner-controls-01/result.json')['status']=='new_preconditioner_adapter_controls_pass'
 assert selection['actual_budgets']==spec['actual_budgets']
 assembly=D.parent/'g03-coupled-face-closure-20261023';manifest=read(assembly/'manifest.json')
 assert selection['accepted_assembly_manifest']==pin(assembly/'manifest.json')
 decision=D.parent/'g03-coupled-face-main-review-20261023/decision.json'
 assert selection['assembly_acceptance_decision']==pin(decision)
 for name,path in spec['aliases'].items():
  if name.startswith('coupled_'):
   p=ROOT/path;relative=p.relative_to(assembly).as_posix()
   assert manifest['files'][relative]==spec['files'][path]==pin(p)
 return spec,selection
def require_format_selection():
 spec=read(D/'input-pins.json');selection=read(D.parent/'g03-coupled-face-main-review-20261023/coupled-solve-format-actual-selection.json')
 assert selection['actual_solve_selected'] is True and selection['assembly_accepted'] is True and selection['actual_stage']=='format-actual-01'
 assert selection['control_stage']=='corrected-controls-01' and selection['integration_source_pins_sha256']==pin(D/'corrected-control-source-pins.json')['sha256']
 assert selection['target_control_stage']=='preconditioner-controls-01' and selection['preconditioner_source_pins_sha256']==pin(D/'preconditioner-control-source-pins.json')['sha256']
 assert selection['preconditioner_delta_record']==pin(D/'preconditioner-delta-record.json')
 assert selection['format_control_stage']=='format-controls-01' and selection['source_pins_sha256']==pin(D/'format-source-pins.json')['sha256']
 assert selection['format_delta_record']==pin(D/'format-delta-record.json') and selection['original_failed_actual_terminal']==pin(D/'actual-01/terminal.json')
 for name,status in [('corrected-controls-01','new_solver_policy_output_controls_pass'),('preconditioner-controls-01','new_preconditioner_adapter_controls_pass'),('format-controls-01','new_raw_sparse_loader_controls_pass')]:
  assert read(D/name/'terminal.json')['status']=='success' and read(D/name/'result.json')['status']==status
 assert selection['actual_budgets']==spec['actual_budgets']
 assembly=D.parent/'g03-coupled-face-closure-20261023';manifest=read(assembly/'manifest.json')
 assert selection['accepted_assembly_manifest']==pin(assembly/'manifest.json')
 assert selection['assembly_acceptance_decision']==pin(D.parent/'g03-coupled-face-main-review-20261023/decision.json')
 for name,path in spec['aliases'].items():
  if name.startswith('coupled_'):
   p=ROOT/path;assert manifest['files'][p.relative_to(assembly).as_posix()]==spec['files'][path]==pin(p)
 return spec,selection
