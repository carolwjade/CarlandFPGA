"""Raw numerical evidence precedes rejection; JSON is metadata only."""
import os
import numpy as np
from evidence_json import write_new_report
def arrays(stage,values):
 for name,value in values.items():
  a=np.asarray(value)
  if a.dtype.kind not in 'biufc':raise TypeError('numeric raw arrays only')
  with (stage/(name+'.npy')).open('xb') as f:
   np.save(f,a,allow_pickle=False);f.flush();os.fsync(f.fileno())
def persist_return(stage,delta,info):arrays(stage,{'returned_delta':delta,'returned_info':np.asarray(info,dtype=np.int64)})
def require_finite(*values):
 if any(not bool(np.all(np.isfinite(v))) for v in values):raise ArithmeticError('nonfinite raw candidate/input; available raw outputs retained')
def publish(stage,metadata):
 assert (stage/'returned_delta.npy').is_file() and (stage/'returned_info.npy').is_file()
 write_new_report(stage/'result.json',metadata)
