"""Metadata only: source handoff and final evidence manifest, no science imports."""
import ast,difflib,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
sys.path.insert(0,str(ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools'))
from evidence_json import write_new_report as save
from selection_gate import pin,read
def main():
 for p in D.glob('*.py'):ast.parse(p.read_text(encoding='utf8'),filename=str(p))
 if sys.argv[1]=='pre-green':
  old=read(D/'red-source-pins.json');names=('solve_worker.py','run_solve.py')
  root_selection=D.parent/'g03-coupled-solve-main-review-20261023/pre-green-worker-revision-selection.json'
  record={'root_selection':pin(root_selection),'before':{n:old[(D/n).relative_to(ROOT).as_posix()] for n in names},'after':{n:pin(D/n) for n in names},'fixture_unchanged':pin(D/'fixture.json')==old[(D/'fixture.json').relative_to(ROOT).as_posix()],'reason':'selected exception-path runtime_after evidence and corresponding source-freeze assertion only','RED_replayed':False,'threshold_changes':False}
  assert record['fixture_unchanged']
  save(D/'pre-green-revision.json',record)
  delta=''
  for name,backup in [('solve_worker.py','red-worker-source.txt'),('run_solve.py','red-runner-source.txt')]:
   assert pin(D/backup)==record['before'][name]
   delta+=''.join(difflib.unified_diff((D/backup).read_text().splitlines(True),(D/name).read_text().splitlines(True),fromfile=backup,tofile=name))
  with (D/'pre-green-revision.diff').open('x',encoding='utf8',newline='') as f:f.write(delta)
  save(D/'pre-green-handoff.json',{'sources':{p.name:pin(p) for p in D.glob('*.py')},'fixture':pin(D/'fixture.json'),'input_pins':pin(D/'input-pins.json'),'RED_terminal':pin(D/'red-01/terminal.json'),'revision':pin(D/'pre-green-revision.json'),'global_solve_selected':False,'assembly_snapshot':'prior provisional numerical pins unchanged; acceptance supplied only by future exact-pin root selection','old_tests_replayed':0})
 else:
  files={p.relative_to(D).as_posix():pin(p) for p in D.rglob('*') if p.is_file() and p.name not in ('lease.private.json','manifest.json','native-completion-receipt.json') and '__pycache__' not in p.parts}
  save(D/'manifest.json',{'work_id':'A-G03-COUPLED-SOLVE-20261023-v1','files':files,'file_count':len(files),'actual_global_solve':'not_run','old_tests_replayed':0,'acceptance_owner':'root','excluded':['private lease','manifest self','subsequent completion receipt']})
if __name__=='__main__':main()
