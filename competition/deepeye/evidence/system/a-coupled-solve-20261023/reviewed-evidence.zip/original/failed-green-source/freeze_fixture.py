"""Independent exact rational manufactured block; no implementation imports."""
from fractions import Fraction as F
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
def z(r=0,i=0):return F(r),F(i)
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[0],-a[1]
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def dot(a,b):
 out=z()
 for x,y in zip(a,b):out=add(out,mul(x,y))
 return out
def mv(a,x):return [dot(row,x) for row in a]
def transpose(a):return [list(x) for x in zip(*a)]
A=[[z(10,1),z(1,F(1,2)),z(F(1,2)),z(1)], [z(1,F(1,2)),z(12,2),z(1),z(F(1,2),F(1,4))], [z(F(1,2)),z(1),z(14,3),z(F(1,3))], [z(1),z(F(1,2),F(1,4)),z(F(1,3)),z(9,1)]]
U=[[z(1,F(1,2)),z(F(1,2)),z()], [z(),z(1,F(-1,2)),z(F(1,3))], [z(F(1,4)),z(),z(1,F(1,4))], [z(F(1,2),F(1,4)),z(F(1,3),F(-1,5)),z(F(1,7))]]
Q=[[z(6,1),z(1,F(1,4)),z(0,F(1,2))], [z(1,F(1,4)),z(7,2),z(1,F(-1,4))], [z(0,F(1,2)),z(1,F(-1,4)),z(8,3)]]
want=[z(1,2),z(-2,1),z(F(1,2),F(-1,2)),z(F(3,4),F(1,3))]
alpha=[z(F(-1,2),F(1,4)),z(F(2,3),F(-1,3)),z(F(1,5),F(2,5))]
Eh=[z(F(1,4)),z(F(-1,3),F(1,4)),z(F(1,2),F(1,5)),want[-1]]
db=[z(F(1,8),F(-1,7)),z(F(-1,9),F(1,6)),z(F(1,10),F(1,11)),z()]
b8=[add(a,b) for a,b in zip(mv(A,want),mv(U,alpha))];b8[-1]=z()
b4=[add(a,neg(b)) for a,b in zip(b8,db)]
fq=[add(a,b) for a,b in zip(mv(transpose(U),want),mv(Q,alpha))]
ell=[add(a,neg(b)) for a,b in zip(fq,mv(transpose(U),Eh))]
r4=[add(a,neg(b)) for a,b in zip(mv(A,Eh),b4)][:3]
beff4=[add(b4[j],neg(mul(A[j][-1],want[-1]))) for j in range(3)]
trace=[[z(F(1,2)),z(F(1,4)),z(F(-1,10)),z(F(1,3))],[z(F(1,5)),z(F(-2,5)),z(F(3,5)),z(F(-1,5))]]
tQ=[[z(F(1,10)),z(F(1,5)),z()],[z(),z(F(-1,10)),z(F(3,10))]]
H=[add(a,b) for a,b in zip(mv(trace,want),mv(tQ,alpha))]
def encoded(v):
 if isinstance(v,tuple):return [str(v[0]),str(v[1])]
 return [encoded(x) for x in v]
record={k:encoded(v) for k,v in {'A':A,'U':U,'D':Q,'want_e':want,'want_alpha':alpha,'Eh':Eh,'db':db,'b8':b8,'b4':b4,'F8':fq,'ell8':ell,'r4':r4,'beff4':beff4,'trace':trace,'tQ':tQ,'H':H,'oldV':mv(trace,Eh)}.items()}
record.update({'expectation_method':'independent Fraction complex polynomial arithmetic; literal exact solution, not a production solve','I':[0,1,2],'B':[3],'policy_cases':[{'info':0,'strict':True,'aug':True,'want':'strict_converged_candidate'},{'info':3,'strict':False,'aug':True,'want':'roundoff_limited_candidate'},{'info':3,'strict':False,'aug':False,'want':'numerical_gate_failed'},{'info':-1,'strict':False,'aug':True,'want':'solver_breakdown'},{'info':0,'strict':False,'aug':True,'want':'strict_residual_revalidation_failed'}],'mutations_caught':['wrong Schur sign','conjugate physical transpose','diagonal D','omitted U boundary','wrong b8 delta sign','raw loss before nonfinite/info stop','tiny eta accepted despite failed row','nonfinite JSON silently written'],'old_controls_repeated':False})
with (D/'fixture.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2,allow_nan=False)
print(json.dumps({'fixture_frozen':True,'sha256':hashlib.sha256((D/'fixture.json').read_bytes()).hexdigest()}))
