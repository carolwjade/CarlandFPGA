"""Prospective coupled equations and unchanged receiver screens."""
import math
import numpy as np
from scipy import sparse
EPS=np.finfo(float).eps;C=128*EPS
def apply(matrix,x):
 a=sparse.csr_matrix(matrix);out=np.empty(a.shape[0],complex);scale=np.empty(a.shape[0],float)
 for i in range(a.shape[0]):
  lo,hi=a.indptr[i:i+2];products=a.data[lo:hi]*x[a.indices[lo:hi]]
  out[i]=complex(math.fsum(float(v.real) for v in products),math.fsum(float(v.imag) for v in products))
  scale[i]=math.fsum(float(abs(v))*float(abs(w)) for v,w in zip(a.data[lo:hi],x[a.indices[lo:hi]]))
 return out,scale
def rownorm(a):return np.asarray(abs(a).sum(axis=1)).ravel()
def maximum(a):return float(np.max(abs(a),initial=0.))
def floor_gate(r,scale,eta):
 return bool(r.shape==scale.shape and np.all(np.isfinite(r)) and np.all(np.isfinite(scale)) and np.all(scale>=0) and math.isfinite(eta) and eta<=C and np.all(abs(r)<=C*scale))
def status(info,strict,aug):
 if info<0:return 'solver_breakdown'
 if not aug['passed']:return 'numerical_gate_failed'
 if info==0:return 'strict_converged_candidate' if strict else 'strict_residual_revalidation_failed'
 return 'roundoff_limited_candidate'
def augmented(A,U,D,I,B,e,alpha,b8,F8,beff8,gB):
 A=sparse.csr_matrix(A);U=sparse.csr_matrix(U);D=sparse.csr_matrix(D)
 AII=A[I,:][:,I];UI=U[I,:];UT=UI.T.tocsr()
 ae,sae=apply(A,e);ua,sua=apply(UI,alpha);ute,sute=apply(U.T,e);da,sda=apply(D,alpha)
 ag,sag=apply(A[I,:][:,B],gB);ug,sug=apply(U[B,:].T,gB)
 aii,saii=apply(AII,e[I]);uti,suti=apply(UT,e[I]);fbar=F8-ug;beffdirect=b8[I]-ag
 rI=ae[I]-b8[I]+ua;rQ=ute+da-F8;ri=aii+ua-beff8;rq=uti+da-fbar
 pI=saii+sua+abs(beff8);pQ=suti+sda+abs(fbar);r=np.concatenate((rI,rQ));p=np.concatenate((pI,pQ))
 normB=maximum(np.concatenate((rownorm(AII)+rownorm(UI),rownorm(UT)+rownorm(D))))
 xinf=max(maximum(e[I]),maximum(alpha));rhsinf=max(maximum(beff8),maximum(fbar));denom=normB*xinf+rhsinf
 eta=maximum(r)/denom if denom>0 else (0. if maximum(r)==0 and xinf==0 and rhsinf==0 else float('inf'))
 directpass=bool(np.all(np.isfinite(r)) and np.all(abs(rI-ri)<=C*(sae[I]+abs(b8[I])+sua+pI)) and np.all(abs(rQ-rq)<=C*(sute+sda+abs(F8)+pQ)) and np.all(abs(beff8-beffdirect)<=C*(abs(b8[I])+sag+abs(beff8))))
 boundary=bool(np.array_equal(e[B],gB));passed=bool(boundary and directpass and floor_gate(r,p,eta) and math.isfinite(normB) and math.isfinite(denom))
 return {'passed':passed,'boundary_exact':boundary,'direct_reduced_pass':directpass,'eta':eta,'augmented_norm_inf':normB,'normwise_denominator':denom,'arrays':{'augmented_residual':r,'augmented_absolute_product_scale':p,'augmented_floor':C*p,'direct_rI':rI,'direct_rQ':rQ,'reduced_rI':ri,'reduced_rQ':rq,'beff8_direct':beffdirect,'fbarQ':fbar,'new_boundary_action':ag,'new_boundary_action_scale':sag,'bubble_boundary_action':ug,'bubble_boundary_action_scale':sug}}
def receiver(trace,tQ,e,alpha,H,oldV,I,delta):
 t=sparse.csr_matrix(trace);q=sparse.csr_matrix(tQ);coarse,sc=apply(t,e);bubble,sb=apply(q,alpha);dv,sd=apply(t[:,I],delta)
 V=coarse+bubble;update=oldV+dv+bubble;scale=sc+sb;bound=C*scale;identityscale=sc+sb+abs(oldV)+sd+sb
 identity=bool(np.all(abs(V-update)<=C*identityscale));stable=(abs(H)>bound)&(abs(V)>bound)
 relative=np.full(H.shape,float('inf'));np.divide(abs(V-H),abs(H),out=relative,where=stable)
 passed=bool(identity and np.all(np.isfinite(V)) and np.all(np.isfinite(H)) and np.all(np.isfinite(scale)) and np.all(stable) and np.all(relative<=.01))
 return {'passed':passed,'identity_pass':identity,'arrays':{'receiver_V':V,'receiver_update_V':update,'receiver_error_abs':abs(V-H),'receiver_error_relative':relative,'receiver_stable':stable,'receiver_stability_floor':bound,'receiver_absolute_product_scale':scale,'receiver_identity_error':V-update,'receiver_identity_bound':C*identityscale}}
