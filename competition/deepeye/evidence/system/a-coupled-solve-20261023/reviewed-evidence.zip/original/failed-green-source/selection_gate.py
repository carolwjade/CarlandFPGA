"""Exact-pin dependency gate, called by controller and worker before arrays."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def require_selection():
 spec=read(D/'input-pins.json');selection=read(ROOT/spec['root_actual_selection_path'])
 assert selection['actual_solve_selected'] is True and selection['assembly_accepted'] is True
 assert selection['source_pins_sha256']==pin(D/'control-source-pins.json')['sha256']
 assert selection['actual_budgets']==spec['actual_budgets']
 assembly=D.parent/'g03-coupled-face-closure-20261023';manifest=read(assembly/'manifest.json')
 assert selection['accepted_assembly_manifest']==pin(assembly/'manifest.json')
 decision=D.parent/'g03-coupled-face-main-review-20261023/decision.json'
 assert selection['assembly_acceptance_decision']==pin(decision)
 for name,path in spec['aliases'].items():
  if name.startswith('coupled_'):
   p=ROOT/path;relative=p.relative_to(assembly).as_posix()
   assert manifest['files'][relative]==spec['files'][path]==pin(p)
 return spec,selection
