"""Pin bytes and source chain; never decode numerical payloads."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];P=D.parent
def read(p):return json.loads(p.read_bytes())
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
prior=read(P/'g03-coupled-solve-design-20261023/source-manifest.json');aliases=dict(prior['aliases'])
assembly=P/'g03-coupled-face-closure-20261023/assembly-01'
for n in ('closure_indices','Q_rows','Q_cols','MQ','KQ','D','D_absolute_scale','U_rows','U_cols','U','U_absolute_scale','F8_Q','ell8_Q','tQ','tQ_absolute_scale'):
 aliases['coupled_'+n]=(assembly/(n+'.npy')).relative_to(ROOT).as_posix()
files={n:pin(ROOT/n) for n in aliases.values() if (ROOT/n).exists()}
for n,v in files.items():
 if n in prior['files']:assert v==prior['files'][n]
extra=[P/'g03-source8-main-review-20261023/decision.json',P/'g03-face-enrichment-20261023/prepare.py',P/'g03-face-enrichment-20261023/input-pins.json',P/'g03-face-enrichment-20261023/probe_stage.py',P/'g03-source8-enrichment-20261023/source8_stage.py',P/'g03-source8-enrichment-20261023/source-pins.json',P/'g03-coupled-solve-design-20261023/manifest.json',P/'g03-coupled-face-main-review-20261023/solve-implementation-selection.json',P/'g03-coupled-face-main-review-20261023/next-solve-design-review.json',ROOT/'docs/competition/deepeye-2026/immutable_scope.md',ROOT/'docs/competition/deepeye-2026/immutable_scope.json',ROOT/'.agents/skills/fpga-multi-node/SKILL.md',ROOT/'.agents/skills/fpga-multi-node/skill-role.json',ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json',ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py',P/'r02-amd-wheel-acquisition-20261021/win_job.py',P/'r02-amd-wheel-acquisition-20261021/boundary.py',ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe']
runtime=read(P/'g03-source8-enrichment-20261023/source-01/worker-evidence.json')['runtime_before']
for record in runtime['BLAS']:
 p=Path(record['path']);assert pin(p)['sha256']==record['sha256'];extra.append(p)
for p in extra:files[p.relative_to(ROOT).as_posix()]=pin(p)
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
h=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
record={'aliases':aliases,'files':files,'assembly_acceptance':'pending; these numerical output hashes are provisional identities only','root_actual_selection_path':'.planning/deepeye-resume-20261018/g03-coupled-face-main-review-20261023/coupled-solve-actual-selection.json','requirements_sha256':h,'runtime':runtime,'actual_budgets':read(P/'g03-coupled-solve-design-20261023/design.json')['proposed_guard'],'payloads_decoded':0,'controls_may_read_production_arrays':False}
with (D/'input-pins.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2,allow_nan=False)
print(json.dumps({'input_files':len(files),'assembly_accepted':False,'global_solve_selected':False,'array_decodes':0}))
