"""Only new tiny solver integration and policy/raw-output behavior."""
from fractions import Fraction
import json
from pathlib import Path
import numpy as np
from scipy import sparse
from evidence_json import write_new_report as save
D=Path(__file__).resolve().parent
def decode(value):
 if len(value)==2 and all(isinstance(x,str) for x in value):return complex(float(Fraction(value[0])),float(Fraction(value[1])))
 return [decode(x) for x in value]
def run(stage):
 f=json.loads((D/'fixture.json').read_bytes());a={k:np.asarray(decode(f[k]),dtype=complex) for k in ('A','U','D','want_e','want_alpha','Eh','db','b8','b4','F8','ell8','r4','beff4','trace','tQ','H','oldV')}
 I=np.array(f['I']);B=np.array(f['B']);A=sparse.csr_matrix(a['A']);U=sparse.csr_matrix(a['U']);Q=sparse.csr_matrix(a['D']);A0=A[I,:][:,I].tocsc()
 import coupled_core as core
 case=stage/'manufactured';case.mkdir()
 got=core.run_condensed(A,U,Q,I,a['Eh'],a['r4'],a['db'],a['ell8'],A0,case,lambda name:None)
 # These literal exact solutions catch sign, transpose, D-diagonal and boundary errors.
 eps=np.finfo(float).eps
 assert np.max(abs(got['e']-a['want_e']))<=512*eps*max(1,float(np.max(abs(a['want_e']))))
 assert np.max(abs(got['alpha']-a['want_alpha']))<=512*eps*max(1,float(np.max(abs(a['want_alpha']))))
 assert np.array_equal(got['e'][B],a['want_e'][B]) and got['info']==0 and got['GMRES_calls']==1
 assert np.max(abs(a['U'].T@a['want_e']-a['U'].conj().T@a['want_e']))>1e-3
 assert np.max(abs((a['D']-np.diag(np.diag(a['D'])))@a['want_alpha']))>1e-3
 import numerical_policy as policy
 beff8=a['beff4']+a['db'][I]
 checked=policy.augmented(A,U,Q,I,B,got['e'],got['alpha'],a['b8'],a['F8'],beff8,a['want_e'][B])
 assert checked['passed'] and checked['boundary_exact'] and checked['direct_reduced_pass']
 statuses=[]
 for row in f['policy_cases']:
  verdict=policy.status(row['info'],row['strict'],{'passed':row['aug']})
  assert verdict==row['want'];statuses.append({'synthetic_info':row['info'],'status':verdict})
 # Tiny eta must not bypass a failing componentwise row; literal synthetic policy input.
 assert policy.floor_gate(np.array([1e-12]),np.array([1.]),1e-30) is False
 assert policy.floor_gate(np.array([0j]),np.array([0.]),0.) is True
 physical=policy.receiver(a['trace'].real,a['tQ'].real,got['e'],got['alpha'],a['H'],a['oldV'],I,got['delta'])
 assert physical['passed'] and physical['identity_pass']
 failed=policy.receiver(a['trace'].real,a['tQ'].real,got['e'],got['alpha'],a['H']*1.25,a['oldV'],I,got['delta'])
 assert not failed['passed']
 import raw_outputs as raw
 nonfinite=stage/'nonfinite';nonfinite.mkdir();raw.persist_return(nonfinite,np.array([complex(float('nan'),0)]),3)
 try:raw.require_finite(np.load(nonfinite/'returned_delta.npy',allow_pickle=False))
 except ArithmeticError:pass
 else:raise AssertionError('nonfinite candidate not rejected')
 assert (nonfinite/'returned_delta.npy').is_file() and int(np.load(nonfinite/'returned_info.npy',allow_pickle=False))==3
 try:raw.publish(nonfinite,{'bad_array':np.array([1.])})
 except TypeError:pass
 else:raise AssertionError('unsupported report value accepted')
 assert not (nonfinite/'result.json').exists() and (nonfinite/'returned_delta.npy').is_file()
 raw.publish(nonfinite,{'candidate_saved_before_rejection':np.bool_(True),'synthetic_info':np.int64(3)})
 assert json.loads((nonfinite/'result.json').read_bytes())['candidate_saved_before_rejection'] is True
 return {'status':'new_solver_policy_output_controls_pass','actual_small_GMRES_calls':1,'global_GMRES_calls':0,'actual_small_info':int(got['info']),'synthetic_status_cases':statuses,'synthetic_positive_info_is_not_actual_convergence':True,'full_D_ordinary_transpose_nonzero_boundary_solution_verified':True,'raw_nonfinite_preserved_before_rejection':True,'strict_metadata_failure_preserved_raw':True,'physical_pass_and_fail_checked':True,'old_tests_replayed':0}
