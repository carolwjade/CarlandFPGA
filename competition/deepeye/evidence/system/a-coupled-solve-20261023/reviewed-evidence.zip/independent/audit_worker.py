"""Held, one-shot stdlib audit worker; no scientific runtime imports."""
import json,os,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];stage=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools'))
from evidence_json import write_new_report as save,dumps_report
save(stage/'hello.json',{'pid':os.getpid(),'mode':'saved_audit','science_imports':False})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
 if time.monotonic()>deadline:raise RuntimeError('held grant missing')
 time.sleep(.01)
assert json.loads((stage/'grant.json').read_bytes())['worker']['pid']==os.getpid()
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system'):raise PermissionError('no external operation')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).resolve();mode=args[1];flags=args[2]
  writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if writing and not p.is_relative_to(stage):raise PermissionError('stage writes only')
sys.addaudithook(audit);sys.path.insert(0,str(D));began=time.monotonic()
try:
 import saved_audit
 config=json.loads((D/'audit-inputs.json').read_bytes());result=saved_audit.run(config)
 assert not any(x in sys.modules for x in ('numpy','scipy','simpeg'))
 save(stage/'result.json',result);save(stage/'worker-evidence.json',{'stdlib_only':True,'science_imports':False,'elapsed_seconds':time.monotonic()-began})
 print(dumps_report(result),end='',flush=True)
except BaseException as exc:
 save(stage/'failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),'elapsed_seconds':time.monotonic()-began});raise
