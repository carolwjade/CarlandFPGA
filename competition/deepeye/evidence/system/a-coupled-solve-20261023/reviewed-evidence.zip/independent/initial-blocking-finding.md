Blocking finding before any global solve: the selected design and first implemented Schur right-hand side have the wrong sign on the bubble residual term.

For the full correction equations,

```
AII delta + UI alpha = -r8
UI.T delta + D alpha = ell8
alpha = D^-1 (ell8 - UI.T delta)
```

substitution gives

```
(AII - UI D^-1 UI.T) delta = -r8 - UI D^-1 ell8.
```

The first implementation instead used `h=-r8+UI@luD.solve(ell)`. The archived design contains the same incorrect plus sign. Ordinary transpose and the definition ell8=F8-U.T Eh do not change this derivation. The missing minus sign changes the equations; a receiver or backward-error screen cannot repair it.

The first new control attempt stopped at the frozen exact returned-field assertion in test_solver_controls.py:20. Its terminal reports exit 1, 0.875 seconds, 95,473,664 bytes peak job memory, and all three held processes terminated. Its failure record retains equal runtime_before/runtime_after with BLAS1. Raw returned correction, field, alpha, residual and callback files remain in the author's controls-01/manufactured directory. This review did not decode or reduce those numerical arrays and did not run any control or solver.

The independent literal Fraction fixture is unchanged and is the correct reference. The required repair is the single RHS sign, not weaker tolerances or changed expected fields. Root subsequently explicitly selected one bounded correction/control group in schur-rhs-correction-selection.json. Original controls-01, original source snapshots and archived design must remain immutable; the design receives a separate erratum. Actual global execution remains unselected and must require the separately successful corrected control stage and final source pins.

The root-authorized worker exception-evidence revision was also inspected. It captures the original exception before an optional single runtime-after readback, skips runtime retry when the initial runtime failed, records diagnostic errors without replacing the original exception, and preserves the original RED worker. The observed failed control now has the requested after-runtime evidence. No numerical policy or threshold changed in that worker revision.
