"""Seal existing review evidence only; no numerical work."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def save(p,x):
 with p.open('x',encoding='utf8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
frozen=read(D/'audit-source-pins.json');inputs=read(D/'audit-inputs.json')['files'];rb=read(D/'saved-audit-01/readback.json')
assert rb['source_unchanged'] and rb['inputs_unchanged'] and all(pin(ROOT/n)==v for n,v in frozen.items()) and all(pin(ROOT/n)==v for n,v in inputs.items())
t=read(D/'saved-audit-01/terminal.json');r=read(D/'saved-audit-01/result.json');assert t['exit_code']==0 and t['all_processes_terminated'] and t['active_processes_final']==0 and r['status']=='saved_output_audit_conforms'
save(D/'final-handoff.json',{'work_id':'A-G03-COUPLED-SOLVE-REVIEW-20261023-v1','status':'independent_static_and_selected_saved_output_review_complete','audit_source_pins':pin(D/'audit-source-pins.json'),'audit_terminal':pin(D/'saved-audit-01/terminal.json'),'audit_result':pin(D/'saved-audit-01/result.json'),'audit_readback':pin(D/'saved-audit-01/readback.json'),'final_review':pin(D/'final-review.md'),'actual_author_manifest':read(D/'audit-inputs.json')['actual_final_manifest'],'audit_seconds':t['seconds'],'audit_peak_job_memory_bytes':t['peak_job_memory_bytes'],'all_three_held_terminated':True,'numerical_candidate_status':r['solver_status'],'physical_screens_pass':False,'receiver_relative_errors':[v['relative_error'] for v in r['receiver_checks']],'reviewer_solver_factorization_old_test_replays':0,'limitations':r['limitations'],'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','H01_H15_preserved':True,'G03':'not_run','R03':'not_run','all29':'not_run','acceptance_owner':'root','native_completion':'awaiting_root_readback'})
excluded={'lease.private.json','manifest.json','native-completion-receipt.json'};files={}
secret=read(D/'lease.private.json')['lease_token'].encode()
for p in D.rglob('*'):
 if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts:
  assert secret not in p.read_bytes();files[p.relative_to(D).as_posix()]=pin(p)
save(D/'manifest.json',{'work_id':'A-G03-COUPLED-SOLVE-REVIEW-20261023-v1','file_count':len(files),'total_bytes':sum(v['bytes'] for v in files.values()),'files':files,'excluded':sorted(excluded),'scope':'independent static review and one selected stdlib saved-output audit; physical screens failed; no acceptance'})
assert all(pin(D/n)==v for n,v in files.items())
print(json.dumps({'manifest':pin(D/'manifest.json'),'file_count':len(files),'total_bytes':sum(v['bytes'] for v in files.values()),'handoff':pin(D/'final-handoff.json'),'audit_result':pin(D/'saved-audit-01/result.json'),'audit_terminal':pin(D/'saved-audit-01/terminal.json')}))
