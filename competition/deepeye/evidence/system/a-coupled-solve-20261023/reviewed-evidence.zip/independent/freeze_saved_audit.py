"""Prepare immutable audit inputs/code pins with hashes and headers only."""
import ast,hashlib,json,struct
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];A=D.parent/'g03-coupled-solve-20261023'
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def save(p,x):
 with p.open('x',encoding='utf8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
manifest=A/'format-actual-final-manifest.json';assert pin(manifest)['sha256']=='9ae051d0a1b020e1d5166660c2b57f025f99f656fa28e6567e9b19359629c011'
files=read(A/'format-source-pins.json')
for n,v in read(manifest)['files'].items():files[(A/n).relative_to(ROOT).as_posix()]=v
files[manifest.relative_to(ROOT).as_posix()]=pin(manifest)
assert all(pin(ROOT/n)==v for n,v in files.items())
headers={}
for p in (A/'format-actual-01').glob('*.npy'):
 with p.open('rb') as f:
  assert f.read(6)==b'\x93NUMPY';version=tuple(f.read(2));assert version==(1,0);n=struct.unpack('<H',f.read(2))[0];headers[p.name]=ast.literal_eval(f.read(n).decode('latin1'))
budget={'seconds':30,'process_memory_bytes':512*1024**2,'job_memory_bytes':1024**3,'active_processes':3,'stdout_bytes':128*1024,'stderr_bytes':128*1024,'tree_bytes':64*1024**2,'tree_entries':2048,'free_reserve_bytes':512*1024**2}
save(D/'audit-inputs.json',{'root':str(ROOT),'author':A.relative_to(ROOT).as_posix(),'actual_final_manifest':pin(manifest),'files':files,'budgets':budget,'new_output_headers':headers,'preparation_array_payload_decoded':False})
names=[D/n for n in ['saved_audit.py','audit_worker.py','run_saved_audit.py','freeze_saved_audit.py','saved-audit-plan.md','audit-inputs.json']]
names += [ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py',D.parent/'r02-amd-wheel-acquisition-20261021/win_job.py',D.parent/'r02-amd-wheel-acquisition-20261021/boundary.py']
for p in names:
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf8'),filename=str(p))
save(D/'audit-source-pins.json',{p.relative_to(ROOT).as_posix():pin(p) for p in names})
print(json.dumps({'source_pins':pin(D/'audit-source-pins.json'),'input_files':len(files),'new_output_headers':len(headers),'budgets':budget,'numerical_execution':0}))
