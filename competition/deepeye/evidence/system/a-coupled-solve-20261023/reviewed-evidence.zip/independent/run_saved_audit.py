"""Only root exact-pin selection permits the single new saved-output audit."""
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];stage=D/'saved-audit-01'
sys.path.insert(0,str(ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools'))
from evidence_json import write_new_report as save,dumps_report
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def main():
 config=read(D/'audit-inputs.json');frozen=read(D/'audit-source-pins.json');selected=read(D/'root-audit-selection.json')
 assert selected['saved_output_audit_selected'] is True and selected['stage']=='saved-audit-01' and selected['source_pins']==pin(D/'audit-source-pins.json') and selected['budgets']==config['budgets']
 before={n:pin(ROOT/n) for n in frozen};assert before==frozen and not stage.exists()
 inputs={n:pin(ROOT/n) for n in config['files']};assert inputs==config['files']
 sys.path.insert(0,str(D.parent/'r02-amd-wheel-acquisition-20261021'));from win_job import run_bounded,process_identity
 env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),'PATH':'','TEMP':str(stage),'TMP':str(stage),'TMPDIR':str(stage),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',**{n:'1' for n in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS')}}
 granted=False
 def tick(job,pids):
  nonlocal granted
  if not granted and (stage/'hello.json').exists():
   hello=read(stage/'hello.json');assert hello['pid'] in pids and hello['mode']=='saved_audit';save(stage/'grant.pending.json',{'worker':process_identity(hello['pid'],job)});os.replace(stage/'grant.pending.json',stage/'grant.json');granted=True
 terminal=run_bounded([str(ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'),'-I','-B','-P','-X','utf8',str(D/'audit_worker.py'),str(stage)],env,D,stage,config['budgets'],[D],on_tick=tick)
 after={n:pin(ROOT/n) for n in frozen};inputs_after={n:pin(ROOT/n) for n in config['files']}
 save(stage/'readback.json',{'source_unchanged':before==after,'inputs_unchanged':inputs==inputs_after,'sources':after,'inputs':inputs_after});assert before==after and inputs==inputs_after and terminal['all_processes_terminated']
 print(dumps_report({k:terminal.get(k) for k in ('status','exit_code','seconds','stop_reason','peak_job_memory_bytes','all_processes_terminated')}),end='',flush=True)
 return terminal['exit_code'] if terminal['exit_code'] is not None else 125
if __name__=='__main__':raise SystemExit(main())
