# Independent coupled-solve review: final evidence

The one selected saved-output audit conforms to the author's retained result. The new coupled candidate is numerically converged; both physical receiver screens fail. This is not G03, product or full-scope acceptance.

The implementation review found the original Schur RHS sign defect through the independent literal control, and reviewed its explicitly selected correction while preserving failed GREEN. The A0 L/U export allocation was removed through a separately selected finite-output adapter and isolated fake-only control. The original actual then failed at the unsupported raw NPZ load; its failure remains unchanged. Static writer/header review verified the separately selected CSR/CSC format adapter, new loader RED/GREEN, unchanged mathematical sources and complete phase-budget coverage. Frozen source d9d42840a29b04cf3f1a3a59ab4f6984255884afa45a84560efab772c90049ff and accepted assembly were dependencies, not independently reimplemented here.

The subsequent author `format-actual-01` used one D factor, one fresh A0 factor and one GMRES call: info=0, 47 callbacks, strict residual norm 1.5260620360909669e-18 versus 1.2707301235092744e-15 threshold. It exited 2 after 70.984 s because the unchanged receiver screens failed. Its candidate, residuals, scales and receiver evidence remain saved under author final manifest 9ae051d0a1b020e1d5166660c2b57f025f99f656fa28e6567e9b19359629c011.

Root selected this review's one stdlib audit at source-pins 8b6c556b69bef749d95be14e8fa9a7a564af4103a6fd57d5de72ac07e230f337. `saved-audit-01` exited 0 in 0.640 s, peak 91,734,016 bytes, all three held processes terminated, no resource stop. Nine source pins and 309 input/file pins remained identical before/after. No numerical tests, LU, GMRES, source/assembly, Green computation or complete old operator action were replayed by the reviewer.

The audit checked the full saved candidate update and boundary, strict correction norm/status, complete saved augmented residual/floor identities and every-row 128eps gate. Seven predetermined coarse rows and four bubble rows independently match the direct/reduced coupled equations, absolute-product scales and boundary terms. Recomputed eta is 1.8853945086840339e-19 using the producer's saved actual norm scalar. Both independently reduced receivers agree with the saved fields and old-V-plus-correction identities:

| Receiver | Complex relative error | Stability and update identity | Unchanged 1% gate |
|---|---:|---|---|
| 0 | 0.05858712111541739 (5.8587121115%) | Pass | Fail |
| 1 | 0.03527765623066182 (3.5277656231%) | Pass | Fail |

Limits: the augmented matrix maximum row norm and full direct/reduced consistency boolean remain dependencies on the reviewed producer. This audit independently checks fixed sample equations and row-norm lower bounds, not the complete old operator or maximum row norm. A successful audit means the retained evidence is consistent within that scope; it does not promote the failed physical screen or repair any older attempt. Original failures, thresholds and H01-H15 remain preserved under requirements SHA c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804. G03/R03/all29 remain not_run. Root retains all acceptance and successor selection.
