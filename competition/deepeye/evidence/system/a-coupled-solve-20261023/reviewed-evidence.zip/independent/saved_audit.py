"""Single prospective stdlib saved-candidate audit; no solver/science imports."""
import ast,hashlib,json,math,struct,zipfile
from pathlib import Path
C=128*2.220446049250313e-16
class Array:
 def __init__(self,f):
  assert f.read(6)==b'\x93NUMPY';version=tuple(f.read(2));assert version in ((1,0),(2,0),(3,0))
  n=struct.unpack('<H' if version==(1,0) else '<I',f.read(2 if version==(1,0) else 4))[0];assert n<65536
  h=ast.literal_eval(f.read(n).decode('utf8' if version==(3,0) else 'latin1'));assert not h['fortran_order']
  self.shape=h['shape'];self.descr=h['descr'];types={'<c16':('dd',True),'<f8':('d',False),'<i8':('q',False),'<i4':('i',False),'|b1':('?',False)}
  code,self.complex=types[self.descr];self.s=struct.Struct('<'+code);self.data=f.read();self.n=math.prod(self.shape)
  assert len(self.data)==self.n*self.s.size
 def __len__(self):return self.n
 def __getitem__(self,i):
  if not 0<=i<self.n:raise IndexError(i)
  v=self.s.unpack_from(self.data,i*self.s.size);return complex(*v) if self.complex else v[0]
 def __iter__(self):
  for v in self.s.iter_unpack(self.data):yield complex(*v) if self.complex else v[0]
def npy(path):
 with path.open('rb') as f:return Array(f)
def matrix(path):
 with zipfile.ZipFile(path) as z:
  assert set(z.namelist())=={'data.npy','indices.npy','indptr.npy','shape.npy'}
  out={}
  for n in ('data','indices','indptr','shape'):
   with z.open(n+'.npy') as f:out[n]=Array(f)
 return out
def total(values):
 values=list(values);return complex(math.fsum(v.real for v in values),math.fsum(v.imag for v in values))
def maximum(values):return max((abs(v) for v in values),default=0.)
def finite(values):return all(math.isfinite(v.real) and math.isfinite(v.imag) if isinstance(v,complex) else math.isfinite(v) for v in values)
def near(a,b,scale):return abs(a-b)<=C*(scale+abs(a)+abs(b))
def run(config):
 root=Path(config['root']);author=root/config['author'];actual=author/'format-actual-01';spec=json.loads((author/'input-pins.json').read_bytes());aliases=spec['aliases']
 def old(name):return npy(root/aliases[name])
 def new(name):return npy(actual/(name+'.npy'))
 result=json.loads((actual/'result.json').read_bytes());info=new('returned_info')[0];I=old('I');B=old('B');g=old('gB');Eh=old('Eh');e=new('returned_e');alpha=new('returned_alpha');delta=new('returned_delta');m=len(alpha);n=len(I)
 assert e.shape==Eh.shape==(63250,) and I.shape==(54418,) and B.shape==(8832,) and alpha.shape==(556,) and delta.shape==(54418,)
 assert finite(e) and finite(alpha) and finite(delta) and all(e[b]==g[j] for j,b in enumerate(B))
 assert all(e[i]==Eh[i]+delta[j] for j,i in enumerate(I))
 r=new('augmented_residual');p=new('augmented_absolute_product_scale');floor=new('augmented_floor');ri=new('direct_rI');rq=new('direct_rQ');red_i=new('reduced_rI');red_q=new('reduced_rQ');beff=new('beff8_direct');fbar=new('fbarQ')
 assert r.shape==p.shape==floor.shape==(n+m,) and ri.shape==red_i.shape==beff.shape==(n,) and rq.shape==red_q.shape==fbar.shape==(m,)
 assert all(finite(a) for a in (r,p,floor,ri,rq,red_i,red_q,beff,fbar)) and all(x>=0 for x in p)
 assert all(r[j]==ri[j] for j in range(n)) and all(r[n+j]==rq[j] for j in range(m)) and all(floor[j]==C*p[j] for j in range(n+m))
 rinf=maximum(r);xinf=max(maximum(e[i] for i in I),maximum(alpha));beff4=old('beff4_compensated');db=old('delta_b8_minus_b4');b8=old('b8');F8=old('coupled_F8_Q')
 beff8=[beff4[j]+db[i] for j,i in enumerate(I)];norm=result['augmented']['augmented_norm_inf'];assert math.isfinite(norm) and norm>=0
 den=norm*xinf+max(maximum(beff8),maximum(fbar));eta=rinf/den if den>0 else (0. if rinf==xinf==maximum(beff8)==maximum(fbar)==0 else math.inf)
 assert near(den,result['augmented']['normwise_denominator'],den) and near(eta,result['augmented']['eta'],abs(eta))
 floorpass=math.isfinite(eta) and eta<=C and all(abs(r[j])<=floor[j] for j in range(n+m))
 # Only fixed sampled rows of Ac and U/D; no full old operator action or full norm reduction.
 A=matrix(root/aliases['Ac']);ur=old('coupled_U_rows');uc=old('coupled_U_cols');uv=old('coupled_U');qr=old('coupled_Q_rows');qc=old('coupled_Q_cols');dv=old('coupled_D')
 ub={};ut={};drows={}
 for row,col,val in zip(ur,uc,uv):ub.setdefault(row,[]).append((col,val));ut.setdefault(col,[]).append((row,val))
 for row,col,val in zip(qr,qc,dv):drows.setdefault(row,[]).append((col,val))
 inverse={v:j for j,v in enumerate(I)};bmap={v:g[j] for j,v in enumerate(B)};canonical=sorted(ub)
 sample_i=sorted(set([0,1,n//2,n-1]+[inverse[canonical[j]] for j in (0,len(canonical)//2,len(canonical)-1) if canonical[j] in inverse]));sample_q=sorted(set([0,1,m//2,m-1]));sample_reports=[]
 for j in sample_i:
  row=I[j];lo,hi=A['indptr'][row],A['indptr'][row+1];entries=[(A['indices'][k],A['data'][k]) for k in range(lo,hi)];u=ub.get(row,[])
  ae=total(v*e[c] for c,v in entries);ua=total(v*alpha[c] for c,v in u);direct=ae-b8[row]+ua
  ai=total(v*e[c] for c,v in entries if c in inverse);ag=total(v*bmap[c] for c,v in entries if c in bmap);reduced=ai+ua-beff8[j]
  scale=math.fsum(abs(v)*abs(e[c]) for c,v in entries if c in inverse)+math.fsum(abs(v)*abs(alpha[c]) for c,v in u)+abs(beff8[j])
  fullscale=math.fsum(abs(v)*abs(e[c]) for c,v in entries)+abs(b8[row])+math.fsum(abs(v)*abs(alpha[c]) for c,v in u)
  assert near(direct,ri[j],fullscale) and near(reduced,red_i[j],scale) and near(scale,p[j],scale) and near(beff[j],b8[row]-ag,abs(b8[row])+abs(ag))
  rowsum=math.fsum(abs(v) for c,v in entries if c in inverse)+math.fsum(abs(v) for c,v in u);assert rowsum<=norm+C*(rowsum+norm)
  sample_reports.append({'kind':'coarse','free_position':j,'global_row':row,'residual_match':True,'scale_match':True,'row_norm_lower_bound':rowsum})
 for j in sample_q:
  u=ut.get(j,[]);dr=drows.get(j,[]);ue=total(v*e[c] for c,v in u);da=total(v*alpha[c] for c,v in dr);ug=total(v*bmap[c] for c,v in u if c in bmap);ui=total(v*e[c] for c,v in u if c in inverse)
  scale=math.fsum(abs(v)*abs(e[c]) for c,v in u if c in inverse)+math.fsum(abs(v)*abs(alpha[c]) for c,v in dr)+abs(fbar[j]);fullscale=math.fsum(abs(v)*abs(e[c]) for c,v in u)+math.fsum(abs(v)*abs(alpha[c]) for c,v in dr)+abs(F8[j])
  assert near(ue+da-F8[j],rq[j],fullscale) and near(ui+da-fbar[j],red_q[j],scale) and near(scale,p[n+j],scale) and near(fbar[j],F8[j]-ug,abs(F8[j])+abs(ug))
  rowsum=math.fsum(abs(v) for c,v in u if c in inverse)+math.fsum(abs(v) for c,v in dr);assert rowsum<=norm+C*(rowsum+norm)
  sample_reports.append({'kind':'bubble','row':j,'residual_match':True,'scale_match':True,'row_norm_lower_bound':rowsum})
 condensed=new('true_condensed_residual');h=new('new_h');assert finite(condensed) and finite(h)
 rn=math.sqrt(math.fsum(abs(v)**2 for v in condensed));hn=math.sqrt(math.fsum(abs(v)**2 for v in h));strict=rn<=1e-12*hn
 assert near(rn,result['true_condensed_norm'],rn) and near(hn,result['condensed_rhs_norm'],hn) and strict==result['strict_pass'] and info==result['info']
 aug=result['augmented'];assert aug['boundary_exact'] is True
 assert aug['passed']==bool(aug['direct_reduced_pass'] and floorpass and math.isfinite(den))
 status='solver_breakdown' if info<0 else 'numerical_gate_failed' if not aug['passed'] else ('strict_converged_candidate' if strict else 'strict_residual_revalidation_failed') if info==0 else 'roundoff_limited_candidate'
 assert result['status']==status
 physical=[]
 if status in ('strict_converged_candidate','roundoff_limited_candidate'):
  trace=old('trace');tq=old('coupled_tQ');H=old('high_H_saved');oldV=old('old_Vh_compensated');V=new('receiver_V');update=new('receiver_update_V');relative=new('receiver_error_relative');stability=new('receiver_stable');savedscale=new('receiver_absolute_product_scale');savedbound=new('receiver_identity_bound');identityerror=new('receiver_identity_error');abserror=new('receiver_error_abs');stabilityfloor=new('receiver_stability_floor')
  assert trace.shape==(2,len(e)) and tq.shape==(2,m) and H.shape==V.shape==(2,)
  for k in range(2):
   products=[trace[k*len(e)+j]*e[j] for j in range(len(e))];bubble=[tq[k*m+j]*alpha[j] for j in range(m)];dp=[trace[k*len(e)+i]*delta[j] for j,i in enumerate(I)];sc=math.fsum(abs(v) for v in products);sb=math.fsum(abs(v) for v in bubble);sd=math.fsum(abs(v) for v in dp)
   value=total(products)+total(bubble);upd=oldV[k]+total(dp)+total(bubble);scale=sc+sb;bound=C*(sc+sb+abs(oldV[k])+sd+sb);stable=abs(H[k])>C*scale and abs(value)>C*scale;err=abs(value-H[k]);rel=err/abs(H[k]) if stable else math.inf
   assert near(value,V[k],scale) and near(upd,update[k],scale+sd+abs(oldV[k])) and near(scale,savedscale[k],scale) and near(bound,savedbound[k],bound) and near(value-upd,identityerror[k],scale+sd+abs(oldV[k])) and near(err,abserror[k],abs(value)+abs(H[k])) and near(C*scale,stabilityfloor[k],C*scale)
   assert bool(stability[k])==stable and ((not stable and math.isinf(relative[k])) or near(rel,relative[k],abs(rel)))
   physical.append({'receiver':k,'value':[value.real,value.imag],'relative_error':rel if math.isfinite(rel) else None,'stable':stable,'identity_pass':abs(value-upd)<=bound,'one_percent_pass':stable and rel<=.01})
  passed=all(x['identity_pass'] and x['one_percent_pass'] for x in physical);assert passed==result['selected_screens_pass']==result['physical_screens']['passed']
 else:assert result['physical_screens']=='not_run' and result['selected_screens_pass'] is False
 return {'status':'saved_output_audit_conforms','solver_status':status,'info':info,'strict_pass':strict,'every_row_floor_pass':floorpass,'eta':eta,'sampled_rows':sample_reports,'receiver_checks':physical,'selected_screens_pass':result['selected_screens_pass'],'limitations':['augmented norm scalar reused from frozen producer; only sampled row-norm lower bounds independently checked','full direct/reduced comparison uses producer saved boolean; fixed sampled equations independently checked','no old full operator action, factorization, solver or control replay'],'G03':'not_run','R03':'not_run','all29':'not_run'}
