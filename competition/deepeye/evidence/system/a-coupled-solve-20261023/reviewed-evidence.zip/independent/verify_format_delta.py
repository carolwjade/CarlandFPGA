"""Independent hashes, JSON and ZIP/NPY headers only. No science imports."""
import ast,hashlib,json,struct,zipfile
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];A=D.parent/'g03-coupled-solve-20261023'
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
latest=read(A/'format-source-pins.json');old=read(A/'preconditioner-control-source-pins.json');red=read(A/'format-red-source-pins.json')
assert all(pin(ROOT/n)==v for n,v in latest.items())
manifest=read(A/'format-delta-manifest.json');assert all(pin(A/n)==v for n,v in manifest['files'].items())
snapshots=list((A/'format-before-source').glob('*.py'))
assert snapshots and all(pin(p)==old[(A/p.name).relative_to(ROOT).as_posix()] for p in snapshots)
unchanged=['coupled_core.py','numerical_policy.py','raw_outputs.py','fixture.json','test_solver_controls.py','test_preconditioner_adapter.py','input-pins.json']
for n in unchanged:
 k=(A/n).relative_to(ROOT).as_posix();assert old[k]==latest[k]==pin(A/n)
loader=(A/'raw_sparse.py').relative_to(ROOT).as_posix()
assert red.keys()==latest.keys() and [k for k in red if red[k]!=latest[k]]==[loader]
assert pin(A/'format-red-loader.txt')==red[loader]
spec=read(A/'input-pins.json');headers={}
for alias in ['Ac','A0II']:
 path=ROOT/spec['aliases'][alias];members={}
 with zipfile.ZipFile(path) as z:
  assert set(z.namelist())=={'shape.npy','data.npy','indices.npy','indptr.npy'}
  for name in z.namelist():
   with z.open(name) as f:
    assert f.read(6)==b'\x93NUMPY';version=tuple(f.read(2));assert version in [(1,0),(2,0),(3,0)]
    n=struct.unpack('<H' if version==(1,0) else '<I',f.read(2 if version==(1,0) else 4))[0];assert n<65536
    h=ast.literal_eval(f.read(n).decode('utf8' if version==(3,0) else 'latin1'))
    members[name]=h
 headers[alias]={'path':spec['aliases'][alias],'members':members,'array_payload_decoded':False}
stages={}
for n in ['actual-01','format-red-01','format-controls-01']:
 t=read(A/n/'terminal.json');rb=read(A/n/'input-readback.json');assert t['all_processes_terminated'] and t['active_processes_final']==0 and rb['unchanged'] and rb['before']==rb['after']
 assert t['exit_code']==(0 if n=='format-controls-01' else 1)
 f=read(A/n/('worker-evidence.json' if n=='format-controls-01' else 'failure.json'));assert f['runtime_before']==f['runtime_after']
 stages[n]={'terminal':pin(A/n/'terminal.json'),'seconds':t['seconds'],'peak_job_memory_bytes':t['peak_job_memory_bytes'],'all_processes_terminated':True,'runtime_before_after_equal':True,'input_readback_unchanged':True}
assert read(A/'format-controls-01/result.json')['status']=='new_raw_sparse_loader_controls_pass'
prior=read(A/'actual-final-manifest.json')
preserved={n:v for n,v in prior['files'].items() if n.startswith('actual-01/')}
assert preserved and all(pin(A/n)==v for n,v in preserved.items())
assert not (A/'format-actual-01').exists()
out={'status':'format_delta_static_readback_pass','source_pins':pin(A/'format-source-pins.json'),'source_pin_count':len(latest),'manifest':pin(A/'format-delta-manifest.json'),'manifest_files':len(manifest['files']),'format_delta_record':pin(A/'format-delta-record.json'),'format_before_source_count':len(snapshots),'unchanged':unchanged,'RED_to_GREEN_only_change':'raw_sparse.py','original_failed_actual_files_preserved':len(preserved),'raw_archive_headers':headers,'stages':stages,'format_actual_absent_at_readback':True,'numerical_arrays_decoded':0,'numerical_execution':0}
with (D/'format-readback.json').open('x',encoding='utf8') as f:json.dump(out,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(out))
