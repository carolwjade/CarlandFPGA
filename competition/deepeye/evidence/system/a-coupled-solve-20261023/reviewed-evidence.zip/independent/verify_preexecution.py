"""Hash/JSON-only independent readback; no numerical array decoding."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];A=D.parent/'g03-coupled-solve-20261023'
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
latest=read(A/'preconditioner-control-source-pins.json')
assert all(pin(ROOT/n)==v for n,v in latest.items())
manifest=read(A/'preconditioner-delta-manifest.json')
assert all(pin(A/n)==v for n,v in manifest['files'].items())
old=read(A/'control-source-pins.json');green=read(A/'corrected-control-source-pins.json')
snapshots={}
for folder,record in [('failed-green-source',old),('preconditioner-before-source',green)]:
 files=list((A/folder).glob('*.py'))
 assert files and all(pin(p)==record[(A/p.name).relative_to(ROOT).as_posix()] for p in files)
 snapshots[folder]=len(files)
for n in ['fixture.json','test_solver_controls.py','input-pins.json']:
 k=(A/n).relative_to(ROOT).as_posix();assert old[k]==green[k]==latest[k]==pin(A/n)
stages={}
for n in ['controls-01','corrected-controls-01','preconditioner-controls-01']:
 t=read(A/n/'terminal.json');rb=read(A/n/'input-readback.json')
 assert t['all_processes_terminated'] and t['active_processes_final']==0 and rb['unchanged'] and rb['before']==rb['after']
 if n!='controls-01':assert t['status']=='success' and t['exit_code']==0
 else:assert t['status']=='failed' and t['exit_code']==1
 stages[n]={'terminal':pin(A/n/'terminal.json'),'result':pin(A/n/'result.json') if (A/n/'result.json').exists() else None,'seconds':t['seconds'],'peak_job_memory_bytes':t['peak_job_memory_bytes'],'all_processes_terminated':True}
assert not (A/'actual-01').exists()
out={'status':'static_preexecution_readback_pass','source_pins':pin(A/'preconditioner-control-source-pins.json'),'source_pin_count':len(latest),'delta_manifest':pin(A/'preconditioner-delta-manifest.json'),'delta_manifest_files':len(manifest['files']),'snapshots_verified':snapshots,'frozen_fixture_tests_inputs_unchanged':True,'stages':stages,'actual_stage_absent_at_readback':True,'numerical_arrays_decoded':0,'numerical_tests_or_solves':0}
with (D/'preexecution-readback.json').open('x',encoding='utf8') as f:json.dump(out,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(out))
