"""Independently check the new L6 cached boundary and saved assembly; no solve."""
import json,math,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent
S=O/'g03-l6-outer-xy-refinement-20261021';C=S/'controls-01';A=S/'run-01'
OLD=O/'g03-l5-propagation-z-refinement-20261021/controls-01'
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.startfile','socket.connect','socket.bind','socket.getaddrinfo'):
        raise RuntimeError('review forbids processes, network and UI')
    if event=='open' and not isinstance(args[0],int):
        mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writing and not Path(args[0]).resolve().is_relative_to(D):raise RuntimeError('unowned write')
sys.addaudithook(audit)
import numpy as np
from scipy.sparse import csr_matrix,csc_matrix
def arr(folder,name):return np.load(folder/(name+'.npy'),allow_pickle=False)
def matrix(name,cls):
    with np.load(A/(name+'.npz'),allow_pickle=False) as n:return cls((n['data'],n['indices'],n['indptr']),shape=tuple(n['shape']))
b=arr(C,'boundary_indices');interior=arr(C,'interior_indices');old_b=arr(OLD,'boundary_indices')
reuse=arr(C,'boundary_reused_positions');old_positions=arr(C,'boundary_old_positions');new=arr(C,'boundary_new_positions')
assert np.array_equal(np.sort(np.r_[b,interior]),np.arange(85434))
assert len(reuse)==7904 and len(new)==2848 and len(old_positions)==len(reuse)
assert np.array_equal(np.sort(np.r_[reuse,new]),np.arange(len(b)))
for name in ('edge_starts_m','edge_ends_m'):
    actual=arr(C,name)[b[reuse]].astype('<f8',copy=False).tobytes()
    previous=arr(OLD,name)[old_b[old_positions]].astype('<f8',copy=False).tobytes()
    assert actual==previous,name
for name in ('boundary_g_64x8_Vpm','boundary_g_128x16_Vpm'):
    assert arr(C,name)[reuse].tobytes()==arr(OLD,name)[old_positions].tobytes(),name
curl=matrix('C-csr',csr_matrix);system=matrix('A-csr',csr_matrix);reduced=matrix('AII-csc',csc_matrix)
assert curl.shape==(82656,85434) and system.shape==(85434,85434) and reduced.shape==(74682,74682)
delta=(system[interior,:][:,interior]-reduced).tocsr()
assert delta.nnz==0 or np.all(delta.data==0)
rhs=arr(A,'raw_rhs');saved_source=arr(A,'source_actual_CtW_Am')
assert np.array_equal(rhs,-1j*(2*math.pi*2e6)*saved_source)
expected=rhs[interior]-system[interior,:][:,b].dot(arr(C,'boundary_g_128x16_Vpm'))
assert np.array_equal(expected,arr(A,'A_II_rhs'))
assert not (A/'E_Vpm.npy').exists() and not (A/'V_compatible_V.npy').exists() and not (A/'result.json').exists()
result={'status':'ACCEPT_NEW_L6_SAVED_ASSEMBLY_AND_CACHE_ONLY','bit_identical_cached_edges':len(reuse),
    'new_boundary_edges':len(new),'AII_exact_submatrix':True,'reduced_rhs_exact_from_saved_assembly':True,
    'solution_present':False,'matrix_assemblies':0,'factorizations':0,'Green_evaluations':0,'old_tests_repeated':False,
    'physical_accuracy':'unqualified','G03':'not_run','all29':'not_run'}
with (D/'array-review.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
