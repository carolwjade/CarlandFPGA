from datetime import datetime,timezone
import ast,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent;ROOT=O.parents[1]
S=O/'g03-l6-outer-xy-refinement-20261021'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):
    with p.open('x',encoding='utf-8') as f:json.dump(d,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
assert read(O/'field-refinement-publication-20261021/l6-executor-readback.json')['count']==0
assert read(D/'array-review.json')['status']=='ACCEPT_NEW_L6_SAVED_ASSEMBLY_AND_CACHE_ONLY'
pins=read(S/'input-pins.json')
for p,expected in pins.items():assert sha(ROOT/p)==expected,p
for stage in ('controls-01','run-01'):
    check=read(S/stage/'input-readback.json')
    assert check['unchanged'] and check['before']==check['after']==pins
    t=read(S/stage/'terminal.json')
    assert t['all_processes_terminated'] and t['active_processes_final']==0
    assert all(h['signaled'] and h['wait_result']==0 for h in t['held_members'])
actual=read(S/'run-01/terminal.json')
assert actual['exit_code']==124 and actual['stop_reason']=='timeout'
before=read(S/'run-01/pre-factorization-assembly.json')
for name,pin in before['files'].items():
    p=S/'run-01'/name
    assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],name
def function(path,name):
    return ast.dump(next(n for n in ast.parse(path.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False)
old=O/'g03-l5-propagation-z-refinement-20261021/grid_model.py'
assert function(old,'green_boundary')==function(S/'grid_model.py','green_boundary')
takeover={'utc':datetime.now(timezone.utc).isoformat(),'main_thread_id':'01a13d7e-dcf1-7272-a738-a637dd62ff9d',
    'generation':2,'canonical_worker':'/root/g03_grid_continuation_20261021',
    'collaboration_interrupt_previous_status':'interrupted','collaboration_list_status':'interrupted',
    'original_science_processes_terminated':True,'outer_executor_readback_count':0,
    'original_source_pins_unchanged':True,'new_science_replays':0,'purpose':'Seal failed original job, not resume it.'}
save(S/'main-closeout.json',takeover)
text='''A-G03-L6-OUTER-XY-REFINEMENT-20261021-v1 failed in its one selected actual process with timeout/exit124. The original worker was confirmed interrupted; root confirmed all three retained science handles signaled and no matching outer executor remained, then sealed this exact job without replay. Native job child-d810d0c8ece848e593e105a1f943c65b. H01-H15 canonical requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 remains unchanged.

New 28x28x34 controls passed: 85434 edges, 74682 interior and10752 boundary, source176 interior/zero boundary. Exactly7904 byte-identical oriented boundary edges reused saved L5 values; only2848 new boundary edges were integrated. One actual process persisted exact C/A/AII/source/raw/reduced RHS before the selected factorization; completion of factorization/solve was not observed and no field or receiver voltage exists. C330624/A1077306/AII940386 nonzeros. Root independently verified all source pins, six saved operator hashes, cached endpoint/value bytes, exact AII submatrix and reduced RHS without mesh assembly, factorization or Green/reference integration.

Actual terminal elapsed308.954s exceeds selected120s threshold; stop_reason timeout and peak job memory3728248832B. Every retained handle signaled and active count0. Evidence does not separate timeout observation, native termination and cleanup delay and does not prove a120s hard wall-time bound. No automatic retry, second grid, new ordering or voltage accuracy claim. Independent saved-array review0.859s/160907264B, all held processes terminated. Existing passed tests and base-board384/384 were not repeated. Physical accuracy, G03/R03/H12 and all29 formal acceptance remain open/not_run.
'''
with (S/'final-result.txt').open('x',encoding='utf-8') as f:f.write(text)
with (S/'report.md').open('x',encoding='utf-8') as f:f.write('# L6 selected outer-XY attempt: failed and preserved\n\n'+text)
files=[]
for p in sorted(S.rglob('*')):
    if not p.is_file() or any(x.startswith('matplotlib-') or x=='__pycache__' for x in p.parts):continue
    if 'private' in p.name.casefold() or p.name in ('reserve-request.json','public-manifest.json','native-complete-response.json'):continue
    files.append(p)
manifest={'work_id':'A-G03-L6-OUTER-XY-REFINEMENT-20261021-v1','status':'failed_timeout_no_solution',
    'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    'file_count':len(files),'files':{p.relative_to(S).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files},
    'private_exclusions':['lease.private.json','reserve-request.json','reserve.stderr.private.txt','native-complete-response.json'],
    'main_sealed_after_confirmed_interruption':True,'all29':'not_run'}
save(S/'public-manifest.json',manifest)
lease=read(S/'lease.private.json')
if 'job_id' not in lease:lease=json.loads(next(v['text'] for v in lease['content'] if v['type']=='text'))
assert lease['job_id']=='child-d810d0c8ece848e593e105a1f943c65b'
save(D/'complete-args.private.json',{'job_id':lease['job_id'],'lease_token':lease['lease_token'],
    'text':text,'error':'Selected L6 actual process timeout; no solved field. Original worker interrupted, root verified termination and sealed without replay.'})
save(D/'integrity.json',{'verified_source_pins':len(pins),'saved_prefactorization_files':6,
    'manifest_files':len(files),'manifest_sha256':sha(S/'public-manifest.json'),'native_completion_pending':True})
print(json.dumps({'files':len(files),'manifest_sha256':sha(S/'public-manifest.json'),'failed_job_closeout_prepared':True}))
