from pathlib import Path
D=Path(__file__).resolve().parent
with (D/'run_review.py').open('x',encoding='utf-8') as f:f.write((D.parent/'g03-l5-main-review-20261021/run_review.py').read_text(encoding='utf-8'))
print('Prepared new saved-array review, no science replay.')
