"""Archive only selected, completed and independently reviewed new science."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parent;O=D.parent;ROOT=O.parents[1]
P=ROOT/'.local/deepeye-implementation-a'
T=P/'competition/deepeye/evidence/system/a-field-refinement-20261021'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def enc(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(p,raw):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(raw)
selection=read(D/'selected.json')
tokens=[]
for spec in selection['work']:
    lease=read(O/spec['folder']/'lease.private.json')
    if 'lease_token' in lease:tokens.append(lease['lease_token'].encode())
    else:
        for row in lease.get('content',[]):
            if row.get('type')=='text':
                value=json.loads(row['text'])
                if 'lease_token' in value:tokens.append(value['lease_token'].encode())
members={};derivatives=[];reviews={}
def clean(v):
    if isinstance(v,list):return [clean(x) for x in v]
    if isinstance(v,dict):return {k:clean(x) for k,x in v.items() if k not in ('environment','env')}
    return v
def add(p):
    assert p.is_relative_to(O)
    if 'private' in p.name.casefold() or p.name=='reserve-request.json':return
    raw=p.read_bytes();name=p.relative_to(O).as_posix()
    if p.suffix=='.json':
        value=json.loads(raw);public=clean(value)
        if public!=value:
            public['original_environment_omitted']=True
            public['original_local_sha256']=sha(raw)
            name=name.removesuffix('.json')+'-public.json'
            derivatives.append({'published_path':name,'original_sha256':sha(raw)})
            raw=enc(public)
    assert name not in members and not any(token in raw for token in tokens),name
    members[name]=raw
for spec in selection['work']:
    folder=O/spec['folder'];manifest_name=spec.get('manifest_name','public-manifest.json');manifest=read(folder/manifest_name)
    assert sha((folder/manifest_name).read_bytes())==spec['manifest_sha256']
    review_folder=O/spec['review_folder'];review=read(review_folder/'review.json')
    assert review['status']==spec['review_status']
    reviews[spec['folder']]=review
    native=read(folder/'native-complete-response.json')
    if 'job_id' not in native:native=json.loads(next(v['text'] for v in native['content'] if v['type']=='text'))
    assert native['status']==spec.get('native_status','completed') and native['terminal'] and not native['stale']
    if native['status']=='failed':assert native['result'] is None and native['error']==spec['native_error']
    else:assert native['result']['text']==(folder/spec.get('native_text_file','final-result.txt')).read_text(encoding='utf-8')
    for rel,pin in manifest['files'].items():
        p=folder/rel
        assert p.stat().st_size==pin['bytes'] and sha(p.read_bytes())==pin['sha256'],str(p)
        add(p)
    add(folder/manifest_name);add(folder/'native-complete-response.json')
    for extra in spec.get('extra_files',[]):add(folder/extra)
    for p in sorted(review_folder.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:add(p)
summary={'utc':datetime.now(timezone.utc).isoformat(),'selection':selection,'reviews':reviews,'public_derivatives':derivatives,
    'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    'old_tests_repeated':False,'physical_accuracy':'unqualified','formal_G03':'not_run','formal_R03':'not_run','all29':'not_run'}
members['main/summary.json']=enc(summary);members['main/prepare.py']=Path(__file__).read_bytes()
for name in ('finalize_reviews_attempt1.py','finalize-attempt1-failure.json','finalize_reviews.py'):
    members['main/'+name]=(D/name).read_bytes()
T.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(T/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()):
        zi=zipfile.ZipInfo(name,(2026,10,21,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16
        z.writestr(zi,raw)
with zipfile.ZipFile(T/'evidence.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for name,raw in members.items():assert z.read(name)==raw
write(T/'.gitattributes',b'* -text -eol -filter\n')
write(T/'archive-index.json',enc({n:{'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(members.items())}))
write(T/'summary.json',enc(summary))
write(T/'README.md',(D/'README-source.md').read_bytes())
write(T/'manifest.json',enc({'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(T.iterdir())},
    'archive_members':len(members),'exact_member_bytes_and_crc_checked':True}))
guide=P/'competition/deepeye/docs/field_refinement_checkpoint_20261021.md'
write(guide,'''# New field refinement evidence

The [field refinement checkpoint](../evidence/system/a-field-refinement-20261021/README.md)
contains new receiver error decomposition and selected 3D mesh results, with
their exact arrays, sources, bounded process terminals and main reviews.
Previous solver, runtime, R03 and board baselines were reused, not rerun.
Physical accuracy and formal G03 acceptance remain open.
'''.encode())
paths=[*sorted(T.iterdir()),guide]
files={p.relative_to(P).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in paths}
write(D/'publication-files.json',enc(files));write(D/'owned-paths.nul',b''.join(n.encode()+b'\0' for n in files))
r={'files':len(files),'archive_members':len(members),'archive_bytes':(T/'evidence.zip').stat().st_size,
   'archive_sha256':sha((T/'evidence.zip').read_bytes()),'environment_derivatives':len(derivatives)}
write(D/'package-summary.json',enc(r));print(json.dumps(r))
