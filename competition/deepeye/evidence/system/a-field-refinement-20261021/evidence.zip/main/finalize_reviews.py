import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent;ROOT=O.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
def native(folder,text_file):
    n=read(folder/'native-complete-response.json')
    if 'job_id' not in n:n=json.loads(next(v['text'] for v in n['content'] if v['type']=='text'))
    assert n['terminal'] and not n['stale']
    if n['status']=='failed':
        submitted=read(O/'g03-l6-main-review-20261021/complete-args.private.json')
        assert n['result'] is None and n['error']==submitted['error']
        assert submitted['text']==(folder/text_file).read_text(encoding='utf-8')
    else:assert n['result']['text']==(folder/text_file).read_text(encoding='utf-8')
    return {k:n[k] for k in ('job_id','status','terminal','stale','error') if k in n}
l6=O/'g03-l6-outer-xy-refinement-20261021'
n=native(l6,'final-result.txt');assert n['status']=='failed'
m=read(l6/'public-manifest.json')
for name,pin in m['files'].items():
    p=l6/name;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256']
save(O/'g03-l6-main-review-20261021/review.json',{'status':'ACCEPT_NEW_L6_CONTROLS_AND_FAILED_ATTEMPT_ONLY',
    'native':n,'manifest_sha256':sha(l6/'public-manifest.json'),'verified_files':len(m['files']),
    'array_review':read(O/'g03-l6-main-review-20261021/array-review.json'),
    'scope':'Source and cache mapping reviewed; C/A/AII and RHS saved and independently checked. No solved field or voltage, no hard120s wall-time proof.',
    'original_worker_interrupted_verified':True,'old_tests_repeated':False,'formal_G03':'not_run','all29':'not_run'})
s=O/'g03-secondary-field-design-20261021';m=read(s/'manifest.json')
assert sha(s/'manifest.json')=='774f655449546250fc18c647a985a9657c5514eea7ce5c969713a15f240deead'
for name,pin in m['files'].items():
    p=s/name;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256']
pins=read(s/'source-pins.json')['files']
for name,pin in pins.items():
    p=ROOT/name;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],name
n=native(s,'native-final-body.txt');assert n['status']=='completed'
assert (s/'final-result.txt').read_text(encoding='utf-8')==(s/'native-final-body.txt').read_text(encoding='utf-8')+'\n'
save(O/'g03-secondary-field-main-review-20261021/review.json',{'status':'SELECT_S1_NONZERO_OFF_AXIS_DERIVATIVE_DESIGN',
    'verified_manifest_files':len(m['files']),'verified_source_pins':len(pins),'manifest_sha256':sha(s/'manifest.json'),'native':n,
    'design_sha256':sha(s/'design.md'),'review':'Consistent exp(+iwt), admittivity displacement sign, physical contrast vs discrete wire residual distinction, arbitrary-pose finite loop, compatible three-component trace and independent H-volume/flux derivative. Installed conductivity-only primary-secondary and sigma-denominator E oracle excluded.',
    'selected_scope':'One new nonzero off-axis sigma+epsilon derivative, fixed saved L5 background AII and independent Geoana magnetic-field volume integral; no finite-strength or arbitrary-heterogeneous acceptance.',
    'qualifications':['1% derivative and0.1% quadrature screens are new engineering diagnostics, not original taskbook gates.',
      'Zero secondary boundary is approximate and its bias remains part of the observed difference.',
      'Timeouts are sampled thresholds; L6 proves no hard wall-time bound. Require actual terminal and held-handle evidence.',
      'Noise/calibration budget and independent full heterogeneous validation remain missing.'],
    'numerical_validation':'not_run','old_tests_repeated':False,'formal_G03':'not_run','all29':'not_run'})
print(json.dumps({'L6':'failed original native terminal and52files verified','S1_design':'selected after9manifest/27source/native review','goal':'active'}))
