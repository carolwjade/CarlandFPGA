"""Public L4 file hash manifest; exclude private lease and installed environment."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
excluded={'lease.private.json','reserve-request.json','reserve.stderr.private.txt',
          'public-manifest.json','native-complete-response.json'}
files={}
for p in sorted(D.rglob('*')):
    if not p.is_file() or p.name in excluded:continue
    rel=p.relative_to(D).as_posix()
    files[rel]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
record={'work_id':'A-G03-L4-GLOBAL-REFINEMENT-20261021-v1',
    'status':'controls_pass_actual_superlu_memoryerror_no_L4_voltage',
    'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    'file_count':len(files),'files':files,'private_exclusions':sorted(excluded),
    'installed_environment_included':False,'all29':'not_run'}
with (D/'public-manifest.json').open('x',encoding='utf-8') as f:
    json.dump(record,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
print(json.dumps({'file_count':len(files),'manifest_sha256':hashlib.sha256((D/'public-manifest.json').read_bytes()).hexdigest()}))
