# Proposed next G03 experiment: a nonzero, off-axis secondary-field derivative

Status: **design only; main selection required before implementation**. No numerical computation, scientific import, installation, old test, or runtime probe was performed in this task. H01–H15, the active generation-2 director, and the pinned requirements hash remain unchanged. This is a reference-model development step, not G03 or all29 acceptance.

## Recommendation and alternatives

Propose one new bounded experiment: **S1**, a full-wave, finite-coil, off-axis response derivative for a compact 3D conductivity/permittivity contrast. Reuse the fixed L5 background operator; solve one genuinely new right-hand side. Compare its nonzero complex receiver voltage with a free-space volume-integral reference using the already installed Geoana **electric-current-dipole magnetic-field** implementation. This tests the contrast source, pose, receiver, sign and full-wave material handling without resolving the singular transmitter in the PDE source. It is not a finite-strength heterogeneous solution.

| Route | Evidence and cost | Appropriate use |
|---|---|---|
| Continue total-field refinement | L5 errors remain 11.1375% / 9.2099%; L4 receiver decomposition attributes most discrepancy to the solved field, not the receiver functional. More cells increase direct-factor memory. Existing L5 is a genuine full 3D field solve. | Retain as an independent formulation and convergence branch. Wait for the separately owned refinement result; this task has not read that mutable directory. Refining only receiver quadrature is unlikely to remove the present discrepancy. |
| Physical primary–secondary | Removes the known background wire field from the unknown, leaving a distributed contrast source away from the wire. Same heterogeneous operator and factorization cost at a given mesh; no guaranteed speedup or accuracy improvement. | Best proposed next development direction for compact heterogeneity and arbitrary coil pose. Begin with S1 and an independent nonzero oracle, then qualify finite contrast and boundaries. |
| Independent installed reference | Geoana 0.8.1 has whole-space current-dipole H with displacement-aware wavenumber. It can support finite-coil and first-Born volume integration without SimPEG/discretize. No installed empymod distribution was present in the selected scientific environment. | Independent implementation of homogeneous fields and the exact first derivative about a homogeneous background. Not an independent solver for arbitrary strong 3D heterogeneity. Layered, static-sphere, magnetic-dipole or coaxial solutions cannot validate the complete target model. |

The next experiment must not report a zero-contrast background plus analytic primary as a successful independent Maxwell solve. A zero right-hand side returning zero only tests wiring. S1 has a nonzero contrast derivative and a separately assembled observable.

## Exact source findings

Installed read-only environment: `.local/deepeye-fdem-validation-20261020/Lib/site-packages`; SimPEG **0.25.2**, discretize **0.12.0**, Geoana **0.8.1**, versions read from dist-info METADATA without imports. Exact local source hashes and relevant line ranges are in `source-pins.json` / `source-evidence.json`.

* SimPEG `simulation.py` uses `sigma + 1j*omega*permittivity` and `C.T*MfMui*C + 1j*omega*Meyhat`. Its permittivity path explicitly warns that testing is incomplete and derivatives are not implemented; do not silently drop epsilon or claim vendor qualification.
* `PrimSecSigma` and `PrimSecMappedSigma` construct conductivity mass contrast only. They are not drop-in full-wave admittivity/permeability contrast sources. `CircularLoop` imports its primary from `geoana.em.static`; its documented primary split is a zero-frequency construction. Keep the current finite-frequency background Green field instead of silently substituting this source.
* The **installed** `ElectricDipoleWholeSpace.electric_field` denominator is `self.sigma`, while its docstring specifies `sigma+i*omega*epsilon`. Its full-wave E output is therefore excluded from the oracle. Do not patch the installed package, multiply an unexplained correction into it, or invoke its E/current-density branch.
* Its `magnetic_field` branch uses `(1+i*k*r)*exp(-i*k*r)/(4*pi*r^2)` times the cross product and current moment, with `k=sqrt(omega^2*mu*epsilon-i*omega*mu*sigma)` and `quasistatic=False`. This source supports the proposed H/flux oracle. This is a source-review finding; the new branch still needs its own bounded controls before numerical use.
* SimPEG `getRHS` magnetic-source docstring differs from its executable expression. S1 sets magnetic impressed source to zero and constructs its weak electric contrast RHS explicitly; no inference from that inconsistent docstring is needed.

Official primary references: [SimPEG primary-secondary API](https://docs.simpeg.xyz/latest/content/api/generated/simpeg.electromagnetics.frequency_domain.sources.PrimSecSigma.html), [SimPEG source](https://github.com/simpeg/simpeg/blob/v0.25.2/simpeg/electromagnetics/frequency_domain/simulation.py), [discretize 0.12 edge inner products](https://discretize.simpeg.xyz/en/v0.12.0/api/generated/discretize.TensorMesh.get_edge_inner_product.html), [Geoana 0.8.1 source](https://raw.githubusercontent.com/simpeg/geoana/v0.8.1/geoana/em/fdem/wholespace.py). Installed pinned bytes take precedence over a moving documentation page.

## Equations, units and discrete split

Use physical fields `Re{E exp(+i omega t)}`, SI units, omega=2*pi*f and admittivity `zeta=sigma+i*omega*epsilon`. Passive isotropic initial materials have sigma>=0, epsilon>0 and mu>0. Maxwell equations are

```
curl E = -i*omega*mu*H
curl H = zeta*E + J_s
L_m E := curl(mu^-1 curl E) + i*omega*zeta*E = -i*omega*J_s.
```

Thus displacement contributes **-omega^2*epsilon**, not +omega^2*epsilon. For a background p containing the same impressed coil, `L_p E_p=-i*omega*J_s`, and

```
L_m E_s = curl[(mu_p^-1-mu^-1) curl E_p]
          + i*omega*(zeta_p-zeta)*E_p;    E=E_p+E_s.
```

Retain the heterogeneous target operator on the left; this is not a Born approximation when solved with full `L_m`. Fixed permeability reduces the RHS to `-i*omega*Delta_zeta*E_p`.

For the existing tensor FV convention, `e` stores edge-average tangential E [V/m], `C` maps it to face-average curl E [V/m²]. Material inner products include cell-volume weighting; they are not raw edgewise property diagonals. With `M_f(mu^-1)` and `M_e(zeta)` constructed by the pinned discretize methods,

```
A_m = C.T M_f(mu^-1) C + i*omega M_e(zeta)
q_s = C.T [M_f(mu_p^-1)-M_f(mu^-1)] C e_p
      + i*omega [M_e(zeta_p)-M_e(zeta)] e_p.
```

`M_e(zeta)e` is a weak current [A m], and `q_s` has [A m/s], matching L5's `-i*omega*s_e`. For constant mu and new S1 contrast `delta_zeta`, `A_p e_dot_s=-i*omega*M_e(delta_zeta)*e_p`, where the dot is derivative with respect to dimensionless contrast strength tau at zero. The identity follows by differentiating `A(tau)e_s(tau)=-i*omega*tau*M_e(delta_zeta)e_p`; S1 has **one new nonzero derivative solve**, not a zero-contrast total-field solve.

Important discrete distinction: interpolated continuum `e_p` generally does not satisfy `A_p e_p=b`. Let `r_p=b-A_p e_p`. Using `q_s=(A_p-A_m)e_p` is the physical-contrast discretization; adding `r_p` makes `A_m(e_p+e_s)=b` exactly, algebraically reproducing the original total-field discretization. That residual-corrected version cannot remove its physical discretization error by relabeling the unknown. Record these as different formulations; never add the wire defect unnoticed. Zero-contrast residual norms may diagnose this distinction but are not a new accuracy certificate.

Initial boundary: constrain secondary tangential boundary edges to zero and solve `A_II e_s,I=q_s,I`. This approximates an outgoing secondary field; compact contrast does **not** make its boundary field exactly zero. No claim of exact radiation/PEC physics follows. The infinite-space oracle comparison includes this domain error; later separate padding/domain and mesh studies are mandatory. PML/DtN or heterogeneous exterior changes require a new selected design. For full total field the corresponding approximate boundary is the sampled primary, not zero total E.

## Arbitrary finite-coil primary and singular support

Represent a circular filament by center c, radius a and right-handed orthonormal `(u,v,n)` with `u cross v=n`. `r(theta)=c+a(u cos theta+v sin theta)` and `dl=a(-u sin theta+v cos theta)dtheta`. A rigid rotation R must satisfy `R.T R=I`, det R=+1. Retain finite radius, current and turns; no point-magnetic-dipole substitution.

For homogeneous scalar background, a closed uniform impressed current is divergence free. With `q=sqrt(i*omega*mu_p*zeta_p)` chosen Re(q)>=0 (outgoing continuation for exp(+i*omega*t)),

```
E_p(x) = -i*omega*mu_p*N_t*I/(4*pi)
         integral_loop exp(-q*|x-r|)/|x-r| dl.
```

This is L5's finite-frequency Green representation extended by rigid pose; scalar-potential contributions cancel for the ideal closed loop in a uniform background. It is not valid for an open wire, spatially varying primary material, arbitrary lumped feed/charge, or a finite-thickness winding without an appropriate source model.

Sample edge **averages**, not midpoint values. For fixed-mu S1 evaluate primary only on the support of `M_e(delta_zeta)` and at independent oracle volume points; irrelevant entries may be stored as zero with an explicit support mask. No evaluation is required on the impressed wire. Receiver/source/contrast separation must be computed geometrically before integration. Reject a wire intersecting the contrast closure or any evaluated edge/path, zero distance, unresolved near-singular quadrature, or a nonzero delta-mu stencil touching the wire. Do not replace singular values with zero, epsilon, NaN cleanup, or a mesh-dependent exclusion. Extending contrast to the wire requires a selected finite-conductor cross-section/source treatment and its own integration/convergence evidence. An artificial background tube is allowed only as an explicitly chosen physical-model approximation, never as invisible removal of real material.

Receiver r measures `V_r=N_r integral_closed_circle E dot dl = -i*omega*N_r integral_disk B dot n dS` [V], with matching path/normal orientation. For the mesh field use a reusable true-circle trace functional: split its parameter interval at crossings of all mesh planes, integrate the compatible rectangular edge basis along each arc, and retain all Ex/Ey/Ez contributions. Record 8/16-point arc quadrature change for this **new pose**. Do not retain the old horizontal-disk z-only functional after tilting a receiver.

## Independent reference that is actually available

For S1, background permeability is fixed. The continuum equivalent current derivative is `J_c_dot(x)=delta_zeta(x)*E_p(x)` [A/m²]. For each contrast volume quadrature point with weight dV, form the complex current moment `m=J_c_dot*dV` [A m]. Use three Geoana `ElectricDipoleWholeSpace.magnetic_field` unit-axis responses with `current=1`, `length=1`, selected background sigma/mu/epsilon and `quasistatic=False`; multiply each real unit response externally by its complex component m_j and sum. Do not pass complex current through a float setter.

Compute `V_dot_Born=-i*omega*mu_p*N_r integral_disk H_dot_Born dot n dS`, using an independent oriented polar-disk quadrature. This requires neither C, material masses, `A`, its factorization nor the mesh receiver weights. It is the **exact first derivative at tau=0** of the infinite homogeneous-background problem with a compact perturbation; the word Born does not make it an exact finite-tau oracle. It shares the physical Green model and primary formula, so document this remaining common assumption rather than claiming complete model independence.

For a new-pose homogeneous primary control, integrate current-dipole H along the finite transmitter loop and disk flux at each receiver, and compare with primary E integrated along the receiver circumference. This cross-representation check covers orientation/Faraday sign and the selected Geoana H branch. It does not rerun the old coaxial reference. Never use the excluded Geoana E branch, reuse `q_s` as the oracle current, or turn a derivative result into a strong-contrast full 3D certificate.

## Proposed S1 input and bounded execution contract

Freeze these as a proposed benchmark, not task-book material measurements:

* f=2 MHz; sigma_p=0.0005 S/m; epsilon_p=1.77083756256e-10 F/m; mu_p=1.2566370614359173e-6 H/m, matching the fixed L5 background.
* Tx: c=(0,0,-0.25)m, radius .05m, I=1A, turns=1, n=(0,1,4)/sqrt(17). Rx1: c=(.025,-.0125,.05)m; Rx2: c=(-.0125,.025,.25)m; each radius .02m, turns=1, n=(1,2,3)/sqrt(14). For each n choose u=normalize((1,0,0)-n*n_x), v=n cross u.
* Compact box D=[.025,.05] x [.025,.05] x [-.05,.025]m, aligned with L5 cell faces. `sigma(tau)=sigma_p*(1+tau*1_D)`, `epsilon(tau)=epsilon_p*(1+tau*1_D)`, mu fixed. The derivative contrast is `(sigma_p+i*omega*epsilon_p)*1_D`. This is off-axis and genuinely 3D, but is only one restricted case on the path to arbitrary heterogeneous solids.
* Read pinned saved L5 mesh geometry, curl, A_II and interior ordering through its immutable manifest; no old assembly/source solve/old reference integration. Construct only the new contrast mass/RHS and receiver traces. Factor A_II once and solve one RHS. Preserve complete vectors, complex voltages, support/pose checks and held-process terminal evidence. If the input ordering is unavailable/ambiguous, stop before any solve.
* New-geometry primary line quadrature pair 128/256 points, edge Gauss 8/16; oracle box tensor Gauss 4 then 8; receiver radial/angular 8x64 then 16x128. These are fixed two-level observations, not adaptive automatic retries or mathematical error bounds. Chunk oracle receiver observations to <=2048 and at most 3 unit-current components; never allocate an all-edges x all-volume x all-Rx tensor.
* Proposed resource ceiling: one actual solve stage <=90s, <=4GiB/process and <=5GiB/job, <=4 processes, BLAS threads=1, using the reviewed held-handle guard; preflight >=10GiB available physical memory, matching L5. Separate new-controls/oracle stages <=60s each and <=512MiB/process, <=1GiB/job. Main may select a different explicitly frozen budget; none is selected or executed here. A cap/memory/terminal failure is preserved and stops, without rerun or mesh coarsening.

Only new controls: proper-pose/reversed-winding sign and receiver-voltage orientation; deliberate singular-support intersection rejection; compatible trace on a constant vector and a simple known-curl field; complex sigma/epsilon mass contrast linearity and sign; the selected Geoana H analytic expression and full-wave k branch; new-pose finite-coil E-line versus H-flux; provenance separation so the oracle cannot read C/A/mass/RHS or solved fields. Do not replay L5, the old source/reference tests or installed runtime tests.

## Gates, subsequent steps and limits

Freeze diagnostic comparisons before implementation. Suggested S1 screening gates, explicitly **new engineering screens, not existing formal acceptance**: (a) algebraic backward eta <=128*float64 epsilon, reported only as solve stability; (b) for each nonzero complex oracle voltage, each new quadrature-pair change <=0.1% of its fine value; (c) mesh derivative vs fine infinite-space oracle <=1% complex relative discrepancy. Record absolute voltage errors as well. If the oracle is zero/near cancellation so relative error is unstable, report its absolute values and leave the relative screen undefined; do not insert a favorable denominator floor. Both receivers must pass. A failure distinguishes evidence to investigate, not permission for automatic reruns.

These observational gates do not certify unresolved boundary, mesh or model error. In particular a two-level agreement can alias common bias. No order of convergence, Richardson estimate, global bound, universal finite-mesh certificate or accuracy from residual eta alone is claimed.

The physically meaningful noise gate remains **unqualified**: no task-specific complex receiver noise/covariance, calibration uncertainty, bandwidth, drive stability and minimum discrimination signal were supplied by this design task. Main must freeze `E_budget,r=min(E_noise_budget,r, E_task_budget,r)` from those sources and require independently assessed absolute forward-model error <=E_budget,r for the same frequency/pose/material/receiver observable; any safety factor/allocation must be selected and sourced, not inferred from numerical precision. Unknown budgets cannot pass. The homogeneous carrier voltage must not hide secondary/differential error by normalizing everything to total primary magnitude. Noise is applied after noiseless causal measurement, with provenance; it is not a substitute for physical discretization accuracy.

After S1 evidence, main chooses: separate domain/padding vs local-mesh tests if needed; then a **new** finite-tau heterogeneous solve with the full A_m and observed tau-halving departure from the derivative; then high/anisotropic sigma, epsilon and mu contrasts, realistic interfaces and feed/finite-wire models as actually required. A separate 3D solver/reference or carefully qualified limiting cases/measurements are still required for strong heterogeneous cases. Reciprocity, power/passivity, manufactured fields and a second formulation provide additional checks but do not become an independent full-case oracle by themselves.

The eventual forward-model interface must accept full 3D material geometry and arbitrary rigid coil poses, compute sensor observables causally with units and provenance, keep hidden truth away from AI input, and preserve the game-level 3D/volume-collision/live-editing/PC-direct and PC-AI–FPGA control requirements. S1's box and two finite coils are a numerical benchmark only. Product sensing, noise qualification, C's CNN bundle and all formal H01–H15 acceptance remain outside this design result.
