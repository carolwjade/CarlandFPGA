"""Read-only source evidence sealing. No scientific imports or numerical execution."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
SP = ROOT / '.local/deepeye-fdem-validation-20261020/Lib/site-packages'
PIN = 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'

def read(p):
    return json.loads(p.read_text(encoding='utf-8'))

def save(name, value):
    with (D / name).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.write('\n')

def info(p):
    raw = p.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

assignment = read(D / 'assignment.json')
assert assignment['owner'] == '/root/r02_amd_acquisition_20261021'
assert assignment['work_id'] == 'A-G03-SECONDARY-FIELD-DESIGN-20261021-v1'
scope = read(ROOT / 'docs/competition/deepeye-2026/immutable_scope.json')
canon = json.dumps(scope['requirements'], sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
assert hashlib.sha256(canon).hexdigest() == PIN == assignment['requirements_sha256']
transfer = read(ROOT / '.planning/deepeye-desktop-handoff-20261015/transfer.json')
assert transfer['status'] == 'active' and transfer['director_generation'] == 2
assert transfer['new_director_thread_id'] == assignment['director_thread_id'] == '01a13d7e-dcf1-7272-a738-a637dd62ff9d'

inputs = [
    ROOT / 'AGENTS.md',
    ROOT / '.agents/skills/fpga-multi-node/SKILL.md',
    ROOT / '.agents/skills/fpga-multi-node/references/protocol.md',
    ROOT / 'docs/competition/deepeye-2026/immutable_scope.md',
    ROOT / 'docs/competition/deepeye-2026/immutable_scope.json',
    ROOT / '.planning/deepeye-desktop-handoff-20261015/transfer.json',
    D / 'assignment.json', D / 'reserve-request.json',
]
for folder, names in {
    'g03-l5-propagation-z-refinement-20261021': ['grid_model.py', 'grid_worker.py', 'run_grid.py', 'report.md', 'public-manifest.json'],
    'g03-l5-main-review-20261021': ['review.json'],
    'g03-l4-receiver-error-decomposition-20261021': ['report.md', 'public-manifest.json'],
}.items():
    inputs.extend(D.parent / folder / n for n in names)
sources = {
    'simpeg/electromagnetics/frequency_domain/simulation.py': [(23, 84), (141, 176), (614, 653), (806, 844)],
    'simpeg/electromagnetics/frequency_domain/sources.py': [(1, 6), (308, 385), (758, 802), (890, 929), (1152, 1184), (1227, 1264), (1378, 1413)],
    'simpeg/electromagnetics/utils/current_utils.py': [(119, 150)],
    'discretize/operators/inner_products.py': [(147, 219), (221, 244)],
    'discretize/base/base_tensor_mesh.py': [(792, 879)],
    'geoana/em/fdem/wholespace.py': [(12, 22), (106, 124), (196, 216), (294, 320), (373, 390)],
    'geoana/em/fdem/base.py': [(42, 83), (180, 201), (245, 270)],
    'geoana/em/base.py': [],
}
evidence = {}
for relative, ranges in sources.items():
    p = SP / relative
    inputs.append(p)
    lines = p.read_text(encoding='utf-8').splitlines()
    evidence[relative] = {'path': p.relative_to(ROOT).as_posix(), 'ranges': [
        {'start_line': lo, 'end_line': hi, 'text': '\n'.join(lines[lo-1:hi])} for lo, hi in ranges
    ]}
versions = {}
for name, version in [('simpeg', '0.25.2'), ('discretize', '0.12.0'), ('geoana', '0.8.1')]:
    p = SP / f'{name}-{version}.dist-info/METADATA'
    inputs.append(p)
    text = p.read_text(encoding='utf-8')
    assert f'Name: {name}\n' in text and f'Version: {version}\n' in text
    versions[name] = version
assert not any(SP.glob('empymod-*.dist-info'))
pins = {p.relative_to(ROOT).as_posix(): info(p) for p in inputs}
prior = read(D.parent / 'g03-l5-propagation-z-refinement-20261021/public-manifest.json')
for name in ('grid_model.py', 'grid_worker.py', 'run_grid.py', 'report.md'):
    p = D.parent / 'g03-l5-propagation-z-refinement-20261021' / name
    assert pins[p.relative_to(ROOT).as_posix()] == prior['files'][name]

save('source-pins.json', {'requirements_sha256': PIN, 'versions_read_without_import': versions, 'files': pins})
save('source-evidence.json', {'note': 'Quoted installed source lines, read only; no package import.', 'sources': evidence})
save('report.json', {
    'work_id': assignment['work_id'], 'owner': assignment['owner'],
    'utc': datetime.now(timezone.utc).isoformat(), 'status': 'design_complete_pending_main_selection',
    'requirements_sha256': PIN, 'director_generation': 2,
    'recommendation': 'S1: one new nonzero off-axis 3D admittivity-contrast derivative solve, independent installed Geoana H/volume/flux reference',
    'scientific_imports': 0, 'solver_runs': 0, 'matrix_assemblies': 0, 'factorizations': 0,
    'reference_evaluations': 0, 'old_tests_repeated': False, 'other_worker_mutable_directory_access': False,
    'product_writes': 0, 'installations': 0, 'GPU_tensor_or_kernel_calls': 0,
    'physical_accuracy': 'unqualified', 'new_numerical_validation': 'not_run',
    'G03': 'not_run', 'all29_formal': 'not_run',
    'noise_gate': 'unqualified_missing_sourced_noise_and_task_voltage_error_budget',
    'limitations': [
        'No guarantee of primary-secondary accuracy or speedup at a fixed mesh.',
        'Physical contrast and residual-corrected algebraic total-field split must remain distinct.',
        'Installed Geoana electric_field excluded: sigma denominator differs from full-wave docstring.',
        'Independent installed magnetic_field supports first derivative, not strong arbitrary 3D heterogeneity.',
        'Zero secondary boundary is a domain approximation, not exact radiation.',
        'Finite wire/source-overlap treatment, stronger/anisotropic materials and independent full-case reference remain open.',
    ],
    'primary_urls': [
        'https://docs.simpeg.xyz/latest/content/api/generated/simpeg.electromagnetics.frequency_domain.sources.PrimSecSigma.html',
        'https://github.com/simpeg/simpeg/blob/v0.25.2/simpeg/electromagnetics/frequency_domain/simulation.py',
        'https://discretize.simpeg.xyz/en/v0.12.0/api/generated/discretize.TensorMesh.get_edge_inner_product.html',
        'https://raw.githubusercontent.com/simpeg/geoana/v0.8.1/geoana/em/fdem/wholespace.py',
    ],
})

final = '''A-G03-SECONDARY-FIELD-DESIGN-20261021-v1 completed as design only. Fixed L5 remains physically unqualified (11.1375219287% / 9.2099414169% reference errors). Proposed next bounded experiment S1 uses one new nonzero off-axis 3D conductivity/permittivity contrast derivative RHS and an independent installed Geoana H-field volume/receiver-flux reference. design.md defines +i omega t signs, curl-curl/mass/contrast equations, physical versus residual-corrected split, arbitrary finite-coil pose, singular-support exclusions, approximate boundary, diagnostic and missing noise gates, and finite-strength continuation limits. Exact installed SimPEG0.25.2/discretize0.12.0/Geoana0.8.1 source pins are sealed. Existing PrimSecSigma/CircularLoop are not drop-in full-wave replacements; Geoana electric_field's sigma-only denominator excludes that branch from the oracle. No scientific import, solver, factorization, reference integration, old test, installation, product/runtime/board/UI/service action or other worker mutable-directory read occurred. Main selects implementation; new numerical validation, G03 and all29 formal remain not_run. H01-H15 requirements SHA c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 and active generation2 preserved. Artifacts: design.md, source-pins.json, source-evidence.json, report.json, manifest.json in .planning/deepeye-resume-20261018/g03-secondary-field-design-20261021/.'''
with (D / 'final-result.txt').open('x', encoding='utf-8', newline='\n') as f:
    f.write(final + '\n')
names = ['assignment.json', 'reserve-request.json', 'design.md', 'source-pins.json', 'source-evidence.json', 'report.json', 'seal_design.py', 'final-result.txt', 'native-validation.json']
manifest = {'work_id': assignment['work_id'], 'status': 'design_only', 'requirements_sha256': PIN,
            'excluded': 'Private lease/reserve stderr and later actual native-complete response; no credentials in public manifest.',
            'files': {n: info(D / n) for n in names}}
save('manifest.json', manifest)
# Verify only generated evidence serialization and source-byte binding; not numerical tests.
for n in ('source-pins.json', 'source-evidence.json', 'report.json', 'manifest.json'):
    read(D / n)
assert all(info(ROOT / p) == v for p, v in pins.items())
print(json.dumps({'status': 'design_sealed', 'source_file_count': len(pins), 'files': {n: info(D/n) for n in ('design.md','source-pins.json','source-evidence.json','report.json','manifest.json','final-result.txt')}}))
