"""Fixed L4 compatible disk and homogeneous boundary geometry.

Edge values are tangential E averages (V/m); face values are normal curl
averages (V/m^2). The forward disk functional is W @ C @ E in volts.
"""
import cmath
import math
import numpy as np

GATE = 128*np.finfo(float).eps
X_BASE = np.array([-.6,-.15,-.05,-.0375,-.025,-.0125,0.,.0125,.025,.0375,.05,.15,.6])
X = np.array([value for left,right in zip(X_BASE[:-1],X_BASE[1:])
              for value in (left,(left+right)/2)] + [X_BASE[-1]])
Z_BASE = np.array([-.85,-.4,-.3,-.275,-.25,-.225,-.2,-.05,.025,.05,.075,.225,.25,.275,.35])
Z = np.array([value for left,right in zip(Z_BASE[:-1],Z_BASE[1:])
              for value in (left,(left+right)/2)] + [Z_BASE[-1]])
CENTERS = (-.25,.05,.25)
RADII = (.05,.02,.02)
FREQ = 2e6
SIGMA = .0005
EPSILON = 1.77083756256e-10
MU = 1.2566370614359173e-6

def mesh_new():
    from discretize import TensorMesh
    mesh=TensorMesh([np.diff(X),np.diff(X),np.diff(Z)],origin=[X[0],X[0],Z[0]])
    assert (mesh.n_cells,mesh.n_edges,mesh.n_faces)==(16128,52300,50304)
    for actual,nominal in zip((mesh.nodes_x,mesh.nodes_y,mesh.nodes_z),(X,X,Z)):
        assert np.max(abs(actual-nominal)) <= 64*np.finfo(float).eps*1.2
    return mesh

def plane_basis(nodes,nominal):
    """Locate nominal plane; use ordinary linear basis across actual nodes."""
    nodes=np.asarray(nodes)
    nearest=int(np.argmin(abs(nodes-nominal)))
    tolerance=64*np.finfo(float).eps*max(1.,abs(nominal),abs(nodes[-1]-nodes[0]))
    if abs(nodes[nearest]-nominal)>tolerance:
        raise ValueError('nominal plane is not a roundoff-close mesh node')
    if nominal==nodes[nearest]:return [(nearest,1.)]
    k=int(np.searchsorted(nodes,nominal,side='right')-1)
    if k<0 or k>=len(nodes)-1:raise ValueError('plane outside grid')
    t=(nominal-nodes[k])/(nodes[k+1]-nodes[k])
    return [(k,1.-t),(k+1,t)]

def circular_tail(v,r):
    """Integral_v^r sqrt(r²-x²) dx using a stable circular-segment angle."""
    if not 0<=v<=r:raise ValueError('tail endpoint outside first quadrant')
    theta=math.atan2(math.sqrt((r-v)*(r+v)),v)
    if theta<.001:
        t2=theta*theta
        segment=theta*t2*(2/3+t2*(-2/15+t2*(4/315-t2*2/2835)))
    else:
        segment=theta-math.sin(theta)*math.cos(theta)
    return .5*r*r*segment

def positive_rectangle(a,b,c,d,r):
    """First-quadrant rectangle area, split at both circle/strip intersections."""
    if not (0<=a<=b and 0<=c<=d):raise ValueError('positive rectangle order')
    # Integrate along the coordinate nearest the circle endpoint. This avoids
    # subtracting two quarter-disk antiderivatives for a tiny cap at y ~= r.
    if c>a:a,b,c,d=c,d,a,b
    a=max(0.,min(a,r));b=max(0.,min(b,r))
    c=max(0.,min(c,r));d=max(0.,min(d,r))
    if a==b or c==d:return 0.
    full_end=math.sqrt((r-d)*(r+d))
    partial_end=math.sqrt((r-c)*(r+c))
    full=max(0.,min(b,full_end)-a)*(d-c)
    lo=max(a,full_end);hi=min(b,partial_end)
    partial=0. if hi<=lo else circular_tail(lo,r)-circular_tail(hi,r)-c*(hi-lo)
    area=full+partial
    if area<0:raise ArithmeticError('negative first-quadrant disk area')
    return area

def rectangle_disk(x0,x1,y0,y1,r):
    """Exact-area geometry without subtraction of nearly equal quadrants."""
    if not x0<x1 or not y0<y1:raise ValueError('rectangle order')
    def parts(lo,hi):
        p=[]
        if lo<0:p.append((abs(min(hi,0.)),abs(lo)))
        if hi>0:p.append((max(lo,0.),hi))
        return p
    return sum(positive_rectangle(a,b,c,d,r)
               for a,b in parts(x0,x1) for c,d in parts(y0,y1))

def disks(mesh):
    nx,ny,nz=mesh.shape_cells
    rows=np.zeros((3,mesh.n_faces),dtype=float)
    fz0=math.prod(mesh.shape_faces_x)+math.prod(mesh.shape_faces_y)
    areas=np.zeros((3,nx,ny))
    for d,(z,r) in enumerate(zip(CENTERS,RADII)):
        for i in range(nx):
            for j in range(ny):
                a=rectangle_disk(mesh.nodes_x[i],mesh.nodes_x[i+1],mesh.nodes_y[j],mesh.nodes_y[j+1],r)
                areas[d,i,j]=a
                for k,hat in plane_basis(mesh.nodes_z,z):
                    rows[d,fz0+np.ravel_multi_index((i,j,k),mesh.shape_faces_z,order='F')]+=a*hat
        if abs(rows[d].sum()-math.pi*r*r)>GATE*math.pi*r*r:
            raise ArithmeticError('disk area total')
        if np.any(rows[d]<0) or not np.any(rows[d]>0):raise ArithmeticError('disk weight positivity')
    return rows,areas

def z_curl_transpose(mesh,w):
    """Matrix-free transpose curl on the selected z faces; 4 oriented edges."""
    nx,ny,nz=mesh.shape_cells
    fz0=math.prod(mesh.shape_faces_x)+math.prod(mesh.shape_faces_y)
    ey0=math.prod(mesh.shape_edges_x)
    sx,sy=mesh.shape_edges_x,mesh.shape_edges_y
    out=np.zeros(mesh.n_edges,dtype=float)
    for k in range(nz+1):
        for j in range(ny):
            for i in range(nx):
                a=w[fz0+np.ravel_multi_index((i,j,k),mesh.shape_faces_z,order='F')]
                if a==0:continue
                hx=mesh.h[0][i];hy=mesh.h[1][j]
                def ex(ii,jj):return np.ravel_multi_index((ii,jj,k),sx,order='F')
                def ey(ii,jj):return ey0+np.ravel_multi_index((ii,jj,k),sy,order='F')
                out[ex(i,j)]+=a/hy;out[ey(i+1,j)]+=a/hx
                out[ex(i,j+1)]-=a/hy;out[ey(i,j)]-=a/hx
    return out

def edges(mesh):
    starts=np.empty((mesh.n_edges,3));ends=np.empty_like(starts)
    nodes=(mesh.nodes_x,mesh.nodes_y,mesh.nodes_z)
    offset=0
    for axis,shape in enumerate((mesh.shape_edges_x,mesh.shape_edges_y,mesh.shape_edges_z)):
        count=math.prod(shape)
        sub=np.unravel_index(np.arange(count),shape,order='F')
        for d in range(3):
            starts[offset:offset+count,d]=nodes[d][sub[d]]
            ends[offset:offset+count,d]=nodes[d][sub[d]+(d==axis)]
        offset+=count
    return starts,ends

def line_oracle(mesh,z,r,order=24):
    """Independent piecewise bilinear edge traces around a segmented circle."""
    angles=[0.,2*math.pi]
    for dim,axis in enumerate((mesh.nodes_x,mesh.nodes_y)):
        for v in axis:
            if -r<v<r:
                if dim==0:
                    t=math.acos(v/r);angles.extend((t,2*math.pi-t))
                else:
                    t=math.asin(v/r);angles.extend((t%(2*math.pi),(math.pi-t)%(2*math.pi)))
    angles=sorted(angles)
    breaks=[]
    for t in angles:
        if not breaks or t-breaks[-1]>1e-12:breaks.append(t)
    q,weight=np.polynomial.legendre.leggauss(order)
    nx,ny,nz=mesh.shape_cells;sx,sy=mesh.shape_edges_x,mesh.shape_edges_y
    ey0=math.prod(sx);out=np.zeros(mesh.n_edges)
    for a,b in zip(breaks[:-1],breaks[1:]):
        theta=(a+b)/2+(b-a)*q/2;dw=weight*(b-a)/2
        for t,wt in zip(theta,dw):
            x,y=r*math.cos(t),r*math.sin(t)
            i=int(np.clip(np.searchsorted(mesh.nodes_x,x,side='right')-1,0,nx-1))
            j=int(np.clip(np.searchsorted(mesh.nodes_y,y,side='right')-1,0,ny-1))
            tx=(x-mesh.nodes_x[i])/mesh.h[0][i];ty=(y-mesh.nodes_y[j])/mesh.h[1][j]
            dx=-r*math.sin(t);dy=r*math.cos(t)
            for k,hz in plane_basis(mesh.nodes_z,z):
                for side in (0,1):
                    ex=np.ravel_multi_index((i,j+side,k),sx,order='F')
                    ey=ey0+np.ravel_multi_index((i+side,j,k),sy,order='F')
                    out[ex]+=wt*dx*((1-ty) if side==0 else ty)*hz
                    out[ey]+=wt*dy*((1-tx) if side==0 else tx)*hz
    return out

def green_boundary(starts,ends,order_tx,order_edge):
    """Fixed source-circle midpoint and edge-Gauss quadrature, bounded chunks."""
    omega=2*math.pi*FREQ
    q=cmath.sqrt(1j*omega*MU*(SIGMA+1j*omega*EPSILON))
    angle=(np.arange(order_tx)+.5)*(2*math.pi/order_tx)
    src=np.column_stack((.05*np.cos(angle),.05*np.sin(angle),np.full(order_tx,-.25)))
    dl=np.column_stack((-.05*np.sin(angle),.05*np.cos(angle),np.zeros(order_tx)))*(2*math.pi/order_tx)
    gauss,gw=np.polynomial.legendre.leggauss(order_edge)
    t=(gauss+1)/2;gw=gw/2
    result=np.empty(len(starts),dtype=complex)
    factor=-1j*omega*MU/(4*math.pi)
    for first in range(0,len(starts),16):
        last=min(first+16,len(starts))
        delta=ends[first:last]-starts[first:last]
        tangent=delta/np.linalg.norm(delta,axis=1)[:,None]
        p=starts[first:last,None,:]+t[None,:,None]*delta[:,None,:]
        R=np.linalg.norm(p.reshape(-1,3)[:,None,:]-src[None,:,:],axis=2)
        if np.any(R<=0):raise ArithmeticError('singular boundary Green sample')
        A=(np.exp(-q*R)/R)@dl
        E=factor*A.reshape(last-first,order_edge,3)
        result[first:last]=np.einsum('ijk,ik,j->i',E,tangent,gw)
    if not np.all(np.isfinite(result)):raise ArithmeticError('nonfinite boundary')
    return result
