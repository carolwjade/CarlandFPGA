"""One bounded new receiver-local quadrature pair from frozen L4 evidence."""
import hashlib,json,os,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
L4=D.parent/'g03-l4-global-refinement-20261021'
ORDER=D.parent/'g03-l4-ordering-repair-20261021'
SOLVED=D.parent/'g03-l4-saved-operator-solve-20261021'
SUPPORT=D.parent/'r02-amd-wheel-acquisition-20261021'
REF=D.parent/'g03-source-voltage-20261021/run-01/V_reference128_V.npy'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def publish_grant(stage,v):
    pending=stage/'grant.pending.json';save(pending,v);os.replace(pending,stage/'grant.json')
def pins():
    a=read(D/'assignment.json');t=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
    assert a['owner']=='/root/g03_grid_continuation_20261021'
    assert a['work_id']=='A-G03-L4-RECEIVER-ERROR-DECOMPOSITION-20261021-v1'
    assert a['selected_by']==t['new_director_thread_id'] and t['director_generation']==2 and t['status']=='active'
    assert sha(D/'design-plan.md')==a['design_sha256']
    scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
    digest=hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
    assert digest==a['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    assert sha(SOLVED/'public-manifest.json')==a['previous_manifest_sha256']
    solved=read(SOLVED/'public-manifest.json')
    assert read(D.parent/'g03-l4-saved-main-review-20261021/review.json')['status']=='ACCEPT_NEW_L4_SAVED_OPERATOR_NUMERICAL_RESULT_ONLY'
    for n in ('E_Vpm.npy','V_compatible_V.npy','result.json','terminal.json'):
        p=SOLVED/'run-01'/n
        assert sha(p)==solved['files']['run-01/'+n]['sha256']
    l4=read(L4/'public-manifest.json')
    assert sha(D/'source-snapshot-l4/grid_model.py')==l4['files']['grid_model.py']['sha256']
    for n in ('W_faces_m2.npy','edge_starts_m.npy','edge_ends_m.npy','boundary_indices.npy'):
        p=L4/'controls-01'/n
        assert sha(p)==l4['files']['controls-01/'+n]['sha256']
    ordering=read(ORDER/'public-manifest.json')
    assert sha(ORDER/'run-01/C-csr.npz')==ordering['files']['run-01/C-csr.npz']['sha256']
    assert sha(REF)=='fd68cfa481e92251fd14616f0ca177f312db89904557c8c44fd9219fd1df1889'
    sources=[D/n for n in ('assignment.json','design-plan.md','rx_worker.py','run_rx.py')]
    sources += [D/'source-snapshot-l4/grid_model.py',SOLVED/'public-manifest.json',
        L4/'public-manifest.json',ORDER/'public-manifest.json',ORDER/'run-01/C-csr.npz',
        D.parent/'g03-l4-saved-main-review-20261021/review.json',REF,
        ROOT/'docs/competition/deepeye-2026/immutable_scope.json',
        ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json']
    sources += [SOLVED/'run-01'/n for n in ('E_Vpm.npy','V_compatible_V.npy','result.json','terminal.json')]
    sources += [L4/'controls-01'/n for n in
        ('W_faces_m2.npy','edge_starts_m.npy','edge_ends_m.npy','boundary_indices.npy')]
    sources += [SUPPORT/n for n in ('win_job.py','boundary.py')]
    return {p.relative_to(ROOT).as_posix():sha(p) for p in sources}
def main():
    assert sys.argv[1:]==['analytic']
    before=pins();save(D/'input-pins.json',before)
    sys.path.insert(0,str(SUPPORT))
    from win_job import run_bounded,process_identity
    stage=D/'run-01';granted=False
    env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'WINDIR':os.environ.get('WINDIR',os.environ['SYSTEMROOT']),
        'PATH':'','TEMP':str(D),'TMP':str(D),'TMPDIR':str(D),'PYTHONDONTWRITEBYTECODE':'1',
        'PYTHONNOUSERSITE':'1','PYTHONIOENCODING':'utf-8',
        **{k:'1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS',
            'NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','VECLIB_MAXIMUM_THREADS')}}
    budget={'seconds':40,'active_processes':4,'process_memory_bytes':1024**3,
        'job_memory_bytes':1536*1024**2,'stdout_bytes':128*1024,'stderr_bytes':128*1024,
        'tree_bytes':32*1024**2,'tree_entries':1024,'free_reserve_bytes':512*1024**2,
        'components':[{'path':str(stage),'bytes':32*1024**2,'entries':1024}]}
    def tick(job,pids):
        nonlocal granted
        if (stage/'hello.json').exists() and not granted:
            hello=read(stage/'hello.json');assert hello['pid'] in pids and hello['mode']=='analytic'
            publish_grant(stage,{'worker':process_identity(hello['pid'],job),'mode':'analytic',
                'scientific_import_allowed':True,'source_pins':before})
            granted=True
    result=run_bounded([str(ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe'),
        '-I','-B','-X','utf8',str(D/'rx_worker.py'),str(stage),'analytic'],
        env,D,stage,budget,[D],on_tick=tick)
    after=pins();save(stage/'input-readback.json',{'unchanged':before==after,'before':before,'after':after})
    assert result['all_processes_terminated'] and before==after
    print(json.dumps({k:result.get(k) for k in
        ('status','exit_code','seconds','stop_reason','all_processes_terminated','held_members')}))
    raise SystemExit(result['exit_code'] if result['exit_code'] is not None else 125)
if __name__=='__main__':main()
