"""One local receiver-support diagnostic from frozen L4 arrays."""
import hashlib,json,math,os,sys,time
from pathlib import Path
D=Path(__file__).resolve().parent
L4=D.parent/'g03-l4-global-refinement-20261021'
ORDER=D.parent/'g03-l4-ordering-repair-20261021'
SOLVED=D.parent/'g03-l4-saved-operator-solve-20261021'
stage=Path(sys.argv[1]);mode=sys.argv[2]
def save_json(path,value):
    with path.open('x',encoding='utf-8') as f:
        json.dump(value,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def save_array(path,value):
    with path.open('xb') as f:
        import numpy as np
        np.save(f,value,allow_pickle=False)
def pairs(values):
    return [[float(complex(v).real),float(complex(v).imag)] for v in values]
save_json(stage/'hello.json',{'pid':os.getpid(),'before_scientific_import':True,'mode':mode})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('no science grant')
    time.sleep(.01)
grant=json.loads((stage/'grant.json').read_text(encoding='utf-8'))
assert mode=='analytic' and grant['worker']['pid']==os.getpid() and grant['mode']==mode
import ctypes as ct
import numpy as np
import scipy.linalg
from scipy.sparse import csr_matrix
sys.path.insert(0,str(D/'source-snapshot-l4'))
import grid_model as m
def threads():
    k=ct.WinDLL('kernel32',use_last_error=True)
    k.GetModuleHandleW.argtypes=[ct.c_wchar_p];k.GetModuleHandleW.restype=ct.c_void_p
    site=Path(np.__file__).resolve().parents[1];rows=[]
    for folder,symbol in (('numpy.libs','scipy_openblas_get_num_threads64_'),
                          ('scipy.libs','scipy_openblas_get_num_threads')):
        paths=list((site/folder).glob('*openblas*.dll'));assert len(paths)==1
        handle=k.GetModuleHandleW(str(paths[0]));assert handle
        getter=getattr(ct.CDLL(str(paths[0]),handle=handle),symbol)
        getter.argtypes=[];getter.restype=ct.c_int
        count=getter();assert count==1
        rows.append({'path':str(paths[0]),
                     'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),
                     'num_threads':count})
    return rows
def load_saved_c():
    path=ORDER/'run-01/C-csr.npz'
    with np.load(path,allow_pickle=False) as z:
        shape=tuple(int(v) for v in z['shape'])
        C=csr_matrix((z['data'],z['indices'],z['indptr']),shape=shape,copy=False)
    if C.shape!=(50304,52300) or C.nnz!=201216 or not np.all(np.isfinite(C.data)):
        raise ValueError('frozen C identity')
    return C
started=time.monotonic();before=threads();error=None
counts={'C_constructions':0,'A_assemblies':0,'factorizations':0,'reference_evaluations':0,
        'new_receiver_support_quadrature_pairs':0}
try:
    C=load_saved_c()
    control=L4/'controls-01'
    W=np.load(control/'W_faces_m2.npy',allow_pickle=False)
    starts=np.load(control/'edge_starts_m.npy',allow_pickle=False)
    ends=np.load(control/'edge_ends_m.npy',allow_pickle=False)
    B=np.load(control/'boundary_indices.npy',allow_pickle=False)
    E=np.load(SOLVED/'run-01/E_Vpm.npy',allow_pickle=False)
    V_saved=np.load(SOLVED/'run-01/V_compatible_V.npy',allow_pickle=False)
    ref=np.load(D.parent/'g03-source-voltage-20261021/run-01/V_reference128_V.npy',allow_pickle=False)
    if W.shape!=(3,50304) or starts.shape!=(52300,3) or ends.shape!=(52300,3):
        raise ValueError('frozen geometry shapes')
    if E.shape!=(52300,) or V_saved.shape!=(2,) or ref.shape!=(2,):
        raise ValueError('saved field/voltage shapes')
    if not all(np.all(np.isfinite(v)) for v in (W,starts,ends,E,V_saved,ref)):
        raise ArithmeticError('nonfinite saved inputs')
    r=np.vstack([np.asarray(C.T@W[d]).ravel() for d in (1,2)])
    if r.shape!=(2,52300) or not np.all(np.isfinite(r)):
        raise ArithmeticError('receiver coefficient shape or finite values')
    support=np.flatnonzero(np.any(r!=0,axis=0))
    if len(support)==0 or np.intersect1d(support,B).size:
        raise ValueError('receiver support absent or on old prescribed boundary')
    rs=r[:,support];es=E[support]
    zlo=np.minimum(starts[support,2],ends[support,2])
    zhi=np.maximum(starts[support,2],ends[support,2])
    tx_z=-.25
    dz=np.where(tx_z<zlo,zlo-tx_z,np.where(tx_z>zhi,tx_z-zhi,0.))
    min_dz=float(np.min(dz))
    if not min_dz>0:raise ValueError('receiver support intersects source plane')
    low=m.green_boundary(starts[support],ends[support],64,8)
    high=m.green_boundary(starts[support],ends[support],128,16)
    counts['new_receiver_support_quadrature_pairs']=1
    pair_gap=float(np.max(abs(high-low)))
    fixed_gate=1.967577343353139e-12
    if pair_gap>fixed_gate:raise ArithmeticError('unchanged Green pair consistency gate')
    V_numeric=rs@es
    V_low=rs@low;V_high=rs@high
    gate=128*np.finfo(float).eps
    numeric_bound=gate*(np.sum(abs(rs*es[None,:]),axis=1)+abs(V_saved))
    numeric_gap=abs(V_numeric-V_saved)
    if np.any(numeric_gap>numeric_bound):
        raise ArithmeticError('transposed receiver functional roundoff bound')
    field_component=V_saved-V_high
    functional_component=V_high-ref
    total=V_saved-ref
    closure=abs(field_component+functional_component-total)
    closure_bound=gate*(abs(V_saved)+abs(V_high)+abs(ref))
    if np.any(closure>closure_bound):
        raise ArithmeticError('receiver decomposition roundoff bound')
    sensitivity=abs(V_high-V_low)
    sensitivity_bound=np.sum(abs(rs)*abs(high-low)[None,:],axis=1)
    if np.any(sensitivity>sensitivity_bound+gate*sensitivity_bound):
        raise ArithmeticError('low/high receiver sensitivity summation bound')
    for name,array in {'receiver_edge_coeff_m':r,'receiver_support_indices':support,
        'receiver_support_coeff_m':rs,'receiver_support_E_numeric_Vpm':es,
        'receiver_support_starts_m':starts[support],'receiver_support_ends_m':ends[support],
        'receiver_green_64x8_Vpm':low,'receiver_green_128x16_Vpm':high,
        'V_saved_V':V_saved,'V_reference128_V':ref,'V_numeric_from_rE_V':V_numeric,
        'V_green_low_V':V_low,'V_green_high_V':V_high,
        'field_component_V':field_component,'receiver_functional_component_V':functional_component,
        'total_difference_V':total}.items():
        save_array(stage/(name+'.npy'),array)
    result={'status':'receiver_support_decomposition_complete','counts':counts,
        'support_counts':[int(np.count_nonzero(r[d]!=0)) for d in range(2)],
        'support_union_count':len(support),'support_on_old_boundary':0,
        'minimum_z_separation_from_Tx_plane_m':min_dz,
        'new_receiver_pair_max_difference_Vpm':pair_gap,
        'unchanged_pair_gate_Vpm':fixed_gate,
        'V_numeric_from_rE_V':pairs(V_numeric),'V_saved_V':pairs(V_saved),
        'numeric_reconstruction_abs_gap_V':numeric_gap.tolist(),
        'numeric_reconstruction_roundoff_bound_V':numeric_bound.tolist(),
        'V_green_low_V':pairs(V_low),'V_green_high_V':pairs(V_high),
        'field_component_V':pairs(field_component),
        'receiver_functional_component_V':pairs(functional_component),
        'total_difference_V':pairs(total),
        'field_component_abs_V':abs(field_component).tolist(),
        'receiver_functional_component_abs_V':abs(functional_component).tolist(),
        'total_difference_abs_V':abs(total).tolist(),
        'decomposition_closure_abs_gap_V':closure.tolist(),
        'decomposition_roundoff_bound_V':closure_bound.tolist(),
        'observed_receiver_low_high_sensitivity_V':sensitivity.tolist(),
        'low_high_sensitivity_sumabs_bound_V':sensitivity_bound.tolist(),
        'qualification':'observed quadrature consistency and algebraic decomposition only; not a physical error certificate',
        'physical_acceptance':'open','G03':'not_run','R03':'not_run','all29':'not_run'}
    save_json(stage/'result.json',result)
except BaseException as exc:
    error={'type':type(exc).__name__,'message':str(exc)}
    raise
finally:
    save_json(stage/'execution.json',{'mode':mode,'pid':os.getpid(),
        'seconds':time.monotonic()-started,'counts':counts,
        'blas_before':before,'blas_after':threads(),'error':error})
