"""Review frozen L5 arrays without factorization, assembly or reference integration."""
import json, math, os, sys
from pathlib import Path
D=Path(__file__).resolve().parent
OUT=D.parent
S=OUT/'g03-l5-propagation-z-refinement-20261021/run-01'
A=OUT/'g03-l5-propagation-z-refinement-20261021/run-01'
C=OUT/'g03-l5-propagation-z-refinement-20261021/controls-01'

def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.startfile','socket.connect','socket.bind','socket.getaddrinfo'):
        raise RuntimeError('review forbids processes, network and UI')
    if event=='open' and not isinstance(args[0],int):
        mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writing and not Path(args[0]).resolve().is_relative_to(D):
            raise RuntimeError('unowned write')
sys.addaudithook(audit)
import numpy as np
from scipy.sparse import csr_matrix, csc_matrix

def load(p):return np.load(p,allow_pickle=False)
def matrix(p,cls):
    with load(p) as a:
        return cls((a['data'],a['indices'],a['indptr']),shape=tuple(a['shape']))

reported=json.loads((S/'result.json').read_text(encoding='utf-8'))
interior=load(C/'interior_indices.npy');boundary=load(C/'boundary_indices.npy')
g=load(C/'boundary_g_128x16_Vpm.npy');x=load(S/'interior_solution_Vpm.npy');field=load(S/'E_Vpm.npy')
assert np.array_equal(field[interior],x) and np.array_equal(field[boundary],g)
assert np.array_equal(np.sort(np.r_[interior,boundary]),np.arange(len(field)))
system=matrix(A/'AII-csc.npz',csc_matrix).tocsr()
rhs=load(A/'A_II_rhs.npy')
residual=system.dot(x)-rhs
gate=128*np.finfo(float).eps
scale=float(np.max(abs(system).sum(axis=1)))*float(np.max(abs(x)))+float(np.max(abs(rhs)))
eta=float(np.max(abs(residual)))/scale
assert math.isfinite(eta) and eta<=gate
# Different sparse traversal may round differently; retain the actual difference.
residual_difference=float(np.max(abs(residual-load(S/'AII_residual.npy'))))
component_bounds=gate*(abs(system).dot(abs(x))+abs(rhs))
assert np.all(abs(residual-load(S/'AII_residual.npy'))<=component_bounds)
curl=matrix(A/'C-csr.npz',csr_matrix)
weights=load(C/'W_faces_m2.npy')
voltages=[];voltage_bounds=[]
for row in weights[1:]:
    functional=curl.T.dot(row)
    voltages.append(functional.dot(field))
    voltage_bounds.append(gate*float(abs(functional).dot(abs(field))))
voltages=np.asarray(voltages)
stored=load(S/'V_compatible_V.npy')
assert np.all(np.isfinite(field)) and np.all(abs(voltages-stored)<=voltage_bounds)
reference=load(OUT/'g03-source-voltage-20261021/run-01/V_reference128_V.npy')
assert np.array_equal(reference,load(S/'V_reference128_V.npy'))
relative=abs(voltages-reference)/abs(reference)
assert all(math.isclose(float(a),b,rel_tol=gate,abs_tol=0) for a,b in zip(relative,reported['relative_difference']))
result={'status':'ACCEPT_NEW_L5_NUMERICAL_RESULT_ONLY',
    'independent_residual_eta':eta,'fixed_gate':gate,'residual_traversal_max_difference':residual_difference,
    'independent_transposed_functional_V':[[float(v.real),float(v.imag)] for v in voltages],
    'transposed_vs_reported_absolute_V':abs(voltages-stored).tolist(),
    'fixed_roundoff_voltage_bounds':voltage_bounds,'relative_reference_errors':relative.tolist(),
    'factorizations':0,'matrix_assemblies':0,'reference_evaluations':0,'old_tests_repeated':False,
    'physical_accuracy':'unqualified','G03':'not_run','all29_formal':'not_run'}
with (D/'review.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(result))
