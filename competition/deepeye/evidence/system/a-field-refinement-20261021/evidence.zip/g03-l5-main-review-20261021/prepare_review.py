"""Review newly completed L5 without repeating the solve or prior grid checks."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
OUT=D.parent
S=OUT/'g03-l5-propagation-z-refinement-20261021'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,data):
    with p.open('x',encoding='utf-8') as f:json.dump(data,f,indent=2,allow_nan=False);f.write('\n')
manifest=read(S/'public-manifest.json')
assert sha(S/'public-manifest.json')=='521022089175583b344c45cbb6a2ca88e1198845a9f14f0ea347421e10fb9730'
assert len(manifest['files'])==64
for name,pin in manifest['files'].items():
    p=S/name
    assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],name
native=read(S/'native-complete-response.json')
if 'job_id' not in native:native=json.loads(next(v['text'] for v in native['content'] if v['type']=='text'))
assert native['job_id']=='child-aade5231f8b04ca18d7d439f2b631efc'
assert native['status']=='completed' and native['terminal'] and not native['stale']
assert native['result']['text']==(S/'final-result.txt').read_text(encoding='utf-8')
terminal={}
for name in ('controls-01','run-01'):
    t=read(S/name/'terminal.json')
    assert t['exit_code']==0 and t['all_processes_terminated'] and t['active_processes_final']==0
    assert all(x['signaled'] and x['wait_result']==0 for x in t['held_members'])
    terminal[name]={k:t[k] for k in ('exit_code','seconds','peak_job_memory_bytes','all_processes_terminated','active_processes_final')}
result=read(S/'run-01/result.json')
assert result['counts']=={'C_constructions':1,'A_assemblies':1,'factorizations':1,'RHS_columns':1}
assert result['LU_nnz']=='not_materialized'
assembly=read(S/'run-01/pre-factorization-assembly.json')
for name,pin in assembly['files'].items():
    p=S/'run-01'/name
    assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],name
save(D/'integrity.json',{'manifest_sha256':sha(S/'public-manifest.json'),'verified_files':64,
    'native':{k:native[k] for k in ('job_id','status','terminal','stale')},'terminal':terminal,
    'counts':result['counts'],'saved_prefactorization_files_verified':len(assembly['files']),
    'source_review':'L4 physics and source unchanged. Only six selected z intervals bisected; XY areas compared exactly. Operators persisted before one COLAMD factorization and solve. No L/U count materialization. Fixed backward residual gate and frozen reference retained.',
    'old_tests_repeated':False,'numerical_independent_review_pending':True})
old=OUT/'g03-l4-saved-main-review-20261021'
text=(old/'review_arrays.py').read_text(encoding='utf-8')
text=text.replace('L4 arrays','L5 arrays').replace('ACCEPT_NEW_L4_SAVED_OPERATOR_NUMERICAL_RESULT_ONLY','ACCEPT_NEW_L5_NUMERICAL_RESULT_ONLY')
text=text.replace("g03-l4-saved-operator-solve-20261021/run-01","g03-l5-propagation-z-refinement-20261021/run-01")
text=text.replace("g03-l4-ordering-repair-20261021/run-01","g03-l5-propagation-z-refinement-20261021/run-01")
text=text.replace("g03-l4-global-refinement-20261021/controls-01","g03-l5-propagation-z-refinement-20261021/controls-01")
with (D/'review_arrays.py').open('x',encoding='utf-8') as f:f.write(text)
with (D/'run_review.py').open('x',encoding='utf-8') as f:f.write((old/'run_review.py').read_text(encoding='utf-8'))
print(json.dumps({'integrity_verified_files':64,'native_completed':True,'new_array_review_prepared':True}))
