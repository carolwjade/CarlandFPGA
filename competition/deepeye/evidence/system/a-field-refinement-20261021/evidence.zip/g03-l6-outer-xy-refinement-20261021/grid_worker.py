"""One selected L6 control or actual process. No grid campaign."""
import gc,hashlib,json,math,os,sys,time,warnings
from pathlib import Path
D=Path(__file__).resolve().parent
ROOT=D.parents[2]
stage=Path(sys.argv[1]);mode=sys.argv[2]
def save_json(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def save_array(p,x):
    with p.open('xb') as f:
        import numpy as np
        np.save(f,x,allow_pickle=False)
def pair(v):return [[float(complex(x).real),float(complex(x).imag)] for x in v]
save_json(stage/'hello.json',{'pid':os.getpid(),'before_scientific_import':True,'mode':mode})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('no science grant')
    time.sleep(.01)
grant=json.loads((stage/'grant.json').read_text(encoding='utf-8'))
assert grant['worker']['pid']==os.getpid() and grant['mode']==mode
sys.path.insert(0,str(D))
import numpy as np
from scipy import sparse
import grid_model as m

def threads():
    import ctypes as ct
    import scipy.linalg
    k=ct.WinDLL('kernel32',use_last_error=True)
    k.GetModuleHandleW.argtypes=[ct.c_wchar_p];k.GetModuleHandleW.restype=ct.c_void_p
    site=Path(np.__file__).resolve().parents[1];rows=[]
    for folder,symbol in (('numpy.libs','scipy_openblas_get_num_threads64_'),('scipy.libs','scipy_openblas_get_num_threads')):
        paths=list((site/folder).glob('*openblas*.dll'));assert len(paths)==1
        handle=k.GetModuleHandleW(str(paths[0]));assert handle
        getter=getattr(ct.CDLL(str(paths[0]),handle=handle),symbol)
        getter.argtypes=[];getter.restype=ct.c_int
        count=getter();assert count==1
        rows.append({'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),'num_threads':count})
    return rows

started=time.monotonic();before=threads();error=None;counts={}
try:
    mesh=m.mesh_new()
    assignment=json.loads((D/'assignment.json').read_text(encoding='utf-8'))
    if not np.array_equal(m.Z,np.asarray(assignment['z_nodes_m'])) or not np.array_equal(m.X,np.asarray(assignment['level']['x_nodes_m'])):
        raise ValueError('selected L6 nominal nodes differ from assignment')
    if mode=='controls':
        W,areas=m.disks(mesh)
        old=D.parent/'g03-l5-propagation-z-refinement-20261021'
        old_manifest=json.loads((old/'public-manifest.json').read_text(encoding='utf-8'))
        def old_array(name):
            p=old/'controls-01'/(name+'.npy')
            assert hashlib.sha256(p.read_bytes()).hexdigest()==old_manifest['files']['controls-01/'+name+'.npy']['sha256']
            return np.load(p,allow_pickle=False)
        old_areas=old_array('disk_cell_areas_m2')
        old_x=m.X_L4
        old_to_new=np.array([np.flatnonzero(m.X==value)[0] for value in old_x])
        for di in range(3):
            for i in range(len(old_x)-1):
                for j in range(len(old_x)-1):
                    summed=float(np.sum(areas[di,old_to_new[i]:old_to_new[i+1],old_to_new[j]:old_to_new[j+1]]))
                    if abs(summed-old_areas[di,i,j])>m.GATE*math.pi*m.RADII[di]**2:
                        raise ArithmeticError('new XY cell areas fail old-grid aggregation')
        s=m.z_curl_transpose(mesh,W[0]);line=m.line_oracle(mesh,m.CENTERS[0],m.RADII[0])
        starts,ends=m.edges(mesh)
        lengths=np.linalg.norm(ends-starts,axis=1)
        B=np.sort(mesh.project_edge_to_boundary_edge.indices)
        mask=np.ones(mesh.n_edges,dtype=bool);mask[B]=False;I=np.flatnonzero(mask)
        assert (len(B),len(I))==(10752,74682)
        scale=max(float(np.max(abs(s))),float(np.sum(abs(s))))
        line_error=float(np.max(abs(s-line)))
        if line_error>m.GATE*scale:raise ArithmeticError('independent segmented line oracle')
        divergence=np.zeros(mesh.n_nodes)
        nx,ny,nz=mesh.shape_cells;off=0
        for axis,shape in enumerate((mesh.shape_edges_x,mesh.shape_edges_y,mesh.shape_edges_z)):
            n=math.prod(shape)
            sub=np.unravel_index(np.arange(n),shape,order='F')
            tail=np.ravel_multi_index(sub,mesh.shape_nodes,order='F')
            other=list(sub);other[axis]=other[axis]+1
            head=np.ravel_multi_index(tuple(other),mesh.shape_nodes,order='F')
            np.add.at(divergence,tail,-s[off:off+n]/lengths[off:off+n])
            np.add.at(divergence,head,s[off:off+n]/lengths[off:off+n])
            off+=n
        divmax=float(np.max(abs(divergence)))
        if divmax>m.GATE*max(float(np.sum(abs(s/lengths))),1e-30):raise ArithmeticError('weak divergence')
        moment=float(s @ np.r_[-(starts[:math.prod(mesh.shape_edges_x),1]+ends[:math.prod(mesh.shape_edges_x),1])/4,
            (starts[math.prod(mesh.shape_edges_x):math.prod(mesh.shape_edges_x)+math.prod(mesh.shape_edges_y),0]+ends[math.prod(mesh.shape_edges_x):math.prod(mesh.shape_edges_x)+math.prod(mesh.shape_edges_y),0])/4,
            np.zeros(math.prod(mesh.shape_edges_z))])
        if abs(moment-math.pi*.05**2)>m.GATE*math.pi*.05**2:raise ArithmeticError('rotational moment')
        if not np.any(abs(s[I])>m.GATE*scale):raise ArithmeticError('no resolved interior forcing')
        if not np.array_equal(s[B],np.zeros(len(B))):raise ArithmeticError('source touches prescribed boundary')
        if abs(s[:math.prod(mesh.shape_edges_x)].sum())>m.GATE*scale or abs(s[math.prod(mesh.shape_edges_x):math.prod(mesh.shape_edges_x)+math.prod(mesh.shape_edges_y)].sum())>m.GATE*scale:raise ArithmeticError('constant field circulation')
        old_starts=old_array('edge_starts_m')
        old_ends=old_array('edge_ends_m')
        old_B=old_array('boundary_indices')
        old_low=old_array('boundary_g_64x8_Vpm')
        old_high=old_array('boundary_g_128x16_Vpm')
        assert len(old_B)==len(old_low)==len(old_high) and old_starts.shape==old_ends.shape
        def edge_key(a,b):
            return np.concatenate((a,b)).astype('<f8',copy=False).tobytes()
        cache={}
        for q,edge in enumerate(old_B):
            key=edge_key(old_starts[edge],old_ends[edge])
            if key in cache:raise ArithmeticError('ambiguous old boundary edge key')
            cache[key]=q
        reused_positions=[];old_positions=[];new_positions=[]
        for q,edge in enumerate(B):
            old_q=cache.get(edge_key(starts[edge],ends[edge]))
            if old_q is None:new_positions.append(q)
            else:reused_positions.append(q);old_positions.append(old_q)
        reused_positions=np.asarray(reused_positions,dtype=np.int64)
        old_positions=np.asarray(old_positions,dtype=np.int64)
        new_positions=np.asarray(new_positions,dtype=np.int64)
        low=np.empty(len(B),dtype=complex);high=np.empty(len(B),dtype=complex)
        low[reused_positions]=old_low[old_positions]
        high[reused_positions]=old_high[old_positions]
        low[new_positions]=m.green_boundary(starts[B[new_positions]],ends[B[new_positions]],64,8)
        high[new_positions]=m.green_boundary(starts[B[new_positions]],ends[B[new_positions]],128,16)
        if not np.all(np.isfinite(low)) or not np.all(np.isfinite(high)):
            raise ArithmeticError('nonfinite cached/new boundary values')
        maxdiff=float(np.max(abs(high-low)))
        gate=1.967577343353139e-12
        if maxdiff>gate:raise ArithmeticError('fixed Green boundary pair consistency gate')
        for name,x in {'W_faces_m2':W,'disk_cell_areas_m2':areas,'s_matrix_free_Am':s,'s_line_oracle_Am':line,
                       'boundary_indices':B,'interior_indices':I,'edge_starts_m':starts,'edge_ends_m':ends,
                       'boundary_g_64x8_Vpm':low,'boundary_g_128x16_Vpm':high,'weak_divergence_A':divergence,
                       'boundary_reused_positions':reused_positions,'boundary_old_positions':old_positions,
                       'boundary_new_positions':new_positions}.items():
            save_array(stage/(name+'.npy'),x)
        result={'status':'controls_pass','shape_cells':mesh.shape_cells,'n_edges':mesh.n_edges,'n_faces':mesh.n_faces,
            'boundary_edges':len(B),'interior_edges':len(I),'plane_basis':[m.plane_basis(mesh.nodes_z,z) for z in m.CENTERS],
            'source_positive_face_count':int(np.count_nonzero(W[0]>0)),
            'xy_disk_areas_aggregate_to_reviewed_L5_within_128eps':True,
            'boundary_cache_key':'oriented_start_end_little_endian_float64_bytes',
            'boundary_cached_count':len(reused_positions),'boundary_new_integral_count':len(new_positions),
            'boundary_old_count':len(old_B),
            'source_area_m2':float(W[0].sum()),'receiver_area_m2':W[1:].sum(axis=1).tolist(),
            'source_interior_nonzero_count':int(np.count_nonzero(abs(s[I])>m.GATE*scale)),
            'source_boundary_exact_zero':True,'line_oracle_max_difference_Am':line_error,
            'divergence_max_A':divmax,'rotational_moment_Am2':moment,
            'boundary_pair_max_difference_Vpm':maxdiff,'boundary_pair_gate_Vpm':gate,
            'boundary_high_max_Vpm':float(np.max(abs(high))),
            'qualification':'observed quadrature consistency, not rigorous receiver error certification',
            'G03':'not_run','all29':'not_run'}
        save_json(stage/'control-result.json',result)
        counts={'C_constructions':0,'A_assemblies':0,'factorizations':0,'RHS_columns':0}
    elif mode=='actual':
        from scipy.sparse.linalg import splu
        from simpeg.electromagnetics.frequency_domain.simulation import Simulation3DElectricField
        control=D/'controls-01'
        c=json.loads((control/'control-result.json').read_text(encoding='utf-8'))
        assert c['status']=='controls_pass' and c['boundary_pair_max_difference_Vpm']<=c['boundary_pair_gate_Vpm']
        W=np.load(control/'W_faces_m2.npy',allow_pickle=False)
        s=np.load(control/'s_matrix_free_Am.npy',allow_pickle=False)
        B=np.load(control/'boundary_indices.npy',allow_pickle=False)
        I=np.load(control/'interior_indices.npy',allow_pickle=False)
        g=np.load(control/'boundary_g_128x16_Vpm.npy',allow_pickle=False)
        C=mesh.edge_curl.tocsr(copy=True);counts['C_constructions']=1
        source_actual=np.asarray(C.T@W[0]).ravel()
        se=float(np.max(abs(source_actual-s)))
        if se>m.GATE*max(float(np.sum(abs(s))),1e-30):raise ArithmeticError('actual C.T W differs from matrix-free source')
        sim=Simulation3DElectricField(mesh,survey=None,sigma=np.full(mesh.n_cells,m.SIGMA),
            mu=np.full(mesh.n_cells,m.MU),permittivity=np.full(mesh.n_cells,m.EPSILON))
        A=sim.getA(m.FREQ).tocsr(copy=True);counts['A_assemblies']=1
        if A.shape!=(85434,85434) or C.shape!=(82656,85434):raise ValueError('actual operator size')
        rhs=-1j*(2*math.pi*m.FREQ)*source_actual
        AII=A[I,:][:,I].tocsc();AIB=A[I,:][:,B].tocsr()
        reduced=rhs[I]-AIB@g
        if not all(np.all(np.isfinite(mat.data)) for mat in (C,A,AII)):
            raise ArithmeticError('nonfinite sparse operator before factorization')
        if not all(np.all(np.isfinite(arr)) for arr in (source_actual,rhs,reduced)):
            raise ArithmeticError('nonfinite source or RHS before factorization')
        for name,xarr in {'source_actual_CtW_Am':source_actual,
                          'raw_rhs':rhs,'A_II_rhs':reduced}.items():
            save_array(stage/(name+'.npy'),xarr)
        for name,matrix in (('C-csr',C),('A-csr',A),('AII-csc',AII)):
            with (stage/(name+'.npz')).open('xb') as f:
                np.savez(f,shape=np.asarray(matrix.shape),data=matrix.data,
                         indices=matrix.indices,indptr=matrix.indptr)
        symmetry_delta=AII-AII.T
        symmetry_inf=float(np.max(np.asarray(abs(symmetry_delta).sum(axis=1)).ravel()))
        A_nnz=int(A.nnz);C_nnz=int(C.nnz);AII_nnz=int(AII.nnz)
        saved=('source_actual_CtW_Am.npy','raw_rhs.npy','A_II_rhs.npy',
               'C-csr.npz','A-csr.npz','AII-csc.npz')
        save_json(stage/'pre-factorization-assembly.json',{
            'status':'exact_assembly_persisted_before_factorization',
            'C_shape':C.shape,'C_nnz':int(C.nnz),'A_shape':A.shape,'A_nnz':int(A.nnz),
            'AII_shape':AII.shape,'AII_nnz':int(AII.nnz),
            'AII_transpose_symmetry_inf':symmetry_inf,
            'C_transpose_source_max_difference_Am':se,
            'files':{n:{'bytes':(stage/n).stat().st_size,
                        'sha256':hashlib.sha256((stage/n).read_bytes()).hexdigest()} for n in saved},
            'factorization_ordering_selected':'COLAMD',
            'factorization_started':False})
        del A,AIB,sim,symmetry_delta
        gc.collect()
        with warnings.catch_warnings(record=True) as wr:
            warnings.simplefilter('error')
            lu=splu(AII,permc_spec='COLAMD');counts['factorizations']=1
            x=lu.solve(reduced);counts['RHS_columns']=1
        del lu
        gc.collect()
        residual=AII@x-reduced
        normA=float(np.max(np.asarray(abs(AII).sum(axis=1)).ravel()))
        den=normA*float(np.max(abs(x)))+float(np.max(abs(reduced)))
        eta=float(np.max(abs(residual))/den) if den else (0. if np.array_equal(residual,np.zeros_like(residual)) else math.inf)
        if not math.isfinite(eta) or eta>m.GATE:raise ArithmeticError('fixed 128eps backward residual gate')
        E=np.empty(mesh.n_edges,dtype=complex);E[B]=g;E[I]=x
        V=W@(C@E)
        refpath=D.parent/'g03-source-voltage-20261021/run-01/V_reference128_V.npy'
        if hashlib.sha256(refpath.read_bytes()).hexdigest()!='fd68cfa481e92251fd14616f0ca177f312db89904557c8c44fd9219fd1df1889':raise ValueError('reference pin')
        ref=np.load(refpath,allow_pickle=False)
        assert ref.shape==(2,)
        diff=V[1:]-ref
        l1path=D.parent/'g03-internal-source-grid-continuation-20261021/run-01/V_compatible_V.npy'
        l1manifest=json.loads((D.parent/'g03-internal-source-grid-continuation-20261021/public-manifest.json').read_text(encoding='utf-8'))
        assert hashlib.sha256(l1path.read_bytes()).hexdigest()==l1manifest['files']['run-01/V_compatible_V.npy']['sha256']
        l1=np.load(l1path,allow_pickle=False)
        assert l1.shape==(2,)
        delta_l1=V[1:]-l1
        l2path=D.parent/'g03-l2-xy-refinement-20261021/run-01/V_compatible_V.npy'
        l2manifest=json.loads((D.parent/'g03-l2-xy-refinement-20261021/public-manifest.json').read_text(encoding='utf-8'))
        assert hashlib.sha256(l2path.read_bytes()).hexdigest()==l2manifest['files']['run-01/V_compatible_V.npy']['sha256']
        l2=np.load(l2path,allow_pickle=False)
        assert l2.shape==(2,)
        delta_l2=V[1:]-l2
        l3path=D.parent/'g03-l3-z-refinement-20261021/run-01/V_compatible_V.npy'
        l3manifest=json.loads((D.parent/'g03-l3-z-refinement-20261021/public-manifest.json').read_text(encoding='utf-8'))
        assert hashlib.sha256(l3path.read_bytes()).hexdigest()==l3manifest['files']['run-01/V_compatible_V.npy']['sha256']
        l3=np.load(l3path,allow_pickle=False)
        assert l3.shape==(2,)
        delta_l3=V[1:]-l3
        l4path=D.parent/'g03-l4-saved-operator-solve-20261021/run-01/V_compatible_V.npy'
        l4manifest=json.loads((D.parent/'g03-l4-saved-operator-solve-20261021/public-manifest.json').read_text(encoding='utf-8'))
        assert hashlib.sha256(l4path.read_bytes()).hexdigest()==l4manifest['files']['run-01/V_compatible_V.npy']['sha256']
        l4=np.load(l4path,allow_pickle=False)
        assert l4.shape==(2,)
        delta_l4=V[1:]-l4
        l5path=D.parent/'g03-l5-propagation-z-refinement-20261021/run-01/V_compatible_V.npy'
        l5manifest=json.loads((D.parent/'g03-l5-propagation-z-refinement-20261021/public-manifest.json').read_text(encoding='utf-8'))
        assert hashlib.sha256(l5path.read_bytes()).hexdigest()==l5manifest['files']['run-01/V_compatible_V.npy']['sha256']
        l5=np.load(l5path,allow_pickle=False)
        assert l5.shape==(2,)
        delta_l5=V[1:]-l5
        for name,xarr in {'interior_solution_Vpm':x,'E_Vpm':E,'V_compatible_V':V[1:],
                          'V_reference128_V':ref,'V_difference_V':diff,'V_L1_saved_V':l1,
                          'V_L2_saved_V':l2,'V_L3_saved_V':l3,'V_L4_saved_V':l4,'V_L5_saved_V':l5,
                          'V_L6_minus_L1_V':delta_l1,'V_L6_minus_L2_V':delta_l2,
                          'V_L6_minus_L3_V':delta_l3,'V_L6_minus_L4_V':delta_l4,
                          'V_L6_minus_L5_V':delta_l5,
                          'AII_residual':residual}.items():
            save_array(stage/(name+'.npy'),xarr)
        result={'status':'one_actual_L6_solve_complete','counts':counts,'C_transpose_source_max_difference_Am':se,
            'A_nnz':A_nnz,'C_nnz':C_nnz,'AII_shape':AII.shape,'AII_nnz':AII_nnz,
            'factorization_ordering':'COLAMD','LU_nnz':'not_materialized',
            'backward_residual_eta':eta,'backward_residual_gate':m.GATE,
            'V_compatible_V':pair(V[1:]),'V_reference128_V':pair(ref),
            'V_L1_saved_V':pair(l1),'V_L2_saved_V':pair(l2),'V_L3_saved_V':pair(l3),'V_L4_saved_V':pair(l4),'V_L5_saved_V':pair(l5),
            'finite_minus_reference_V':pair(diff),'absolute_difference_V':abs(diff).tolist(),
            'relative_difference':(abs(diff)/abs(ref)).tolist(),
            'L6_minus_L1_V':pair(delta_l1),'L6_minus_L1_absolute_V':abs(delta_l1).tolist(),
            'L6_minus_L2_V':pair(delta_l2),'L6_minus_L2_absolute_V':abs(delta_l2).tolist(),
            'L6_minus_L3_V':pair(delta_l3),'L6_minus_L3_absolute_V':abs(delta_l3).tolist(),
            'L6_minus_L4_V':pair(delta_l4),'L6_minus_L4_absolute_V':abs(delta_l4).tolist(),
            'L6_minus_L5_V':pair(delta_l5),'L6_minus_L5_absolute_V':abs(delta_l5).tolist(),
            'L6_minus_L5_relative_to_reference':(abs(delta_l5)/abs(ref)).tolist(),
            'L1_relative_difference':[.4288648983112377,.34381684017566017],
            'L2_relative_difference':[.42521623756675525,.3403507317006062],
            'L3_relative_difference':[.3019413420486286,.29950851212244745],
            'L4_relative_difference':[.1496213588467958,.11474472402851406],
            'L5_relative_difference':[.11137521928697758,.09209941416907708],
            'comparison_note':'L5/L6 use same compatible receiver functional; one selected outer-XY change is observational, not convergence or accuracy certification',
            'physical_acceptance':'open','G03':'not_run','R03':'not_run','all29':'not_run'}
        save_json(stage/'result.json',result)
    else:raise ValueError('unknown mode')
except BaseException as exc:
    error={'type':type(exc).__name__,'message':str(exc)}
    raise
finally:
    save_json(stage/'execution.json',{'mode':mode,'pid':os.getpid(),'seconds':time.monotonic()-started,
        'counts':counts,'blas_before':before,'blas_after':threads(),'error':error})
