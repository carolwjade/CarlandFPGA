"""Main selects one outer-XY comparison; no solver runs in this script."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
OLD=D.parent/'g03-l5-propagation-z-refinement-20261021'
def save(p,data):
    with p.open('x',encoding='utf-8') as f:json.dump(data,f,indent=2,ensure_ascii=False);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(OLD/'public-manifest.json')=='521022089175583b344c45cbb6a2ca88e1198845a9f14f0ea347421e10fb9730'
assert json.loads((D.parent/'g03-l5-main-review-20261021/review.json').read_text())['status']=='ACCEPT_NEW_L5_NUMERICAL_RESULT_ONLY'
a=json.loads((OLD/'assignment.json').read_text(encoding='utf-8'))
gaps=[[-.6,-.375],[-.375,-.15],[.15,.375],[.375,.6]]
x=a['level']['x_nodes_m']
for left,right in gaps:assert x[x.index(left)+1]==right
x=sorted(x+[(left+right)/2 for left,right in gaps])
nx=ny=len(x)-1;nz=len(a['z_nodes_m'])-1
edges=nx*(ny+1)*(nz+1)+(nx+1)*ny*(nz+1)+(nx+1)*(ny+1)*nz
interior=nx*(ny-1)*(nz-1)+(nx-1)*ny*(nz-1)+(nx-1)*(ny-1)*nz
faces=(nx+1)*ny*nz+nx*(ny+1)*nz+nx*ny*(nz+1)
a.update(work_id='A-G03-L6-OUTER-XY-REFINEMENT-20261021-v1',ownership=[str(D.relative_to(D.parents[2])).replace('\\','/')],
         previous_job_completed='child-aade5231f8b04ca18d7d439f2b631efc',previous_manifest_sha256=sha(OLD/'public-manifest.json'),
         actual_L5_runs_selected=0,actual_L6_runs_selected=1,split_original_xy_intervals=gaps)
a.pop('split_original_z_intervals',None)
a['level'].update(name='L5_z_outer_xy_four_interval_bisections',x_nodes_m=x,shape_cells=[nx,ny,nz],cells=nx*ny*nz,
    edges=edges,faces=faces,nodes=(nx+1)*(ny+1)*(nz+1),interior_edges=interior,tangential_boundary_edges=edges-interior)
assert (nx,ny,nz,edges,interior)==(28,28,34,85434,74682)
design='''# One selected L6 outer-XY refinement

Main decision: advance the existing G03 3D Maxwell reference with one controlled comparison. L5 reduced observed relative receiver differences to 11.1375% and 9.2099%, but these remain unqualified. Earlier receiver decomposition made the field term much larger than receiver-functional error. The retained mesh still has 0.225 m XY cells outside |x| or |y|=0.15 m. Their role in the remaining field error is a hypothesis to test, not an established causal conclusion.

Bisect only four outer intervals [-0.6,-0.375], [-0.375,-0.15], [0.15,0.375], [0.375,0.6] in X and Y. Keep all L5 Z nodes, domain, central/source/receiver geometry, physics, current, boundary formula, original reference and numerical gates fixed. Selected shape 28x28x34, 26656 cells, 85434 edges, 74682 interior and 10752 boundary. This is one selected geometry; no automatic next grid, retuning, alternate ordering or retry.

Snapshot reviewed L5 sources. Save exact C/A/AII/source/raw/reduced RHS with hashes BEFORE one COLAMD factorization and one RHS solve. Reuse saved original reference, L1-L5 voltages and passed old controls. Do not rerun old grids, references, endpoint tests, boundary integrals on bit-identical cached edges, runtime/ROCm probes, board baselines or R03 suites. Geometry-specific source/area/index mapping and boundary controls must cover the new mesh; where cached boundary starts/ends are byte-identical and physics/function source hashes match, reuse both original saved quadrature values, calculate only new edge geometry and record counts. Do not hide a changed edge through fuzzy cache matching.

Controls budget40s/512MiB process/768MiB job. Actual budget120s/6GiB process/7GiB job, fresh free physical RAM>=12GiB before execution, BLAS1. Use reviewed extended win_job guard, atomic JSON grant, retained original process handles. No lu.L/U copies just to count fill. A resource/physics/control failure is preserved and handed back; it does not authorize a second actual process. All writes remain in this assigned planning folder, except its bounded temporary files. No product/board/GPU/service/network/UI/peer/group effects.

Report original and independently computed residual, exact voltages and differences to the frozen reference and saved L5. All accuracy/convergence/heterogeneous-material acceptance remains open; one comparison never closes G03 or R03. Preserve H01-H15 and canonical requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804. Native validate before first work; complete exact original job with sealed result. Main owns independent review, acceptance and publication.
'''
with (D/'design-plan.md').open('x',encoding='utf-8') as f:f.write(design)
a['design_sha256']=sha(D/'design-plan.md')
save(D/'assignment.json',a)
r={'task_id':a['task_id'],'task_version':a['task_version'],'work_id':a['work_id'],'ownership':a['ownership'],
   'reason':'One selected outer-XY correction after independent L5 review; no repeated old tests.',
   'text':json.dumps(a,ensure_ascii=False)+' Read design-plan.md. One L6 model only.'}
save(D/'reserve-request.json',r)
print(json.dumps({'work_id':a['work_id'],'shape':a['level']['shape_cells'],'edges':edges,'interior':interior,'scope':a['ownership']}))
