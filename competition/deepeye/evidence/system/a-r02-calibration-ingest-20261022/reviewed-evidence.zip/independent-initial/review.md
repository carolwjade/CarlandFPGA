# R02 offline calibration independent review

Review scope: `A-R02-CALIBRATION-REVIEW-20261022-v1`, candidate base `1be741a896e28eb38d42bbea80dce125755dba02`, exact three files in sibling `r02-calibration-main-20261022/candidate`. No prior green groups or board/GPU/science tests were repeated. H01-H15 remains pinned to requirements SHA `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`.

## Result

Severity: **none / narrow offline acceptance**. The implementation is internally consistent for the declared software intake boundary. It validates exact schema fields, duplicate keys, finite JSON, byte-size limit, identities, four channels, packing and raw-word boundaries, level/reference separation, sample uniqueness, quality flags, and equal-weight-per-level least squares. Repeated samples affect the level mean but not level weight. Structural errors invalidate the complete report; quality issues block only the affected channel and preserve other diagnostic fits.

Focused additional counterexamples, run against the pinned source, were:

```text
duplicate_key -> invalid; schema: duplicate JSON key
nonfinite     -> invalid; nonfinite JSON value: NaN
oversize      -> invalid; input: maximum size is 4 MiB
```

Source line anchors: JSON duplicate/nonfinite and size handling are in `integration/input_calibrate.py` lines 42-59; raw packing and rail/saturation checks lines 120-149; level/reference quality and ambiguity checks lines 150-181; centered equal-level fit lines 62-79; physical/ENOB status remains `not_run` in lines 184-199 and the report fields.

## Pinned source identity

| file | bytes | SHA-256 |
|---|---:|---|
| `candidate/hardware/calibration_format.md` | 5948 | `333355f35b3c1b55f2abc9db3dcbb99d4996bea3978dfa007d108173c1cf02e4` |
| `candidate/integration/input_calibrate.py` | 13127 | `5463fe1101c6e805679bdfdf31849bb6004623dada5f3f7e4ddceaf189c3398d` |
| `candidate/tests/test_input_calibrate.py` | 8568 | `1f9c54f6847fe20f76500a498ff6062d239a7698c60f218072b89d619622fe59` |

This review establishes software evidence only. Physical R02/R03, ENOB, board behavior, and product acceptance remain `not_run`; declared provenance and input hashes do not authenticate measurements.
