# R02 calibration intake implementation plan

Goal: make the taskbook offline calibration command usable without claiming physical acceptance.
Architecture: one standard-library module validates an explicit four-channel record, computes per-level means and linear fits, and writes an exclusive deterministic report. Unit tests use clearly labeled software fixtures. Documentation is the record contract and evidence boundary.

## Global constraints

DEEPEYE-IMPLEMENTATION-20261014/v1, sole generation-2 A Desktop director, H01-H15 pinned c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804. Preserve C-owned dirty bytes. No board, GUI, model, service or previous-test execution. Root directly implements under human autonomous authorization; the unavailable old worker directory remains untouched.

## One independently reviewable deliverable

- Create candidate/integration/input_calibrate.py: `analyze(raw: bytes | None, levels: int = 8) -> dict` and `main(argv=None) -> int`.
- Create candidate/tests/test_input_calibrate.py: only new unittest cases; hand-derived reference 0.1 + 0.001*code and uneven repetition to expose incorrect sample weighting. Invoke `python -B -m unittest discover -s tests -p test_input_calibrate.py -v` in candidate.
- Create candidate/hardware/calibration_format.md: complete schema, packed words, units, statuses, CLI and physical limits.

Steps:
- [ ] Write tests for documented behaviors; first run fails because the command is absent. Save exact stdout/stderr/exit.
- [ ] Implement strict bounded decoding, structural validation, quality issues, centered equal-level least squares, CLI and no-overwrite output.
- [ ] Run the new test file once; fix actual defects with focused delta reruns, preserve failures.
- [ ] Independent review exact candidate and saved evidence. Resolve actionable findings. Do not repeat passed groups without a code-change reason.
- [ ] Root adopts only three new files, publishes reviewed evidence and exact source hash to existing PR24; preserve original failed worker and all existing dirty files.

Main design review: selected option 2. Four-channel header-voltage mapping is kept separate from physical units, PGA gain acceptance and ENOB. Existing human authorization permits this routine design choice without an extra user confirmation.
