# R02 offline four-channel calibration intake

Root work A-R02-CALIBRATION-MAIN-20261022-v1, director 01a13d7e-dcf1-7272-a738-a637dd62ff9d generation 2, DEEPEYE-IMPLEMENTATION-20261014/v1. H01-H15 and c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 unchanged. Product base 1be741a896e28eb38d42bbea80dce125755dba02. Ownership is this new preparation directory; root adopts only the reviewed three new product files.

The earlier native worker is absent from the live collaboration inventory; interrupt returned not_found. Cancellation made its ledger terminal with error native stop unconfirmed. Its original directory and private records remain untouched; this work does not take over that directory or replay any operation. No design, code or process execution result was found there.

## Choice

1. Schema/documentation alone cannot exercise the taskbook calibration command.
2. A small standard-library offline validator and least-squares calculator provides a working intake now. **Selected.** It consumes declared measurements, never operates instruments or certifies the physical evidence.
3. Hardware acquisition now would require B's integrated registers/bit/HWH and confirmed external wiring. Defer that separate dependency rather than invent an acquisition adapter.

## Interface and data

`python integration/input_calibrate.py --levels 8 [--input records.json] [--output report.json]`. No input returns a structured not_run report and exit 3. Output is optional and exclusively created, never overwritten. Input is bounded to 4 MiB; no paths or programs inside the document are accessed. Exit 0 means offline computation completed, 2 malformed input/output error, 3 missing/incomplete/unsafe-to-fit records. No default hardware/calibration.json is created.

Strict JSON schema 1 contains source_mode (sensor_live, twin_fixture, software_fixture), operation_id, request_hash, tested_commit, captured_at_utc, and exactly four channels A0-A3. Digital geo_replay is not an ADC calibration source. Each channel supplies signal_chain_id, fixed gain, nominal_adc_bits=12, container_bits=16, packing right_aligned/left_aligned, range_v=[low,high] at the analog input header, independent reference_instrument identifier, and 8-256 planned levels. Each level has a unique level_id, unique target_v, reference_kind (independent_measurement for physical modes, software_fixture for fixtures), reference_v, reference_uncertainty_v, and 1-4096 samples. Each sample has a unique sample_id, raw_word and analog_saturation (true/false/null). Sample IDs are unique throughout the dataset. Flags are declarations, not verified evidence.

Each planned level counts once, irrespective of repetitions. Distinct targets and non-overlapping independent-reference uncertainty intervals prevent repeat samples or small noise within the same level from manufacturing eight points. Distinctness also uses a 64-epsilon arithmetic resolution check, not a physical acceptance tolerance. References must be within the declared range. The tool explicitly decodes only documented left/right 12-bit words; nonzero padding is malformed. ADC endpoint codes are rail flags, distinct from declared analog saturation or unknown status. Any unsafe/unknown point prevents fitting that entire channel; no rejected sample is silently dropped. Every issue names the channel/level/sample path and the original byte hash is retained.

For complete channels, fit reference volts = offset_v + volts_per_code * mean ADC code with equal weight per level. Return point count, sample count, point means, gain, offset and per-level/max/RMS residual volts. Reject unresolved ADC spread, nonpositive gain and nonfinite arithmetic. No residual threshold is invented. Repeated samples improve the mean but do not increase calibration-level weight.

All reports retain source_mode, nominal versus container width, input-byte SHA256, declared operation/request/commit, and evidence_level. Offline computation and physical verification are separate. ENOB stays not_run: DC linearity cannot establish it. Physical verification, R02/R03 and product acceptance always remain not_run in this utility. software_fixture never becomes a physical record. Missing analog evidence is not assumed safe. No synthesized data is installed in product hardware/calibration.json.

## Verification

Only new tests: independently specified affine response and unequal replicate counts; packing; incomplete channels/levels; duplicate IDs and noisy repeated levels; nonfinite/malformed metadata; saturation/range and unknown state; degenerate slope; exact byte provenance; CLI missing input and exclusive output. No prior pipeline/GPU/board/science suite is rerun. Independent review reads this implementation and runs only additional counterexamples if needed.
