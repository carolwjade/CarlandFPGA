# R02 calibration CLI provenance delta review

Scope: `A-R02-CALIBRATION-DELTA-REVIEW-20261022-v1`, reviewing only the two demonstrated CLI regressions and their repairs in sibling `r02-calibration-main-20261022`. The original review and job remain immutable. H01-H15 remains pinned to requirements SHA `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`.

## Result

Severity: **none for this delta**. Both original failures have a direct, minimal repair:

1. `main` reads at most `MAX_INPUT_BYTES + 1`; `analyze` now rejects that oversized prefix before assigning `input_sha256` (lines 195-199). Therefore an unread suffix is never represented as a complete-file hash.
2. `main` retains the already-created `result` through output-file `OSError` (lines 236-254), changing only status and appending `file_error`. The input identity, provenance, and diagnostic calculation are preserved; the old fallback to a fabricated `input_missing` report is removed.

The accompanying documentation states both boundaries, and the final new test run recorded `11 tests ... OK`, exit code 0. The two red tests specifically demonstrated the pre-fix failures: prefix hash was non-null for oversized input, and output failure discarded the input hash. No prior groups were repeated and no additional counterexample was needed.

## Exact final source identity

| file | bytes | SHA-256 |
|---|---:|---|
| `candidate/hardware/calibration_format.md` | 6416 | `d0d1b081af713db0c0efa4a7408e19579c5ee4487f922d0d5dd182ce47dece61` |
| `candidate/integration/input_calibrate.py` | 13396 | `250da3f358d833f21a0c4fdbdebeef124f943de30bfb6118d5c31217e7949cc0` |
| `candidate/tests/test_input_calibrate.py` | 9955 | `aa5234c44361db64007348370a480a750633b100e37991bb5fa0ad16faf85700` |
| `candidate/integration/__pycache__/input_calibrate.cpython-312.pyc` | 21778 | `f61e194a699d20388afc40a5701364071cbf58e660e2f153c24d4e7047fe9abb` |

This is software CLI/provenance evidence only. Physical R02/R03, ENOB, board behavior, and product acceptance remain `not_run`; hashes and declared provenance do not authenticate measurements.
