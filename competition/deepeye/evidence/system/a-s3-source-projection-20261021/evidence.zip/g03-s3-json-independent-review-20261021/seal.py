"""Public manifest for this sole-owned independent review; never expose lease."""
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parent
skip = {"lease.private.json", "manifest.json", "reserve-request.json", "reserve.stderr.txt"}
files = []
for path in sorted(D.rglob("*")):
    if path.is_file() and path.name not in skip:
        data = path.read_bytes()
        files.append({"path": path.relative_to(D).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
manifest = {
    "work_id": "A-G03-S3-JSON-INDEPENDENT-REVIEW-20261021-v1",
    "requirements_sha256": "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804",
    "status": "independent_array_audit_pass_physical_screen_failed",
    "files": files,
}
(D / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(len(files))
