"""Launch one saved-array review under the previously reviewed Windows guard."""
import hashlib
import json
import os
import sys
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
AUTHOR = D.parent / "g03-s3-json-continuation-20261021"
SUPPORT = D.parent / "r02-transient-quota-fix-20261021"
PYTHON = ROOT / ".local/deepeye-fdem-validation-20261020/Scripts/python.exe"
STAGE = D / "run-01"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    assignment = read(D / "assignment.json")
    assert assignment["work_id"] == "A-G03-S3-JSON-INDEPENDENT-REVIEW-20261021-v1"
    assert assignment["owner"] == "/root/r03_ipc_framing_review_20261021"
    assert assignment["requirements_sha256"] == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
    binding = read(D / "audit-input-pins.json")
    assert sha(AUTHOR / "manifest.json") == binding["author_manifest_sha256"]
    assert sha(AUTHOR / "frozen-source-pins.json") == "0823819b9e233391d47abad9924c554d295674d80094f4f15dded632722f2ae4"
    assert sha(SUPPORT / "win_job.py") == "80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d"
    for stage, status in (("controls-01", "controls_pass"), ("projection-01", "projection_pass"), ("run-01", "one_source_correction_screen_failed")):
        path = AUTHOR / stage
        terminal = read(path / "terminal.json")
        result = read(path / "result.json")
        assert terminal["all_processes_terminated"] and len(terminal["held_members"]) == 3
        assert all(member["signaled"] for member in terminal["held_members"])
        assert terminal["status"] == ("failed" if stage == "run-01" else "success")
        assert result["status"] == status
        assert sha(path / "terminal.json") == binding["terminals"][stage]
    assert not STAGE.exists()
    return binding


def main():
    binding = verify()
    sys.path.insert(0, str(SUPPORT))
    from win_job import run_bounded
    env = {
        "SYSTEMROOT": os.environ["SYSTEMROOT"],
        "WINDIR": os.environ.get("WINDIR", os.environ["SYSTEMROOT"]),
        "PATH": "",
        "TEMP": str(STAGE),
        "TMP": str(STAGE),
        "TMPDIR": str(STAGE),
        "MPLCONFIGDIR": str(STAGE / "mplconfig"),
        "MPLBACKEND": "Agg",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONNOUSERSITE": "1",
        "PYTHONIOENCODING": "utf-8",
        **{key: "1" for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")},
    }
    budget = {
        "seconds": 25,
        "active_processes": 4,
        "process_memory_bytes": 512 * 1024**2,
        "job_memory_bytes": 1024**3,
        "stdout_bytes": 64 * 1024,
        "stderr_bytes": 64 * 1024,
        "tree_bytes": 64 * 1024**2,
        "tree_entries": 1000,
        "free_reserve_bytes": 256 * 1024**2,
        "components": [{"path": str(STAGE), "bytes": 64 * 1024**2, "entries": 1000}],
    }
    result = run_bounded([str(PYTHON), "-I", "-B", "-X", "utf8", str(D / "audit_saved.py")], env, D, STAGE, budget, [D])
    with (D / "audit-launch-result.json").open("x", encoding="utf-8") as f:
        json.dump({
            "status": result["status"],
            "exit_code": result["exit_code"],
            "seconds": result["seconds"],
            "all_processes_terminated": result["all_processes_terminated"],
            "held_members": result["held_members"],
            "bound_author_manifest_sha256": binding["author_manifest_sha256"],
        }, f, indent=2)
        f.write("\n")
    print(json.dumps({"status": result["status"], "exit_code": result["exit_code"], "seconds": result["seconds"], "all_processes_terminated": result["all_processes_terminated"]}))
    return 0 if result["all_processes_terminated"] else 5


if __name__ == "__main__":
    raise SystemExit(main())
