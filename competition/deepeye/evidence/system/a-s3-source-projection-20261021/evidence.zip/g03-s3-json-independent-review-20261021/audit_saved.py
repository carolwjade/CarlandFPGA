"""One independent read-only S3 saved-array audit; no primary or solve."""
import hashlib
import json
import math
import os
import sys
from pathlib import Path

D = Path(__file__).resolve().parent
OUT = D / "run-01"


def audit_effect(event, args):
    if event in ("socket.connect", "socket.getaddrinfo", "subprocess.Popen", "os.system"):
        raise PermissionError("array audit prohibits network and subprocess")
    if event == "open" and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.fsdecode(args[0])).resolve()
        mode = args[1] if len(args) > 1 else None
        flags = args[2] if len(args) > 2 else 0
        writing = (isinstance(mode, str) and any(c in mode for c in "wax+")) or (isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)))
        if writing and not path.is_relative_to(OUT):
            raise PermissionError("array audit writes confined to owned stage")


sys.addaudithook(audit_effect)
sys.path.insert(0, str(D))
import numpy as np
from scipy import sparse

import audit_math as am

ROOT = D.parents[2]
AUTHOR = D.parent / "g03-s3-json-continuation-20261021"
S1 = D.parent / "g03-s1-cache-path-continuation-20261021"
S2 = D.parent / "g03-s2-boundary-correction-20261021"
L5 = D.parent / "g03-l5-propagation-z-refinement-20261021"
EPS = sys.float_info.epsilon


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def pin(path, table):
    key = path.relative_to(ROOT).as_posix()
    record = table[key]
    data = path.read_bytes()
    if len(data) != record["bytes"] or hashlib.sha256(data).hexdigest() != record["sha256"]:
        raise ValueError(f"input pin mismatch: {key}")


def load(path, pins):
    pin(path, pins)
    value = np.load(path, allow_pickle=False)
    if not np.all(np.isfinite(value)):
        raise ValueError(f"nonfinite saved array: {path.name}")
    return value


def check(actual, expected, extra=0.0, factor=128.0):
    actual = np.asarray(actual)
    expected = np.asarray(expected)
    if actual.shape != expected.shape:
        raise ValueError(f"shape mismatch {actual.shape} versus {expected.shape}")
    diff = float(np.max(np.abs(actual - expected)))
    scale = float(np.sum(np.abs(actual)) + np.sum(np.abs(expected)) + extra)
    bound = factor * EPS * scale
    return {"pass": bool(diff <= bound), "absolute": diff, "bound": bound, "scale": scale}


def signed_axis(start, end, bounds):
    lo, hi = bounds
    width = hi - lo
    d = end - start
    axis = int(np.argmax(np.abs(d)))
    if not np.allclose(start, np.where(np.arange(3) == axis, lo, start), rtol=0, atol=4e-14):
        raise ValueError("edge start orientation")
    if abs(d[axis] - width[axis]) > 4e-14 or np.max(np.abs(np.delete(d, axis))) > 4e-14:
        raise ValueError("edge endpoint or direction")
    for j in range(3):
        if j != axis and min(abs(start[j] - lo[j]), abs(start[j] - hi[j])) > 4e-14:
            raise ValueError("transverse edge face")
    return axis


def compensated_scatter(local, edge_map, n=63250):
    terms = {}
    for c in range(len(edge_map)):
        for slot in range(12):
            edge = int(edge_map[c, slot])
            terms.setdefault(edge, []).append(local[c, slot])
    out = np.zeros(n, dtype=complex)
    for edge, values in terms.items():
        out[edge] = am.compensated_complex_sum(values)
    return out


def main():
    frozen = read(AUTHOR / "frozen-source-pins.json")
    manifest = read(AUTHOR / "manifest.json")["files"]
    if len(frozen) != 57:
        raise ValueError("frozen pin count")
    def old(path):
        return load(path, frozen)
    def new(stage, name):
        path = AUTHOR / stage / name
        key = path.relative_to(AUTHOR).as_posix()
        entry = manifest[key]
        data = path.read_bytes()
        if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise ValueError(f"new output pin mismatch: {key}")
        value = np.load(path, allow_pickle=False)
        if not np.all(np.isfinite(value)):
            raise ValueError(f"nonfinite new output: {key}")
        return value

    bounds = new("projection-01", "cell_bounds_m.npy")
    edge_map = new("projection-01", "cell_edge_map.npy")
    cell_ids = new("projection-01", "cell_ids.npy")
    support = new("projection-01", "potential_edge_support.npy")
    starts = old(L5 / "controls-01/edge_starts_m.npy")
    ends = old(L5 / "controls-01/edge_ends_m.npy")
    I = old(S1 / "controls-01/interior_indices.npy")
    B = old(S1 / "controls-01/boundary_indices.npy")
    frozen_ids = old(S1 / "controls-01/contrast_cell_indices.npy")
    frozen_support = old(S1 / "controls-01/primary_support_indices.npy")
    if bounds.shape != (64, 2, 3) or edge_map.shape != (64, 12):
        raise ValueError("cell geometry")
    if not np.array_equal(cell_ids, frozen_ids) or not np.array_equal(support, frozen_support):
        raise ValueError("frozen cell/support mapping")
    if len(support) != 300 or np.intersect1d(support, B).size:
        raise ValueError("source support / boundary")
    if not np.array_equal(np.unique(edge_map), support):
        raise ValueError("mapped support")
    if not np.array_equal(np.sort(np.r_[I, B]), np.arange(63250)):
        raise ValueError("interior/boundary partition")

    p = read(AUTHOR / "assignment.json")["inputs"]
    omega = 2 * math.pi * p["frequency_Hz"]
    zeta = p["sigma_background_Spm"] + 1j * omega * p["epsilon_background_Fpm"]
    e0 = np.array([1 + 2j, -.5 + .7j, .3 - .2j])
    expected_constant = np.empty((64, 12), dtype=complex)
    expected_affine = np.empty((64, 12), dtype=complex)
    axes = np.empty((64, 12), dtype=int)
    for c in range(64):
        for slot in range(12):
            edge = int(edge_map[c, slot])
            axes[c, slot] = signed_axis(starts[edge], ends[edge], bounds[c])
            expected_constant[c, slot] = am.local_expected_from_edge_geometry(bounds[c], starts[edge], ends[edge], zeta, e0)
            expected_affine[c, slot] = am.local_expected_from_edge_geometry(bounds[c], starts[edge], ends[edge])
    charge_moments = [am.exact_affine_weak_charge(cell) for cell in bounds]
    expected_charge = math.fsum(value for value, _ in charge_moments)
    charge_scale = math.fsum(bound / (128 * EPS) for _, bound in charge_moments)
    old_mass = old(S1 / "controls-01/delta_mass_diag_Sm2.npy")
    old_rhs = old(S1 / "run-01/new_derivative_RHS.npy")
    global_axes = np.argmax(np.abs(ends - starts), axis=1)
    out = {"frozen_inputs": 57, "frozen_support": 300, "checks": {}, "orders": {}, "actual": {}}
    all_ok = True
    for order in (2, 4):
        key = f"g{order}"
        constant_local = new("controls-01", f"{key}_constant_local_Am.npy")
        affine_local = new("controls-01", f"{key}_affine_local_Am.npy")
        constant_source = new("controls-01", f"{key}_constant_source_Am.npy")
        affine_source = new("controls-01", f"{key}_affine_source_Am.npy")
        tests = {
            "constant_V_over_4": check(constant_local, expected_constant),
            "affine_local_analytic": check(affine_local, expected_affine),
            "constant_scatter": check(constant_source, compensated_scatter(constant_local, edge_map)),
            "affine_scatter": check(affine_source, compensated_scatter(affine_local, edge_map)),
            "constant_saved_mass_action": check(constant_source, old_mass * e0[global_axes]),
        }
        gradient = np.array([(am.phi(*ends[e]) - am.phi(*starts[e])) / np.linalg.norm(ends[e]-starts[e]) for e in support])
        charge = am.compensated_complex_sum(gradient * affine_source[support])
        tests["affine_charge_exact"] = check(np.array([charge]), np.array([expected_charge]), extra=charge_scale)
        points = new("projection-01", f"{key}_new_target_points_m.npy")
        weights = new("projection-01", f"{key}_new_target_weights_m3.npy")
        primary = new("projection-01", f"{key}_primary_Vpm.npy")
        current = new("projection-01", f"{key}_equivalent_current_Apm2.npy")
        local = new("projection-01", f"{key}_local_load_Am.npy")
        source = new("projection-01", f"{key}_projected_source_Am.npy")
        rhs = new("projection-01", f"{key}_projected_full_RHS.npy")
        difference = new("projection-01", f"{key}_source_difference_full_RHS.npy")
        if points.shape != (64, order**3, 3) or weights.shape != (64, order**3):
            raise ValueError("physical Gauss target shape")
        volume = np.prod(bounds[:, 1] - bounds[:, 0], axis=1)
        tests["weight_volume"] = check(np.sum(weights, axis=1), volume)
        tests["current_zeta_primary"] = check(current, zeta * primary)
        expected_local = np.empty((64, 12), dtype=complex)
        for c in range(64):
            lo, hi = bounds[c]
            for slot in range(12):
                edge = int(edge_map[c, slot])
                axis = int(axes[c, slot])
                shape = np.ones(order**3)
                for j in range(3):
                    if j == axis:
                        continue
                    ratio = (points[c, :, j] - lo[j]) / (hi[j] - lo[j])
                    shape *= ratio if abs(starts[edge, j] - hi[j]) < abs(starts[edge, j] - lo[j]) else 1 - ratio
                expected_local[c, slot] = am.compensated_complex_sum(weights[c] * shape * current[c, :, axis])
        tests["physical_local_from_saved_current"] = check(local, expected_local)
        tests["physical_scatter"] = check(source, compensated_scatter(local, edge_map))
        tests["single_minus_iomega"] = check(rhs, -1j * omega * source)
        tests["full_rhs_subtraction"] = check(difference, -1j * omega * source - old_rhs)
        X, Y, Z = points[..., 0], points[..., 1], points[..., 2]
        gradient_volume = np.stack((Y + .2*Z + Y*Z, X + .4*Z + X*Z, .4*Y + .2*X + X*Y), axis=-1)
        terms = weights[:, :, None] * gradient_volume * current
        charge_volume = am.compensated_complex_sum(terms.ravel())
        charge_edges = am.compensated_complex_sum(gradient * source[support])
        tests["physical_compatible_charge"] = check(
            np.array([charge_edges]), np.array([charge_volume]),
            extra=float(np.sum(np.abs(terms))),
        )
        tests["boundary_zero"] = {"pass": bool(np.all(source[B] == 0) and np.all(rhs[B] == 0) and np.all(difference[B] == 0))}
        out["orders"][key] = tests
        all_ok &= all(v["pass"] for v in tests.values())
    s2 = new("projection-01", "g2_projected_source_Am.npy")
    s4 = new("projection-01", "g4_projected_source_Am.npy")
    d2 = new("projection-01", "g2_source_difference_full_RHS.npy")
    d4 = new("projection-01", "g4_source_difference_full_RHS.npy")
    pair_s = float(np.max(np.abs(s4-s2))/np.max(np.abs(s4)))
    pair_d = float(np.max(np.abs(d4-d2))/np.max(np.abs(d4)))
    out["pair_source"] = pair_s
    out["pair_difference"] = pair_d
    out["pair_pass"] = pair_s <= .001 and pair_d <= .001
    all_ok &= out["pair_pass"]

    if (AUTHOR / "run-01/result.json").exists():
        delta_full = new("run-01", "source_correction_full_RHS.npy")
        rhs_I = new("run-01", "source_correction_interior_RHS.npy")
        x = new("run-01", "interior_source_correction_Vpm.npy")
        delta = new("run-01", "full_source_correction_Vpm.npy")
        field = new("run-01", "corrected_derivative_Vpm.npy")
        residual = new("run-01", "new_source_residual.npy")
        V2 = old(S2 / "run-01/V_corrected_V.npy")
        field2 = old(S2 / "run-01/corrected_derivative_Vpm.npy")
        gB = old(S2 / "run-01/selected_gB_Vpm.npy")
        trace = old(S1 / "controls-01/receiver_trace_m.npy")
        H = old(S1 / "oracle-01/Born_derivative_V.npy")[1]
        matrix_path = L5 / "run-01/AII-csc.npz"
        pin(matrix_path, frozen)
        with np.load(matrix_path, allow_pickle=False) as z:
            A = sparse.csc_matrix((z["data"], z["indices"], z["indptr"]), shape=tuple(z["shape"])).tocsr()
        if A.shape != (len(I), len(I)):
            raise ValueError("saved AII shape")
        checks = {
            "full_delta_rhs": check(delta_full, d4),
            "interior_rhs": check(rhs_I, d4[I]),
            "boundary_delta_exact_zero": {"pass": bool(np.all(delta[B] == 0) and np.array_equal(field[B], gB))},
            "interior_delta": check(delta[I], x),
            "field_S2_plus_delta": check(field, field2 + delta),
        }
        calc_residual = A @ x - rhs_I
        operation_scale = float(np.max(abs(A) @ abs(x) + abs(rhs_I)))
        checks["saved_residual"] = check(residual, calc_residual, extra=operation_scale)
        normA = float(np.max(np.asarray(abs(A).sum(axis=1)).ravel()))
        eta = float(np.max(abs(calc_residual)) / (normA * float(np.max(abs(x))) + float(np.max(abs(rhs_I)))))
        out["actual"]["independent_eta"] = eta
        checks["eta_gate"] = {"pass": bool(eta <= 128*EPS)}
        deltaV = new("run-01", "delta_source_V.npy")
        V3 = new("run-01", "V_S3_V.npy")
        V3field = new("run-01", "V_S3_from_field_V.npy")
        compensated_deltaV = np.array([am.compensated_complex_sum(trace[r, I]*x) for r in range(2)])
        compensated_fieldV = np.array([am.compensated_complex_sum(trace[r]*field) for r in range(2)])
        trace_scale = float(np.sum(np.abs(trace[:, I]*x[None, :])))
        checks["trace_deltaV"] = check(deltaV, compensated_deltaV, extra=trace_scale)
        checks["V2_plus_deltaV"] = check(V3, V2+deltaV)
        checks["trace_fullV"] = check(V3field, compensated_fieldV, extra=float(np.sum(np.abs(trace*field[None, :]))))
        checks["field_voltage_identity"] = check(V3, compensated_fieldV, extra=float(np.sum(np.abs(trace*field[None, :]))))
        errors = np.abs(V3-H)/np.abs(H)
        out["actual"]["relative_receiver_error"] = errors.tolist()
        out["actual"]["fixed_receiver_gate"] = .01
        out["actual"]["physical_screen_pass"] = bool(np.all(errors <= .01))
        out["actual"]["checks"] = checks
        all_ok &= all(v["pass"] for v in checks.values())
    out["array_audit_pass"] = bool(all_ok)
    with (OUT / "audit.json").open("x", encoding="utf-8") as f:
        json.dump(out, f, indent=2, allow_nan=False)
        f.write("\n")
    print(json.dumps({"array_audit_pass": out["array_audit_pass"], "pair_source": pair_s, "pair_difference": pair_d, "relative_receiver_error": out["actual"].get("relative_receiver_error")}), flush=True)
    return 0 if all_ok else 3


if __name__ == "__main__":
    raise SystemExit(main())
