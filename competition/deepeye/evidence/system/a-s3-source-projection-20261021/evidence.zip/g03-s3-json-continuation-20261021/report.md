# S3 JSON successor: projection passed; one source correction still fails 1%

This selected successor completed the previously unfinished S3 experiment. The fixed receiver screen failed. The original S3 preflight/RED/JSON failure, its 40-byte partial receipt and failed native terminal remain unchanged in the predecessor directory.

Only two source replacements were selected and independently accepted by the main: explicit `bool(absolute<=bound)` for the manufactured control receipt, and the launcher work-ID assertion. The four other scientific/worker files are byte-identical to the frozen predecessor. No encoder monkeypatch, math, threshold, source geometry, budget or old evidence was changed. `exact-source-diff.patch`, `origin-source-map.json`, `frozen-source-pins.json` and `main-source-review.json` retain this binding. Existing RED was reused without execution.

## Completed new stages

| Stage | Original terminal | Measured elapsed | Original held handles |
|---|---|---:|---:|
| Manufactured controls | success / exit0 | 0.812 s | 3/3 signaled |
| Physical per-cell projection | success / exit0 | 0.750 s | 3/3 signaled |
| One source-difference solve | failed / exit2: fixed 1% receiver screen | 57.453 s | 3/3 signaled |

All nine held handles are signaled and all source readbacks are unchanged. The sampled guard did not stop these stages for time/resource limits; measured elapsed is not a hard wall-time guarantee. Fresh available physical memory was **14,098,173,952 B** against **10,737,418,240 B**. Actual peak job memory was **3,349,176,320 B**, below the unchanged 5 GiB job cap. BLAS was checked at one thread before every stage and after the successful controls/projection stages; the final comparison failure retains its before-check, without a new post-failure runtime probe.

Manufactured controls now produced complete JSON receipts and arrays. At both fixed Gauss orders 2 and 4, constant complex-current local V/4 loads and the saved diagonal-mass constant-field action agreed (maximum global discrepancy <=1.170e-24 A m). Independently integrated affine polynomial global loads differed by <=1.615e-20 A m, within the frozen explicit polynomial/summation scales. Compatible weak charge and exact polynomial charge agreed; the manufactured charge is nonzero, about -5.570068359375e-7, and was not projected to zero. Signed-current / single `-i omega`, duplicate-cell, wrong mapping, wrong circulation normalization, nonpositive-cell and transmitter-support-overlap controls all passed or genuinely rejected the selected negative case.

## New physical source data

The physical stage integrated 64 frozen cells with dimensionless bilinear edge test functions, fixed Gauss **2/4**, **512/4096 new physical targets**, fixed finite-coil transmitter **256** points and chunks <=128. It reused the pinned primary implementation only at these new cell targets. No old primary edge/global-volume/receiver targets, H/E/boundary oracle, material mass, C or A construction was repeated. Potential global source support was exactly the same 300 interior edges; source B entries were exactly zero. Geometry separation lower bound was 0.1878732187 m.

| New pair | Relative infinity change | Absolute infinity change | Frozen gate |
|---|---:|---:|---:|
| Projected weak source `s2` vs `s4` | 3.149261716080581e-5 | 1.822360366133425e-15 A m | 0.001 |
| New full source-difference RHS `delta_b2` vs `delta_b4` | 6.410996856396376e-4 | 2.29004557537194e-8 A m/s | 0.001 |

Both pair denominators were stable above the saved explicit rounding-sum thresholds; no denominator floor was introduced. Physical weak-charge identities differed by 1.2924697071141057e-26 at each order, below the recorded thresholds around 7.9996e-23. This checks compatibility, not physical convergence certification.

The old RHS used was precisely the **full 63,250-entry** S1 `new_derivative_RHS.npy`. The worker formed `delta_b=(-i omega*s4)-b_S1_full` and persisted it before selecting I. It did not subtract the reduced RHS or reconstruct the old diagonal-mass/edge-primary source. Boundary differences were exactly zero.

## One conditional new solve and actual response

After the controls, pair gates and fresh memory check passed, the worker loaded exact saved L5 AII (54,418²; 682,554 nonzeros), performed one COLAMD factorization and one source-difference RHS solve, and added that correction once to the frozen S2 field. `deltaE_B=0`, and both the baseline and new corrected B values equal saved S2 gB exactly. No second `-AIB*gB`, new boundary integration, original wire residual or new full operator was added.

New backward eta = **4.187683382636219e-18**, passing unchanged **2.842170943040401e-14**. `V_S2 + deltaV_source` and the saved receiver trace applied to the new full field agreed within the explicit floating-sum threshold.

All voltages are derivatives per unit dimensionless contrast strength at zero, not finite-strength heterogeneous responses.

| Rx | Source correction delta V | Final S3 derivative V | S3 minus saved H V | Absolute discrepancy V | Relative discrepancy |
|---|---|---|---|---:|---:|
| 1 | -2.311229698609551e-13 - i 1.0237997504235145e-12 | 3.161014941931209e-11 + i 1.404628130500722e-10 | -4.8520116859731e-12 - i 2.156357476373574e-11 | 2.210270965271092e-11 | **13.3085987173%** |
| 2 | 1.685476616651734e-14 + i 7.484382089722283e-14 | -1.5008219200067605e-12 - i 6.660880138805725e-12 | -4.6578514347026594e-14 - i 2.072556555287112e-13 | 2.124251980048788e-13 | **3.2110499868%** |

Both exceed the unchanged **1%** diagnostic. Compared with the preserved S2 values (12.6766301761% / 4.3707331497%), Rx1 became slightly worse and Rx2 improved. This is a measured influence of the chosen source representation on the fixed operator/boundary, not a unique allocation of the remaining error or a proof that the old S1 source was defective. No improvement was assumed. The process intentionally exited 2 after saving its result and arrays, and its original failed terminal and `SystemExit(2)` evidence are retained. No extra solve, quadrature, mesh, ordering, tolerance or automatic retry followed.

The 57 frozen input/source pins, local cell receipts, new primary/current/load arrays, full old/new/difference RHS binding, residual/correction/updated field, voltages and original process evidence are available for independent **array-only** review. No tests, Green evaluations or factorization need be replayed for that review.

Physical accuracy and noise/calibration remain **unqualified**; finite tau, G03, R03 and all29 formal acceptance remain `not_run`/open. H01–H15 and requirements SHA `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` are unchanged. There were no dependency, product, service, UI, GPU, board, peer or network changes. Native completion is accurately failed with `result=null`; its actual response and the exact text supplied to it are saved separately.
