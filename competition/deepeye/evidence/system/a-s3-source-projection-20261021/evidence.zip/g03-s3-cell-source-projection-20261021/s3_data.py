"""Pinned input loading and explicit cell/edge geometry, no mesh/operator construction."""
import hashlib,json,math
from pathlib import Path
import numpy as np
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
S1=D.parent/'g03-s1-cache-path-continuation-20261021';S2=D.parent/'g03-s2-boundary-correction-20261021';L5=D.parent/'g03-l5-propagation-z-refinement-20261021'
EPS=np.finfo(float).eps
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def array(p,x):
    with p.open('xb') as f:np.save(f,x,allow_pickle=False)
def pairs(x):return [[float(complex(v).real),float(complex(v).imag)] for v in np.asarray(x).ravel()]
def load_old(p):
    a=read(D/'assignment.json');pins=dict(read(ROOT/a['source_pins'])['files']);pins.update(read(ROOT/a['reuse_inputs'])['files']);pin=pins[p.relative_to(ROOT).as_posix()]
    if p.stat().st_size!=pin['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=pin['sha256']:raise ValueError('frozen input pin')
    value=np.load(p,allow_pickle=False)
    if not np.all(np.isfinite(value)):raise ValueError('nonfinite old array')
    return value
def validate_cell_ids(ids,expected):
    if ids.shape!=(64,) or not np.issubdtype(ids.dtype,np.integer) or len(np.unique(ids))!=64 or not np.array_equal(ids,expected):raise ValueError('contrast cell IDs must be exact ordered unique64')
def source_separation(bounds,p):
    normal=np.array(p['Tx_normal_unnormalized'],dtype=float);normal/=np.linalg.norm(normal)
    extent=p['Tx_radius_m']*np.sqrt(1-normal*normal);center=np.array(p['Tx_center_m'])
    low=bounds[:,0].min(axis=0);high=bounds[:,1].max(axis=0)
    gap=np.maximum(np.maximum(low-(center+extent),(center-extent)-high),0.)
    distance=float(np.linalg.norm(gap))
    if distance<=1e-12:raise ValueError('cell source box intersects or unresolved at transmitter support AABB')
    return distance
def validate_map(bounds,mapping,starts,ends):
    slot=0
    for axis in range(3):
        transverse=[j for j in range(3) if j!=axis]
        for second in (0,1):
            for first in (0,1):
                begin=bounds[:,0].copy();finish=bounds[:,0].copy();finish[:,axis]=bounds[:,1,axis]
                for j,bit in zip(transverse,(first,second)):
                    begin[:,j]=bounds[:,bit,j];finish[:,j]=bounds[:,bit,j]
                if np.any(mapping[:,slot]<0) or np.any(mapping[:,slot]>=63250):raise ValueError('global edge ID out of range')
                if np.max(abs(starts[mapping[:,slot]]-begin))>128*EPS or np.max(abs(ends[mapping[:,slot]]-finish))>128*EPS:raise ValueError('local/global edge mapping, scaling or orientation mismatch')
                slot+=1
def fixtures(p):
    a=read(L5/'assignment.json');x=np.array(a['level']['x_nodes_m']);z=np.array(a['z_nodes_m']);nodes=[x,x,z]
    low=np.array(p['contrast_box_min_m']);high=np.array(p['contrast_box_max_m']);expected=[]
    for k in range(34):
        for j in range(24):
            for i in range(24):
                index=(i,j,k)
                if all(nodes[axis][v]>=low[axis]-1e-12 and nodes[axis][v+1]<=high[axis]+1e-12 for axis,v in enumerate(index)):expected.append(i+24*(j+24*k))
    ids=load_old(S1/'controls-01/contrast_cell_indices.npy');validate_cell_ids(ids,np.array(expected,dtype=np.int64))
    sub=np.array(np.unravel_index(ids,(24,24,34),order='F')).T
    bounds=np.array([[[nodes[j][cell[j]] for j in range(3)],[nodes[j][cell[j]+1] for j in range(3)]] for cell in sub])
    if not np.allclose(bounds[:,0].min(axis=0),low,rtol=0,atol=128*EPS) or not np.allclose(bounds[:,1].max(axis=0),high,rtol=0,atol=128*EPS):raise ValueError('box coverage bounds')
    volumes=np.prod(bounds[:,1]-bounds[:,0],axis=1)
    if abs(np.sum(volumes)-np.prod(high-low))>128*EPS*np.prod(high-low):raise ValueError('box volume coverage')
    shapes=[(24,25,35),(25,24,35),(25,25,34)];offsets=[0,21000,42000];mapping=np.empty((64,12),dtype=np.int64);slot=0
    for axis in range(3):
        transverse=[j for j in range(3) if j!=axis]
        for second in (0,1):
            for first in (0,1):
                edge=sub.copy()
                for j,bit in zip(transverse,(first,second)):edge[:,j]+=bit
                mapping[:,slot]=offsets[axis]+np.ravel_multi_index(tuple(edge.T),shapes[axis],order='F');slot+=1
    starts=load_old(L5/'controls-01/edge_starts_m.npy');ends=load_old(L5/'controls-01/edge_ends_m.npy')
    if starts.shape!=(63250,3) or ends.shape!=starts.shape:raise ValueError('old edge shape')
    validate_map(bounds,mapping,starts,ends)
    support=np.unique(mapping);saved_support=load_old(S1/'controls-01/primary_support_indices.npy')
    if len(support)!=300 or not np.array_equal(support,saved_support):raise ValueError('potential source support differs')
    I=load_old(S1/'controls-01/interior_indices.npy');B=load_old(S1/'controls-01/boundary_indices.npy')
    if I.shape!=(54418,) or B.shape!=(8832,) or not np.array_equal(np.sort(np.r_[I,B]),np.arange(63250)) or np.intersect1d(support,B).size:raise ValueError('source/order/boundary partition')
    axes=np.argmax(abs(ends-starts),axis=1);lengths=np.linalg.norm(ends-starts,axis=1)
    separation=source_separation(bounds,p)
    return {'cell_ids':ids,'bounds':bounds,'volumes':volumes,'edge_map':mapping,'support':support,'I':I,'B':B,'starts':starts,'ends':ends,'axes':axes,'lengths':lengths,'source_separation_lower_m':separation}
def phi(x):return x[...,0]*x[...,1]+.4*x[...,1]*x[...,2]+.2*x[...,2]*x[...,0]+np.prod(x,axis=-1)
def grad_phi(x):
    a,b,c=x[...,0],x[...,1],x[...,2]
    return np.stack((b+.2*c+b*c,a+.4*c+a*c,.4*b+.2*a+a*b),axis=-1)
def charge_identity(f,source,points,weights,current):
    support=f['support'];edges=(phi(f['ends'][support])-phi(f['starts'][support]))/f['lengths'][support]
    lhs=np.sum(edges*source[support]);terms=weights[:,:,None]*grad_phi(points)*current;rhs=np.sum(terms)
    # Include polynomial evaluation cancellation from phi at edge endpoints.
    node_scale=(abs(f['starts'][support,0]*f['starts'][support,1])+abs(f['ends'][support,0]*f['ends'][support,1])
        +.4*(abs(f['starts'][support,1]*f['starts'][support,2])+abs(f['ends'][support,1]*f['ends'][support,2]))
        +.2*(abs(f['starts'][support,2]*f['starts'][support,0])+abs(f['ends'][support,2]*f['ends'][support,0]))
        +abs(np.prod(f['starts'][support],axis=1))+abs(np.prod(f['ends'][support],axis=1)))
    scale=float(np.sum(abs(terms))+np.sum(abs(source[support])*node_scale/f['lengths'][support]))
    difference=float(abs(lhs-rhs));bound=128*EPS*scale
    return {'passed':bool(difference<=bound),'weak_charge_LHS':pairs([lhs]),'direct_gradient_volume_RHS':pairs([rhs]),'absolute_difference':difference,'absolute_sum_scale_including_phi_evaluation':scale,'roundoff_threshold':bound,'zero_charge_required':False}
def norm_pair(low,high,low_scale,high_scale):
    den=float(np.max(abs(high)));lo=float(np.max(abs(low)));bound_high=128*EPS*float(np.max(high_scale));bound_low=128*EPS*float(np.max(low_scale));absolute=float(np.max(abs(high-low)))
    stable=den>bound_high and lo>bound_low;relative=absolute/den if stable else None
    return {'passed':relative is not None and relative<=.001,'relative_inf':relative,'absolute_inf_difference':absolute,'high_inf':den,'low_inf':lo,'high_roundoff_sum_threshold':bound_high,'low_roundoff_sum_threshold':bound_low,'fixed_gate':.001,'near_cancellation':'stable' if stable else 'undefined_no_floor'}
