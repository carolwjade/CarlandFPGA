# S3 stopped at a manufactured-control serialization failure

The selected new native job is failed; no automatic retry or source repair followed the actual scientific stage failure. The independently reviewed frozen implementation is retained unchanged.

The first author launcher preflight originally referenced nonexistent support `projection.py`, before any stage or guard call. The main explicitly selected the preserved one-reference fix back to existing `boundary.py` (SHA `04cf7d53f3dbf1fca66aab05fe497ae193aab94a56ab4e0d36e81d1eb0a040fe`). Original launcher bytes, actual command traceback transcript, no-stage inventory and single-line diff remain separate evidence. This was not a replay of a scientific stage.

After that authorized fix, the **first genuine new RED** invoked the missing cell projector with a constant-current brick fixture and raised the expected `NotImplementedError`. Its original failed/exit1 terminal measured 0.187 s, with all three original held handles signaled. The projector/test author RED snapshots are retained. The six completed source files and 57 input pins were frozen and independently reviewed with a conditional static PASS before GREEN was started.

The only new GREEN controls process then failed/exit1 after **0.797 s**, with all three original held handles signaled and source readback unchanged. It had entered the new Gauss2 manufactured calculations, but stopped at the first call to save `manufactured_g2.json`, before the program's manufactured-pass assertions or array receipts. The raw exception is:

```
TypeError: Object of type bool is not JSON serializable
```

The failure traceback identifies `test_projection.py:76` -> `s3_data.save` -> the standard JSON encoder. Static source diagnosis: `check_roundoff` returns `passed=absolute<=bound`, where `bound` is computed with NumPy `EPS`. This comparison returns a NumPy boolean scalar, and the evidence writer does not convert it to a JSON-native bool. This is an output-harness failure, not a reported numerical discrepancy. The original **40-byte incomplete JSON** is preserved unchanged, along with `failure.json`, stderr, original held terminals and pins. No numeric outcome was recovered by rerunning or recomputing the control, and no manufacturing-pass claim is made.

The actual observations are therefore:

* New projector RED: expected missing-implementation failure observed and retained.
* New manufactured GREEN: **failed while serializing the first Gauss2 record**; no passed control result.
* New 512/4096 physical target evaluations: `not_run`.
* Fixed Gauss2/4 physical source/correction screens: `not_run`.
* New source-difference RHS solve/factorization: `not_run`.
* Old primary/global-volume/edge targets, H/E/boundary integrals, C/A/mass assembly, original RHS solve, ROCm/GPU/board/UI/service/network/product actions: none rerun or modified.

Both actual bounded trees are fully stopped: six of six original held handles are signaled. The preflight-only ordinary launcher created no bounded stage or held handles. The old S1/S2 failed native jobs, numerical results, S2 gB and all old passed controls remain intact. Physical accuracy, source noise/calibration, finite tau, G03 and all29 remain open. H01–H15 and SHA `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` are unchanged.

The saved-source manifest records the unmodified implementation and partial failure artifacts. Any continuation of JSON-only serialization must be separately selected by the main; this failed job is not resumed. The actual native failed response is retained with `result=null` semantics and its persisted error; the supplied explanatory text is saved separately as `final-result.txt`.
