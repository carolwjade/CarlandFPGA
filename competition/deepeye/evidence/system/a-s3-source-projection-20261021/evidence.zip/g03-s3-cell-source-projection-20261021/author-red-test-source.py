"""New source-projection control specification, before implementation."""
import numpy as np
import s3_projector as projector
def new_RED_constant_brick():
    bounds=np.array([[[.025,.025,-.05],[.03125,.03125,-.03125]]])
    mapping=np.arange(12)[None,:]
    J=np.broadcast_to(np.array([1.,2.,3.]),(1,8,3))
    source,local,scale=projector.project(bounds,mapping,J,2,12)
    volume=np.prod(bounds[0,1]-bounds[0,0]);expected=np.repeat([1.,2.,3.],4)*volume/4
    if not np.all(abs(source-expected)<=128*np.finfo(float).eps*(abs(source)+abs(expected))):raise AssertionError('new constant brick normalization')
