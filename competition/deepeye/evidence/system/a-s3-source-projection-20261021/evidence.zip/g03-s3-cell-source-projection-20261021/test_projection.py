"""New source-projection control specification, before implementation."""
import numpy as np
import s3_projector as projector
def new_RED_constant_brick():
    bounds=np.array([[[.025,.025,-.05],[.03125,.03125,-.03125]]])
    mapping=np.arange(12)[None,:]
    J=np.broadcast_to(np.array([1.,2.,3.]),(1,8,3))
    source,local,scale=projector.project(bounds,mapping,J,2,12)
    volume=np.prod(bounds[0,1]-bounds[0,0]);expected=np.repeat([1.,2.,3.],4)*volume/4
    if not np.all(abs(source-expected)<=128*np.finfo(float).eps*(abs(source)+abs(expected))):raise AssertionError('new constant brick normalization')

def multiply(a,b):
    out={}
    for i,u in a.items():
        for j,v in b.items():
            key=tuple(i[k]+j[k] for k in range(3));out[key]=out.get(key,0.)+u*v
    return out
def integral(poly,bounds):
    low,high=bounds;value=0.;scale=0.;volume=float(np.prod(high-low))
    for power,coefficient in poly.items():
        term=coefficient
        for j,n in enumerate(power):term*=(high[j]**(n+1)-low[j]**(n+1))/(n+1)
        value+=term
        scale+=abs(coefficient)*volume*np.prod([max(abs(low[j]),abs(high[j]))**n for j,n in enumerate(power)])
    return value,float(scale)
def affine_expected(f):
    # Independent analytic polynomial integration: never uses production quadrature.
    J=[{(0,0,0):1.,(1,0,0):1.,(0,1,0):2.},{(0,0,0):-2.,(0,1,0):1.,(0,0,1):-1.},{(0,0,0):.5,(0,0,1):2.,(1,0,0):1.}]
    derivative=[{(0,1,0):1.,(0,0,1):.2,(0,1,1):1.},{(1,0,0):1.,(0,0,1):.4,(1,0,1):1.},{(0,1,0):.4,(1,0,0):.2,(1,1,0):1.}]
    local=np.empty((64,12));source=np.zeros(63250);poly_scale=0.;charge=0.;charge_scale=0.
    for k,bounds in enumerate(f['bounds']):
        slot=0
        for axis in range(3):
            transverse=[j for j in range(3) if j!=axis]
            for second in (0,1):
                for first in (0,1):
                    shape={(0,0,0):1.}
                    for j,bit in zip(transverse,(first,second)):
                        lo,hi=bounds[:,j];h=hi-lo;power=tuple(1 if c==j else 0 for c in range(3))
                        factor={(0,0,0):-lo/h,power:1/h} if bit else {(0,0,0):hi/h,power:-1/h}
                        shape=multiply(shape,factor)
                    value,scale=integral(multiply(shape,J[axis]),bounds)
                    local[k,slot]=value;source[f['edge_map'][k,slot]]+=value;poly_scale+=scale;slot+=1
        for component in range(3):
            value,scale=integral(multiply(derivative[component],J[component]),bounds);charge+=value;charge_scale+=scale
    return local,source,float(poly_scale),float(charge),float(charge_scale)
def check_roundoff(actual,expected,extra_scale=0.):
    import s3_data as d
    scale=float(np.sum(abs(actual))+np.sum(abs(expected))+extra_scale)
    absolute=float(np.max(abs(np.asarray(actual)-expected)));bound=128*d.EPS*scale
    return {'passed':absolute<=bound,'max_absolute_difference':absolute,'absolute_sum_scale':scale,'roundoff_threshold':bound,'polynomial_evaluation_scale':float(extra_scale)}
def run(stage,a):
    import math
    import s3_data as d
    p=a['inputs'];f=d.fixtures(p);omega=2*math.pi*p['frequency_Hz'];zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm']
    E0=np.array([complex(*v) for v in a['fixed_new_parameters']['constant_E_complex_pairs']]);J0=zeta*E0
    mass=d.load_old(d.S1/'controls-01/delta_mass_diag_Sm2.npy')
    if mass.shape!=(63250,):raise ValueError('saved contrast mass diagonal shape')
    old_expected=mass*E0[f['axes']]
    local_expected=f['volumes'][:,None]*np.repeat(J0,4)[None,:]/4
    affine_local,affine_source,polynomial_scale,exact_charge,charge_scale=affine_expected(f)
    rows=[]
    for order in (2,4):
        points,weights=projector.quadrature(f['bounds'],order)
        constant=np.broadcast_to(J0,points.shape)
        source,local,absolute=projector.project(f['bounds'],f['edge_map'],constant,order,63250)
        const_local=check_roundoff(local,local_expected);const_global=check_roundoff(source,old_expected)
        X,Y,Z=points[...,0],points[...,1],points[...,2]
        current=np.stack((1+X+2*Y,-2+Y-Z,.5+2*Z+X),axis=-1)
        affine,local_affine,affine_absolute=projector.project(f['bounds'],f['edge_map'],current,order,63250)
        affine_local_check=check_roundoff(local_affine,affine_local,polynomial_scale)
        affine_global_check=check_roundoff(affine,affine_source,polynomial_scale)
        identity=d.charge_identity(f,affine,points,weights,current)
        support=f['support'];gradient=(d.phi(f['ends'][support])-d.phi(f['starts'][support]))/f['lengths'][support]
        charge_observed=np.sum(gradient*affine[support]);charge_check=check_roundoff(np.array([charge_observed]),np.array([exact_charge]),charge_scale+identity['absolute_sum_scale_including_phi_evaluation'])
        d.save(stage/f'manufactured_g{order}.json',{'constant_local':const_local,'constant_vs_saved_mass_action':const_global,'affine_local_analytic':affine_local_check,'affine_global_analytic':affine_global_check,'compatible_charge_identity':identity,'analytic_charge':charge_check})
        if not all(row['passed'] for row in (const_local,const_global,affine_local_check,affine_global_check,identity,charge_check)):raise AssertionError('new constant/affine/charge manufactured control failed')
        for name,value in {'constant_source_Am':source,'constant_local_Am':local,'affine_source_Am':affine,'affine_local_Am':local_affine,'independent_affine_expected_source_Am':affine_source}.items():d.array(stage/f'g{order}_{name}.npy',value)
        rows.append({'Gauss_order':order,'constant_local':const_local,'constant_vs_saved_mass_action':const_global,'affine_local_analytic':affine_local_check,'affine_global_analytic':affine_global_check,'compatible_charge_identity':identity,'analytic_charge':charge_check,'analytic_charge_value':exact_charge,'observed_charge_value':d.pairs([charge_observed])})
    points,weights=projector.quadrature(f['bounds'],2)
    positive=np.zeros_like(points);positive[:,:,0]=1
    pos,positive_local,absolute=projector.project(f['bounds'],f['edge_map'],positive,2,63250)
    neg,_,_=projector.project(f['bounds'],f['edge_map'],-positive,2,63250)
    orientation=check_roundoff(neg,-pos)
    b=-1j*omega*pos
    if not orientation['passed'] or not np.all(positive_local[:,:4].real>0) or not np.all(positive_local[:,4:]==0) or not np.all(b[pos!=0].imag<0) or not np.all(b.real==0):raise AssertionError('weak load orientation/single -iomega sign')
    bad=f['cell_ids'].copy();bad[1]=bad[0]
    try:d.validate_cell_ids(bad,f['cell_ids']);raise AssertionError('duplicate not rejected')
    except ValueError:pass
    badmap=f['edge_map'].copy();badmap[:,[0,1]]=badmap[:,[1,0]]
    try:d.validate_map(f['bounds'],badmap,f['starts'],f['ends']);raise AssertionError('wrong edge map not rejected')
    except ValueError:pass
    wrong_scaled=local_expected/np.repeat(f['bounds'][:,1]-f['bounds'][:,0],4,axis=1)
    normalization_negative=check_roundoff(wrong_scaled,local_expected)
    if normalization_negative['passed']:raise AssertionError('circulation-scaling mutant was not rejected')
    try:projector.quadrature(np.zeros((1,2,3)),2);raise AssertionError('zero cell not rejected')
    except ValueError:pass
    center=np.array(p['Tx_center_m']);radius=p['Tx_radius_m']
    try:d.source_separation(np.array([[center-radius,center+radius]]),p);raise AssertionError('source-overlap box not rejected')
    except ValueError:pass
    for name,value in {'cell_ids':f['cell_ids'],'cell_bounds_m':f['bounds'],'cell_volumes_m3':f['volumes'],'cell_edge_map':f['edge_map'],'potential_support':f['support'],'independent_affine_expected_local_Am':affine_local}.items():d.array(stage/(name+'.npy'),value)
    return {'status':'controls_pass','orders':rows,'orientation_sign':orientation,'duplicate_cell_rejected':True,'wrong_edge_map_rejected':True,'wrong_circulation_normalization_screen_rejected':not normalization_negative['passed'],'normalization_negative':normalization_negative,'nonpositive_cell_rejected':True,'source_support_overlap_rejected':True,'source_separation_lower_m':f['source_separation_lower_m'],'contrast_cells':64,'potential_edge_support':300,'new_primary_evaluations':0,'C_A_mass_assemblies':0,'old_tests_repeated':False}
