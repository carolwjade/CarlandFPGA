"""New S3 projection API, author RED stub."""
def project(bounds, edge_map, values, order, n_edges):
    raise NotImplementedError('S3 cell-volume projector not implemented')
