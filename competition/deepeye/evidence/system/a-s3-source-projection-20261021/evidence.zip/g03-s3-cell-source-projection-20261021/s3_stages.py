"""S3 only: manufactured load checks, new per-cell projection, one source delta solve."""
import gc,hashlib,math,sys,warnings
import numpy as np
import s3_data as d
import s3_projector as projector
def controls(stage,a):
    import test_projection
    result=test_projection.run(stage,a);d.save(stage/'result.json',result);return result
def projection(stage,a):
    p=a['inputs'];f=d.fixtures(p);omega=2*math.pi*p['frequency_Hz'];zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm']
    old_full=d.load_old(d.S1/'run-01/new_derivative_RHS.npy')
    if old_full.shape!=(63250,) or not np.iscomplexobj(old_full) or np.any(old_full[f['B']]!=0):raise ValueError('must use full saved S1 RHS with zero B')
    sys.path.insert(0,str(d.S1));import s1_geometry as geometry
    tx,_=geometry.selected_coils(p)
    sources=[];scales=[];differences=[];difference_scales=[];charges=[]
    for order,ntarget in [(2,512),(4,4096)]:
        points,weights=projector.quadrature(f['bounds'],order)
        if points.shape!=(64,order**3,3) or points.reshape(-1,3).shape[0]!=ntarget:raise ValueError('new per-cell target count')
        primary=geometry.primary(points.reshape(-1,3),tx,p,256).reshape(points.shape)
        current=zeta*primary
        source,local,absolute=projector.project(f['bounds'],f['edge_map'],current,order,63250)
        outside=np.ones(63250,dtype=bool);outside[f['support']]=False
        if np.any(source[f['B']]!=0) or np.any(source[outside]!=0) or not np.all(np.isfinite(source)):raise ValueError('new load source support/boundary')
        charge=d.charge_identity(f,source,points,weights,current)
        new_rhs=-1j*omega*source;difference=new_rhs-old_full;sum_scale=omega*absolute+abs(old_full)
        for name,value in {'new_target_points_m':points,'new_target_weights_m3':weights,'primary_Vpm':primary,'equivalent_current_Apm2':current,'local_load_Am':local,'projected_source_Am':source,'projected_absolute_sum_Am':absolute,'projected_full_RHS':new_rhs,'source_difference_full_RHS':difference,'difference_absolute_sum_scale':sum_scale}.items():d.array(stage/f'g{order}_{name}.npy',value)
        d.save(stage/f'g{order}_charge_identity.json',charge)
        if not charge['passed']:raise AssertionError('physical new-load weak-charge identity failed')
        sources.append(source);scales.append(absolute);differences.append(difference);difference_scales.append(sum_scale);charges.append(charge)
    source_pair=d.norm_pair(sources[0],sources[1],scales[0],scales[1]);difference_pair=d.norm_pair(differences[0],differences[1],difference_scales[0],difference_scales[1])
    for name,value in {'cell_ids':f['cell_ids'],'cell_bounds_m':f['bounds'],'cell_volumes_m3':f['volumes'],'cell_edge_map':f['edge_map'],'potential_edge_support':f['support']}.items():d.array(stage/(name+'.npy'),value)
    passed=source_pair['passed'] and difference_pair['passed']
    result={'status':'projection_pass' if passed else 'projection_screen_failed','source_pair':source_pair,'source_difference_pair':difference_pair,'physical_weak_charge':charges,'cell_Gauss_orders':[2,4],'target_counts':[512,4096],'Tx_points_fixed':256,'source_separation_lower_m':f['source_separation_lower_m'],
        'contrast_cells':64,'potential_edge_support':300,'old_RHS_input':'full S1 run-01/new_derivative_RHS.npy; shape63250, not reduced','source_B_exact_zero':True,'old_H_E_boundary_integrations':0,'old_primary_targets_repeated':False,'C_A_mass_assemblies':0,'factorizations':0}
    d.save(stage/'result.json',result)
    if not passed:raise SystemExit(2)
    return result
def actual(stage,a):
    from scipy import sparse
    from scipy.sparse.linalg import splu
    f=d.fixtures(a['inputs']);I,B=f['I'],f['B']
    delta_full=np.load(d.D/'projection-01/g4_source_difference_full_RHS.npy',allow_pickle=False)
    if delta_full.shape!=(63250,) or not np.all(np.isfinite(delta_full)) or np.any(delta_full[B]!=0) or not np.any(delta_full!=0):raise ValueError('fine source correction full vector')
    # Full-source subtraction has already been persisted; only now select I.
    rhs=delta_full[I]
    S2field=d.load_old(d.S2/'run-01/corrected_derivative_Vpm.npy');V2=d.load_old(d.S2/'run-01/V_corrected_V.npy');gB=d.load_old(d.S2/'run-01/selected_gB_Vpm.npy')
    trace=d.load_old(d.S1/'controls-01/receiver_trace_m.npy');Href=d.load_old(d.S1/'oracle-01/Born_derivative_V.npy')[1]
    if S2field.shape!=(63250,) or V2.shape!=(2,) or gB.shape!=(8832,) or trace.shape!=(2,63250) or not np.array_equal(S2field[B],gB):raise ValueError('fixed S2 field/boundary or trace shape')
    matrix_path=d.L5/'run-01/AII-csc.npz';pin=d.read(d.ROOT/a['reuse_inputs'])['files'][matrix_path.relative_to(d.ROOT).as_posix()]
    if hashlib.sha256(matrix_path.read_bytes()).hexdigest()!=pin['sha256']:raise ValueError('saved AII pin')
    with np.load(matrix_path,allow_pickle=False) as z:A=sparse.csc_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
    if A.shape!=(54418,54418) or not np.all(np.isfinite(A.data)):raise ValueError('saved AII shape/finite')
    for name,value in {'source_correction_full_RHS':delta_full,'source_correction_interior_RHS':rhs}.items():d.array(stage/(name+'.npy'),value)
    d.save(stage/'pre-factorization.json',{'status':'new_source_difference_RHS_persisted','new_RHS_columns':1,'full_subtraction_before_I':True,'old_full_RHS':'S1/new_derivative_RHS.npy','AII_shape':A.shape,'AII_nnz':int(A.nnz),'factorization_started':False,'factorization_ordering':'COLAMD','S2_gB_exactly_preserved':True,'deltaE_B':'zero','C_A_mass_assemblies':0,'old_RHS_recomputed':False})
    with warnings.catch_warnings():
        warnings.simplefilter('error');lu=splu(A,permc_spec='COLAMD');x=lu.solve(rhs)
    del lu;gc.collect()
    residual=A@x-rhs;normA=float(np.max(np.asarray(abs(A).sum(axis=1)).ravel()))
    eta=float(np.max(abs(residual))/(normA*float(np.max(abs(x)))+float(np.max(abs(rhs)))))
    delta=np.zeros(63250,dtype=complex);delta[I]=x;corrected=S2field+delta
    if not np.array_equal(corrected[B],gB):raise ValueError('S2 boundary changed')
    deltaV=trace[:,I]@x;V3=V2+deltaV;from_field=trace@corrected
    identity_scale=np.sum(abs(trace*corrected[None,:]),axis=1)+abs(V2)+abs(deltaV)
    identity_bound=128*d.EPS*identity_scale;identity_difference=abs(from_field-V3)
    if np.any(identity_difference>identity_bound):raise ArithmeticError('new voltage update vs full field trace')
    den=abs(Href);roundoff=128*d.EPS*np.sum(abs(trace*corrected[None,:]),axis=1)
    stable=(den>roundoff)&(abs(V3)>roundoff)
    absolute=abs(V3-Href);relative=[float(absolute[r]/den[r]) if stable[r] else None for r in range(2)]
    for name,value in {'interior_source_correction_Vpm':x,'full_source_correction_Vpm':delta,'corrected_derivative_Vpm':corrected,'new_source_residual':residual,'V_S2_V':V2,'delta_source_V':deltaV,'V_S3_V':V3,'V_S3_from_field_V':from_field,'R_S2_V':V2-Href,'R_S3_V':V3-Href}.items():d.array(stage/(name+'.npy'),value)
    passed=math.isfinite(eta) and eta<=128*d.EPS and all(v is not None and v<=.01 for v in relative)
    result={'status':'one_source_correction_screens_pass' if passed else 'one_source_correction_screen_failed','new_RHS_columns':1,'factorizations':1,'C_A_mass_assemblies':0,'old_RHS_recomputed':False,'boundary_correction_added_again':False,'S2_gB_exactly_preserved':True,
        'backward_eta':eta,'backward_eta_gate':128*d.EPS,'V_S2_V':d.pairs(V2),'delta_source_V':d.pairs(deltaV),'V_S3_V':d.pairs(V3),'saved_H_V':d.pairs(Href),'R_S2_V':d.pairs(V2-Href),'R_S3_V':d.pairs(V3-Href),'absolute_error_V':absolute.tolist(),'relative_error':relative,'fixed_relative_gate':.01,'roundoff_denominator_threshold_V':roundoff.tolist(),
        'voltage_identity_absolute_V':identity_difference.tolist(),'voltage_identity_roundoff_bound_V':identity_bound.tolist(),'physical_accuracy':'unqualified','noise_gate':'unqualified_missing_sourced_budget','finite_tau':'not_run','G03':'not_run','all29_formal':'not_run'}
    d.save(stage/'result.json',result)
    if not passed:raise SystemExit(2)
    return result
