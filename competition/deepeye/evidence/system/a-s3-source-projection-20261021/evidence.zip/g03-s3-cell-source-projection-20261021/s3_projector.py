"""Cell-split dimensionless bilinear edge weak load; no material/operator assembly."""
import numpy as np
from numpy.polynomial.legendre import leggauss
def quadrature(bounds,order):
    bounds=np.asarray(bounds,dtype=float)
    if order not in (2,4) or bounds.ndim!=3 or bounds.shape[1:]!=(2,3) or not np.all(np.isfinite(bounds)):raise ValueError('cell quadrature shape/order')
    widths=bounds[:,1]-bounds[:,0]
    if not np.all(widths>0):raise ValueError('nonpositive cell widths')
    q,w=leggauss(order)
    reference=np.stack(np.meshgrid(q,q,q,indexing='ij'),axis=-1).reshape(-1,3)
    weights=(w[:,None,None]*w[None,:,None]*w[None,None,:]).ravel()
    points=bounds[:,0,None,:]+widths[:,None,:]*(reference[None,:,:]+1)/2
    physical_weights=np.prod(widths,axis=1)[:,None]*weights[None,:]/8
    return points,physical_weights
def project(bounds,edge_map,values,order,n_edges):
    points,weights=quadrature(bounds,order);values=np.asarray(values);edge_map=np.asarray(edge_map)
    if values.shape!=points.shape or edge_map.shape!=(len(bounds),12) or not np.issubdtype(edge_map.dtype,np.integer) or np.any(edge_map<0) or np.any(edge_map>=n_edges):raise ValueError('projector mapping/current shape')
    if not np.all(np.isfinite(values)):raise ValueError('nonfinite current')
    xi=(points-bounds[:,0,None,:])/(bounds[:,1]-bounds[:,0])[:,None,:]
    local=np.empty((len(bounds),12),dtype=complex);local_abs=np.empty((len(bounds),12));slot=0
    for axis in range(3):
        transverse=[j for j in range(3) if j!=axis]
        for second in (0,1):
            for first in (0,1):
                shape=np.ones(points.shape[:2])
                for j,bit in zip(transverse,(first,second)):shape*=xi[:,:,j] if bit else 1-xi[:,:,j]
                contribution=weights*shape*values[:,:,axis]
                local[:,slot]=np.sum(contribution,axis=1);local_abs[:,slot]=np.sum(abs(contribution),axis=1);slot+=1
    source=np.zeros(n_edges,dtype=complex);absolute_sum=np.zeros(n_edges)
    np.add.at(source,edge_map.ravel(),local.ravel());np.add.at(absolute_sum,edge_map.ravel(),local_abs.ravel())
    return source,local,absolute_sum
