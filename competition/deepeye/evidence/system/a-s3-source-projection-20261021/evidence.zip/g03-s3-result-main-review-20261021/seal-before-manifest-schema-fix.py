"""Seal reviewed S3 evidence without running numerical tests or solvers again."""
from datetime import datetime, timezone
from pathlib import Path
import asyncio
import hashlib
import json
import sys

D = Path(__file__).resolve().parent
O = D.parent
ROOT = D.parents[2]
sys.path.insert(0, str(ROOT))
from fpga_mesh.child_control import LocalControlFileClient
from fpga_mesh.project_cli import discovery

def read(path):
    return json.loads(path.read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, value):
    with (D/name).open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

specs = [
    ('g03-s3-cell-source-projection-20261021', 'child-7a47f23c3278418ea1a3f1d4beacebce', 'failed', '3297d3d9bd4474e5af29d30f3c42d11e4fc9e7bbd79d83502ce80d8ba02ade04'),
    ('g03-s3-independent-review-20261021', 'child-e656fcf47bef4f23a0262544cba3fdf9', 'completed', None),
    ('g03-s3-json-continuation-20261021', 'child-0be3050f77fe4bcf93857c08dfc58e02', 'failed', '4779df292d7a4450f96008ad4b16e1ad6055eb036a1ff40eed9448fc9a78e4db'),
    ('g03-s3-json-independent-review-20261021', 'child-fec30cc5c1ec4bc280a414d22a885ca6', 'completed', 'b02df0ced8273007f610b6695f8c2da97c7f005fada07dec71072cd1c6bec667'),
]

async def current_jobs():
    client = LocalControlFileClient(discovery(ROOT))
    return await asyncio.gather(*(client.call('job', {'job_id': row[1]}) for row in specs))

jobs = asyncio.run(current_jobs())
sealed = []
for (folder, job_id, expected, expected_hash), job in zip(specs, jobs):
    if 'content' in job:
        job = json.loads(next(x['text'] for x in job['content'] if x.get('type') == 'text'))
    assert job['job_id'] == job_id and job['status'] == expected and job['terminal'] and not job['stale']
    source = O/folder
    manifest_hash = sha(source/'manifest.json')
    assert expected_hash is None or manifest_hash == expected_hash
    files = read(source/'manifest.json')['files']
    for rel, pin in files.items():
        p = source/rel
        assert p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256'], (folder, rel)
    final_text_match = None
    if expected == 'failed':
        assert job['result'] is None and job['error']
    else:
        matches = [p for p in (source/'final-result.txt', source/'final-text.txt') if p.exists()]
        if matches:
            assert any(job['result']['text'].encode('utf-8') == p.read_bytes() for p in matches)
            final_text_match = True
    write(folder+'-native-readback.json', job)
    sealed.append({'folder': folder, 'manifest_sha256': manifest_hash, 'files': len(files),
                   'job_id': job_id, 'native_status': expected, 'native_error': job['error'],
                   'terminal': True, 'exact_final_text_match': final_text_match})

author = O/'g03-s3-json-continuation-20261021'
reviewer = O/'g03-s3-json-independent-review-20261021'
pins = read(author/'frozen-source-pins.json')
assert len(pins) == 57
for rel, pin in pins.items():
    p = ROOT/rel
    assert p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256'], rel
terminals = {}
for folder, code in [('controls-01', 0), ('projection-01', 0), ('run-01', 2)]:
    terminal = read(author/folder/'terminal.json')
    assert terminal['exit_code'] == code and terminal['all_processes_terminated']
    assert terminal['active_processes_final'] == 0 and len(terminal['held_members']) == 3
    assert all(x['signaled'] for x in terminal['held_members'])
    before_after = read(author/folder/'input-readback.json')
    assert before_after['unchanged'] and before_after['before'] == before_after['after'] == pins
    terminals[folder] = {k: terminal[k] for k in ('status', 'exit_code', 'seconds', 'peak_job_memory_bytes')}
independent_terminal = read(reviewer/'run-01/terminal.json')
assert independent_terminal['exit_code'] == 0 and independent_terminal['all_processes_terminated']
assert all(x['signaled'] for x in independent_terminal['held_members'])
audit = read(reviewer/'run-01/audit.json')
actual = read(author/'run-01/result.json')
assert audit['array_audit_pass'] and not audit['actual']['physical_screen_pass']
assert actual['fixed_relative_gate'] == audit['actual']['fixed_receiver_gate'] == .01
assert actual['relative_error'] == audit['actual']['relative_receiver_error']
assert actual['backward_eta'] == audit['actual']['independent_eta']
for value, reference, threshold, expected in zip(actual['V_S3_V'], actual['saved_H_V'],
        actual['roundoff_denominator_threshold_V'], actual['relative_error']):
    v, h = complex(*value), complex(*reference)
    assert abs(v) > threshold and abs(h) > threshold
    assert abs(abs(v-h)/abs(h)-expected) < 1e-14
assert actual['S2_gB_exactly_preserved'] and not actual['boundary_correction_added_again']

result = {'utc': datetime.now(timezone.utc).isoformat(), 'status': 'ACCEPT_NEW_S3_EVIDENCE_ONLY',
          'sealed': sealed, 'frozen_inputs_verified': 57, 'author_terminals': terminals,
          'independent_audit_terminal': {k: independent_terminal[k] for k in ('status', 'exit_code', 'seconds', 'peak_job_memory_bytes')},
          'source_pair': audit['pair_source'], 'source_difference_pair': audit['pair_difference'],
          'new_corrected_accuracy_screen_pass': False, 'receiver_relative_errors': actual['relative_error'],
          'backward_eta': actual['backward_eta'], 'resolved_denominators': True,
          'root_review': 'Read exact source diff and independent audit implementation; verified sealed bytes, actual original native states, all stage terminals, input readbacks and reported scalar reductions.',
          'no_new_array_audit_or_primary_or_solve_in_root': True,
          'old_test_groups_repeated': 0, 'prior_failure_preserved': True,
          'next_scientific_work': 'No additional solve selected; remaining error cause is not isolated.',
          'physical_accuracy': 'unqualified', 'noise_gate': 'unqualified', 'finite_tau': 'not_run',
          'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run'}
write('review.json', result)
print(json.dumps({'status': result['status'], 'manifests': len(sealed), 'receiver_relative_errors': result['receiver_relative_errors'], 'old_test_groups_repeated': 0}))
