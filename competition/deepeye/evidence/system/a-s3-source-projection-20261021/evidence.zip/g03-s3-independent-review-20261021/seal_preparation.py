"""Public hash manifest for the independent review's preparation files."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
skip = {"assignment.json", "lease.private.json", "reserve-request.json", "reserve.stderr.txt", "manifest.json"}
files = []
for p in sorted(root.rglob("*")):
    if p.is_file() and p.name not in skip:
        data = p.read_bytes()
        files.append({"path": p.relative_to(root).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
manifest = {"work_id": "A-G03-S3-INDEPENDENT-REVIEW-20261021-v1", "status": "author_failure_evidence_review_completed_terminal", "requirements_sha256": "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804", "files": files}
(root / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(len(files))
