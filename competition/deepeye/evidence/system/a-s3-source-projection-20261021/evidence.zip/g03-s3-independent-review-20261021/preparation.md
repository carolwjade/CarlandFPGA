# Independent S3 review preparation — frozen source reviewed, awaiting author stages

Update after initial preparation: the author froze six source files and 57 inherited inputs in `frozen-source-pins.json`, SHA-256 `bfcd8f3a67f2ae3a9f7f431a0bc4f758486cfc37fa98036899fdab41a23e23cc`. Six source hashes matched. `static-review.json` records a conditional static pass with no source-level blocker. Earlier language below describes the pre-freeze snapshot; no controls/projection/actual stage terminal has yet been supplied. Saved-array and execution claims remain open.

The native lease for `A-G03-S3-INDEPENDENT-REVIEW-20261021-v1` validated with `execution_allowed=true`. The selected S3 design is byte-pinned at SHA-256 `38e28d9dea6dde4c7a1376fc0c511df96cc63dbb59376a05038aa78211a24e82`. The active generation-2 transfer and H01–H15 contract SHA-256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` remain the task boundary. This is preparation, **not** an S3 result or native completion.

## Current read-only source state

The author's original new RED stage has a retained `terminal.json` with exit code 1, `all_processes_terminated=true`, and a traceback ending in the intentional `NotImplementedError` projector stub. The author has since begun changing `s3_projector.py` (one observed in-flight read: 2,137 bytes, SHA-256 `c35722a768f23ec7d69d6eeee3f2d92392acc4763b4ee171077f143adbf33bd3`). That is **not** a frozen source pin. No controls/projection/actual stage terminal or author freeze message has been supplied to this reviewer. The pre-RED launcher failure is preserved separately as a preflight failure before guard/stage invocation, not science RED.

The current `run_s3.py` snapshot imports `win_job.py` from `r02-amd-wheel-acquisition-20261021` (SHA-256 `c997e69b7439776fdaf63cd3dc8235e3448ef26556e69a980b2d9e9315610f59`); that is the separately reviewed extended guard for the author's 90-second scientific stage. This review assignment names `r02-transient-quota-fix-20261021/win_job.py` (SHA-256 `80cc41fd629bc3618b50c88fbd97332ec14cdd8cbaf8f927f0235390664cb77d`) for this reviewer's shorter 25-second array audit. The director resolved the distinction; no guard change or old guard test is needed.

The selected installed `discretize` code defines nodal gradient as incidence divided by edge lengths and curl as face-area inverse times face incidence times edge lengths. Its SimPEG utility defines the local edge weights as dimensionless bilinear transverse functions and the weak load as `∫W·J dV`. This supports edge-average normalization and no extra edge length, material mass, or second `-iω`. The author's in-flight projector uses cell Gauss orders 2/4 and dimensionless factors, but edge-map ordering, actual saved geometry and full source/solve path require a frozen review.

## Independent analytic oracle prepared

`audit_math.py` contains no author import, Green/source evaluation, quadrature, sparse matrix construction, or solve. For a cell of volume `V`, each local constant parallel current contributes `V J_axis / 4`. For the selected affine `J=(1+x+2y,-2+y-z,0.5+2z+x)`, use independent edge endpoint geometry and weighted transverse face coordinates `lo+h/3` or `lo+2h/3`:

* x edge: `V/4 * (1+x_mid+2*y_weighted)`;
* y edge: `V/4 * (-2+y_mid-z_weighted)`;
* z edge: `V/4 * (0.5+2*z_mid+x_weighted)`.

The separate weak-charge oracle expands `∇phi·J`, where `phi=xy+0.4yz+0.2zx+xyz`, into monomials and integrates each over the cell using `(b^(n+1)-a^(n+1))/(n+1)`. It does not call the author's projector, quadrature or scatter. The future audit will independently identify each of the 12 oriented cell edges from saved L5 endpoints/bounds, not assume the author's local slot order. It will compare per-cell loads, shared-edge scatter and `(Gphi)^T s` against these analytic values; the transpose is bilinear, without conjugation. Zero weak charge is **not** expected at the contrast boundary.

## Single bounded array audit after freeze

Wait for an explicit message with frozen source/input hashes and original stage terminals. Then bind the exact saved per-cell bounds, edge IDs, quadrature weights, primary/current/local loads, assembled `s2/s4`, full saved S1 RHS, and (if reached) S2 field/trace, `gB`, delta solution and old AII. Review frozen source before executing any script. Run one read-only, BLAS1, bounded process under the assigned guard and capture held-terminal evidence. No author test, Green/H/E evaluation, mass/matrix assembly, LU or old test rerun.

Array checks: independent `V/4` constant/affine oracle and charge moment; source support 300 frozen edges and zero boundary entries; compensated complex contraction/scatter from saved contributions; `b4=-iωs4`, `delta_b=b4-b_S1_full` including subtraction sign; new 2/4 difference with absolute contribution scale and no unstable-denominator floor. If an actual solve exists, check `delta_e[B]=0`, unchanged `gB`, `e_S3=e_S2+delta_e`, one `AII delta_e[I]-delta_b[I]` residual from pinned old AII, and `delta_V=t_I^T delta_e[I]` with `math.fsum` real/imag and propagated `128 eps Σ|term|` scales. Compute receiver errors against the same saved H reference at the unchanged 1% criterion; report cancellation sensitivity without redefining the physical denominator or relaxing 1%.

If the author stops at a failed control or source-pair stage, audit only actually saved stage arrays and report absent later quantities as `not_run`. Do not synthesize a successful solve or repair/retry the author run. Actual PCB, UI, board, GPU, product and all 29 formal acceptance gates remain out of scope and open.
