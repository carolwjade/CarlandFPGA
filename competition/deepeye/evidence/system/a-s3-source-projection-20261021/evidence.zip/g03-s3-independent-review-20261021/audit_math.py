"""Independent S3 manufactured controls. Do not import the author's projector.

Pure geometry/polynomial functions only. This module is preparation; it has not
been executed against S3 arrays or used to evaluate a new primary/Green field.
"""
import math
import sys


def compensated_complex_sum(terms):
    items = tuple(complex(x) for x in terms)
    return complex(math.fsum(x.real for x in items), math.fsum(x.imag for x in items))


def roundoff_bound(terms):
    return 128.0 * sys.float_info.epsilon * math.fsum(abs(complex(x)) for x in terms)


def _near(a, b, span):
    # This is a geometry identity check, not a scientific tolerance relaxation.
    return abs(float(a) - float(b)) <= 32.0 * sys.float_info.epsilon * max(1.0, abs(a), abs(b), abs(span))


def _face_code(value, lo, hi):
    if _near(value, lo, hi - lo):
        return 0
    if _near(value, hi, hi - lo):
        return 1
    raise ValueError("edge transverse coordinate is not on a selected cell face")


def local_expected_from_edge_geometry(bounds, edge_start, edge_end, delta_zeta=None, constant_e=None):
    """Return the independent V/4 constant or affine-J load for one oriented edge.

    bounds = ((xmin,ymin,zmin),(xmax,ymax,zmax)); edge endpoints must form a
    positive-axis edge of precisely this cell. The affine fixture is fixed by
    selected S3 design: J=(1+x+2y,-2+y-z,.5+2z+x) A/m^2.
    """
    lo, hi = tuple(map(float, bounds[0])), tuple(map(float, bounds[1]))
    start, end = tuple(map(float, edge_start)), tuple(map(float, edge_end))
    width = tuple(hi[i] - lo[i] for i in range(3))
    if any(h <= 0 for h in width):
        raise ValueError("nonpositive cell width")
    changed = [i for i in range(3) if not _near(start[i], end[i], width[i])]
    if len(changed) != 1:
        raise ValueError("edge must have one positive axial direction")
    axis = changed[0]
    if not (_near(start[axis], lo[axis], width[axis]) and _near(end[axis], hi[axis], width[axis])):
        raise ValueError("edge circulation does not span cell in positive orientation")
    codes = {}
    for i in range(3):
        if i != axis:
            if not _near(start[i], end[i], width[i]):
                raise ValueError("non-axial edge displacement")
            codes[i] = _face_code(start[i], lo[i], hi[i])
    volume = math.prod(width)
    if constant_e is not None:
        if delta_zeta is None:
            raise ValueError("constant-E fixture requires delta_zeta")
        return (volume / 4.0) * complex(delta_zeta) * complex(constant_e[axis])
    mid = tuple((lo[i] + hi[i]) / 2.0 for i in range(3))
    # For L0 and L1, the transverse weighted coordinate is at 1/3 or 2/3.
    q = lambda bit: 1.0 / 3.0 if bit == 0 else 2.0 / 3.0
    if axis == 0:
        ybar = lo[1] + width[1] * q(codes[1])
        current = 1.0 + mid[0] + 2.0 * ybar
    elif axis == 1:
        zbar = lo[2] + width[2] * q(codes[2])
        current = -2.0 + mid[1] - zbar
    else:
        xbar = lo[0] + width[0] * q(codes[0])
        current = 0.5 + 2.0 * mid[2] + xbar
    return (volume / 4.0) * current


def phi(x, y, z):
    return x*y + 0.4*y*z + 0.2*z*x + x*y*z


def _poly_mul(left, right):
    product = {}
    for powers_a, coeff_a in left.items():
        for powers_b, coeff_b in right.items():
            powers = tuple(a+b for a, b in zip(powers_a, powers_b))
            product[powers] = product.get(powers, 0.0) + coeff_a*coeff_b
    return product


def exact_affine_weak_charge(bounds):
    """Exact integral of grad(phi) dot fixed affine J using monomial moments."""
    lo, hi = bounds
    grad = (
        {(0,1,0): 1.0, (0,0,1): 0.2, (0,1,1): 1.0},
        {(1,0,0): 1.0, (0,0,1): 0.4, (1,0,1): 1.0},
        {(0,1,0): 0.4, (1,0,0): 0.2, (1,1,0): 1.0},
    )
    current = (
        {(0,0,0): 1.0, (1,0,0): 1.0, (0,1,0): 2.0},
        {(0,0,0): -2.0, (0,1,0): 1.0, (0,0,1): -1.0},
        {(0,0,0): 0.5, (0,0,1): 2.0, (1,0,0): 1.0},
    )
    contributions = []
    for component in range(3):
        for powers, coeff in _poly_mul(grad[component], current[component]).items():
            moment = math.prod((float(hi[i])**(power+1) - float(lo[i])**(power+1))/(power+1) for i, power in enumerate(powers))
            contributions.append(coeff*moment)
    return math.fsum(contributions), 128.0*sys.float_info.epsilon*math.fsum(abs(x) for x in contributions)
