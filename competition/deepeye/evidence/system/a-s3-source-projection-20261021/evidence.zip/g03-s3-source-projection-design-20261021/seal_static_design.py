"""Seal only static source/manifest bytes. Never load scientific arrays or imports."""
import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];BASE=D.parent
SP=ROOT/'.local/deepeye-fdem-validation-20261020/Lib/site-packages'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def info(p):
    raw=p.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def save(name,value):
    with (D/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
a=read(D/'assignment.json');assert a['owner']=='/root/r02_amd_acquisition_20261021'
assert a['work_id']=='A-G03-S3-SOURCE-PROJECTION-DESIGN-20261021-v1'
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
assert hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==a['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
t=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
assert t['status']=='active' and t['director_generation']==2 and t['new_director_thread_id']==a['director_thread_id']=='01a13d7e-dcf1-7272-a738-a637dd62ff9d'
S1=BASE/'g03-s1-cache-path-continuation-20261021';S2=BASE/'g03-s2-boundary-correction-20261021';L5=BASE/'g03-l5-propagation-z-refinement-20261021'
assert info(S2/'manifest.json')['sha256']==a['frozen_S2']['manifest_sha256']=='0e8e9644eb2a9050add8759d11ccb67954433a478162906ca237de9c9c661cf0'
paths=[D/'assignment.json',ROOT/'AGENTS.md',ROOT/'.agents/skills/fpga-multi-node/SKILL.md',ROOT/'.agents/skills/fpga-multi-node/skill-role.json',ROOT/'.agents/skills/fpga-multi-node/references/protocol.md',ROOT/'docs/competition/deepeye-2026/immutable_scope.md',ROOT/'docs/competition/deepeye-2026/immutable_scope.json',ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json',ROOT/a['main_review'],S2/'manifest.json',S2/'report.md',S2/'run-01/result.json',S2/'s2_stages.py',S1/'manifest.json',S1/'assignment.json',S1/'s1_model.py',S1/'s1_worker.py',S1/'s1_geometry.py',L5/'public-manifest.json',L5/'assignment.json']
ranges={
 'discretize/base/base_tensor_mesh.py':[(792,874)],
 'discretize/operators/differential_operators.py':[(659,665),(2170,2184),(2895,2910),(3010,3017)],
 'discretize/operators/inner_products.py':[(202,244)],
 'discretize/utils/matrix_utils.py':[(227,239)],
 'simpeg/electromagnetics/utils/current_utils.py':[(8,42),(50,104)],
 'simpeg/electromagnetics/frequency_domain/sources.py':[(1319,1338)],
 'simpeg/electromagnetics/frequency_domain/simulation.py':[(641,651)],
}
evidence={}
for relative,spans in ranges.items():
    p=SP/relative;paths.append(p);lines=p.read_text(encoding='utf-8').splitlines()
    evidence[relative]={'path':p.relative_to(ROOT).as_posix(),'ranges':[{'start_line':lo,'end_line':hi,'text':'\n'.join(lines[lo-1:hi])} for lo,hi in spans]}
for name,version in [('simpeg','0.25.2'),('discretize','0.12.0')]:
    p=SP/f'{name}-{version}.dist-info/METADATA';paths.append(p);raw=p.read_text(encoding='utf-8')
    assert f'Name: {name}\n' in raw and f'Version: {version}\n' in raw
pins={p.relative_to(ROOT).as_posix():info(p) for p in paths}
save('source-pins.json',{'work_id':a['work_id'],'requirements_sha256':a['requirements_sha256'],'static_only':True,'scientific_array_loads':0,'files':pins})
save('source-evidence.json',{'local_installed_primary_sources_only':True,'network_requests':0,'sources':evidence})
reuse={}
for folder,manifest,names in [
 (S1,'manifest.json',['assignment.json','s1_geometry.py','controls-01/contrast_cell_indices.npy','controls-01/primary_support_indices.npy','controls-01/delta_mass_diag_Sm2.npy','controls-01/interior_indices.npy','controls-01/boundary_indices.npy','controls-01/receiver_trace_m.npy','run-01/new_derivative_RHS.npy','oracle-01/Born_derivative_V.npy']),
 (S2,'manifest.json',['run-01/corrected_derivative_Vpm.npy','run-01/V_corrected_V.npy','run-01/selected_gB_Vpm.npy','run-01/pre-factorization.json','boundary-01/result.json','run-01/result.json']),
 (L5,'public-manifest.json',['assignment.json','controls-01/edge_starts_m.npy','controls-01/edge_ends_m.npy','run-01/AII-csc.npz']),
]:
    doc=read(folder/manifest)
    for name in names:reuse[(folder/name).relative_to(ROOT).as_posix()]={'inherited_from_manifest':(folder/manifest).relative_to(ROOT).as_posix(),**doc['files'][name]}
save('reuse-inputs.json',{'note':'Inherited exact entries copied from frozen manifests; numerical array files were not opened or loaded in this design job. Future executor verifies them before use.','files':reuse})
result={'work_id':a['work_id'],'owner':a['owner'],'utc':datetime.now(timezone.utc).isoformat(),'status':'static_design_complete_pending_main_selection','candidate':'acceptable_as_fixed_operator_compatible_weak_load_diagnostic','rejected':['global_saved_moments_remapped_across_piecewise_edge_basis_as_accurate_cell_quadrature','silent_edge_circulation_normalization','claim_of_exact_Galerkin_operator_or_proven_S1_bug'],
 'proposed_cell_Gauss_orders':[2,4],'proposed_Tx_points_fixed':256,'contrast_cells_reused':64,'maximum_future_correction_solves':1,'actual_scientific_imports':0,'actual_array_loads':0,'actual_numerical_tests':0,'actual_Green_evaluations':0,'actual_matrix_assemblies':0,'actual_factorizations':0,'old_tests_repeated':False,'network_requests':0,'source_file_count':len(pins),'requirements_sha256':a['requirements_sha256'],'physical_accuracy':'unqualified','numerical_S3':'not_run','finite_tau':'not_run','G03':'not_run','all29_formal':'not_run'}
save('result.json',result)
body='A-G03-S3-SOURCE-PROJECTION-DESIGN-20261021-v1 completed as static design only. Accept a cell-volume weak-load projection as a new diagnostic on unchanged L5 mimetic/Hodge AII, not an exact Galerkin replacement, proof of S1 bug or promised improvement. Installed SimPEG line-current code explicitly integrates 12 dimensionless bilinear edge test functions; discretize isotropic edge mass contributes V*property/4 per local parallel edge. Derive s_j=sum_K integral N_j dot(delta_zeta*Ep)dV [A m], b=-i*omega*s and compatible weak-charge identity; do not force discontinuous contrast current to be divergence-free. Reject global saved Gauss moments remapped across piecewise cell/edge support. Select proposed per-cell Gauss2/4 on64 frozen cells with fixed Tx256 at new targets, independent constant/affine/charge/orientation controls, then at most one future delta_b=b_projected-b_S1_saved correction solve on saved AII with zero boundary correction and preserved S2 field/gB/receiver/H reference. Existing eta and1% gates remain; no change of physics, grid or tolerance. No array load, scientific import, Green/quadrature/solver/test/network/product/UI/GPU/board/service action occurred. H01-H15 SHA c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 and active generation2 preserved; S3 numerical/finite-tau/G03/all29 not_run, physical/noise qualification open. Artifacts: .planning/deepeye-resume-20261018/g03-s3-source-projection-design-20261021/design.md,source-pins.json,source-evidence.json,reuse-inputs.json,result.json,manifest.json. Main retains implementation selection/acceptance.'
with (D/'final-result.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(body)
files={p.relative_to(D).as_posix():info(p) for p in sorted(D.rglob('*')) if p.is_file() and 'private' not in p.name and p.name!='manifest.json'}
save('manifest.json',{'work_id':a['work_id'],'status':'static_design_only','file_count':len(files),'files':files})
assert all(info(ROOT/p)==v for p,v in pins.items())
print(json.dumps({'source_file_count':len(pins),'file_count':len(files),'files':{n:info(D/n) for n in ['design.md','source-pins.json','result.json','final-result.txt','manifest.json']}}))
