# S3: one cell-volume weak-source projection increment on the frozen operator

Status: **acceptable as a narrowly defined new load-discretization diagnostic; not executed**. Reject the claim that this replaces the fixed mimetic operator by an exact Galerkin method, proves a defect in S1, or must improve either receiver. The main selects any later executable task. This task performed only source/JSON reading, hashing and design writing: no numerical array loading, scientific imports, Green evaluation, quadrature, matrix construction, solve or old test.

S2's independently reviewed response remains failed at the fixed 1% screen (12.6766301761% / 4.3707331497%); its original native `failed/result=null`, all previous failures and passed controls remain immutable. H01–H15, requirements SHA `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`, the active generation-2 transfer and full 3D/hidden-truth/causal-observation requirements are unchanged.

## 1. What the installed code supports

The actually read installed code is SimPEG 0.25.2 / discretize 0.12.0 in `.local/deepeye-fdem-validation-20261020/Lib/site-packages/`. Exact source bytes and line references are pinned in `source-pins.json` / `source-evidence.json`.

| Source | Relevant executable/documented behavior |
|---|---|
| `discretize/operators/differential_operators.py:659` | `G=diag(1/edge_lengths)*G_incidence`; electric unknowns are edge-average components, not edge circulation DOFs. |
| Same file:2170 | `C=diag(1/face_areas)*C_incidence*diag(edge_lengths)`: face-average curl. |
| `discretize/base/base_tensor_mesh.py:792` and differential operators:2895,3016 | Isotropic tensor-mesh edge mass is `3*diag(Av_E2CC.T*(cell_volume*property))`; each cell contributes `V_K*property_K/4` to each of its four edges parallel to a given axis. |
| `simpeg/electromagnetics/utils/current_utils.py:8,50` | Dimensionless local bilinear edge functions W and an explicit description of the weak source as `integral W dot J dV`; its line-current routine integrates this source over cell-split segments. |
| FDEM `sources.py:1319` | `LineCurrent.Mejs` supplies this integrated weak vector directly, not an additional material mass times that vector. |
| FDEM `simulation.py:641` | Existing operator `A=C.T*M_f(mu^-1)*C+i*omega*M_e(zeta)` with full `zeta=sigma+i*omega*epsilon`. |
| S1 `s1_model.py:57`, `s1_worker.py:77` | S1 uses diagonal `M_e(delta_zeta)` times primary edge averages, then multiplies by `-i*omega` once. Source support lies away from the wire. |

These findings support replacing only the supplied weak electric source vector. They do not show that S1's sign, index order or material mass is wrong. Its load is the selected lumped approximation. The left-hand side also uses mimetic/lumped Hodge matrices; a more directly integrated load does not remove its operator, propagation or receiver errors. A fully consistent FE mass/stiffness change would be a different experiment and is rejected here.

## 2. Basis, units, normalization and charge

For cell `K=[x_i,x_i+h_x] x [y_j,y_j+h_y] x [z_k,z_k+h_z]`, set `xi=(x-x_i)/h_x`, `eta=(y-y_j)/h_y`, `nu=(z-z_k)/h_z`, and `L_0(t)=1-t`, `L_1(t)=t`. Local shape functions for **edge-average** unknowns are

```
N_x,bc = L_b(eta)*L_c(nu) xhat
N_y,ac = L_a(xi)*L_c(nu) yhat
N_z,ab = L_a(xi)*L_b(eta) zhat,       a,b,c in {0,1}.
E_h|K = sum_(12 local edges) e_j*N_j.
```

They are dimensionless, constant in their own axial coordinate and bilinear in the transverse coordinates. In global positive-axis orientation the proposed physical equivalent-current load is

```
J_dot(x)=delta_zeta_K*E_primary(x),     delta_zeta_K=zeta_0 inside D, zero outside;
s_proj,j = sum_(K touching edge j) integral_K N_(K,j)(x) dot J_dot(x) dV;
b_proj = -i*omega*s_proj.
```

`J_dot` has A/m², `s_proj` A m, and `b_proj` A m/s, matching the saved L5 weak system. **No division by edge length, inverse mass, extra cell volume, mu, conjugation or second `-i*omega`** is applied. An edge-circulation-normalized basis would be `N_j/length_j` with circulation unknowns `length_j*e_j`; inserting that basis without transforming A, source and receiver is incompatible and rejected. Reorienting an edge flips its signed DOF and load together; here all global edge directions stay positive as in L5/S1.

For a nodal trilinear scalar `phi_h`, `grad(phi_h)=sum_j (G phi)_j*N_j` cellwise. Hence the exact compatible weak-charge identity is

```
(G phi)^T*s_proj = sum_K integral_K grad(phi_h) dot J_dot dV.
```

It uses an ordinary bilinear transpose, not a Hermitian adjoint. This remains an identity for each fixed cell quadrature when both sides use the same physical J at those cell nodes, with the right side evaluated through an independently coded analytic gradient. For polynomial manufactured currents it should also match independent exact monomial integrals, avoiding a self-consistent indexing error.

Do **not** impose `G.T*s_proj=0`. Compact `delta_zeta` jumps at the contrast boundary, so even a solenoidal homogeneous primary produces an equivalent-current divergence/surface-charge distribution. Away from the wire, constant delta_zeta gives zero divergence inside a cell in the continuous model, but its normal current at the contrast boundary supplies the weak charge. For the existing system `G.T*C.T=0`, so `G.T*M_e(zeta_0)*e = -G.T*s_proj` for zero magnetic impressed source (with the appropriate full/boundary rows). This sign follows from the same `exp(+i omega t)` equation and is not a reason to project the source into a divergence-free subspace. No new G/C matrix construction is needed: geometry/incidence lists suffice for the new load control.

## 3. Select genuine per-cell Gauss 2/4; reject remapped global moments

The saved S1 global 4³/8³ volume nodes integrate over the **whole contrast box**. The global edge test function is supported only on neighboring cells and changes its polynomial expression across their faces; some components have an axial cell-support discontinuity. Multiplying those old global moments by sampled basis values is not a high-order cell-split integral. More global points do not automatically supply an accurate or exact local load, and point-to-cell binning cannot repair missing quadrature support. **Reject this candidate as the selected S3 projection.** Keep those moments only as historical input for the already accepted smooth H/E reference and boundary, where the kernel is smooth and no piecewise edge basis was introduced.

Select one new integration over the same **64 frozen contrast cells**, not a remesh:

* Read the pinned nominal L5 node vectors and saved S1 cell IDs. Enumerate each selected `(i,j,k)` with the same Fortran/x-fast order and positive widths. Verify their union is exactly the original aligned box `[.025,.05] x [.025,.05] x [-.05,.025]` m, without overlap, gaps or extra cells. Compare source-support edge IDs to the frozen potential support (300 edges), not to a floating zero pattern of a new physical source.
* In each cell map the standard tensor Gauss–Legendre points from `[-1,1]^3` by the affine cell map, with weight `h_x*h_y*h_z/8` times the three 1D weights. Use **orders 2 and 4 only**: 512 and 4096 new total physical target points. Their locations differ from the saved global moment nodes even where counts happen to match.
* Evaluate the unchanged finite-loop primary implementation from pinned S1 `s1_geometry.py` at these **new** cell targets, using transmitter 256 midpoint points at both orders. Retain exactly the S1 frequency, sigma, epsilon, mu, current, turns and arbitrary coil pose. This is distinct new target integration, not replay of old edge/volume/receiver/boundary primary tests. Do not reuse primary values at different locations or retest old 128/256 targets. Wire/box separation follows from the frozen geometry, but each new target must still pass the source function's nonsingular-distance check. Stop on ambiguity or nonfinite values.
* Evaluate the 12 local dimensionless functions directly; scatter their weighted J components to shared global edge IDs. Save per-cell bounds/volumes/IDs, quadrature points/weights, primary/J values, local 64-by-12 load contributions and assembled `s_2`, `s_4`. Point chunks <=128 and transmitter count fixed256 keep memory small; no global all-edge-by-all-source tensor.

The new projection is the continuum weak load in the compatible edge test space, approximately integrated per cell, **on the old quadrature/mimetic operator**. It is a defensible load experiment, not an assertion of exactness for nonpolynomial primary E. Holding the primary line rule fixed isolates this new cell quadrature pair; it does not certify that rule at every new target. Old homogeneous Green/source evidence is reused only within its stated scope.

## 4. Only new low-cost coverage, before any solve

A later executable task must freeze these controls and actual code first and capture a genuine new projection RED before its implementation, without replaying S1/S2 RED or old passing tests.

1. **Constant complex field/current control.** Set the manufactured constant edge-average E vector to `(1+2i,-.5+.7i,.3-.2i)` V/m, with J=delta_zeta*E in the same cells. For either Gauss order, each local parallel-edge load is exactly `V_K*J_axis/4`. Compare assembled projection against the **saved** S1 diagonal contrast mass times the corresponding constant component; do not rebuild the old material mass or evaluate a primary. An independently generated local analytic expected vector and the saved-mass action should agree with the new projector. Use `128*eps*sum_abs_contributions` as a predeclared floating-sum diagnostic, not a physical certificate.
2. **Affine-current and weak-charge coverage.** A separate fixed polynomial fixture `J(x)=(1+x+2y, -2+y-z, .5+2z+x)` A/m² in the same physical cells has analytic monomial integrals. With `phi=x*y+.4*y*z+.2*z*x+x*y*z`, check both the new edge load and `(G phi)^T*s` against directly evaluated exact cell polynomial integrals of `grad(phi)*J`. The Gauss2 rule is exact for these degree-at-most-two componentwise products; compute expected moments from `(b^(n+1)-a^(n+1))/(n+1)`, not the projector's quadrature or scatter code. Include cell/shared-edge indexing and global edge-axis offsets. For the actual J, report the independently coded analytic-gradient quadrature identity at each selected order, with absolute sum scales. Do not demand zero weak charge or rerun the old receiver closure test.
3. **Orientation, dimensions and negative controls.** Check signed linearity under J→-J for the new projector; a real positive x-current in a selected single cell must give four positive x-loads `V_K*J_x/4` and negative-imaginary b after the single `-i*omega`. Reject duplicate/wrong cell IDs, mismatched local/global edge mappings, nonaligned contrast geometry, wrong edge-average/circulation scaling and a deliberately intersecting/undefined source target. These target the new projector, not old solver functionality.
4. **New physical cell-quadrature screen.** Freeze `||s_4-s_2||_inf/||s_4||_inf <=0.001`, record absolute differences, all summation scales and the complex vectors. Also screen the nonzero correction difference `delta_b_2`/`delta_b_4` with the same 0.001 norm rule when both are stable above their explicit `128eps*sum_abs` scales. A zero/unstably cancelling correction is reported as undefined and stops before solving; no denominator floor, extra Gauss level, auto-refinement or automatic retry. These are new source diagnostics, not a relaxation of the unchanged 1% response screen.

This fixed two-level pair cannot establish a universal error bound. No claim is made that the sum threshold covers all Green truncation/rounding error or that local quadrature agreement controls the receiver response. A control failure leaves the original evidence and stops.

## 5. Exactly one new source correction, preserving S2 boundary

Only after new controls/pairs pass, reuse the saved S1 `new_derivative_RHS.npy` **as data**, without recomputing the old diagonal-mass/primary RHS. With the fine new projection define

```
delta_b = -i*omega*s_4 - b_S1_saved;
AII*delta_e_I = delta_b[I];      delta_e_B=0;
e_S3 = e_S2_corrected + delta_e;
delta_V_source = t_I^T*delta_e_I;
V_S3 = V_S2_corrected + delta_V_source.
```

The boundary gB remains the exact same sampled S2 Born boundary; do not add `-AIB*gB` again, resample the boundary, evaluate E/H again, or add the old wire residual. The continuous source and physical reference are unchanged; only their discrete load representation changes. Require both proposed and saved old b to have zero B entries, the same ordered I/B partition and the intended interior source support. Loading exact saved AII is sufficient; reuse the accepted S2 A/AII partition evidence, not a new full-A construction/assembly.

One conditional new COLAMD factorization and one RHS solve maximum, with source/RHS arrays and a pre-factorization receipt persisted first. Proposed ceilings match the existing scientific boundary: source/control stage <=90 s sampled threshold, <=512 MiB/process and <=1 GiB/job; actual <=90 s sampled threshold, <=4 GiB/process and <=5 GiB/job, >=10 GiB observed fresh available physical memory, <=4 processes and BLAS1. These are proposals for a new selected job, not execution under this design lease or hard wall-time promises. Preserve actual elapsed and every original held handle, and stop on any failure without retry.

Save the new residual `AII*delta_e_I-delta_b[I]`; require the unchanged eta gate `<=128*eps=2.842170943040401e-14`. Save corrected field, old/new/source-delta voltages and `V_S3-V_H_saved` with absolute and stable complex-relative values against the same high S1 H-flux reference. Both Rx still face **1%**, never a relaxed or primary-carrier-normalized target. Success or failure is only this diagnostic, not finite-strength/noise/product qualification; improvement is not assumed.

An independent **array-only** main review can verify old/new source-vector subtraction, exact ordered support/boundary, one new residual, `t^T*delta_e`, `e_S3=e_S2+delta_e`, voltage update and reported discrepancies. It need not rerun primary, quadrature, old controls or any factorization. The projected new RHS is independently justified by its manufactured/charge controls and pinned cell receipts; array arithmetic alone does not prove the Green/source physics. The measured source-representation delta is not a unique causal allocation of all remaining error.

## 6. Fixed reuse map and remaining scope

The future implementation must bind the existing S1/S2/L5 manifests and accepted main reviews before reading arrays. `reuse-inputs.json` records the exact inherited file entries copied from those manifests, without loading numerical arrays in this design task:

* Geometry/primary: L5 `assignment.json`, S1 `assignment.json`, `s1_geometry.py`, `controls-01/{contrast_cell_indices,primary_support_indices,delta_mass_diag_Sm2,interior_indices,boundary_indices}.npy`, L5 edge starts/ends.
* Old source and immutable operator: S1 `run-01/new_derivative_RHS.npy`, L5 `run-01/AII-csc.npz`.
* Boundary-corrected baseline: S2 `run-01/{corrected_derivative_Vpm,V_corrected_V,selected_gB_Vpm}.npy`, plus its passed boundary/partition and failed physical-screen evidence.
* Same observable/reference: S1 saved receiver trace and high/low `Born_derivative_V.npy`; no new H integration or old E/receiver controls.

No tensor material, new geometry, mesh, boundary, frequency, driver, package, product interface or hardware route is selected. Strong heterogeneous finite-tau physics, independent full-case reference, sensor/calibration noise, C's model, hidden truth/causal observation wiring, game-level 3D interactions, both H12 paths, G03 and all29 remain open. Main retains final selection and acceptance.
