"""Package only independently reviewed S3 results and complete R02 documents."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

D = Path(__file__).resolve().parent
O = D.parent
ROOT = D.parents[2]
P = ROOT/'.local/deepeye-implementation-a'
R = O/'g03-s3-result-main-review-20261021'
T = P/'competition/deepeye/evidence/system/a-s3-source-projection-20261021'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n').encode()

def write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(raw)

def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}

def table(manifest):
    rows = manifest['files']
    return rows if isinstance(rows, dict) else {r['path']: {'bytes': r['bytes'], 'sha256': r['sha256']} for r in rows}

review = read(R/'review.json')
assert review['status'] == 'ACCEPT_NEW_S3_EVIDENCE_ONLY' and not review['new_corrected_accuracy_screen_pass']
specs = review['sealed'] + [{'folder': 'g03-s3-source-projection-design-20261021', 'manifest_sha256': '450f9fa4de7d7392b84e1ede090fe11d1bd1cc34520e723343436c8c0d705be2'}]
tokens = []
for spec in specs:
    lease = read(O/spec['folder']/'lease.private.json')
    if 'content' in lease:
        lease = json.loads(next(x['text'] for x in lease['content'] if x.get('type') == 'text'))
    tokens.append(lease['lease_token'].encode())
members, derivatives, malformed = {}, [], []

def clean(value):
    if isinstance(value, list):
        return [clean(x) for x in value]
    if isinstance(value, dict):
        return {k: clean(v) for k, v in value.items() if k not in ('env', 'environment')}
    return value

def add(path):
    if 'private' in path.name.casefold() or path.name == 'reserve-request.json':
        return
    raw = path.read_bytes()
    name = path.relative_to(O).as_posix()
    if path.suffix == '.json':
        try:
            value = json.loads(raw)
        except json.JSONDecodeError:
            assert name.endswith('g03-s3-cell-source-projection-20261021/controls-01/manufactured_g2.json') and len(raw) == 40
            malformed.append({'path': name, 'bytes': len(raw), 'sha256': sha(raw), 'preserved_original_partial_json': True})
        else:
            public = clean(value)
            if public != value:
                public['original_environment_omitted'] = True
                public['original_local_sha256'] = sha(raw)
                name = name.removesuffix('.json')+'-public.json'
                derivatives.append({'path': name, 'original_local_sha256': sha(raw)})
                raw = encode(public)
    assert not any(token in raw for token in tokens), name
    if name in members:
        assert members[name] == raw
    else:
        members[name] = raw

for spec in specs:
    source = O/spec['folder']
    assert sha((source/'manifest.json').read_bytes()) == spec['manifest_sha256']
    for rel, expected in table(read(source/'manifest.json')).items():
        path = source/rel
        assert pin(path) == expected, (source, rel)
        add(path)
    for name in ('manifest.json', 'native-complete-response.json', 'terminal-evidence.json'):
        path = source/name
        if path.exists():
            add(path)
for path in sorted(R.iterdir()):
    if path.is_file():
        add(path)
summary = {'utc': datetime.now(timezone.utc).isoformat(), 'review': review,
           'array_review': read(O/'g03-s3-json-independent-review-20261021/run-01/audit.json'),
           'public_environment_derivatives': derivatives, 'preserved_malformed_evidence': malformed,
           'requirements_sha256': 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
           'old_test_groups_repeated': 0, 'new_board_operations': 0, 'physical_accuracy': 'unqualified',
           'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run'}
members['main/summary.json'] = encode(summary)
members['main/prepare.py'] = Path(__file__).read_bytes()
T.mkdir(parents=True)
with zipfile.ZipFile(T/'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in sorted(members.items()):
        info = zipfile.ZipInfo(name, (2026,10,21,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, raw)
with zipfile.ZipFile(T/'evidence.zip') as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(members)
    assert all(archive.read(name) == raw for name, raw in members.items())
write(T/'.gitattributes', b'* -text -eol -filter\n')
write(T/'archive-index.json', encode({name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())}))
write(T/'summary.json', encode(summary))
write(T/'README.md', b'''# S3 cell-source projection result

The new dimensionless cell-edge weak-load implementation passed constant/affine
and compatible-charge controls. Fixed cell Gauss2/4 source and source-difference
pairs passed0.001. One new source-difference solve preserved the S2 boundary;
the unchanged1% receiver screen failed at13.3085987173% and3.2110499868%.

Independent review used saved arrays only, including compensated loads/traces
and one CSR residual; it confirmed both arithmetic and the physical-screen
failure. No old Green targets, operators, tests or board operations were rerun.
The original NumPy-bool JSON failure, partial file and failed native operation
remain intact; a separate operation fixed exactly the bool conversion and work ID.

The archive includes the selected design, both author operations, both independent
reviews and main acceptance. Environment fields alone are removed in named public
derivatives; original local hashes are recorded. Known private lease tokens are
excluded. ZIP CRC and every member byte/hash were checked before publication.
This diagnostic does not isolate the remaining model error or qualify G03,
noise, finite-contrast sensing, R03, hardware or full H01-H15 acceptance.
''')
write(T/'manifest.json', encode({'files': {p.name: pin(p) for p in sorted(T.iterdir())}, 'archive_members': len(members), 'exact_member_bytes_and_crc_checked': True}))

DOC = O/'r02-hardware-docs-completeness-final-20261021'
DOCREVIEW = O/'r02-hardware-docs-completeness-review-20261021'
HARDWARE = P/'competition/deepeye/hardware'
H = P/'competition/deepeye/evidence/system/a-r02-hardware-docs-completeness-20261021'
H.mkdir()
doc_review = read(DOCREVIEW/'final-delta-review.json')
assert not doc_review['new_document_contradiction_found_in_delta']
assert doc_review['bom_rows_verified'] == 17 and doc_review['render_pages_visually_inspected'] == 4
old = read(O/'r02-hardware-docs-20261021/build-result.json')
build = read(DOC/'build-result.json')
for name, expected in build.items():
    assert pin(HARDWARE/name) == old[name]
    assert pin(DOC/'candidate'/name) == expected
    assert expected['sha256'] == doc_review['candidate_hashes_verified'][name]
    shutil.copyfile(DOC/'candidate'/name, HARDWARE/name)
    assert pin(HARDWARE/name) == expected
for source, name in [(DOC/'verification-delta.json','artifact-verification.json'),
        (DOCREVIEW/'final-delta-review.json','independent-review.json'),
        (DOCREVIEW/'final-delta-review.md','independent-review.md'),
        (DOCREVIEW/'review.md','prior-completeness-findings.md')]:
    shutil.copyfile(source, H/name)
write(H/'summary.json', encode({'status': 'complete_taskbook_BOM_and_candidate_wiring_documents_only',
      'artifacts': build, 'BOM_items': 17, 'rendered_pages': 4, 'source_inputs': 7,
      'main_visual_inspection_pages': 4, 'prior_published_document_commit': '0e93e0884b1d018226491c1d0d76870f9832c0d5',
      'new_measurements': 0, 'old_tests_repeated': 0, 'physical_installation': 'unverified',
      'R02': 'not_run', 'R03': 'not_run', 'all29': 'not_run'}))
write(H/'README.md', b'''# Complete R02 document inventory

The current hardware/bom.csv contains17items and wiring.pdf has4reviewed pages.
This increment closes the prior document's taskbook coverage omissions: three
real sensors, two RS485 modules with explicit board/spare roles, MicroSD,
protection, mounting and three manual single-source cable groups. Source selection
is de-energized manual wiring with source_mode locked after confirmation; an
automatic switch has not been designed or claimed. The pinmap remains unchanged.

All7source hashes and current artifact bytes are bound in wiring_sources.json.
Both main and independent review inspected the4pages. The prior9-item publication
and intervening13-item candidate are preserved as history, not current inventory.
Actual part identity, installation, J3 contacts, protection values, calibration
and electrical measurements remain unverified. No old tests or board run repeated.
''')
write(H/'.gitattributes', b'* -text -eol -filter\n')
write(H/'manifest.json', encode({'files': {p.name: pin(p) for p in sorted(H.iterdir())}}))

paths = [*T.iterdir(), *H.iterdir(), *(HARDWARE/name for name in build)]
files = {p.relative_to(P).as_posix(): pin(p) for p in sorted(paths)}
write(D/'publication-files.json', encode(files))
write(D/'owned-paths.nul', b''.join(name.encode()+b'\0' for name in files))
publisher = (O/'r02-hardware-docs-publication-20261021/publish.py').read_text(encoding='utf-8')
publisher = publisher.replace('127d156731a1802fc0a9a57da1df0b0e742b7d6c', '0e93e0884b1d018226491c1d0d76870f9832c0d5')
publisher = publisher.replace('Add source-bound R02 BOM and independently reviewed wiring document',
                              'Archive reviewed S3 source result and complete R02 hardware inventory')
write(D/'publish.py', publisher.encode())
result = {'files': len(files), 'archive_members': len(members), 'archive': pin(T/'evidence.zip'),
          'environment_derivatives': len(derivatives), 'preserved_partial_jsons': len(malformed),
          'BOM_items': 17, 'wiring_pages': 4, 'new_physical_screen_pass': False}
write(D/'package-summary.json', encode(result))
print(json.dumps(result))
