"""Static source hashes, NPY headers and closed-form counts only."""
import ast,hashlib,json,math,struct,time
from pathlib import Path
D=Path(__file__).resolve().parent; P=D.parent; ROOT=D.parents[2]
began=time.monotonic()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def save(name,value):
    with (D/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
def header(path):
    with path.open('rb') as f:
        assert f.read(6)==b'\x93NUMPY';version=tuple(f.read(2));size=struct.unpack('<H' if version==(1,0) else '<I',f.read(2 if version==(1,0) else 4))[0]
        h=ast.literal_eval(f.read(size).decode('latin1' if version[0]<3 else 'utf8'))
        return {'version':version,'header':h,'payload_not_decoded':True,'header_end':f.tell()}
names=[
'g03-next-precision-design-20261023/assignment.md',
'g03-consistent-solve-main-review-20261023/decision.json',
'g03-consistent-solve-main-review-20261023/candidate-metadata-recovery.json',
'g03-consistent-solve-20261023/manifest.json',
'g03-consistent-solve-20261023/summary.json',
'g03-consistent-solve-20261023/consistent_assembler.py',
'g03-consistent-solve-20261023/solve_stages.py',
'g03-consistent-solve-20261023/test_assembly.py',
'g03-consistent-solve-20261023/actual-01/terminal.json',
'g03-consistent-solve-20261023/actual-01/factorization-complete.json',
'g03-consistent-solve-20261023/actual-01/correction-residual.json',
'g03-consistent-candidate-independent-20261023/manifest.json',
'g03-consistent-candidate-independent-20261023/review.md',
'g03-consistent-hodge-json-continuation-20261023/hodge_kernel.py',
'g03-l5-propagation-z-refinement-20261021/assignment.json',
'g03-l6-outer-xy-refinement-20261021/assignment.json',
'g03-l6-main-review-20261021/review.json',
'g03-s1-cache-path-continuation-20261021/assignment.json',
'g03-s1-cache-path-continuation-20261021/s1_model.py',
'g03-s3-json-continuation-20261021/assignment.json',
'g03-s3-json-continuation-20261021/s3_projector.py',
'g03-s3-json-continuation-20261021/s3_stages.py',
'g03-s3-json-continuation-20261021/projection-01/result.json',
'g03-s3-error-diagnosis-20261022/diagnosis.md',
'g03-s3-error-diagnosis-20261022/scalar-reduction.json']
paths=[P/n for n in names]+[ROOT/n for n in ['docs/competition/deepeye-2026/immutable_scope.md','docs/competition/deepeye-2026/immutable_scope.json','docs/competition/deepeye-2026/taskbook_final.md','docs/competition/deepeye-2026/simulation_contract_final.json','.planning/deepeye-desktop-handoff-20261015/transfer.json','.agents/skills/fpga-multi-node/SKILL.md','.agents/skills/fpga-multi-node/skill-role.json','.agents/skills/fpga-multi-node/references/protocol.md']]
array_names=['g03-consistent-candidate-independent-20261023/audit-01/candidate_E4_full_Vpm.npy',
'g03-consistent-hodge-json-continuation-20261023/action-01/cell_bounds_m.npy',
'g03-consistent-hodge-json-continuation-20261023/action-01/cell_edge_map.npy',
'g03-consistent-hodge-json-continuation-20261023/action-01/cell_ids.npy']
for order in (2,4):
    for name in ('new_target_points_m','new_target_weights_m3','equivalent_current_Apm2'):
        array_names.append(f'g03-s3-json-continuation-20261021/projection-01/g{order}_{name}.npy')
array_names.extend(['g03-s3-json-continuation-20261021/projection-01/cell_ids.npy','g03-s3-json-continuation-20261021/projection-01/cell_bounds_m.npy'])
headers={n:header(P/n) for n in array_names};paths.extend(P/n for n in array_names)
pins={p.relative_to(ROOT).as_posix():pin(p) for p in paths}
assert pin(P/'g03-consistent-solve-20261023/manifest.json')['sha256']=='7526ecfb910f6cd85c3d57e66633fd2805a6a6b1ec7de2d57c7007de655f5ca6'
assert pin(P/'g03-consistent-candidate-independent-20261023/manifest.json')['sha256']=='a657acd73a59d16f7ae85d38d3befa3af97e98af8e4f84e720c4c243ada25cd2'
manifest=read(P/'g03-consistent-candidate-independent-20261023/manifest.json')
assert pin(P/array_names[0])==manifest['files']['audit-01/candidate_E4_full_Vpm.npy']
contract=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
canonical=hashlib.sha256(json.dumps(contract['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
assert canonical=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
def counts(nx,ny,nz):
    cells=nx*ny*nz
    edges=nx*(ny+1)*(nz+1)+(nx+1)*ny*(nz+1)+(nx+1)*(ny+1)*nz
    interior=nx*(ny-1)*(nz-1)+(nx-1)*ny*(nz-1)+(nx-1)*(ny-1)*nz
    nnz=nx*(3*ny+1)*(3*nz+1)+ny*(3*nx+1)*(3*nz+1)+nz*(3*nx+1)*(3*ny+1)+8*(nx*ny*(3*nz+1)+nx*nz*(3*ny+1)+ny*nz*(3*nx+1))
    return {'shape':[nx,ny,nz],'cells':cells,'edges':edges,'interior_edges':interior,'boundary_edges':edges-interior,'raw_12x12_triplets':144*cells,'COO_bytes':144*cells*24,'CSR_clique_nnz':nnz,'CSR_bytes':20*nnz+4*(edges+1),'GMRES_41_complex_vectors_bytes':41*interior*16}
l5=read(P/'g03-l5-propagation-z-refinement-20261021/assignment.json');nodes=l5['z_nodes_m']
intervals=[[nodes[i],nodes[i+1]] for i in range(len(nodes)-1) if ((nodes[i]>=-.2 and nodes[i+1]<=-.05) or (nodes[i]>=.075 and nodes[i+1]<=.225))]
assert len(intervals)==8
old=counts(24,24,34);candidate=counts(24,24,42)
assert old['CSR_clique_nnz']==1969810
interior_faces=[(24-1)*24*34,24*(24-1)*34,24*24*(34-1)]
nprobe=2*sum(interior_faces);q=24;u_nonzero=q*20
result={'execution':'static source/JSON/header reads and small stdlib counts only','scientific_imports':0,'array_payloads_decoded':0,'mesh_operator_builds':0,'quadratures_Green_solves_old_tests':0,
'canonical_contract_sha256':canonical,'current':old,'prospective_z_bisection_not_selected':{'intervals':intervals,'counts':candidate,'interior_growth':candidate['interior_edges']/old['interior_edges'],
'illustrative_LU_memory_linear_bytes':3420585984*candidate['interior_edges']/old['interior_edges'],'illustrative_LU_memory_4thirds_bytes':3420585984*(candidate['interior_edges']/old['interior_edges'])**(4/3),'warning':'not a fill forecast or feasibility certificate; old L6 timed out'},
'selected_indicator':{'interior_faces_by_normal':interior_faces,'probe_count':nprobe,'cell_probe_incidences':2*nprobe,'coarse_basis_pairings':24*nprobe,'source_cells':64,'source_touched_faces':240,'source_touched_probes':480,'source_probe_cell_incidences_upper':64*12,'archived_g4_weighted_terms_upper':64*12*64,'archived_g2_weighted_terms_upper':64*12*8,'output_bytes_8float64_1complex128_5int32_per_probe':nprobe*(64+16+20),'chunk_probes':128,'working_set_design_ceiling_bytes':64*1024**2},
'bounded_enrichment':{'maximum_bubbles':q,'maximum_distinct_touched_cells':2*q,'maximum_U_entries':u_nonzero,'sparse_U_values_and_indices_bytes':u_nonzero*20+4*(q+1),'complex_D_bytes':q*16,'augmented_interior_dofs':old['interior_edges']+q,'augmented_full_dofs':old['edges']+q,'augmented_full_CSR_max_nnz':old['CSR_clique_nnz']+2*u_nonzero+q,'condensed_rank_update_terms_upper':q*20*20,'extra_41_vector_bytes_if_augmented':41*q*16,'stored_old_LU_reuse':False,'one_new_old_A0_LU_required_for_future_solve':True,'new_global_LU_selected':False},
'runtime_seconds':time.monotonic()-began}
save('source-pins.json',{'files':pins,'private_records_excluded':True,'current_product_head_parent_record':'834b5c022c1fdc41f7c1b4f8ca9f8006573e7d62','git_commands_run':0})
save('headers.json',headers);save('counts.json',result)
print(json.dumps(result,indent=2))
