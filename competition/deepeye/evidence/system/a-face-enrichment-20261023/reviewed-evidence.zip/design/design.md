# Bounded conforming face enrichment: proposal for root selection

**Recommendation:** implement one new face-bubble residual indicator on the saved consistent candidate. Its deterministic output either specifies at most 24 cell-disjoint conforming enrichment functions, with exact coupling/source data for a later correction, or rejects this bounded enrichment as insufficiently supported. Do not select another global mesh or PDE solve now. This is an executable approximation-space increment with a selection gate, not another evaluation of the existing coarse equations.

Work A-G03-NEXT-PRECISION-DESIGN-20261023-v1; native child-e45c633afaa445fdb299a29b65d3d247 validated for /root/g03_s3_error_diagnosis_20261022. Only this folder is writable. Root retains mathematical selection, implementation authorization and acceptance. Product HEAD834b5c022c1fdc41f7c1b4f8ca9f8006573e7d62 is parent-recorded; no Git operation was run. Current node configuration identifies A/fpga-main and active transfer generation2 identifies director01a13d7e-dcf1-7272-a738-a637dd62ff9d. Canonical H01-H15 hash was recomputed unchanged: c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.

## Evidence and unresolved attribution

The original solve remains failed, info=3, 78 callbacks. Independent recovered metadata reports candidate errors5.7027777284% and2.8609120129%, both above unchanged1%; old S3 errors were13.3085987173% and3.2110499868%. Candidate final backward eta1.8005914754566148e-19 does not bound receiver error. Compensated true correction residual still exceeded the old strict GMRES target119.4-fold; the standard result exceeded it131.6-fold. The independent audit serialization failure also remains failed.

Consistent forms, new scatter controls and assembly/action identity support the implemented coarse weak operator. They do not certify its approximation space. Archived source Gauss2/4 relative pairs3.14926e-5 and6.41100e-4, exact selected boundary preservation, and continuum contour/flux consistency reduce specific source/boundary/sign hypotheses without proving exact source or radiation accuracy. The sampled-reference receiver biases0.33489829%/0.20752462% are smaller than the failures, but are diagnostics, never corrections. Neither source pair nor backward error is an adjoint-weighted response-error bound. Primary/source/reference share assumptions; finite-domain boundary sampling and graded-cell representation remain possible contributors. The new indicator must not claim to isolate the entire error.

Source identities are pinned in source-pins.json: actual S1 physics and trace, S3 projector/stages and recorded current samples, accepted Hodge kernel, consistent assembler/stages, root decision/recovered metadata, failed L6 review and original taskbook. headers.json reads only NPY headers. count_and_pin.py imports standard-library modules only, computes closed-form geometry/storage counts and hashes bytes; it decodes no numerical payload and performs no mesh, operator, quadrature, Green or solver work. Counts completed in0.141s; whole shell invocation0.450s. Prior passed controls were not rerun.

## One additional conforming test/trial space

Retain the exact L5 nominal24x24x34 cells, existing actual cumulative endpoint mapping, edge-average unknowns and positive edge orientations. Use the saved independent candidate_E4_full_Vpm.npy only as an unqualified initial field. Physical parameters, contrast box, tilted Tx/Rx, currents, frequency, units, exp(+i omega t), S2 gB, S3 b3 and independent high H reference remain unchanged. No oracle field or response enters selection, load, operator or runtime inference.

For each interior face with normal axis n and each of its two tangential axes t, let b be the remaining axis. The two cells share widths h_t,h_b, with normal widths h_minus,h_plus. On their union define

```
q_F,t(x) = e_t lambda_n(x_n) B(s_b),  B(s)=4s(1-s).
lambda = (x_n-left_outer)/h_minus on the minus cell;
lambda = (right_outer-x_n)/h_plus on the plus cell;
s_b = (x_b-b_lower)/h_b.
q=0 outside the patch; it is constant in coordinate t.
```

At the common face lambda=1 from either side. On outer n faces lambda=0, on b faces B=0, and on t faces q is normal. Thus its tangential trace is continuous and zero on the patch boundary, including any external domain boundary. Every coarse edge tangential degree of freedom is zero; this is an independent H(curl) enrichment direction. No boundary-value unknown is added. Normal field continuity is not imposed. Adjacent cells must share the exact selected face geometry; no tolerance-based merge or hanging-face construction.

Use the existing bilinear reconstruction E_h and define ordinary-transpose weak forms (no conjugation in the complex symmetric operator):

```
a(u,v)=sum_cells integral(mu^-1 curl(u).curl(v)+i omega zeta0 u.v) dV
f_q=-i omega sum_contrast_cells integral(q.d_zeta_E_primary) dV
ell_q=f_q-a(E_h,q)
M_qq=sum_patch V*8/45
K_qq=sum_patch V*(8/(15*h_n^2)+16/(9*h_b^2))
D_q=K_qq/mu+i omega zeta0 M_qq
d_q=K_qq/mu+abs(omega*zeta0) M_qq > 0
score_q=abs(ell_q)^2/d_q
```

All coarse/bubble mass and curl pairings are fixed low-degree physical-coordinate monomial integrals, at most24 local edge contributions per probe. Retain mass, curl, source and absolute-term sums separately. Score is a positive local residual priority, not a certified error estimator, predicted voltage improvement or conditioning bound. It can miss cell-interior and other enrichment directions.

For source action use the already saved g4 equivalent currents, targets and physical weights on64 aligned contrast cells. These64 values per cell define a tensor cubic current interpolant. q has degree0 in t,1 in n and2 in b, so its product with that interpolant has coordinate degrees at most3,4,5. Tensor Gauss4 is exact up to degree7 in each coordinate, and therefore suffices for **this represented current**. It does not prove accuracy of the nonpolynomial physical primary. Compute the distinct new q-source functionals using archived g2 samples as a comparison; no old coarse projector execution and no new target/Green evaluation. Outside the contrast source is exactly zero. Do not use nodal b3 entries to infer new source moments.

## Deterministic decision and bounded correction specification

Enumerate all interior faces, normal-axis order x,y,z, then increasing (i,j,k), then t in increasing axis order. There are56,544 faces and113,088 probes. Save every result, not only selected peaks.

1. Require every new analytic control, pin, geometry, finite-value and positive d_q check. Record128eps times explicit absolute polynomial/product sums for arithmetic checks.
2. For the new source-functional vector require norm_inf(F4-F2)/norm_inf(F4)<=0.001. If its high denominator is not above128eps times its recorded absolute sum, mark undefined and stop. This is a new engineering consistency screen, not a revised old screen. A failure returns source-action-unresolved, without another quadrature level.
3. For each probe let u_q=abs(F4-F2)+128eps*S_q, where S_q includes both source rules and all mass/curl/coarse-field terms. It is a declared resolution margin, not a rigorous physical uncertainty. A probe is resolved only when abs(ell_q)>10u_q. Save excluded probes and their margins.
4. Sort resolved probes by descending score, exact ties by canonical key. Greedily append a probe only if neither of its two cells occurs in an already selected patch; stop at24 selected probes. This enforces disjoint volume support and a diagonal bubble-bubble block. No receiver/reference-driven tuning.
5. Define coverage=sum(selected scores)/sum(all resolved scores). If no resolved probes or coverage<0.50, return bounded_enrichment_not_supported; publish the complete map and select no solve. The50% threshold is a fixed concentration heuristic for this small budget, not an accuracy claim. If coverage>=0.50, return candidate_enrichment_defined with the exact ordered patch list, U,D,f_q, margins, scores and coverage. Root then independently decides whether the new correction merits a separate job. No automatic implementation/solve after either result.

For an accepted list Q, U_jq=a(N_j,q) has at most20 distinct coarse-edge rows per two-cell patch. There are at most480 U entries and24 extra complex unknowns. With alpha the bubble coefficients, the future augmented system is

```
[Ac  U] [e    ] = [b3 ]       e_B=gB, all alpha interior.
[U^T D] [alpha]   [f_Q]
```

D is diagonal because selected patch interiors do not intersect. Shared coarse edges do not invalidate this. Static condensation gives S=Ac_II-U_I D^-1 U_I^T. From the saved full candidate E_h, a new correction would satisfy

```
r_h=(Ac E_h-b3)_I; ell=f_Q-U^T E_h
S delta_I = -r_h+U_I D^-1 ell; delta_B=0
alpha=D^-1(ell-U_I^T delta_I).
```

Thus boundary U_B*gB is included exactly once inside ell. Do not drop it. Do not assemble a new large LU: reuse the pinned old A0II matrix for one newly computed COLAMD LU preconditioner only; no LU factor object was persisted. Apply the rank<=24 update as sparse U products. This later calculation is a genuinely different discretization; the old info3 is never reclassified.

Future voltages require V=t_coarse e+t_Q alpha on the identical tilted physical circles. Reuse the old coarse trace, and calculate only the new bubble columns. Segment circles at patch planes and the internal face. On each segment q.r'(theta) is a trigonometric polynomial of degree<=4, so use analytic sine/cosine primitives, with a new independent polynomial-circle control. Omitting t_Q would silently change measurement consistency. Keep original high H and both1% gates; no rescaling, bias subtraction or response-based patch selection.

## Resources and why another refined LU is not selected

The indicator processes128 probes at a time, keeps no global sparse operator, and needs2,714,112 local coarse-basis pairings. At most768 source probe/cell incidences use49,152 archived g4 and6,144 archived g2 weighted terms. The counted baseline output columns (8float64,1complex128,5int32 per probe) occupy11,308,800 bytes. Retaining four further complex components (mass, curl, source2, source4), in addition to complex ell, adds7,237,632 bytes:18,546,432 bytes total. Geometry, saved field, chunk buffers and these outputs have a64MiB working-array design allowance. Python/library overhead is additional. Proposed guard:60s sampled threshold,512MiB process/1GiB job,3 held processes,BLAS1,64MiB artifact cap; this is a ceiling, not a measured runtime guarantee. Any failure preserves the single attempt, stops, and completes failed without repair or retry.

The supported24-bubble candidate adds at most984 structural entries to the full CSR and15,744 bytes to a41-vector augmented Krylov basis. Sparse U storage is9,700 bytes, D384 bytes; a condensed materialized update would have at most9,600 terms, but matrix-free U is preferred. These counts bound added algebra storage, not iteration count. A future solve could retain4GiB process/5GiB job, fresh free>=10GiB,BLAS1,90s and one40x3 GMRES call; old84.281s/3.42GB is close to the time limit, so convergence and timing remain unproven. Root must explicitly authorize that job after the indicator and new controls. An overrun/failure does not trigger more time, restart or another solver.

For comparison only, bisecting the eight currently long z propagation intervals produces24x24x42 cells,77,850 edges,67,482 interior edges,3,483,648 triplets and2,431,386 CSR entries. I grows24.0%. Multiplying the old total job peak by N and N^(4/3) growth gives illustrative4.242GB/4.557GB, already near/above the4GiB process ceiling; these are not a fill model or proof of infeasibility. Old L6's28x28x34 attempt actually timed out. CSR storage itself is small; new LU fill/time is the unsupported expense. No large refined factorization is selected on this evidence.

## Prospective numerical stopping policy and minimal new controls

Only for a separately selected new enriched solve, freeze one GMRES call with restart40,maxiter3,rtol1e-12,atol0 and <=120 callbacks. Preserve returned info, callback journal and candidate before reporting. Add a wrapper policy declared **before** execution: info0 is strict convergence; positive info may be labeled roundoff_limited_candidate only when finite, with independently compensated full augmented residual satisfying every row abs(r_i)<=128eps*(sum_j abs(Aaug_ij*x_j)+abs(baug_i)), plus actual augmented-II normwise eta<=128eps using boundary-adjusted RHS. Also report the strict true2norm ratio and norm of the componentwise floor. No lowered internal tolerance or retry. Negative info, nonfinite values, unmet row/eta checks or resource failure stop immediately. A roundoff-limited candidate may enter the unchanged physical screens under this prospective policy, but is not strict solver convergence. Both receiver1% gates and full taskbook gates remain mandatory; tiny backward error never substitutes for them. Original info3 remains failed under its original policy.

Minimal new controls, with independent Fraction monomial expectations frozen before RED:

* Two unequal adjacent boxes (normal widths.03,.05m; other widths.04,.07m): q has matching interface tangential trace, zero patch-boundary tangent/coarse-edge moments; check exact M_qq,K_qq,U and a manufactured piecewise-linear tangential field with a known curl jump. Reverse one side's normal-hat derivative and deliberately omit its field contribution as negatives. This tests new directions, not the accepted Hodge/scatter suite.
* Tensor monomial current degrees0..3: exact q-current integrals versus the new archived-layout rule evaluator; Gauss4 degree claim, Gauss2 exactness for tensor-affine current and an intentional wrong single -i*omega factor. Independently check greedy canonical tie-breaking, cell-disjoint exclusion and50%/undefined-source status with small scalar records. No physical source replay.
* Only before a later enriched solve: tiny two-patch augmented-versus-condensed rational system including nonzero fixed gB, and the new bubble circle integral primitive; a zero-boundary or missing t_Q negative must fail. Add one cancellation fixture distinguishing strict GMRES status, rowwise floating floor and unchanged receiver failure. Reuse the root's independently validated scalar serializer; do not reimplement it.

Candidate files in a future separately owned folder: face_probe_geometry.py (keys and q/curl polynomials), face_probe_moments.py (U,D and source actions), test_face_probes.py (new independent controls), probe_stage.py (one saved-field traversal, scales and deterministic selection), run_probes.py (existing held guard), selected_enrichment.json (raw keys/U/D/f_Q and decision). Later solve/trace files require a separate selected assignment; no code for them is executed here.

## Full-scope route and failure semantics

Preflight exact original manifests, source hashes, field/current/header schemas, candidate diagnostic provenance,64 source cells and2/4 sample order before scientific imports. Verify readback after execution. Require NumPy/SciPy/DLL identity and actual BLAS1 in any future numerical stage. Save arrays before report conversion; use root's strict scalar serializer, preserving partial reports and failure state. Do not recover a failed operation in place.

Even a successful enrichment experiment is a tau=0 derivative case and an intermediate discretization check. The original taskbook G03 still requires arbitrary3D materials, homogeneous/interface/tilted/double-target/low-contrast/thin-layer/shielding/saturation cases (>=30 unseen configurations per group), mesh uncertainty<=0.25 frozen noise sigma, surrogate RMS<=0.5/P95<=1 sigma, finite-strength responses, calibrated noise and quantization,20Hz updates, source/online distinction, unknown/OOD and far-field support evidence. Physical accuracy, finite tau, training, G03/R03/all29 remain unqualified/not_run. No truth is supplied to the controller and neither H12 mode is removed. H01-H15 remain mandatory. This design selects no runtime dataset, surrogate fit, product integration or acceptance.
