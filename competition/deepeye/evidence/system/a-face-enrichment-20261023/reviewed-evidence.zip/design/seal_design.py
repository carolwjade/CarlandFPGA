"""Inert design delivery readback and manifest; no scientific imports."""
import ast,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def save(name,x):
    with (D/name).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
before=read(D/'source-pins.json')['files'];after={n:pin(ROOT/n) for n in before};assert before==after
script=ast.parse((D/'count_and_pin.py').read_text(encoding='utf-8'))
imports=[]
for n in ast.walk(script):
    if isinstance(n,ast.Import):imports.extend(i.name for i in n.names)
    if isinstance(n,ast.ImportFrom):imports.append(n.module)
assert set(imports)<={'ast','hashlib','json','math','struct','time','pathlib'}
d=read(D/'design.json');c=read(D/'counts.json');h=read(D/'headers.json')
assert d['probe_count']==c['selected_indicator']['probe_count']==113088
assert d['maximum_selected_bubbles']==c['bounded_enrichment']['maximum_bubbles']==24
assert all(v['payload_not_decoded'] for v in h.values())
assert d['next_solve_selected'] is False and d['existing_failed_GMRES_info']==3 and d['receiver_gate_unchanged']==.01
save('verification.json',{'status':'static_design_delivery_verified','source_readback_unchanged':True,'source_count':len(before),'before':before,'after':after,'count_script_imports':imports,'header_count':len(h),'design_JSON_parsed':True,'science_or_old_test_execution':False,
 'count_command':".local/deepeye-fdem-validation-20261020/Scripts/python.exe -I -B -X utf8 .planning/deepeye-resume-20261018/g03-next-precision-design-20261023/count_and_pin.py",'count_exit_code':0,'count_computation_seconds':c['runtime_seconds'],'shell_elapsed_seconds':.4497731,'peak_process_memory':'not_measured_for_stdlib_static_count','extended_indicator_retained_output_bytes':113088*(8*8+5*16+5*4)})
excluded={'lease.private.json','reserve-request.json','reserve.stderr.txt'}
files={p.name:pin(p) for p in sorted(D.iterdir()) if p.is_file() and p.name not in excluded}
save('manifest.json',{'files':files,'bytes':sum(v['bytes'] for v in files.values()),'excludes':'private lease/reservation records; this manifest and final native text'})
mh=pin(D/'manifest.json')['sha256']
text=f"A-G03-NEXT-PRECISION-DESIGN-20261023-v1 completed as a static proposal for root selection. Recommend one NEW conforming face-bubble weak-residual indicator on the saved consistent candidate. Fixed 113088 probes deterministically select at most24 cell-disjoint enrichment DOFs only if source/resolution/concentration gates pass; otherwise reject this bounded enrichment without a solve. Exact basis, source-degree argument, U/D static condensation including gB, new measurement columns, minimal new controls, prospective residual-floor policy and resource limits are in design.md/design.json. Original info3, audit failure and both1% failures remain unchanged; no arrays decoded/scientific imports/operator/Green/quadrature/solves/old tests/product operations. Stdlib source/header/count work only; all45 source pins unchanged. G03/R03/all29 and finite-strength/noise/OOD/training remain not_run/unqualified; H01-H15 preserved. Manifest SHA256 {mh}; design SHA256 {pin(D/'design.md')['sha256']}; JSON SHA256 {pin(D/'design.json')['sha256']}. Root owns critical selection and acceptance."
assert len(before)==45
with (D/'native-final.txt').open('x',encoding='utf-8') as f:f.write(text+'\n')
assert all(pin(D/n)==v for n,v in files.items())
print(json.dumps({'manifest_sha256':mh,'design_sha256':pin(D/'design.md')['sha256'],'design_json_sha256':pin(D/'design.json')['sha256'],'source_count':len(before),'manifest_files':len(files),'bytes':sum(v['bytes'] for v in files.values())}))
