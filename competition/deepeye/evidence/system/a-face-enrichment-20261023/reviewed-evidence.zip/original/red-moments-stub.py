def local_moments(widths,normal,tangent,side):
    raise NotImplementedError('face bubble moments not implemented')
