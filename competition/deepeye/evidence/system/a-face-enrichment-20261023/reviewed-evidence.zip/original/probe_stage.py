"""One new full saved-candidate face indicator; no global operator or solve."""
import hashlib,json,math
from pathlib import Path
import numpy as np
from evidence_json import write_new_report as save
import face_probe_geometry as geometry
import face_probe_moments as moments
import face_probe_selection as selection
D=Path(__file__).resolve().parent;ROOT=D.parents[2];EPS=np.finfo(float).eps
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def path(alias):
 spec=read(D/'input-pins.json');name=spec['aliases'][alias];p=ROOT/name
 if pin(p)!=spec['files'][name]:raise ValueError('input pin '+alias)
 return p
def load(alias):
 value=np.load(path(alias),allow_pickle=False)
 if not np.all(np.isfinite(value)):raise ValueError('nonfinite input '+alias)
 return value
def array(stage,name,value):
 if not np.all(np.isfinite(value)):raise ValueError('nonfinite output '+name)
 with (stage/(name+'.npy')).open('xb') as f:np.save(f,value,allow_pickle=False)
def validate_geometry(bounds,mapping,ids,starts,ends,a):
 if bounds.shape!=(19584,2,3) or mapping.shape!=(19584,12) or not np.array_equal(ids,np.arange(19584)):raise ValueError('fixed cells')
 if not np.issubdtype(mapping.dtype,np.integer) or np.any(mapping<0) or np.any(mapping>=63250) or np.any(np.diff(np.sort(mapping,axis=1),axis=1)==0):raise ValueError('map IDs')
 nodes=[np.array(a['level']['x_nodes_m']),np.array(a['level']['x_nodes_m']),np.array(a['z_nodes_m'])]
 actual=[np.r_[v[0],np.diff(v)].cumsum() for v in nodes];sub=np.column_stack((ids%24,(ids//24)%24,ids//576))
 for j in range(3):
  if not np.array_equal(bounds[:,0,j],nodes[j][sub[:,j]]) or not np.array_equal(bounds[:,1,j],nodes[j][sub[:,j]+1]):raise ValueError('nominal bounds')
 if starts.shape!=(63250,3) or ends.shape!=starts.shape:raise ValueError('edge geometry shape')
 slot=0
 for axis in range(3):
  transverse=[j for j in range(3) if j!=axis]
  for second in (0,1):
   for first in (0,1):
    lo=np.column_stack([actual[j][sub[:,j]] for j in range(3)]);hi=lo.copy();hi[:,axis]=actual[axis][sub[:,axis]+1]
    for j,bit in zip(transverse,(first,second)):lo[:,j]=hi[:,j]=actual[j][sub[:,j]+bit]
    if not np.array_equal(starts[mapping[:,slot]],lo) or not np.array_equal(ends[mapping[:,slot]],hi):raise ValueError('exact cumulative actual endpoints')
    slot+=1
 if not np.array_equal(np.unique(mapping),np.arange(63250)):raise ValueError('edge coverage')
def run(stage):
 bounds=load('bounds');mapping=load('mapping');ids=load('cell_ids');starts=load('starts');ends=load('ends')
 validate_geometry(bounds,mapping,ids,starts,ends,read(path('L5_assignment')))
 field=load('field');B=load('B');gB=load('gB')
 if field.shape!=(63250,) or field.dtype!=np.complex128 or B.shape!=(8832,) or gB.shape!=(8832,) or not np.array_equal(field[B],gB):raise ValueError('full candidate boundary')
 source_ids=load('source_cell_ids');source_bounds=load('source_cell_bounds_m')
 if source_ids.shape!=(64,) or len(np.unique(source_ids))!=64 or not np.array_equal(bounds[source_ids],source_bounds):raise ValueError('archived source cell geometry')
 p=read(path('S1_assignment'))['inputs'];low=np.array(p['contrast_box_min_m']);high=np.array(p['contrast_box_max_m'])
 mid=(bounds[:,0]+bounds[:,1])/2;expected=np.flatnonzero(np.all((mid>low)&(mid<high),axis=1))
 if not np.array_equal(source_ids,expected):raise ValueError('fixed source support IDs')
 source_lookup=np.full(19584,-1,dtype=np.int32);source_lookup[source_ids]=np.arange(64)
 samples={}
 for order in (2,4):
  points=load(f'g{order}_new_target_points_m');weights=load(f'g{order}_new_target_weights_m3');current=load(f'g{order}_equivalent_current_Apm2')
  if points.shape!=(64,order**3,3) or weights.shape!=(64,order**3) or current.shape!=points.shape or current.dtype!=np.complex128 or np.any(weights<=0):raise ValueError('archived sample layout')
  samples[order]=(points,weights,current)
 omega=2*math.pi*p['frequency_Hz'];zeta=p['sigma_background_Spm']+1j*omega*p['epsilon_background_Fpm'];mu=p['mu_background_Hpm'];coeff=1j*omega*zeta
 keys,cells=geometry.enumerate_probes((24,24,34));N=len(keys)
 if N!=113088:raise ValueError('fixed face probe count')
 data={k:np.zeros(N,dtype=complex) for k in ('mass','curl','F2','F4')}
 data.update({k:np.zeros(N) for k in ('mass_scale','curl_scale','F2_scale','F4_scale','Mq','Kq')})
 save(stage/'before-indicator.json',{'probe_count':N,'chunk_max':128,'field_pin':pin(path('field')),'source_current_convention':'archived zeta0 E_primary, exactly one -i omega in new source functional','boundary':'all saved field entries including exact gB','nominal_widths_and_actual_endpoint_identity_verified':True,'new_global_operators':0,'solver_calls':0,'new_physical_targets':0})
 for n in range(3):
  for t in range(3):
   if n==t:continue
   indices=np.flatnonzero((keys[:,0]==n)&(keys[:,4]==t))
   for first in range(0,len(indices),128):
    selected=indices[first:first+128];pair=cells[selected];left=bounds[pair[:,0]];right=bounds[pair[:,1]]
    if not np.array_equal(left[:,1,n],right[:,0,n]):raise ValueError('shared nominal face')
    for j in range(3):
     if j!=n and not np.array_equal(left[:,:,j],right[:,:,j]):raise ValueError('shared transverse face extents')
    for side in (0,1):
     cell=pair[:,side];bb=bounds[cell];width=bb[:,1]-bb[:,0];local=moments.local_moments(width,n,t,side);e=field[mapping[cell]]
     data['mass'][selected]+=coeff*np.sum(local['M']*e,axis=1);data['curl'][selected]+=np.sum(local['K']*e,axis=1)/mu
     data['mass_scale'][selected]+=abs(coeff)*np.sum(local['Ms']*abs(e),axis=1);data['curl_scale'][selected]+=np.sum(local['Ks']*abs(e),axis=1)/mu
     data['Mq'][selected]+=local['Mq'];data['Kq'][selected]+=local['Kq']
     source=source_lookup[cell];present=np.flatnonzero(source>=0)
     if len(present):
      s=source[present]
      for order in (2,4):
       points,weights,current=samples[order]
       value,scale=moments.source_action(points[s],weights[s],current[s],bb[present],n,t,side,omega)
       data[f'F{order}'][selected[present]]+=value;data[f'F{order}_scale'][selected[present]]+=scale
 ell=data['F4']-data['mass']-data['curl'];diag=data['Kq']/mu+coeff*data['Mq'];energy=data['Kq']/mu+abs(coeff)*data['Mq']
 scale=data['F2_scale']+data['F4_scale']+data['mass_scale']+data['curl_scale']
 out=selection.select(keys,cells,ell,energy,data['F2'],data['F4'],scale,data['F4_scale']);chosen=out['selected_indices']
 # Raw complete results precede JSON conversion, including nonselected directions.
 for name,value in {**data,'keys':keys,'cells':cells,'ell':ell,'D':diag,'positive_energy_diagonal':energy,'arithmetic_scale':scale,'resolution_margin':out['margin'],'score':out['score'],'resolved':out['resolved'],'tentative_selected_indices':chosen}.items():array(stage,name,value)
 # Only <=24 selected local columns, never a global sparse assembly.
 Uids=np.full((len(chosen),20),-1,dtype=np.int32);U=np.zeros((len(chosen),20),dtype=complex);lengths=np.empty(len(chosen),dtype=np.int32)
 boundary_mask=np.zeros(63250,dtype=bool);boundary_mask[B]=True;boundary_actions=np.zeros(len(chosen),dtype=complex);full_actions=np.zeros_like(boundary_actions);coupling_checks=[]
 for row,index in enumerate(chosen):
  n=int(keys[index,0]);t=int(keys[index,4]);merged={}
  for side in (0,1):
   cell=cells[index,side];bb=bounds[cell];local=moments.local_moments((bb[1]-bb[0])[None,:],n,t,side);values=local['K'][0]/mu+coeff*local['M'][0]
   for gid,value in zip(mapping[cell],values):merged[int(gid)]=merged.get(int(gid),0j)+value
  ordered=sorted(merged);lengths[row]=len(ordered)
  if len(ordered)!=20:raise ValueError('two-cell edge union')
  Uids[row]=ordered;U[row]=[merged[j] for j in ordered]
  full_actions[row]=np.sum(U[row]*field[ordered]);mask=boundary_mask[ordered];boundary_actions[row]=np.sum(U[row,mask]*field[np.asarray(ordered)[mask]])
  parent=data['mass'][index]+data['curl'][index];bound=128*EPS*(scale[index]+np.sum(abs(U[row]*field[ordered])))
  error=abs(full_actions[row]-parent)
  if error>bound:raise ArithmeticError('selected U^T full-field action identity')
  coupling_checks.append({'probe_index':int(index),'error':error,'bound':bound})
 for name,value in {'selected_U_edge_ids':Uids,'selected_U_values':U,'selected_U_lengths':lengths,'selected_D':diag[chosen],'selected_fQ':data['F4'][chosen],'selected_ell':ell[chosen],'selected_U_full_field_action':full_actions,'selected_U_B_gB':boundary_actions,'selected_keys':keys[chosen],'selected_cells':cells[chosen]}.items():array(stage,name,value)
 result=out['result'];result.update({'coupling_checks':coupling_checks,'source_samples_reused':True,'field_is_failed_solve_diagnostic_candidate':True,'original_GMRES_info':3,'saved_source_cell_count':64,'source_sign':'-i omega exactly once','source_rule_scope':'exact for represented tensor cubic current; physical accuracy not certified','full_boundary_preserved':True,'complex_transpose':'ordinary, no conjugation','selected_arrays_role':'candidate_enrichment' if result['candidate_defined'] else 'tentative_diagnostic_only','controls_replayed':0,'old_tests_replayed':0,'new_Green_targets':0,'new_global_operators':0,'factorizations':0,'PDE_solves':0,'physical_receiver_gate':.01,'physical_receiver_screens':'not_run','finite_tau_noise_OOD_training':'not_run','physical_accuracy':'unqualified','G03':'not_run','R03':'not_run','all29':'not_run'})
 return result
