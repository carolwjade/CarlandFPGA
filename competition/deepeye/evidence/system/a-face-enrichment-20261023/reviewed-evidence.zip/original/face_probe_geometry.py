"""Topological interior-face keys and zero-patch-tangent polynomial bubbles."""
import numpy as np
def enumerate_probes(shape):
    if len(shape)!=3 or any(type(x)!=int or x<1 for x in shape):raise ValueError('positive integer cell shape')
    nx,ny,nz=shape;count=2*((nx-1)*ny*nz+nx*(ny-1)*nz+nx*ny*(nz-1))
    keys=np.empty((count,5),dtype=np.int32);cells=np.empty((count,2),dtype=np.int32);slot=0
    for n in range(3):
        ranges=[range(s) for s in shape];ranges[n]=range(1,shape[n])
        for i in ranges[0]:
            for j in ranges[1]:
                for k in ranges[2]:
                    plus=[i,j,k];minus=list(plus);minus[n]-=1
                    ci=minus[0]+nx*(minus[1]+ny*minus[2]);cj=plus[0]+nx*(plus[1]+ny*plus[2])
                    for t in range(3):
                        if t==n:continue
                        keys[slot]=(n,i,j,k,t);cells[slot]=(ci,cj);slot+=1
    assert slot==count
    return keys,cells
def q_and_curl(points,bounds,normal,tangent,side):
    x=np.asarray(points,dtype=float);bounds=np.asarray(bounds,dtype=float)
    if normal not in (0,1,2) or tangent not in (0,1,2) or normal==tangent or side not in (0,1):raise ValueError('probe axes/side')
    if bounds.ndim!=3 or bounds.shape[1:]!=(2,3) or x.ndim!=3 or x.shape[0]!=len(bounds) or x.shape[2]!=3:raise ValueError('point/bounds shape')
    h=bounds[:,1]-bounds[:,0]
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(bounds)) or np.any(h<=0):raise ValueError('finite positive geometry')
    s=(x-bounds[:,0,None,:])/h[:,None,:]
    if np.any(s < -128*np.finfo(float).eps) or np.any(s > 1+128*np.finfo(float).eps):raise ValueError('point outside nominal cell')
    n=normal;t=tangent;b=3-n-t
    lam=s[:,:,n] if side==0 else 1-s[:,:,n];B=4*s[:,:,b]*(1-s[:,:,b]);q=lam*B
    derivatives={n:(1 if side==0 else -1)*B/h[:,None,n],b:lam*4*(1-2*s[:,:,b])/h[:,None,b]}
    curls=np.zeros_like(x)
    for d,value in derivatives.items():
        c=3-d-t;sgn=1 if (c,d,t) in ((0,1,2),(1,2,0),(2,0,1)) else -1;curls[:,:,c]=sgn*value
    return q,curls
