"""Standard-library receipt/integrity sealing only; no science replay."""
import hashlib,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
sys.path.insert(0,str(ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools'))
from evidence_json import write_new_report as save
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
frozen=read(D/'indicator-source-pins.json');assert all(pin(ROOT/n)==p for n,p in frozen.items())
stages={}
for name in ('red-01','controls-01','indicator-01'):
 t=read(D/name/'terminal.json');r=read(D/name/'input-readback.json')
 assert t['all_processes_terminated'] and t['active_processes_final']==0 and len(t['held_members'])==3 and all(x['signaled'] for x in t['held_members'])
 assert r['unchanged'] and r['before']==r['after']
 stages[name]={k:t[k] for k in ('status','exit_code','seconds','stop_reason','peak_job_memory_bytes','all_processes_terminated','held_members')}
assert read(D/'red-01/expected-red.json')['expected_missing_moments']
controls=read(D/'controls-01/result.json');result=read(D/'indicator-01/result.json')
assert controls['status']=='new_face_controls_pass' and stages['controls-01']['exit_code']==0
assert pin(D/'red-01/physical-rational-expectations.json')==pin(D/'controls-01/physical-rational-expectations.json')
assert result['status']=='source_action_unresolved' and not result['source_pair_pass'] and result['selected_count']==0
assert stages['indicator-01']['exit_code']==2 and stages['indicator-01']['stop_reason'] is None
assert read(D/'indicator-01/failure.json')['type']=='SystemExit'
runtime=read(D/'indicator-01/worker-evidence.json');assert runtime['runtime_before']==runtime['runtime_after']
assert all(x['threads']==1 for x in runtime['runtime_after']['BLAS'])
assert read(D/'indicator-01/stdout.txt')==result
assert pin(D/'root-indicator-selection.json')==pin(D.parent/'g03-face-enrichment-main-review-20261023/indicator-selection.json')
summary={'work_id':'A-G03-FACE-ENRICHMENT-20261023-v1','job_id':'child-dd1ebf92a342433bb72ad989a2cf5a84','status':'failed_fixed_source_action_gate_no_retry','stages':stages,'indicator_result':result,
 'controls':{'physical_moment_cases':controls['physical_moment_cases'],'polynomial_checks':len(controls['checks']),'source_checks':len(controls['source_checks']),'selection_negatives':True,'expected_Fraction_bytes_identical_to_RED':True},
 'source_pins':pin(D/'indicator-source-pins.json'),'source_readback':pin(D/'indicator-01/input-readback.json'),'result_pin':pin(D/'indicator-01/result.json'),
 'runtime_before_after_identical':True,'BLAS_threads':1,'strict_report_file_and_stdout_equal':True,'raw_arrays_saved_before_reports':True,'retries':0,'old_tests_replayed':0,'global_operators_Green_targets_factorizations_solves':0,
 'concentration_gate':'not_evaluated_for_selection_after_source_gate_failure; zero coverage is not a diffuse-defect finding',
 'source_pair_interpretation':'new enriched source functional is unresolved at the fixed two-rule screen; no proof which rule has the physical error',
 'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','H01_H15':'preserved','physical_receiver_gate':.01,'physical_accuracy':'unqualified','finite_tau_noise_OOD_training':'not_run','G03':'not_run','R03':'not_run','all29':'not_run','root_owns_acceptance':True}
save(D/'summary.json',summary)
report='''# Face indicator failed the fixed source-action gate

The selected single indicator attempt completed its new polynomial traversal and stopped at source_action_unresolved. The new face-bubble source functional has relative infinity difference0.0012562635425821533 between archived Gauss2 and Gauss4 samples, above the unchanged0.001 gate. High-rule infinity magnitude is0.0005435380881566748; absolute difference is6.828270841560351e-7, well above the1.5448281606470643e-17 high-rule arithmetic threshold. This is a real selected numerical-screen failure, not a JSON serialization or resource failure.

All113,088 new conforming directions and their keys, cells, electric/curl actions, source2/source4 actions, absolute sums, positive normalization, resolution margins and scores are preserved as raw arrays. No candidate enrichment was defined, selected_count=0 and no solver was selected or run. The zero reported coverage is a consequence of stopping at the source gate; it does not establish that the residual is diffuse or that the24-patch/50% concentration rule failed. Local resolution flags do not override global source qualification.

The new space uses q=e_t*lambda_normal*4*s_other*(1-s_other), tangentially continuous across the two-cell face and zero in tangential trace on the patch boundary and all coarse edges. The implementation computes physical polynomial moments analytically, with ordinary complex transpose and exactly one -i*omega multiplying archived equivalent current. It uses full saved candidate values, including exact gB. Nominal integration widths and exact actual cumulative-node endpoint mapping were separately checked. No old global operator, old residual, Green source, new physical target or PDE solve was evaluated.

The accepted design/source identities and56 external inputs were pinned before work. Meaningful missing-moment RED was captured after exact independent Fraction expectations were saved. Static review before first GREEN identified a test-only zero arithmetic scale at polynomial cancellation zeros. The authorized correction uses absolute polynomial evaluation terms, preserving expected values and128eps. Exact RED test/runner snapshots and the recorded revision remain. RED/GREEN rational expectation SHA256 is identical:58a599eff300b6fbcdc95d9456a8c641c0b73b36112effe7b939c0ada526745d.

First GREEN passed once:12 physical cases,114 polynomial checks,60 manufactured source checks, deterministic selection/status checks and sign/omission/disjoint/undefined-source negatives. It took1.797s, peak job60,125,184B, exit0. These controls exercise only the new geometry/moments/selection; old controls were not replayed. Root then requested a narrow stdout fix through the reviewed evidence_json.dumps_report helper. The successful GREEN was preserved without rerun; only worker stdout and runner source-manifest authority changed. Exact old/new diffs and original orchestration sources are retained, and the runner enforces equality for every other mathematical/input byte.

Root explicitly selected the full attempt at indicator-source-pins SHA2563b0160dd8fe2179d310675a55e9322a1dc35a5e0bc9a947a4174e366faf66281 after independent/root source review. The authority record was copied byte-exact. The held indicator ended at2.578s, peak job71,553,024B, worker/held launcher exit2, no resource stop, all3held process objects signaled and no remaining active process. The outer PowerShell tool reported exit1; the raw held terminal preserves exit2. Scientific environment was NumPy2.5.4/SciPy1.18.1, both DLL identities and actual BLAS1 unchanged before/after. Full report JSON and stdout parse identically through the strict helper, and every before/after source pin matches.

Indicator result SHA256:abe0a8e88649b9ae8dc19933ba47fd50f66468c5f0adce623b5a3e3aa48e661a.
Indicator input-readback SHA256:6b6b21e4b13318e10f141394ae12059cc4bb58d78d6f44dada0d593599d3ff42.
The manifest binds all public code, frozen sources, controls, logs, raw arrays and receipts; lease/reservation credentials are excluded.

The failure shows that the old coarse-space source-rule agreement does not automatically qualify these added test directions. Gauss4 is polynomial-exact for the represented tensor-cubic current, but the two physical-sample rules do not agree at the selected enriched-functional threshold. This record does not identify which approximation is closer to the true primary. No extra quadrature rule, changed gate, rescaling, oracle subtraction, retry or repair was attempted. Root may inspect the frozen source actions under a separate assignment; this worker selects no follow-on experiment.

Original GMRES info3, the independent audit failure, both physical1% failures, and all previous completed jobs remain unchanged. Physical response tests were not run. Finite strength, noise, OOD, training, G03/R03/all29 remain unqualified/not_run. H01-H15 and DEEPEYE-HUMAN-LOCK-20261014/revision1 are preserved. All writes remain in this assigned evidence directory; no product/Git/peer/service/board/UI changes occurred. Root owns acceptance and subsequent selection.
'''
with (D/'report.md').open('x',encoding='utf8') as f:f.write(report)
excluded={'lease.private.json','reserve-request.json','reserve.stderr.txt'}
files={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in excluded}
total=sum(p['bytes'] for p in files.values());assert total<64*1024**2
save(D/'manifest.json',{'files':files,'total_bytes':total,'excludes':'private lease/reservation; this manifest and native final text'})
manifest=pin(D/'manifest.json')
text=f"A-G03-FACE-ENRICHMENT-20261023-v1 failed its selected source-action screen and stopped without retry. One full indicator preserved113088 new face directions; archived-source Gauss2/4 relative infinity difference0.0012562635425821533 exceeds unchanged0.001. No candidate enrichment or solve selected. New controls passed once (12 physical cases,114 polynomial checks,60 source checks plus negatives); originals and authorized pre/post-GREEN source deltas preserved. Indicator2.578s,71553024B peak, exit2, no resource stop, all3held processes terminated, all69 final source/input pins unchanged, BLAS1 and DLL identity before/after preserved. Strict report and stdout agree; raw arrays retained. No old tests/global operator/Green/new physical targets/PDE solve/retry/product changes. Original info3 and both1% failures unchanged; H01-H15 preserved; physical accuracy/finite tau/noise/OOD/training/G03/R03/all29 remain unqualified/not_run. Evidence report.md and summary.json. Manifest SHA256 {manifest['sha256']}; {len(files)} public files, {total} bytes. Root retains acceptance."
assert len(frozen)==69
with (D/'native-final.txt').open('x',encoding='utf8') as f:f.write(text+'\n')
assert all(pin(D/n)==p for n,p in files.items())
print(json.dumps({'manifest':manifest,'summary':pin(D/'summary.json'),'files':len(files),'bytes':total,'status':summary['status']}))
