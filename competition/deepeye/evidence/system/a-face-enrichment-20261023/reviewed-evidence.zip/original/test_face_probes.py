"""New face directions only; independent physical-coordinate Fraction oracle."""
from fractions import Fraction as F
from itertools import product
import numpy as np
from evidence_json import write_new_report as save
Z=(0,0,0);EPS=np.finfo(float).eps
def add(a,b):
 c=dict(a)
 for p,v in b.items():c[p]=c.get(p,F(0))+v
 return {p:v for p,v in c.items() if v}
def mul(a,b):
 c={}
 for p,x in a.items():
  for q,y in b.items():
   k=tuple(p[j]+q[j] for j in range(3));c[k]=c.get(k,F(0))+x*y
 return c
def neg(a):return {p:-v for p,v in a.items()}
def der(a,i):
 c={}
 for p,v in a.items():
  if p[i]:q=list(p);q[i]-=1;c[tuple(q)]=v*p[i]
 return c
def curl(v):return [add(der(v[2],1),neg(der(v[1],2))),add(der(v[0],2),neg(der(v[2],0))),add(der(v[1],0),neg(der(v[0],1)))]
def dot(a,b):
 p={}
 for x,y in zip(a,b):p=add(p,mul(x,y))
 return p
def integ(p,lo,hi):
 val=F(0);scale=F(0)
 for k,c in p.items():
  for j,degree in enumerate(k):c*=(hi[j]**(degree+1)-lo[j]**(degree+1))/F(degree+1)
  val+=c;scale+=abs(c)
 return val,scale
def ev(p,x):
 return sum((c*x[0]**k[0]*x[1]**k[1]*x[2]**k[2] for k,c in p.items()),F(0))
def evscale(p,x):
 return sum((abs(c)*abs(x[0])**k[0]*abs(x[1])**k[1]*abs(x[2])**k[2] for k,c in p.items()),F(0))
def linear(axis,lo,hi,bit):
 k=tuple(int(j==axis) for j in range(3));h=hi-lo
 return {k:1/h,Z:-lo/h} if bit else {k:-1/h,Z:hi/h}
def oracle(lo,hi,n,t,side):
 b=3-n-t;qpoly=mul(linear(n,lo[n],hi[n],1-side),mul(linear(b,lo[b],hi[b],0),linear(b,lo[b],hi[b],1)))
 qpoly={k:4*v for k,v in qpoly.items()};q=[{}, {}, {}];q[t]=qpoly
 bases=[]
 for a in range(3):
  transverse=[j for j in range(3) if j!=a]
  for second,first in product((0,1),repeat=2):
   p={Z:F(1)}
   for j,bit in zip(transverse,(first,second)):p=mul(p,linear(j,lo[j],hi[j],bit))
   vec=[{}, {}, {}];vec[a]=p;bases.append(vec)
 M=[];K=[];MS=[];KS=[]
 for basis in bases:
  v,s=integ(dot(basis,q),lo,hi);M.append(v);MS.append(s)
  v,s=integ(dot(curl(basis),curl(q)),lo,hi);K.append(v);KS.append(s)
 mq,mqs=integ(dot(q,q),lo,hi);kq,kqs=integ(dot(curl(q),curl(q)),lo,hi)
 return q,bases,{'M':M,'K':K,'Ms':MS,'Ks':KS,'Mq':mq,'Kq':kq,'Mqs':mqs,'Kqs':kqs}
def check(a,b,scale,label):
 a=np.asarray(a);b=np.asarray(b);scale=np.asarray(scale);bound=128*EPS*(abs(a)+abs(b)+scale)
 error=abs(a-b)
 if a.shape!=b.shape or not np.all(np.isfinite(a)) or not np.all(error<=bound):raise AssertionError(label)
 return {'label':label,'max_error':np.max(error),'max_bound':np.max(bound),'passed':True}
def run(stage):
 import face_probe_moments as moments
 rows=[];expectations=[]
 for n in range(3):
  for t in range(3):
   if n==t:continue
   b=3-n-t;origin=[F('0.1'),F('-0.2'),F('0.3')]
   for side in (0,1):
    lo=origin.copy();hi=origin.copy();width=[F(0)]*3;width[n]=F('.03') if side==0 else F('.05');width[t]=F('.04');width[b]=F('.07')
    if side:lo[n]+=F('.03')
    hi=[lo[j]+width[j] for j in range(3)]
    q,bases,e=oracle(lo,hi,n,t,side);rows.append((n,t,side,lo,hi,q,bases,e))
    expectations.append({'normal':n,'tangent':t,'side':side,'lo':[str(x) for x in lo],'hi':[str(x) for x in hi],'moments':{k:[str(x) for x in v] if isinstance(v,list) else str(v) for k,v in e.items()}})
 save(stage/'physical-rational-expectations.json',expectations)
 # Meaningful RED occurs only after independently frozen moment expectations.
 n,t,side,lo,hi,q,bases,e=rows[0]
 moments.local_moments(np.array([[float(hi[j]-lo[j]) for j in range(3)]]),n,t,side)
 import face_probe_geometry as geom
 import face_probe_selection as selection
 checks=[];actual_m=[];actual_k=[];jump_totals={}
 for n,t,side,lo,hi,q,bases,e in rows:
  bounds=np.array([[lo,hi]],dtype=float);width=bounds[:,1]-bounds[:,0];got=moments.local_moments(width,n,t,side)
  for k,s in [('M','Ms'),('K','Ks')]:checks.append(check(got[k][0],np.array(e[k],dtype=float),np.array(e[s],dtype=float),'physical '+k+str((n,t,side))))
  for k,s in [('Mq','Mqs'),('Kq','Kqs')]:checks.append(check(got[k][0],float(e[k]),float(e[s]),'physical '+k+str((n,t,side))))
  actual_m.append(got['M'][0]);actual_k.append(got['K'][0]);b=3-n-t
  points=[]
  for frac in product((F(0),F(1,2),F(1)),repeat=3):points.append([lo[j]+frac[j]*(hi[j]-lo[j]) for j in range(3)])
  x=np.array([points],dtype=float);values,curls=geom.q_and_curl(x,bounds,n,t,side)
  exp=np.array([float(ev(q[t],v)) for v in points]);expc=np.array([[float(ev(c,v)) for c in curl(q)] for v in points])
  exps=np.array([float(evscale(q[t],v)) for v in points]);expcs=np.array([[float(evscale(c,v)) for c in curl(q)] for v in points])
  checks.append(check(values[0],exp,exps,'q values '+str((n,t,side))));checks.append(check(curls[0],expc,expcs,'q curl '+str((n,t,side))))
  # Tangent coarse edges have b at an endpoint; all other edge directions see zero dot product.
  mask=np.array([p[b] in (lo[b],hi[b]) for p in points]);checks.append(check(values[0,mask],np.zeros(np.sum(mask)),np.ones(np.sum(mask)),'coarse edge zero'))
  outer=lo[n] if side==0 else hi[n];mask=np.array([p[n]==outer for p in points]);checks.append(check(values[0,mask],np.zeros(np.sum(mask)),np.ones(np.sum(mask)),'outer normal boundary zero'))
  mid=[(lo[j]+hi[j])/2 for j in range(3)];mid[n]=hi[n] if side==0 else lo[n]
  faceval=geom.q_and_curl(np.array([[mid]],dtype=float),bounds,n,t,side)[0][0,0]
  checks.append(check(faceval,1.,1.,'common face tangential value'))
  # E_t is piecewise linear with slopes1 and2, continuous at the face.
  edge_values=[]
  base=F('0.1') if n==0 else F('-0.2') if n==1 else F('0.3')
  for a in range(3):
   transverse=[j for j in range(3) if j!=a]
   for second,first in product((0,1),repeat=2):
    start=lo.copy()
    for j,bit in zip(transverse,(first,second)):start[j]=hi[j] if bit else lo[j]
    value=start[n]-base if side==0 else F('.03')+2*(start[n]-base-F('.03'))
    edge_values.append(float(value) if a==t else 0.)
  kfield=got['K'][0]@edge_values;jump_totals.setdefault((n,t),[]).append(float(kfield))
 for key,terms in jump_totals.items():
  target=-float(F('.04')*F('.07')*F(2,3));checks.append(check(sum(terms),target,sum(abs(x) for x in terms),'piecewise curl jump '+str(key)))
  assert abs(terms[0]-terms[1]-target)>128*EPS*sum(abs(x) for x in terms)
  assert abs(terms[0]-target)>128*EPS*sum(abs(x) for x in terms)
 # New represented-current moments. No saved arrays or physical primary targets.
 from numpy.polynomial.legendre import leggauss
 source_checks=[];omega=3.
 for n,t,side,lo,hi,q,bases,e in rows:
  bounds=np.array([[lo,hi]],dtype=float);width=bounds[:,1]-bounds[:,0]
  for order in (2,4):
   a,w=leggauss(order);a=(a+1)/2;w=w/2
   ref=np.array(list(product(a,a,a)));weights=np.array([wx*wy*wz for wx,wy,wz in product(w,w,w)])[None,:]*np.prod(width)
   points=bounds[:,0,None,:]+width[:,None,:]*ref[None,:,:]
   for powers in ((0,0,0),(1,1,1),(3,3,3)):
    if order==2 and powers==(3,3,3):continue
    current=np.zeros_like(points,dtype=complex);current[:,:,t]=(1+2j)*np.prod(points**np.array(powers)[None,None,:],axis=2)
    value,scale=moments.source_action(points,weights,current,bounds,n,t,side,omega)
    exact,es=integ(mul(q[t],{powers:F(1)}),lo,hi);expected=-1j*omega*(1+2j)*float(exact)
    source_checks.append(check(value[0],expected,scale[0]+omega*abs(1+2j)*float(es),'source degree '+str((n,t,side,order,powers))))
    if powers==(0,0,0):assert abs(value[0]-expected/(-1j*omega))>128*EPS*(abs(value[0])+abs(expected))
 keys,cells=geom.enumerate_probes((2,1,1));assert keys.tolist()==[[0,1,0,0,1],[0,1,0,0,2]] and cells.tolist()==[[0,1],[0,1]]
 selection_checks=[]
 for count,expected in [(40,True),(60,False)]:
  k=np.array([[0,i,0,0,1] for i in range(count)],dtype=np.int32);c=np.array([[2*i,2*i+1] for i in range(count)],dtype=np.int32)
  f=np.ones(count,dtype=complex);out=selection.select(k,c,f,np.ones(count),f,f,np.ones(count)*4,np.ones(count))
  assert out['selected_indices'].tolist()==list(range(24)) and out['result']['candidate_defined']==expected
  selection_checks.append(out['result'])
 k=np.array([[0,i,0,0,1] for i in range(4)],dtype=np.int32);c=np.array([[0,1],[1,2],[3,4],[5,6]],dtype=np.int32);f=np.ones(4,dtype=complex)
 out=selection.select(k,c,f,np.ones(4),f,f,np.ones(4)*4,np.ones(4));assert out['selected_indices'].tolist()==[0,2,3]
 bad=selection.select(k,c,f,np.ones(4),np.zeros(4),np.zeros(4),np.ones(4),np.ones(4));assert bad['result']['status']=='source_action_unresolved'
 bad=selection.select(k,c,f,np.ones(4),f*1.01,f,np.ones(4),np.ones(4));assert not bad['result']['source_pair_pass']
 margin=128*EPS*np.ones(4)*4
 threshold=selection.select(k,c,10*margin,np.ones(4),f,f,np.ones(4)*4,np.ones(4));assert not np.any(threshold['resolved'])
 for name,value in {'new_M':actual_m,'new_K':actual_k}.items():
  with (stage/(name+'.npy')).open('xb') as stream:np.save(stream,np.asarray(value),allow_pickle=False)
 return {'status':'new_face_controls_pass','physical_moment_cases':12,'checks':checks,'source_checks':source_checks,'selection_checks':selection_checks,'curl_sign_and_omission_negatives':True,'source_sign_negative':True,'disjoint_tie_undefined_pair_resolution_negatives':True,'old_tests_replayed':0}
