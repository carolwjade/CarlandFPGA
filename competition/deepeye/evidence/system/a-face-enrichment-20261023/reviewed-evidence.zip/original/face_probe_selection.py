"""Frozen source, resolution and concentration gates; no receiver information."""
import math
import numpy as np
EPS=np.finfo(float).eps
def select(keys,cells,ell,d,F2,F4,scale,F4_scale):
    keys=np.asarray(keys);cells=np.asarray(cells);ell=np.asarray(ell);d=np.asarray(d);F2=np.asarray(F2);F4=np.asarray(F4);scale=np.asarray(scale);F4_scale=np.asarray(F4_scale);N=len(ell)
    if keys.shape!=(N,5) or cells.shape!=(N,2) or any(a.shape!=(N,) for a in (d,F2,F4,scale,F4_scale)):raise ValueError('selection shapes')
    if any(not np.all(np.isfinite(a)) for a in (ell,d,F2,F4,scale,F4_scale)) or np.any(d<=0) or np.any(scale<0) or np.any(F4_scale<0):raise ValueError('selection finite scales')
    high=float(np.max(abs(F4),initial=0));floor=128*EPS*float(np.max(F4_scale,initial=0));difference=float(np.max(abs(F4-F2),initial=0))
    stable=high>floor;pair=difference/high if stable else None;source_pass=stable and pair<=.001
    margin=abs(F4-F2)+128*EPS*scale;resolved=abs(ell)>10*margin;score=abs(ell)**2/d
    if not np.all(np.isfinite(score)):raise ValueError('nonfinite indicator')
    selected=[];coverage=0.;total=math.fsum(float(x) for x in score[resolved])
    if source_pass:
        # np.lexsort uses last key as primary; ascending key breaks descending-score ties.
        order=np.lexsort((keys[:,4],keys[:,3],keys[:,2],keys[:,1],keys[:,0],-score));occupied=set()
        for index in order:
            if not resolved[index]:continue
            left,right=(int(x) for x in cells[index])
            if left in occupied or right in occupied:continue
            selected.append(int(index));occupied.update((left,right))
            if len(selected)==24:break
        if total>0:coverage=math.fsum(float(score[i]) for i in selected)/total
    defined=bool(source_pass and len(selected)>0 and coverage>=.50)
    result={'status':'source_action_unresolved' if not source_pass else 'candidate_enrichment_defined' if defined else 'bounded_enrichment_not_supported',
      'source_pair_pass':bool(source_pass),'source_pair_relative_inf':pair,'source_pair_gate':.001,'source_high_inf':high,'source_difference_inf':difference,'source_high_roundoff_threshold':floor,
      'resolved_probes':int(np.count_nonzero(resolved)),'total_probes':N,'selected_count':len(selected),'selected_score_fraction':coverage,'concentration_gate':.50,'maximum_patches':24,'resolution_margin_multiple':10,
      'candidate_defined':defined,'score_is_not_error_bound':True,'solver_selected':False}
    return {'result':result,'selected_indices':np.array(selected,dtype=np.int32),'score':score,'margin':margin,'resolved':resolved}
