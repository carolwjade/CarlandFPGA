"""Inert preflight: exact accepted pins, headers, current contract and reporter."""
import ast,hashlib,json,struct,sys
from pathlib import Path
D=Path(__file__).resolve().parent;P=D.parent;ROOT=D.parents[2]
HELPER=ROOT/'.local/deepeye-implementation-a/competition/deepeye/tools/evidence_json.py'
sys.path.insert(0,str(HELPER.parent));from evidence_json import write_new_report
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def header(p):
 with p.open('rb') as f:
  assert f.read(6)==b'\x93NUMPY';v=tuple(f.read(2));n=struct.unpack('<H' if v==(1,0) else '<I',f.read(2 if v==(1,0) else 4))[0]
  return ast.literal_eval(f.read(n).decode('latin1' if v[0]<3 else 'utf8'))
design=P/'g03-next-precision-design-20261023';pins=read(design/'source-pins.json')['files']
assert all(pin(ROOT/n)==p for n,p in pins.items())
for n,sha in [('design.md','afc07e483f61b6960b23274144c770261ec2f5ce305e2388222e846c95e36543'),('design.json','eef139449439641d6cb18f5928c08dd7348a15d42413c9b2a37d9eb5dd35e4d4'),('manifest.json','a4f215b65bbdc3b66219245fd4f3fdf91bee3a3e1ec197447cc0c2b08c8043c5')]:
 assert pin(design/n)['sha256']==sha;pins[(design/n).relative_to(ROOT).as_posix()]=pin(design/n)
old=read(P/'g03-consistent-solve-20261023/input-pins.json')
aliases={n:old['paths'][n] for n in ('bounds','mapping','cell_ids','B','gB','starts','ends','L5_assignment','S1_assignment')}
aliases['field']=(P/'g03-consistent-candidate-independent-20261023/audit-01/candidate_E4_full_Vpm.npy').relative_to(ROOT).as_posix()
for order in (2,4):
 for key in ('new_target_points_m','new_target_weights_m3','equivalent_current_Apm2'):
  aliases[f'g{order}_{key}']=(P/f'g03-s3-json-continuation-20261021/projection-01/g{order}_{key}.npy').relative_to(ROOT).as_posix()
for key in ('cell_ids','cell_bounds_m'):
 aliases['source_'+key]=(P/f'g03-s3-json-continuation-20261021/projection-01/{key}.npy').relative_to(ROOT).as_posix()
for n in aliases.values():
 expected=pins.get(n,old['files'].get(n));assert expected is not None and pin(ROOT/n)==expected;pins[n]=expected
for path in [HELPER,P/'r02-amd-wheel-acquisition-20261021/win_job.py',P/'r02-amd-wheel-acquisition-20261021/boundary.py',ROOT/'.local/deepeye-fdem-validation-20261020/Scripts/python.exe']:
 pins[path.relative_to(ROOT).as_posix()]=pin(path)
assert pin(HELPER)['sha256']=='a0aabdbf259f7232bf3e1e77a81d130a8f676ad0b87eba39fae99d118f858554'
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
assert hashlib.sha256(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json');assert transfer['status']=='active' and transfer['director_generation']==2
headers={a:header(ROOT/n) for a,n in aliases.items() if n.endswith('.npy')}
assert headers['field']['shape']==(63250,) and headers['field']['descr']=='<c16'
assert headers['mapping']['shape']==(19584,12) and headers['bounds']['shape']==(19584,2,3)
assert headers['source_cell_ids']['shape']==(64,)
for o in (2,4):
 assert headers[f'g{o}_equivalent_current_Apm2']['shape']==(64,o**3,3)
write_new_report(D/'input-pins.json',{'files':pins,'aliases':aliases,'headers':headers,'payloads_decoded':0,'canonical_scope_verified':True,'reporter_byte_exact':True})
print(json.dumps({'status':'inert_preflight_pass','pins':len(pins),'headers':len(headers)}))
