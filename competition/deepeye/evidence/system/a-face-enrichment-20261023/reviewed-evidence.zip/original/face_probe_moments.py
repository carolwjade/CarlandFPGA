"""Separable analytic face-bubble moments; no sparse operator or old kernel."""
from functools import lru_cache
import numpy as np
def product_integral(a,b):
    c=[0.]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    return sum(x/(i+1) for i,x in enumerate(c)),sum(abs(x)/(i+1) for i,x in enumerate(c))
def deriv(p):return tuple(i*x for i,x in enumerate(p) if i) or (0.,)
def integrate_factors(a,b):
    val=1.;scale=1.
    for x,y in zip(a,b):v,s=product_integral(x,y);val*=v;scale*=s
    return val,scale
def sign(c,d,a):return 1 if (c,d,a) in ((0,1,2),(1,2,0),(2,0,1)) else -1
@lru_cache(maxsize=12)
def table(n,t,side):
    if n not in (0,1,2) or t not in (0,1,2) or n==t or side not in (0,1):raise ValueError('probe axes/side')
    b=3-n-t;Q=[(1.,)]*3;Q[n]=(0.,1.) if side==0 else (1.,-1.);Q[b]=(0.,4.,-4.)
    result=[]
    for a in range(3):
        transverse=[j for j in range(3) if j!=a]
        for second in (0,1):
            for first in (0,1):
                N=[(1.,)]*3
                for j,bit in zip(transverse,(first,second)):N[j]=(0.,1.) if bit else (1.,-1.)
                mv,ms=integrate_factors(N,Q) if a==t else (0.,0.)
                terms=[]
                for d in transverse:
                    c=3-d-a;ND=list(N);ND[d]=deriv(ND[d])
                    for r in (n,b):
                        if 3-r-t!=c:continue
                        QD=list(Q);QD[r]=deriv(QD[r]);value,scale=integrate_factors(ND,QD)
                        terms.append((d,r,sign(c,d,a)*sign(c,r,t)*value,scale))
                result.append((mv,ms,terms))
    return result
def local_moments(widths,normal,tangent,side):
    h=np.asarray(widths,dtype=float)
    if h.ndim!=2 or h.shape[1]!=3 or not np.all(np.isfinite(h)) or np.any(h<=0):raise ValueError('positive finite cell widths')
    rows=table(normal,tangent,side);v=np.prod(h,axis=1);count=len(h)
    M=np.empty((count,12));K=np.zeros_like(M);Ms=np.empty_like(M);Ks=np.zeros_like(M)
    for j,(m,ms,terms) in enumerate(rows):
        M[:,j]=v*m;Ms[:,j]=v*ms
        for d,r,k,ks in terms:
            factor=v/(h[:,d]*h[:,r]);K[:,j]+=factor*k;Ks[:,j]+=factor*ks
    b=3-normal-tangent
    Mq=v*(8/45);Kq=v*(8/(15*h[:,normal]**2)+16/(9*h[:,b]**2))
    return {'M':M,'K':K,'Ms':Ms,'Ks':Ks,'Mq':Mq,'Kq':Kq}
def source_action(points,weights,current,bounds,normal,tangent,side,omega):
    from face_probe_geometry import q_and_curl
    points=np.asarray(points);weights=np.asarray(weights);current=np.asarray(current)
    if current.shape!=points.shape or weights.shape!=points.shape[:2] or not np.isfinite(omega):raise ValueError('source layout')
    if not np.all(np.isfinite(current)) or not np.all(np.isfinite(weights)) or np.any(weights<=0):raise ValueError('source finite positive weights')
    q,_=q_and_curl(points,bounds,normal,tangent,side)
    terms=weights*q*current[:,:,tangent]
    return -1j*omega*np.sum(terms,axis=1),abs(omega)*np.sum(abs(terms),axis=1)
