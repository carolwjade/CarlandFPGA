"""Frozen new-control/source review; no scientific imports or test execution."""
import difflib,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];S=D.parent/'g03-face-enrichment-20261023'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
assert pin(S/'control-source-pins.json')['sha256']=='79f2fab446a319706d6f82394247053aba9cf0fbc4d8a19c08aa744312857b7e'
assert pin(S/'controls-01/result.json')['sha256']=='82b6141ede51389758d416e2b884efae9c9c4a4153c369f6cde8e7b962f400ce'
control=read(S/'control-source-pins.json');original=read(S/'red-source-pins.json');inputs=read(S/'input-pins.json')['files'];used={}
for name,v in inputs.items():assert pin(ROOT/name)==v,name;used[name]=v
for name in ['face_probe_geometry.py','face_probe_moments.py','face_probe_selection.py','probe_stage.py','test_face_probes.py']:
 q=S/name;k=q.relative_to(ROOT).as_posix();assert pin(q)==control[k],k;used[k]=pin(q)
revision=read(S/'pre-green-control-revision.json')
for name,snapshot in [('test_face_probes.py','red-test-source.py'),('run_probes.py','red-runner-source.py')]:
 assert pin(S/snapshot)==original[(S/name).relative_to(ROOT).as_posix()]
 before=(S/snapshot).read_text(encoding='utf-8');after=(S/name).read_text(encoding='utf-8')
 # Root has a pending orchestration-only post-GREEN change. Test is frozen;
 # runner's GREEN identity is in control pins and the revision record.
 assert revision['revised'][name]==control[(S/name).relative_to(ROOT).as_posix()]
 if name=='test_face_probes.py':
  assert pin(S/name)==revision['revised'][name]
  with (D/'verified-pre-green-test-diff.patch').open('x',encoding='utf-8') as f:f.write(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='RED-test',tofile='first-GREEN-test')))
for phase in ['red','controls']:
 t=read(S/(phase+'-01')/'terminal.json');rb=read(S/(phase+'-01')/'input-readback.json')
 assert t['all_processes_terminated'] and t['active_processes_final']==0 and len(t['held_members'])==3 and all(h['signaled'] and h['wait_result']==0 for h in t['held_members'])
 assert rb['unchanged'] and rb['before']==rb['after']
 for stream in ['stdout','stderr']:assert pin(S/(phase+'-01')/(stream+'.txt'))==t['logs'][stream]
 if phase=='controls':assert t['exit_code']==0 and json.loads((S/'controls-01/stdout.txt').read_text())==read(S/'controls-01/result.json')
 else:assert t['exit_code']==1 and read(S/'red-01/failure.json')['message']=='face bubble moments not implemented'
 expected=S/(phase+'-01')/'physical-rational-expectations.json'
 assert pin(expected)['sha256']=='58a599eff300b6fbcdc95d9456a8c641c0b73b36112effe7b939c0ada526745d'
 for q in (S/(phase+'-01')).iterdir():
  if q.is_file():used[q.relative_to(ROOT).as_posix()]=pin(q)
result=read(S/'controls-01/result.json');assert result['physical_moment_cases']==12 and len(result['checks'])==114 and len(result['source_checks'])==60
assert all(v['passed'] for v in result['checks']+result['source_checks'])
assert result['curl_sign_and_omission_negatives'] and result['source_sign_negative'] and result['disjoint_tie_undefined_pair_resolution_negatives']
runtime=read(S/'controls-01/worker-evidence.json')
for label in ['runtime_before','runtime_after']:
 assert all(v['threads']==1 for v in runtime[label]['BLAS'])
 for v in runtime[label]['BLAS']:
  q=Path(v['path']);assert pin(q)['sha256']==v['sha256'];used[q.relative_to(ROOT).as_posix()]=pin(q)
for name in ['control-source-pins.json','red-source-pins.json','pre-green-control-revision.json','red-test-source.py','red-runner-source.py','root-design-selection.json','input-pins.json']:
 q=S/name;used[q.relative_to(ROOT).as_posix()]=pin(q)
save('controls-reviewed-source-pins.json',used)
save('pre-execution-controls-review.json',{'status':'math_and_first_GREEN_evidence_reviewed','blocking_math_findings':[],'final_orchestration_review_pending':True,'indicator_selected':False,'control_source_pins_sha256':pin(S/'control-source-pins.json')['sha256'],'controls_result_sha256':pin(S/'controls-01/result.json')['sha256'],'expectation_sha256':'58a599eff300b6fbcdc95d9456a8c641c0b73b36112effe7b939c0ada526745d','physical_cases':12,'polynomial_checks':114,'source_checks':60,'negative_cases_recorded':True,'all6heldsignaled':True,'controls_replayed_by_reviewer':0,'used_pin_count':len(used)})
print(json.dumps(read(D/'pre-execution-controls-review.json')))
