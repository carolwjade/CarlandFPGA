"""Compact saved-array gate/readback audit only; no NumPy or probe imports.

This verifies the scalar source gate and empty selection against saved arrays.
It does not recalculate any face source/coupling/residual/score map.
"""
import array,ast,hashlib,json,math,struct,sys
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];S=D.parent/'g03-face-enrichment-20261023';A=S/'indicator-01'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
assert pin(A/'result.json')['sha256']=='abe0a8e88649b9ae8dc19933ba47fd50f66468c5f0adce623b5a3e3aa48e661a'
assert pin(A/'input-readback.json')['sha256']=='6b6b21e4b13318e10f141394ae12059cc4bb58d78d6f44dada0d593599d3ff42'
used=read(D/'pre-execution-source-pins.json');assert all(pin(ROOT/n)==v for n,v in used.items())
final=read(S/'indicator-source-pins.json');rb=read(A/'input-readback.json');assert rb['unchanged'] and rb['before']==rb['after']==final
r=read(A/'result.json');t=read(A/'terminal.json');start=read(A/'started.json');failure=read(A/'failure.json');runtime=read(A/'worker-evidence.json')
assert r['status']=='source_action_unresolved' and r['source_pair_pass'] is False and r['candidate_defined'] is False and r['solver_selected'] is False
assert r['selected_count']==0 and r['selected_score_fraction']==0 and r['coupling_checks']==[]
assert t['status']=='failed' and t['exit_code']==2 and t['stop_reason'] is None and t['all_processes_terminated'] and t['active_processes_final']==0
assert len(t['held_members'])==3 and all(h['signaled'] and h['wait_result']==0 for h in t['held_members'])
assert failure['type']=='SystemExit' and failure['message']=='2' and json.loads((A/'stdout.txt').read_text())==r
for stream in ['stdout','stderr']:assert pin(A/(stream+'.txt'))==t['logs'][stream]
assert start['budget']['seconds']==60 and start['readback_limits']=={'job_memory_bytes':1024**3,'process_memory_bytes':512*1024**2,'active_processes':3}
for label in ['runtime_before','runtime_after']:
 assert all(v['threads']==1 for v in runtime[label]['BLAS'])
 for v in runtime[label]['BLAS']:
  q=Path(v['path']);assert pin(q)['sha256']==v['sha256'];used[q.relative_to(ROOT).as_posix()]=pin(q)
def npy(name,payload=False):
 p=A/(name+'.npy');b=p.read_bytes();assert b[:6]==b'\x93NUMPY';version=b[6:8]
 if version==b'\x01\x00':n=struct.unpack('<H',b[8:10])[0];offset=10
 elif version in (b'\x02\x00',b'\x03\x00'):n=struct.unpack('<I',b[8:12])[0];offset=12
 else:raise ValueError('NPY version')
 h=ast.literal_eval(b[offset:offset+n].decode('utf-8'));assert not h['fortran_order'];used[p.relative_to(ROOT).as_posix()]=pin(p)
 return h,b[offset+n:] if payload else None
def doubles(name,complex_values=False):
 h,b=npy(name,True);assert h['descr']==('<c16' if complex_values else '<f8') and h['shape']==(113088,)
 a=array.array('d');a.frombytes(b)
 if sys.byteorder!='little':a.byteswap()
 assert len(a)==113088*(2 if complex_values else 1) and all(math.isfinite(v) for v in a)
 return a
f2=doubles('F2',True);f4=doubles('F4',True);s4=doubles('F4_scale');assert all(v>=0 for v in s4)
high=max(abs(complex(f4[i],f4[i+1])) for i in range(0,len(f4),2))
difference=max(abs(complex(f4[i]-f2[i],f4[i+1]-f2[i+1])) for i in range(0,len(f4),2))
floor=128*sys.float_info.epsilon*max(s4);ratio=difference/high
scalar_errors={}
for key,observed in [('source_high_inf',high),('source_difference_inf',difference),('source_high_roundoff_threshold',floor),('source_pair_relative_inf',ratio)]:
 expected=r[key];bound=128*sys.float_info.epsilon*(abs(expected)+abs(observed));error=abs(expected-observed);assert error<=bound
 scalar_errors[key]={'reduced_value':observed,'recorded_value':expected,'absolute_difference':error,'comparison_bound':bound}
assert high>floor and ratio>r['source_pair_gate']==.001
h,mask=npy('resolved',True);assert h['shape']==(113088,) and h['descr']=='|b1' and len(mask)==113088 and mask.count(1)==r['resolved_probes']==113088
headers={}
for name in ['keys','cells','mass','curl','Mq','Kq','D','ell','score','arithmetic_scale','resolution_margin','positive_energy_diagonal','mass_scale','curl_scale','F2_scale']:
 h,_=npy(name);assert h['shape'][0]==113088;headers[name]=h
assert headers['keys']['shape']==(113088,5) and headers['cells']['shape']==(113088,2)
for name in ['tentative_selected_indices','selected_cells','selected_D','selected_ell','selected_fQ','selected_keys','selected_U_B_gB','selected_U_edge_ids','selected_U_full_field_action','selected_U_lengths','selected_U_values']:
 h,b=npy(name,True);assert h['shape'][0]==0 and len(b)==0;headers[name]=h
for q in A.iterdir():
 if q.is_file():used[q.relative_to(ROOT).as_posix()]=pin(q)
decision=read(S/'root-indicator-selection.json');assert decision['indicator_attempt_selected'] is True and decision['source_pins_sha256']==pin(S/'indicator-source-pins.json')['sha256']
used[(S/'root-indicator-selection.json').relative_to(ROOT).as_posix()]=pin(S/'root-indicator-selection.json')
save('source-pins.json',used)
save('indicator-review.json',{'status':'original_failed_source_gate_verified','original_indicator_status':r['status'],'original_exit':2,'source_gate_reduction':scalar_errors,'source_high_denominator_defined':True,'source_gate_failed_unchanged':True,'selected_count':0,'all_selected_outputs_empty':True,'total_direction_headers':113088,'resolved_count_from_saved_mask':113088,'concentration_screen':'not reached after failed source gate; no24patch candidate','raw_header_checks':headers,'terminal':t,'runtime_before_after_BLAS1':True,'input_source_readbacks_unchanged':True,'scientific_imports_by_review':0,'face_map_source_moments_or_scores_recomputed':0,'new_array_work':'stdlib compact F2/F4 gate reduction, resolved-mask count and shape/empty selection checks only','new_test_or_indicator_execution':False,'used_pin_count':len(used),'root_retains':'acceptance and next numerical choice','G03':'not_run','R03':'not_run','all29':'not_run','physical_accuracy':'unqualified'})
print(json.dumps({'status':'source_gate_failure_confirmed','source_pair':ratio,'source_gate':.001,'selected_count':0,'all_selected_outputs_empty':True,'pins':len(used),'all3heldsignaled':True,'map_recomputed':False}))
