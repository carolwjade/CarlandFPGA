"""Final author seal review after original source-gate failure; no numerics."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];S=D.parent/'g03-face-enrichment-20261023';M=D.parent/'g03-face-enrichment-main-review-20261023'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
old=read(D/'manifest.json');assert all(pin(D/n)==v for n,v in old['files'].items())
assert pin(S/'manifest.json')['sha256']=='be76a5f5fd79c84e4396bea30fd7ce7214c62757c44c46eb63ab90c73ab0781c'
assert pin(S/'summary.json')['sha256']=='b22639af8c491991ce7543247e7bf8ae70897208c7f65f2358c1926086caaef5'
author=read(S/'manifest.json');used={}
for n,v in author['files'].items():
 q=S/n;assert pin(q)==v,n;used[q.relative_to(ROOT).as_posix()]=v
assert len(author['files'])==91 and sum(v['bytes'] for v in author['files'].values())==23523959
summary=read(S/'summary.json');assert summary['status']=='failed_fixed_source_action_gate_no_retry' and summary['indicator_result']==read(S/'indicator-01/result.json')
assert summary['indicator_result']['candidate_defined'] is False and summary['indicator_result']['selected_count']==0
for q in [S/'manifest.json',M/'actual-result-readback.json']:
 used[q.relative_to(ROOT).as_posix()]=pin(q)
assert read(M/'actual-result-readback.json')['result_sha256']==pin(S/'indicator-01/result.json')['sha256']
save('sealed-author-source-pins.json',used)
save('sealed-author-review.json',{'status':'author_seal_independently_verified','original_author_work_id':'A-G03-FACE-ENRICHMENT-20261023-v1','original_author_job_id':'child-dd1ebf92a342433bb72ad989a2cf5a84','original_author_native_terminal':'root reported failed/terminal/nonstale/resultnull; not re-queried by this child','original_manifest':pin(S/'manifest.json'),'original_summary':pin(S/'summary.json'),'manifest_entries_verified':91,'manifest_total_bytes':23523959,'result_summary_matches_actual_stage':True,'original_indicator_status':'source_action_unresolved','original_stage_exit':2,'no_candidate_or_solve':True,'zero_selection_meaning':'source gate prevented selection;50percentconcentration was not evaluated as an acceptance outcome','previous_review_seal_preserved':pin(D/'manifest.json'),'new_numerical_or_array_work':0})
excluded={'lease.private.json','manifest-final.json','native-completion.json','final-seal-verification.json'}
files={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in excluded and p.suffix!='.pyc'}
save('manifest-final.json',{'work_id':'A-G03-FACE-ENRICHMENT-REVIEW-20261023-v1','files':files,'private_and_postseal_records_excluded':sorted(excluded),'first_review_seal_preserved':True,'author_seal_review_added':True})
assert all(pin(D/n)==v for n,v in read(D/'manifest-final.json')['files'].items())
assert all(pin(ROOT/n)==v for n,v in read(D/'source-pins.json').items())
save('final-seal-verification.json',{'status':'verified','manifest':pin(D/'manifest-final.json'),'entries':len(files),'original_review_entries_unchanged':len(old['files']),'original_author_manifest_entries_verified':91,'original_indicator_failed_gate_preserved':True,'new_science':0})
print(json.dumps(read(D/'final-seal-verification.json')))
