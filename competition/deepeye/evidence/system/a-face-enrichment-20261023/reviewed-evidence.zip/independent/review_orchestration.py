"""Definitive frozen orchestration review, no test or indicator execution."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2];S=D.parent/'g03-face-enrichment-20261023'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
assert pin(S/'indicator-source-pins.json')['sha256']=='3b0160dd8fe2179d310675a55e9322a1dc35a5e0bc9a947a4174e366faf66281'
final=read(S/'indicator-source-pins.json');control=read(S/'control-source-pins.json');assert set(final)==set(control)
changed={k for k in final if final[k]!=control[k]};expected={(S/n).relative_to(ROOT).as_posix() for n in ['probe_worker.py','run_probes.py']};assert changed==expected
assert all(pin(ROOT/k)==v for k,v in final.items())
record=read(S/'post-green-report-revision.json')
for name,snapshot in [('probe_worker.py','green-worker-source.txt'),('run_probes.py','green-runner-source.txt')]:
 assert pin(S/snapshot)==record['changed'][name]['old']==control[(S/name).relative_to(ROOT).as_posix()]
 assert pin(S/name)==record['changed'][name]['new']==final[(S/name).relative_to(ROOT).as_posix()]
worker=(S/'green-worker-source.txt').read_text(encoding='utf-8')
worker=worker.replace('from evidence_json import write_new_report as save','from evidence_json import write_new_report as save,dumps_report').replace('print(json.dumps(result),flush=True)',"print(dumps_report(result),end='',flush=True)")
assert worker==(S/'probe_worker.py').read_text(encoding='utf-8')
assert pin(S/'probe_worker.py')['sha256']=='51d1636515d83a7298c2e281c36f57134531394567070e25cda0a18f598a1ac1'
assert pin(S/'run_probes.py')['sha256']=='096ebff35ad217dd81cfa0d89036ef9b6a342cf0b5576c99a46715dadaf07ad4'
used=read(D/'controls-reviewed-source-pins.json')
for k,v in final.items():used[k]=v
for q in [S/'indicator-source-pins.json',S/'post-green-report-revision.json',S/'post-green-report-revision.diff',S/'green-worker-source.txt',S/'green-runner-source.txt']:
 used[q.relative_to(ROOT).as_posix()]=pin(q)
save('pre-execution-source-pins.json',used)
save('pre-execution-review.json',{'status':'definitive_preexecution_source_review_complete','blocking_findings':[],'bounded_indicator_attempt_acceptable_for_root_selection':True,'indicator_authorized_by_reviewer':False,'full_indicator_execution_by_reviewer':False,'indicator_source_pins_sha256':pin(S/'indicator-source-pins.json')['sha256'],'first_GREEN_reused_without_replay':True,'math_and_test_sources_unchanged_after_GREEN':True,'post_GREEN_changes_only':['worker strict stdout serializer','runner explicit final indicator source-pin authority and math source equality gate'],'before_first_GREEN_revision':'Independent Fraction absolute evaluation terms replace zero cancellation scales; expected answers and128eps unchanged; preserved original RED snapshots verified.','independent_derivation':'See derivation-notes.md','scope_limits':['Residual priority/concentration heuristic, not physical error estimator','Archived source representation consistency, not physical source certificate','No receiver/reference input to selection','No global assembly/solver/enriched correction selected','Original failed GMRES/serialization/physical screens unchanged'],'used_pin_count':len(used),'root_retains':'one indicator selection and final acceptance; review job remains open for actual result'})
print(json.dumps(read(D/'pre-execution-review.json')))
