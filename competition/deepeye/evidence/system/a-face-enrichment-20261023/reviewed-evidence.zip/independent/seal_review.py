"""Seal the actual failed-gate review without replaying scientific stages."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(n,x):
 with (D/n).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
src=read(D/'source-pins.json');assert all(pin(ROOT/n)==v for n,v in src.items())
indicator=read(D/'indicator-review.json');pre=read(D/'pre-execution-review.json');controls=read(D/'pre-execution-controls-review.json')
assert pre['blocking_findings']==[] and indicator['source_gate_failed_unchanged'] and indicator['selected_count']==0 and indicator['all_selected_outputs_empty']
scope=read(ROOT/'docs/competition/deepeye-2026/immutable_scope.json');h=hashlib.sha256(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=read(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json');assert transfer['status']=='active' and transfer['director_generation']==2
review={'work_id':'A-G03-FACE-ENRICHMENT-REVIEW-20261023-v1','job_id':'child-92743365a722473f85fc285f2fffdebf','agent_id':'/root/g03_hodge_independent_20261023','status':'independent_review_complete_source_gate_failure_confirmed','formal_acceptance_by_child':False,'preexecution':pre,'controls':controls,'indicator':indicator,'findings':[{'id':'F1','severity':'medium','kind':'blocking_scientific_gate','text':'New source-functional comparison exceeds unchanged0.001gate; source_action_unresolved, no selected enrichment candidate or solve.'},{'id':'L1','severity':'low','kind':'scope_limit','text':'Positive scalar score/resolution/concentration heuristics do not certify physical accuracy or future conditioning; selected-U branch had zero rows.'}],'confirmed_implementation_defects':[],'root_retains':'next numerical choice, implementation/integration and final acceptance','old_tests_or_scientific_stages_replayed':0,'new_calculation_by_reviewer':'stdlib compact saved-vector source gate reduction, mask count, headers only','requirements_sha256':h,'H01_H15_preserved':True,'director':transfer['new_director_thread_id'],'director_generation':2,'physical_accuracy':'unqualified','finite_strength_noise_calibration_OOD_training':'unqualified','G03':'not_run','R03':'not_run','all29':'not_run'}
save('review.json',review)
excluded={'lease.private.json','manifest.json','native-completion.json','final-verification.json'}
files={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in excluded and p.suffix!='.pyc'}
save('manifest.json',{'work_id':review['work_id'],'files':files,'private_and_postseal_records_excluded':sorted(excluded)})
assert all(pin(D/n)==v for n,v in read(D/'manifest.json')['files'].items())
save('final-verification.json',{'status':'verified','manifest':pin(D/'manifest.json'),'entries':len(files),'used_pins_unchanged':len(src),'original_indicator_status':'source_action_unresolved','original_exit':2,'no_candidate_or_solve':True,'all3indicator_heldsignaled':True,'old_tests_science_replayed':0})
print(json.dumps(read(D/'final-verification.json')))
