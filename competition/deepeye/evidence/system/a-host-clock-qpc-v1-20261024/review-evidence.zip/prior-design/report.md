# 新运行实例统一 QPC host clock 设计

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，工作 `A-HIGH-RES-HOST-CLOCK-DESIGN-20261024-v1`。子代理 `/root/live_slot_design`，新 job `child-90cb280dd9e24b588e15e84f4ec2b8d9` 已单独 validate，canonical agent_id 匹配且 `execution_allowed=true`；未复用已 completed 的旧租约。Gen3 transfer 重读为 active，主线程 `01a16988-bdcb-70e1-ae10-1304b5cf7875`。immutable requirements 再实算为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，H01–H15 不变，A 独占实板。

本轮只读固定提交 `88f7214eeb4770106933b9062445152a520ce4fc` 的 `git show`，不读 v2 作者正在写入的工作文件。仅本目录写证据；没有产品修改、测试、板/串口、UI、服务、产品/peer网络或外部消息操作。native 租约控制例外仅为本任务 validate/complete。

## 选择

选择 **受信任固定 QPC leaf + 每个运行实例显式传播同一个 binding**。新模式只能在一个全新的 run/actor/BOOT/ledger/journal/world/history 建立时选定。原 legacy 默认继续使用原 monotonic，不对现存运行、旧时间戳或旧期限热切换。

| 方案 | 取舍 | 决定 |
|---|---|---|
| 固定 QPC leaf、实例传播 | 少量构造 API 增加显式 binding；能让读写、actor生命、runtime和候选的真实 epoch/domain 一致；可明确拒绝混用。 | 采用。binding 只路由真实时钟，不认证端点、模型或板数据。 |
| 编译期 `perf_counter_ns as monotonic_ns` alias | 修改行数较少，但每个模块分别绑定；遗漏 ActorRegistry 即混 epoch，旧默认被改变，长期保留的 owner/历史记录无法据此转换，事件也缺 domain 归属。 | 不采用本次全局 alias；不做 monkeypatch、全局设置切换或 caller 布尔启用。 |

root 已保存的 `host-clock-capabilities-20261024.json` 实读：venv Python3.12.14，`monotonic` 为 GetTickCount64、advertised resolution 15.625ms；`perf_counter` 为 QueryPerformanceCounter、advertised resolution 100ns，均声明 monotonic/non-adjustable。这只证明本次 capability query。父任务还告知 v2 作者唯一实际等待提前约7ms返回、未消费；本子任务未读其未封存文件、未重试该等待，不改变 origin/W/期限，也不把新 QPC 方案倒填为该次成功。

QPC 的 monotonic 性不表示与 GetTickCount64 共 epoch；禁止根据分辨率、当前差值或一次双读，给旧记录加 offset 后放入新运行。100ns advertised resolution 不等于调用延迟、timestamp uncertainty、scheduler jitter、transport 或 ADC/source bounds。

## 固定提交中的准确获取点

路径均相对产品 `competition/deepeye/`，行号及 SHA 固定在 source-pins。

| 边界 | 现在的取得点 | 新 QPC 模式必须做的事 |
|---|---|---|
| OS 读与 availability | `integration/live_board_receipts.py:110–124` 在原 os.read 前后直接调用模块 monotonic；`:117` 仅 EAGAIN 建立 empty lower；`:215` claim 时又取模块 monotonic。 | 全部从 ledger 固定 binding 取值。原最后字节所属 read 的 end、最后真实 empty 的保守 lower 继续保留；不能把 decode 完成时间或 read begin 当到达 lower。 |
| BOOT 写 | `integration/boot_transcript.py:144` started marker，`:147` fsync 后 `:151` 写前读时钟，`:155` 唯一 os.write，`:163` 写后时钟。 | 从原 ledger 继承同一个 binding，禁止另传第二时钟。durable started_unknown→一次 write 顺序不变；写调用区间仍非 UART 完成。 |
| actor 生命周期与原 HANDLE | `simulation/isolation/actor_owner.py:170` registry 固定 monotonic；`:241` owner._time 读 registry；`:300–302` 设置原 lifetime/readiness。`actor_lifetime.py:27,32,37` 用 owner._time 夹原 `Wait(original_handle,0)`；`:28` 比较 runtime now；`:38–41` 检查 probe/sample/lifetime。 | Registry 必须拿到与 runtime 完全相同的 binding，否则即使两个函数都 monotonic，`:28` 及期限比较仍错误。原 HANDLE/creation FILETIME 身份检查不改；FILETIME 保持身份格式，绝不当 QPC 时间。 |
| composition/progress/mailbox | `actor_composition.py:329` 固定模块 monotonic；`:405–407` 传给 runtime；`:424–425,444–446` 把同一 `_clock` 当 progress/candidate clock_domain；`:460–464` 和 completion/slot verifier 返回后的 `:493,271` 刷新 now。 | `_clock` 绑定同一个 QPC callable 对象，沿现有参数传播；verifier 回调后仍读真实当前值，不能传 slot 时间或 child 自报 now。 |
| runtime/fence | `pc_direct_runtime.py:184,215` 读取依赖时钟；`:429` 原 actor life sample；`:432` 再读当前时间；`:439` 形成最终 fence。`motion_executor.py:341–358` 原一次 callback→严格 end<deadline→唯一 CAS。 | 只更换进入 runtime 的固定真实时钟来源；该最终 fence/CAS 顺序与完整 dt 保持。不在 callback 与 CAS 之间增加 clock/domain 查询或 I/O。 |
| IPC dispatch/read/完成 | `simulation/isolation/pipe_read.py:40–45` 只是原 PeekNamedPipe/至多一次 read 的 inactive leaf，未取时钟；`ipc_framing.py` 仅字节分帧。真实 completion producer 仍缺。 | 后续真实 provider 在原 dispatch write 前/后、原输出 read 前/后采同一 binding，保留原字节/offset/invocation。read interval 仅表示读调用；不是 inference completion lower。最保守 completion lower 可用原 dispatch lower，upper 用原完整输出读回后时刻；需要更紧 lower 时，须有原受审 actor 的真实计算区间证据，不能取较晚 receipt 来续 progress。 |
| candidate / broker issue | 原 `_CompletedInference` 与 ProgressGate 保存 dispatch/completion bounds；原 JSON 字段 `completed_monotonic_ns`、`host_issue_monotonic_ns` 是实质时间，不是命名标签。 | 受审固定 CPU entry 在实际推理边界使用被核实的同 host QPC source；原 candidate claim 必须与原 interval 同域。原 broker 在形成原请求时从该运行 binding 取 issue。不能把旧 child 的 GetTickCount64 字段重写为 owner QPC receipt 后称原完成。 |
| tick/source 映射 | `integration/clock_bounds.py:144–153` 从 receipt 建 anchor，`:156–198` 数值映射；`:210–232` first-sample interval。`sensor_source.py:175–200,202–215,255–262` 保存起始host值、接收now及原source健康。 | 这些纯算术没有自动 domain 认证。新 provider 只把同 binding 原捕获的 receipt、同域测量 bounds、原 source/run origin 交给它们，并在 owner 私有记录中绑定 domain。新 QPC run 重建 anchor/source ledger；不跨域复用旧 anchor/源历史。 |

`pipe_read` 与 framing 目前不建立 endpoint ownership、readiness、原完成或响应性证明；本次时钟工作不把它们升级为 provider。C 固定 CPU 包/因果 broker 和原完成 producer 仍须独立交付。

## 最小 API 与文件变更建议

下一实施任务建议独占下列范围；本设计未修改它们，也没有占用 v2 作者文件。

1. 新 `integration/host_clock.py`：固定 `qpc_clock_for_new_run()` 返回 exact `QpcHostClock`。构造不可接受 caller callable、数值 now、mode 字符串或认证旗标；内部固定实际 `time.perf_counter_ns` leaf，验证本轮 implementation/monotonic/non-adjustable capability，不支持则在 IO/acquisition 前拒绝，不自动 fallback。binding 自身实现 `__call__` 返回原 raw QPC ns；另有 `read_sample()` 返回同一次 raw值与原domain的私有记录，未测定的timestamp interval必须为None，不能从advertisedresolution填入。保存 owner thread、严格有界 int/high-water 及只读 metadata。**使用 binding 自身作为 callable 和 clock_domain**，不要反复取得 `binding.now_ns` 这样的新 bound-method 对象去做 `is` 比较。Python 私有构造和类型检查仅为可信进程内接口约束，不是 OS 权限或认证。
2. `integration/live_board_receipts.py`：`ReceiptLedger(..., host_clock=None)`。None 保持原 legacy 函数；非 None 仅接受上述固定新 binding，不接受普通 callable。新增只读 `clock_domain`，保存具体 stable callable；所有实际时刻及 claim now 都用它。snapshot 增加独立诊断 clock 描述，旧严格 wire/host envelope 不增字段。新 binding 的 metadata 不是来源凭据。
3. `integration/boot_transcript.py`：不增加独立 clock 参数，从 exact 原 ledger 取得并冻结同一个 clock_domain。prepared journal 和 snapshot 记录该诊断域关联；在原 identity 连续性之外，发送/检查继续要求原 ledger 的域未被替换。实际 marker/write 时刻全部同域，原 one-attempt 和 journal不可重开行为不变。
4. `simulation/isolation/actor_owner.py`：`ActorRegistry(*, host_clock=None)`，同样 None legacy、非 None 仅 exact 固定 binding。只将 registry `_clock` 改为该绑定；ActorOwner._time、原 lifetime/readiness 起点、Wait前后取值自然继承。`actor_lifetime.py` 的原算法及身份/超时规则无需修改。
5. `simulation/authority/actor_composition.py`：`create_authority(config, *, host_clock=None)` 是 trusted-main 新版时钟路由，不是 provider 注入；校验 exact binding 后将它传给私有 ActorComposition。`_clock` 使用相同 stable 对象；`_start` 给 ActorRegistry 传同一选择，给 runtime 继续传 `_clock`。私有 `_production_channels(config, *, host_clock=...)` 可接收该关联供未来受审 provider 使用，**函数体仍无条件 ActivationUnavailable，仍先于 registry/actor构建**。不新增 allow/verified/qpc-ready 标志或渠道 fallback。None 路径保持旧默认语义；QPC object 本身不能开放生产门。
6. 新 `docs/host_clock_qpc_v1.md` 与少量新 focused tests，例如 `integration/test_host_clock_qpc_v1.py`、`tests/simulation/test_host_clock_qpc_v1.py`。root须在 v2 作者封存/真实终态后，按最新准确 head 协调 actor_composition 的串行归属；不能因本设计基准较旧覆盖 v2 增量。

无须修改 ABI/profile、`clock_bounds` 纯算术、sensor source 验证、runtime、watchdog、actor_lifetime、candidate_owner 或 motion executor 的运算规则。真实 provider 缺失期间，domain 归属先落实为上述实例参数与诊断 sidecar；未来真实 provider 必须有自己的原记录校验，不能只给旧裸 int 贴一个 `qpc` 字符串就通过。该缺项仍挡生产准入。

## 一个 epoch/domain 的约束

可信 root 在任何本次 IO/actor/world 起点之前只建立一次 QPC binding，将同一对象传给 ledger、BOOT、composition、registry、runtime以及其未来真实 channels。原 `_CompletedInference/_MailboxActivation/_VerifiedSlot.clock_domain` 必须是该对象；progress/candidate继续核 exact identity。`VerifiedEnvelope/VerifiedObservation` 现有字段不变，渠道必须先核原 ledger/原 timing/source owner 的 domain，再产生原 verifier record；不能让任意 sidecar 重建出身份。

同一运行不能在 legacy 与 QPC 间混用，也不能混第二个 binding 的 domain，哪怕其 raw QPC 数值接近。第二个实例、磁盘重建对象、相同 domain_id 字符串不替代本次原记录关联。serialized domain_id 仅是可审阅的相关标签。binding 不比较墙钟 UTC；UTC只作日志日历，不参与deadline。

actor 在另一进程使用 QPC 时，不要求跨进程 Python object identity；由原受审固定 entry、原获得的进程/IPC和本次运行握手记录绑定其时钟实现及 host/run。**本轮 capability文件没有证明 child 进程的时钟来源或跨进程 epoch 一致性**，后续须按实际已安装runtime与受审entry核对，并将进程原时间与 owner 原区间的对应留证。独立 child 声称 domain/QPC、READY 文本或环境变量不足以建立该关联。不从 child 的任意 JSON 建原 completion。

新 world/history 的初始时刻也应从本次 binding 取得，原世界实体与 passage history 重建并记录同域；不能把旧初始状态或旧 motion history 自动解释成 QPC。时钟模式不能在运行中替换；终止/未知旧操作仍先原样对账，换时钟不授权重放。

所有时长策略保持原值与单位。原 completion_lower+progress cap、issue+原TTL、原sample lower+age cap、heartbeat lower+timeout、actor原采样与原lifetimedeadline，均在本次同域首次取得并冻结，取最小值。换来源不延长任何既存期限；旧记录不迁入新run以“保留剩余时长”。已到期或failed状态不因此恢复。QPC 单调也不证明模型响应、H11收益或样本新鲜。

## quantization、原 bracket 与真正“当前”的保守性

统一 raw QPC domain 是第一步，不等于已完成源事件测时。设某个原 raw值q在本domain的真实时间仅能被已独立核实的区间 `[q−u_minus,q+u_plus]` 覆盖；不预设两侧相等，也不把100ns resolution直接填作u。u应包含适用的counter量化/整数转换和timestamp边界不确定性，来源与本次domain绑定；rate/transport/ADC误差仍另算。若这两个边界未知，`read_sample()` 只保留raw/domain，interval=None，不生成“已经测定”的可执行current或source interval。

对原 IO 前raw b、返回后raw e，已成立u时，保守调用bracket是 `[max(0,b−u_minus),e+u_plus]`，检查严格整数溢出/有序性。empty→data的availability lower使用原empty前样本的**lower**，upper使用含原最后字节read后的**upper**。没有原empty证据仍保持unknown；quantization扩张也不能把read begin变成availability lower。BOOT write同理保留原raw和扩张区间，不能变为UART TX complete界。

真正的当前准入若需要在连续时间上保守保证，应使用当前样本区间 `[now_lo,now_hi]`：期限用 `now_hi < D_earliest`；v2窗口用 `S<=now_lo` 且 `now_hi<min(E,D_earliest)`；整段dt用 `now_hi+dt < D_earliest` 以保持executor原strict语义。D_earliest来自原事件**lower**加不变的时长，而不是较晚raw/receipt。原lifetime/readiness起点、heartbeat/source/completion和issue的lower都必须保守；原Wait probe耗时上界应以`after_hi−before_lo`对原预算比较。不能只把最后now变大，却仍使用被较晚起点延长的deadline。

**不可把一个全局clock改成“每次返回raw+epsilon”。** 它也会把activation/actor生命/issue等起点推迟，静默延长租期；相反一律返回lower又会低估当前。原raw、event lower、receipt upper和current upper是不同用途。应在受审真实provider的原记录中保留区间，并在owner的各准确获取点选择正确边界，扩张一次，保留raw追溯，不重复减加同一误差。

现有runtime/actor/progress多个接口是单scalar now/起点；它们并没有独立表示上述不确定区间。**本次最小实施范围只能完成raw来源统一及明确的软件时钟契约**；不能因此宣称其物理deadline已覆盖quantization。真实production准入前，root须另行审定这些有方向的区间适配（包括actor首次deadline、原sample/progress/issue lower与final-current upper），或取得足以证明现有scalar值含义的独立测量/接口证据。本报告不暗改这些scalar规则来伪装已完成，现有closed gate继续阻止升级。QPC软件观察、source测量与正式执行验收依然分层。

## 时钟失败与副作用保留

leaf拒绝回退/坏形状时，owner永久停止新准入。clock检查不得执行native/model/transport回调、重入或I/O；原 callback 后checkpoint及实际now刷新保留。

最小实现不能只机械替换函数名：若 **os.read已返回后** 的末时刻获取失败，ledger仍须保存原 chunk/stream offset/bytes事实，将末时刻与availability标为unknown并永久failed；不丢原字节、不再读取或claim，不制造end=begin/now。若 BOOT写前marker失败，无写入；已持久started_unknown后任何stamp/write/journal失败保留原一次尝试，若write确实返回则保留其count事实、无法取得的end保持unknown，禁止自动重发。后采样失败不等于副作用未发生。此处理仅新增时钟错误分支，不能放松原 durable marker在write前fsync、原原字节/once-consume与unknown保留规则。

最终 fence/CAS 区间不加新调用。运行开始时冻结 binding、domain和必要metadata，在常规原checkpoint验证；最后仍使用 runtime 原位置的真实now。executor内原 fence一次、strict `end<deadline`、单一CAS与正commit后veto保留事实不变。

## 后续少量 focused controls 与一次 QPC 观察

本设计回合没有运行这些测试。后续实施仅运行新增组，不重放旧软件/PDE/384：

1. exact固定binding/legacy默认、拒绝普通callable/伪record/第二域；一次构造后各组件的 `_clock/clock_domain` exact同对象，ActorRegistry与runtime都覆盖，生产门仍在原位置先拒绝。
2. 新路径夹真实或明确fixture OS read/write；QPC stamps单调有序、ledger与BOOT同域；post-read stamp故障保留原chunk并unknown/failed，post-write故障保留原started_unknown/count且无第二次write。fixture不证明串口或源测时。
3. 原HANDLE Wait前/后的时间与runtime now同域；probe/lifetime/sample/progress在原严格边界仍拒绝。用不同epoch的fixture值/foreign domain证明拒绝，不能靠epoch恰好接近通过；另加一个边界反例证明resolution不会自动生成u/区间，而未知uncertainty仍为None。后续区间适配任务须有一个now_hi跨原D、raw仍未跨D的拒绝反例。
4. completion/slot verifier的耗时后读真实同域now；固定原完成/issue/sample/heartbeat期限不续期、duplicate不续期；整段dt在原最终fence到期仍拒绝，正CAS后veto仍保留commit。
5. **一次有界真实QPC观察方案**：另建新operation/run记录，使用固定QPC leaf；一次固定origin，原 v2 W=10ms保持；只对一个原定S执行一次普通bounded wait，再读一次真实QPC进行消费判断。不冻结、不改origin、不循环等成功、不复现旧monotonic失败。若实际QPC尚早或已晚出窗，只保存无消费结果；不补wait或扩大W。可同时只记录同一binding夹原OS调用的区间，但不要为了此观察启动真实板/actor/产品。该观察成功也仅证明这一回合本机取时/唤醒，非调度上界、实板、H09/ADC或真实模型验收。

仍待现场独立测量/核对：QPC实际timestamp uncertainty和调用/调度延迟；跨进程原时钟实现/epoch与原计算区间；transport整帧delay（含baud容差、bridge/USB/driver buffering与串口最后字节可用语义）、board tick quantum/相对QPC rate/holdover、ADC period、native/held update时刻与source校准。已有数值只有来源、domain与保守性均核实时才复用，不能用advertisedresolution或一次pipe结果代替。

## 交付边界

`source-pins.json` 固定基准提交blob，不校验或读取并行作者的半写入working bytes；`result.json`、`verification.json` 与 manifest 固定报告/身份/证据。这里只完成设计及字节/合同核对，未建立 clock实际测量上界，也未实现任何provider。原production gate关闭；A-only board、H01–H15、两个完整H12路径及全3D/UI范围不变；G03/R03/all29为not_run。下一次实施及实际观察由root审定，在无重叠写入归属下执行。
