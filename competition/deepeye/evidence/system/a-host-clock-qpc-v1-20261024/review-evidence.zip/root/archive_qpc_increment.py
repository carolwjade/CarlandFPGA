"""Seal the final raw-QPC increment, including original and corrected evidence."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import subprocess
import zipfile

P = Path(__file__).resolve().parent
R = P.parents[2]
O = P.parent
W = R / '.local/deepeye-implementation-a'
A = O / 'host-clock-qpc-v1-20261024'
V = O / 'host-clock-qpc-v1-independent-20261024'
D = O / 'high-res-clock-design-20261024'
F = O / 'qpc-root-interrupt-probe-20261024'
BASE = '17fe7a63652dac6003f3ff6c71abe90eb10c8c87'
GIT = r'C:\Users\CarlJade\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe'
CONTRACT = 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_bytes())


def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')


def git(*args):
    return subprocess.check_output([GIT, '--no-optional-locks', '-C', str(W), *args])


def unwrap(value):
    if isinstance(value, dict) and 'content' in value:
        value = json.loads(next(x['text'] for x in value['content'] if x['type'] == 'text'))
    return value


def terminal(name):
    job = unwrap(read(P / name))[0]
    assert job['status'] == 'completed' and job['terminal'] and not job['stale']
    return job


assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert not git('diff', '--cached', '--name-only').strip()
scope = read(W / 'docs/competition/deepeye-2026/immutable_scope.json')['requirements']
assert len(scope) == 15 and sha(json.dumps(scope, ensure_ascii=False, sort_keys=True,
    separators=(',', ':')).encode('utf-8')) == CONTRACT
protected = read(O / 'r03-mailbox-stop-main-review-20261020/application.json')['protected_files']
assert all(sha((W / name).read_bytes()) == pin for name, pin in protected.items())
author_job = terminal('qpc-author-terminal.json')
review_job = terminal('qpc-review-terminal.json')
terminal('high-res-clock-design-terminal.json')
for folder, job in [(A, author_job), (V, review_job)]:
    for name in ['report.md', 'result.json', 'artifact-manifest.json']:
        assert sha((folder / name).read_bytes()) in job['result']['text']
members = {}
for folder, prefix, count in [(A, 'author/', 51), (V, 'independent/', 139)]:
    manifest = read(folder / 'artifact-manifest.json')
    assert len(manifest['files']) == count
    for name, row in manifest['files'].items():
        path = (folder / name).resolve()
        assert path.is_relative_to(folder.resolve()) and path.is_file()
        raw = path.read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        members[prefix + name] = raw
    for name in ['artifact-manifest.json', 'freeze.json', 'native-complete-receipt.json']:
        members[prefix + name] = (folder / name).read_bytes()
pins = read(V / 'final-sourcehashes.json')
final_sources = pins['final_candidate_sources']
assert len(final_sources) == 9
assert sum(row['root_modified'] for row in final_sources.values()) == 1
for name, row in final_sources.items():
    raw = (W / name).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    assert b'\r' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n')
    assert all(line.rstrip(b' \t') == line for line in raw.splitlines())
    if name.endswith('.py'):
        ast.parse(raw)
assert len(pins['unchanged_dependencies']) == 16
assert all(sha((W / name).read_bytes()) == row['sha256']
    for name, row in pins['unchanged_dependencies'].items())
assert len(pins['ast_preserved']) == 15 and all(pins['ast_preserved'].values())
result = read(V / 'result.json')
assert result['final_revised_controls'] == dict(methods=8, failures=0, errors=0, exit_code=0)
assert result['independent_interrupt_controls'] == dict(methods=3, failures=0, errors=0,
    exit_code=0, actual_kernel_reads=1, boundary_entries=1)
assert result['initial_frozen_controls']['exit_code'] == 1
for name, expected in [('attempt1-execution.json', 1),
                       ('attempt2-root-revision-execution.json', 0),
                       ('interrupt-controls-execution.json', 0)]:
    receipt = read(V / name)
    assert receipt.get('returncode', receipt.get('exit_code', receipt.get('exit'))) == expected
for name in ['attempt2-root-revision-stderr.log', 'interrupt-controls-stderr.log']:
    log = (V / name).read_bytes()
    assert b'\nOK' in log and b'FAILED' not in log
delta = read(F / 'root-correction.json')
assert delta['original_sha256'] == '45879bc7fbe95705b4836d5cadfabc996a80c819e52a50299c2573b7e9b85446'
assert delta['final_sha256'] == 'b427bb730e741bcaf35134a7be0473aa2ec0e3ea262ae81448d8a9872d0dad91'
assert {name: row['sha256'] for name, row in final_sources.items()} == delta['final_owned_source_pins']
for path in F.rglob('*'):
    if path.is_file():
        assert 'lease' not in path.name and '__pycache__' not in path.parts
        members['root-interrupt/' + path.relative_to(F).as_posix()] = path.read_bytes()
for name in ['report.md', 'result.json', 'source-pins.json', 'frozen-manifest.json',
             'verification.json', 'native-complete.json']:
    members['prior-design/' + name] = (D / name).read_bytes()
for name in ['qpc-author-terminal.json', 'qpc-review-terminal.json',
             'high-res-clock-design-terminal.json', 'host-clock-capabilities-20261024.json',
             'host-clock-qpc-v1-decision.json', 'qpc-phase2-candidate.json']:
    members['root/' + name] = (P / name).read_bytes()
members['root/archive_qpc_increment.py'] = Path(__file__).read_bytes()
secrets = [unwrap(read(folder / 'lease.private.json'))['lease_token'].encode()
           for folder in [A, V, D]]
assert all(secret not in raw for raw in members.values() for secret in secrets)
assert all('lease.private' not in name for name in members)
observation = read(A / 'qpc-once.json')
decision = dict(schema=1, utc=datetime.now(timezone.utc).isoformat(),
    owner='A/root 01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3',
    disposition='ACCEPT_RAW_QPC_BINDING_AND_BOUNDED_IO_FAILURE_PRESERVATION_SOFTWARE_INCREMENT_ONLY',
    source_base=BASE, final_source_pins={name: row['sha256'] for name, row in final_sources.items()},
    root_read_interrupt_correction=delta, requirements_sha256=CONTRACT, H01_H15_preserved=True,
    author_original_candidate_methods=21, final_independent_groups=8,
    final_independent_interrupt_methods=3, author_original_manifest_members=51,
    independent_manifest_members=139, unchanged_dependencies=16, unchanged_gate_AST_objects=15,
    author_21_methods_scope='original nine-file candidate; not rerun on the final one-file root correction',
    original_reviewer_Q03_failure_and_limited_oracle_delta_preserved=True,
    root_original_interrupt_RED_and_GREEN_preserved=True,
    actual_QPC_observation=observation,
    observation_scope='one author raw-QPC pure-policy attempt with synthetic upstream, before root receipt-only fix; not a scheduling bound, measured interval, physical or model acceptance',
    timestamp_uncertainty_ns=None, measured_read_write_intervals_ns=None,
    cross_process_QPC_correspondence_established=False, directional_interval_adaptation='next work',
    original_window_W_ns=10000000, original_deadlines_or_CAS_relaxed=False,
    production_gate='unchanged unconditional refusal before registry acquisition',
    protected_C_files_unchanged=True, old_monotonic_or_old_suites_rerun=False,
    PL_ADC_model_motion_build_board_system_or_formal_acceptance=False,
    G03='not_run', R03='not_run', all29='not_run')
dest = W / 'competition/deepeye/evidence/system/a-host-clock-qpc-v1-20261024'
dest.mkdir(parents=True, exist_ok=False)
zp = dest / 'review-evidence.zip'
with zipfile.ZipFile(zp, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(members.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None and len(z.namelist()) == len(members)
    assert all(z.read(name) == raw for name, raw in members.items())
save(dest / 'manifest.json', dict(schema=1, zip_sha256=sha(zp.read_bytes()), zip_bytes=zp.stat().st_size,
    member_count=len(members), members=[dict(path=name, bytes=len(raw), sha256=sha(raw))
    for name, raw in sorted(members.items())], credentials_excluded=True))
save(dest / 'decision.json', decision)
(dest / 'README.md').write_text('Raw QPC source/domain consistency and bounded I/O-failure preservation software increment only. The author21 new methods bind its original9-file candidate; final root receipt-only correction has revised8 independent groups plus3 new interrupt controls and root RED/GREEN. Q03 originally conflated legacy domain/callable; its failed run and limited oracle correction are retained. Unknown interrupted read bytes/count remain null and the original read attempt stays permanently failed. One author QPC pure-policy window consumed265600ns after fixed S with synthetic upstream; no scheduling bound or physical timing is established. Original deadlines/window/CAS and unconditional production refusal remain. No old monotonic or old suites replay. Original author/source pins and final correction are separately retained. H01-H15/C4 unchanged; G03/R03/all29=not_run.\n', encoding='utf-8', newline='\n')
files = {path.relative_to(W).as_posix(): sha(path.read_bytes()) for path in dest.iterdir()}
files.update({name: row['sha256'] for name, row in final_sources.items()})
uart = read(P / 'uart30-publication.json')
assert uart['expected_head'] == BASE and not set(files) & set(uart['files'])
files.update(uart['files'])
save(P / 'qpc-root-decision.json', decision)
save(P / 'qpc-uart30-publication.json', dict(expected_head=BASE,
    message='Bind fresh-run raw QPC and preserve interrupted reads; archive UART30 review', files=files))
assert len(files) == 17
assert all(sha((W / name).read_bytes()) == pin for name, pin in protected.items())
print(json.dumps(dict(prepared_files=len(files), archive_members=len(members), zip_bytes=zp.stat().st_size,
    zip_sha256=sha(zp.read_bytes()), final_source_files=9, C4_unchanged=True)))
