"""New OS-read interruption probe; second OS call is intercepted before I/O."""
import hashlib
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
PRODUCT = ROOT / '.local/deepeye-implementation-a'
sys.path.insert(0, str(PRODUCT))
from competition.deepeye.integration import host_clock as clocks
from competition.deepeye.integration import live_board_receipts as receipts


class ProbeStop(BaseException):
    pass


def run(destination):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    source = PRODUCT / 'competition/deepeye/integration/live_board_receipts.py'
    result = dict(schema=1, scope='new local OS interruption fault control only',
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        actual_qpc_observations=0, sleeps=0, physical_io=False,
        actual_kernel_reads=0, read_boundary_entries=0, consumed_hex=None)
    read_fd, write_fd = os.pipe()
    os.write(write_fd, b'QPC?!')
    os.close(write_fd)
    original_read = os.read
    stamps = iter(range(100, 200))
    ledger = None
    def interrupted(fd, size):
        result['read_boundary_entries'] += 1
        if result['read_boundary_entries'] > 1:
            raise ProbeStop('intercepted before any second kernel read')
        data = original_read(fd, size)
        result['actual_kernel_reads'] += 1
        result['consumed_hex'] = data.hex()
        raise KeyboardInterrupt('fault injected after actual first read consumed bytes')
    try:
        with patch.object(clocks, '_qpc_leaf', lambda: next(stamps)):
            binding = clocks.qpc_clock_for_new_run()
            identity = receipts.CaptureIdentity('A-QPC-READ-INTERRUPT-20261024-01',
                '1'*64, '2'*40, '3'*64, 1)
            ledger = receipts.ReceiptLedger(read_fd, identity, max_bytes=5,
                max_reads=3, read_size=5, host_clock=binding)
            with patch.object(receipts.os, 'read', interrupted):
                try:
                    ledger.read_once()
                except BaseException as exc:
                    result['first_exception'] = type(exc).__name__
                result['after_first'] = ledger.snapshot()
                try:
                    ledger.read_once()
                except BaseException as exc:
                    result['second_exception'] = type(exc).__name__
                result['after_second'] = ledger.snapshot()
        assertions = dict(first_interrupted=result.get('first_exception') == 'KeyboardInterrupt',
            actual_one_kernel_read=result['actual_kernel_reads'] == 1,
            original_bytes_consumed=result['consumed_hex'] == b'QPC?!'.hex(),
            permanently_failed=result['after_first']['failed'] is True,
            recorded_attempt=len(result['after_first']['reads']) == 1,
            no_second_read_boundary=result['read_boundary_entries'] == 1,
            active_refused=result.get('second_exception') == 'ValueError')
        result['assertions'] = assertions
        result['passed'] = all(assertions.values())
    finally:
        if ledger is not None:
            ledger.close()
        os.close(read_fd)
    (destination / 'result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    sys.exit(run(sys.argv[1]))
