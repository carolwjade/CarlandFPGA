"""Record root's one-file correction without changing the author's frozen set."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import json

P = Path(__file__).resolve().parent
O = P.parent
R = O.parents[1]
W = R / '.local/deepeye-implementation-a'
A = O / 'host-clock-qpc-v1-20261024'
pins = json.loads((A / 'source-pins.json').read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
changed = 'competition/deepeye/integration/live_board_receipts.py'
source = {}
for name in pins['owned_files']:
    raw = (W / name).read_bytes()
    source[name] = sha(raw)
    if name != changed:
        assert source[name] == pins['source'][name]['sha256']
    assert b'\r' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n')
    assert all(line.rstrip(b' \t') == line for line in raw.splitlines())
    if name.endswith('.py'):
        ast.parse(raw)
original = (A / 'source-snapshot' / changed).read_bytes()
final = (W / changed).read_bytes()
assert sha(original) == '45879bc7fbe95705b4836d5cadfabc996a80c819e52a50299c2573b7e9b85446'
assert sha(final) == 'b427bb730e741bcaf35134a7be0473aa2ec0e3ea262ae81448d8a9872d0dad91'
for name, raw in [('original-receipts.py', original), ('final-receipts.py', final)]:
    with (P / name).open('xb') as f:
        f.write(raw)
diff = ''.join(difflib.unified_diff(original.decode().splitlines(True),
    final.decode().splitlines(True), fromfile='author-frozen/live_board_receipts.py',
    tofile='root-corrected/live_board_receipts.py'))
(P / 'correction.diff').write_text(diff, encoding='utf-8', newline='\n')
red = json.loads((P / 'attempt1-red/result.json').read_bytes())
green = json.loads((P / 'attempt2-green/result.json').read_bytes())
assert not red['passed'] and green['passed']
for result in [red, green]:
    assert result['actual_kernel_reads'] == 1 and result['consumed_hex'] == '5150433f21'
    assert result['actual_qpc_observations'] == result['sleeps'] == 0
value = dict(schema=1, utc=datetime.now(timezone.utc).isoformat(),
    reason='OS read may consume bytes and then be interrupted before a return value reaches the ledger; old candidate allowed another entry',
    author_original_manifest_unchanged=True, source_file_changes_after_author_freeze=1,
    original_sha256=sha(original), final_sha256=sha(final), final_owned_source_pins=source,
    correction='Reserve an unknown read attempt and latch failed before OS read; save any returned raw bytes/count before stamping; only a completely recorded read and scan clear the latch',
    unknown_semantics='started_unknown/raw_hex=null/returned_bytes=null; bytes_read counts only bytes returned to the ledger and is not a claim that the OS consumed zero bytes',
    counterexample='A local pipe wrapper consumed five original bytes once then raised KeyboardInterrupt. A second boundary spy intercepted before any second kernel read. This is explicit fault injection, not board I/O or actual QPC timing.',
    actual_commands=[dict(argv=['.local/venv/Scripts/python.exe','-B','-X','utf8',
        '.planning/deepeye-resume-20261018/qpc-root-interrupt-probe-20261024/probe.py',
        '.planning/deepeye-resume-20261018/qpc-root-interrupt-probe-20261024/'+directory],
        observed_exit_code=exit_code) for directory,exit_code in [('attempt1-red',1),('attempt2-green',0)]],
    results=dict(red_boundary_entries=red['read_boundary_entries'],
        green_boundary_entries=green['read_boundary_entries'],
        green_permanent_failure=green['after_first']['failed']),
    old_tests_or_clock_observations_replayed=False, physical_acceptance=False)
with (P / 'root-correction.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(value, f, indent=2)
    f.write('\n')
print(json.dumps(dict(final_sha256=sha(final), unchanged_other_files=8,
    root_RED_exit=1, root_GREEN_exit=0, formatting_and_AST=True)))
