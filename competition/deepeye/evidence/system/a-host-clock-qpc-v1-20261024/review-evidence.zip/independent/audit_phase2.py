import ast,difflib,hashlib,json,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];PRODUCT=ROOT/'.local/deepeye-implementation-a'
AUTHOR=OUT.parent/'host-clock-qpc-v1-20261024';BASE='17fe7a63652dac6003f3ff6c71abe90eb10c8c87'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(data):return hashlib.sha256(data).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def blob(p):return subprocess.check_output([GIT,'-C',str(PRODUCT),'show',BASE+':'+p])
candidate=load(OUT.parent/'gen3-live-integration-20261024/qpc-phase2-candidate.json')
assert candidate['base']==BASE
assert sha((AUTHOR/'source-pins.json').read_bytes())==candidate['author_source_pins_sha256']=='e51fa5c40ad78014e7462eeaf2edf304b137b54981122de20f497f66231ea227'
assert sha((AUTHOR/'artifact-manifest.json').read_bytes())==candidate['author_artifact_manifest_sha256']=='c0e1a42e6e20cd9ba7d1dfd58fcbaaaa1fc764169b3c134797a2a42189ecde17'
manifest=load(AUTHOR/'artifact-manifest.json')
for name,pin in manifest['files'].items():
    raw=(AUTHOR/name).read_bytes();assert sha(raw)==pin['sha256'] and len(raw)==pin['bytes'],name
frozen=load(OUT/'phase1-manifest.json')
for name,pin in frozen['files'].items():assert sha((OUT/name).read_bytes())==pin['sha256'],name
pins={};diff=[]
for name,pin in candidate['source_files'].items():
    raw=(PRODUCT/name).read_bytes();assert sha(raw)==pin['sha256'] and len(raw)==pin['bytes'],name
    assert raw==(AUTHOR/'source-snapshot'/name).read_bytes(),name
    dest=OUT/'candidate-snapshot'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    old=(OUT/'baseline'/name).read_bytes() if (OUT/'baseline'/name).exists() else b''
    assert (sha(old) if old else None)==pin['base_sha256'],name
    diff.extend(difflib.unified_diff(old.decode().splitlines(True),raw.decode().splitlines(True),fromfile='base/'+name,tofile='candidate/'+name))
    pins[name]=pin
(OUT/'candidate.diff').write_text(''.join(diff),encoding='utf-8')
authorpins=load(AUTHOR/'source-pins.json');deps={};protected={}
for name,pin in authorpins['source'].items():
    if pin['same_as_base']:
        raw=(PRODUCT/name).read_bytes();assert sha(raw)==pin['sha256']==sha(blob(name)),name
        deps[name]={'sha256':sha(raw),'bytes':len(raw)}
for name,digest in authorpins['protected_files'].items():
    assert sha((PRODUCT/name).read_bytes())==digest,name
    protected[name]={'sha256':digest}
def nodes(path):
    result={}
    def visit(items,prefix=''):
        for node in items:
            if isinstance(node,(ast.ClassDef,ast.FunctionDef)):
                result[prefix+node.name]=node
                if isinstance(node,ast.ClassDef):visit(node.body,prefix+node.name+'.')
    visit(ast.parse(path.read_text(encoding='utf-8')).body);return result
objects={}
checks={'simulation/isolation/actor_owner.py':['ActorOwner','ActorRegistry.launch','ActorRegistry._contains'],
 'simulation/authority/actor_composition.py':['_ProgressGate','_Dependencies','_entry','ActorComposition.accept_boot',
 'ActorComposition.accept_command','ActorComposition.accept_completion','ActorComposition._progress_time',
 'ActorComposition.step','ActorComposition._checkpoint','ActorComposition._retire','ActorComposition._cleanup']}
for rel,names in checks.items():
    name='competition/deepeye/'+rel;old=nodes(OUT/'baseline'/name);new=nodes(PRODUCT/name)
    for item in names:
        value=ast.dump(old[item],include_attributes=False)==ast.dump(new[item],include_attributes=False)
        objects[rel+':'+item]=value;assert value,(rel,item)
name='competition/deepeye/simulation/authority/actor_composition.py'
old=nodes(OUT/'baseline'/name)['_production_channels'];new=nodes(PRODUCT/name)['_production_channels']
bodyeq=ast.dump(ast.Module(body=old.body,type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=new.body,type_ignores=[]),include_attributes=False)
objects['actor_composition:_production_channels.body']=bodyeq;assert bodyeq
scope=load(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
requirements=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
assert requirements=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
for filename in ['qpc-once.json','qpc-once.log','observe_qpc_once.py']:
    source=AUTHOR/filename
    if source.exists():(OUT/('author-'+filename)).write_bytes(source.read_bytes())
record={'schema':1,'base_commit':BASE,'candidate_sources':pins,'unchanged_dependencies':deps,'protected_files':protected,
 'ast_preserved':objects,'author_manifest_members_verified':len(manifest['files']),
 'author_source_pins_sha256':candidate['author_source_pins_sha256'],
 'author_artifact_manifest_sha256':candidate['author_artifact_manifest_sha256'],
 'requirements_sha256':requirements,'phase1_frozen_members_verified':len(frozen['files']),
 'tests_run':False,'actual_clock_sleep_consume_run':False,'product_writes':False}
(OUT/'phase2-sourcehashes.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'source_files':len(pins),'dependencies':len(deps),'protected':len(protected),'ast_objects':len(objects),'author_members':len(manifest['files'])}))
