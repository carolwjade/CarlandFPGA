# QPC v1 独立审查第一阶段

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，work `A-HOST-CLOCK-QPC-V1-REVIEW-20261024-v1`，agent `/root/pc_direct_window_review`。新 job `child-b1f2b02e711a47e2a4e2f17235e64216` 已用新 token/canonical agent 验证，`execution_allowed=true`；未复用上一 completed 租约。仅本目录可写，全部产品只读；不再派工。

主为 Desktop `01a16988-bdcb-70e1-ae10-1304b5cf7875` / generation3，transfer现场读回active。前节点已读根AGENTS、两项技能/A角色、协作协议；本节点重读设计、root决定和immutable md，重读json实算requirements UTF-8 canonical（ensure_ascii=False/sort_keys=True/compact separators）SHA256=`c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`。H01–H15不变，A/root独占实板。

本阶段只用 `git show 17fe7a63652dac6003f3ff6c71abe90eb10c8c87:path` 捕获13个committed源/文档；没有读作者实时9文件或新tests。根工作树后续B wire证据增量不改变该基线。输入与blob哈希见 `phase1-source-pins.json`。本阶段不测试、不取实际时钟、不sleep、不消费、不native_complete；准备后结束回合等root准确pins。

## 冻结预期与少量控制

这次只统一raw host clock来源与诊断故障保留。固定实际QPC leaf、fresh run binding是进程内约束，不能认证来源。100ns advertised resolution不是timestamp uncertainty；未知interval必须None；不从不同epoch接近的值或同名标签取得身份。原v2 W=10ms与任何旧期限不改。

| 组 | 冻结刺激、预期与证据 |
|---|---|
| Q01 固定来源/未知区间 | 源码确认原leaf是实际time.perf_counter_ns，factory不接受普通caller callable、now、verified/authenticated/mode旗标。仅在模块私有leaf处换成script fixture，给111/112，clock与sample必须保留原值、sample domain为exact binding；interval仍None，即使metadata报告100ns。普通构造不能绕开factory。|
| Q02 leaf失败/线程 | script111→110回退，bool/int子类/负数/2**63溢出拒绝，并不在后续正常值复活。foreign线程调用拒绝且不读取leaf；不调用实际QPC。|
| Q03 同对象路由/legacy | ledger.clock_domain、BOOT继承域、ActorRegistry._clock、composition._clock、runtime._clock均为同一binding（不是新bound method）；legacy None仍用原各模块monotonic。registry/native启动处用私有spy，不建立actor/native进程。|
| Q04 混域不接受 | 第二个binding可拥有接近/相同raw值，但foreign Completion.clock_domain仍拒绝；普通callable/同名domain伪对象不可注入。BOOT构造不收第二clock；构造后ledger域若不再是原binding，send在写前拒绝，0次write。不能把raw数值接近或metadata标记当关联。|
| Q05 read后stamp故障 | 新私有fixture用本地pipe/spy返回原chunk `00 51 50 43 ff` 一次；begin成功、os.read返回、end stamp失败。保留raw_hex、stream_start=0、bytes_read=5及1次已用read预算；end/availability unknown、failed。第二read/claim拒绝，OSread调用数不增加；不补end=begin或advertisedresolution。|
| Q06 write后stamp故障 | BOOT原durable started_unknown写入并fsync，再唯一os.write返回count，end stamp失败。snapshot保留request bytes和returned count、end unknown；journal原started_unknown仍存在，不改为未写。第二send拒绝、OSwrite总1次。写前marker/stamp失败对照必须0次write。|
| Q07 原门静态保持 | 独立核对原candidate_mailbox(v2含W)、candidate_owner、runtime、watchdog、actor_lifetime、motion_executor、ABI/profile均等基线；原ProgressGate、Dependencies、owner HANDLE身份/FILETIME与lifetime算法、verifier后刷新、final callback→strictend<CAS不改。仅列明9file中的必要构造/时钟/故障分支差异；不重跑旧行为组。|
| Q08 生产门/默认 | 有效QPC clock仍production无条件拒绝，registry/acquisition spy零调用；非法clock在native/IO前拒绝。不增加provider/allow/verified旗标，raw binding不成为motion/timing认证。|

`independent_controls.py` 冻结上述oracle。因host_clock和私有sample形状尚未解封，不猜字段：phase2允许新写 `candidate_adapter.py` **仅作fixture接线/字段取值**，其接口与限制在 `adapter-contract.md`。adapter不能修改这些预期、阈值、异常意义或静态保护集合；若候选接口无法表达设计，保留失败并报告root，不通过adapter制造布尔成功。phase2报告必须给出adapter源码/hash与任何调用形状调整。

新增控制中的QPC leaf全部换为明确script fixture，不调用实际clock；不运行作者新suite/旧TestCase方法、PDE/384/穷尽。需要借用旧构造逻辑时只读helper，不执行旧测试方法。既有C4 protected bytes由root准确pin核对，不改。

## 实际观察与结论上限

作者允许的唯一新QPC纯policy实际观察只在其封存后读原脚本/原raw记录/时钟属性，不再运行actualclock/sleep/消费，不重试旧monotonic trial，也不将QPC结果倒填旧失败。保留所有原日志、计数和未知副作用。

即使8组通过，最高结论仍为固定候选在有限synthetic/source-routing与错误证据控制中符合约束。provider、跨进程时钟/原完成区间、physical deadline、真实source/ADC/PL和实际调度上界均未建立；raw QPC路由不解决scalar接口的方向性uncertainty。H01–H15、完整H12两路径和全3D/UI保留；`G03/R03/all29=not_run`。root拥有设计决定、正式接受与发布。最终phase2冻结report/result/sourcepins/manifest再完成新租约。
