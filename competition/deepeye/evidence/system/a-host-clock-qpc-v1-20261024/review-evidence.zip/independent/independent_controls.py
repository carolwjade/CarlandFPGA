"""Frozen QPC-v1 oracle; adapter wiring is supplied only after root phase2 pins.

No actual clock/sleep/policy consumption is permitted in these reviewer controls.
"""
from dataclasses import replace
import inspect
import threading
import time
import unittest

class QpcControls(unittest.TestCase):
    def test_Q01_fixed_leaf_and_unknown_interval(self):
        with adapter.scripted_clock() as f:
            self.assertIs(f.original_leaf,time.perf_counter_ns)
            q=f.binding
            for kw in ({'clock':lambda:111},{'now_ns':111},{'verified':True},{'authenticated':True},{'mode':'qpc'}):
                with self.subTest(kw=tuple(kw)),self.assertRaises((TypeError,ValueError)):
                    adapter.api.hc.qpc_clock_for_new_run(**kw)
            with self.assertRaises((TypeError,ValueError)):
                adapter.api.hc.QpcHostClock(lambda:111)
            f.set_values([111,112])
            self.assertEqual(q(),111)
            sample=q.read_sample()
            raw,domain,interval=adapter.sample_parts(sample)
            self.assertEqual(raw,112)
            self.assertIs(domain,q)
            self.assertIsNone(interval)
            self.assertEqual(f.leaf_calls,2)
            self.assertTrue(adapter.metadata(q))

    def test_Q02_failures_and_foreign_thread_do_not_become_time(self):
        class IntChild(int):pass
        for bad in [110,True,IntChild(112),-1,(1<<63)]:
            with self.subTest(bad=repr(bad)),adapter.scripted_clock() as f:
                q=f.binding;f.set_values([111,bad,999])
                self.assertEqual(q(),111)
                with self.assertRaises(ValueError):q()
                with self.assertRaises(ValueError):q()
        with adapter.scripted_clock() as f:
            q=f.binding;f.set_values([111])
            errors=[]
            def foreign():
                try:q()
                except BaseException as exc:errors.append(exc)
            worker=threading.Thread(target=foreign);worker.start();worker.join()
            self.assertEqual(len(errors),1)
            self.assertIsInstance(errors[0],ValueError)
            self.assertEqual(f.leaf_calls,0)

    def test_Q03_one_stable_binding_everywhere_and_legacy(self):
        with adapter.scripted_clock() as f,adapter.routing_fixture(f.binding) as r:
            q=f.binding
            self.assertIs(r.ledger.clock_domain,q)
            self.assertIs(adapter.transcript_binding(r.transcript),q)
            self.assertIs(r.registry._clock,q)
            self.assertIs(r.composition._clock,q)
            self.assertIs(r.runtime._clock,q)
        with adapter.routing_fixture(None) as r:
            self.assertIs(r.registry._clock,adapter.api.actors.monotonic_ns)
            self.assertIs(r.composition._clock,adapter.api.composition.monotonic_ns)
            self.assertIs(r.runtime._clock,r.composition._clock)
            self.assertIsNone(r.ledger.clock_domain)
            self.assertIs(r.ledger._clock,adapter.api.receipts.monotonic_ns)

    def test_Q04_matching_numbers_or_labels_do_not_replace_original_domain(self):
        with adapter.scripted_clock() as f,adapter.scripted_clock() as other:
            self.assertIsNot(f.binding,other.binding)
            with adapter.proof_fixture(f.binding) as p:
                with self.assertRaises(ValueError):
                    p.owner.offer(replace(p.proof,clock_domain=other.binding),p.now)
            with adapter.io_fixture(f.binding) as io:
                adapter.replace_ledger_domain_for_fault(io.ledger,other.binding)
                with self.assertRaises(ValueError):io.transcript.send_once()
                self.assertEqual(io.write_calls,0)
        for invalid in [lambda:111,object(),type('Fake',(),{'domain_id':'qpc','verified':True,'__call__':lambda self:111})()]:
            with adapter.rejected_clock_fixture(invalid) as state:
                self.assertTrue(state.rejected)
                self.assertEqual(state.native_or_io_calls,0)

    def test_Q05_post_read_stamp_failure_retains_consumed_bytes_and_budget(self):
        chunk=b'\x00QPC\xff'
        with adapter.scripted_clock() as f,adapter.io_fixture(f.binding) as io:
            io.arm_read(chunk,post_stamp_failure=True)
            with self.assertRaises((ValueError,RuntimeError)):io.ledger.read_once()
            snapshot=io.ledger.snapshot()
            self.assertTrue(snapshot['failed'])
            self.assertEqual(snapshot['bytes_read'],5)
            self.assertEqual(len(snapshot['reads']),1)
            row=snapshot['reads'][0]
            self.assertEqual(row['raw_hex'],chunk.hex())
            self.assertEqual(row['stream_start'],0)
            self.assertIsNone(adapter.read_end(row))
            for frame in snapshot['frames']:
                self.assertIsNone(frame['availability_interval_ns'])
            self.assertEqual(io.read_calls,1)
            with self.assertRaises(ValueError):io.ledger.read_once()
            with self.assertRaises(ValueError):io.ledger.claim_board_response(object(),context={})
            self.assertEqual(io.read_calls,1)

    def test_Q06_post_write_stamp_failure_keeps_started_unknown_and_count(self):
        with adapter.scripted_clock() as f,adapter.io_fixture(f.binding) as io:
            io.arm_write(post_stamp_failure=True)
            with self.assertRaises((ValueError,RuntimeError)):io.transcript.send_once()
            attempt=io.transcript.snapshot()['attempt']
            self.assertEqual(attempt['raw_hex'],io.original_request.hex())
            self.assertEqual(attempt['bytes_written'],io.returned_count)
            self.assertEqual(io.returned_count,len(io.original_request))
            self.assertIsNone(adapter.write_end(attempt))
            self.assertNotEqual(attempt['outcome'],'journal_error_no_write')
            self.assertTrue(any(row.get('outcome')=='started_unknown' for row in io.journal_rows()))
            self.assertEqual(io.write_calls,1)
            with self.assertRaises(ValueError):io.transcript.send_once()
            self.assertEqual(io.write_calls,1)
        with adapter.scripted_clock() as f,adapter.io_fixture(f.binding) as io:
            io.arm_write(pre_marker_failure=True)
            with self.assertRaises((ValueError,RuntimeError)):io.transcript.send_once()
            self.assertEqual(io.write_calls,0)

    def test_Q07_original_gate_bodies_and_dependency_bytes_remain(self):
        comparisons=adapter.static_preservation()
        self.assertGreaterEqual(len(comparisons),12)
        for name,equal in comparisons.items():
            with self.subTest(name=name):self.assertTrue(equal)

    def test_Q08_qpc_still_cannot_open_production_gate(self):
        with adapter.scripted_clock() as f,adapter.production_fixture(f.binding) as p:
            with self.assertRaises(adapter.api.composition.ActivationUnavailable):
                adapter.api.composition.create_authority(p.config,host_clock=f.binding)
            self.assertEqual(p.acquisition_calls,0)

if __name__=='__main__':
    import argparse
    import importlib
    import sys
    sys.dont_write_bytecode=True
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase2-authorized',action='store_true',required=True)
    parser.parse_args()
    adapter=importlib.import_module('candidate_adapter')
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(QpcControls)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
