import difflib,hashlib,json,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];PRODUCT=ROOT/'.local/deepeye-implementation-a'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(data):return hashlib.sha256(data).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
old=load(OUT/'phase2-sourcehashes.json');current={};diff=[]
for name,pin in old['candidate_sources'].items():
    raw=(PRODUCT/name).read_bytes();expected='b427bb730e741bcaf35134a7be0473aa2ec0e3ea262ae81448d8a9872d0dad91' if name.endswith('/live_board_receipts.py') else pin['sha256']
    assert sha(raw)==expected,name
    target=OUT/'final-source-snapshot'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    current[name]={'sha256':sha(raw),'bytes':len(raw),'author_original_sha256':pin['sha256'],'root_modified':expected!=pin['sha256']}
    baseline=(OUT/'baseline'/name);before=baseline.read_bytes() if baseline.exists() else b''
    diff.extend(difflib.unified_diff(before.decode().splitlines(True),raw.decode().splitlines(True),fromfile='base/'+name,tofile='final/'+name))
    assert b'\r' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n'),name
    assert all(line.rstrip(b' \t')==line for line in raw.splitlines()),name
(OUT/'final-candidate.diff').write_text(''.join(diff),encoding='utf-8')
for category in ['unchanged_dependencies','protected_files']:
    for name,pin in old[category].items():assert sha((PRODUCT/name).read_bytes())==pin['sha256'],name
delta=load(OUT/'q03-authorized-delta.json')
for name,pin in load(OUT/'phase1-manifest.json')['files'].items():
    path=OUT/(delta['original_harness_backup'] if name=='independent_controls.py' else name)
    assert sha(path.read_bytes())==pin['sha256'],name
assert sha((OUT/'independent_controls.py').read_bytes())==delta['revised_harness_sha256']
assert load(OUT/'attempt1-execution.json')['exit_code']==1
assert load(OUT/'attempt2-root-revision-execution.json')['exit_code']==0
assert load(OUT/'interrupt-controls-execution.json')['exit_code']==0
witness=load(OUT/'independent-interrupt-witness.json')
assert witness['actual_kernel_reads']==witness['boundary_entries']==1
for sub in ['attempt1-red','attempt2-green']:
    p=ROOT/'.planning/deepeye-resume-20261018/qpc-root-interrupt-probe-20261024'/sub/'result.json'
    (OUT/('root-interrupt-'+sub+'.json')).write_bytes(p.read_bytes())
(OUT/'root-correction.json').write_bytes((ROOT/'.planning/deepeye-resume-20261018/qpc-root-interrupt-probe-20261024/root-correction.json').read_bytes())
check=subprocess.run([GIT,'-C',str(PRODUCT),'diff','--check','--',*current],capture_output=True)
assert check.returncode==0
(OUT/'final-owned-diff-check.stdout').write_bytes(check.stdout);(OUT/'final-owned-diff-check.stderr').write_bytes(check.stderr)
head=subprocess.check_output([GIT,'-C',str(PRODUCT),'rev-parse','HEAD']).decode().strip();assert head==old['base_commit']
record=dict(old,final_candidate_sources=current,root_revision='Only live_board_receipts.py; pre-read unknown reservation and failure latch',
    original_author_sourcepins_retained=True,final_head=head)
record.pop('tests_run')
record['tests_run_by_this_freeze_script']=False
(OUT/'final-sourcehashes.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
result={'schema':1,'status':'independent_review_passed_after_root_read_interrupt_fix_and_authorized_oracle_delta',
 'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'A-HOST-CLOCK-QPC-V1-REVIEW-20261024-v1',
 'job_id':'child-b1f2b02e711a47e2a4e2f17235e64216','agent_id':'/root/pc_direct_window_review',
 'director':'01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3','base_head':head,
 'requirements_sha256':old['requirements_sha256'],'H01_H15_preserved':True,
 'initial_frozen_controls':{'methods':8,'passed':7,'failures':1,'errors':0,'exit_code':1,'reason':'Q03 reviewer legacy-domain premise; retained'},
 'final_revised_controls':{'methods':8,'failures':0,'errors':0,'exit_code':0},
 'independent_interrupt_controls':{'methods':3,'failures':0,'errors':0,'exit_code':0,'actual_kernel_reads':1,'boundary_entries':1},
 'final_source_files':9,'root_modified_files':1,'final_receipt_sha256':current['competition/deepeye/integration/live_board_receipts.py']['sha256'],
 'unchanged_other_author_pins':8,'author_original_manifest_members':51,'unchanged_dependencies':16,'protected_files':4,'unchanged_gate_ast_objects':15,
 'final_sourcehashes_sha256':sha((OUT/'final-sourcehashes.json').read_bytes()),'report_sha256':sha((OUT/'report.md').read_bytes()),
 'q03_delta':delta,'author_actual_QPC_observation':{'attempts':1,'lateness_ns':265600,'consumed':True,'reviewer_repeated':False,
 'upstream':'synthetic','timestamp_interval_ns':None,'timestamp_uncertainty_ns':None,'scheduling_bound_established':False},
 'actual_clock_sleep_consume_run_by_reviewer':False,'old_or_author_component_suites_run':False,'PDE_384_exhaustive_run':False,
 'production_available':False,'physical_deadline_or_provenance_established':False,'formal_acceptance':False,'acceptance_owner':'A/root',
 'product_writes_by_reviewer':False,'stage_commit':False,'board_serial_UI_services_network_messages':False,
 'G03':'not_run','R03':'not_run','all29':'not_run'}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
excluded={'lease.private.json','artifact-manifest.json','freeze.json','native-complete-request.json','native-complete-receipt.json'}
files={}
for p in sorted(OUT.rglob('*')):
    if not p.is_file() or p.name in excluded:continue
    raw=p.read_bytes();files[p.relative_to(OUT).as_posix()]={'sha256':sha(raw),'bytes':len(raw)}
manifest={'schema':1,'files':files,'excluded':sorted(excluded),'lease_private_publish':False}
(OUT/'artifact-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name,pin in files.items():assert sha((OUT/name).read_bytes())==pin['sha256'],name
freeze={'schema':1,'manifest_sha256':sha((OUT/'artifact-manifest.json').read_bytes()),'member_count':len(files),
 'result_sha256':sha((OUT/'result.json').read_bytes()),'report_sha256':result['report_sha256'],
 'all_members_readback_verified':True,'source_pins_rechecked':True,'tests_rerun_by_freezer':False,
 'actualclock_sleep_consume_repeated':False,'native_complete_not_yet_called':True}
(OUT/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n',encoding='utf-8')
print(json.dumps(freeze))
