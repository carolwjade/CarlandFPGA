"""Shape-only fixture glue for the frozen QPC oracle. No actual clock reads."""
from contextlib import contextmanager,ExitStack
from dataclasses import replace
import ast
import hashlib
import importlib
import json
import os
from pathlib import Path
import struct
import sys
from types import SimpleNamespace
from unittest.mock import patch

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];PRODUCT=ROOT/'.local/deepeye-implementation-a'
sys.path.insert(0,str(PRODUCT))
api=SimpleNamespace(
 hc=importlib.import_module('competition.deepeye.integration.host_clock'),
 receipts=importlib.import_module('competition.deepeye.integration.live_board_receipts'),
 transcript=importlib.import_module('competition.deepeye.integration.boot_transcript'),
 actors=importlib.import_module('competition.deepeye.simulation.isolation.actor_owner'),
 composition=importlib.import_module('competition.deepeye.simulation.authority.actor_composition'))
boot=importlib.import_module('competition.deepeye.integration.boot_profile')
wire=importlib.import_module('competition.deepeye.integration.wire')
co=importlib.import_module('competition.deepeye.simulation.authority.candidate_owner')
_scripts=[]
_READ,_WRITE=os.read,os.write

class Script:
    def __init__(self):self.values=[];self.leaf_calls=0;self.original_leaf=api.hc.time.perf_counter_ns
    def set_values(self,values):self.values=list(values);self.leaf_calls=0
    def leaf(self):
        self.leaf_calls+=1
        if not self.values:raise AssertionError('unexpected private-leaf read; no actual fallback')
        value=self.values.pop(0)
        if isinstance(value,BaseException):raise value
        return value

@contextmanager
def scripted_clock():
    f=Script()
    with patch.object(api.hc,'_qpc_leaf',side_effect=f.leaf),patch.object(api.hc,'_qpc_capability',return_value={
        'implementation':'QueryPerformanceCounter()','monotonic':True,'adjustable':False,'resolution':1e-7}):
        f.binding=api.hc.qpc_clock_for_new_run()
        _scripts.append(f)
        try:yield f
        finally:_scripts.remove(f)

def script_for(binding):return next(f for f in _scripts if f.binding is binding)
def sample_parts(sample):return sample.raw_ns,sample.clock_domain,sample.interval_ns
def metadata(binding):return binding.metadata
def transcript_binding(sender):return sender.clock_domain
def read_end(row):return row['raw_read_call_bracket_ns'][1]
def write_end(row):return row['raw_write_call_bracket_ns'][1]
def replace_ledger_domain_for_fault(ledger,other):ledger._clock_domain=other
def encode(v):return json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()

def config():
    policy=object.__new__(api.actors.ActorPolicy)
    object.__setattr__(policy,'run_id','independent-qpc-route')
    return api.composition.AuthorityConfig(policy,object(),object(),object(),object(),
        500_000_000,16,100_000_000,'b'*64)

class IO:
    def __init__(self,binding):
        base=OUT/'fixture-evidence';base.mkdir(exist_ok=True)
        index=1
        while (base/('%04d'%index)).exists():index+=1
        self.directory=base/('%04d'%index);self.directory.mkdir()
        self.binding=binding;self.read_calls=self.write_calls=0;self.returned_count=None
        self.in_reader,self.in_writer=os.pipe();self.out_reader,self.out_writer=os.pipe()
        os.set_blocking(self.in_reader,False);os.set_blocking(self.out_reader,False)
        build=b'independent QPC synthetic build identity'
        identity=api.receipts.CaptureIdentity('independent-qpc-routing','a'*64,'b'*40,
            hashlib.sha256(build).hexdigest(),1)
        self.ledger=api.receipts.ReceiptLedger(self.in_reader,identity,max_bytes=4096,max_reads=8,host_clock=binding)
        doc=boot.load_document(PRODUCT/'competition/deepeye/docs/boot_profiles.json')
        self.journal=self.directory/'boot.jsonl'
        self.transcript=api.transcript.BootTranscript(self.out_writer,self.ledger,identity=identity,
            profile=doc,profile_sha256=boot.canonical_sha256(doc).hex(),build_manifest=build,
            bit_sha256='c'*64,hwh_sha256='d'*64,session=7,mode=45,config_epoch=2,
            sequence=1,tick_ms=0,max_ack_checks=2,journal_path=self.journal)
        self.original_request=self.transcript._request
        self.stack=ExitStack()
        self.stack.enter_context(patch.object(api.receipts.os,'read',side_effect=self.read))
        self.stack.enter_context(patch.object(api.transcript.os,'write',side_effect=self.write))
    def read(self,*args):self.read_calls+=1;return _READ(*args)
    def write(self,*args):
        self.write_calls+=1;self.returned_count=_WRITE(*args);return self.returned_count
    def arm_read(self,chunk,post_stamp_failure=False):
        _WRITE(self.in_writer,chunk)
        script_for(self.binding).set_values([100,ValueError('independent post-read stamp failure')] if post_stamp_failure else [100,101])
    def arm_write(self,post_stamp_failure=False,pre_marker_failure=False):
        values=([ValueError('independent marker stamp failure')] if pre_marker_failure else
                [100,101,ValueError('independent post-write stamp failure')] if post_stamp_failure else [100,101,102])
        script_for(self.binding).set_values(values)
    def journal_rows(self):return [json.loads(line) for line in self.journal.read_text(encoding='utf-8').splitlines()]
    def close_input_writer(self):
        os.close(self.in_writer)
        self.in_writer=None
    def close(self):
        self.stack.close()
        (self.directory/'ledger.json').write_text(json.dumps(self.ledger.snapshot(),indent=2)+'\n',encoding='utf-8')
        (self.directory/'transcript.json').write_text(json.dumps(self.transcript.snapshot(),indent=2)+'\n',encoding='utf-8')
        (self.directory/'counts.json').write_text(json.dumps({'read_calls':self.read_calls,'write_calls':self.write_calls,
            'returned_count':self.returned_count})+'\n',encoding='utf-8')
        self.transcript.close();self.ledger.close()
        for fd in [self.in_reader,self.in_writer,self.out_reader,self.out_writer]:
            if fd is not None:os.close(fd)

@contextmanager
def io_fixture(binding):
    f=IO(binding)
    try:yield f
    finally:f.close()

@contextmanager
def routing_fixture(binding):
    # Legacy ctor routing is sampled with private module clock seams, not real time.
    with ExitStack() as stack:
        if binding is None:
            legacy=lambda:1_000_000
            stack.enter_context(patch.object(api.actors,'monotonic_ns',legacy))
            stack.enter_context(patch.object(api.composition,'monotonic_ns',legacy))
            stack.enter_context(patch.object(api.receipts,'monotonic_ns',legacy))
        else:script_for(binding).set_values([1_000_000])
        stack.enter_context(patch.object(api.actors,'_native_api',return_value=object()))
        registry_factory=api.actors.ActorRegistry
        # Actual registry class and actual runtime ctor; only launch/executor are seams.
        stack.enter_context(patch.object(registry_factory,'launch',return_value=SimpleNamespace(instance_id='no-native-actor')))
        stack.enter_context(patch.object(api.composition,'OwnedMotionExecutor',return_value=object()))
        owner=api.composition.ActorComposition(api.composition._FACTORY,config(),object(),host_clock=binding)
        owner._start()
        with io_fixture(binding) as io:
            yield SimpleNamespace(ledger=io.ledger,transcript=io.transcript,registry=owner._registry,
                                  composition=owner,runtime=owner._runtime)

@contextmanager
def proof_fixture(binding):
    doc=boot.load_document(PRODUCT/'competition/deepeye/docs/boot_profiles.json')
    context={'session':7,'config_epoch':2,'boot_sha256':boot.canonical_sha256(doc).hex(),
        'transport_profile_id':1,'source_id':3,'topology_id':2,'acquisition_profile_id':1}
    b=SimpleNamespace(context_json=encode(context),generation=1);source=object()
    activation=co._MailboxActivation(b,source,binding,0,0,0)
    owner=co._CandidateOwner(b,source,binding,'b'*64,300_000_000,0,activation,0)
    frame=wire.encode(wire.Frame(1,2,9,9,struct.pack('<4H4HH',1,2,3,4,5,6,7,8,3)))
    raw=encode(dict(schema_version=1,context=context,kind='telem_observation',observed_seq=9,tick_ms_raw=9,
        receipt_interval_ns=dict(lower_ns=0,upper_ns=0),adc_last_interval_ns=dict(lower_ns=0,upper_ns=0),
        adc_first_interval_ns=None,native_em_interval_ns=None,sample_count=50,mean_counts=[1,2,3,4],
        range_counts=[5,6,7,8],quality_flags=3,wire_frame_hex=frame.hex()))
    owner.observe(SimpleNamespace(boot=b,raw=raw,sample_lower_ns=0),0)
    candidate=encode(dict(schema_version=1,context=context,kind='model_candidate',candidate_id=1,model_sha256='b'*64,
        observation=dict(context=context,observed_seq=9),completed_monotonic_ns=100_000_000,
        target=dict(action=1,yaw_q=0,pitch_q=0,speed_code=5,duration_ms=1000)))
    proof=co._CompletedInference(b,source,binding,candidate,1,0,100_000_000,100_000_000)
    yield SimpleNamespace(owner=owner,proof=proof,now=100_000_000)

@contextmanager
def rejected_clock_fixture(invalid):
    errors=[];calls=[]
    def forbidden(*args,**kwargs):calls.append(True);raise AssertionError('invalid clock reached acquisition')
    identity=api.receipts.CaptureIdentity('invalid-clock','a'*64,'b'*40,'c'*64,1)
    with patch.object(api.receipts.os,'fstat',side_effect=forbidden),patch.object(api.actors,'_native_api',side_effect=forbidden),\
         patch.object(api.composition,'_production_channels',side_effect=forbidden):
        for invoke in [lambda:api.receipts.ReceiptLedger(0,identity,max_bytes=32,max_reads=1,host_clock=invalid),
                       lambda:api.actors.ActorRegistry(host_clock=invalid),
                       lambda:api.composition.create_authority(config(),host_clock=invalid)]:
            try:invoke()
            except ValueError as exc:errors.append(type(exc).__name__)
        yield SimpleNamespace(rejected=len(errors)==3,native_or_io_calls=len(calls))

def static_preservation():
    data=json.loads((OUT/'phase2-sourcehashes.json').read_text(encoding='utf-8'))
    results=dict(data['ast_preserved'])
    for name,pin in data['unchanged_dependencies'].items():
        results['bytes:'+name]=hashlib.sha256((PRODUCT/name).read_bytes()).hexdigest()==pin['sha256']
    return results

@contextmanager
def production_fixture(binding):
    with patch.object(api.composition,'ActorRegistry') as registry:
        p=SimpleNamespace(config=config())
        class View:
            config=p.config
            @property
            def acquisition_calls(self):return registry.call_count
        yield View()
