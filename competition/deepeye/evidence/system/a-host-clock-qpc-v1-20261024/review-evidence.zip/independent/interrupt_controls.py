"""New independent read-interruption controls; scripted clocks, actual local pipes."""
import errno,json,os,sys,unittest
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
import candidate_adapter as a
OUT=Path(__file__).resolve().parent

class InterruptControls(unittest.TestCase):
    def test_I01_unknown_after_kernel_read_closes_all_future_entries(self):
        chunk=b'R!\x00\xffQ'
        with a.scripted_clock() as f,a.io_fixture(f.binding) as io:
            io.arm_read(chunk)
            f.set_values([100])
            observed={'boundary_entries':0,'actual_kernel_reads':0,'consumed_hex':None}
            def interrupted(fd,count):
                observed['boundary_entries']+=1
                if observed['boundary_entries']>1:raise AssertionError('second OS boundary entered')
                observed['actual_kernel_reads']+=1
                raw=a._READ(fd,count)
                observed['consumed_hex']=raw.hex()
                raise KeyboardInterrupt('independent post-kernel interrupt')
            with patch.object(a.api.receipts.os,'read',side_effect=interrupted):
                with self.assertRaises(KeyboardInterrupt):io.ledger.read_once()
                after=io.ledger.snapshot()
                self.assertTrue(after['failed'])
                self.assertEqual(len(after['reads']),1)
                row=after['reads'][0]
                self.assertEqual(row['kind'],'started_unknown')
                self.assertIsNone(row['raw_hex'])
                self.assertIsNone(row['returned_bytes'])
                self.assertEqual(row['stream_start'],0)
                self.assertEqual(row['raw_read_call_bracket_ns'],[100,None])
                self.assertEqual(row['failure_type'],'KeyboardInterrupt')
                self.assertEqual(after['frames'],[])
                with self.assertRaises(ValueError):io.ledger.read_once()
                with self.assertRaises(ValueError):io.ledger.claim_board_response(object(),context={})
            self.assertEqual(observed,{'boundary_entries':1,'actual_kernel_reads':1,'consumed_hex':chunk.hex()})
            observed['after_first']=after
            observed['after_refusal']=io.ledger.snapshot()
            (OUT/'independent-interrupt-witness.json').write_text(json.dumps(observed,indent=2)+'\n',encoding='utf-8')

    def test_I02_recorded_empty_data_eof_reopen_only_within_original_budget(self):
        with a.scripted_clock() as f,a.io_fixture(f.binding) as io:
            f.set_values([100,101])
            self.assertEqual(io.ledger.read_once(),())
            first=io.ledger.snapshot()
            self.assertFalse(first['failed']);self.assertEqual(first['reads'][0]['kind'],'empty')
            a._WRITE(io.in_writer,b'abc')
            f.set_values([102,103])
            self.assertEqual(io.ledger.read_once(),())
            second=io.ledger.snapshot()
            self.assertFalse(second['failed']);self.assertEqual(second['bytes_read'],3)
            self.assertEqual(second['reads'][1]['returned_bytes'],3)
            io.close_input_writer();f.set_values([104,105])
            self.assertEqual(io.ledger.read_once(),())
            final=io.ledger.snapshot()
            self.assertFalse(final['failed']);self.assertTrue(final['eof'])
            self.assertEqual([r['kind'] for r in final['reads']],['empty','data','eof'])
            self.assertEqual(io.read_calls,3)
            with self.assertRaises(ValueError):io.ledger.read_once()
            self.assertEqual(io.read_calls,3)
        with a.scripted_clock() as f,a.io_fixture(f.binding) as io:
            io.ledger._max_reads=1  # Independently explicit bounded fixture policy.
            f.set_values([100,101]);io.ledger.read_once()
            with self.assertRaises(ValueError):io.ledger.read_once()
            self.assertEqual(io.read_calls,1)

    def test_I03_os_error_and_scan_error_remain_permanently_failed(self):
        for failure in ['os_error','scan_error']:
            with self.subTest(failure=failure),a.scripted_clock() as f,a.io_fixture(f.binding) as io:
                f.set_values([100,101])
                if failure=='os_error':
                    with patch.object(a.api.receipts.os,'read',side_effect=OSError(errno.EIO,'independent read error')) as call:
                        with self.assertRaises(OSError):io.ledger.read_once()
                        with self.assertRaises(ValueError):io.ledger.read_once()
                        self.assertEqual(call.call_count,1)
                else:
                    a._WRITE(io.in_writer,b'known returned bytes')
                    with patch.object(io.ledger,'_scan',side_effect=ValueError('independent scan failure')):
                        with self.assertRaises(ValueError):io.ledger.read_once()
                        with self.assertRaises(ValueError):io.ledger.read_once()
                    self.assertEqual(io.read_calls,1)
                    self.assertEqual(io.ledger.snapshot()['reads'][0]['raw_hex'],b'known returned bytes'.hex())
                self.assertTrue(io.ledger.snapshot()['failed'])
                self.assertEqual(len(io.ledger.snapshot()['reads']),1)
                with self.assertRaises(ValueError):io.ledger.claim_board_response(object(),context={})

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(InterruptControls)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
