"""Read only the assigned committed baseline; never import product modules."""
import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PRODUCT=ROOT/'.local/deepeye-implementation-a'
BASE='17fe7a63652dac6003f3ff6c71abe90eb10c8c87'
GIT='C:/Users/CarlJade/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(name):return subprocess.check_output([GIT,'-C',str(PRODUCT),'show',BASE+':'+name])
names=['integration/live_board_receipts.py','integration/boot_transcript.py',
 'simulation/isolation/actor_owner.py','simulation/authority/actor_composition.py',
 'docs/actor_composition.md','simulation/isolation/actor_lifetime.py',
 'simulation/authority/pc_direct_runtime.py','simulation/authority/candidate_owner.py',
 'simulation/authority/motion_executor.py','integration/candidate_mailbox.py',
 'integration/pc_direct_watchdog.py','integration/wire.py','docs/boot_profiles.json']
pins={}
for rel in names:
    name='competition/deepeye/'+rel
    data=blob(name);target=OUT/'baseline'/name
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    pins[name]={'sha256':sha(data),'bytes':len(data)}
scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
requirements=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8'))
assert requirements=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=json.loads((ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json').read_text(encoding='utf-8'))
assert transfer['status']=='active' and transfer['director_generation']==3
assert transfer['new_director_thread_id']=='01a16988-bdcb-70e1-ae10-1304b5cf7875'
inputs={}
for rel in ['.planning/deepeye-resume-20261018/high-res-clock-design-20261024/report.md',
 '.planning/deepeye-resume-20261018/gen3-live-integration-20261024/host-clock-qpc-v1-decision.json',
 '.planning/deepeye-desktop-handoff-20261015/transfer.json',
 'docs/competition/deepeye-2026/immutable_scope.md','docs/competition/deepeye-2026/immutable_scope.json']:
    data=(ROOT/rel).read_bytes();inputs[rel]={'sha256':sha(data),'bytes':len(data)}
record={'schema':1,'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,
 'work_id':'A-HOST-CLOCK-QPC-V1-REVIEW-20261024-v1',
 'job_id':'child-b1f2b02e711a47e2a4e2f17235e64216','agent_id':'/root/pc_direct_window_review',
 'baseline_commit':BASE,'requirements_sha256':requirements,'H01_H15_preserved':True,
 'baseline_files':pins,'inputs':inputs,'source_access':'git show exact committed base:path only',
 'author_current_source_or_tests_read':False,'tests_run':False,'product_writes':False,
 'real_clock_or_sleep_observation':False,'native_complete_called':False}
(OUT/'phase1-source-pins.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'baseline_commit':BASE,'baseline_files':len(pins),'requirements_sha256':requirements,'tests_run':False}))
