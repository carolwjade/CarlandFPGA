# QPC v1 限定独立复核

最终候选的 **8 组受限修正控制及 3 组新增 interrupt 控制全部通过**，两次命令各为 exit 0、零 failures/errors。原冻结8组首次为7通过、Q03一项预期错误失败；原harness、失败日志和执行哈希均保留。root另发现并修复的read interrupt缺陷也完整保留RED/GREEN；本复核者未修改产品。

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，work `A-HOST-CLOCK-QPC-V1-REVIEW-20261024-v1`，agent `/root/pc_direct_window_review`，当前job `child-b1f2b02e711a47e2a4e2f17235e64216` 已以新租约/canonical agent验证execution_allowed=true，未复用上一completed租约。主为 Desktop `01a16988-bdcb-70e1-ae10-1304b5cf7875` / generation3，transfer为active。H01–H15现场重算canonical requirements SHA256=`c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，原合同、原29卡和A/root独占实板保留。

## 准确版本与证据

基准/HEAD为 `17fe7a63652dac6003f3ff6c71abe90eb10c8c87`。第一阶段只用该commit的git show读取13个基线源/文档，不读作者实时源或测试；冻结18成员manifest SHA256=`a662b99026f1c23b8e04c0599f18ff35267cc1ebfaae3d49350beca508728292`。第二阶段按root解封读准确9文件、作者新tests/文档及原记录，但不运行作者21方法组或旧组件suite。

作者原source-pins SHA256=`e51fa5c40ad78014e7462eeaf2edf304b137b54981122de20f497f66231ea227`、51成员artifactmanifest SHA256=`c0e1a42e6e20cd9ba7d1dfd58fcbaaaa1fc764169b3c134797a2a42189ecde17`，全部成员和9个原source-snapshot逐字节实算匹配。16个依赖等于基准，4个C保护文件等于原hash；15个原gate AST对象严格相同，其中production gate按获批routing签名之外的原body比较，仍无条件raise且先于registry。

最终候选比作者封存版仅一个root修正：`integration/live_board_receipts.py` 从 `45879bc7fbe95705b4836d5cadfabc996a80c819e52a50299c2573b7e9b85446` 变为 **`b427bb730e741bcaf35134a7be0473aa2ec0e3ea262ae81448d8a9872d0dad91`**。另8个原pins不变。原作者snapshot/manifest不重写；最终9pins、root修正准确diff及当前副本另存 `final-sourcehashes.json`、`final-candidate.diff`、`final-source-snapshot/`。作者原9pins不能被表述成最终9pins全相同。

## oracle修正与fixture边界

原Q03把legacy ledger.clock_domain错误预计为monotonic callable。候选用None标记legacy，而实际 `_clock` 保留原模块monotonic。首次按原oracle运行8组，唯一失败正为 `None is not callable`；adapter直接返回真实None，未制造字段。root明确授权仅改该前提并增加真实 `_clock is 原monotonic callable` 检查。原harness SHA256=`03ff921bec563c9bd012f2325ecf9542b93d9ba1533da93b9dbce3b0e3b062e5`，备份 `independent_controls-phase1.py`；修正版SHA256=`868102f9b1a1ab2e67086505e5b50e39d718be1c3245e45316f6954c6338d6f9`。其余oracle/阈值、普通callable拒绝均不变，见 `q03-authorized-delta.json`。

delta中的 `tests_run_after_delta=false`、`waiting_new_source_pin=true` 和 `adapter_unchanged=true` 是作出Q03修正时的事件快照，不是最终状态。随后收到b427新pin，实际修正版8组exit0记录在 `attempt2-root-revision-execution.json`；为I02正常EOF清理另新增close_input_writer helper并跳过已关闭fd。因此不能把当时adapter_unchanged泛化为最终从未变化。原adapter SHA256为9faca2cf197f7d6e51980b8ba31d26d1ba1795939ae167cfe9e2ddc7aaca898e，最终为c1fc7e57668c3d2f1f13d58e6ca36cdea791fb4ce06a5dd3be65b7e2f4cf7b96；变化仅fixture descriptor清理，不取代任何产品字段/阈值。

`candidate_adapter.py` 仅在phase2按已冻结contract接线：实际sample.raw_ns/clock_domain/interval_ns直接读取，无dict.get填None；原叶静态定位为time.perf_counter_ns，执行时只替换模块私有 `_qpc_leaf/_qpc_capability` 为明确script fixture。实际registry/runtime构造保持，native API/actor launch/executor acquisition是私有spy；legacy取时也只在模块私有fixture seam中供值。新interrupt测试仅补一个关闭fixture输入writer的清理helper，原adapter备份和前后hash保留。没有实际QPC/monotonic observation、sleep或policy consume，没有旧/作者TestCase导入或执行。

## 最终实际控制

`run_controls.py attempt2-root-revision` 执行修正版8组；`interrupt_controls.py` 执行独立新增3方法。现有venv，仅子进程设现有jsonschema PYTHONPATH和禁bytecode；stdout/stderr、参数数组、退出码和harness/adapter hash均留存。并非重跑作者或root probe脚本。新增控制使用有限本地pipe/BOOT journal；不接触板、串口、UI、服务、网络、模型或actor/native进程。

| 组 | 实际结果 |
|---|---|
| Q01–Q02 | fixed leaf/no caller override、原raw/sample域、unknown interval、严格数值/回退/foreign线程永久失败通过。advertised100ns未填测时区间。|
| Q03–Q04 | exact同对象贯穿ledger/BOOT/registry/composition/runtime；legacyNone标记与实际monotonic callable分别核验；第二binding同数值也不能替代原completion/domain，伪对象和普通callable拒绝。|
| Q05 | 实际pipe已返回5字节后post-stamp失败：原bytes/offset/1次read预算保留，末时刻unknown、failed，第二read/claim拒绝。|
| Q06 | 实际BOOT pipe write返回count后post-stamp失败：原request/count和durable started_unknown保留，末时刻unknown、不重发；marker前故障0次write。|
| Q07–Q08 | 原protected gate对象/依赖字节保持；有效QPC仍无条件production拒绝，registry零次构造。|
| I01 | 独立wrapper只实际kernel read一次，取走不同于root probe的5字节 `522100ff51` 后抛KeyboardInterrupt；ledger为failed，保留1条started_unknown、raw_hex=None、returned_bytes=None、stream_start=0、raw bracket=[100,None]。第二read和claim均ValueError，OS边界仍1次，无第二实际读。|
| I02 | 正常empty→data→EOF各完整记录后failed=false，data已知count保留；EOF后拒绝额外read。独立1-read预算fixture也拒绝下一入口。|
| I03 | OSerror、scan异常均保持failed且第二read/claim拒绝；scan失败保留已返回原bytes。post-stamp异常由Q05覆盖。|

I01的 `bytes_read=0` 仅是原已知返回前缀累计，不代表实际未消耗字节。产品不知道wrapper隐藏的返回，所以row的raw/count必须None；独立外部witness单独证明5字节确已取走，不能倒灌为产品“已知”。该分层与最终root修正一致。

## 原缺陷及root修正

root的新边界probe在原45879源中执行一次kernel read后由wrapper抛KeyboardInterrupt；原代码只捕获OSError，failed仍false且第二边界可达（spy在第二真实读前拦下）。原RED保留在 `qpc-root-interrupt-probe-20261024/attempt1-red`，不是本子任务重跑的失败。

root只修receipt源：OS调用前先latch failed并预留unknown read条目/预算，原返回raw/count只在确实返回时记录；完整read/stamp/scan成功后才解除failed。未知异常永久关闭，不虚构raw/count或重读。root GREEN原记录与本复核者独立I01–I03均支持该有限修复。root RED/GREEN副本及哈希在本目录，原位置不改。本复核未改产品、stage/commit或再派工。

root后续的 `qpc-root-interrupt-probe-20261024/root-correction.json` 明确记录该单文件修正、保留RED/GREEN与另8pins不变；本目录只读复制为 `root-correction.json`，不重跑其脚本。

## 实际QPC观察的准确上限

只读作者唯一原观察：operation `A-HOST-CLOCK-QPC-V1-OBSERVE-20261024-01`，run `qpc-new-run-94d1da993a114d678f9c7e9c7dbd7914`，固定origin=131587083635100、S=131587293635100、E=131587303635100，actual raw=131587293900700，即S后265600ns，一次消费成功。原W=10ms、ready=131587100223600、原D=131588584134200未变；timestamp_interval_ns和timestamp_uncertainty_ns均None。

该记录属于作者原封存版的一次raw软件fixture观察；host_clock/mailbox在root单文件修正前后字节未变。本复核未再次执行观察或旧monotonic试验。结果只证明该次本机raw取时/普通等待，不能证明调度上界、物理deadline、跨进程QPC对应、原完成/源测时、PL/ADC/model/motion provenance。100ns resolution不是uncertainty，不对旧epoch作offset换算。

原v2 W、固定O/F/P/k、ready与所有原期限、ProgressGate、一次消费、原HANDLE/FILETIME身份与lifetime算法、验证后刷新及final-fence→strict end<deadline→CAS保持。静态相同不意味着重验每个旧门。生产无条件关闭；本节点只给raw来源一致与有限故障保留证据，不作正式接受。`G03/R03/all29=not_run`，H09、两条完整H12、完整3D/UI、实质PC AI及原29卡继续由root依据真实证据验收。
