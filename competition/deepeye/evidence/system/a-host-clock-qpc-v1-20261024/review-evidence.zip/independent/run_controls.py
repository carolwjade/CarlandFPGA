import hashlib,json,os,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
attempt=sys.argv[1] if len(sys.argv)>1 else 'attempt1'
frozen=json.loads((OUT/'phase1-manifest.json').read_text(encoding='utf-8'))
delta=json.loads((OUT/'q03-authorized-delta.json').read_text(encoding='utf-8'))
assert hashlib.sha256((OUT/delta['original_harness_backup']).read_bytes()).hexdigest()==frozen['files']['independent_controls.py']['sha256']==delta['original_harness_sha256']
expected=delta['revised_harness_sha256']
actual=hashlib.sha256((OUT/'independent_controls.py').read_bytes()).hexdigest()
assert actual==expected
assert hashlib.sha256((ROOT/'.local/deepeye-implementation-a/competition/deepeye/integration/live_board_receipts.py').read_bytes()).hexdigest()=='b427bb730e741bcaf35134a7be0473aa2ec0e3ea262ae81448d8a9872d0dad91'
command=[str(ROOT/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(OUT/'independent_controls.py'),'--phase2-authorized']
run=subprocess.run(command,cwd=ROOT,env=dict(os.environ,PYTHONPATH=str(ROOT/'.local/deepeye-host-deps'),PYTHONDONTWRITEBYTECODE='1'),capture_output=True)
for suffix,data in [('stdout.log',run.stdout),('stderr.log',run.stderr)]:
    target=OUT/(attempt+'-'+suffix)
    if target.exists():raise RuntimeError('Refuse overwrite of an existing run')
    target.write_bytes(data)
meta={'command':command,'exit_code':run.returncode,'harness_sha256':actual,
      'adapter_sha256':hashlib.sha256((OUT/'candidate_adapter.py').read_bytes()).hexdigest(),
      'stdout_sha256':hashlib.sha256(run.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(run.stderr).hexdigest(),
      'actual_clock_sleep_consume_run':False,'old_or_author_tests_run':False}
(OUT/(attempt+'-execution.json')).write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
print(run.stderr.decode('utf-8',errors='replace'))
print(run.stdout.decode('utf-8',errors='replace'))
print(json.dumps(meta))
raise SystemExit(run.returncode)
