"""New QPC controls only, exact source pins, formatting and unchanged gates."""
import ast
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PRODUCT=ROOT/'.local/deepeye-implementation-a'
BASE='17fe7a63652dac6003f3ff6c71abe90eb10c8c87'
OWNED=[
 'competition/deepeye/integration/host_clock.py',
 'competition/deepeye/integration/live_board_receipts.py',
 'competition/deepeye/integration/boot_transcript.py',
 'competition/deepeye/simulation/isolation/actor_owner.py',
 'competition/deepeye/simulation/authority/actor_composition.py',
 'competition/deepeye/integration/test_host_clock_qpc_v1.py',
 'competition/deepeye/tests/simulation/test_host_clock_qpc_v1.py',
 'competition/deepeye/docs/host_clock_qpc_v1.md',
 'competition/deepeye/docs/actor_composition.md']
DEPENDENCIES=[
 'competition/deepeye/integration/candidate_mailbox.py',
 'competition/deepeye/simulation/authority/candidate_owner.py',
 'competition/deepeye/simulation/authority/pc_direct_runtime.py',
 'competition/deepeye/simulation/authority/motion_executor.py',
 'competition/deepeye/simulation/isolation/actor_lifetime.py',
 'competition/deepeye/integration/pc_direct_watchdog.py',
 'competition/deepeye/integration/wire.py',
 'competition/deepeye/integration/boot_profile.py',
 'competition/deepeye/docs/boot_profiles.json',
 'competition/deepeye/integration/test_boot_transcript.py',
 'competition/deepeye/integration/test_live_board_receipts.py',
 'competition/deepeye/tests/simulation/test_actor_owner.py',
 'competition/deepeye/tests/simulation/test_candidate_owner.py',
 'competition/deepeye/tests/simulation/test_actor_composition.py',
 'competition/deepeye/tests/simulation/test_pc_direct_runtime.py',
 'competition/deepeye/tests/simulation/test_motion_executor.py']
sys.path[:0]=[str(PRODUCT),str(ROOT/'.local/deepeye-host-deps')]
def sha(raw): return hashlib.sha256(raw).hexdigest()
def save(name,value):
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def git(*args):
 return subprocess.run(['git',*args],cwd=PRODUCT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)

# Normalize only the nine owned product files, then explicitly check new/untracked too.
formatting={}
for path in OWNED:
 raw=(PRODUCT/path).read_bytes()
 text=raw.decode('utf-8').replace('\r\n','\n').replace('\r','\n')
 normalized='\n'.join(line.rstrip(' \t') for line in text.split('\n')).rstrip('\n')+'\n'
 (PRODUCT/path).write_bytes(normalized.encode('utf-8'))
 check=(PRODUCT/path).read_bytes()
 assert check.endswith(b'\n') and not check.endswith(b'\n\n') and b'\r' not in check
 assert all(not line.endswith((b' ',b'\t')) for line in check.splitlines())
 if path.endswith('.py'): ast.parse(normalized,filename=path)
 formatting[path]=dict(exactly_one_final_LF=True,no_trailing_whitespace=True,all_line_endings_LF=True)
scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
requirements=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
assert requirements=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
pins={}
for path in OWNED+DEPENDENCIES:
 raw=(PRODUCT/path).read_bytes(); base=git('show',BASE+':'+path)
 pins[path]=dict(bytes=len(raw),sha256=sha(raw),base_sha256=sha(base.stdout) if not base.returncode else None,
                 same_as_base=not base.returncode and raw==base.stdout)
assert all(pins[path]['same_as_base'] for path in DEPENDENCIES)
protected=json.loads((ROOT/'.planning/deepeye-resume-20261018/r03-mailbox-stop-main-review-20261020/application.json').read_text(encoding='utf-8'))['protected_files']
assert all(sha((PRODUCT/path).read_bytes())==value for path,value in protected.items())
assert git('diff','--check','--',*OWNED).returncode==0

def subtree(source,target,body_only=False):
 nodes=ast.parse(source).body
 for part in target.split('.'):
  selected=next(node for node in nodes if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name==part)
  nodes=selected.body
 return ([ast.dump(node,include_attributes=False) for node in nodes] if body_only
         else ast.dump(selected,include_attributes=False))
targets={
 OWNED[3]:['ActorOwner','ActorRegistry.launch'],
 OWNED[4]:['_Dependencies','_ProgressGate','_entry','ActorComposition.accept_boot',
            'ActorComposition.accept_command','ActorComposition.accept_completion','ActorComposition.step',
            'ActorComposition._progress_time','_production_channels']}
gates={}
for path,names in targets.items():
 base=git('show',BASE+':'+path).stdout.decode('utf-8'); actual=(PRODUCT/path).read_text(encoding='utf-8')
 for name in names:
  body_only=name=='_production_channels'
  gates[path+':'+name]=subtree(base,name,body_only)==subtree(actual,name,body_only)
assert all(gates.values())
save('source-pins.json',dict(base_commit=BASE,head_readback=git('rev-parse','HEAD').stdout.decode().strip(),
 requirements_sha256=requirements,owned_files=OWNED,source=pins,protected_files=protected,
 formatting=formatting,unchanged_method_AST=gates))
(OUT/'owned.diff').write_bytes(git('diff','--',*OWNED).stdout)
(OUT/'git-status.txt').write_bytes(git('status','--short').stdout)

names=['competition.deepeye.integration.test_host_clock_qpc_v1',
       'competition.deepeye.tests.simulation.test_host_clock_qpc_v1']
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(name)) for name in names)
def cases(suite):
 for case in suite:
  if isinstance(case,unittest.TestSuite): yield from cases(case)
  else: yield case
ids=[case.id() for case in cases(suite)]
assert len(ids)==21 and all('.test_host_clock_qpc_v1.' in case for case in ids)
os.environ['QPC_CONTROL_OUT']=str(OUT/'raw-controls')
class Results(unittest.TextTestResult):
 def __init__(self,*args): super().__init__(*args); self.subtests=[]
 def addSubTest(self,test,subtest,error):
  self.subtests.append(dict(test=test.id(),parameters=str(subtest),success=error is None))
  super().addSubTest(test,subtest,error)
with (OUT/'focused-green.log').open('w',encoding='utf-8') as log:
 result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Results).run(suite)
save('focused-result.json',dict(executed_test_ids=ids,tests_run=result.testsRun,
 subtests=result.subtests,success=result.wasSuccessful(),failures=len(result.failures),errors=len(result.errors),
 old_test_cases_executed=0,old_11_16_25_9_suites_PDE_384=False,
 upstream_native_fixed_leaf='synthetic seams; OS pipe I/O actual',
 source_pins_sha256=sha((OUT/'source-pins.json').read_bytes())))
assert all(sha((PRODUCT/path).read_bytes())==value['sha256'] for path,value in pins.items())
assert all(sha((PRODUCT/path).read_bytes())==value for path,value in protected.items())
print(json.dumps(dict(tests_run=result.testsRun,subtests=len(result.subtests),success=result.wasSuccessful(),
 failures=len(result.failures),errors=len(result.errors),formatting_all_nine='passed',
 dependencies_and_C_four_unchanged=True,unchanged_gate_AST=True),sort_keys=True))
sys.exit(0 if result.wasSuccessful() else 1)
