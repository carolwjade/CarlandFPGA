# Fresh-run raw QPC implementation

Implemented the root-selected fixed QPC binding and same-object routing, with
unknown timing retained and original I/O facts preserved across clock failure.
This is a software increment for root review, not production/physical acceptance.
Task DEEPEYE-IMPLEMENTATION-20261014/v1; work
A-HOST-CLOCK-QPC-V1-IMPLEMENT-20261024-v1; canonical /root/pc_direct_window.
New job child-3ec73af1c38b4a1cb7fd8f2d9205e535 validated execution_allowed=true;
the completed preceding v2 lease was not reused. Current director transfer is
active Gen3 01a16988-bdcb-70e1-ae10-1304b5cf7875. Exact base / HEAD readback:
17fe7a63652dac6003f3ff6c71abe90eb10c8c87. Published v2 was not overwritten.

Read the selected high-res-clock design and root host-clock-qpc-v1 decision;
retained previously loaded mandatory project/A roles/TDD/verification guidance.
Immutable requirements were recomputed with UTF-8 ensure_ascii=False, sorted keys
and compact separators:
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
DEEPEYE-HUMAN-LOCK-20261014/revision1, H01-H15 and A/root-only board operation
remain unchanged. Only the assigned nine product files and this evidence folder
were written. No stage/commit, additional delegation, physical board/serial, UI,
service, product/peer network, PR or external message operation occurred.

## Implementation and limits

qpc_clock_for_new_run() has no caller callable, now, mode or verified flag. It
checks the fixed time.perf_counter_ns capability is QueryPerformanceCounter,
monotonic and nonadjustable; unsupported capability refuses without fallback.
Exact QpcHostClock is a stable callable/domain object with owner-thread,
strict bounded int/high-water and permanent-failure checks. Its metadata is
read-only and not authentication. read_sample retains raw/domain with interval
None; advertised 100 ns resolution never fills timestamp uncertainty.

Ledger fixes that binding at construction, provides read-only clock_domain and
rejects changed callable/domain before OS read/claim. BOOT inherits that exact
ledger clock with no second-clock argument and rejects replacement. Prepared
journal/snapshots carry diagnostic clock metadata. QPC raw read/write brackets
are separated from unknown measured intervals. Availability/sample/current
uncertainty remains unknown; a QPC empty-read bracket cannot manufacture a
claimable board envelope. Original same-domain ACK raw ordering is diagnostic
only, with authentication/motion_authorized false.

After actual os.read returns, raw chunk/offset/read and byte budgets are saved
before the trailing stamp. Stamp exception or regression preserves those bytes,
end=None and permanently failed state; no next read/claim. BOOT reserves its
attempt before any stamp, and preserves durable fsynced started_unknown before
the only os.write. Post-write stamp failure retains returned count and unknown
end, with no retry; marker or before-write stamp failure also cannot reenter a
new write. Raw read/write brackets are never UART completion, ADC/source or
measured arrival intervals. raw-preservation-readback.json independently reads
the frozen pipe snapshots (32 post-read bytes and 41 post-write bytes).

The same exact object passes trusted-main create_authority to ActorComposition,
ActorRegistry, original HANDLE Wait stamps, runtime, progress/candidate clock
domain. None preserves original legacy defaults. The production channel function
still unconditionally raises before registry construction and acquisition;
host_clock is clock routing, not provider injection or gate authorization.

Sixteen dependency files equal base bytes: published mailbox v2/candidate owner,
runtime/executor/actor_lifetime/watchdog/wire/profile and construction fixtures.
The four C-protected files match their original pinned hashes. Static AST checks
confirm entire ActorOwner and registry launch, ProgressGate, Dependencies, entry
guard, accept_boot/command/completion, step and actual _progress_time are
unchanged; the production gate body is unchanged. Original v2 W=10 ms,
O/F/P/grant-index, ready bound, all original deadlines, once-consumption and final
callback-to-CAS remain intact. No additional call is inserted there. These static
checks do not substitute for runtime/physical acceptance.

## New focused verification actually run

Final command from ROOT:
`$env:PYTHONDONTWRITEBYTECODE='1'; & .local/venv/Scripts/python.exe -X utf8 .planning/deepeye-resume-20261018/host-clock-qpc-v1-20261024/verify_focused.py`

Final result: **21 new methods, 6 subtests, zero failures/errors**. The runner
asserts every executed ID is in the two new test_host_clock_qpc_v1 modules.
It executes no old TestCase, old 11/16/25/9 group, PDE, 384 board test or producer
exhaustive suite. Existing setUp/construction helpers only provide upstream and
native fixtures. Private fixed-leaf fault injection is explicitly a seam;
production never accepts an arbitrary callable. Actual OS pipe reads/writes
and BOOT journals are retained under raw-controls/. No actual native actor,
approved model, source provider or board was run. Composition/mailbox/runtime,
numerical full geometry, original lifetime algorithm and executor CAS remain
real software around those seams.

The 14 integration methods cover fixed binding/sample/domain metadata, unknown
uncertainty, wrong capability/no fallback, strict bad values/regression/foreign
thread, caller callable refusal/legacy, actual pipe brackets and unknown
availability, post-read exception/regression retaining bytes, changed domain or
callable refusing before read, BOOT exact inheritance and actual once-write,
post-write failure/count/started_unknown, marker and before-write stamp failures,
second binding refusal and diagnostic ACK ordering without availability promotion.

Seven composition methods cover exact same binding through registry/HANDLE/
progress/candidate/runtime and positive v2 S+1ns pose CAS, second binding original
completion refusal, actual slot-verifier refresh reaching E, original progress
deadline at final fence, exact original HANDLE probe-budget refusal, callable
rejection and unconditional production gate before acquisition, and legacy None
defaults. Full uncertainty-aware current/lifetime/epoch adaptation is not part
of this raw-source increment; no scalar deadline was changed to imply it exists.

Initial red.log is an expected missing-binding API assertion before implementation.
mixing-red.log is a genuine continuity counterexample before the ledger guard:
changed private domain reached the OS read seam and did not mark failed. The
guard was then added; no actual read occurred in that rejection counterexample.
All intermediate and final new-suite logs are preserved. The first integration
10-method and composition 7-method runs passed; a later combined 20-method run
passed, and final 21-method/raw-artifact run passed. No old suite replay or
relaxed gate was used to obtain GREEN. Previous monotonic miss remains unchanged
in its original v2 evidence folder and was not rerun.

The runner normalized only nine owned product files, then explicitly checked
each (including four new/untracked product files) has LF line endings, exactly
one terminal LF and no trailing spaces/tabs; AST parse and owned git diff --check
also passed. C-protected/unowned files were never normalized. Raw logs/journals
are retained as generated. Source hashes were re-read after tests and before
freezing, and source-snapshot/ retains all nine exact final bytes.

## One new actual QPC pure-policy observation

Operation A-HOST-CLOCK-QPC-V1-OBSERVE-20261024-01; new run
qpc-new-run-94d1da993a114d678f9c7e9c7dbd7914; QPC diagnostic domain_id
bd44c4fbdcf8421290fcf7c6a9e19f38. Exactly one fixed origin 131587083635100 ns,
S 131587293635100, E 131587303635100; actual raw now 131587293900700.
One ordinary requested sleep of 0.2074441 s returned **265600 ns after S**;
one v2 consumption succeeded. Ready was 131587100223600 and original D was
131588584134200. W stayed 10 ms. Raw qpc-once.json/log and script are retained.
The script refuses an existing result before creating a clock. There was no
retry-to-pass, second old-monotonic trial, origin reset, clock freeze, W change
or deadline extension.

This success establishes only this local raw-QPC/ordinary-wakeup software
attempt. read_sample/timestamp interval and uncertainty remain None. Synthetic
source/completion/transfer/slot records are used only for pure-policy exercise.
No PL/model/motion evidence, scheduling bound or physical deadline guarantee is
established. Cross-process original QPC correspondence and directed uncertainty
adaptation at source/lifetime/current boundaries remain root-owned future work;
no metadata, string, one-shot observation or epoch-offset conversion supplies it.

## Exact nine final source pins

| Product-relative file | SHA256 |
|---|---|
| `competition/deepeye/integration/host_clock.py` | `091accae52c376d259d0057f7b93b23dc5f4143508025beec88394c4b657e376` |
| `competition/deepeye/integration/live_board_receipts.py` | `45879bc7fbe95705b4836d5cadfabc996a80c819e52a50299c2573b7e9b85446` |
| `competition/deepeye/integration/boot_transcript.py` | `01673cb2caf6700e3a15ac38de622cbf5fa927f7dcc85e8666d41ce96e9f6342` |
| `competition/deepeye/simulation/isolation/actor_owner.py` | `cb3f8319627fbbf94ce3d250173d97f7e6f1ea09b5bf5fd530c741d4e5f857b9` |
| `competition/deepeye/simulation/authority/actor_composition.py` | `d02e81b48a10e7d6e128a58bfed35e43a274568cdb602d7024012eeb15d19227` |
| `competition/deepeye/integration/test_host_clock_qpc_v1.py` | `c9a514089c8b6c3a140c03dd60a1fcbe942d55b44ffc2e5e3e1d73a9eb799687` |
| `competition/deepeye/tests/simulation/test_host_clock_qpc_v1.py` | `7ed076416b83a6f4cba50e045354605a9ffb531bffb935e8c02ad56cd9f58631` |
| `competition/deepeye/docs/host_clock_qpc_v1.md` | `bda8e5cbb09f84a4e9c2156ad98fdabfcea9ddd39df36efbf3c9b9c4a887a629` |
| `competition/deepeye/docs/actor_composition.md` | `7cf201a1d333bffa81bd87a72376919e8739a07edb06941e07b2879e9cc5494b` |

source-pins.json also records exact base/dependency/C-protected hashes and
unchanged-gate AST checks. artifact-manifest.json freezes non-secret raw controls,
journals, scripts, report/result and source copies. lease.private.json is excluded
and must not be published. To avoid circular hashing, manifest itself, freeze.json
and post-freeze native completion request/receipt are excluded. freeze.json
re-reads every manifest member before native completion.

G03=not_run, R03=not_run, all29=not_run; H09, full H12 paths, useful AI,
production and formal acceptance remain unestablished. Final acceptance belongs
to root; this child reports evidence only.
