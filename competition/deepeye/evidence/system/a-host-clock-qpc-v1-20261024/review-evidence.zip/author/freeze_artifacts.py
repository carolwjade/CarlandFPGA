"""Freeze this job's exact files and raw evidence; no tests or observation replay."""
import hashlib
import json
from pathlib import Path
import shutil

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PRODUCT=ROOT/'.local/deepeye-implementation-a'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path): return json.loads((OUT/path).read_text(encoding='utf-8'))
def save(path,value):
 (OUT/path).write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
pins=read('source-pins.json'); focused=read('focused-result.json'); observation=read('qpc-once.json')
assert focused['success'] and focused['tests_run']==21 and observation['attempts']==1
for path,value in pins['source'].items(): assert sha((PRODUCT/path).read_bytes())==value['sha256']
for path,value in pins['protected_files'].items(): assert sha((PRODUCT/path).read_bytes())==value
for path in pins['owned_files']:
 raw=(PRODUCT/path).read_bytes()
 assert raw.endswith(b'\n') and not raw.endswith(b'\n\n') and b'\r' not in raw
 assert all(not line.endswith((b' ',b'\t')) for line in raw.splitlines())
 destination=OUT/'source-snapshot'/path
 destination.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(PRODUCT/path,destination)
 assert sha(destination.read_bytes())==pins['source'][path]['sha256']

post_read=read('raw-controls/QpcHostClockTests/test_post_read_stamp_failure_preserves_chunk_offsets_budget_and_no_extra_read/ledger-0.json')
post_write=read('raw-controls/QpcBootClockTests/test_post_write_stamp_failure_keeps_count_started_unknown_and_once_write/sender-0.json')
assert post_read['failed'] and post_read['bytes_read']==len(bytes.fromhex(post_read['reads'][0]['raw_hex']))
assert post_read['reads'][0]['raw_read_call_bracket_ns']==[100,None]
assert post_read['reads'][0]['read_call_interval_ns'] is None
assert post_write['clock_failed'] and post_write['attempt']['bytes_written']==post_write['attempt']['requested_bytes']
assert post_write['attempt']['raw_write_call_bracket_ns']==[101,None]
assert post_write['attempt']['write_call_interval_ns'] is None
save('raw-preservation-readback.json',dict(post_read_failed=True,post_read_bytes=post_read['bytes_read'],
 post_read_unknown_end=True,post_write_bytes=post_write['attempt']['bytes_written'],
 post_write_unknown_end=True,retries_not_permitted=True,scope='actual pipe I/O; trailing-clock failures use private fixed-leaf seams'))

result=dict(schema=1,status='raw_qpc_routing_implemented_focused_controls_passed',
 task_id='DEEPEYE-IMPLEMENTATION-20261014',task_version=1,
 work_id='A-HOST-CLOCK-QPC-V1-IMPLEMENT-20261024-v1',
 job_id='child-3ec73af1c38b4a1cb7fd8f2d9205e535',agent_id='/root/pc_direct_window',
 director='01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3',
 base_commit=pins['base_commit'],head_readback=pins['head_readback'],
 requirements_sha256=pins['requirements_sha256'],H01_H15_preserved=True,
 source_files={path:pins['source'][path] for path in pins['owned_files']},
 focused_tests=dict(methods=21,subtests=len(focused['subtests']),failures=0,errors=0,
                   old_test_cases_executed=0,old_suites_PDE_384=False),
 qpc_observation=dict(operation_id=observation['operation_id'],run_id=observation['run_id'],
   attempts=1,consumed=observation['consumed'],wake_lateness_ns=observation['wake_lateness_ns'],
   measured_uncertainty_or_scheduling_bound=False,PL_model_motion=False),
 preserved=dict(published_v2=True,original_all_deadlines=True,HANDLE_sampling=True,
  original_ProgressGate_owner_once_consume_and_final_fence_CAS=True,
  production_unconditionally_closed=True,C_four_bytes=True,legacy_default=True),
 timestamp_uncertainty=None,measured_current_availability_source_intervals=None,
 source_pins_sha256=sha((OUT/'source-pins.json').read_bytes()),
 focused_result_sha256=sha((OUT/'focused-result.json').read_bytes()),
 qpc_once_sha256=sha((OUT/'qpc-once.json').read_bytes()),
 G03='not_run',R03='not_run',all29='not_run',formal_acceptance=False,
 raw_manifest='artifact-manifest.json',no_stage_commit_board_UI_services_network=True)
save('result.json',result)
table='\n'.join('| `'+path+'` | `'+pins['source'][path]['sha256']+'` |' for path in pins['owned_files'])
report='''# Fresh-run raw QPC implementation

Implemented the root-selected fixed QPC binding and same-object routing, with
unknown timing retained and original I/O facts preserved across clock failure.
This is a software increment for root review, not production/physical acceptance.
Task DEEPEYE-IMPLEMENTATION-20261014/v1; work
A-HOST-CLOCK-QPC-V1-IMPLEMENT-20261024-v1; canonical /root/pc_direct_window.
New job child-3ec73af1c38b4a1cb7fd8f2d9205e535 validated execution_allowed=true;
the completed preceding v2 lease was not reused. Current director transfer is
active Gen3 01a16988-bdcb-70e1-ae10-1304b5cf7875. Exact base / HEAD readback:
17fe7a63652dac6003f3ff6c71abe90eb10c8c87. Published v2 was not overwritten.

Read the selected high-res-clock design and root host-clock-qpc-v1 decision;
retained previously loaded mandatory project/A roles/TDD/verification guidance.
Immutable requirements were recomputed with UTF-8 ensure_ascii=False, sorted keys
and compact separators:
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
DEEPEYE-HUMAN-LOCK-20261014/revision1, H01-H15 and A/root-only board operation
remain unchanged. Only the assigned nine product files and this evidence folder
were written. No stage/commit, additional delegation, physical board/serial, UI,
service, product/peer network, PR or external message operation occurred.

## Implementation and limits

qpc_clock_for_new_run() has no caller callable, now, mode or verified flag. It
checks the fixed time.perf_counter_ns capability is QueryPerformanceCounter,
monotonic and nonadjustable; unsupported capability refuses without fallback.
Exact QpcHostClock is a stable callable/domain object with owner-thread,
strict bounded int/high-water and permanent-failure checks. Its metadata is
read-only and not authentication. read_sample retains raw/domain with interval
None; advertised 100 ns resolution never fills timestamp uncertainty.

Ledger fixes that binding at construction, provides read-only clock_domain and
rejects changed callable/domain before OS read/claim. BOOT inherits that exact
ledger clock with no second-clock argument and rejects replacement. Prepared
journal/snapshots carry diagnostic clock metadata. QPC raw read/write brackets
are separated from unknown measured intervals. Availability/sample/current
uncertainty remains unknown; a QPC empty-read bracket cannot manufacture a
claimable board envelope. Original same-domain ACK raw ordering is diagnostic
only, with authentication/motion_authorized false.

After actual os.read returns, raw chunk/offset/read and byte budgets are saved
before the trailing stamp. Stamp exception or regression preserves those bytes,
end=None and permanently failed state; no next read/claim. BOOT reserves its
attempt before any stamp, and preserves durable fsynced started_unknown before
the only os.write. Post-write stamp failure retains returned count and unknown
end, with no retry; marker or before-write stamp failure also cannot reenter a
new write. Raw read/write brackets are never UART completion, ADC/source or
measured arrival intervals. raw-preservation-readback.json independently reads
the frozen pipe snapshots (32 post-read bytes and 41 post-write bytes).

The same exact object passes trusted-main create_authority to ActorComposition,
ActorRegistry, original HANDLE Wait stamps, runtime, progress/candidate clock
domain. None preserves original legacy defaults. The production channel function
still unconditionally raises before registry construction and acquisition;
host_clock is clock routing, not provider injection or gate authorization.

Sixteen dependency files equal base bytes: published mailbox v2/candidate owner,
runtime/executor/actor_lifetime/watchdog/wire/profile and construction fixtures.
The four C-protected files match their original pinned hashes. Static AST checks
confirm entire ActorOwner and registry launch, ProgressGate, Dependencies, entry
guard, accept_boot/command/completion, step and actual _progress_time are
unchanged; the production gate body is unchanged. Original v2 W=10 ms,
O/F/P/grant-index, ready bound, all original deadlines, once-consumption and final
callback-to-CAS remain intact. No additional call is inserted there. These static
checks do not substitute for runtime/physical acceptance.

## New focused verification actually run

Final command from ROOT:
`$env:PYTHONDONTWRITEBYTECODE='1'; & .local/venv/Scripts/python.exe -X utf8 .planning/deepeye-resume-20261018/host-clock-qpc-v1-20261024/verify_focused.py`

Final result: **21 new methods, 6 subtests, zero failures/errors**. The runner
asserts every executed ID is in the two new test_host_clock_qpc_v1 modules.
It executes no old TestCase, old 11/16/25/9 group, PDE, 384 board test or producer
exhaustive suite. Existing setUp/construction helpers only provide upstream and
native fixtures. Private fixed-leaf fault injection is explicitly a seam;
production never accepts an arbitrary callable. Actual OS pipe reads/writes
and BOOT journals are retained under raw-controls/. No actual native actor,
approved model, source provider or board was run. Composition/mailbox/runtime,
numerical full geometry, original lifetime algorithm and executor CAS remain
real software around those seams.

The 14 integration methods cover fixed binding/sample/domain metadata, unknown
uncertainty, wrong capability/no fallback, strict bad values/regression/foreign
thread, caller callable refusal/legacy, actual pipe brackets and unknown
availability, post-read exception/regression retaining bytes, changed domain or
callable refusing before read, BOOT exact inheritance and actual once-write,
post-write failure/count/started_unknown, marker and before-write stamp failures,
second binding refusal and diagnostic ACK ordering without availability promotion.

Seven composition methods cover exact same binding through registry/HANDLE/
progress/candidate/runtime and positive v2 S+1ns pose CAS, second binding original
completion refusal, actual slot-verifier refresh reaching E, original progress
deadline at final fence, exact original HANDLE probe-budget refusal, callable
rejection and unconditional production gate before acquisition, and legacy None
defaults. Full uncertainty-aware current/lifetime/epoch adaptation is not part
of this raw-source increment; no scalar deadline was changed to imply it exists.

Initial red.log is an expected missing-binding API assertion before implementation.
mixing-red.log is a genuine continuity counterexample before the ledger guard:
changed private domain reached the OS read seam and did not mark failed. The
guard was then added; no actual read occurred in that rejection counterexample.
All intermediate and final new-suite logs are preserved. The first integration
10-method and composition 7-method runs passed; a later combined 20-method run
passed, and final 21-method/raw-artifact run passed. No old suite replay or
relaxed gate was used to obtain GREEN. Previous monotonic miss remains unchanged
in its original v2 evidence folder and was not rerun.

The runner normalized only nine owned product files, then explicitly checked
each (including four new/untracked product files) has LF line endings, exactly
one terminal LF and no trailing spaces/tabs; AST parse and owned git diff --check
also passed. C-protected/unowned files were never normalized. Raw logs/journals
are retained as generated. Source hashes were re-read after tests and before
freezing, and source-snapshot/ retains all nine exact final bytes.

## One new actual QPC pure-policy observation

Operation A-HOST-CLOCK-QPC-V1-OBSERVE-20261024-01; new run
qpc-new-run-94d1da993a114d678f9c7e9c7dbd7914; QPC diagnostic domain_id
bd44c4fbdcf8421290fcf7c6a9e19f38. Exactly one fixed origin 131587083635100 ns,
S 131587293635100, E 131587303635100; actual raw now 131587293900700.
One ordinary requested sleep of 0.2074441 s returned **265600 ns after S**;
one v2 consumption succeeded. Ready was 131587100223600 and original D was
131588584134200. W stayed 10 ms. Raw qpc-once.json/log and script are retained.
The script refuses an existing result before creating a clock. There was no
retry-to-pass, second old-monotonic trial, origin reset, clock freeze, W change
or deadline extension.

This success establishes only this local raw-QPC/ordinary-wakeup software
attempt. read_sample/timestamp interval and uncertainty remain None. Synthetic
source/completion/transfer/slot records are used only for pure-policy exercise.
No PL/model/motion evidence, scheduling bound or physical deadline guarantee is
established. Cross-process original QPC correspondence and directed uncertainty
adaptation at source/lifetime/current boundaries remain root-owned future work;
no metadata, string, one-shot observation or epoch-offset conversion supplies it.

## Exact nine final source pins

| Product-relative file | SHA256 |
|---|---|
'''+table+'''

source-pins.json also records exact base/dependency/C-protected hashes and
unchanged-gate AST checks. artifact-manifest.json freezes non-secret raw controls,
journals, scripts, report/result and source copies. lease.private.json is excluded
and must not be published. To avoid circular hashing, manifest itself, freeze.json
and post-freeze native completion request/receipt are excluded. freeze.json
re-reads every manifest member before native completion.

G03=not_run, R03=not_run, all29=not_run; H09, full H12 paths, useful AI,
production and formal acceptance remain unestablished. Final acceptance belongs
to root; this child reports evidence only.
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
excluded={'lease.private.json','artifact-manifest.json','freeze.json',
          'native-complete-request.json','native-complete-receipt.json'}
files={path.relative_to(OUT).as_posix():dict(bytes=path.stat().st_size,sha256=sha(path.read_bytes()))
       for path in sorted(OUT.rglob('*')) if path.is_file() and path.name not in excluded}
save('artifact-manifest.json',dict(schema=1,files=files,excluded=sorted(excluded),lease_private_publish=False))
assert all((OUT/path).stat().st_size==value['bytes'] and sha((OUT/path).read_bytes())==value['sha256']
           for path,value in files.items())
freeze=dict(schema=1,frozen=True,member_count=len(files),all_members_readback_match=True,
 artifact_manifest_sha256=sha((OUT/'artifact-manifest.json').read_bytes()),
 report_sha256=sha((OUT/'report.md').read_bytes()),result_sha256=sha((OUT/'result.json').read_bytes()),
 source_pins_sha256=sha((OUT/'source-pins.json').read_bytes()),no_product_writes_after_freeze=True)
save('freeze.json',freeze)
print(json.dumps(freeze,sort_keys=True))
