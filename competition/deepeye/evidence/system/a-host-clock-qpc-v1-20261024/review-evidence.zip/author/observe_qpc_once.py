"""Exactly one new actual-QPC policy observation, without motion or timing claims."""
import json
from pathlib import Path
import sys
import time
import uuid

OUT=Path(__file__).resolve().parent
if (OUT/'qpc-once.json').exists():
    raise RuntimeError('original single-shot result exists; refuse replay before acquiring clock')
ROOT=OUT.parents[2]
PRODUCT=ROOT/'.local/deepeye-implementation-a'
sys.path[:0]=[str(PRODUCT),str(ROOT/'.local/deepeye-host-deps'),
              str(PRODUCT/'competition/deepeye/integration')]
from competition.deepeye.integration import host_clock, candidate_mailbox as m, boot_profile as boot
from test_host_envelope import encode,CONTEXT,telem_document,candidate_document

operation='A-HOST-CLOCK-QPC-V1-OBSERVE-20261024-01'
run='qpc-new-run-'+uuid.uuid4().hex
binding=host_clock.qpc_clock_for_new_run()
document=boot.load_document(PRODUCT/'competition/deepeye/docs/boot_profiles.json')
context=dict(CONTEXT,topology_id=2,boot_sha256=boot.canonical_sha256(document).hex())
owner,source=m.LatestCompletedMailbox(document),object()
origin=binding()  # Exactly one fixed origin; no later reset.
owner.activate(encode(context),generation=1,slot_origin_ns=origin,source=source,
    clock_domain=binding,bounds=m.TransferBounds(10_000_000,5_000_000),
    now_ns=binding(),pc_direct_window_v2=m.PcDirectWindowV2(10_000_000))
sample=binding()
owner.observe(encode(telem_document(context=context,count=50,seq=9,tick=9,
    receipt=dict(lower_ns=sample,upper_ns=sample),
    adc_last=dict(lower_ns=sample,upper_ns=sample))),sample_lower_ns=sample,now_ns=binding())
dispatch,lower=binding(),binding()
candidate=encode(candidate_document(context=context,candidate_id=1,
    observation=dict(context=context,observed_seq=9),completed=lower))
upper=binding()
deadline=lower+2_000_000_000
owner.complete(m.Completion(1,source,binding,candidate,1,dispatch,lower,upper,deadline),now_ns=binding())
start,close=origin+210_000_000,origin+220_000_000
before_wait=binding()
delay=max(0,(start-before_wait)/1_000_000_000)
time.sleep(delay)  # One ordinary bounded wait only.
actual=binding()
selected=owner.consume_pc_direct_v2(actual,grant=m.SlotGrant(1,0))  # One consume attempt only.
result=dict(schema=1,operation_id=operation,run_id=run,attempts=1,
    clock_metadata=dict(binding.metadata),timestamp_interval_ns=None,
    origin_ns=origin,nominal_slot_ns=start,window_close_ns=close,
    ready_ns=upper+15_000_000,original_deadline_ns=min(deadline,sample+1_500_000_000),
    policy_width_ns=10_000_000,requested_wait_seconds=delay,before_wait_ns=before_wait,
    actual_now_ns=actual,wake_lateness_ns=actual-start,consumed=selected is not None,
    consumed_at_ns=None if selected is None else selected.consumed_at_ns,
    snapshot=owner.snapshot(),upstream='synthetic source/completion/transfer/slot',
    raw_current_is_not_measured_interval=True,native_model_board=False,
    measured_scheduler_or_timestamp_uncertainty=False,G03='not_run',R03='not_run',all29='not_run')
(OUT/'qpc-once.json').write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,sort_keys=True))
