"""One selected isolated installation/probe stage, with offline/write audit."""
from datetime import datetime,timezone
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import runpy
import site
import struct
import sys
import time
import traceback
D=Path(__file__).resolve().parent
P=json.loads((D/'prepared.json').read_bytes())
STAGE=Path(P['stage'])
ACTION=sys.argv[1]
Q=D/'evidence'/ACTION
def pin(p):
    p=Path(p)
    with p.open('rb') as f: h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':p.stat().st_size,'sha256':h}
def save(name,value):
    with (Q/name).open('x',encoding='utf-8',newline='\n') as f: json.dump(value,f,indent=2,ensure_ascii=False)
assert sys.implementation.name=='cpython' and sys.version_info[:2]==(3,12) and struct.calcsize('P')==8
assert pin(sys._base_executable)==P['base_executable_pin']
if ACTION!='venv':
    # CPython3.12 establishes venv prefixes in site.py. -S deliberately avoids
    # installed .pth execution before the selected probe, so restore only the
    # exact selected environment prefix and verify the resulting install paths.
    assert Path(sys.executable).resolve()==STAGE/'Scripts/python.exe'
    assert (STAGE/'pyvenv.cfg').is_file()
    sys.prefix=sys.exec_prefix=str(STAGE)
    import sysconfig
    paths=sysconfig.get_paths()
    assert Path(paths['purelib']).resolve()==STAGE/'Lib/site-packages'
    assert Path(paths['scripts']).resolve()==STAGE/'Scripts'
events=[]
local_events=[]
def writable(p):
    if isinstance(p,int): return True
    p=Path(p).resolve()
    return p.is_relative_to(STAGE) or p.is_relative_to(Q) or str(p).casefold()=='nul'
def audit(event,args):
    if event in {'socket.connect','socket.connect_ex','socket.sendto','socket.gethostbyname','socket.gethostbyaddr','socket.getaddrinfo'}:
        events.append(event)
        raise RuntimeError('offline stage forbids network/DNS')
    if event=='socket.gethostname':
        assert len(local_events)<4
        local_events.append('local hostname')
    if event=='socket.bind':
        target=args[1]
        if not (isinstance(target,tuple) and target[0] in ('::1','127.0.0.1','localhost') and target[1]==0):
            events.append(event)
            raise RuntimeError('only local capability probe bind is allowed')
        local_events.append('loopback capability bind')
    if event=='open' and not isinstance(args[0],int):
        mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writing and not writable(args[0]):
            events.append('outside write')
            raise RuntimeError('write outside new stage/evidence')
    if event in ('os.mkdir','os.remove','os.rmdir','os.chmod','os.utime','os.truncate'):
        if not writable(args[0]):
            events.append(event)
            raise RuntimeError('mutation outside new stage')
    if event in ('os.rename','os.replace'):
        if not all(writable(p) for p in args[:2]):
            events.append(event)
            raise RuntimeError('rename outside new stage')
    if event in ('os.symlink','os.link','os.startfile','os.startfile/2','os.system'):
        events.append(event)
        raise RuntimeError('unselected side effect')
sys.addaudithook(audit)
save('ready.json',{'pid':os.getpid(),'base_executable':sys._base_executable,'prefix':sys.prefix})
deadline=time.monotonic()+15
while not (Q/'release.json').exists():
    assert time.monotonic()<deadline
    time.sleep(.02)
image=json.loads((Q/'release.json').read_bytes())
assert image['pid']==os.getpid() and image['image_sha256']==P['base_executable_pin']['sha256']
outcome={'action':ACTION,'status':'failed','started_utc':datetime.now(timezone.utc).isoformat(),
    'python':{'pid':os.getpid(),'ppid':os.getppid(),'prefix':sys.prefix,'version':sys.version,
        'base_executable':sys._base_executable,'isolated':sys.flags.isolated,'no_site':sys.flags.no_site},
    'independent_live_image':image}
def pip_run(arguments,bootstrap=False):
    if bootstrap: sys.path.insert(0,P['ensurepip_wheel'])
    else: sys.path.insert(0,str(STAGE/'Lib/site-packages'))
    sys.argv=['pip','--isolated','--disable-pip-version-check',*arguments]
    try: runpy.run_module('pip',run_name='__main__')
    except SystemExit as e:
        assert e.code in (None,0),f'pip actual exit {e.code}'
try:
    if ACTION=='venv':
        import venv
        assert not STAGE.exists()
        venv.EnvBuilder(with_pip=False,symlinks=False).create(STAGE)
        for name in ('wheelhouse','tmp','cache','userhome','appdata','localappdata','logs'):
            (STAGE/name).mkdir()
        outcome['stage_created_fresh']=True
    elif ACTION=='copy':
        copied=[]
        for n in P['artifacts']:
            src=Path(n['source_path'])
            target=Path(n['wheelhouse_path'])
            h,size=hashlib.sha256(),0
            with src.open('rb') as f,target.open('xb') as g:
                for b in iter(lambda:f.read(128*1024),b''):
                    h.update(b)
                    size+=len(b)
                    assert size<=n['bytes']
                    g.write(b)
                g.flush()
                os.fsync(g.fileno())
            assert {'bytes':size,'sha256':h.hexdigest()}=={k:n[k] for k in ('bytes','sha256')}
            copied.append({'name':n['name'],'source':str(src),'target':str(target),'bytes':size,'sha256':h.hexdigest()})
        outcome['copied']=copied
    elif ACTION=='bootstrap':
        pip_run(['install','--no-index','--find-links',str(Path(P['ensurepip_wheel']).parent),'--no-deps',
            '--require-hashes','--no-cache-dir','--only-binary=:all:','--no-compile','-r',str(D/'bootstrap.lock')],True)
        sys.path.insert(0,str(STAGE/'Lib/site-packages'))
        assert metadata.version('pip')=='25.0.1'
        outcome['pip_version']=metadata.version('pip')
        outcome['bootstrap_source']='current bundled ensurepip pip25.0.1 wheel, local offline hashed install'
    elif ACTION=='install':
        pip_run(['install','--no-index','--find-links',str(STAGE/'wheelhouse'),'--require-hashes','--no-cache-dir',
            '--only-binary=:all:','--no-compile','--report',str(Q/'install-report.json'),'-r',str(D/'requirements.lock')])
        outcome['install_report']=pin(Q/'install-report.json')
    elif ACTION=='check':
        pip_run(['check'])
        from pip._vendor.packaging.requirements import Requirement
        from pip._vendor.packaging.markers import default_environment
        from pip._vendor.packaging.utils import canonicalize_name
        expected={n['name']:n for n in P['artifacts']}
        installed={canonicalize_name(d.metadata['Name']):d for d in metadata.distributions(path=[str(STAGE/'Lib/site-packages')])}
        assert set(installed)==set(expected)|{'pip'},'installed distribution set differs from exact lock plus bootstrap pip'
        rows=[]
        def normalized(raw):
            r=Requirement(raw)
            return canonicalize_name(r.name),str(r.specifier),tuple(sorted(r.extras)),str(r.marker)
        for name,n in expected.items():
            dist=installed[name]
            assert dist.version==n['version']
            assert sorted(normalized(r) for r in (dist.requires or []))==sorted(normalized(r) for r in n['requires_dist']),name+' Requires-Dist changed'
            rows.append({'name':name,'version':dist.version,'metadata_sha256':hashlib.sha256(dist.read_text('METADATA').encode()).hexdigest(),
                'requires_dist':dist.requires or []})
        active={'torch':{'device-gfx1103'},'rocm':{'libraries','device-gfx1103'}}
        environment=default_environment()
        changed=True
        while changed:
            changed=False
            for name,extras in list(active.items()):
                for raw in installed[name].requires or []:
                    r=Requirement(raw)
                    if r.marker and not any(r.marker.evaluate({**environment,'extra':e}) for e in {''}|extras): continue
                    target=canonicalize_name(r.name)
                    assert target in expected and installed[target].version in r.specifier,raw
                    previous=active.get(target)
                    value=(previous or set())|set(r.extras)
                    if previous is None or previous!=value:
                        active[target]=value
                        changed=True
        assert set(active)==set(expected),'actual current-runtime marker/root-extra closure differs'
        report=json.loads((D/'evidence/install/install-report.json').read_bytes())
        reported={canonicalize_name(r['metadata']['name']):r for r in report['install']}
        assert set(reported)==set(expected)
        for name,r in reported.items():
            assert r['metadata']['version']==expected[name]['version']
            assert r['download_info']['archive_info']['hashes']['sha256']==expected[name]['sha256']
        outcome.update(pip_check='passed',installed_metadata=rows,root_extra_closure={k:sorted(v) for k,v in active.items()},
            marker_environment=environment,install_report_all_17_hashes_match=True)
    elif ACTION=='probe':
        site.addsitedir(str(STAGE/'Lib/site-packages'))
        assert metadata.version('torch')=='2.12.0+rocm7.14.1' and metadata.version('rocm')=='7.14.1'
        import torch
        outcome['torch']={'version':torch.__version__,'file':str(torch.__file__),'hip':torch.version.hip,'cuda':torch.version.cuda}
        assert Path(torch.__file__).resolve().is_relative_to(STAGE)
        assert str(torch.version.hip).startswith('7.14') and torch.version.cuda is None,'not selected HIP build'
        outcome['available']=torch.cuda.is_available()
        rows=[]
        for i in range(torch.cuda.device_count()):
            p=torch.cuda.get_device_properties(i)
            rows.append({'index':i,'name':p.name,'gcnArchName':getattr(p,'gcnArchName',None),'total_memory':p.total_memory})
        outcome['devices']=rows
        assert outcome['available'] and rows,'actual HIP device unavailable'
        assert all('NVIDIA' not in r['name'].upper() for r in rows)
        selected=[r for r in rows if ('AMD' in r['name'].upper() or 'RADEON' in r['name'].upper()) and str(r['gcnArchName']).split(':')[0]=='gfx1103']
        assert len(selected)==1,'missing or ambiguous real AMD gfx1103'
        device=torch.device('cuda',selected[0]['index'])
        left=[[1.,2.,3.,4.],[5.,6.,7.,8.],[9.,10.,11.,12.],[13.,14.,15.,16.]]
        right=[[1.,0.,0.,0.],[0.,2.,0.,0.],[0.,0.,3.,0.],[0.,0.,0.,4.]]
        expected=[[1.,4.,9.,16.],[5.,12.,21.,32.],[9.,20.,33.,48.],[13.,28.,45.,64.]]
        a=torch.tensor(left,dtype=torch.float32,device=device)
        b=torch.tensor(right,dtype=torch.float32,device=device)
        value=torch.matmul(a,b)
        torch.cuda.synchronize(device)
        actual=value.cpu().tolist()
        outcome['kernel']={'operation':'one FP32 4x4 matmul','device':str(device),'actual':actual,'expected_literal':expected,
            'sync_calls':1,'matmul_calls':1,'matches':actual==expected}
        assert actual==expected
        outcome['experimental_current_driver_probe']='passed; not official 8845H support or project CNN'
    else: raise AssertionError('unselected action')
    assert not events
    outcome['status']='success'
except BaseException:
    outcome['error']=traceback.format_exc()
    traceback.print_exc()
finally:
    outcome.update(ended_utc=datetime.now(timezone.utc).isoformat(),prohibited_attempts=events,local_capability_events=local_events,
        project_CNN='external_dependency_not_run',R02='not_run',C03='not_run',all29='not_run')
    save('worker-result.json',outcome)
print(json.dumps({'action':ACTION,'status':outcome['status'],'error':outcome.get('error')}),flush=True)
raise SystemExit(0 if outcome['status']=='success' else 1)
