"""Exact 17-artifact installation lock and current-runtime command freeze."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys
from urllib.parse import unquote,urlsplit
D=Path(__file__).resolve().parent
B=D.parent
ROOT=D.parents[2]
def pin(p):
    p=Path(p)
    with p.open('rb') as f: h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':p.stat().st_size,'sha256':h}
def load(p): return json.loads(Path(p).read_bytes())
def save(name,value):
    with (D/name).open('x',encoding='utf-8',newline='\n') as f: json.dump(value,f,indent=2,ensure_ascii=False)
a=load(D/'assignment.json')
assert pin(D/'design-plan.md')['sha256']==a['design_sha256']=='7f0c8e19937d6b935a621bea2d7592739d535686d7372fd405071dfdcd55edca'
assert a['new_install_selected'] and a['one_backend_probe_selected'] and not a['product_activation']
stage=Path(a['stage'])
assert not stage.exists() and stage==ROOT/'.local/deepeye-rocm-7.14.1-cp312-gfx1103'
contract=load(ROOT/'docs/competition/deepeye-2026/immutable_scope.json')
assert hashlib.sha256(json.dumps(contract['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==a['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
transfer=load(ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json')
assert transfer['status']=='active' and transfer['director_generation']==2 and transfer['new_director_thread_id']==a['selected_by']
graphpath=B/'r02-static-dependency-closure-20261020/dependency-graph.json'
graph=load(graphpath)
nodes={n['name']:n for n in graph['nodes']}
continuation=load(B/'r02-wheel-postrun-independent-20261021/audit-02/dependency-continuation-data.json')
expanded_sizes={r['name']:r['declared_uncompressed_bytes'] for r in continuation['expanded_size_components']}
lock=load(B/'r02-static-dependency-closure-20261020/runtime-lock.provisional.json')
locknodes={n['name']:n for n in lock['nodes']}
refs=load(B/'r02-remaining-amd-20261021/summary.json')
artifacts={n['name']:n for n in refs['existing_complete_references']}
artifacts.update({n['name']:n['artifact'] for n in refs['new_complete']})
assert len(artifacts)==17 and set(artifacts)==set(nodes)==set(locknodes)
selected=[]
for name in sorted(nodes):
    meta=nodes[name]
    r=artifacts[name]
    source=Path(r['path'])
    filename=source.name if name=='rocm' else unquote(urlsplit(locknodes[name]['artifact_url']).path.rsplit('/',1)[1])
    assert filename.endswith('.whl') and filename.isascii() and '/' not in filename and '\\' not in filename
    assert source.is_file() and source.stat().st_size==r['bytes']
    selected.append({'name':name,'version':meta['version'],'source_path':str(source),'filename':filename,
        'bytes':r['bytes'],'sha256':r['sha256'],'wheelhouse_path':str(stage/'wheelhouse'/filename),
        'published_sha256':locknodes[name].get('published_sha256'),
        'hash_origin':'published' if locknodes[name].get('published_sha256') else 'locally observed or locally built complete artifact',
        'requires_dist':meta['requires_dist'],'declared_expanded_bytes':expanded_sizes[name]})
compressed=sum(n['bytes'] for n in selected)
expanded=sum(n['declared_expanded_bytes'] for n in selected)
assert compressed==1348657019 and expanded==3803906104
required=compressed+2*expanded+256*1024**2+10*1024**3
free=shutil.disk_usage(D).free
assert free>=required,'insufficient current disk; preserve all originals'
assert sys.implementation.name=='cpython' and sys.version_info[:2]==(3,12) and struct.calcsize('P')==8
base=Path(sys.base_prefix)
baseexe=Path(sys._base_executable)
assert pin(baseexe)['sha256']=='ceabb31054d429f57cb3825775677eeaf0db35fdabbc5ff6aef661c037154b00'
pipwheel=base/'Lib/ensurepip/_bundled/pip-25.0.1-py3-none-any.whl'
assert pipwheel.is_file() and '_PIP_VERSION = "25.0.1"' in (base/'Lib/ensurepip/__init__.py').read_text()
lines=[]
for n in selected:
    extra='[device-gfx1103]' if n['name']=='torch' else '[libraries,device-gfx1103]' if n['name']=='rocm' else ''
    lines.append(f"{n['name']}{extra}=={n['version']} --hash=sha256:{n['sha256']}")
(D/'requirements.lock').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
(D/'bootstrap.lock').write_text('pip==25.0.1 --hash=sha256:'+pin(pipwheel)['sha256']+'\n',encoding='utf-8',newline='\n')
source=B/'r02-amd-wheel-acquisition-20261021'
oldpins=load(source/'incoming-pins.json')['files']
pins={}
for name in ('win_job.py','boundary.py'):
    p=source/name
    assert pin(p)==oldpins[str(p)]
    pins[str(p)]=pin(p)
for p in (baseexe,base/'python312.dll',base/'DLLs/_socket.pyd',pipwheel,base/'Lib/ensurepip/__init__.py',base/'Lib/venv/__init__.py',
          graphpath,B/'r02-static-dependency-closure-20261020/runtime-lock.provisional.json',
          B/'r02-remaining-amd-20261021/summary.json',ROOT/'docs/competition/deepeye-2026/immutable_scope.json',ROOT/'docs/competition/deepeye-2026/immutable_scope.md',
          ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json',D/'assignment.json',D/'design-plan.md',D/'requirements.lock',D/'bootstrap.lock'):
    pins[str(p)]=pin(p)
for p in D.glob('*.py'):
    ast.parse(p.read_text(encoding='utf-8'))
    pins[str(p)]=pin(p)
venvpy=str(stage/'Scripts/python.exe')
commands={action:[str(baseexe) if action=='venv' else venvpy,'-I','-S','-B','-X','utf8',str(D/'stage_worker.py'),action]
          for action in ('venv','copy','bootstrap','install','check','probe')}
save('prepared.json',{'work_id':a['work_id'],'job_id':'child-c4a6ba1e16ff434d95fa251202522899',
    'stage':str(stage),'stage_absent_before':True,'artifacts':selected,'source_pins':pins,'runner_directory':str(source),
    'base_executable':str(baseexe),'base_executable_pin':pin(baseexe),'python_version':sys.version,'ensurepip_wheel':str(pipwheel),
    'ensurepip_wheel_pin':pin(pipwheel),'pip_version':'25.0.1','commands':commands,
    'space':{'compressed':compressed,'expanded':expanded,'temporary_expansion':expanded,'venv_log_allowance':256*1024**2,
        'reserve':10*1024**3,'required_before_new_stage':required,'actual_free_before':free,
        'stage_byte_cap':compressed+2*expanded+256*1024**2},
    'support_mode':'experimental current driver; not official 8845H support','product_activation':False,
    'source_artifact_hashes_verified_during_copy':True,'old_archive_tests_repeated':False})
print(json.dumps({'status':'frozen','packages':17,'required_bytes':required,'free_bytes':free,'headroom':free-required,'commands':commands}))
