"""Seal cumulative actual evidence without rerunning install/check/probe."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import shutil
D=Path(__file__).resolve().parent
def load(p): return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p)
    with p.open('rb') as f: h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':p.stat().st_size,'sha256':h}
def save(name,value):
    with (D/name).open('x',encoding='utf-8',newline='\n') as f: json.dump(value,f,indent=2,ensure_ascii=False)
p=load(D/'continuation-03/prepared.json')
stage=Path(p['stage'])
original=load(D/'result.json')
c1=load(D/'continuation-01/result.json')
c2=load(D/'continuation-02/result.json')
c3=load(D/'continuation-03/result.json')
copy=load(D/'evidence/copy/worker-result.json')
install=load(D/'continuation-01/evidence/install/worker-result.json')
check=load(D/'continuation-03/evidence/check/worker-result.json')
probe=load(D/'continuation-03/evidence/probe/worker-result.json')
assert copy['status']==install['status']==check['status']==probe['status']=='success'
assert len(copy['copied'])==len(check['installed_metadata'])==len(check['root_extra_closure'])==17
assert check['install_report_all_17_hashes_match'] and 'pip_check_reused_from' in check
assert probe['torch']['cuda'] is None and str(probe['torch']['hip']).startswith('7.14')
assert probe['kernel']['matches'] and probe['kernel']['matmul_calls']==probe['kernel']['sync_calls']==1
assert probe['kernel']['actual']==probe['kernel']['expected_literal']
assert len(probe['devices'])==1 and probe['devices'][0]['gcnArchName']=='gfx1103'
assert not probe['prohibited_attempts']
terminals=[]
for label,r,root in [('original',original,D),('continuation-01',c1,D/'continuation-01'),
                     ('continuation-02',c2,D/'continuation-02'),('continuation-03',c3,D/'continuation-03')]:
    for item in r['stages']:
        t=item['terminal']
        assert t['all_processes_terminated'] is True and t['active_processes_final']==0 and not t['faults']
        assert all(m['signaled'] and m['wait_result']==0 for m in t['held_members'])
        terminals.append({'continuation':label,'action':item['action'],'status':t['status'],'exit_code':t['exit_code'],
            'path':str(root/'runs'/item['action']/'terminal.json'),**pin(root/'runs'/item['action']/'terminal.json'),
            'held_members':len(t['held_members']),'peak_job_memory_bytes':t['peak_job_memory_bytes'],
            'all_original_handles_signaled':True})
for file,expected in p['source_pins'].items(): assert pin(file)==expected,file
summary={'status':'success','work_id':p['work_id'],'job_id':p['job_id'],
    'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    'stage':str(stage),'support_mode':'experimental current driver; not official 8845H support',
    'installation':{'status':'success','packages':17,'pip_version':'25.0.1','lock':pin(D/'requirements.lock'),
        'copied_source_hash_bindings':copy['copied'],'install_report':{'path':str(D/'continuation-01/evidence/install/install-report.json'),
            **pin(D/'continuation-01/evidence/install/install-report.json')},'full_install_attempts':1},
    'pip_check':{'status':'success','actual_stdout':'No broken requirements found.','actual_runs':1,
        'stdout_path':str(D/'continuation-01/runs/check/stdout.txt'),'passed_result_reused':True},
    'metadata_lock_check':{'status':'success','installed_metadata':check['installed_metadata'],
        'metadata_hash_scope':'UTF8 text returned by importlib.metadata; selected rocm byte equality independently recorded',
        'root_extra_closure':check['root_extra_closure'],'marker_environment':check['marker_environment'],
        'all_17_report_artifact_hashes_match':True,
        'rocm_expected_source':load(D/'continuation-02/metadata-source-selection.json')},
    'backend_probe':{'status':'success','actual_runs':1,'torch':probe['torch'],'devices':probe['devices'],
        'kernel':probe['kernel'],'actual_stdout_path':str(D/'continuation-03/runs/probe/stdout.txt'),
        'actual_stderr_path':str(D/'continuation-03/runs/probe/stderr.txt'),
        'warning':'NumPy absent; warning retained, no new NumPy install selected',
        'loaded_HIP_runtime_DLL_and_API_version':'not_collected_in_this_selected_probe',
        'CPU_or_NVIDIA_fallback':False,'architecture_override':False,'prohibited_attempts':probe['prohibited_attempts']},
    'prior_failures_preserved':['pre-worker transient free-space assertion','pip bootstrap Windows argv protection',
        'rocm static-sdist graph expectation mismatch against previously selected built-v6 metadata',
        'metadata-only harness missing selected site-packages search path'],
    'main_selected_repairs_preserve_old_sources_and_pins':True,'terminals':terminals,
    'original_held_handles_signaled':sum(t['held_members'] for t in terminals),'all_original_handles_signaled':True,
    'peak_job_memory_bytes':max(t['peak_job_memory_bytes'] for t in terminals),
    'runtime_binding':{'base_executable':p['base_executable'],'base_pin':p['base_executable_pin'],
        'venv_launcher':pin(stage/'Scripts/python.exe'),'pyvenv_cfg':pin(stage/'pyvenv.cfg')},
    'new_network_requests':0,'old_archive_tests_repeated':False,'old_wheel_function_tests_repeated':False,
    'product_activation':False,'board_operations':0,'project_CNN':'external_dependency_not_run',
    'disk_free_after_bytes':shutil.disk_usage(D).free,'R02':'not_run','C03':'not_run','all29':'not_run',
    'created_utc':datetime.now(timezone.utc).isoformat()}
save('installation-summary.json',summary)
files={str(f.relative_to(D)):pin(f) for f in D.rglob('*') if f.is_file() and 'private' not in f.name.lower()}
save('manifest.json',{'files':files,'stage':str(stage),'stage_artifacts':p['artifacts'],
    'stage_installed_identity_evidence':'17-copy hashes + exact hashed pip report + installed metadata/closure + single real probe',
    'whole_installed_tree_or_old_artifact_tests_repeated':False})
text=('隔离环境已离线安装 17 包，pip 25.0.1、pip check、元数据/根 extras 闭包及安装报告哈希核对通过。\n\n'
      '实际 AMD Radeon 780M（gfx1103）完成一次 FP32 4×4 矩阵乘法并同步，输出逐项等于预期；torch 2.12.0+rocm7.14.1，HIP 构建标记 7.14.60850，CUDA 构建标记为空。\n\n'
      '仅为当前驱动下的实验性小核通过，不代表官方 8845H 支持或项目 CNN 验收。原失败、NumPy 缺失警告均保留；无重装、驱动/产品激活或板卡操作。C 项目 CNN 仍是外部依赖，R02/C03/all29 保持 not_run。\n\n'
      f'[汇总]({D.as_posix()}/installation-summary.json) · [清单]({D.as_posix()}/manifest.json) · [完成回应]({D.as_posix()}/native-complete-response.json)\n')
with (D/'final-result.txt').open('x',encoding='utf-8',newline='\n') as f: f.write(text)
print(json.dumps({'status':'success','summary':pin(D/'installation-summary.json'),'manifest':pin(D/'manifest.json'),
    'final_text':pin(D/'final-result.txt'),'terminals':len(terminals),'held_signaled':summary['original_held_handles_signaled'],
    'peak_job_memory_bytes':summary['peak_job_memory_bytes']}))
