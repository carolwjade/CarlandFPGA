"""Execute frozen new install once, then selected real probe; retain failures."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import traceback
D=Path(__file__).resolve().parent
P=json.loads((D/'prepared.json').read_bytes())
STAGE=Path(P['stage'])
def pin(p):
    p=Path(p)
    with p.open('rb') as f: h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'bytes':p.stat().st_size,'sha256':h}
def load(p): return json.loads(Path(p).read_bytes())
def save(p,value):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f: json.dump(value,f,indent=2,ensure_ascii=False)
def unchanged():
    for p,value in P['source_pins'].items(): assert pin(p)==value,p
unchanged()
space_observation={'utc':datetime.now(timezone.utc).isoformat(),'free_bytes':shutil.disk_usage(D).free,
    'required_bytes':P['space']['required_before_new_stage'],'stage_exists':STAGE.exists(),
    'main_selection':'one new exact observation after earlier pre-worker transient gate failure; no threshold change'}
save(D/'space-gate-main-selected-02.json',space_observation)
assert not space_observation['stage_exists']
assert space_observation['free_bytes']>=space_observation['required_bytes'],'recorded current fresh-stage space insufficient'
sys.path.insert(0,P['runner_directory'])
from win_job import run_bounded,process_identity
from boundary import check_no_links
check_no_links(STAGE,missing_ok=True)
for name in ('evidence','runs'): (D/name).mkdir()
result={'status':'running','work_id':P['work_id'],'job_id':P['job_id'],'prepared':pin(D/'prepared.json'),
    'stages':[],'installation_status':'not_run','pip_check_status':'not_run','backend_probe_status':'not_run',
    'support_mode':P['support_mode'],'project_CNN':'external_dependency_not_run','product_activation':False,
    'started_utc':datetime.now(timezone.utc).isoformat()}
save(D/'started.json',result)
try:
    for action,argv in P['commands'].items():
        unchanged()
        Q=D/'evidence'/action
        Q.mkdir()
        (Q/'tmp').mkdir()
        env={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR')}
        env.update(PATH='',TEMP=str(Q/'tmp'),TMP=str(Q/'tmp'),USERPROFILE=str(STAGE/'userhome'),HOME=str(STAGE/'userhome'),
            APPDATA=str(STAGE/'appdata'),LOCALAPPDATA=str(STAGE/'localappdata'),XDG_CACHE_HOME=str(STAGE/'cache'),
            PIP_CONFIG_FILE='NUL',PIP_NO_INDEX='1',PIP_DISABLE_PIP_VERSION_CHECK='1',PIP_NO_CACHE_DIR='1',
            PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',TORCH_HOME=str(STAGE/'cache/torch'),
            TORCH_EXTENSIONS_DIR=str(STAGE/'cache/torch-extensions'),TRITON_CACHE_DIR=str(STAGE/'cache/triton'),
            HIP_CACHE_PATH=str(STAGE/'cache/hip'),AMD_COMGR_CACHE_DIR=str(STAGE/'cache/comgr'),
            MIOPEN_USER_DB_PATH=str(STAGE/'cache/miopen-db'),MIOPEN_CUSTOM_CACHE_DIR=str(STAGE/'cache/miopen'))
        assert not any('OVERRIDE' in k for k in env)
        budget={'seconds':120 if action=='probe' else 600,'active_processes':4 if action=='probe' else 8,
            'process_memory_bytes':2*1024**3 if action=='probe' else 1024**3,'job_memory_bytes':2*1024**3,
            'stdout_bytes':4*1024**2,'stderr_bytes':4*1024**2,'tree_bytes':P['space']['stage_byte_cap'],
            'tree_entries':50000,'free_reserve_bytes':10*1024**3,
            'components':[{'path':str(STAGE),'bytes':P['space']['stage_byte_cap'],'entries':45000},
                {'path':str(D/'evidence'),'bytes':64*1024**2,'entries':1000},
                {'path':str(D/'runs'),'bytes':64*1024**2,'entries':1000}]}
        save(Q/'command.json',{'argv':argv,'environment':env,'budget':budget})
        print(json.dumps({'event':'stage_started','action':action}),flush=True)
        def on_tick(job,pids):
            ready=Q/'ready.json'
            release=Q/'release.json'
            if ready.exists() and not release.exists():
                identity=load(ready)
                assert identity['pid'] in pids
                actual=process_identity(identity['pid'],job)
                assert Path(actual['image'])==Path(identity['base_executable'])
                assert actual['image_sha256']==P['base_executable_pin']['sha256']
                save(release,actual)
        terminal=run_bounded(argv,env,D,D/'runs'/action,budget,[STAGE,D/'evidence',D/'runs'],on_tick=on_tick)
        assert terminal['all_processes_terminated'] is True and not terminal['faults']
        assert terminal['active_processes_final']==0 and terminal['held_members']
        assert all(m['signaled'] and m['wait_result']==0 for m in terminal['held_members'])
        worker=load(Q/'worker-result.json') if (Q/'worker-result.json').exists() else None
        row={'action':action,'terminal':terminal,'terminal_pin':pin(D/'runs'/action/'terminal.json'),
            'worker_result':worker,'command':pin(Q/'command.json')}
        result['stages'].append(row)
        if worker:
            assert worker['python']['pid'] in [m['pid'] for m in terminal['held_members']]
        if action=='install': result['installation_status']='success' if worker and worker['status']=='success' else 'failed'
        if action=='check': result['pip_check_status']='success' if worker and worker['status']=='success' else 'failed'
        if action=='probe': result['backend_probe_status']='success' if worker and worker['status']=='success' else 'failed'
        print(json.dumps({'event':'stage_ended','action':action,'process_status':terminal['status'],
            'exit':terminal['exit_code'],'worker_status':worker['status'] if worker else 'absent'}),flush=True)
        assert terminal['status']=='success' and terminal['exit_code']==0 and worker and worker['status']=='success',action+' failed; preserve stage; no retry'
        unchanged()
    result['status']='success'
except BaseException:
    result.update(status='failed_stopped',error=traceback.format_exc())
finally:
    result.update(ended_utc=datetime.now(timezone.utc).isoformat(),disk_free_after_bytes=shutil.disk_usage(D).free,
        stage_preserved=True,automatic_reinstalls=0,R02='not_run',C03='not_run',all29='not_run')
    save(D/'result.json',result)
print(json.dumps({'event':'run_ended','status':result['status'],'installation':result['installation_status'],
    'pip_check':result['pip_check_status'],'probe':result['backend_probe_status']}),flush=True)
raise SystemExit(0 if result['status']=='success' else 1)
