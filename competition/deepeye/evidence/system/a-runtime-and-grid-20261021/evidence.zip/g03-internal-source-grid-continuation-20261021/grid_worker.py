"""One granted control or actual L1 process. No loop over candidate meshes."""
import hashlib,json,math,os,sys,time,warnings
from pathlib import Path
D=Path(__file__).resolve().parent
ROOT=D.parents[2]
stage=Path(sys.argv[1]);mode=sys.argv[2]
def save_json(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def save_array(p,x):
    with p.open('xb') as f:
        import numpy as np
        np.save(f,x,allow_pickle=False)
def pair(v):return [[float(complex(x).real),float(complex(x).imag)] for x in v]
save_json(stage/'hello.json',{'pid':os.getpid(),'before_scientific_import':True,'mode':mode})
deadline=time.monotonic()+5
while not (stage/'grant.json').exists():
    if time.monotonic()>deadline:raise RuntimeError('no science grant')
    time.sleep(.01)
grant=json.loads((stage/'grant.json').read_text(encoding='utf-8'))
assert grant['worker']['pid']==os.getpid() and grant['mode']==mode
sys.path.insert(0,str(D))
import numpy as np
from scipy import sparse
import grid_model as m

def threads():
    import ctypes as ct
    import scipy.linalg
    k=ct.WinDLL('kernel32',use_last_error=True)
    k.GetModuleHandleW.argtypes=[ct.c_wchar_p];k.GetModuleHandleW.restype=ct.c_void_p
    site=Path(np.__file__).resolve().parents[1];rows=[]
    for folder,symbol in (('numpy.libs','scipy_openblas_get_num_threads64_'),('scipy.libs','scipy_openblas_get_num_threads')):
        paths=list((site/folder).glob('*openblas*.dll'));assert len(paths)==1
        handle=k.GetModuleHandleW(str(paths[0]));assert handle
        getter=getattr(ct.CDLL(str(paths[0]),handle=handle),symbol)
        getter.argtypes=[];getter.restype=ct.c_int
        count=getter();assert count==1
        rows.append({'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest(),'num_threads':count})
    return rows

started=time.monotonic();before=threads();error=None;counts={}
try:
    mesh=m.mesh_new()
    if mode=='controls':
        # Independent smooth endpoint integration for the exact failed cell.
        from scipy.integrate import quad
        radius=.05;a=float(mesh.nodes_x[6]);delta=radius-a
        c=abs(float(mesh.nodes_y[4]));d=abs(float(mesh.nodes_y[3]))
        if not (0<delta<64*np.finfo(float).eps and c<64*np.finfo(float).eps and d>.02):
            raise ArithmeticError('failed-cell binary geometry changed')
        endpoint,endpoint_error=quad(lambda t:2*delta*t*(math.sqrt(delta*t*t*(2*radius-delta*t*t))-c),
                                     0.,1.,epsabs=1e-35,epsrel=1e-13)
        area=m.rectangle_disk(mesh.nodes_x[6],mesh.nodes_x[7],mesh.nodes_y[3],mesh.nodes_y[4],radius)
        if endpoint<=0 or abs(area-endpoint)>m.GATE*(abs(area)+abs(endpoint))+endpoint_error:
            raise ArithmeticError('independent failed-cell endpoint area control')
        W,areas=m.disks(mesh)
        s=m.z_curl_transpose(mesh,W[0]);line=m.line_oracle(mesh,m.CENTERS[0],m.RADII[0])
        starts,ends=m.edges(mesh)
        lengths=np.linalg.norm(ends-starts,axis=1)
        B=np.sort(mesh.project_edge_to_boundary_edge.indices)
        mask=np.ones(mesh.n_edges,dtype=bool);mask[B]=False;I=np.flatnonzero(mask)
        assert (len(B),len(I))==(1152,2142)
        scale=max(float(np.max(abs(s))),float(np.sum(abs(s))))
        line_error=float(np.max(abs(s-line)))
        if line_error>m.GATE*scale:raise ArithmeticError('independent segmented line oracle')
        divergence=np.zeros(mesh.n_nodes)
        nx,ny,nz=mesh.shape_cells;off=0
        for axis,shape in enumerate((mesh.shape_edges_x,mesh.shape_edges_y,mesh.shape_edges_z)):
            n=math.prod(shape)
            sub=np.unravel_index(np.arange(n),shape,order='F')
            tail=np.ravel_multi_index(sub,mesh.shape_nodes,order='F')
            other=list(sub);other[axis]=other[axis]+1
            head=np.ravel_multi_index(tuple(other),mesh.shape_nodes,order='F')
            np.add.at(divergence,tail,-s[off:off+n]/lengths[off:off+n])
            np.add.at(divergence,head,s[off:off+n]/lengths[off:off+n])
            off+=n
        divmax=float(np.max(abs(divergence)))
        if divmax>m.GATE*max(float(np.sum(abs(s/lengths))),1e-30):raise ArithmeticError('weak divergence')
        moment=float(s @ np.r_[-(starts[:math.prod(mesh.shape_edges_x),1]+ends[:math.prod(mesh.shape_edges_x),1])/4,
            (starts[math.prod(mesh.shape_edges_x):math.prod(mesh.shape_edges_x)+math.prod(mesh.shape_edges_y),0]+ends[math.prod(mesh.shape_edges_x):math.prod(mesh.shape_edges_x)+math.prod(mesh.shape_edges_y),0])/4,
            np.zeros(math.prod(mesh.shape_edges_z))])
        if abs(moment-math.pi*.05**2)>m.GATE*math.pi*.05**2:raise ArithmeticError('rotational moment')
        if not np.any(abs(s[I])>m.GATE*scale):raise ArithmeticError('no resolved interior forcing')
        if not np.array_equal(s[B],np.zeros(len(B))):raise ArithmeticError('source touches prescribed boundary')
        if abs(s[:math.prod(mesh.shape_edges_x)].sum())>m.GATE*scale or abs(s[math.prod(mesh.shape_edges_x):math.prod(mesh.shape_edges_x)+math.prod(mesh.shape_edges_y)].sum())>m.GATE*scale:raise ArithmeticError('constant field circulation')
        low=m.green_boundary(starts[B],ends[B],64,8)
        high=m.green_boundary(starts[B],ends[B],128,16)
        maxdiff=float(np.max(abs(high-low)))
        gate=1.967577343353139e-12
        if maxdiff>gate:raise ArithmeticError('fixed Green boundary pair consistency gate')
        for name,x in {'W_faces_m2':W,'disk_cell_areas_m2':areas,'s_matrix_free_Am':s,'s_line_oracle_Am':line,
                       'boundary_indices':B,'interior_indices':I,'edge_starts_m':starts,'edge_ends_m':ends,
                       'boundary_g_64x8_Vpm':low,'boundary_g_128x16_Vpm':high,'weak_divergence_A':divergence}.items():
            save_array(stage/(name+'.npy'),x)
        result={'status':'controls_pass','shape_cells':mesh.shape_cells,'n_edges':mesh.n_edges,'n_faces':mesh.n_faces,
            'boundary_edges':len(B),'interior_edges':len(I),'plane_basis':[m.plane_basis(mesh.nodes_z,z) for z in m.CENTERS],
            'source_positive_face_count':int(np.count_nonzero(W[0]>0)),
            'failed_cell_area_m2':area,'independent_endpoint_area_m2':endpoint,
            'endpoint_quadrature_error_estimate_m2':endpoint_error,
            'source_area_m2':float(W[0].sum()),'receiver_area_m2':W[1:].sum(axis=1).tolist(),
            'source_interior_nonzero_count':int(np.count_nonzero(abs(s[I])>m.GATE*scale)),
            'source_boundary_exact_zero':True,'line_oracle_max_difference_Am':line_error,
            'divergence_max_A':divmax,'rotational_moment_Am2':moment,
            'boundary_pair_max_difference_Vpm':maxdiff,'boundary_pair_gate_Vpm':gate,
            'boundary_high_max_Vpm':float(np.max(abs(high))),
            'qualification':'observed quadrature consistency, not rigorous receiver error certification',
            'G03':'not_run','all29':'not_run'}
        save_json(stage/'control-result.json',result)
        counts={'C_constructions':0,'A_assemblies':0,'factorizations':0,'RHS_columns':0}
    elif mode=='actual':
        from scipy.sparse.linalg import splu
        from simpeg.electromagnetics.frequency_domain.simulation import Simulation3DElectricField
        control=D/'controls-04'
        c=json.loads((control/'control-result.json').read_text(encoding='utf-8'))
        assert c['status']=='controls_pass' and c['boundary_pair_max_difference_Vpm']<=c['boundary_pair_gate_Vpm']
        W=np.load(control/'W_faces_m2.npy',allow_pickle=False)
        s=np.load(control/'s_matrix_free_Am.npy',allow_pickle=False)
        B=np.load(control/'boundary_indices.npy',allow_pickle=False)
        I=np.load(control/'interior_indices.npy',allow_pickle=False)
        g=np.load(control/'boundary_g_128x16_Vpm.npy',allow_pickle=False)
        C=mesh.edge_curl.tocsr(copy=True);counts['C_constructions']=1
        source_actual=np.asarray(C.T@W[0]).ravel()
        se=float(np.max(abs(source_actual-s)))
        if se>m.GATE*max(float(np.sum(abs(s))),1e-30):raise ArithmeticError('actual C.T W differs from matrix-free source')
        sim=Simulation3DElectricField(mesh,survey=None,sigma=np.full(mesh.n_cells,m.SIGMA),
            mu=np.full(mesh.n_cells,m.MU),permittivity=np.full(mesh.n_cells,m.EPSILON))
        A=sim.getA(m.FREQ).tocsr(copy=True);counts['A_assemblies']=1
        if A.shape!=(3294,3294) or C.shape!=(2976,3294):raise ValueError('actual operator size')
        rhs=-1j*(2*math.pi*m.FREQ)*source_actual
        AII=A[I,:][:,I].tocsc();AIB=A[I,:][:,B].tocsr()
        reduced=rhs[I]-AIB@g
        with warnings.catch_warnings(record=True) as wr:
            warnings.simplefilter('error')
            lu=splu(AII);counts['factorizations']=1
            x=lu.solve(reduced);counts['RHS_columns']=1
        residual=AII@x-reduced
        normA=float(np.max(np.asarray(abs(AII).sum(axis=1)).ravel()))
        den=normA*float(np.max(abs(x)))+float(np.max(abs(reduced)))
        eta=float(np.max(abs(residual))/den) if den else (0. if np.array_equal(residual,np.zeros_like(residual)) else math.inf)
        if not math.isfinite(eta) or eta>m.GATE:raise ArithmeticError('fixed 128eps backward residual gate')
        E=np.empty(mesh.n_edges,dtype=complex);E[B]=g;E[I]=x
        V=W@(C@E)
        refpath=D.parent/'g03-source-voltage-20261021/run-01/V_reference128_V.npy'
        if hashlib.sha256(refpath.read_bytes()).hexdigest()!='fd68cfa481e92251fd14616f0ca177f312db89904557c8c44fd9219fd1df1889':raise ValueError('reference pin')
        ref=np.load(refpath,allow_pickle=False)
        assert ref.shape==(2,)
        diff=V[1:]-ref
        for name,xarr in {'source_actual_CtW_Am':source_actual,'A_II_rhs':reduced,'raw_rhs':rhs,
                          'interior_solution_Vpm':x,'E_Vpm':E,'V_compatible_V':V[1:],
                          'V_reference128_V':ref,'V_difference_V':diff,'AII_residual':residual}.items():
            save_array(stage/(name+'.npy'),xarr)
        for name,matrix in (('A',A),('C',C)):
            matrix.sum_duplicates();matrix.sort_indices()
            with (stage/(name+'-csr.npz')).open('xb') as f:
                np.savez(f,shape=np.asarray(matrix.shape),data=matrix.data,indices=matrix.indices,indptr=matrix.indptr)
        result={'status':'one_actual_L1_solve_complete','counts':counts,'C_transpose_source_max_difference_Am':se,
            'A_nnz':int(A.nnz),'C_nnz':int(C.nnz),'AII_shape':AII.shape,'AII_nnz':int(AII.nnz),
            'backward_residual_eta':eta,'backward_residual_gate':m.GATE,
            'V_compatible_V':pair(V[1:]),'V_reference128_V':pair(ref),
            'finite_minus_reference_V':pair(diff),'absolute_difference_V':abs(diff).tolist(),
            'relative_difference':(abs(diff)/abs(ref)).tolist(),
            'previous_8cell_relative_difference':[.934164478734929,.7874690186755858],
            'comparison_note':'receiver functional changed from old smooth Fz to compatible face flux; errors are descriptive',
            'physical_acceptance':'open','G03':'not_run','R03':'not_run','all29':'not_run'}
        save_json(stage/'result.json',result)
    else:raise ValueError('unknown mode')
except BaseException as exc:
    error={'type':type(exc).__name__,'message':str(exc)}
    raise
finally:
    save_json(stage/'execution.json',{'mode':mode,'pid':os.getpid(),'seconds':time.monotonic()-started,
        'counts':counts,'blas_before':before,'blas_after':threads(),'error':error})
