from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parent;O=D.parent;ROOT=O.parents[1]
P=ROOT/'.local/deepeye-implementation-a'
T=P/'competition/deepeye/evidence/system/a-runtime-and-grid-20261021'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(p):return json.loads(p.read_bytes())
def enc(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(p,raw):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(raw)
specs=[('g03-internal-source-grid-continuation-20261021','public-manifest.json'),
       ('g03-l2-xy-refinement-20261021','public-manifest.json'),
       ('g03-l3-z-refinement-20261021','public-manifest.json'),
       ('r02-runtime-install-20261021','manifest.json')]
tokens=[load(O/n/'lease.private.json')['lease_token'].encode() for n,_ in specs]
members={};derivatives=[]
def clean(v):
    if isinstance(v,list):return [clean(x) for x in v]
    if isinstance(v,dict):return {k:clean(x) for k,x in v.items() if k not in ('environment','env')}
    return v
def add(p):
    if 'private' in p.name.casefold() or p.name=='reserve-request.json':return
    raw=p.read_bytes();name=p.relative_to(O).as_posix()
    if p.suffix=='.json':
        try:v=load(p)
        except json.JSONDecodeError as exc:
            # A retained interrupted JSON write can contain environment fields.
            # Keep its exact original locally and publish a hash-bound descriptor.
            name=name.removesuffix('.json')+'-unparsed-public.json'
            v={'original_local_sha256':sha(raw),'original_bytes':len(raw),
               'original_environment_omitted':True,'original_retained_locally':True,
               'reason':'Malformed partial JSON from a retained failed attempt',
               'parse_error':{'line':exc.lineno,'column':exc.colno,'message':exc.msg}}
            derivatives.append({'published_path':name,'original_sha256':sha(raw),'malformed_original_retained_locally':True})
            raw=enc(v)
        c=clean(v)
        if v!=c:
            name=name.removesuffix('.json')+'-public.json'
            c['original_environment_omitted']=True;c['original_local_sha256']=sha(raw)
            derivatives.append({'published_path':name,'original_sha256':sha(raw)})
            raw=enc(c)
    assert name not in members and not any(token in raw for token in tokens),name
    members[name]=raw
for name,manifest in specs:
    s=O/name;m=load(s/manifest)
    for rel,pin in m['files'].items():
        p=s/rel;assert p.stat().st_size==pin['bytes'] and sha(p.read_bytes())==pin['sha256'],str(p)
        add(p)
    for extra in (manifest,'native-complete-response.json'):
        if (s/extra).relative_to(O).as_posix() not in members:add(s/extra)
reviews={}
for name in ('g03-l1-main-review-20261021','g03-l2-main-review-20261021','g03-l3-main-review-20261021','r02-runtime-main-review-20261021'):
    reviews[name]=load(O/name/'review.json');add(O/name/'review.json')
summary=dict(utc=datetime.now(timezone.utc).isoformat(),reviews=reviews,public_derivatives=derivatives,
    requirements_sha256='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    old_tests_repeated=False,formal_R03='not_run',full_H12='not_run',all29='not_run')
members['main/summary.json']=enc(summary);members['main/prepare.py']=Path(__file__).read_bytes()
T.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(T/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()):
        zi=zipfile.ZipInfo(name,(2026,10,21,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16
        z.writestr(zi,raw)
with zipfile.ZipFile(T/'evidence.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for name,raw in members.items():assert z.read(name)==raw
write(T/'.gitattributes',b'* -text -eol -filter\n')
write(T/'archive-index.json',enc({n:{'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(members.items())}))
write(T/'summary.json',enc(summary))
readme='''# Actual AMD execution and new spatial diagnostics

The selected isolated CPython 3.12 environment now contains all 17 pinned packages
plus pip 25.0.1. One offline hashed install succeeded. One pip check passed; its
success was reused while later metadata harness failures were corrected. Main
independently verified 121 evidence files and all 17 installed METADATA files
against the selected wheel bytes. Original failed free-space gate, Windows pip
launcher protection, stale sdist-vs-built metadata comparison and missing parser
path remain in their original directories. There was no package reinstall.

One actual probe found AMD Radeon 780M/gfx1103, torch 2.12.0+rocm7.14.1 and HIP build
marker 7.14.60850, with no CUDA build marker. One FP32 4x4 matmul and one sync gave
the exact expected 16 values. No CPU/NVIDIA fallback or architecture override ran.
All26 retained handles across 9 stage trees terminated. This is experimental
current-driver execution, not official 8845H support. The loaded HIP runtime DLL
and API version were not collected. The NumPy-absent warning is preserved; no
unselected dependency was added. A real C-owned project CNN, concurrency and
physical-fixture calibration remain required for their respective task gates.

G03 now has a resolved compatible finite-loop source and receiver implementation.
L1 has 896 cells and 32 nonzero interior source edges. L2 refines centralXY to 2016 cells
and 80 source edges. L3 keeps L2XY and halves every z interval to 4032 cells. Each new
grid had exactly one actual A/C assembly, sparse factorization and RHS. Existing
L1/L2 outputs and reference128 were reused, never recomputed for comparisons.

Relative receiver-voltage differences from the pinned homogeneous reference are:

|Grid|Near receiver|Far receiver|
|---|---:|---:|
|L1|42.8865%|34.3817%|
|L2|42.5216%|34.0351%|
|L3|30.1941%|29.9509%|

All three retained solves satisfy the same 128eps backward-residual gate. The
new boundary quadrature pairs satisfy the unchanged consistency gate. These
checks do not certify physical accuracy or total discretization uncertainty.
Axial refinement materially changes the answer; roughly 30% residual errors mean
the model is still unqualified. These homogeneous cases do not replace arbitrary
3D heterogeneous/off-axis cases or the taskbook sensor/unknown/OOD matrices.
L2's raw inherited L1 label is preserved with a separate interpretation record;
the actual L2 geometry and dimensions are verified. L3's new label is correct.

The original PC_DIRECT, pipe-read, 13 R03 software groups and base-BRAM 384/384
results were reused. No old tests, original board load, driver/service changes,
UI/display actions, production activation or full-model training were performed
by this checkpoint. B register/HWH and C project-model dependencies remain open.

All exact final native results, new source/control/solve evidence and main reviews
are archived. Private leases/vendor wheel payloads/full environments are excluded;
environment-removed derivatives retain original local hashes. H01-H15 and canonical
requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804
are unchanged. Formal R02/G03/R03/C03/H12/all29 acceptance remains open.
'''
write(T/'README.md',readme.encode())
write(T/'manifest.json',enc(dict(files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(T.iterdir())},archive_members=len(members),exact_member_bytes_and_crc_checked=True)))
guide=P/'competition/deepeye/docs/runtime_and_grid_checkpoint_20261021.md'
write(guide,'''# Runtime and field-model progress

[The current evidence](../evidence/system/a-runtime-and-grid-20261021/README.md)
records a successful isolated 17-package installation, an actual AMD 780M FP32
kernel with exact output, and three distinct resolved-source spatial diagnostics.
Each new grid ran once. Successful old software/board tests and reference arrays
were reused. The remaining roughly 30% field-model errors are preserved as failed
physical accuracy, separate from solver/control success. Project CNN, full
three-dimensional sensor qualification and custom-board integration remain open.
'''.encode())
files={p.relative_to(P).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in [*sorted(T.iterdir()),guide]}
write(D/'publication-files.json',enc(files));write(D/'owned-paths.nul',b''.join(n.encode()+b'\0' for n in files))
r=dict(files=len(files),archive_members=len(members),archive_bytes=(T/'evidence.zip').stat().st_size,archive_sha256=sha((T/'evidence.zip').read_bytes()),environment_derivatives=len(derivatives))
write(D/'package-summary.json',enc(r));print(json.dumps(r))
