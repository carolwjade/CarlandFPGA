"""Read-only product audit and exclusive evidence snapshots; no product imports."""
import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import re

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
PRODUCT = ROOT / ".local/deepeye-implementation-a/competition/deepeye"
DESIGN = D.parent / "r03-stateful-wiring-design-20261020"
PRIOR = D.parent / "r02-install-recipe-fix-20261020"
MAIN_ADDITION = "evidence/control/a-b-op17-review-20261021/"


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def save(name, value):
    with (D / name).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def tree(path):
    return ast.parse(path.read_text(encoding="utf-8-sig"))


def node(module, *names):
    current = module
    for name in names:
        current = next(n for n in current.body if isinstance(
            n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return current


def same_node(before, after, *names):
    left, right = node(before, *names), node(after, *names)
    assert ast.dump(left, include_attributes=False) == ast.dump(right, include_attributes=False), names
    return {"name": ".".join(names), "identical_ast": True,
            "before_lines": [left.lineno, left.end_lineno],
            "after_lines": [right.lineno, right.end_lineno]}


baseline = json.loads((D / "baseline.json").read_bytes())
allowed = set(baseline["allowed_product_paths"])
current = {p.relative_to(PRODUCT).as_posix(): pin(p)
           for p in sorted(PRODUCT.rglob("*"))
           if p.is_file() and "__pycache__" not in p.parts}
missing = sorted(set(baseline["files"]) - set(current))
changed = sorted(name for name, value in baseline["files"].items()
                 if name in current and current[name] != value)
added = sorted(set(current) - set(baseline["files"]))
unexpected = sorted(set(changed) - allowed)
unexpected += [name for name in added if name not in allowed and not name.startswith(MAIN_ADDITION)]
assert not missing and not unexpected, {"missing": missing, "unexpected": unexpected}
assert set(changed) == {
    "simulation/authority/actor_composition.py",
    "tests/simulation/test_actor_composition.py", "docs/actor_composition.md"}
assert {name for name in added if name in allowed} == {
    "simulation/authority/candidate_owner.py", "tests/simulation/test_candidate_owner.py"}
unowned = {name: current[name] for name in baseline["files"] if name not in allowed}
assert all(value == baseline["files"][name] for name, value in unowned.items())
save("ownership-audit.json", {
    "audited_utc": datetime.now(timezone.utc).isoformat(),
    "main_supplied_source_baseline_commit": baseline["main_supplied_baseline_commit"],
    "git_not_invoked": True, "baseline_file_count": len(baseline["files"]),
    "current_file_count": len(current), "unchanged_baseline_unowned_count": len(unowned),
    "changed_existing": changed, "new_owned": [n for n in added if n in allowed],
    "main_owned_new_evidence": {n: current[n] for n in added if n.startswith(MAIN_ADDITION)},
    "missing": missing, "unexpected": unexpected, "files": current,
    "pycache_excluded_consistently_with_baseline": True})
print(json.dumps({"ownership_verified": True, "unchanged_unowned": len(unowned),
                  "main_owned_added": sum(n.startswith(MAIN_ADDITION) for n in added)}), flush=True)

manifest = json.loads((DESIGN / "artifact-manifest.json").read_bytes())
assert pin(DESIGN / "artifact-manifest.json") == baseline["design_manifest"]
for name, value in manifest["files"].items():
    assert pin(DESIGN / name) == value, name
source_pins = {}
for name, value in baseline["design_source_pins"].items():
    path = ROOT / name
    owned = path.is_relative_to(PRODUCT) and path.relative_to(PRODUCT).as_posix() in allowed
    actual = pin(path)
    if not owned:
        assert actual == value, name
    source_pins[name] = {"baseline": value, "current": actual, "owned_change": owned}
contract = json.loads((ROOT / "docs/competition/deepeye-2026/immutable_scope.json").read_bytes())
requirements_sha = hashlib.sha256(json.dumps(contract["requirements"], sort_keys=True,
    separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
assert requirements_sha == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
assert [r["id"] for r in contract["requirements"]] == [f"H{i:02}" for i in range(1, 16)]
transfer = json.loads((ROOT / ".planning/deepeye-desktop-handoff-20261015/transfer.json").read_bytes())
assert transfer["status"] == "active" and transfer["director_generation"] == 2
assert transfer["new_director_thread_id"] == "01a13d7e-dcf1-7272-a738-a637dd62ff9d"
save("source-pins.json", {"design_manifest": pin(DESIGN / "artifact-manifest.json"),
    "design_files_verified": len(manifest["files"]), "design_source_files": source_pins,
    "requirements_sha256": requirements_sha, "H01_H15_preserved": True,
    "active_director_generation": 2, "product_after": {n: current[n] for n in sorted(allowed)}})

for name in sorted(allowed):
    data = (PRODUCT / name).read_bytes()
    target = D / "product-after" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(data)
    old_path = D / "baseline" / name
    old = old_path.read_text(encoding="utf-8-sig") if old_path.exists() else ""
    new = data.decode("utf-8-sig")
    patch = "".join(difflib.unified_diff(old.splitlines(keepends=True),
        new.splitlines(keepends=True), fromfile="baseline/" + name, tofile="product-after/" + name))
    target = D / "diffs" / (name + ".diff")
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(patch)

before = tree(D / "baseline/simulation/authority/actor_composition.py")
after = tree(PRODUCT / "simulation/authority/actor_composition.py")
guards = [same_node(before, after, *names) for names in (
    ("_ProgressGate",), ("_Dependencies", "ai_lease"), ("_Dependencies", "prepare_step"),
    ("_Dependencies", "commit_step"), ("_production_channels",), ("create_authority",))]
new_proof = node(tree(PRODUCT / "simulation/authority/candidate_owner.py"), "_CompletedInference")
old_proof = node(before, "_CompletedInference")
proof_fields = lambda n: [ast.dump(item, include_attributes=False) for item in n.body if isinstance(item, ast.AnnAssign)]
assert proof_fields(new_proof) == proof_fields(old_proof)
assert [ast.dump(n) for n in new_proof.decorator_list] == [ast.dump(n) for n in old_proof.decorator_list]
before_tests = tree(D / "baseline/tests/simulation/test_actor_composition.py")
after_tests = tree(PRODUCT / "tests/simulation/test_actor_composition.py")
old_methods = {n.name: n for n in node(before_tests, "ActorCompositionTests").body
               if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")}
new_methods = {n.name: n for n in node(after_tests, "ActorCompositionTests").body
               if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")}
assert old_methods.keys() == new_methods.keys()
unchanged_methods = [name for name in old_methods
    if ast.dump(old_methods[name], include_attributes=False) == ast.dump(new_methods[name], include_attributes=False)]
changed_methods = sorted(set(old_methods) - set(unchanged_methods))
for module in (PRODUCT / "simulation/authority/candidate_owner.py",
               PRODUCT / "simulation/authority/actor_composition.py"):
    assert "completion_for_command" not in module.read_text(encoding="utf-8")
save("semantic-guards.json", {"unchanged_ast": guards,
    "moved_completed_inference_fields_and_frozen_decorator_identical": True,
    "original_composition_test_names_retained": sorted(old_methods),
    "original_composition_test_count": len(old_methods),
    "unchanged_test_method_ast": sorted(unchanged_methods),
    "migrated_test_method_ast": changed_methods,
    "production_completion_for_command_absent": True,
    "unowned_runtime_executor_mailbox_hil_all_byte_identical": True})

expected = {
    "red-original-v2": (125, None, None),
    "red-original-v3": (1, 2, False),
    "red-stateful-v1": (1, 22, False),
    "red-stateful-v2": (1, 22, False),
    "green-stateful-v1": (1, 22, False),
    "green-stateful-v2": (0, 22, True),
    "composition-integration-v1": (125, None, None),
    "composition-integration-v2": (0, 74, True),
    "final-focused-v1": (0, 31, True),
    "runtime-executor-v1": (0, 91, True)}
runs = {}
for run in sorted((D / "executions").iterdir()):
    if (run / "prelaunch-refusal.json").exists():
        record = json.loads((run / "prelaunch-refusal.json").read_bytes())
        assert run.name == "red-original-v1" and record["process_created"] is False
        assert not (run / "process").exists()
        runs[run.name] = {"created_process": False, "receipt": pin(run / "prelaunch-refusal.json")}
        continue
    receipt = json.loads((run / "terminal.json").read_bytes())
    assert receipt["all_processes_terminated"] is True
    assert len(receipt["held_members"]) == 3
    assert all(r["signaled"] is True and r["wait_result"] == 0 for r in receipt["held_members"])
    if "active_processes_final" in receipt:
        assert receipt["active_processes_final"] == 0
        closure = "numeric active_processes_final=0 and every original held handle signaled"
    else:
        assert receipt["stop_reason"] == "runner_exception_FileNotFoundError" and receipt["resumed"]
        closure = "exception receipt: original pinned HeldMembers.wait_terminated verifies empty job and every original held handle signaled; numeric active count absent"
    result = json.loads((run / "test-result.json").read_bytes()) if (run / "test-result.json").exists() else {}
    assert (receipt["exit_code"], result.get("testsRun"), result.get("successful")) == expected[run.name]
    if result:
        assert result["prohibited_attempts"] == []
    started = json.loads((run / "started.json").read_bytes())
    counts = {}
    if (run / "process/stderr.log").exists():
        stderr = (run / "process/stderr.log").read_text(encoding="utf-8", errors="replace")
        for classname in re.findall(r"^test_\w+ \(([^)]+)\)", stderr, re.MULTILINE):
            classname = classname.rsplit(".", 1)[0] if ".test_" in classname else classname
            counts[classname] = counts.get(classname, 0) + 1
    runs[run.name] = {"created_process": True, "terminal_pin": pin(run / "terminal.json"),
        "exit_code": receipt["exit_code"], "stop_reason": receipt.get("stop_reason"),
        "held_members": receipt["held_members"], "closure_basis": closure,
        "testsRun": result.get("testsRun"), "successful": result.get("successful"),
        "failures": len(result.get("failures", [])), "errors": len(result.get("errors", [])),
        "skipped": result.get("skipped"), "prohibited_attempts": result.get("prohibited_attempts"),
        "test_result_pin": pin(run / "test-result.json") if result else None,
        "command": started["argv"], "budget": started["budget"],
        "test_class_counts_from_stderr": counts}
assert set(runs) == set(expected) | {"red-original-v1"}
assert pin(PRIOR / "win_job.py")["sha256"] == "127daf70b2aa6cf3e7a299978596766fc310d191d13f6a2165626f719889052d"
assert pin(PRIOR / "boundary.py")["sha256"] == "dc27aea6104424fbb2ee9109bb5e2adaf90684161e9d43bd2636b5ea4d6f2908"
save("execution-audit.json", {"runs": runs, "actual_runs": len(expected),
    "held_handle_receipts_verified": 3 * len(expected), "all_actual_runs_terminated": True,
    "failures_preserved_without_promotion": True,
    "original_runner": pin(PRIOR / "win_job.py"), "original_boundary": pin(PRIOR / "boundary.py")})

version_map = {}
versions = {
    "composition-integration-v2": ["simulation/authority/actor_composition.py",
        "simulation/authority/candidate_owner.py", "tests/simulation/test_actor_composition.py"],
    "final-focused-v1": sorted(allowed),
    "runtime-executor-v1": sorted(allowed)}
for run_id, names in versions.items():
    snap = D / "executions" / run_id / "source-snapshots"
    checked = {}
    for name in names:
        assert pin(snap / name) == current[name], (run_id, name)
        checked[name] = current[name]
    harness = {}
    if run_id in ("final-focused-v1", "runtime-executor-v1"):
        for name in ("run_tests.py", "test_worker.py", "red_controls.py",
                     "tree_observer.py", "test_tree_observer.py"):
            assert pin(snap / name) == pin(D / name), (run_id, name)
            harness[name] = pin(D / name)
    result = json.loads((D / "executions" / run_id / "test-result.json").read_bytes())
    for name, expected_pin in result["imports_and_reads"].items():
        path = Path(name)
        if path.is_relative_to(PRODUCT):
            assert pin(path) == expected_pin, (run_id, name)
    version_map[run_id] = {"current_product_snapshot_equality": checked,
        "current_harness_snapshot_equality": harness,
        "all_recorded_product_import_read_hashes_current": True}
save("tested-version-map.json", version_map)

old_walker = node(tree(PRIOR / "win_job.py"), "measure_tree")
old_text = ast.get_source_segment((PRIOR / "win_job.py").read_text(encoding="utf-8"), old_walker) + "\n"
new_walker = node(tree(D / "tree_observer.py"), "measure_tree")
new_text = ast.get_source_segment((D / "tree_observer.py").read_text(encoding="utf-8"), new_walker) + "\n"
with (D / "diffs/measure_tree.diff").open("x", encoding="utf-8", newline="\n") as stream:
    stream.writelines(difflib.unified_diff(old_text.splitlines(keepends=True), new_text.splitlines(keepends=True),
        fromfile="pinned_original/win_job.py:measure_tree", tofile="this_task/tree_observer.py:measure_tree"))
for name in ("run_tests.py", "test_worker.py", "red_controls.py"):
    old_path = D / "executions/red-original-v3/source-snapshots" / name
    with (D / "diffs" / (name + ".diff")).open("x", encoding="utf-8", newline="\n") as stream:
        stream.writelines(difflib.unified_diff(old_path.read_text(encoding="utf-8").splitlines(keepends=True),
            (D / name).read_text(encoding="utf-8").splitlines(keepends=True),
            fromfile="red-original-v3/" + name, tofile="current/" + name))
print(json.dumps({"complete": True, "owned_product_paths": len(allowed),
    "original_composition_methods": len(old_methods), "unchanged_method_ast": len(unchanged_methods),
    "migrated_methods": changed_methods, "actual_runs_terminated": len(expected),
    "held_handle_receipts_verified": 3 * len(expected), "requirements_sha256": requirements_sha}), flush=True)
