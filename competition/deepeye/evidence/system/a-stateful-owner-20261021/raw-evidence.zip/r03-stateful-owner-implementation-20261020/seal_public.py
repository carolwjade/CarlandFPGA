"""Final static seal of public evidence; never opens private/reservation material."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
PRODUCT = ROOT / ".local/deepeye-implementation-a/competition/deepeye"
JOB = "child-b4ad57212b1943f09f34fab01700abde"
WORK = "A-R03-STATEFUL-OWNER-IMPLEMENTATION-20261020-v1"
AGENT = "/root/r02_recipe_fix_20261020"
EXCLUDED = {"artifact-manifest.json", "seal-result.json", "native-complete-response.json"}


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def save(name, value):
    with (D / name).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def excluded(path):
    name = path.name.lower()
    return path.relative_to(D).as_posix() in EXCLUDED or "private" in name or "reserve" in name


assert not (D / "native-complete-response.json").exists()
lease_check = json.loads((D / "native-validate-response.json").read_bytes())
assert lease_check["job_id"] == JOB and lease_check["work_id"] == WORK
assert lease_check["native_agent_id"] == AGENT and lease_check["execution_allowed"] is True
assert json.loads((D / "static-audit-completion.json").read_bytes())["complete"] is True
ownership = json.loads((D / "ownership-audit.json").read_bytes())
current = {p.relative_to(PRODUCT).as_posix(): pin(p) for p in sorted(PRODUCT.rglob("*"))
           if p.is_file() and "__pycache__" not in p.parts}
assert current == ownership["files"], "Product changed since static ownership audit"
source_pins = json.loads((D / "source-pins.json").read_bytes())
product_pins = source_pins["product_after"]
for name, value in product_pins.items():
    assert pin(PRODUCT / name) == value and pin(D / "product-after" / name) == value
for name, record in source_pins["design_source_files"].items():
    assert pin(ROOT / name) == record["current"], name

budget = {"seconds": 50, "job_memory_bytes": 512*1024**2,
    "process_memory_bytes": 256*1024**2, "active_processes": 4,
    "stdout_bytes": 2*1024**2, "stderr_bytes": 2*1024**2,
    "tree_bytes": 64*1024**2, "tree_entries": 3000, "free_reserve_bytes": 10*1024**3}
closures = {}
for run in sorted((D / "executions").iterdir()):
    if not (run / "terminal.json").exists():
        refusal = json.loads((run / "prelaunch-refusal.json").read_bytes())
        assert refusal["process_created"] is False and not (run / "process").exists()
        continue
    outer = json.loads((run / "terminal.json").read_bytes())
    inner = json.loads((run / "process/terminal.json").read_bytes())
    assert outer == inner
    assert outer["all_processes_terminated"] is True and len(outer["held_members"]) == 3
    assert all(r["signaled"] is True and r["wait_result"] == 0 for r in outer["held_members"])
    assert json.loads((run / "started.json").read_bytes())["budget"] == budget
    for channel in ("stdout", "stderr"):
        assert pin(run / "process" / (channel + ".txt")) == outer["logs"][channel]
    assert outer.get("active_processes_final", 0) == 0
    if "active_processes_final" not in outer:
        assert outer["stop_reason"] == "runner_exception_FileNotFoundError" and outer["resumed"]
    closures[run.name] = {"inner_outer_terminal_exact": True, "logs_match_terminal_hashes": True,
        "budget_exact": True, "held_count": 3, "all_held_wait_0_signaled": True,
        "numeric_active_field_present": "active_processes_final" in outer,
        "terminal_pin": pin(run / "terminal.json")}
assert len(closures) == 10
save("closure-and-budgets.json", {
    "runs": closures, "budget": budget, "all_actual_runs_terminated": True,
    "current_product_equals_ownership_audit": True,
    "source_and_contract_pins_rechecked": True,
    "private_reservation_files_not_opened": True})

files = {}
directories = []
for path in sorted(D.rglob("*")):
    if excluded(path):
        continue
    info = os.lstat(path)
    assert not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400
    if stat.S_ISDIR(info.st_mode):
        directories.append(path.relative_to(D).as_posix())
        continue
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1, path
    files[path.relative_to(D).as_posix()] = pin(path)
manifest = {"work_id": WORK, "job_id": JOB, "agent_id": AGENT,
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "requirements_sha256": source_pins["requirements_sha256"],
    "product_after": product_pins, "public_file_count": len(files),
    "public_directory_count": len(directories), "files": files, "directories": directories,
    "exclusions": sorted(EXCLUDED),
    "private_material_policy": "Names containing private or reserve are excluded without opening.",
    "scope": "Public synthetic software evidence only; R03/full H12/all29 not_run"}
save("artifact-manifest.json", manifest)
for name, expected in files.items():
    assert pin(D / name) == expected, name
save("seal-result.json", {"sealed": True, "work_id": WORK, "job_id": JOB, "agent_id": AGENT,
    "public_manifest": pin(D / "artifact-manifest.json"), "public_files_verified": len(files),
    "public_directories": len(directories), "final_result": pin(D / "final-result.txt"),
    "product_after": product_pins, "all_original_runs_terminated": True,
    "original_native_complete_not_yet_called": True,
    "next_and_last_write": "original native helper complete response, then read-only exact readback",
    "H01_H15_requirements_sha256": source_pins["requirements_sha256"],
    "R03": "not_run", "full_H12": "not_run", "all29": "not_run"})
print(json.dumps({"sealed": True, "public_files": len(files),
    "public_directories": len(directories), "manifest_sha256": pin(D / "artifact-manifest.json")["sha256"],
    "final_result_sha256": pin(D / "final-result.txt")["sha256"],
    "all_actual_runs_terminated": True}))
