"""Finish static audit after explicit 22-to-25 test-only version distinction."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
PRODUCT = ROOT / ".local/deepeye-implementation-a/competition/deepeye"
PRIOR = D.parent / "r02-install-recipe-fix-20261020"


def pin(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(name, value):
    with (D / name).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def tree(path):
    return ast.parse(path.read_text(encoding="utf-8-sig"))


def node(module, name):
    return next(n for n in module.body if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name == name)


def patch(old_path, new_path, output, before_label, after_label):
    with (D / output).open("x", encoding="utf-8", newline="\n") as stream:
        stream.writelines(difflib.unified_diff(
            old_path.read_text(encoding="utf-8-sig").splitlines(keepends=True),
            new_path.read_text(encoding="utf-8-sig").splitlines(keepends=True),
            fromfile=before_label, tofile=after_label))


baseline = json.loads((D / "baseline.json").read_bytes())
allowed = baseline["allowed_product_paths"]
current = {n: pin(PRODUCT / n) for n in allowed}
for name in allowed:
    assert pin(D / "product-after" / name) == current[name]
old_tests = D / "executions/composition-integration-v2/source-snapshots/tests/simulation/test_candidate_owner.py"
new_tests = PRODUCT / "tests/simulation/test_candidate_owner.py"
old_ast, new_ast = tree(old_tests), tree(new_tests)
old_class, new_class = node(old_ast, "CandidateOwnerTests"), node(new_ast, "CandidateOwnerTests")
methods = lambda n: {m.name for m in n.body if isinstance(m, ast.FunctionDef) and m.name.startswith("test_")}
old_methods, new_methods = methods(old_class), methods(new_class)
assert len(old_methods) == 22 and len(new_methods) == 25 and old_methods <= new_methods
added_methods = new_methods - old_methods
assert added_methods == {
    "test_completion_verifier_wrong_records_source_clock_model_and_overflow_refuse",
    "test_missing_slot_provider_refuses_after_completion_without_consuming_fallback",
    "test_wrong_activation_identity_and_unknown_transfer_bounds_refuse"}
new_class.body = [n for n in new_class.body if not
    (isinstance(n, ast.FunctionDef) and n.name in added_methods)]
assert ast.dump(new_ast, include_attributes=False) == ast.dump(old_ast, include_attributes=False)
patch(old_tests, new_tests, "diffs/owner-tests-22-to-25.diff",
      "composition-integration-v2/test_candidate_owner.py", "final-focused-v1/test_candidate_owner.py")

versions = {
    "composition-integration-v2": ["simulation/authority/actor_composition.py",
        "simulation/authority/candidate_owner.py", "tests/simulation/test_actor_composition.py"],
    "final-focused-v1": sorted(allowed), "runtime-executor-v1": sorted(allowed)}
version_map = {}
for run_id, names in versions.items():
    run = D / "executions" / run_id
    snap = run / "source-snapshots"
    checked = {}
    for name in names:
        assert pin(snap / name) == current[name], (run_id, name)
        checked[name] = current[name]
    harness = {}
    if run_id in ("final-focused-v1", "runtime-executor-v1"):
        for name in ("run_tests.py", "test_worker.py", "red_controls.py",
                     "tree_observer.py", "test_tree_observer.py"):
            assert pin(snap / name) == pin(D / name), (run_id, name)
            harness[name] = pin(D / name)
    result = json.loads((run / "test-result.json").read_bytes())
    imports = {}
    for name, expected in result["imports_and_reads"].items():
        path = Path(name)
        if path.is_relative_to(PRODUCT):
            actual = pin(path)
            equal = actual == expected
            if not equal:
                assert run_id == "composition-integration-v2" and path == new_tests
                assert pin(old_tests) == expected
            imports[name] = {"tested": expected, "current": actual, "equal": equal,
                "difference": None if equal else "exact three additional provider tests; remaining full AST identical"}
    stderr = (run / "process/stderr.txt").read_text(encoding="utf-8")
    counts = {}
    for classname in re.findall(r"^test_\w+ \(([^)]+)\)", stderr, re.MULTILINE):
        classname = classname.rsplit(".", 1)[0] if ".test_" in classname else classname
        counts[classname] = counts.get(classname, 0) + 1
    assert sum(counts.values()) == result["testsRun"], (run_id, counts)
    version_map[run_id] = {"current_product_snapshot_equality": checked,
        "current_harness_snapshot_equality": harness,
        "product_import_read_hash_comparison": imports,
        "test_class_counts_from_actual_stderr": counts}
save("tested-version-map.json", {"runs": version_map,
    "owner_tests_22_to_25": {"before": pin(old_tests), "after": pin(new_tests),
        "added_methods": sorted(added_methods), "remaining_full_ast_identical": True},
    "tests_repeated_during_static_audit": False})

original = (PRIOR / "win_job.py").read_text(encoding="utf-8")
local = (D / "tree_observer.py").read_text(encoding="utf-8")
old_text = ast.get_source_segment(original, node(ast.parse(original), "measure_tree")) + "\n"
new_text = ast.get_source_segment(local, node(ast.parse(local), "measure_tree")) + "\n"
with (D / "diffs/measure_tree.diff").open("x", encoding="utf-8", newline="\n") as stream:
    stream.writelines(difflib.unified_diff(old_text.splitlines(keepends=True), new_text.splitlines(keepends=True),
        fromfile="pinned_original/win_job.py:measure_tree", tofile="this_task/tree_observer.py:measure_tree"))
for name in ("run_tests.py", "test_worker.py", "red_controls.py"):
    patch(D / "executions/red-original-v3/source-snapshots" / name, D / name,
          "diffs/" + name + ".diff", "red-original-v3/" + name, "current/" + name)
save("static-audit-completion.json", {
    "complete": True, "read_only_product_audit": True,
    "initial_static_audit_failure_retained": "static-audit-initial-result.json",
    "owned_product_paths": len(allowed), "current_after_images_verified": True,
    "source_and_authority_guards": "semantic-guards.json", "terminal_receipts": "execution-audit.json",
    "exact_tested_versions": "tested-version-map.json",
    "initial_audit_records_left_unchanged": True})
print(json.dumps({"static_audit_complete": True, "added_provider_test_methods": sorted(added_methods),
    "groups": {k: v["test_class_counts_from_actual_stderr"] for k, v in version_map.items()}}))
