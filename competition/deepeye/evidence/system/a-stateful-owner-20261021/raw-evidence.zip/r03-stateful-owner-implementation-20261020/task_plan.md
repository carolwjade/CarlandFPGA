# Main-selected stateful owner implementation

Work A-R03-STATEFUL-OWNER-IMPLEMENTATION-20261020-v1; native job
child-b4ad57212b1943f09f34fab01700abde; owner /root/r02_recipe_fix_20261020.
Validate succeeded. Main supplied and approved the complete design; no new
design/permission cycle or Git operation is needed. Apply fpga-multi-node,
brainstorming's design checks, test-driven development and completion verification
within this assignment's exact ownership.

1. Pin the selected design manifest and current source; snapshot the three
   existing owned files and record all product file hashes without Git.
2. Add the six focused integration scenario groups and explicit synthetic
   original-event fixture protocol first. Capture a meaningful RED with the
   unchanged real composition/runtime/executor and reviewed hidden JobObject.
3. Implement the private candidate owner and exactly scoped composition hooks:
   schedule activation, one verified-observation tap after runtime admission,
   pre-command original completion, current-clock slot consume, tentative
   association finalized only after both admissions, gate-first retirement.
4. Migrate old command-to-proof fixture assumptions explicitly; preserve
   adversarial assertions by targeting the original completion verifier.
   Arrange BOOT at a pre-established legal slot in synthetic fixtures; never
   substitute a scheduled timestamp inside the owner. Use a separately stated
   long progress policy only for a test that genuinely traverses a 500 ms slot.
5. Run focused integration and original composition plus directly dependent
   runtime/executor tests. Retain every failure, exact tested/imported source,
   prohibited-action audit and all held process closures.
6. Verify only the five allowed product paths changed; freeze their full
   after-images/diffs, tests and public manifest; complete the original job
   once, verify persisted terminal/exact response, then stop all writes.

The original runtime/executor, actor native boundary, mailbox/HIL/source/vector
bytes, BOOT/schema/ABI, C dirty files and closed production factory are preserved.
No completion_for_command fallback, dictionary of completions, provider
installation, scheduled-time substitution or work after before_commit is allowed.
R03/full H12/all29 remain not_run. All work is hidden/background and no other
agent is spawned. H01-H15 and DEEPEYE-HUMAN-LOCK-20261014/revision1 remain
mandatory, canonical requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
