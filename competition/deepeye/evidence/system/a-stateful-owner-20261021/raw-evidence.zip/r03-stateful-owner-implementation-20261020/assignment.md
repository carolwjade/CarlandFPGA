# Main-selected PC_DIRECT stateful owner composition

Task DEEPEYE-IMPLEMENTATION-20261014/v1.
Work A-R03-STATEFUL-OWNER-IMPLEMENTATION-20261020-v1.
Owner /root/r02_recipe_fix_20261020, after its centered-reference job is terminal.

Read mandatory A skill/role, active generation2 transfer and immutable scope.
H01-H15 canonical requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
All tests hidden/background; no screen, input or browser.

Main has read and selected the concrete composition design in
../r03-stateful-wiring-design-20261020/design.md and verified its10-file
manifest422732203312366c206e54d3496ebfbe864b5cc3122a69bdcbd29e8e147ca92d
and exact original terminal. This is substantive software wiring, with the
production factory still closed. Original completed events/BOOT timing/slot
providers are missing and remain explicitly required. Do not create providers.

Product baseline commit26aa83e68d89c41da456459df852406b8957e1a6 was published
and all262 new blobs verified. Allowed product writes are exactly:

1. competition/deepeye/simulation/authority/candidate_owner.py (new)
2. competition/deepeye/simulation/authority/actor_composition.py
3. competition/deepeye/tests/simulation/test_candidate_owner.py (new)
4. competition/deepeye/tests/simulation/test_actor_composition.py
5. competition/deepeye/docs/actor_composition.md

These paths are under .local/deepeye-implementation-a/, not the root checkout.
Also write only this new assignment/evidence directory. Preserve four C dirty
files, all mailbox/HIL/source/vector hashes, existing final runtime/executor,
actor native boundary, BOOT/schema/ABI and production factory. Main owns Git.

Key implementation decisions:

- Private original-completion event verification must happen before command
  selection. Require explicit original channel callbacks for verified completion,
  BOOT schedule/transfer bounds and original current-slot event. Missing methods
  or evidence refuse; no fallback to completion_for_command, receipt timestamps,
  user booleans, self-created Selection/Association or C ordinal conversion.
- Retain original _CompletedInference identity from the verifier through mailbox
  selection to existing _ProgressGate.admit and actor lifetime/final authority.
  Moving its definition to candidate_owner.py with a private import alias in
  actor_composition is acceptable if needed to avoid a circular dependency.
  These Python records remain containers, not authentication.
- Only one pending original proof, one current-command proof and one transient
  input transaction. No unbounded completion dictionary. Exact duplicate
  commands use their original committed association without a second consume,
  renewal, new slot or fallback; changed/new numbered replay of consumed proof
  refuses. Do not install tentative association until both runtime and executor
  admission succeed; failure retires rather than reinserts a consumed proposal.
- Tap the existing verified observation once after actual runtime admission,
  retaining its same original bytes/boot/sample bound; do not invoke a second
  permissive verifier. Any partial admission failure retires the composition.
- Refresh the real owner clock after every external verifier callback and check
  the same veto epoch. Project fixed completion_lower+progress_max_age with
  integer overflow checks; do not renew the initial/current progress deadline
  merely because a completion arrived.
- Consume only with the reviewed mailbox's exact current-slot time rule. Never
  replace current time with a nominal/scheduled timestamp, tune equality or
  grant fictional jitter tolerance. A late verifier causes a refusal. Fixtures
  may arrange a deterministic legal slot but cannot prove real scheduler timing.
- STOP bypasses completion/slot prerequisites. Retire pending/current proof and
  mailbox before callbacks/cleanup, preserving the existing gate-first state,
  foreign/reentrant vetoes and truthful positive-CAS result after later veto.
  No new owner reset or mailbox reactivation revives an old composition.
- Keep existing _Dependencies.ai_lease target, runtime time refresh, geometry
  checks and executor CAS path. Add no work between final before_commit and CAS.
  No changes to runtime/executor implementation or actual HIL capture path.
  PC_DIRECT-only composition does not remove the separate required H12 HIL path.

Before code, save a concise implementation plan and baseline hashes/ownership.
Use meaningful RED then GREEN for the six integration groups in the selected
design with real mailbox/runtime/executor and explicitly synthetic upstream/
native fixtures. Preserve original assertions or document exact semantic
fixture migrations where the mandatory pre-command completion/slot protocol
requires them. Existing adversarial lookup tests must be migrated to the new
original-completion verifier, not deleted or weakened to regain green.
A5ms progress policy cannot magically wait500ms for another slot; invalid
policy/timing combinations must still stop. Prefer transparent shared fixture
setup over changing expected deadlines or passing scheduled time as now.

Run focused new integration tests, original composition and directly dependent
runtime/executor tests needed to establish no authority regression. No broad245
R03 replay, real model/native actor, vendor install, board or service. Use bounded
hidden reviewed process mechanics, pin tested/imported source, retain every
failure and held-handle closure; no permissive mocks of the final authority.
Production factory refusal before any acquisition is a required control.

No Git/network/peer/group, driver/OS, UI or additional agent. Freeze all five
product deltas, tests, traces and public manifest. Complete this original new
job once, verify terminal/exact and stop writes for independent review.
R03/full H12/all29 remain not_run. Main independently reviews and publishes.
