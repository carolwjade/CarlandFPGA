import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
PRODUCT = ROOT / ".local/deepeye-implementation-a/competition/deepeye"
DESIGN = D.parent / "r03-stateful-wiring-design-20261020"
ALLOWED = ["simulation/authority/candidate_owner.py","simulation/authority/actor_composition.py",
    "tests/simulation/test_candidate_owner.py","tests/simulation/test_actor_composition.py",
    "docs/actor_composition.md"]

def pin(p):
    raw = p.read_bytes()
    return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}

manifest = json.loads((DESIGN / "artifact-manifest.json").read_bytes())
assert pin(DESIGN / "artifact-manifest.json")["sha256"] == "422732203312366c206e54d3496ebfbe864b5cc3122a69bdcbd29e8e147ca92d"
for name, expected in manifest["files"].items():
    assert pin(DESIGN / name) == expected, name
sources = json.loads((DESIGN / "source-pins.json").read_bytes())["files"]
for name, expected in sources.items():
    assert pin(ROOT / name) == expected, name
contract = json.loads((ROOT / "docs/competition/deepeye-2026/immutable_scope.json").read_bytes())
sha = hashlib.sha256(json.dumps(contract["requirements"],sort_keys=True,
    separators=(",",":"),ensure_ascii=False).encode()).hexdigest()
assert sha == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
assert [r["id"] for r in contract["requirements"]] == [f"H{i:02}" for i in range(1,16)]
transfer = json.loads((ROOT / ".planning/deepeye-desktop-handoff-20261015/transfer.json").read_bytes())
assert transfer["status"] == "active" and transfer["director_generation"] == 2
assert transfer["new_director_thread_id"] == "01a13d7e-dcf1-7272-a738-a637dd62ff9d"
files = {p.relative_to(PRODUCT).as_posix():pin(p) for p in sorted(PRODUCT.rglob("*"))
    if p.is_file() and "__pycache__" not in p.parts}
for name in ALLOWED:
    path = PRODUCT / name
    if path.exists():
        target = D / "baseline" / name
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open("xb") as f: f.write(path.read_bytes())
    else:
        assert name in ("simulation/authority/candidate_owner.py","tests/simulation/test_candidate_owner.py")
result = {"main_supplied_baseline_commit":"26aa83e68d89c41da456459df852406b8957e1a6",
    "git_not_invoked":True,"allowed_product_paths":ALLOWED,"files":files,
    "design_manifest":pin(DESIGN / "artifact-manifest.json"),"design_source_pins":sources,
    "requirements_sha256":sha,"active_generation":2}
with (D / "baseline.json").open("x",encoding="utf-8") as f:
    json.dump(result,f,indent=2,ensure_ascii=False)
print(json.dumps({"product_files_pinned":len(files),"design_files_verified":len(manifest["files"]),
    "design_source_pins_verified":len(sources),"requirements_sha256":sha}))
