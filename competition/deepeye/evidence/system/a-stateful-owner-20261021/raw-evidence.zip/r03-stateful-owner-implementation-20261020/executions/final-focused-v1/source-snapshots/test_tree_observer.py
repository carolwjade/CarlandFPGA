import os
from pathlib import Path
import stat
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import tree_observer as t


def require(value,message):
    if not value: raise ValueError(message)


class TreeObserverTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        (self.root/'file').write_bytes(b'123')
        (self.root/'dir').mkdir()
        (self.root/'dir'/'nested').write_bytes(b'4567')
    def measure(self):
        return t.measure_tree(self.root,require=require,check_no_links=lambda p:None)
    def test_stable_inventory_exact_bytes_and_entries(self):
        self.assertEqual(self.measure(),(7,3))
    def test_vanished_file_is_counted_but_not_sized(self):
        original=os.lstat
        removed=[]
        def gone(path,*args,**kwargs):
            if Path(path)==self.root/'file' and not removed:
                (self.root/'file').unlink(); removed.append(True)
            return original(path,*args,**kwargs)
        with patch.object(t.os,'lstat',gone):
            self.assertEqual(self.measure(),(4,3))
    def test_vanished_queued_directory_is_tolerated(self):
        original=os.scandir
        def gone(path):
            if Path(path)==self.root/'dir':
                (self.root/'dir'/'nested').unlink()
                (self.root/'dir').rmdir()
            return original(path)
        with patch.object(t.os,'scandir',gone):
            self.assertEqual(self.measure(),(3,2))
    def test_recreated_path_is_not_swallowed(self):
        original=os.lstat
        replaced=[]
        def recreated(path,*args,**kwargs):
            if Path(path)==self.root/'file' and not replaced:
                replaced.append(True)
                (self.root/'file').unlink()
                (self.root/'file').write_bytes(b'new generation')
                raise FileNotFoundError(path)
            return original(path,*args,**kwargs)
        with patch.object(t.os,'lstat',recreated):
            with self.assertRaises(FileNotFoundError): self.measure()
    def test_permission_error_still_refuses(self):
        with patch.object(t.os,'scandir',side_effect=PermissionError('denied')):
            with self.assertRaises(PermissionError): self.measure()
    def test_hardlink_and_reparse_still_refuse(self):
        original=os.lstat
        for attrs,links in ((0,2),(0x400,1)):
            def changed(path,*args,**kwargs):
                if Path(path)==self.root/'file':
                    return SimpleNamespace(st_mode=stat.S_IFREG,st_file_attributes=attrs,st_nlink=links,st_size=3)
                return original(path,*args,**kwargs)
            with self.subTest(attrs=attrs,links=links),patch.object(t.os,'lstat',changed):
                with self.assertRaises(ValueError): self.measure()
