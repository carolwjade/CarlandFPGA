"""Preimplementation behavioral counterexamples using the real old composition."""
from competition.deepeye.tests.simulation import test_actor_composition as ac


class RedTests(ac.ActorCompositionTests):
    def test_command_must_not_invent_completion_after_command(self):
        self.activate()
        self.f.observe()
        refused = False
        try:
            self.f.command()
        except ac.c.CompositionRejected:
            refused = True
        committed = False if refused else self.step().committed
        self.assertTrue(refused and not committed,
            "command without any original completion event was admitted and committed")

    def test_original_completion_owner_entry_required(self):
        self.create()
        self.assertTrue(callable(getattr(self.comp,"accept_completion",None)),
            "pre-command original completion entry is absent")
