"""Offline tests with exact import/read pins and writes confined to this task."""
import hashlib
import json
import os
from pathlib import Path
import sys
import unittest

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
PRODUCT_ROOT = ROOT / ".local/deepeye-implementation-a"
RUN = Path(sys.argv[1]).resolve()
assert RUN.is_relative_to(D)
sys.path[:0] = [str(D),str(PRODUCT_ROOT),str(ROOT / ".local/deepeye-host-deps")]
READS, ATTEMPTS = set(), []

def audit(event,args):
    if event in {"subprocess.Popen","os.system","os.startfile","socket.connect",
                 "socket.bind","socket.sendto","socket.getaddrinfo"}:
        ATTEMPTS.append(event)
        raise RuntimeError("external action prohibited in offline authority tests")
    if event == "open" and not isinstance(args[0],int):
        path = Path(args[0]).resolve()
        mode,flags = args[1:3]
        writing = ((isinstance(mode,str) and any(c in mode for c in "wax+"))
            or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)))
        if writing and not path.is_relative_to(D):
            ATTEMPTS.append("unowned_write:"+str(path))
            raise RuntimeError("unowned test write")
        if not writing:
            if ".private." in path.name: raise RuntimeError("private credential read forbidden")
            READS.add(str(path))

sys.addaudithook(audit)
names = sys.argv[2:]
suite = unittest.defaultTestLoader.loadTestsFromNames(names)
result = unittest.TextTestRunner(verbosity=2).run(suite)
reads = {}
for name in tuple(READS):
    path = Path(name)
    if path.is_file() and (path.is_relative_to(PRODUCT_ROOT) or path.is_relative_to(D)
                           or path.is_relative_to(ROOT / ".local/deepeye-host-deps")):
        raw = path.read_bytes()
        reads[name] = {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
with (RUN / "test-result.json").open("x",encoding="utf-8") as f:
    json.dump({"testsRun":result.testsRun,"successful":result.wasSuccessful(),
        "failures":[{"test":str(t),"traceback":s} for t,s in result.failures],
        "errors":[{"test":str(t),"traceback":s} for t,s in result.errors],
        "skipped":[(str(t),s) for t,s in result.skipped],
        "prohibited_attempts":ATTEMPTS,"imports_and_reads":reads,
        "scope":"offline real mailbox/runtime/executor with synthetic upstream/native/time",
        "R03":"not_run","full_H12":"not_run","all29":"not_run"},f,indent=2)
raise SystemExit(0 if result.wasSuccessful() and not ATTEMPTS else 1)
