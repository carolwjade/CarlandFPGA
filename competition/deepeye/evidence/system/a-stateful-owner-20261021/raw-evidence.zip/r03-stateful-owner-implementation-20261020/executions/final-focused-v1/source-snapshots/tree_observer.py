"""Same quota inventory, allowing only entries that disappear during traversal.

The reviewed runner still enforces its original bytes/entries/time/memory caps.
This is a transient filesystem observer, not a modification of process control.
"""
import os
from pathlib import Path
import stat


def measure_tree(root, *, require, check_no_links):
    if not os.path.lexists(root):
        return 0,0
    check_no_links(root)
    total,count,stack = 0,0,[Path(root)]
    while stack:
        current=stack.pop()
        try:
            entries=os.scandir(current)
        except FileNotFoundError:
            if os.path.lexists(current):
                raise  # Recreated path is not evidence of an absent entry.
            continue
        with entries:
            for item in entries:
                # Bound observed entries even if they vanish before stat.
                count+=1
                require(count<=100000,"watched tree scan cap")
                try:
                    s=os.lstat(item.path)
                except FileNotFoundError:
                    if os.path.lexists(item.path):
                        raise
                    continue
                require(not stat.S_ISLNK(s.st_mode) and not getattr(s,"st_file_attributes",0)&0x400,
                        "watched tree link/reparse")
                if stat.S_ISDIR(s.st_mode):
                    stack.append(Path(item.path))
                else:
                    require(stat.S_ISREG(s.st_mode) and s.st_nlink==1,"watched tree nonregular/hardlink")
                    total+=s.st_size
    return total,count
