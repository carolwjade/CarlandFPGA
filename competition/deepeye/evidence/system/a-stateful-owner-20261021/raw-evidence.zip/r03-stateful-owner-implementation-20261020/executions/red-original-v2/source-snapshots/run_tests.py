"""Reviewed hidden JobObject wrapper; no product/native actor execution."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
PRIOR = D.parent / "r02-install-recipe-fix-20261020"
PINS = {"win_job.py":"127daf70b2aa6cf3e7a299978596766fc310d191d13f6a2165626f719889052d",
    "boundary.py":"dc27aea6104424fbb2ee9109bb5e2adaf90684161e9d43bd2636b5ea4d6f2908"}
for name,sha in PINS.items():
    assert hashlib.sha256((PRIOR / name).read_bytes()).hexdigest() == sha
sys.path.insert(0,str(PRIOR))
from win_job import run_bounded
from boundary import save_new

run_id,*tests = sys.argv[1:]
assert run_id.isascii() and run_id.replace("-","").isalnum() and tests
executions = D / "executions"
executions.mkdir(exist_ok=True)
for prior in executions.iterdir():
    if (prior / "prelaunch-refusal.json").exists():
        refusal = json.loads((prior / "prelaunch-refusal.json").read_bytes())
        assert refusal["process_created"] is False and not (prior / "process").exists()
        continue
    receipt = json.loads((prior / "terminal.json").read_bytes())
    assert receipt["all_processes_terminated"] and receipt["active_processes_final"] == 0
    assert all(r["signaled"] and r["wait_result"] == 0 for r in receipt["held_members"])
run = executions / run_id
run.mkdir()
snap = run / "source-snapshots"
snap.mkdir()
baseline = json.loads((D / "baseline.json").read_bytes())
for name in baseline["allowed_product_paths"]:
    p = ROOT / ".local/deepeye-implementation-a/competition/deepeye" / name
    if p.exists():
        target = snap / name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(p.read_bytes())
for name in ("run_tests.py","test_worker.py","red_controls.py"):
    (snap / name).write_bytes((D / name).read_bytes())
argv = [str(ROOT / ".local/venv/Scripts/python.exe"),"-I","-S","-B","-X","utf8",
    str(D / "test_worker.py"),str(run),*tests]
env = {k:v for k,v in os.environ.items() if k.upper() in ("SYSTEMROOT","WINDIR")}
env.update(PATH="",PYTHONDONTWRITEBYTECODE="1",PYTHONNOUSERSITE="1",
    TEMP=str(run),TMP=str(run),OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1")
budget = {"seconds":50,"job_memory_bytes":512*1024**2,
    "process_memory_bytes":256*1024**2,"active_processes":4,
    "stdout_bytes":2*1024**2,"stderr_bytes":2*1024**2,
    "tree_bytes":64*1024**2,"tree_entries":3000,"free_reserve_bytes":10*1024**3}
save_new(run / "started.json",{"argv":argv,"cwd":str(D),"environment":env,
    "budget":budget,"runner_pins":PINS,"started_utc":datetime.now(timezone.utc).isoformat(),
    "scope":"offline synthetic upstream/native only; real final software authority"})
result = run_bounded(argv,env,D,run / "process",budget,[D])
save_new(run / "terminal.json",result)
print(json.dumps({"run_id":run_id,"exit_code":result["exit_code"],
    "all_processes_terminated":result["all_processes_terminated"],
    "receipt":str(run / "terminal.json")}))
raise SystemExit(0 if result["exit_code"] == 0 else 1)
