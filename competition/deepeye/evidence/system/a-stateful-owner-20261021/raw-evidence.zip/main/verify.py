import asyncio
from datetime import datetime, timezone
import hashlib
import json
import marshal
from pathlib import Path
import stat
import sys

D = Path(__file__).resolve().parent
OUT = D.parent
ROOT = D.parents[2]
PRODUCT = ROOT / ".local/deepeye-implementation-a/competition/deepeye"
CONTRACT = "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
A = OUT / "r03-stateful-owner-implementation-20261020"
R = OUT / "r03-stateful-owner-independent-20261021"

def load(p):
    return json.loads(p.read_bytes())

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def check_manifest(folder, expected):
    assert sha(folder / "artifact-manifest.json") == expected
    rows = load(folder / "artifact-manifest.json")["files"]
    for rel, pin in rows.items():
        p = folder / rel
        st = p.lstat()
        assert p.resolve().is_relative_to(folder.resolve())
        assert stat.S_ISREG(st.st_mode)
        assert not getattr(st, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT
        assert st.st_size == pin["bytes"] and sha(p) == pin["sha256"], rel
    return len(rows)

async def main():
    scope = load(ROOT / "docs/competition/deepeye-2026/immutable_scope.json")
    canonical = json.dumps(scope["requirements"], ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    assert hashlib.sha256(canonical).hexdigest() == CONTRACT
    transfer = load(ROOT / ".planning/deepeye-desktop-handoff-20261015/transfer.json")
    assert transfer["status"] == "active" and transfer["director_generation"] == 2
    assert transfer["new_director_thread_id"] == "01a13d7e-dcf1-7272-a738-a637dd62ff9d"
    groups = [
        (A, "9547bd821046dd4a349b75df099009022f2b77bbf86b7b335b2a937baa0bae0f", "child-b4ad57212b1943f09f34fab01700abde"),
        (R, "613d49c871da889ce877e0385f825622e0c356da9527df00de9310bbdd5427a6", "child-2c35d0e9ff2342cf9ec2be5f3732c179"),
    ]
    verified = {}
    sys.path.insert(0, str(ROOT))
    from fpga_mesh.child_control import LocalControlFileClient
    client = LocalControlFileClient(ROOT / ".local/deployment/node-a/.local/node-a/main-control.json")
    for folder, expected, job_id in groups:
        count = check_manifest(folder, expected)
        job = await client.call("job", {"job_id": job_id})
        assert job["status"] == "completed" and job["terminal"]
        assert job["result"]["text"] == (folder / "final-result.txt").read_text(encoding="utf-8")
        verified[folder.name] = dict(manifest_sha256=expected, files=count, job_id=job_id,
                                    completed=True, terminal=True, exact_result=True,
                                    result_sha256=sha(folder / "final-result.txt"))
    sources = load(A / "seal-result.json")["product_after"]
    assert len(sources) == 5
    for rel, pin in sources.items():
        p = PRODUCT / rel
        assert p.stat().st_size == pin["bytes"] and sha(p) == pin["sha256"], rel
    controls = load(R / "control-01/test-result.json")
    terminal = load(R / "control-01/terminal.json")
    assert controls["testsRun"] == 8 and controls["successful"]
    assert not any(controls[k] for k in ["failures", "errors", "skipped", "prohibited_attempts"])
    assert terminal["exit_code"] == 0 and terminal["active_processes_final"] == 0
    assert terminal["all_processes_terminated"] and len(terminal["held_members"]) == 3
    assert all(x["signaled"] and x["wait_result"] == 0 for x in terminal["held_members"])
    cached = 0
    for name, pin in controls["imports_and_reads"].items():
        p = Path(name)
        assert p.stat().st_size == pin["bytes"] and sha(p) == pin["sha256"], name
        if p.suffix == ".pyc":
            code = marshal.loads(p.read_bytes()[16:])
            source = Path(code.co_filename)
            if source.is_file():
                assert code == compile(source.read_bytes(), code.co_filename, "exec", dont_inherit=True, optimize=0)
                cached += 1
    result = dict(utc=datetime.now(timezone.utc).isoformat(), source_groups=verified,
                  product_files=sources, independent_controls=8, cached_source_equivalence=cached,
                  independent_terminal=terminal, requirements_sha256=CONTRACT,
                  adoption="bounded stateful owner integration",
                  historical_red_correction="Original combined refusal/no-commit assertion failed; numeric commit alone is not established.",
                  production_factory="closed", R03="not_run", full_H12="not_run", all29="not_run")
    with (D / "main-verification.json").open("x", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(json.dumps({"author_files": verified[A.name]["files"], "review_files": verified[R.name]["files"],
                      "source_files": len(sources), "independent_controls": 8, "exact_original_terminals": True}))

asyncio.run(main())
