import ctypes, collections, datetime
from capture import *

def load(p):return json.loads(p.read_bytes())
assert not (OUT/'report.md').exists() and not (OUT/'result.json').exists(),'final reports already frozen'
boundary=load(OUT/'boundary.json'); identity=load(OUT/'api-identity.json'); tree=load(OUT/'git-tree-identity.json')
saved=load(OUT/'saved-evidence-audit.json'); sim=load(OUT/'independent-simulation.json'); vec=load(OUT/'vectors.json')
mapping=load(OUT/'ascii-mapping.json'); context=load(OUT/'published-context-identity.json')
assert saved['status']==sim['status']=='passed'
assert sim['checks']==vec['checks']==196 and sim['mismatches']==0 and vec['unique_pairs']==189
assert mapping['removed'] and mapping['absent_after'] and not pathlib.Path(mapping['drive']+'/').exists()
assert tree['expected_head_current_at_readback'] and context['requirements_sha256']==boundary['requirements_sha256']
rtl=WORK/'head/competition/deepeye/fpga/transport/deepeye_crc16_byte.sv'
assert sha(rtl.read_bytes())==sim['rtl_sha256']==sha((WORK/'sim-ascii-02/dut.sv').read_bytes())
assert sha((WORK/'independent_tb.sv').read_bytes())==sim['tb_sha256']
assert sha((WORK/'vectors.hex').read_bytes())==sim['vectors_sha256']==vec['vector_file_sha256']
command_count=0
for meta in RAW.glob('*.command.json'):
    record=load(meta); label=meta.name.removesuffix('.command.json')
    for stream in ('stdout','stderr'):
        assert sha((RAW/(label+'.'+stream)).read_bytes())==record[stream+'_sha256']
    command_count+=1
for rec in load(OUT/'archive-members.json'):
    assert sha((WORK/'archive'/rec['path']).read_bytes())==rec['sha256']
dump(OUT/'verification.json',dict(status='passed',raw_command_receipts_verified=command_count,
    simulation_source_hash_match=True,archive_members_rechecked=355,mapping_removed=True,
    result_scope='Review evidence only; main owns acceptance',at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))

report=f'''# CRC27 独立审查（冻结版）

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`；工作 `A-B-CRC27-INDEPENDENT-20261024-v1`；执行者 `/root/b_crc27_review`；job `child-10754011c366422f86f76029b153674c`。父主为 Gen3 director `01a16988-bdcb-70e1-ae10-1304b5cf7875`。租约已 validate 且 `execution_allowed=true`。本报告提交审查证据，正式接收、发布和同 PR 反馈由 A/root 决定。

本轮指定 CRC byte update 范围内未发现二进制功能矛盾。新增 ModelSim SE-64 2020.4 实际比较 **196 次／189 组不同输入，0 mismatch**；篡改期望值负控实际检测到数字差异并退出 1。此数量不是全空间穷尽。

## 固定身份与获取方式

| 对象 | 本轮核验值 |
|---|---|
| PR30 head | `11e24d80ebf2acf822a7b45d3c3c346eb2a4d7cc` |
| source commit／head 父提交 | `779e66ddc7d454ee997f449f6ee5c86063a97324` |
| operation | `B-DEEPEYE-CRC16-BYTE-20261024-27` |
| request SHA256 | `2addd741faa481897314cde62d1f3f0abe9169b4eef1404208759066d9125013` |
| handoff manifest SHA256 | `9baff4320ef1d28cbd356d68263ea7ba952206535accca669c007e725dec00ba` |
| RTL SHA256 | `8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f` |
| raw-evidence.tar.gz SHA256 | `68dc3216599f0ed886b97e6d8a889b7d4c9c39da1e48fc6d91a0f7f9440deb97` |

沿用原 Git/gh 认证，以 `gh api` 从 immutable head 下载指定文件，在本任务隔离目录按 `SHA1("blob <length>\\0" + bytes)` 核验每个下载 blob，再核验交接 SHA256 与长度。未执行 git fetch、未取得完整 checkout，未把本原语仿真外推为整个 top 状态。PR30 在获取和审查后读回时均为指定 head。

12 项 manifest artifacts 全部核对原始字节、长度及 Git blob；input 与 manifest 的 request/artifacts/stages 相同，request 按 UTF-8、ensure_ascii=False、sort_keys=True、紧凑分隔符实算。6 项 SOURCE_BINDING 源文件均与 source commit 和 head 的 blob 一致。额外下载 head 的 immutable_scope.md/json 及 handoff README；发布 scope 的 H01–H15 canonical SHA256 实算为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，全部要求保持不变。

还从完整递归树元数据逐级重建 Git tree 对象：head 根树 `051241e57a91c54cbc692008e7a06ffa0397449a`（3231 个 tree）与 source 根树 `5d6dfac384c044801a0ee5362d6d0cfef7922243`（3230 个 tree）匹配。head 与 source 的文件差异仅此 operation 的 handoff README/input/manifest。提交本身为 unsigned，commit 身份依赖现有认证 HTTPS API，未重建 raw commit 对象。初次辅助树校验错误地假定以 commit ref 请求时顶层 sha 必为 tree sha；失败脚本、退出 1 和输出已保留。改为请求 commit 内指定的 exact tree SHA 后，返回条目与原元数据完全相同，逐级对象复算通过，未绕过原失败。

## 保存证据复核

`RAW_INDEX.json` 与解包成员集合精确相等：**355 个普通文件、2,539,059 原始字节**；逐项长度/SHA256、无重复成员、archive/index bundle 哈希均核对。归档仅解包到本任务目录，未执行其中脚本。`saved-evidence-audit.json` 给出实际核查细目。

保存的作者 attempt-03-final 与主修复后的 attempt-main-qualified-04 均有 7 个 CASE_END、总计 198437 checks、唯一 TB_END pass、0 errors/0 warnings；各自 6 个进程回执的 stdout/stderr 哈希及源快照核对。真实 vlib work/vlog/vsim 各退出 0，历史 vlib -version 退出 1 保持为该安装的 usage 探针。

保存的主 exhaustive-01 日志明确记录 16777216 pairs、9 prefixes、standard=10673 和 MAIN_PASS；DUT、TB、表及 5 个工具命令回执的哈希一致。oracle-02 的成功 receipt 记录 direct binascii pairs=16777216、表 hash `364ef72ec21a070f1f8c4641f171b53bb488c0ca3c1b06d4704cd532f562ce66`，65536 表行及 simulation 输入表一致。preinspection 标记仅按生产者保存记录归属，未冒称本轮独立观测到其当时操作顺序。

三个保存的编译变体各有实际数字反例：discard_seed `(seed=0,byte=0,got=57840,want=0)`；wrong_first_bit `(0,1,33193,4129)`；wrong_poly `(0,1,32773,4129)`。各自源/表/命令/原始输出与 RESULT 一致；保留 expected fatal 和 Errors:1，不把日志判定器接受 mutant 误记为 DUT 功能通过。

保存的 runner 修复证据保留原 runner `ea5288522976f718a5669834afc144c7d4643e92452347a68cbc5e55f51bc4ab`、原 accepted-negative、真实 positive、6 个 synthetic-negative fixtures，以及新实际 CLI 的 exit0 receipt。最终 runner `f54f6d5f5e50a467f094d0bed0873dcb7cb5abd1fed05be71f0b897b74fddcb7` 添加 CASE_END checks 总和约束，且是 qualified-04 实际源快照。作者 RESULT 早于该修复，已分开归属。旧作者首编译 vlog-2892/exit2、主 oracle-01 的 binascii.__file__ AttributeError／无成功 count receipt 全部保留；未改写为通过。

以上 16777216 对穷尽、作者 7 cases、主 mutants/判定器 probes 均为**保存证据复核**，本轮没有重跑。作者 sampled constants 和旧主 exhaustive 表均源于 binascii，不能称为两个算法独立实现。

## 新增数学控制与真实仿真

本轮 `generate_vectors.py` 自建逐位 GF(2) 多项式长除法 oracle：对 `((seed << 8) XOR (byte << 16))`，从 degree 23 至 16 逐位除以 `0x11021`（x^16+x^12+x^5+1），取 16 位余数。未导入 binascii、作者 oracle 或旧表，也未使用库 CRC 输出生成期望值。它与 RTL、binascii 共享同一数学多项式；代码路径不同。向量在读过源码后生成，不声称 preinspection freeze。

| 新增输入类别 | 比较次数 |
|---|---:|
| 全零及 24 位输入基向量 | 25 |
| 7 个 seed × 7 个 byte 边界／交替模式 | 49 |
| 相邻基向量异或组合 | 24 |
| 固定 xorshift32 seed=0xc27a2026 | 32 |
| 16 组三元叠加关系 | 48 |
| 123456789，seed FFFF 与 0000 的全部前缀 | 18 |
| 合计 | 196 |

前缀末值分别为 0x29B1、0x31C3。`vectors.json` 保留每个输入、期望值、类别与 16 组叠加关系；`vectors.hex` SHA256 为 `06c9e3d5af90507be18e4cf53570ba757545e7caaa9348249896f06b2a0c6536`。独立 testbench 只连 3 个公开端口，用四态不等比较捕获实际 X 输出，对每行等待 1ns。

实际工具 `C:/modeltech64_2020.4/win64`，vlog/vsim 回报 2020.4。真实命令在新 work library 中编译 `dut.sv independent_tb.sv`，vlib/vlog/vsim 退出均 0；vlog 与 vsim 都显示 Errors:0, Warnings:0，唯一 INDEPENDENT_PASS checks=196。随后同一编译 DUT 用单行错误期望 `0000,00 -> 0001` 做新负控，实际得到 `actual=0000 expected=0001`，fatal、Errors:1、退出 1，且没有 PASS。

首次中文真实路径的 vlog 退出 232，报 sqlite3_open unable to open database、vlog-9；原命令/stdout/stderr 全部保留。之后检查 V: 未被盘符或映射占用，仅将 V: 映射到本任务 `.local/deepeye-b-crc27-review-20261024`，以 ASCII cwd 完成新仿真；finally 移除 V: 并确认不存在，`ascii-mapping.json` 与 subst 前后原始输出保留。未映射仓库整体。复现需使用新的本任务输出目录或重新选取经检查的临时映射，不复用旧仿真结果目录。

## 源审与边界

RTL 是 8 个命名组合步骤，明确处理 data[7] 到 data[0]；无 clock/reset/storage/handshake/seed policy。对二进制值，单步为 `T(s,d)=(s<<1 mod 2^16) XOR ((s[15] XOR d)*0x1021)`，是 GF(2) 线性映射；8 次复合仍对 24 输入位线性。全零和 24 基向量有明确数学依据，附加组合／边界输入用于检查连线与组合行为。此为源码代数论证与小样本实际仿真，未运行 elaborated RTL 形式等价证明。

只声明二进制 byte-update。X/Z 输入语义未验证；源码 if 遇未知条件会取 else，不能承诺未知值完整传播。实际传播延迟、组合毛刺、综合／实现／时序、CDC/RDC 均未执行。没有 packet CRC/framing、解析／认证／freshness、控制闭环、板卡或 system 结论；B04、G03、R03、all29 和 full product 仍 not_run。A/root 独占板卡，本工作未访问板卡、串口、显示器、服务或凭据，未发送 peer/群/PR 评论，未派工，未修改产品文件。只写两个父主分配目录；并发主写入可能存在，保存 git status 快照而不把他人变化归到本工作。

原始命令与输出位于本证据目录 `raw/`；identity/artifact/archive/saved-audit/source-audit/independent-simulation/verification JSON 可逐层核对。最终 `result.json`、`evidence-manifest.json` 与 `final_hashes.json` 冻结后提交 native_complete；终态以其持久回执为准。
'''
(OUT/'report.md').write_text(report,encoding='utf-8',newline='\n')
result=dict(schema=1,status='review_completed_evidence_submitted_to_root',task_id='DEEPEYE-IMPLEMENTATION-20261014',task_version=1,
    work_id='A-B-CRC27-INDEPENDENT-20261024-v1',job_id=boundary['job_id'],canonical_agent_id=boundary['canonical_agent_id'],
    tested_commit=HEAD,source_commit=SOURCE,operation_id=OP,request_hash=ident['expected_head'] and '2addd741faa481897314cde62d1f3f0abe9169b4eef1404208759066d9125013',
    manifest_sha256='9baff4320ef1d28cbd356d68263ea7ba952206535accca669c007e725dec00ba',requirements_sha256=boundary['requirements_sha256'],H01_H15_preserved=True,
    identity=dict(acquisition='Authenticated gh API, exact tree and downloaded Git blob verification',full_checkout=False,head_tree=tree['head']['tree_sha1'],source_tree=tree['source']['tree_sha1'],raw_commit_reconstructed=False),
    evidence_integrity=dict(manifest_artifacts=12,archive_members=355,archive_raw_bytes=2539059,source_binding_files=6),
    saved_evidence=dict(author_runs_audited=2,main_runs_audited=4,old_direct_library_pairs=16777216,old_rtl_pairs=16777216,old_suites_rerun=False,
        binascii_independence='Author sampled library and old main full oracle share binascii; new oracle is serial polynomial division without binascii'),
    independent_simulation=dict(tool='ModelSim SE-64 2020.4',checks=196,unique_pairs=189,mismatches=0,compile_exit=0,simulation_exit=0,
        negative_control_exit=1,exhaustive=False,oracle='new GF(2) serial long division by 0x11021',rtl_sha256=sim['rtl_sha256'],tb_sha256=sim['tb_sha256'],vectors_sha256=sim['vectors_sha256']),
    failures_preserved=['author vlog-2892 exit2','old oracle binascii.__file__ failure','original accepted-negative runner fixture','local Unicode vlog exit232','auxiliary tree-ref assertion exit1'],
    mapping_cleanup=mapping,blocking_findings=[],acceptance_owner='A/root',formal_acceptance='not_performed_by_child',
    not_run=['B04','G03','R03','all29','full_product','synthesis','implementation','timing','CDC_RDC','board','system','packet_CRC','control'],
    report_path=str((OUT/'report.md').relative_to(ROOT)),report_sha256=sha((OUT/'report.md').read_bytes()),
    evidence_manifest_path=str((OUT/'evidence-manifest.json').relative_to(ROOT)),native_completion_receipt_path=str((OUT/'native-complete.json').relative_to(ROOT)),
    file_ownership=boundary['ownership'],product_modified=False,board_accessed=False,external_messages_sent=False)
dump(OUT/'result.json',result)

included=[];excluded=[]
for base in (WORK,OUT):
    for p in sorted(base.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(ROOT).as_posix(); parts=p.relative_to(base).parts
        reason=None
        if p.name=='lease.private.json':reason='private lease credential'
        elif '__pycache__' in parts:reason='Python cache'
        elif parts and parts[0].startswith('sim-') and any(x in ('work','temp') for x in parts[1:]):reason='simulator library/temp scratch; raw receipts and exact inputs retained'
        elif p.name in ('evidence-manifest.json','final_hashes.json','native-complete.json'):reason='self/reference or later completion receipt'
        if reason:excluded.append(dict(path=rel,reason=reason));continue
        b=p.read_bytes();included.append(dict(path=rel,bytes=len(b),sha256=sha(b)))
dump(OUT/'evidence-manifest.json',dict(schema=1,files=included,excluded=excluded,files_count=len(included),scope='Frozen review report, result, downloaded exact input bytes, expanded archive and raw command evidence'))
hashes={p.name:dict(path=str(p.relative_to(ROOT)).replace('\\','/'),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in (OUT/'report.md',OUT/'result.json',OUT/'evidence-manifest.json')}
dump(OUT/'final_hashes.json',hashes)
print(json.dumps(hashes,ensure_ascii=False,indent=2))
