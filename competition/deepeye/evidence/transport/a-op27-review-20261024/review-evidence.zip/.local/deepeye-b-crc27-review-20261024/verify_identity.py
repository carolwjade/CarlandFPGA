from capture import *

def tree_hash(d, expected):
    # Reconstruct Git tree objects from complete recursive API metadata.
    assert not d['truncated']
    nodes={x['path']:x for x in d['tree']}
    trees=['']+[x['path'] for x in d['tree'] if x['type']=='tree']
    computed={}
    for parent in sorted(trees,key=lambda p:p.count('/')+(1 if p else 0),reverse=True):
        children=[]
        for path,item in nodes.items():
            if path.rpartition('/')[0]!=parent: continue
            name=path.rpartition('/')[2]
            oid=item['sha']
            if item['type']=='tree': assert computed[path]==oid
            mode=item['mode'].lstrip('0')
            children.append((name.encode()+(b'/' if item['type']=='tree' else b''),mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid)))
        raw=b''.join(x[1] for x in sorted(children,key=lambda x:x[0]))
        actual=hashlib.sha1(f'tree {len(raw)}\0'.encode()+raw).hexdigest()
        declared=expected if parent=='' else nodes[parent]['sha']
        assert actual==declared,(parent,actual,declared)
        computed[parent]=actual
    return dict(tree_sha1=computed[''],trees_verified=len(trees),entries=len(nodes),full_file_checkout=False)

results={}
for label in ('head','source'):
    commit=json.loads((RAW/f'commit-{label}.stdout').read_bytes())
    original=json.loads((RAW/f'tree-{label}.stdout').read_bytes())
    # GitHub can echo a commit ref in top-level sha when it resolves the tree.
    # Ask for the exact tree object ID and compare the returned entry metadata.
    d=api(f'tree-{label}-exact',f'git/trees/{commit["tree"]["sha"]}?recursive=1')
    assert d['sha']==commit['tree']['sha']
    assert d['tree']==original['tree']
    results[label]=tree_hash(d,commit['tree']['sha'])
    results[label]['commit_api_sha']=commit['sha']
    results[label]['commit_authenticity']='Existing authenticated gh HTTPS API; unsigned commit, no raw commit object reconstruction'
head=json.loads((RAW/'tree-head.stdout').read_bytes())
source=json.loads((RAW/'tree-source.stdout').read_bytes())
hi={x['path']:x['sha'] for x in head['tree'] if x['type']=='blob'}
si={x['path']:x['sha'] for x in source['tree'] if x['type']=='blob'}
results['head_source_file_changes']=[dict(path=p,source=si.get(p),head=hi.get(p)) for p in sorted(set(hi)|set(si)) if hi.get(p)!=si.get(p)]
pr=api('pr30-after-review','pulls/30')
results['pr_head_after_review']=pr['head']['sha']
results['expected_head_current_at_readback']=pr['head']['sha']==HEAD
dump(OUT/'git-tree-identity.json',results)
command('product-status-after',['git','status','--porcelain=v1'],ROOT/'.local/deepeye-implementation-a')
command('root-status-after',['git','status','--porcelain=v1'])
dump(OUT/'source-audit.json',dict(rtl_sha256=sha((WORK/'head/competition/deepeye/fpga/transport/deepeye_crc16_byte.sv').read_bytes()),
    scope='Pure binary combinational CRC16 state/byte update; no acceptance decision',
    structure=['3 public ports: crc_in16, data_in8, crc_out16','8 explicitly chained calls process data[7] to data[0]',
        'function writes both branches; continuous assignments only; no clock, reset, counter, memory, parameter or file input'],
    binary_algebra='T(s,d) = (s<<1 mod 2^16) XOR ((s[15] XOR d)*0x1021). This is linear over GF(2); composition of eight steps is linear in the 24 input bits.',
    oracle_algebra='Polynomial remainder of ((seed<<8) XOR (byte<<16)) divided serially by 0x11021. 24 basis vectors and zero test the linear generators; sampled superpositions additionally check combinations.',
    qualification='Source-level algebraic reasoning, not a formal elaborated RTL equivalence run. 196 actual comparisons/189 unique pairs do not constitute exhaustive simulation.',
    uncovered=['X/Z four-state input semantics: an X-valued if condition chooses the else branch, so unknown propagation is not guaranteed',
        'Real propagation delay/glitches, synthesis, implementation and timing',
        'Packet CRC framing/byte order/seed policy, CRC error detection guarantees, parser, authentication, freshness, control, board and system'],
    modifications='No product changes, no external messages, no board/serial, no service or credential changes. Files written only under the two assigned review directories. Concurrent root/product status snapshots retained without assigning other writers changes to this review.'))
print(json.dumps(results,ensure_ascii=False))
