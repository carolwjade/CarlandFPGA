onerror {quit -code 2}
onbreak {quit -code 1}
run -all
quit -code 0
