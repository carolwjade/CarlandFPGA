import re
from capture import *

A=WORK/'archive'
pub=WORK/'head/competition/deepeye/evidence/transport/crc16-byte-20261024-27/publication'
def load(p): return json.loads(p.read_bytes())
index=load(pub/'RAW_INDEX.json')['files']
actual={x['path']:x for x in load(OUT/'archive-members.json')}
assert len(index)==len(actual)==355 and set(index)==set(actual)
for p,meta in index.items():
    assert meta['bytes']==actual[p]['bytes'] and meta['sha256']==actual[p]['sha256']
bundle=load(pub/'BUNDLE_MANIFEST.json')
assert sha((pub/bundle['archive']).read_bytes())==bundle['sha256']
assert sha((pub/bundle['index']).read_bytes())==bundle['index_sha256']
assert sum(x['bytes'] for x in actual.values())==bundle['raw_bytes']==2539059
ident=load(OUT/'artifact-identity.json')
binding=load(pub/'SOURCE_BINDING.json')
headpaths={x['repository_path']:x for x in ident['records']}
for p,hash in binding['sources'].items():
    assert headpaths[p]['sha256']==hash and headpaths[p]['same_blob_at_source_commit']

# Check original process receipts and exact bytes, without re-executing old suites.
author=[]
for attempt in ('attempt-03-final','attempt-main-qualified-04'):
    d=A/'author'/attempt
    summary=load(d/'summary.json')
    assert summary['passed'] and summary['source_unchanged_after_run']
    receipts=[]
    for jf in sorted((d/'commands').glob('*/command.json')):
        c=load(jf)
        assert not c.get('timed_out') and not c.get('process_error')
        for stream in ('stdout','stderr'):
            b=(jf.parent/(stream+'.bin')).read_bytes()
            assert sha(b)==c[stream+'_sha256']
        assert c['exit_code']==(1 if jf.parent.name=='tool-versions_vlib.exe' else 0)
        receipts.append(dict(name=jf.parent.name,exit_code=c['exit_code']))
    assert len(receipts)==6
    raw=(d/'vsim-log.txt').read_text(encoding='utf-8')
    rows=[x[2:] if x.startswith('# ') else x for x in raw.splitlines()]
    cases=[x for x in rows if x.startswith('CASE_END')]
    checks=sum(int(re.search(r'checks=(\d+)',x)[1]) for x in cases)
    assert len(cases)==7 and checks==198437
    assert rows.count('TB_END pass')==1 and 'Errors: 0, Warnings: 0' in rows
    assert not any('** Error' in x or '** Warning' in x or '** Fatal' in x for x in rows)
    basenames=dict(candidate='crc16_byte_candidate.md',rtl='deepeye_crc16_byte.sv',runner='run_crc16_byte.py',tb='tb_crc16_byte.sv')
    for role,hash in summary['source_hashes'].items():
        assert sha((d/'inputs/author-source'/basenames[role]).read_bytes())==hash
    assert summary['source_hashes']['rtl']==binding['sources']['competition/deepeye/fpga/transport/deepeye_crc16_byte.sv']
    author.append(dict(attempt=attempt,case_rows=cases,total_checks=checks,process_receipts=receipts,source_snapshots_verified=4))

main=[]
for name in ('exhaustive-01','mutants-01/discard_seed','mutants-01/wrong_first_bit','mutants-01/wrong_poly'):
    d=A/'main'/name; result=load(d/'RESULT.json')
    assert result['accepted']
    for inp,meta in result['inputs'].items(): assert sha((d/inp).read_bytes())==meta['sha256']
    for c in result['commands']:
        assert c['returncode']==0 and not c['timeout']
        for stream in ('stdout','stderr'): assert sha((d/(c['name']+'.'+stream+'.bin')).read_bytes())==c[stream+'_sha256']
    raw=(d/'vsim.stdout.bin').read_text(encoding='utf-8')
    rows=[x[2:] if x.startswith('# ') else x for x in raw.splitlines()]
    if name=='exhaustive-01':
        assert rows.count('MAIN_BEGIN pairs=16777216')==rows.count('MAIN_PASS')==1
        assert rows.count('MAIN_STATS pairs=16777216 prefix=9 standard=10673')==1
        assert 'Errors: 0, Warnings: 0' in rows and not result['numeric_counterexamples']
        assert sha((d/'dut.sv').read_bytes())==binding['sources']['competition/deepeye/fpga/transport/deepeye_crc16_byte.sv']
    else:
        mismatch=[x for x in rows if x.startswith('MAIN_MISMATCH')]
        assert mismatch==result['numeric_counterexamples'] and len(mismatch)==1
        assert '** Fatal: main numeric mismatch' in rows and 'Errors: 1, Warnings: 0' in rows and 'MAIN_PASS' not in rows
    main.append(dict(name=name,accepted_result=True,numeric_counterexamples=result['numeric_counterexamples'],command_receipts=len(result['commands'])))

freeze=load(A/'main/oracle-02/FREEZE.json')
assert freeze['actual_direct_library_pairs']==16777216
assert freeze['author_source_inspected'] is False
assert freeze['table_sha256']==sha((A/'main/oracle-02/oracle.hex').read_bytes())==sha((A/'main/exhaustive-01/oracle.hex').read_bytes())
assert len((A/'main/oracle-02/oracle.hex').read_text().splitlines())==65536
q=load(A/'main/qualification-01/RESULT.json')
final_runner=WORK/'head/competition/deepeye/tools/transport/run_crc16_byte.py'
assert q['final_runner_sha256']==sha(final_runner.read_bytes())
assert q['original_runner_sha256']==sha((A/'main/qualification-01/original_runner.py').read_bytes())
assert q['accepted'] and q['synthetic_negative_probes']==6 and q['saved_real_positive']==1 and q['new_cli']['exit']==0
positive=(A/'main/qualification-01/original_positive.bin').read_bytes()
negative=(A/'main/qualification-01/original_accepted_negative.bin').read_bytes()
assert positive==(A/'author/attempt-03-final/vsim-log.txt').read_bytes()
assert positive!=negative
for fixture in ('inflated_case','fake_end','duplicate_end','bad_summary','bad_stat','early_end'):
    assert (A/f'main/qualification-01/{fixture}.bin').is_file()
old=(A/'main/qualification-01/original_runner.py').read_text()
new=final_runner.read_text()
assert 'case_check_total' not in old and 'case_check_total != EXPECTED_CHECKS' in new
# Original failures remain preserved and correctly attributed.
failed_compile=load(A/'author/attempt-01-smoke/commands/simulation_02-vlog/command.json')
assert failed_compile['exit_code']==2
failed_output=(A/'author/attempt-01-smoke/commands/simulation_02-vlog/stdout.bin').read_bytes()
assert b'vlog-2892' in failed_output
oracle_failure=(A/'main/oracle-01/FAILURE.txt').read_text()
assert 'AttributeError' in oracle_failure and 'no saved successful' in oracle_failure.lower()
terminal=load(A/'main-control/wait.stdout.json')[0]
assert terminal['status']=='completed' and terminal['terminal'] and not terminal['stale']
assert terminal['job_id']==binding['author_job']
dump(OUT/'saved-evidence-audit.json',dict(status='passed',archive_members_verified=355,archive_raw_bytes_verified=2539059,
    source_binding_files_verified=len(binding['sources']),author=author,main=main,freeze=freeze,
    parser_qualification=dict(original_runner_sha256=q['original_runner_sha256'],final_runner_sha256=q['final_runner_sha256'],
        saved_positive=1,saved_negative_fixtures=6,new_cli_exit_recorded=0,scope='saved byte and source inspection only; old parser/suites not re-executed'),
    preserved_failures=dict(author_first_vlog_exit=2,author_first_vlog_diagnostic='vlog-2892',oracle_first_attempt='AttributeError binascii.__file__; no accepted count receipt'),
    author_terminal_record=dict(job_id=terminal['job_id'],status=terminal['status'],terminal=terminal['terminal'],updated_at=terminal['updated_at']),
    attribution='Old 16777216 direct-library pairs, 16777216 RTL pairs, 7-case author suites and mutants are producer evidence audited from saved bytes, not newly executed here'))
print(json.dumps(dict(status='passed',members=355,source_binding=6,author_saved_runs=2,main_saved_runs=4,original_failures_retained=True)))
