from pathlib import Path
import json,hashlib,subprocess,sys,importlib.util,time
R=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014');P=R/'competition/deepeye';M=P/'evidence/transport/crc16-byte-20261024-27/main';O=M/'mutants-01';O.mkdir(exist_ok=False)
rtl=P/'fpga/transport/deepeye_crc16_byte.sv';tb=P/'tests/rtl/transport/main_tb_crc16_byte.sv';run=P/'tools/transport/main_verify_crc16_byte.py';table=M/'oracle-02/oracle.hex';old=rtl.read_bytes();s=old.decode();rows=[]
for name,a,b in [('wrong_poly',"16'h1021","16'h8005"),('wrong_first_bit','crc_bit_step(crc_in,     data_in[7])','crc_bit_step(crc_in,     data_in[0])'),('discard_seed','crc_bit_step(crc_in,     data_in[7])',"crc_bit_step(16'hffff,   data_in[7])")]:
 assert s.count(a)==1;f=O/(name+'.sv');f.write_text(s.replace(a,b),encoding='utf-8',newline='\n')
 argv=[sys.executable,'-B','-X','utf8',str(run),'--rtl',str(f),'--tb',str(tb),'--table',str(table),'--out',str(O/name),'--mutant'];t=time.time();r=subprocess.run(argv,capture_output=True)
 (O/(name+'.stdout.bin')).write_bytes(r.stdout);(O/(name+'.stderr.bin')).write_bytes(r.stderr);row={'name':name,'argv':argv,'exit':r.returncode,'elapsed':time.time()-t,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()};rows.append(row);print(name,r.returncode);assert r.returncode==0
assert rtl.read_bytes()==old
spec=importlib.util.spec_from_file_location('main_crc_qual',run);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
valid=b'MAIN_BEGIN pairs=16777216\nMAIN_STATS pairs=16777216 prefix=9 standard=10673\nMAIN_PASS\nErrors: 0, Warnings: 0\n';probes=[]
cases=[('valid',valid,0,True),('badexit',valid,1,False),('fakepass',valid.replace(b'MAIN_PASS',b'NOT_MAIN_PASS_MARKER'),0,False),('duplicatepass',valid+b'MAIN_PASS\n',0,False),('dupe_stats',valid+b'MAIN_STATS pairs=16777216 prefix=9 standard=10673\n',0,False),('wrong_count',valid.replace(b'prefix=9',b'prefix=8'),0,False),('wrong_standard',valid.replace(b'10673',b'10674'),0,False),('fatal',valid+b'** Fatal: hidden\n',0,False),('warning',valid+b'** Warning: hidden\n',0,False),('bad_tally',valid.replace(b'Errors: 0',b'Errors: 1'),0,False),('early_pass',b'MAIN_PASS\n'+valid.replace(b'MAIN_PASS\n',b''),0,False)]
for name,raw,code,want in cases:
 got=m.classify(raw,code)['accepted'];assert got==want,(name,got);probes.append({'name':name,'got':got,'expected':want,'synthetic':True})
(O/'RESULT.json').write_text(json.dumps({'actual_compiled_mutants':rows,'synthetic_classifier_probes':probes,'accepted':True},indent=2)+'\n')
