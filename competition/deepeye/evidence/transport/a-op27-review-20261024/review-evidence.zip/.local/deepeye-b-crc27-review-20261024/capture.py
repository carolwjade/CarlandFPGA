from __future__ import annotations
import base64, hashlib, json, pathlib, subprocess, sys, time

ROOT = pathlib.Path(__file__).resolve().parents[2]
WORK = pathlib.Path(__file__).resolve().parent
OUT = ROOT / '.planning/deepeye-resume-20261018/b-crc27-independent-20261024'
RAW = OUT / 'raw'
RAW.mkdir(parents=True, exist_ok=True)
HEAD = '11e24d80ebf2acf822a7b45d3c3c346eb2a4d7cc'
SOURCE = '779e66ddc7d454ee997f449f6ee5c86063a97324'
OP = 'B-DEEPEYE-CRC16-BYTE-20261024-27'
MPATH = f'handoffs/b/{OP}/manifest.json'
REPO = 'repos/carolwjade/CarlandFPGA'

def sha(b): return hashlib.sha256(b).hexdigest()
def dump(p, x):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def command(label, args, cwd=ROOT, timeout=60):
    t = time.time()
    try:
        r = subprocess.run(args, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        code, stdout, stderr = r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired as e:
        code, stdout, stderr = 124, e.stdout or b'', e.stderr or b''
    (RAW / f'{label}.stdout').write_bytes(stdout)
    (RAW / f'{label}.stderr').write_bytes(stderr)
    dump(RAW / f'{label}.command.json', dict(argv=list(map(str,args)), cwd=str(cwd), exit_code=code, elapsed_seconds=time.time()-t,
        stdout_sha256=sha(stdout), stderr_sha256=sha(stderr)))
    if code: raise RuntimeError(f'{label} exit {code}')
    return stdout
def api(label, endpoint): return json.loads(command(label, ['gh', 'api', f'{REPO}/{endpoint}']))
def getblob(label, item, path):
    d = api(label, f'git/blobs/{item["sha"]}')
    assert d['encoding'] == 'base64'
    b = base64.b64decode(d['content'])
    actual = hashlib.sha1(f'blob {len(b)}\0'.encode() + b).hexdigest()
    assert actual == item['sha'] == d['sha']
    assert len(b) == item['size']
    path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(b)
    return dict(path=str(path.relative_to(ROOT)), repository_path=item['path'], git_blob_sha1=actual, bytes=len(b), sha256=sha(b))

def main():
    scope = json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text(encoding='utf-8'))
    h = sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
    assert h == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    transfer = json.loads((ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json').read_text(encoding='utf-8'))
    assert transfer['director_generation'] == 3 and transfer['new_director_thread_id'] == '01a16988-bdcb-70e1-ae10-1304b5cf7875'
    dump(OUT/'boundary.json', dict(task='DEEPEYE-IMPLEMENTATION-20261014/v1', work_id='A-B-CRC27-INDEPENDENT-20261024-v1',
        canonical_agent_id='/root/b_crc27_review', job_id='child-10754011c366422f86f76029b153674c', lease_validation_execution_allowed=True,
        director_generation=3, requirements_sha256=h, ids=[x['id'] for x in scope['requirements']], board_operator='A/root only',
        ownership=[str(WORK.relative_to(ROOT)),str(OUT.relative_to(ROOT))], full_checkout=False))
    command('git-version',['git','--version']); command('gh-version',['gh','--version'])
    command('root-status-before',['git','status','--porcelain=v1'])
    command('product-status-before',['git','status','--porcelain=v1'],ROOT/'.local/deepeye-implementation-a')
    pr=api('pr30','pulls/30')
    commits={key:api(f'commit-{key}',f'git/commits/{value}') for key,value in [('head',HEAD),('source',SOURCE)]}
    assert commits['head']['sha']==HEAD and commits['source']['sha']==SOURCE
    tree=api('tree-head',f'git/trees/{HEAD}?recursive=1')
    assert not tree['truncated']
    items={x['path']:x for x in tree['tree'] if x['type']=='blob'}
    source_tree=api('tree-source',f'git/trees/{SOURCE}?recursive=1')
    assert not source_tree['truncated']
    dump(OUT/'api-identity.json',dict(expected_head=HEAD, actual_pr_head=pr['head']['sha'], head_matches=pr['head']['sha']==HEAD,
        source_commit=SOURCE, head_tree=commits['head']['tree']['sha'], source_tree=commits['source']['tree']['sha'],
        head_parents=[x['sha'] for x in commits['head']['parents']], source_parents=[x['sha'] for x in commits['source']['parents']],
        acquisition='Authenticated existing gh API; Git blob identity verified for each downloaded path; no complete checkout and no complete-tree status assertion'))
    assert pr['head']['sha']==HEAD
    rec=getblob('blob-manifest',items[MPATH],WORK/'head'/MPATH)
    assert rec['sha256']=='9baff4320ef1d28cbd356d68263ea7ba952206535accca669c007e725dec00ba'
    manifest=json.loads((WORK/'head'/MPATH).read_text(encoding='utf-8'))
    ipath=f'handoffs/b/{OP}/input.json'
    rec2=getblob('blob-input',items[ipath],WORK/'head'/ipath)
    dump(OUT/'initial-blobs.json',[rec,rec2])
    print(json.dumps(dict(manifest=manifest,input=json.loads((WORK/'head'/ipath).read_text(encoding='utf-8'))),ensure_ascii=False,indent=2))

if __name__=='__main__': main()
