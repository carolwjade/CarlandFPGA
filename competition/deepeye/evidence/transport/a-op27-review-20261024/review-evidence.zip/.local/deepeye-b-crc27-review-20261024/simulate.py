import ctypes, os, re, shutil
from capture import *

TOOLS=pathlib.Path('C:/modeltech64_2020.4/win64')
rtl=WORK/'head/competition/deepeye/fpga/transport/deepeye_crc16_byte.sv'
for name in ('vlog','vsim'):
    command(f'local-{name}-version',[str(TOOLS/f'{name}.exe'),'-version'],WORK)
dump(OUT/'local-tool-binaries.json', {name:dict(path=str(TOOLS/f'{name}.exe'),sha256=sha((TOOLS/f'{name}.exe').read_bytes())) for name in ('vlib','vlog','vsim')})

def attempt(label, cwd):
    physical=WORK/label
    physical.mkdir(exist_ok=False)
    (physical/'temp').mkdir()
    for source,name in ((rtl,'dut.sv'),(WORK/'independent_tb.sv','independent_tb.sv'),(WORK/'vectors.hex','vectors.hex'),(WORK/'negative.hex','negative.hex')):
        shutil.copyfile(source,physical/name)
    (physical/'run.do').write_text('onerror {quit -code 2}\nonbreak {quit -code 1}\nrun -all\nquit -code 0\n',encoding='ascii')
    # Environment changes stay process-local and under this owned directory.
    previous={k:os.environ.get(k) for k in ('TEMP','TMP','TMPDIR')}
    for k in previous: os.environ[k]=str(cwd/'temp')
    try:
        command(label+'-vlib',[str(TOOLS/'vlib.exe'),'work'],cwd)
        compiled=command(label+'-vlog',[str(TOOLS/'vlog.exe'),'-sv','-work','work','dut.sv','independent_tb.sv'],cwd)
        assert b'Errors: 0, Warnings: 0' in compiled
        assert not re.search(rb'\*\*\s*(?:Error|Warning|Fatal)',compiled)
        good=command(label+'-vsim',[str(TOOLS/'vsim.exe'),'-c','-onfinish','stop','work.independent_tb','+vectors=vectors.hex','-do','do run.do'],cwd)
        lines=good.decode(errors='replace').splitlines()
        rows=[x[2:] if x.startswith('# ') else x for x in lines]
        assert rows.count('INDEPENDENT_BEGIN')==1
        assert rows.count('INDEPENDENT_PASS checks=196')==1
        assert not any('INDEPENDENT_MISMATCH' in x or '** Error' in x or '** Warning' in x or '** Fatal' in x for x in rows)
        # New negative control: corrupt only one expected value, preserve the exact DUT.
        try:
            command(label+'-negative',[str(TOOLS/'vsim.exe'),'-c','-onfinish','stop','work.independent_tb','+vectors=negative.hex','-do','do run.do'],cwd)
        except RuntimeError:
            receipt=json.loads((RAW/(label+'-negative.command.json')).read_bytes())
            negative=(RAW/(label+'-negative.stdout')).read_bytes()
            assert receipt['exit_code']==1
            assert b'INDEPENDENT_MISMATCH id=0 seed=0000 data=00 actual=0000 expected=0001' in negative
            assert b'INDEPENDENT_PASS' not in negative
        else: raise AssertionError('negative control unexpectedly passed')
        return dict(label=label,checks=196,mismatches=0,negative_control_detected=True,rtl_sha256=sha(rtl.read_bytes()),
            tb_sha256=sha((WORK/'independent_tb.sv').read_bytes()),vectors_sha256=sha((WORK/'vectors.hex').read_bytes()))
    finally:
        for k,v in previous.items():
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v

mapped=False; mapping=None
try:
    # Try the real owned path first; retain any Unicode tool failure verbatim.
    try:
        result=attempt('sim-unicode-01',WORK/'sim-unicode-01')
    except (RuntimeError,AssertionError) as e:
        dump(OUT/'unicode-attempt-failure.json',dict(error=repr(e),preserved=True))
        command('subst-before',['subst'],WORK)
        mask=ctypes.windll.kernel32.GetLogicalDrives()
        drive=next((x for x in 'VUTSRQPONMLKJIHGFED' if not mask&(1<<(ord(x)-ord('A'))) and not pathlib.Path(x+':/').exists()),None)
        assert drive is not None
        mapping=dict(drive=drive+':',target=str(WORK),logical_drive_mask_before=mask,not_occupied_before=True)
        dump(OUT/'ascii-mapping.json',mapping)
        command('subst-create',['subst',drive+':',str(WORK)],WORK); mapped=True
        command('subst-after-create',['subst'],WORK)
        result=attempt('sim-ascii-02',pathlib.Path(drive+':/sim-ascii-02'))
    dump(OUT/'independent-simulation.json',dict(status='passed',**result))
    print(json.dumps(result))
finally:
    if mapped:
        command('subst-remove',['subst',mapping['drive'],'/D'],WORK)
        after=command('subst-after-remove',['subst'],WORK)
        assert not pathlib.Path(mapping['drive']+'/').exists()
        mapping.update(removed=True,absent_after=True)
        dump(OUT/'ascii-mapping.json',mapping)
