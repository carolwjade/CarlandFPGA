from pathlib import Path
old=Path(__file__).with_name('freeze_oracle.py').read_text(encoding='utf-8')
old=old.replace('main/oracle-01','main/oracle-02')
old=old.replace("'binascii_binary':str(binascii.__file__),'binascii_sha256':hashlib.sha256(Path(binascii.__file__).read_bytes()).hexdigest()", "'binascii_origin':binascii.__spec__.origin,'runtime_executable':sys.executable,'runtime_executable_sha256':hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest()")
exec(compile(old,__file__,'exec'))
