`timescale 1ns/1ps
`default_nettype none
module independent_tb;
  logic [15:0] crc_in;
  logic [7:0] data_in;
  wire [15:0] crc_out;
  integer fd, n, row, id, count;
  logic [15:0] seed_value, expected;
  logic [7:0] data_value;
  reg [1023:0] vector_file;
  deepeye_crc16_byte dut(.crc_in(crc_in), .data_in(data_in), .crc_out(crc_out));
  initial begin
    if (!$value$plusargs("vectors=%s", vector_file)) $fatal(1,"missing vector path");
    fd=$fopen(vector_file,"r");
    if (!fd) $fatal(1,"cannot open vector file");
    count=0;
    $display("INDEPENDENT_BEGIN");
    while (!$feof(fd)) begin
      n=$fscanf(fd,"%d %h %h %h\n",id,seed_value,data_value,expected);
      if (n!=4) $fatal(1,"malformed vector row");
      crc_in=seed_value; data_in=data_value;
      #1;
      if (crc_out!==expected) begin
        $display("INDEPENDENT_MISMATCH id=%0d seed=%04h data=%02h actual=%04h expected=%04h",id,crc_in,data_in,crc_out,expected);
        $fatal(1,"independent numeric mismatch");
      end
      count=count+1;
    end
    $fclose(fd);
    $display("INDEPENDENT_PASS checks=%0d",count);
  end
endmodule
`default_nettype wire
