# Operation27: reusable CRC16/CCITT-FALSE byte update primitive

Task DEEPEYE-IMPLEMENTATION-20261014/v1; work B-CRC16-BYTE-20261024-27-v1;
operation B-DEEPEYE-CRC16-BYTE-20261024-27. Sole main
01a13b55-095b-7461-8dd5-5476a130bd82, turn01a16933-edc1-7022-8e5f-25b4561a4ea5.
Base b90fcbc58cdd7f3bf53fb6931dbdd47cd55afc8a. New nonoverlapping paths.
Prior frame-TX executor child-c263537e76b44ac199257f232d9676ce is actually
completed/nonstale; RX worker continues separately. Main retains acceptance.

Read/verify all H01-H15, DEEPEYE-HUMAN-LOCK-20261014/revision1 pinned
f5989cd5defce561f9ba98e6b18fc2682945f0a2, canonical requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Frozen design1011259415a0916054eb580687612580bc1e5f09. Physical board A-only.
Taskbook final section7 selects poly1021, initFFFF, no reflection, xorout0;
123456789 ->29B1. This primitive is only the mathematical update, not parser,
packet authorization, length/type/profile acceptance or public ABI freeze.
Search found no existing CRC RTL in competition/deepeye/fpga/*.sv recursively.

Implement parameter-free purely combinational module deepeye_crc16_byte with
input logic[15:0] crc_in, input logic[7:0] data_in, output logic[15:0] crc_out.
It returns the unreflected CRC state after exactly one byte, MSB first, poly
0x1021, 16-bit truncation. No initial seed, reset, clock, storage, complement,
handshake, packet or field-policy behavior inside this primitive. The caller
seeds0xFFFF at packet start; example repeated calls on ASCII123456789 ->29B1.
Use synthesizable fixed eight-step combinational logic, no delays/files/
dynamic allocation or giant ROM. Only binary input domain is claimed.

Root D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014.
Flash author owns only these competition/deepeye-relative paths:
fpga/transport/deepeye_crc16_byte.sv; fpga/transport/crc16_byte_candidate.md;
tests/rtl/transport/tb_crc16_byte.sv; tools/transport/run_crc16_byte.py;
evidence/transport/crc16-byte-20261024-27/author/.
Main owns main_tb/main_verify, main evidence, handoff/private scope. No old
TX/RX/frame/controller/shared-schema edits. No commit/push/peer/group/service/
credentials/config/SQL/queue/board. Do not read main tests/oracle/evidence.

Author real ModelSim10.7 tests: standard9byte check, zero-length seed handling
at caller, all256byte values across several seed states, all65536states with
selected bytes, multi-byte streaming concatenation and bit-order contrasts.
An author's own bit recurrence is not an independent external oracle; describe
it honestly. Main independently binds Python binascii.crc_hqx and exhausts
all16777216 state/byte pairs using a frozen linearity table, with separate
full direct-library sweep, plus actual compiled behavioral mutants.
Portable runner binds source snapshots/contract; Git HEAD context only and
private scope absence context only. Strict anchored unique markers, complete
consistent stats, real return codes/timeouts/diagnostics. No warning suppression.
Fresh attempt directory, preserve failures/commands/version/raw bytes/hashes;
TEMP/TMP/TMPDIR/caches/simulator cwd stay inside author evidence. Actual
thread/turn and RESULT.json required. All29/B04/R03/synth/impl/CDC_RDC/board/
system not_run. Concrete blockers [需桌面回合]/[需本人操作] to parent only.
Ordinary program event waiting; no model polling, READY or presence reports.
