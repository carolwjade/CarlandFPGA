from capture import *
from collections import Counter

# Serial polynomial division in GF(2). This uses no binascii and no author code.
# Multiplying seed by x^8 and placing data at degree 16 yields the dividend.
# Divide by x^16+x^12+x^5+1, scanning degrees 23 down to 16.
def oracle(seed, byte):
    dividend = (seed << 8) ^ (byte << 16)
    for degree in range(23,15,-1):
        if dividend & (1 << degree):
            dividend ^= 0x11021 << (degree-16)
    assert 0 <= dividend <= 0xffff
    return dividend

vectors=[]
def add(category, seed, byte):
    vectors.append(dict(id=len(vectors),category=category,seed=seed,byte=byte,expected=oracle(seed,byte)))
def add24(category, word): add(category,word>>8,word&255)
add('zero',0,0)
for i in range(24): add24('basis',1<<i)
for seed in (0,1,0x7fff,0x8000,0xffff,0xaaaa,0x5555):
    for byte in (0,1,0x7f,0x80,0xff,0xaa,0x55): add('boundary',seed,byte)
for i in range(24): add24('adjacent_basis_pair',(1<<i)^(1<<((i+1)%24)))
state=0xc27a2026
def next24():
    global state
    state ^= (state<<13)&0xffffffff; state ^= state>>17; state ^= (state<<5)&0xffffffff
    state &= 0xffffffff
    return state&0xffffff
for _ in range(32): add24('xorshift32',next24())
superposition=[]
for _ in range(16):
    x,y=next24(),next24(); ids=[]
    for word in (x,y,x^y): ids.append(len(vectors)); add24('superposition',word)
    assert vectors[ids[0]]['expected'] ^ vectors[ids[1]]['expected'] == vectors[ids[2]]['expected']
    superposition.append(ids)
prefixes=[]
for seed,final in ((0xffff,0x29b1),(0,0x31c3)):
    state_value=seed
    for byte in b'123456789':
        add('prefix',state_value,byte); state_value=vectors[-1]['expected']
    assert state_value==final
    prefixes.append(dict(initial=seed,final=state_value))
assert len(vectors)==196
dest=WORK/'vectors.hex'
dest.write_text(''.join(f'{v["id"]} {v["seed"]:04x} {v["byte"]:02x} {v["expected"]:04x}\n' for v in vectors),encoding='ascii')
negative=WORK/'negative.hex'
negative.write_text(f'0 0000 00 0001\n',encoding='ascii')
dump(OUT/'vectors.json',dict(oracle='serial GF(2) polynomial division, generator 0x11021; no binascii, no imported author code',
    algorithm_independence='Different code path from archived binascii-derived table; mathematical polynomial is necessarily shared; generated after source inspection; not a preinspection freeze',
    xorshift32_initial='0xc27a2026',categories=dict(Counter(v['category'] for v in vectors)),checks=len(vectors),
    unique_pairs=len({(v['seed'],v['byte']) for v in vectors}),superposition_triples=superposition,prefixes=prefixes,
    vectors=vectors,vector_file_sha256=sha(dest.read_bytes()),negative_file_sha256=sha(negative.read_bytes()),
    coverage_limit='196 selected vectors, not full 2^24 simulation; binary values only'))
print(json.dumps(dict(checks=len(vectors),categories=dict(Counter(v['category'] for v in vectors)),prefixes=prefixes)))
