import json, pathlib, tarfile, io
from capture import *

manifest=json.loads((WORK/'head'/MPATH).read_text(encoding='utf-8'))
inp=json.loads((WORK/'head'/f'handoffs/b/{OP}/input.json').read_text(encoding='utf-8'))
request_hash=sha(json.dumps(manifest['request'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
assert request_hash==manifest['request_hash']=='2addd741faa481897314cde62d1f3f0abe9169b4eef1404208759066d9125013'
assert inp['request']==manifest['request'] and inp['artifacts']==manifest['artifacts'] and inp['stages']==manifest['stages']
assert manifest['request']['code_commit']==SOURCE
tree=json.loads((RAW/'tree-head.stdout').read_bytes())
items={x['path']:x for x in tree['tree'] if x['type']=='blob'}
source_tree=json.loads((RAW/'tree-source.stdout').read_bytes())
source_items={x['path']:x for x in source_tree['tree'] if x['type']=='blob'}
records=[]
for n,path in enumerate(manifest['artifacts']):
    rec=getblob(f'blob-artifact-{n:02d}',items[path],WORK/'head'/path)
    assert rec['sha256']==manifest['files'][path]['sha256']
    assert rec['bytes']==manifest['files'][path]['size']
    rec['same_blob_at_source_commit']=source_items.get(path,{}).get('sha')==items[path]['sha']
    records.append(rec)
dump(OUT/'artifact-identity.json',dict(request_hash=request_hash,all_manifest_files_verified=True,records=records))
pub=WORK/'head/competition/deepeye/evidence/transport/crc16-byte-20261024-27/publication'
with tarfile.open(pub/'raw-evidence.tar.gz','r:gz') as tf:
    members=tf.getmembers()
    assert len(members)==355
    listing=[]
    for m in members:
        assert m.isfile(),f'non-regular archive member {m.name}'
        name=pathlib.PurePosixPath(m.name)
        assert not name.is_absolute() and '..' not in name.parts and '\\' not in m.name
        b=tf.extractfile(m).read()
        dest=WORK/'archive'/str(name)
        dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(b)
        listing.append(dict(path=m.name,bytes=len(b),sha256=sha(b)))
dump(OUT/'archive-members.json',listing)
print(json.dumps(dict(artifact_count=len(records),request_hash=request_hash,archive_members=len(listing),
    source_binding=json.loads((pub/'SOURCE_BINDING.json').read_bytes()),
    index_shape=str(type(json.loads((pub/'RAW_INDEX.json').read_bytes()))),
    bundle=json.loads((pub/'BUNDLE_MANIFEST.json').read_bytes()),acceptance=json.loads((pub/'ACCEPTANCE.json').read_bytes())),ensure_ascii=False,indent=2))
