import datetime,hashlib,json,pathlib,subprocess,sys
out=pathlib.Path(__file__).resolve().parent
name=sys.argv[1];assert name in ['audit.py','seal.py']
label=sys.argv[2];assert label.isalnum()
root=out.parents[2]
args=[str(root/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(out/name)]
r=subprocess.run(args,capture_output=True,cwd=root)
d=out/'own-command-logs';d.mkdir(exist_ok=True)
(d/(label+'.stdout')).write_bytes(r.stdout);(d/(label+'.stderr')).write_bytes(r.stderr)
(d/(label+'.command.json')).write_text(json.dumps({'argv':args,'exit_code':r.returncode,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()},indent=2)+'\n',encoding='utf-8')
sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr);sys.exit(r.returncode)
