from acquire import *
import re, tarfile
ops=[('35','B-DEEPEYE-BUFFERED-BLOCK-STREAM-20261024-35','stream/buffered-block-stream-20261024-35'),('36','B-DEEPEYE-ENCODER-REMAINDER-20261024-36','codec/encoder-remainder-20261024-36'),('37','B-DEEPEYE-ENCODER-REMAINDER-ADOPTION-20261024-37','codec/encoder-remainder-adoption-20261024-37')]
def j(p):return json.loads(p.read_text('utf-8-sig'))
nodes={x['path']:x for x in tree()['tree'] if x['type']=='blob'}
acq=j(OUT/'acquisition-index.json');by={x['path']:x for x in acq}
for x in acq:
    b=(ROOT/x['local_path']).read_bytes();assert len(b)==x['size'] and sha(b)==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['git_blob']==nodes[x['path']]['sha']
records=[];report_rows=[];rawbind=[];process_rows=[]
for num,op,ev in ops:
    hd=LOCAL/'snapshot/handoffs/b'/op;pub=LOCAL/'snapshot/competition/deepeye/evidence'/ev/'publication'
    m=j(hd/'manifest.json');inp=j(hd/'input.json');sb=j(pub/'SOURCE_BINDING.json')
    assert inp['request']==m['request'] and inp['artifacts']==m['artifacts'] and inp['stages']==m['stages']
    request_sha=sha(json.dumps(m['request'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode());assert request_sha==m['request_hash']
    code=m['request']['code_commit'];st=j(LOCAL/'metadata'/('source-tree-'+code+'.stdout'));assert not st.get('truncated')
    sn={x['path']:x for x in st['tree'] if x['type']=='blob'}
    for p,f in m['files'].items():
        assert by[p]['sha256']==f['sha256'] and by[p]['size']==f['size'] and sn[p]['sha']==by[p]['git_blob']
    for p,h in sb['sources'].items():assert by[p]['sha256']==h
    assert sb['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    idx=j(pub/'RAW_INDEX.json')['files']
    with tarfile.open(pub/'raw-evidence.tar.gz','r:gz') as tf:
        for name,f in idx.items():
            # Validate saved synthesis snapshot bytes directly against the operation source tree.
            mt=re.match(r'(main/(?:ooc-candidate-01|integrated-ooc-01)|short-path-recovery)/source_snapshot/((?:fpga|rtl)/.*\.sv)$',name)
            if mt:
                b=tf.extractfile(name).read();assert sha(b)==f['sha256'];p='competition/deepeye/'+mt[2]
                gs=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
                assert p in sn and sn[p]['sha']==gs
                rawbind.append({'op':num,'member':name,'git_path':p,'source_commit':code,'git_blob':gs,'sha256':sha(b),'bytes':len(b)})
            if name.endswith(('vivado.stdout.bin','vivado.stderr.bin')) and ('ooc' in name or name.startswith('short-path-recovery/')):
                b=tf.extractfile(name).read();assert sha(b)==f['sha256']
                dst=LOCAL/'raw-selected'/num/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
    # Producer run/process receipts remain producer evidence. Verify referenced stdout/stderr where present.
    for proc in (LOCAL/'raw-selected'/num).rglob('PROCESS.json'):
        r=j(proc);entry={'op':num,'member':str(proc.relative_to(LOCAL/'raw-selected'/num)).replace('\\','/'),'exit_code':r.get('exit_code'),'pid':r.get('pid'),'stdout_stderr_checked':[]}
        for kind in ['stdout','stderr']:
            v=r.get(kind)
            if isinstance(v,dict) and v.get('path'):
                basename=pathlib.PureWindowsPath(v['path']).name;p=proc.parent/basename
                if p.exists():assert sha(p.read_bytes())==v['sha256'];entry['stdout_stderr_checked'].append(kind)
        process_rows.append(entry)
    records.append({'op':num,'operation_id':op,'code_commit':code,'manifest_sha256':sha((hd/'manifest.json').read_bytes()),'request_hash':request_sha,'artifacts_verified':len(m['files']),'source_binding_sources_verified':len(sb['sources']),'all_canonical_artifacts_same_git_blob_at_source_and_tested_head':True})
for p in (LOCAL/'raw-selected').rglob('timing_summary.rpt'):
    text=p.read_text('utf-8',errors='replace');lines=text.splitlines();wns=None
    for i,line in enumerate(lines):
        if 'WNS(ns)' in line:
            for nxt in lines[i+1:i+9]:
                if re.match(r'^\s*[+-]?\d+\.\d+\s',nxt):wns=nxt.split()[0];break
            if wns is not None:break
    assert wns is not None
    gaps={k:re.search(r'checking '+k+r'\s*\((\d+)\)',text).group(1) for k in ['no_input_delay','no_output_delay']}
    clock_lines=[l.strip() for l in lines if re.match(r'^\s*clk\s+10\.000',l)]
    report_rows.append({'path':str(p.relative_to(LOCAL)).replace('\\','/'),'sha256':sha(p.read_bytes()),'producer_report_WNS_ns':wns,'producer_report_gaps':gaps,'clock_rows':clock_lines,'evidence_layer':'saved producer post-synthesis OOC report bytes; no independent tool execution'})
dump(OUT/'handoff-source-verification.json',{'records':records,'raw_synthesis_source_blob_bindings':rawbind,'raw_process_receipts':process_rows,'raw_timing_rows':report_rows})
delta=j(LOCAL/'metadata/delta.stdout')
paths=[x for x in tree()['tree'] if x['type']=='blob' and x['path'].startswith('competition/deepeye/')]
inventory={'tested_head':HEAD,'full_git_tree_metadata_not_truncated':True,'tracked_deepeye_bit_hwh_xdc':[x for x in paths if x['path'].lower().endswith(('.bit','.hwh','.xdc'))],'delta_files':[{k:x[k] for k in ['filename','status','additions','deletions']} for x in delta['files']],'source_file_metadata':[x for x in paths if '/evidence/' not in x['path'] and ('/fpga/' in x['path'] or '/tools/' in x['path'] or '/rtl/' in x['path'])],'raw_new_archive_delivery_suffixes':[{k:r[k] for k in ['op','members_verified','suffix_counts','archive_sha256','archive_bytes']} for r in j(OUT/'raw-byte-verification.json')]}
dump(OUT/'published-delivery-inventory.json',inventory)
dump(OUT/'SOURCE_HASH_MANIFEST.json',{'tested_head':HEAD,'scope':'selected exact Git blobs; not whole-top checkout','files':acq})
print(json.dumps({'selected_blobs':len(acq),'canonical_artifacts_verified':sum(r['artifacts_verified'] for r in records),'operations':records,'raw_source_bindings':len(rawbind),'raw_timing_rows':report_rows,'tracked_deepeye_bit_hwh_xdc':inventory['tracked_deepeye_bit_hwh_xdc']},ensure_ascii=False,indent=2))
