import base64, datetime, hashlib, json, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
LOCAL=ROOT/'.local/deepeye-b-op35-37-readiness-20261024'
GH='C:/Program Files/GitHub CLI/gh.exe'
HEAD='0885ed48b9edc48be7fd20135e8c141a485218d4'
REPO='carolwjade/CarlandFPGA'
LOCAL.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,obj):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def api(endpoint,label):
    d=LOCAL/'metadata';d.mkdir(exist_ok=True)
    args=[GH,'api',endpoint]
    r=subprocess.run(args,capture_output=True)
    (d/(label+'.stdout')).write_bytes(r.stdout);(d/(label+'.stderr')).write_bytes(r.stderr)
    dump(d/(label+'.command.json'),{'argv':args,'exit_code':r.returncode,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)})
    if r.returncode:raise RuntimeError(label+' gh exit '+str(r.returncode))
    return json.loads(r.stdout)
def tree():return json.loads((LOCAL/'metadata/tree.stdout').read_bytes())
def fetch(path,ref=HEAD):
    if ref!=HEAD:raise RuntimeError('only fixed head accepted')
    nodes={x['path']:x for x in tree()['tree']}
    x=nodes[path];assert x['type']=='blob'
    bapi=api(f'repos/{REPO}/git/blobs/{x["sha"]}','blob-'+x['sha'])
    b=base64.b64decode(bapi['content']);gitsha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    assert gitsha==x['sha']==bapi['sha'] and len(b)==x['size']==bapi['size']
    dest=LOCAL/'snapshot'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
    idxp=OUT/'acquisition-index.json';idx=json.loads(idxp.read_text('utf-8')) if idxp.exists() else []
    item={'path':path,'tested_head':HEAD,'git_blob':gitsha,'sha256':sha(b),'size':len(b),'local_path':str(dest.relative_to(ROOT)).replace('\\','/')}
    idx=[i for i in idx if i['path']!=path]+[item];dump(idxp,sorted(idx,key=lambda i:i['path']))
    return item
if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='bootstrap':
        scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_text('utf-8-sig'))
        canonical=json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
        h=sha(canonical);assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
        tr=json.loads((ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json').read_text('utf-8-sig'))
        assert tr['director_generation']==3 and tr['new_director_thread_id']=='01a16988-bdcb-70e1-ae10-1304b5cf7875' and tr['status']=='active'
        dump(OUT/'scope-validation.json',{'contract':scope['contract_id'],'revision':scope['revision'],'requirements_sha256':h,'requirement_ids':[r['id'] for r in scope['requirements']],'director_generation':tr['director_generation'],'director_thread':tr['new_director_thread_id'],'H12_preserved':True,'physical_board_operator':'A only','scope_md_sha256':sha((ROOT/'docs/competition/deepeye-2026/immutable_scope.md').read_bytes()),'scope_json_sha256':sha((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_bytes()),'transfer_sha256':sha((ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json').read_bytes())})
        pr=api(f'repos/{REPO}/pulls/30','pr30')
        c=api(f'repos/{REPO}/commits/{HEAD}','tested-commit')
        t=api(f'repos/{REPO}/git/trees/{c["commit"]["tree"]["sha"]}?recursive=1','tree');assert not t.get('truncated')
        comp=api(f'repos/{REPO}/compare/8ca3dd05cac4aea49c0afe53a6d9a12124aa12d2...{HEAD}','delta')
        print(json.dumps({'observed_pr_head':pr['head']['sha'],'tested_head':HEAD,'tree_entries':len(t['tree']),'tree_truncated':t.get('truncated'),'delta_commits':[(x['sha'],x['commit']['message'].splitlines()[0]) for x in comp['commits']],'new_handoff_paths':[x['path'] for x in t['tree'] if x['path'].startswith('handoffs/b/') and any(s in x['path'] for s in ['-35/','-36/','-37/'])]},ensure_ascii=False,indent=2))
    elif mode=='fetch':
        for p in sys.argv[2:]:print(json.dumps(fetch(p),ensure_ascii=False))
    else:raise RuntimeError(mode)
