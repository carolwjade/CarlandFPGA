# PR30 operations35–37 published readiness delta

准确审查head：`0885ed48b9edc48be7fd20135e8c141a485218d4`。本次实际GitHub GET读到的PR30 head相同。相对`8ca3dd05cac4aea49c0afe53a6d9a12124aa12d2`新增六个commit。**该published head尚未交付可供A加载的最小PL诊断包**：没有同次bit/HWH/build交付，没有原source4/topology2 stopped BOOT与显式新trigger产生新样本的集成入口，也没有与该真实镜像匹配的A headless受限采集/停止入口。这一结论仅限定已发布head，不推断B未发布工作不存在。

## 本次独立做了什么

新作业`A-B-OP35-37-READINESS-20261024-v1`、`child-ac20a1fc3c67487c85910b09c0c9c1d9`在canonical agent `/root/b_wire2829_review` fresh validation返回`execution_allowed=true`后执行。当前transfer为generation3、主thread `01a16988-bdcb-70e1-ae10-1304b5cf7875` active。重读H01–H15 MD/JSON并实算requirements UTF8/ensure_ascii=False/sort_keys=True/compact SHA256，结果为`c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，完整H12两条控制链保留。A/root唯一实板操作者。

使用既有gh认证进行只读GET；保存原始metadata字节、argv、exit、stdout/stderr哈希。取得48份选定exact Git blobs，重新计算Git blob SHA1、SHA256及size。完整树metadata未截断，但没有whole-top checkout。35/36/37三份request canonical hash与input/manifest相符，35项canonical artifacts全部按字节验证，且在各自source/evidence commit与tested head具有相同Git blob。17项SOURCE_BINDING sources符合声明。没有运行任何producer/main脚本、软件组、RTL仿真、OOC、Vivado、DCP reopen或板操作；报告中的行为统计和工具结果均是保存的生产者记录。

三个immutable tar共12,773,809压缩字节，仅留本独占.local。使用标准库tarfile逐成员验证普通文件、安全相对路径、无重复、无链接、size与SHA256；1033+418+301=1752成员，187,430,332解压字节全部对上RAW_INDEX/BUNDLE_MANIFEST。没有向产品解包；只另存必要的小型来源、失败、process和报告记录。60份保存的综合RTL snapshot直接计算Git blob并匹配相应source commit。未重新执行生产者旧qualification，也未把字节核验称为独立RTL或时序验收。

## 新增组合与来源

| operation | 实际source/evidence commit | 本次可确认的新增交付层 |
|---|---|---|
|35 buffered block stream|`9b3f5af3635e63601c9f0421505a7bccb367204b`|同clk、无新增状态/存储的`deepeye_block_stream`→`deepeye_encoded_frame_queue`连接wrapper；cfg/sample输入，metadata/byte输出，rst/cancel与直接诊断别名。|
|36 remainder candidate|`4afcddb9fb6637f74dca2e8e78a676517d80bf3a`|独立候选编码器，以captured sample和Euclidean remainder替代predictor重建乘法；原production core当时不变。一个candidate OOC DCP及保存报告。|
|37 production adoption|`8d69443de35585b8b8e4f8bbd499b1406f23421d`|production encoder采用候选算术；block stream/queue/wrapper字节不变；两个组合top的OOC DCP及保存报告。这里的“组合”仅指编码/缓冲层。|

35的SOURCE_BINDING旧encoder SHA256是`870bc5dcfe9a3a82124cf5d305082964b9a6ebf3447c13f1a92ec052a591d8a5`，本次用原tar字节和35 source tree核实。当前37 production encoder为`4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532`。这是有新operation记录的后续采用，不把35旧历史依赖偷偷改成新core，也不继承旧head验收。全部request、manifest、Git blob及raw source pins见`handoff-source-verification.json`、`historical-dependency-delta.json`与`SOURCE_HASH_MANIFEST.json`。

生产者35记录130783 events/4054242 public comparisons、3 compiled wiring mutants；author 21 cases/100 checks/113 admissions。生产者36记录1966035 feasible arithmetic transitions（不是全2^32）、1559 reused cases新执行、3184107 cycles/41393378 comparisons及2 mutants。生产者37记录130783 edges/4054242 comparisons及1 mutant、author reused297 valid cases/505112 trace rows。独立旧reference/共同queue/历史stimulus复用、35 adapter在部分wrapper inspection后编写、37 author comparator共享新算术等限制均保留。本次没有重新验证这些运行的逻辑充分性。

## 原失败与OOC边界

35原Flash402三份partial与移除两条错误ready-net assignment的恢复材料仍在tar；author attempt1是onerror宏告警导致失败，attempt2以`BBS_TERMINAL ... outcome=error`日志判定失败，attempt3才被生产者资格化。原runner203 false accepts及保存日志repair、后续100新增wrong-expected negatives仍保留，未重跑。

36原parser14 false accepts及134 author/22 main negatives修复记录、main首次negative fixture和输出目录guard失败保留。原OOC汇总`warning_bearing=0`与实际10 warnings之间的erratum由生产者后续per-run记录修正，原receipt未改。旧OOC33 encoder -4.379ns/blockstream -4.349ns失败继续作为历史记录，未重跑、未抹除。

37保存的三次综合尝试为：原blockstream exit0；原buffered wrapper综合/报告已生成但DCP export超过Windows260-byte路径，exit1且无DCP，随后driver聚合`int(None)`失败；仅wrapper在`D:/pynq/CarlandFPGA/.local/b37r1`新短路径恢复exit0。没有把第一次wrapper当完整产物，也没有把成功stream称为再次重跑。原main final-audit list/map处理失败在publication README中仍披露。两个DCP reopen是B保存的实际运行记录，本次只验证其归档字节，未自行reopen。

本次从原报告直接读取的WNS为：36候选+0.561ns，37 blockstream+0.491ns、buffered wrapper+0.389ns（原失败export前报告和恢复报告一致）。保存Tcl明确先`synth_design -mode out_of_context`，再`create_clock -period 10.000`，最后`write_checkpoint`；没有place/route/bitstream/HWH生成。36有35 input/53 output无delay；37分别51/232与51/399无delay。9/11 warnings、ZPS7-1与I/O约束缺口保留。新正WNS是生产者post-synthesis诊断记录，不能升级为100MHz全路径时序闭合、实现、物理时钟或board结果。嵌套资源不可相加。

本次自己的一个只读PowerShell JSON投影命令在执行前发生`An empty pipe element is not allowed`语法错误，保存于`read-command-failure.json`；后用自己的Python读取投影。没有修改producer或产品，亦未以该失败触发工具链重试。

## 最小PL诊断仍缺哪些东西

1. **真实同次镜像交付**：完整Git树metadata中的DeepEye跟踪路径没有`.bit/.hwh/.xdc`；三个新raw包分别有0/1/2个DCP、均无bit/HWH/XDC。35–37 handoffs没有一个实际实现构建、同次bit/HWH及其加载身份/地址映射包。DCP是综合中间产物。
2. **source4/topology2因果集成**：新wrapper只有cfg_count/e/tag、16-bit sample与opaque metadata/byte链路；没有BOOT/source/topology/session/public sample_id或trigger处理。当前sample-scan primitive的公开文档明确ordinal不是public sample_id，out_valid不认证fresh/live/physical；stop/rearm只是局部同步flush/rearm。35–37没有把这些连接成“stopped BOOT → A显式新trigger → 当次新样本/序列”的对外协议或真实top。内部<=256B编码块也不是公共TRACE<=32B ABI。
3. **匹配A受限入口**：新增软件路径都是仿真/保存日志审计runner；没有随同35–37交付与同次HWH绑定的A headless bounded collection/stop入口、有限采样窗口与停止清理记录。B原任务里的“最小真实PL观测包”仍未在这个published delta闭合。

这些缺件不要求等待全部19top timing、最终ADC、CNN或三路PWM。Root可以继续要求最窄数字/raw软件注入经真实PL的诊断包；本review不替root选择板操作、不自放板，也不将编码优化OOC作为该包的替代。A ABI/type/profile/source/session/BOOT/clock/TTL/replay/control、CDC/RDC、synth/impl/timing signoff、board/system与正式接受均未由本次review赋予。

旧F01保持OPEN；本次没有重审、修复或改写其归档。G03/R03/all29与B01/B03/B06等正式门仍not_run。C PR25不在本次byte review；未继承其验收。

## 封存与可复用材料

`result.json`给出机器可读缺件；`SOURCE_HASH_MANIFEST.json`固定48选定blob；`handoff-source-verification.json`固定request/manifest、60个raw synthesis source bindings与原report读数；`raw-byte-verification.json`保存1752全部成员hash；`ROOT_ARCHIVE_SELECTION.json`是供root选择的小材料清单和immutable upstream tar引用，不复制旧大包。`EVIDENCE_MANIFEST.json`最后冻结本作业文件；private lease、manifest自身及post-seal readback/native completion另存并明确排除。Root负责正式接受、PR/peer反馈与下一实际操作。
