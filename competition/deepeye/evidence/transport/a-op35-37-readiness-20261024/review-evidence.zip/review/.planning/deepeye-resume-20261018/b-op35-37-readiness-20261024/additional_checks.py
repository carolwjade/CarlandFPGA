from acquire import *
import tarfile,re
def j(p):return json.loads(p.read_text('utf-8-sig'))
records=[]
pub=LOCAL/'snapshot/competition/deepeye/evidence/stream/buffered-block-stream-20261024-35/publication'
sb=j(pub/'SOURCE_BINDING.json');idx=j(pub/'RAW_INDEX.json')['files'];code='9b3f5af3635e63601c9f0421505a7bccb367204b'
old={x['path']:x for x in j(LOCAL/'metadata'/('source-tree-'+code+'.stdout'))['tree']}
current={x['path']:x for x in j(OUT/'acquisition-index.json')}
with tarfile.open(pub/'raw-evidence.tar.gz','r:gz') as tf:
    for dep,h in sb['dependencies'].items():
        p='competition/deepeye/'+dep;matches=[n for n,v in idx.items() if v['sha256']==h]
        assert matches
        b=tf.extractfile(matches[0]).read();assert sha(b)==h
        gs=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert old[p]['sha']==gs
        records.append({'path':p,'historical_source_commit':code,'historical_sha256':h,'raw_member':matches[0],'git_blob':gs,'at_tested_head_sha256':current[p]['sha256'],'same_at_tested_head':h==current[p]['sha256']})
dump(OUT/'historical-dependency-delta.json',records)
summaries=[]
for num,folder in [('36','main/ooc-candidate-01'),('37','main/integrated-ooc-01'),('37','short-path-recovery')]:
    r=j(LOCAL/'raw-selected'/num/folder/'RESULT.json')
    summaries.append({'op':num,'folder':folder,'overall_status':r.get('overall_status'),'candidate':r.get('candidate'),'selection':r.get('selection'),'recovery_decision':r.get('recovery_decision'),'totals':r.get('totals'),'fatal_error':r.get('fatal_error')})
dump(OUT/'producer-run-summary-readback.json',summaries)
events=[]
for p in (LOCAL/'raw-selected').rglob('vivado.stdout.bin'):
    text=p.read_bytes().decode('utf-8',errors='replace');hits=[{'line':i+1,'text':l} for i,l in enumerate(text.splitlines()) if re.search(r'ERROR:|WARNING:|write_checkpoint|too long|260|WNS|synth_design|create_clock',l)]
    events.append({'path':str(p.relative_to(LOCAL)).replace('\\','/'),'sha256':sha(p.read_bytes()),'matches':hits})
dump(OUT/'producer-raw-log-excerpts.json',events)
print(json.dumps({'historical_dependencies':records,'producer_summary':summaries},ensure_ascii=False,indent=2))
