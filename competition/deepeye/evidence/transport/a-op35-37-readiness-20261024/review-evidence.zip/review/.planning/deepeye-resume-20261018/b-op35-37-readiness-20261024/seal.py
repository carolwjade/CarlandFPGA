from acquire import *
excluded={'lease.private.json','EVIDENCE_MANIFEST.json','manifest-readback.json','native-complete.json'}
if sys.argv[1:] == ['verify']:
    data=json.loads((OUT/'EVIDENCE_MANIFEST.json').read_text('utf-8'))
else:
    files=[]
    for folder in [OUT,LOCAL]:
        for p in sorted(folder.rglob('*')):
            if not p.is_file() or p.name in excluded:continue
            b=p.read_bytes();files.append({'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':sha(b),'size':len(b)})
    data={'work_id':'A-B-OP35-37-READINESS-20261024-v1','tested_head':HEAD,'files':sorted(files,key=lambda x:x['path']),'excluded_private_or_postseal':sorted(excluded),'scope':'Only the two assigned evidence directories; selected exact Git bytes, metadata and safe upstream tar audit. No product files.'}
    dump(OUT/'EVIDENCE_MANIFEST.json',data)
for f in data['files']:
    b=(ROOT/f['path']).read_bytes();assert len(b)==f['size'] and sha(b)==f['sha256']
readback={'work_id':data['work_id'],'tested_head':HEAD,'manifest_sha256':sha((OUT/'EVIDENCE_MANIFEST.json').read_bytes()),'files_verified':len(data['files']),'all_hashes_match':True,'report_sha256':sha((OUT/'report.md').read_bytes()),'result_sha256':sha((OUT/'result.json').read_bytes()),'source_hash_manifest_sha256':sha((OUT/'SOURCE_HASH_MANIFEST.json').read_bytes()),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
dump(OUT/'manifest-readback.json',readback)
print(json.dumps(readback,indent=2))
