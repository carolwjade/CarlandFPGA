from acquire import *
ops=[('B-DEEPEYE-BUFFERED-BLOCK-STREAM-20261024-35','stream/buffered-block-stream-20261024-35'),('B-DEEPEYE-ENCODER-REMAINDER-20261024-36','codec/encoder-remainder-20261024-36'),('B-DEEPEYE-ENCODER-REMAINDER-ADOPTION-20261024-37','codec/encoder-remainder-adoption-20261024-37')]
if sys.argv[1]=='docs':
    for op,ev in ops:
        for n in ['README.md','ACCEPTANCE.json','SOURCE_BINDING.json','BUNDLE_MANIFEST.json','RAW_INDEX.json']:
            fetch('competition/deepeye/evidence/'+ev+'/publication/'+n)
    for p in ['fpga/stream/deepeye_buffered_block_stream.sv','fpga/stream/buffered_block_stream_candidate.md','fpga/codec/deepeye_block_encoder_remainder_candidate.sv','fpga/codec/encoder_remainder_candidate.md','fpga/codec/deepeye_block_encoder.sv','fpga/codec/encoder_remainder_adoption.md']:
        fetch('competition/deepeye/'+p)
    print('selected publication declarations and RTL/docs acquired')
elif sys.argv[1]=='tar':
    for _,ev in ops:fetch('competition/deepeye/evidence/'+ev+'/publication/raw-evidence.tar.gz')
    print('three immutable raw archives acquired')
elif sys.argv[1]=='binding':
    existing={i['path'] for i in json.loads((OUT/'acquisition-index.json').read_text('utf-8'))}
    delta=json.loads((LOCAL/'metadata/delta.stdout').read_bytes())
    commits={x['sha']:x for x in delta['commits']}
    for op,ev in ops:
        m=json.loads((LOCAL/'snapshot/handoffs/b'/op/'manifest.json').read_text('utf-8'))
        for p in m['artifacts']:
            if p not in existing:fetch(p);existing.add(p)
        c=m['request']['code_commit'];ts=commits[c]['commit']['tree']['sha']
        api(f'repos/{REPO}/git/trees/{ts}?recursive=1','source-tree-'+c)
    for p in ['fpga/stream/deepeye_block_stream.sv','fpga/stream/deepeye_encoded_frame_queue.sv','fpga/acquisition/deepeye_sample_scan_capture.sv','fpga/acquisition/sample_scan_capture_candidate.md']:
        fetch('competition/deepeye/'+p)
    print('canonical artifact bytes, original source trees and selected acquisition dependencies acquired')
