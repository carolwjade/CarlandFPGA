from acquire import *
import tarfile
ops=[('35','stream/buffered-block-stream-20261024-35'),('36','codec/encoder-remainder-20261024-36'),('37','codec/encoder-remainder-adoption-20261024-37')]
results=[]
for number,ev in ops:
    pub=LOCAL/'snapshot/competition/deepeye/evidence'/ev/'publication'
    idx=json.loads((pub/'RAW_INDEX.json').read_text('utf-8'))['files'];bundle=json.loads((pub/'BUNDLE_MANIFEST.json').read_text('utf-8'))
    assert sha((pub/'raw-evidence.tar.gz').read_bytes())==bundle['sha256']
    assert sha((pub/'RAW_INDEX.json').read_bytes())==bundle['index_sha256']
    selected=[];seen={};total=0
    with tarfile.open(pub/'raw-evidence.tar.gz','r:gz') as tf:
        for m in tf:
            pp=pathlib.PurePosixPath(m.name)
            assert m.isfile() and not pp.is_absolute() and '..' not in pp.parts and '\\' not in m.name and ':' not in m.name and m.name not in seen
            assert m.name in idx and m.size==idx[m.name]['bytes'] and m.size<=100_000_000
            b=tf.extractfile(m).read();assert len(b)==m.size and sha(b)==idx[m.name]['sha256']
            seen[m.name]={'size':m.size,'sha256':sha(b)};total+=m.size
            # Only provenance/summary, original failure logs and relevant OOC reports are written separately.
            take=(m.name.endswith('/RESULT.json') or m.name.endswith('/run-result.json') or m.name.endswith('/commands.json') or m.name.endswith('/PROCESS.json') or m.name.endswith('/SOURCE_MANIFEST.json') or m.name.endswith('/ADOPTION.json') or ('recovery-inputs/' in m.name and m.size<50_000) or ('ooc' in m.name or 'short-path-recovery/' in m.name) and (m.name.endswith(('.rpt','.tcl','.stdout.txt','.stderr.txt'))))
            if take and m.size<=350_000 and not m.name.endswith('.py'):
                dst=LOCAL/'raw-selected'/number/pp;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
                selected.append(m.name)
    assert set(seen)==set(idx) and len(seen)==bundle['members'] and total==bundle['raw_bytes']
    result={'op':number,'archive_sha256':bundle['sha256'],'archive_bytes':(pub/'raw-evidence.tar.gz').stat().st_size,'members_verified':len(seen),'raw_bytes_verified':total,'selected_members':selected,'suffix_counts':{ext:len([p for p in seen if p.lower().endswith(ext)]) for ext in ['.dcp','.bit','.hwh','.xdc']},'all_member_hashes':seen}
    results.append(result)
dump(OUT/'raw-byte-verification.json',results)
print(json.dumps([{k:v for k,v in r.items() if k not in ['selected_members','all_member_hashes']}|{'selected_count':len(r['selected_members'])} for r in results],indent=2))
