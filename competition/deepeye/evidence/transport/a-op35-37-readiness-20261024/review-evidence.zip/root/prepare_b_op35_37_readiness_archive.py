"""Stage the bounded readiness review without duplicating upstream raw archives."""
from pathlib import Path
import hashlib, json, zipfile

P = Path(__file__).resolve().parent
R = P.parents[2]
B = P.parent / 'b-op35-37-readiness-20261024'
read = lambda p: json.loads(p.read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()
selection = read(B / 'ROOT_ARCHIVE_SELECTION.json')
decision = read(P / 'b-op35-37-readiness-root-decision.json')
assert decision['manifest_members_rehashed'] == 333 and decision['selected_Git_blobs_rehashed'] == 48
tokens = [read(p)['lease_token'].encode() for p in P.parent.glob('*/lease.private.json')]
members = {}
def add(name, path, expected=None):
    assert name not in members and '\\' not in name and '..' not in name.split('/')
    raw = path.read_bytes()
    if expected:
        assert sha(raw) == expected['sha256'] and len(raw) == expected['size']
    assert not any(token in raw for token in tokens), name
    members[name] = raw
for row in selection['selected_files']:
    path = (R / row['path']).resolve()
    path.relative_to(R.resolve())
    assert path.suffix.lower() not in ['.gz', '.dcp', '.bit', '.hwh', '.exe']
    add('review/' + row['path'], path, row)
for name in ['EVIDENCE_MANIFEST.json', 'ROOT_ARCHIVE_SELECTION.json', 'native-complete.json']:
    add('seal/' + name, B / name)
for name in ['verify_b_op35_37_readiness.py', 'b-op35-37-readiness-root-decision.json',
             'prepare_b_op35_37_readiness_archive.py', 'b-op35-37-peer-feedback.json',
             'peer-heads-after-game-evidence.json']:
    add('root/' + name, P / name)
stage = P / 'staged-b-op35-37-readiness'
stage.mkdir(exist_ok=False)
archive = stage / 'review-evidence.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(members.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.infolist()) == len(members)
    assert all(z.read(name) == raw for name, raw in members.items())
manifest = {'schema': 1, 'archive_sha256': sha(archive.read_bytes()), 'member_count': len(members),
            'members': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())},
            'immutable_upstream_archives_not_duplicated': selection['immutable_upstream_archives']}
for name, data in [('manifest.json', manifest), ('decision.json', decision)]:
    with (stage / name).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')
with (stage / 'README.md').open('x', encoding='utf-8', newline='\n') as f:
    f.write('Exact B PR30 head0885ed48b9edc48be7fd20135e8c141a485218d4 read-only operations35-37 readiness delta. '
            'Root rehashed333 review records and48 selected Git blobs; producer archives were byte-checked by the reviewer, not rerun. '
            'New buffered encoding wrapper/remainder adoption and positive post-synthesis OOC reports retain missing I/O delays, warnings, original failures and model exposure. '
            'This published head still lacks same-build bit/HWH/build, source4/topology2 BOOT/fresh-trigger integration and a matching A bounded collector/stop entrypoint. '
            'No unpublished-work absence, independent RTL/timing/implementation or board acceptance is inferred. '
            'Full upstream raw tar files are immutably referenced rather than duplicated. '
            'Existing B task/operation retained, concise feedback delivered once; guest readback not established. '
            'H01-H15/full H12 unchanged; old F01OPEN; G03/R03/all29 not_run.\n')
result = {'target': 'competition/deepeye/evidence/transport/a-op35-37-readiness-20261024',
          'member_count': len(members), 'archive_sha256': manifest['archive_sha256'],
          'files': {p.name: sha(p.read_bytes()) for p in sorted(stage.iterdir())},
          'product_writes': 0, 'lease_tokens_checked_without_output': len(tokens)}
with (P / 'b-op35-37-readiness-archive-preparation-result.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
