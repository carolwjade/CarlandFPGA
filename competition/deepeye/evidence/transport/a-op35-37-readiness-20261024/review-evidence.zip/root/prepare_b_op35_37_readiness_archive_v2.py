"""Handle recorded lease response shapes; preserve the first packaging failure."""
from pathlib import Path

path = Path(__file__).with_name('prepare_b_op35_37_readiness_archive.py')
source = path.read_text(encoding='utf-8')
old = "tokens = [read(p)['lease_token'].encode() for p in P.parent.glob('*/lease.private.json')]"
new = '''tokens = []
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key == 'lease_token' and isinstance(item, str) and item:
                tokens.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)
    elif isinstance(value, str) and value.lstrip().startswith(('{', '[')):
        try:
            decoded = json.loads(value)
        except (ValueError, TypeError):
            return
        collect(decoded)
for lease_path in P.parent.glob('*/lease.private.json'):
    collect(read(lease_path))
tokens = list(set(tokens))
assert len(tokens) >= 9'''
assert source.count(old) == 1
source = source.replace(old, new)
old = "'peer-heads-after-game-evidence.json']:"
new = "'peer-heads-after-game-evidence.json', 'prepare_b_op35_37_readiness_archive_v2.py', 'b-op35-37-archive-packaging-correction.json']:"
assert source.count(old) == 1
source = source.replace(old, new)
exec(compile(source, str(path), 'exec'))
