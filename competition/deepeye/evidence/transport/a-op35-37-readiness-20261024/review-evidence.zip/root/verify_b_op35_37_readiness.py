"""Root byte readback only; no producer/toolchain execution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

P = Path(__file__).resolve().parent
R = P.parents[2]
B = P.parent / 'b-op35-37-readiness-20261024'
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(p.read_bytes())
manifest = B / 'EVIDENCE_MANIFEST.json'
assert sha(manifest.read_bytes()) == '057cc3dcea06a1fe92c1c947352e3a2ee9724e92d316a2c8a352b3ccfe91776b'
rows = read(manifest)['files']
assert len(rows) == 333
for row in rows:
    path = (R / row['path']).resolve()
    path.relative_to(R.resolve())
    raw = path.read_bytes()
    assert len(raw) == row['size'] and sha(raw) == row['sha256'], row['path']
sources = read(B / 'SOURCE_HASH_MANIFEST.json')
assert sources['tested_head'] == '0885ed48b9edc48be7fd20135e8c141a485218d4'
assert len(sources['files']) == 48
for row in sources['files']:
    raw = (R / row['local_path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['size']
    blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    assert blob == row['git_blob'], row['path']
result = read(B / 'result.json')
decision = {
    'utc': datetime.now(timezone.utc).isoformat(),
    'tested_head': sources['tested_head'], 'manifest_members_rehashed': 333,
    'selected_Git_blobs_rehashed': 48, 'source_and_saved_record_review_only': True,
    'actual_independent_toolchain_or_board_calls': 0,
    'new35_37': 'buffered encoding wrapper, remainder candidate/adoption; producer post-synthesis OOC reports only',
    'minimum_PL_package': 'not delivered at this published head; no inference about unpublished work',
    'missing': ['same-build bit/HWH/build', 'source4/topology2 stoppedBOOT→fresh trigger→new sample integration',
                'matching A bounded headless collection/stop entrypoint'],
    'timing': 'saved positive post-synth WNS with missing I/O delays/warnings; not full implementation timing acceptance',
    'old_wire_F01': 'OPEN', 'original_B_C_tasks_and_operations': 'retained; no duplicate assignment',
    'original_failures_and_model_exposure': 'preserved', 'H01_H15_full_H12': 'preserved',
    'G03': 'not_run', 'R03': 'not_run', 'all29': 'not_run',
}
with (P / 'b-op35-37-readiness-root-decision.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(decision, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps(decision, indent=2))
