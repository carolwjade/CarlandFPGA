"""Root limited RX31 acceptance; preserve raw locally and publish a small selection."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import tarfile
import zipfile

P = Path(__file__).resolve().parent
R = P.parents[2]
O = P.parent
W = R / '.local/deepeye-implementation-a'
A = O / 'b-uart-wire-rx31-independent-20261024'
S = R / '.local/deepeye-b-uart-wire-rx31-review-20261024'
BASE = '360b102b299849a24a0b8cb2b6592f64f475e611'
GIT = r'C:\Users\CarlJade\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_bytes())


def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')


def root_path(name):
    path = (R / name).resolve()
    assert path.is_relative_to(R.resolve()) and path.is_file()
    return path


def git(*args):
    return subprocess.check_output([GIT, '--no-optional-locks', '-C', str(W), *args])


assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert not git('diff', '--cached', '--name-only').strip()
protected = read(O / 'r03-mailbox-stop-main-review-20261020/application.json')['protected_files']
assert all(sha((W / name).read_bytes()) == pin for name, pin in protected.items())
terminal = read(P / 'rx31-terminal.json')
if isinstance(terminal, dict) and 'content' in terminal:
    terminal = json.loads(next(x['text'] for x in terminal['content'] if x['type'] == 'text'))
job = terminal[0]
assert job['status'] == 'completed' and job['terminal'] and not job['stale']
for name in ['report.md', 'result.json', 'EVIDENCE_MANIFEST.json']:
    assert sha((A / name).read_bytes()) in job['result']['text']
manifest = read(A / 'EVIDENCE_MANIFEST.json')
assert len(manifest['files']) == 1784
for row in manifest['files']:
    raw = root_path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
source = read(A / 'SOURCE_HASH_MANIFEST.json')
assert source['tested_head'] == '04e3a46eb1169afca0c133815a9b9f3da15d89f5'
assert source['source_commit'] == 'bbfb11439b35e0866a6d2486f3857b92ed6cf529'
assert len(source['files']) == 21
for row in source['files']:
    raw = (S / 'snapshot' / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['git_blob']
operation = 'B-DEEPEYE-UART-WIRE-RX-20261024-31'
upstream = S / 'snapshot/handoffs/b' / operation / 'manifest.json'
doc = read(upstream)
assert sha(upstream.read_bytes()) == '06c386683a29d154a2fa954f3b3a7583637fe5b1710c81dc552b68928766547e'
request = sha(json.dumps(doc['request'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
assert request == 'a0419132c5d6f88d15dd97e18e03e28daec1be3777765d253fac03187faa2570'
for name, row in doc['files'].items():
    raw = (S / 'snapshot' / name).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row.get('size', row.get('bytes'))
    if name.endswith('/raw-evidence.tar.gz'):
        assert sha(raw) == 'aae437347fc69b355c2c04d20e2dc35b7c48cc691407dc4937e81d4c13958946'
        with tarfile.open(S / 'snapshot' / name, 'r:gz') as tf:
            entries = tf.getmembers()
            assert len(entries) == 1551 and all(x.isfile() for x in entries)
            assert len({x.name for x in entries}) == 1551
            assert sum(x.size for x in entries) == 631190350
focused = read(A / 'focused-result-focused-01.json')
assert focused['passed'] and len(focused['results']) == 2
for test in focused['results']:
    assert test['passed'] and test['exit'] == 0
    path = S / 'focused-01' / test['config']['id']
    log = (path / 'vsim.stdout.bin').read_bytes()
    assert sha(log) == test['stdout_sha256'] and sha((path / 'vsim.stderr.bin').read_bytes()) == test['stderr_sha256']
    assert b'Errors: 0, Warnings: 0' in log and b'Warning:' not in log
    assert sha((path / 'pin-events.csv').read_bytes()) == test['pin_events_sha256']
assert sum(x['cycles'] for x in focused['results']) == 15641
assert sum(x['checks'] for x in focused['results']) == 486
events = read(A / 'event-verification.json')
assert events['passed'] and events['total_actual_clocks'] == 15641
assert events['total_documented_half_sample_checks'] == 942
assert sum(x['actual_input_edges'] for x in events['results']) == 540
assert sum(x['normal_bytes_checked'] for x in events['results']) == 94
qualification = read(A / 'own-log-event-qualification.json')
assert qualification['all_expected'] and len(qualification['probes']) == 20
result = read(A / 'result.json')
assert not result['missing_final_audit_references']
assert result['prior_F01'] == 'OPEN, out of scope and untouched'
selection = read(A / 'ROOT_ARCHIVE_SELECTION.json')
assert len(selection['files']) == 93
members = {}
for row in selection['files']:
    raw = root_path(row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    members[row['path']] = raw
for name in selection['post_seal_paths']:
    members[name] = root_path(name).read_bytes()
for row in source['files']:
    if not row['path'].endswith('/raw-evidence.tar.gz'):
        members['upstream-selected/' + row['path']] = (S / 'snapshot' / row['path']).read_bytes()
members['root/native-terminal.json'] = (P / 'rx31-terminal.json').read_bytes()
members['root/archive_rx31_review.py'] = Path(__file__).read_bytes()
assert sum(map(len, members.values())) < 10 * 1024 * 1024
secret = read(A / 'lease.private.json')['lease_token'].encode()
assert all(secret not in raw for raw in members.values())
assert all('lease.private' not in name for name in members)
decision = dict(schema=1, utc=datetime.now(timezone.utc).isoformat(),
    owner='A/root 01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3',
    disposition='ACCEPT_NEW_DIRECTED_OPAQUE_UART_TO_PARSER_DIGITAL_SIMULATION_ONLY',
    operation_id=operation, request_hash=request, manifest_sha256=sha(upstream.read_bytes()),
    tested_commit=source['tested_head'], source_commit=source['source_commit'],
    requirements_sha256='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    H01_H15_preserved=True, root_frozen_files_verified=1784, selected_Git_blobs_verified=21,
    promised_raw_members_verified=1551, promised_raw_bytes_verified=631190350,
    new_configs=2, all_actual_new_clocks=15641, new_assertions=486, reruns=0,
    actual_input_transitions_checked=540, actual_public_sample_rows=15641,
    normal_UART_bytes_checked=94, documented_half_sample_checks=942,
    sampling_boundary='public INPUT/CLOCK/SAMPLE/OUTPUT realtime is simulator evidence; internal half-bit samples are predicted, not directly probed',
    own_log_event_probes=20, new_DUT_findings=[], producer_old_groups_rerun=False,
    original_13_STAT_W33_warnings_and_9_invalid_runner_acceptances_preserved=True,
    unavailable_historical_transient='producer-disclosed deleted out-of-ownership transient RESULT is not rehashable; not reconstructed or claimed verified',
    full_historical_execution_or_producer_qualification_accepted=False,
    independence='own vectors/history frozen before wrapper read; prior parser/serializer/TX-document exposure disclosed',
    old_wire2829_F01='still OPEN, untouched',
    original_producer_bundle_reference=selection['upstream_bundle_reference'],
    archive_scope='small new A controls/CSV/commands and saved-audit selection; original631MB raw not embedded',
    A_semantic_control_build_board_system_or_B33_B34_toolchain_accepted=False,
    B04='not_run', G03='not_run', R03='not_run', all29='not_run')
dest = W / 'competition/deepeye/evidence/transport/a-op31-review-20261024'
dest.mkdir(parents=True, exist_ok=False)
zp = dest / 'review-evidence.zip'
with zipfile.ZipFile(zp, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(members.items()): z.writestr(name, raw)
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None and len(z.namelist()) == len(members)
    assert all(z.read(name) == raw for name, raw in members.items())
save(dest / 'manifest.json', dict(schema=1, zip_sha256=sha(zp.read_bytes()), zip_bytes=zp.stat().st_size,
    member_count=len(members), original_raw_embedded=False, members=[dict(path=name,
    bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(members.items())], credentials_excluded=True))
save(dest / 'decision.json', decision)
(dest / 'README.md').write_text('Root accepts only new directed opaque UART-to-parser digital simulation at the pinned B head: two first-pass configs,15641 clocks/486 assertions,540 actual input transitions and94 checked UART bytes. Public event times are simulator observations; internal half-bit sample boundaries are predictions, not direct internal probes. Original STAT_W33/runner failures retained. A deleted historical transient RESULT remains unavailable and is not claimed rehashed. This selected archive references the immutable upstream tar instead of embedding631MB raw. Prior dependency exposure and old op28/29 F01 OPEN remain explicit. No A semantic/BOOT/TTL/motion/physicalclock/build/board/system or B33/B34/toolchain acceptance. H01-H15 unchanged; B04/G03/R03/all29=not_run.\n', encoding='utf-8', newline='\n')
files = {path.relative_to(W).as_posix(): sha(path.read_bytes()) for path in dest.iterdir()}
save(P / 'rx31-root-decision.json', decision)
save(P / 'rx31-publication.json', dict(expected_head=BASE,
    message='Archive directed RX31 review and predicted-sampling boundary', files=files))
assert all(sha((W / name).read_bytes()) == pin for name, pin in protected.items())
print(json.dumps(dict(prepared_files=len(files), archive_members=len(members), zip_bytes=zp.stat().st_size,
    zip_sha256=sha(zp.read_bytes()), verified_frozen_files=1784, C4_unchanged=True)))
