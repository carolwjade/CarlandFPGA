import json,pathlib,hashlib,platform
from acquire import ROOT,OUT,LOCAL,SNAP,HEAD,SOURCE,OP,entries,sha,save_json
from check_events import parse,check,classify
plan=json.loads((OUT/'oracle-freeze.json').read_bytes());ev=json.loads((OUT/'evidence-verification.json').read_bytes());hist=json.loads((OUT/'history-review.json').read_bytes());focused=json.loads((OUT/'focused-result-focused-01.json').read_bytes());event=json.loads((OUT/'event-verification.json').read_bytes())
assert focused['passed'] and event['passed'] and not hist['missing_references']
assert sum(r['cycles'] for r in focused['results'])==15641<25000 and sum(r['checks'] for r in focused['results'])==486
for cfg in plan['configs']:
 p=LOCAL/'focused-01'/cfg['id'];assert classify((p/'vsim.stdout.bin').read_bytes()+(p/'vsim.stderr.bin').read_bytes(),cfg);assert check(parse(p/'rx-events.csv'),cfg)['normal_bytes_checked']==47
assert json.loads((OUT/'mapping-cleanup-focused-01.json').read_bytes())['mapping_absent_after']
assert SOURCE in [p['sha'] for p in json.loads((LOCAL/'metadata/head-commit.json').read_bytes())['parents']]
es=entries();ss=entries('source');files=[]
for p in sorted(SNAP.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(SNAP).as_posix();b=p.read_bytes();gid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert es[rel]['sha']==gid
 files.append({'path':rel,'bytes':len(b),'sha256':sha(b),'git_blob':gid,'same_blob_at_source':ss.get(rel,{}).get('sha')==gid})
assert len(files)==21
tools=[]
for name in ['vlib.exe','vlog.exe','vsim.exe']:
 p=pathlib.Path('C:/modeltech64_2020.4/win64')/name;tools.append({'path':str(p),'sha256':sha(p.read_bytes())})
save_json(OUT/'SOURCE_HASH_MANIFEST.json',{'tested_head':HEAD,'source_commit':SOURCE,'selected_blob_count':21,'whole_top_snapshot':False,'files':files,'own_TB':{'path':str((LOCAL/'tb_rx31.sv').relative_to(ROOT)),'sha256':sha((LOCAL/'tb_rx31.sv').read_bytes())},'tools':tools,'python':platform.python_version(),'oracle_freeze_sha256':sha((OUT/'oracle-freeze.json').read_bytes())})
result={'schema':1,'status':'bounded_independent_RX31_digital_review_complete','work_id':'A-B-UART-WIRE-RX31-INDEPENDENT-20261024-v1','job_id':'child-4a83c0aedab54603af14c9d1cadec738','agent_id':'/root/b_wire2829_review','task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'director_generation':3,'acceptance_owner':'A Gen3/root; no formal acceptance by this child','tested_head':HEAD,'source_commit':SOURCE,'operation_id':OP,'request_hash':ev['request_hash'],'manifest_sha256':ev['manifest_sha256'],'contract':'DEEPEYE-HUMAN-LOCK-20261014/revision1','requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','selected_Git_blobs':21,'whole_top_snapshot':False,'raw_members':1551,'raw_bytes':ev['raw_bytes'],'canonical_bytes_and_source_binding':'verified','new_controls':{'configs':plan['configs'],'all_actual_clocks':15641,'assertions':486,'actual_input_edges':540,'actual_public_input_sample_rows':15641,'normal_UART_bytes_checked':94,'documented_half_sample_checks':942,'own_log_event_qualification_probes':20,'attempts':'first invocation of each config passed clean; no rerun','hard_budget':25000,'new_DUT_findings':[]},'sampling_evidence_boundary':'INPUT/CLOCK/SAMPLE/OUTPUT callback realtime is actual simulator evidence. Internal half-bit sample boundaries are independent predictions crosschecked against actual public input samples two clocks earlier; no direct internal probe or counter-as-timestamp claim.','independence_boundary':'Own fixtures/history frozen before first newwrapper source read. Prior parser/serializer RTL and TX composition/public UART documents exposure disclosed. No producer TB/oracle imports/execution.','saved_producer_review':'15savedmainruns and351probes, originalSTAT33 13warnings and9invalidrunneracceptances, finalrepair/source/20authorcommands retained and byte checked; no old3.7M/guards/mutants/72authorcases rerun','missing_final_audit_references':hist['missing_references'],'removed_transient_original_file':'historical producer disclosure only; not rehashable/restored','prior_F01':'OPEN, out of scope and untouched','not_run':['G03','R03','all29','B04','A_ABI_type_profile_source_session_BOOT_TTL_replay_motion','physical_clock_UART_electrical_CDC','synthesis','implementation','timing','build','board','system'],'actions':{'product_edits_stage_commit_reset':False,'board_serial_UI_services_credentials':False,'network_writes_or_external_messages':False,'delegation':False,'B_OOC33_pinlink34_Vivado_readback':False},'raw_storage':'full631MB producer raw in exclusive.local only; root small-selection plus immutable upstream tar/hash references, no duplicate large package','ASCII_mapping_cleanup_verified':True}
save_json(OUT/'result.json',result)
report=f'''# B RX31 限定独立复核

新同钟域 opaque UART→parser 小型数字仿真通过，未发现新DUT断言或接收/丢弃历史时序失败。正式接受、PR和peer反馈由A Gen3/root决定。

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，work `A-B-UART-WIRE-RX31-INDEPENDENT-20261024-v1`；新job `child-4a83c0aedab54603af14c9d1cadec738` canonical `/root/b_wire2829_review` 验证 execution_allowed=true。当前Gen3主与H01–H15重核，canonical requirements实算仍为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`。A/root唯一板操作者。

## 精确字节

PR30 https://github.com/carolwjade/CarlandFPGA/pull/30 ，tested head `{HEAD}`，直接parent/source `{SOURCE}`。Operation `{OP}`；request `a0419132c5d6f88d15dd97e18e03e28daec1be3777765d253fac03187faa2570`；manifest `06c386683a29d154a2fa954f3b3a7583637fe5b1710c81dc552b68928766547e`。21选定Git blobs（19operation/依赖+2公开文档）、canonical artifacts/sourcebinding、全部1551承诺raw成员（631,190,350 B）逐字节相符；不声称whole-top checkout。

原tar SHA256 `{ev['archive_sha256']}`，RAW_INDEX SHA256 `{ev['RAW_INDEX_sha256']}`。完整raw仅留task.local，没有复制入产品或另打大包。

## 独立顺序与新控制

公开wrapper/UART RX/parser文档→冻结fresh struct+binascii 0/1payload wire包及采样/丢弃history→首次新RX31 wrapper源阅读。此前已读parser/serializer依赖RTL及TX composition/public UART文档，不能称整个依赖栈盲测。没有导入/执行作者或main TB/oracle。

ModelSim SE-64 **2020.4**，clock刺激`clk10ns`：

| CLOCK_HZ/BAUD | 首次实际clocks | 断言 |
|---|---:|---:|
|16/1|7703|243|
|33/2|7938|243|

两次首次均exit0、Errors0/Warnings0；所有实际新时钟共 **15641**（含全部attempt，未重跑），低于25000硬预算。覆盖正确0/1包/端序/零尾与输出保持/退役；A5 partial后的false-start共享丢弃；输出stall时一个UART待字节再overrun，错误沿立即mask candidate、下一沿clear；坏CRC保持parser错误域、bad-stop framing；cancel/reset低电平不能虚构新的合格falling start，重新高电平资格与reset优先级。

仿真器原始callback CSV记录 **540次实际rx_async跳变、15641条实际公开输入采样记录**，另存CLOCK和公开输出变化的`$realtime` ps。独立checker复核94个正常UART字节、942个契约半位边界检查、4个候选上升及false/overrun/CRC/framing事件时间。输入fall后的第一个实际clock为c0，公开uart_busy起点核对c0+2T；half h按`ceil(h*CLOCK_HZ/(2*BAUD))`预测并核对对应真实CLOCK及两clock前的公开输入采样；终端busy变化、candidate+1T及shared-discard+1T由实际输出事件核对。

**公开INPUT/SAMPLE/OUTPUT时间是实际仿真记录；内部半位采样时刻是契约预测，没有直接探测内部寄存器，不以counter值反推timestamp。** 例16/1：false-start事件24,555,000ps、overrun52,165,000ps、CRC74,935,000ps、framing76,545,000ps，均与独立history一致。不是物理时钟/UART测量或CDC证明。20项小型日志/合成事件反例qualification符合预期；不算新DUT运行。

## 保存的生产者证据

旧3,725,739cycles/193,738,428checks、guards/mutants、72authorcases均未重跑。保存15个main run的RESULT/input/raw stdout/stderr绑定重核，351保存probe accepted/expected与样本hash一致。原STAT_W33的13warnings、旧runner接受9非法样本、最终width-clamp与runner修复、author5suites/7guards/20commands（19 exit0、vlib-version exit1例外）完整保留。

最终audit的7项明确reference均有字节（1归档路径、4canonical Git blobs、2private scope同hash归档副本），未发现其中缺失项。生产者披露的已删除out-of-ownership transient RESULT不再可rehash，未还原或伪称已验证。prepared-only final-run scripts没有算作执行；旧preinspection/acceptance仍是生产者记录。先前op28/29 F01保持OPEN，未触碰。

## 交接和边界

ROOT_ARCHIVE_SELECTION.json列较小的新CSV/命令/源pins/旧审计子集，并固定引用原upstream tar/hash；该小选择不内嵌631MB全量raw。全EVIDENCE_MANIFEST仍列本地完整留存字节。

没有产品编辑/stage/commit/reset、board/串口/UI/服务/credentials、网络写/外部消息或派工。B OOC33/pinlink34/Vivado readback不在本项。A ABI/type/profile/source/session/BOOT/TTL/replay/motion、physicalclock/CDC/synth/impl/timing/build/board/system未接受；G03/R03/all29/B04仍not_run。H01–H15完整保留。
'''
(OUT/'report.md').write_text(report,encoding='utf8')
small=[p for p in OUT.iterdir() if p.is_file() and p.name not in ['lease.private.json','ROOT_ARCHIVE_SELECTION.json','EVIDENCE_MANIFEST.json','MANIFEST.sha256.txt','manifest-readback.json','native-complete.json']]
small += [LOCAL/n for n in ['tb_rx31.sv','frame0.hex','frame1.hex']]
for p in (LOCAL/'focused-01').rglob('*'):
 if p.is_file() and 'work' not in p.relative_to(LOCAL/'focused-01').parts and (p.suffix in ['.bin','.json','.csv','.do'] or p.name=='transcript'):small.append(p)
for rel in ['main/final-audit-01/RESULT.json','main/runner-qualification-repair1-01/RESULT.json','main/runner-negative-01/RESULT.json','main/guards-mutants-01/FAILURE.json','main/guards-mutants-01/stat33/vsim.stdout.bin','main/guards-mutants-01/stat33/vsim.stderr.bin','author/repair1/REPAIR1_RESULT.json','author/RESULT.json']:small.append(LOCAL/'raw'/rel)
save_json(OUT/'ROOT_ARCHIVE_SELECTION.json',{'scope':'Small selected review archive descriptor only; no631MB full raw embedding or new package','files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(set(small))],'upstream_bundle_reference':{'commit':HEAD,'source_commit':SOURCE,'path':'competition/deepeye/evidence/transport/uart-wire-rx-20261024-31/publication/raw-evidence.tar.gz','sha256':ev['archive_sha256'],'members':1551,'raw_bytes':ev['raw_bytes'],'inline_all_raw_members':False},'post_seal_paths':[str((OUT/n).relative_to(ROOT)) for n in ['ROOT_ARCHIVE_SELECTION.json','EVIDENCE_MANIFEST.json','MANIFEST.sha256.txt','manifest-readback.json','native-complete.json']]})
print(json.dumps({'status':result['status'],'report_sha256':sha((OUT/'report.md').read_bytes()),'result_sha256':sha((OUT/'result.json').read_bytes()),'source_blobs':len(files),'small_selection_files':len(set(small))},indent=2))
