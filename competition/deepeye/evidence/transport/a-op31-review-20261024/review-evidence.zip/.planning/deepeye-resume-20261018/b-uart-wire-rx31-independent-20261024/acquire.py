import base64,hashlib,json,pathlib,subprocess,datetime,sys,concurrent.futures
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
LOCAL=ROOT/'.local/deepeye-b-uart-wire-rx31-review-20261024';LOCAL.mkdir(parents=True,exist_ok=True)
META=LOCAL/'metadata';META.mkdir(exist_ok=True)
SNAP=LOCAL/'snapshot';SNAP.mkdir(exist_ok=True)
HEAD='04e3a46eb1169afca0c133815a9b9f3da15d89f5'
SOURCE='bbfb11439b35e0866a6d2486f3857b92ed6cf529'
GH=r'C:/Program Files/GitHub CLI/gh.exe'
OP='B-DEEPEYE-UART-WIRE-RX-20261024-31'
def sha(b):return hashlib.sha256(b).hexdigest()
def save_json(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def api(endpoint,name):
 p=META/(name+'.json')
 if p.exists():return json.loads(p.read_bytes())
 argv=[GH,'api',endpoint];r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (META/(name+'.stderr.txt')).write_bytes(r.stderr)
 save_json(META/(name+'.command.json'),{'argv':argv,'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 if r.returncode:raise RuntimeError((name,r.returncode,r.stderr.decode(errors='replace')))
 p.write_bytes(r.stdout);return json.loads(r.stdout)
def entries(which='head'):
 return {e['path']:e for e in json.loads((META/(which+'-tree.json')).read_bytes())['tree'] if e['type']=='blob'}
def blob(path):
 es=entries();e=es[path];p=SNAP/path
 if p.exists():b=p.read_bytes()
 else:
  obj=api('repos/carolwjade/CarlandFPGA/git/blobs/'+e['sha'],'blob-'+e['sha']);b=base64.b64decode(obj['content']);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 gid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert gid==e['sha'] and len(b)==e['size']
 return {'path':path,'sha256':sha(b),'bytes':len(b),'git_blob':gid,'same_blob_at_source':entries('source').get(path,{}).get('sha')==gid}
def main():
 scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_bytes())
 h=sha(json.dumps(scope['requirements'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8'))
 assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
 transfer=json.loads((ROOT/'.planning/deepeye-desktop-handoff-20261015/transfer.json').read_bytes())
 assert transfer['director_generation']==3 and transfer['status']=='active' and transfer['new_director_thread_id']=='01a16988-bdcb-70e1-ae10-1304b5cf7875'
 save_json(OUT/'scope-validation.json',{'contract':'DEEPEYE-HUMAN-LOCK-20261014/revision1','canonical_requirements_sha256':h,'ids':[r['id'] for r in scope['requirements']],'director_generation':3,'director_thread':transfer['new_director_thread_id'],'physical_board_operator':'A/root only'})
 pr=api('repos/carolwjade/CarlandFPGA/pulls/30','pr30')
 hc=api('repos/carolwjade/CarlandFPGA/git/commits/'+HEAD,'head-commit')
 sc=api('repos/carolwjade/CarlandFPGA/git/commits/'+SOURCE,'source-commit')
 for name,rev in [('head',HEAD),('source',SOURCE)]:
  t=api('repos/carolwjade/CarlandFPGA/git/trees/'+rev+'?recursive=1',name+'-tree');assert not t.get('truncated')
 paths=[p for p in entries() if ('uart_wire' in p.lower() or 'uart-wire-rx-20261024-31' in p.lower())]
 save_json(OUT/'acquisition-index.json',{'pinned_head':HEAD,'pinned_source':SOURCE,'current_pr_head':pr['head']['sha'],'head_parent_shas':[p['sha'] for p in hc['parents']],'source_parent_shas':[p['sha'] for p in sc['parents']],'metadata_tree_complete':True,'snapshot_scope':'selected blobs only; no whole-top checkout claim','paths':paths})
 # Only public docs and publication/manifest metadata are read before oracle freeze.
 initial=[p for p in paths if p.endswith('.md') or p.endswith('.json')]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(blob,initial))
 save_json(OUT/'initial-Git-blobs.json',rows)
 print(json.dumps({'requirements_sha256':h,'current_pr_head':pr['head']['sha'],'paths':paths},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
