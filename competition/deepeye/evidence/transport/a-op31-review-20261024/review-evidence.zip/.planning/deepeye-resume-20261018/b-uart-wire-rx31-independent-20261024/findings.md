# Findings

Original human29/root assignment authorizes this review; peer reference effects_allowed=false grants no execution authority. A Gen3 remains sole main. New pins head04e3a46eb1169afca0c133815a9b9f3da15d89f5/sourcebbfb11439b35e0866a6d2486f3857b92ed6cf529.

21 selected blobs include19operation/dependencies+2public dependency docs, not whole-top. All1551 promised raw members631190350B verified.
First and only2new simulations clean:7703+7938=15641 actual clocks,486assertions. Actual callback CSV records540INPUT edges and15641public input-at-clock SAMPLE rows;94normalbytes/942documented half-sample checks and exact output/discard times match. Internal sample boundaries are predictions, not direct internal probes.20log/event probes pass.
Saved15main runs/351probes/7final-audit references verified; no missing in that list. Original STAT_W33 13warnings and9invalid runner acceptances retained, repair/source binding retained. Producer removed transient file remains historical non-rehashable, not restored. Prior op28/29F01 remains OPEN.
