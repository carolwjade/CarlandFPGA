# B RX31 限定独立复核

新同钟域 opaque UART→parser 小型数字仿真通过，未发现新DUT断言或接收/丢弃历史时序失败。正式接受、PR和peer反馈由A Gen3/root决定。

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，work `A-B-UART-WIRE-RX31-INDEPENDENT-20261024-v1`；新job `child-4a83c0aedab54603af14c9d1cadec738` canonical `/root/b_wire2829_review` 验证 execution_allowed=true。当前Gen3主与H01–H15重核，canonical requirements实算仍为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`。A/root唯一板操作者。

## 精确字节

PR30 https://github.com/carolwjade/CarlandFPGA/pull/30 ，tested head `04e3a46eb1169afca0c133815a9b9f3da15d89f5`，直接parent/source `bbfb11439b35e0866a6d2486f3857b92ed6cf529`。Operation `B-DEEPEYE-UART-WIRE-RX-20261024-31`；request `a0419132c5d6f88d15dd97e18e03e28daec1be3777765d253fac03187faa2570`；manifest `06c386683a29d154a2fa954f3b3a7583637fe5b1710c81dc552b68928766547e`。21选定Git blobs（19operation/依赖+2公开文档）、canonical artifacts/sourcebinding、全部1551承诺raw成员（631,190,350 B）逐字节相符；不声称whole-top checkout。

原tar SHA256 `aae437347fc69b355c2c04d20e2dc35b7c48cc691407dc4937e81d4c13958946`，RAW_INDEX SHA256 `0239f64059d92eb18fe8e8a3af48a09f452674dc378458bf4f5db66e3c89af39`。完整raw仅留task.local，没有复制入产品或另打大包。

## 独立顺序与新控制

公开wrapper/UART RX/parser文档→冻结fresh struct+binascii 0/1payload wire包及采样/丢弃history→首次新RX31 wrapper源阅读。此前已读parser/serializer依赖RTL及TX composition/public UART文档，不能称整个依赖栈盲测。没有导入/执行作者或main TB/oracle。

ModelSim SE-64 **2020.4**，clock刺激`clk10ns`：

| CLOCK_HZ/BAUD | 首次实际clocks | 断言 |
|---|---:|---:|
|16/1|7703|243|
|33/2|7938|243|

两次首次均exit0、Errors0/Warnings0；所有实际新时钟共 **15641**（含全部attempt，未重跑），低于25000硬预算。覆盖正确0/1包/端序/零尾与输出保持/退役；A5 partial后的false-start共享丢弃；输出stall时一个UART待字节再overrun，错误沿立即mask candidate、下一沿clear；坏CRC保持parser错误域、bad-stop framing；cancel/reset低电平不能虚构新的合格falling start，重新高电平资格与reset优先级。

仿真器原始callback CSV记录 **540次实际rx_async跳变、15641条实际公开输入采样记录**，另存CLOCK和公开输出变化的`$realtime` ps。独立checker复核94个正常UART字节、942个契约半位边界检查、4个候选上升及false/overrun/CRC/framing事件时间。输入fall后的第一个实际clock为c0，公开uart_busy起点核对c0+2T；half h按`ceil(h*CLOCK_HZ/(2*BAUD))`预测并核对对应真实CLOCK及两clock前的公开输入采样；终端busy变化、candidate+1T及shared-discard+1T由实际输出事件核对。

**公开INPUT/SAMPLE/OUTPUT时间是实际仿真记录；内部半位采样时刻是契约预测，没有直接探测内部寄存器，不以counter值反推timestamp。** 例16/1：false-start事件24,555,000ps、overrun52,165,000ps、CRC74,935,000ps、framing76,545,000ps，均与独立history一致。不是物理时钟/UART测量或CDC证明。20项小型日志/合成事件反例qualification符合预期；不算新DUT运行。

## 保存的生产者证据

旧3,725,739cycles/193,738,428checks、guards/mutants、72authorcases均未重跑。保存15个main run的RESULT/input/raw stdout/stderr绑定重核，351保存probe accepted/expected与样本hash一致。原STAT_W33的13warnings、旧runner接受9非法样本、最终width-clamp与runner修复、author5suites/7guards/20commands（19 exit0、vlib-version exit1例外）完整保留。

最终audit的7项明确reference均有字节（1归档路径、4canonical Git blobs、2private scope同hash归档副本），未发现其中缺失项。生产者披露的已删除out-of-ownership transient RESULT不再可rehash，未还原或伪称已验证。prepared-only final-run scripts没有算作执行；旧preinspection/acceptance仍是生产者记录。先前op28/29 F01保持OPEN，未触碰。

## 交接和边界

ROOT_ARCHIVE_SELECTION.json列较小的新CSV/命令/源pins/旧审计子集，并固定引用原upstream tar/hash；该小选择不内嵌631MB全量raw。全EVIDENCE_MANIFEST仍列本地完整留存字节。

没有产品编辑/stage/commit/reset、board/串口/UI/服务/credentials、网络写/外部消息或派工。B OOC33/pinlink34/Vivado readback不在本项。A ABI/type/profile/source/session/BOOT/TTL/replay/motion、physicalclock/CDC/synth/impl/timing/build/board/system未接受；G03/R03/all29/B04仍not_run。H01–H15完整保留。
