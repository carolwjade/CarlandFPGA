import json,pathlib,re,collections,difflib
from acquire import OUT,LOCAL,SNAP,sha,save_json
raw=LOCAL/'raw';members=json.loads((OUT/'raw-members.json').read_bytes());byhash={}
for r in members:byhash.setdefault(r['sha256'],[]).append(r['path'])
prefix='competition/deepeye/evidence/transport/uart-wire-rx-20261024-31/'
def resolve(p,h):
 norm=p.replace('\\','/');i=norm.find('competition/')
 if i>=0:
  norm=norm[i:];q=raw/norm[len(prefix):] if norm.startswith(prefix) else SNAP/norm
  if q.exists():assert sha(q.read_bytes())==h;return {'mode':'archive path' if norm.startswith(prefix) else 'canonical Git blob','path':str(q.relative_to(LOCAL))}
 if h in byhash:return {'mode':'same-hash archived copy; original absolute B path not accessed','paths':byhash[h]}
 return {'mode':'missing'}
ap=raw/'main/final-audit-01/RESULT.json';a=json.loads(ap.read_bytes());refs=[]
for p,h in a['author_references'].items():refs.append({'reference':p,'sha256':h,**resolve(p,h)})
sources=[]
for p,h in a['final_sources'].items():
 match=resolve(p,h);assert match['mode']!='missing';sources.append({'reference':p,'sha256':h,**match})
runs=[]
for row in a['main_runs']:
 p=raw/row['path'];assert sha(p.read_bytes())==row['sha256'];res=json.loads(p.read_bytes());pipes=0
 for c in res['commands']:
  for stream in ['stdout','stderr']:
   assert sha((p.parent/(c['name']+'.'+stream+'.bin')).read_bytes())==c[stream+'_sha256'];pipes+=1
 for filename,d in res['inputs'].items():assert sha((p.parent/filename).read_bytes())==(d['sha256'] if isinstance(d,dict) else d)
 log=(p.parent/'vsim.stdout.bin').read_bytes()
 for ex in res['numeric_counterexamples']:assert ex.encode() in log
 runs.append({'path':row['path'],'sha256':row['sha256'],'mode':res['mode'],'producer_classifier_accepted':res['accepted'],'saved_pipes_verified':pipes,'numeric_counterexamples':res['numeric_counterexamples'],'DUT_binding':res['inputs']['dut.sv']})
qp=raw/'main/runner-qualification-repair1-01/RESULT.json';q=json.loads(qp.read_bytes());assert len(q['probes'])==351
for r in q['probes']:assert r['accepted']==r['expected'] and r['sha256'] in byhash
negative=json.loads((raw/'main/runner-negative-01/RESULT.json').read_bytes());assert negative['actual_invalid_accepted']==9
for r in negative['tests']:assert r['sha256'] in byhash
failure=json.loads((raw/'main/guards-mutants-01/FAILURE.json').read_bytes());orig=raw/'main/guards-mutants-01/stat33/vsim.stdout.bin';log=orig.read_bytes()
assert sha(log)==failure['raw_log_sha256'];warnings=re.findall(rb'\*\* Warning:',log);assert len(warnings)==13
assert b'deepeye_uart_wire_rx: STAT_W out of range' in log
old=(raw/'main/guards-mutants-01/stat33/dut.sv').read_text();new=(SNAP/'competition/deepeye/fpga/transport/deepeye_uart_wire_rx.sv').read_text();diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original-width-warning-source',tofile='exact-final-head'))
(OUT/'producer-width-repair.diff.txt').write_text(diff,encoding='utf8')
repair=json.loads((raw/'author/repair1/REPAIR1_RESULT.json').read_bytes())
authorcmds=a['author_commands'];exits=collections.Counter(r['actual_exit'] for r in authorcmds)
assert len(authorcmds)==20 and exits[0]==19 and exits[1]==1
for c in authorcmds:
 for h in c['pipes'].values():assert h in byhash
missing=[r for r in refs if r['mode']=='missing']
result={'producer_final_audit_sha256':sha(ap.read_bytes()),'author_references':refs,'missing_references':missing,'final_sources':sources,'saved_main_runs':runs,'old_counts_only':{k:a[k] for k in ['main_cycles','main_port_checks','main_guards','compiled_behavioral_mutants','final_author_cases','final_author_checks']},'saved_log_probes':{'count':351,'all_expected':True,'sample_hashes_present':True},'original_runner_invalid_acceptance':{'count':9,'tests':negative['tests']},'original_STAT33_failure':{'warnings_count':13,'failure':failure,'raw_stdout_sha256':sha(log),'final_source_diff':'producer-width-repair.diff.txt'},'final_author_saved_suites':a['author_suites_reclassified'],'final_author_saved_guards':a['author_guards_reclassified'],'author_command_exits':dict(exits),'saved_author_repair_original':repair['original'],'saved_author_repair_changes':repair['repair'],'saved_author_repair_validation':repair['validation'],'removed_original_evidence':'Producer discloses removed transient out-of-ownership RESULT; its former observed hash is historical only, not rehashable or restored. No removed-file hash verification claim.','prepared_only_scripts':'Prepared final-run commands are not counted as executed; only saved actual process receipts/runs in this report are inspected.','new_vendor_or_author_runs_by_history_review':0,'prior_F01':'OPEN and out of this task; no edits or closure'}
save_json(OUT/'history-review.json',result);print(json.dumps({'saved_main_runs':len(runs),'saved_probes':351,'author_references':len(refs),'missing_references':missing,'original_warnings':len(warnings),'original_invalid_acceptances':9,'author_exit_counts':dict(exits)},indent=2))
