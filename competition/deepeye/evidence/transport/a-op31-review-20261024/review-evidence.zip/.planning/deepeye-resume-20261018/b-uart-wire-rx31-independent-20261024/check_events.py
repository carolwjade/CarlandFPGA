import csv,json,bisect,copy,re,traceback
from acquire import OUT,LOCAL,sha,save_json
PLAN=json.loads((OUT/'oracle-freeze.json').read_bytes());T=10000
def parse(p):
 rows=list(csv.DictReader(p.open(encoding='ascii',newline='')))
 for r in rows:
  for k in ['time_ps','phase','byte_id']:r[k]=int(r[k])
 return rows
def cd(a,b):return (a+b-1)//b
def check(rows,cfg):
 clocks=[r['time_ps'] for r in rows if r['kind']=='CLOCK'];assert clocks==list(range(5000,clocks[-1]+1,T)),'clock stimulus timestamps'
 samples={r['time_ps']:r for r in rows if r['kind']=='SAMPLE'};assert len(samples)==len(clocks),'actual input sample row per clock'
 byte_rows=[r for r in rows if r['kind']=='BYTE'];f0=list(bytes.fromhex(PLAN['frames'][0]['wire_hex']));f1=list(bytes.fromhex(PLAN['frames'][1]['wire_hex']))
 seq={1:[(b,1) for b in f0],2:[(0xa5,1)],3:[(b,1) for b in f1],4:[(0x11,1),(0x22,1)],5:[(b^(1 if i==len(f0)-1 else 0),1) for i,b in enumerate(f0)],6:[(0x33,0)]}
 for phase,expected in seq.items():
  actual=[(int(r['label'].split('_')[0],16),int(r['label'][-1])) for r in byte_rows if r['phase']==phase];assert actual==expected,'frozen byte history'
 outs=[r for r in rows if r['kind']=='OUTPUT'];terminals={};halfchecks=0;events=[]
 for br in byte_rows:
  start=br['time_ps'];bid=br['byte_id'];v=int(br['label'].split('_')[0],16);stop=int(br['label'][-1])
  assert any(r['kind']=='INPUT' and r['time_ps']==start and r['rx']=='0' for r in rows),'actual falling input event missing'
  c0=clocks[bisect.bisect_right(clocks,start)];detect=c0+2*T
  assert any(r['time_ps']==detect and r['busy']=='1' for r in outs),'actual UART busy start differs from documented older-sync delay'
  for h in [1,3,5,7,9,11,13,15,17,19]:
   required=detect+cd(h*cfg['CLOCK_HZ'],2*cfg['BAUD'])*T
   assert required in clocks,'predicted sample boundary missing actual clock'
   source=required-2*T+1
   expected=0 if h==1 else stop if h==19 else (v>>((h-3)//2))&1
   assert int(samples[source]['rx'])==expected,'documented older-sync input sample value'
   halfchecks+=1
  terminal=detect+cd(19*cfg['CLOCK_HZ'],2*cfg['BAUD'])*T;terminals[bid]=terminal
  assert any(r['time_ps']==terminal and r['busy']=='0' for r in outs),'actual terminal busy edge'
  events.append({'byte_id':bid,'phase':br['phase'],'value':v,'stop':stop,'actual_input_fall_ps':start,'first_observed_clock_ps':c0,'predicted_detect_ps':detect,'observed_busy_rise_ps':detect,'predicted_terminal_ps':terminal,'observed_busy_fall_ps':terminal})
 for phase in [1,3]:
  last=[r for r in byte_rows if r['phase']==phase][-1];expected=terminals[last['byte_id']]+T
  valid=[r for r in outs if r['phase']==phase and r['valid']=='1'];assert valid and min(r['time_ps'] for r in valid)==expected,'candidate rising time'
 falsemark=next(r for r in rows if r['kind']=='MARK' and r['label']=='FALSE_START_BEGIN');start=falsemark['time_ps'];c0=clocks[bisect.bisect_right(clocks,start)];false_time=c0+2*T+cd(cfg['CLOCK_HZ'],2*cfg['BAUD'])*T
 assert any(r['time_ps']==false_time and r['line']=='1' for r in outs),'false-start event time'
 assert any(r['time_ps']==false_time+T and r['line']=='0' and r['aborted']=='1' for r in outs),'next-edge partial discard'
 over=[r for r in byte_rows if r['phase']==4][-1];over_time=terminals[over['byte_id']]
 assert any(r['time_ps']==over_time and r['line']=='4' and r['valid']=='0' for r in outs),'overrun event immediately masks candidate'
 assert any(r['time_ps']==over_time+T and r['line']=='0' and r['aborted']=='2' for r in outs),'overrun next-edge discard'
 bad=[r for r in byte_rows if r['phase']==5][-1];crc_time=terminals[bad['byte_id']]+T
 assert any(r['time_ps']==crc_time and r['error']=='3' and r['line']=='0' for r in outs),'CRC parser diagnostic time'
 assert not any(r['valid']=='1' or r['line']!='0' for r in outs if r['phase']==5),'bad CRC cannot create candidate/line cancel'
 framing=[r for r in byte_rows if r['phase']==6][-1];frame_time=terminals[framing['byte_id']]
 assert any(r['time_ps']==frame_time and r['line']=='2' for r in outs),'framing diagnostic time'
 assert not any(r['busy']=='1' or r['valid']=='1' for r in outs if r['phase']==7),'held-low requalification'
 return {'config':cfg,'actual_clocks':len(clocks),'actual_input_edges':sum(r['kind']=='INPUT' for r in rows),'actual_public_sample_rows':len(samples),'normal_bytes_checked':len(byte_rows),'documented_half_sample_checks':halfchecks+1,'byte_event_times':events,'observed_false_start_ps':false_time,'observed_overrun_ps':over_time,'observed_crc_error_ps':crc_time,'observed_framing_ps':frame_time,'candidate_rise_times':[min(r['time_ps'] for r in outs if r['phase']==ph and r['valid']=='1') for ph in [1,3]],'scope':'Input/clock/public output times are actual simulator records. Internal half-sampling times are predictions crosschecked against actual input-at-clock rows, not direct internal probing.'}
CASES=['good0 PASS','false_start PASS','good1 PASS','overrun PASS','bad_crc PASS','framing PASS','cancel_reset_low PASS']
def classify(data,cfg):
 if re.search(rb'(?im)^[#\s]*(?:\*\*\s*)?(?:Error|Warning|Fatal)\s*:',data):return False
 if re.findall(rb'Errors:\s*(\d+),\s*Warnings:\s*(\d+)',data)!=[(b'0',b'0')]:return False
 ls=[s.strip().lstrip(b'#').strip().decode('ascii',errors='replace') for s in data.splitlines() if b'RX31_' in s]
 return len(ls)==8 and ls[:7]==['RX31_CASE '+s for s in CASES] and re.fullmatch(rf'RX31_PASS clock={cfg["CLOCK_HZ"]} baud={cfg["BAUD"]} checks=243 cycles=[1-9][0-9]*',ls[-1]) is not None
def main():
 results=[];probes=[]
 for cfg in PLAN['configs']:
  p=LOCAL/'focused-01'/cfg['id'];rows=parse(p/'rx-events.csv');r=check(rows,cfg);r['csv_sha256']=sha((p/'rx-events.csv').read_bytes());results.append(r)
  data=(p/'vsim.stdout.bin').read_bytes()+(p/'vsim.stderr.bin').read_bytes();assert classify(data,cfg)
  for name,mut,want in [('positive',data,True),('warning',data+b'\n# Warning: synthetic\n',False),('duplicate',data+b'\n# RX31_CASE good0 PASS\n',False),('unknown',data+b'\n# RX31_FALLBACK\n',False),('extra_tally',data+b'\n# Errors: 1, Warnings: 0\n',False),('missing',data.replace(b'RX31_CASE overrun PASS',b'IGNORED'),False)]:
   accepted=classify(mut,cfg);assert accepted==want;probes.append({'config':cfg['id'],'kind':'log','name':name,'accepted':accepted,'expected':want,'sha256':sha(mut),'synthetic':name!='positive'})
  for name in ['candidate_clock_late','false_start_late','sample_bit_inversion','clock_time_error']:
   mut=copy.deepcopy(rows)
   if name=='candidate_clock_late':
    t=min(r['time_ps'] for r in mut if r['kind']=='OUTPUT' and r['phase']==1 and r['valid']=='1')
    for r in mut:
     if r['kind']=='OUTPUT' and r['time_ps']==t and r['phase']==1:r['time_ps']+=T
   elif name=='false_start_late':
    for r in mut:
     if r['kind']=='OUTPUT' and r['phase']==2 and r['line']=='1':r['time_ps']+=T
   elif name=='sample_bit_inversion':
    first=next(r for r in mut if r['kind']=='BYTE');c0=next(r['time_ps'] for r in mut if r['kind']=='CLOCK' and r['time_ps']>first['time_ps']);s=c0+cd(3*cfg['CLOCK_HZ'],2*cfg['BAUD'])*T+1
    row=next(r for r in mut if r['kind']=='SAMPLE' and r['time_ps']==s);row['rx']='0' if row['rx']=='1' else '1'
   else:next(r for r in mut if r['kind']=='CLOCK')['time_ps']+=1000
   try:check(mut,cfg);accepted=True
   except AssertionError:accepted=False
   assert not accepted,name;probes.append({'config':cfg['id'],'kind':'synthetic_event','name':name,'accepted':False,'expected':False,'synthetic':True,'sha256':sha(json.dumps(mut,sort_keys=True).encode())})
 assert sum(r['actual_clocks'] for r in results)<=25000
 save_json(OUT/'event-verification.json',{'passed':True,'results':results,'total_actual_clocks':sum(r['actual_clocks'] for r in results),'total_documented_half_sample_checks':sum(r['documented_half_sample_checks'] for r in results)})
 save_json(OUT/'own-log-event-qualification.json',{'all_expected':True,'probes':probes,'new_simulator_runs':0});print(json.dumps({'passed':True,'actual_clocks':sum(r['actual_clocks'] for r in results),'normal_bytes':sum(r['normal_bytes_checked'] for r in results),'half_sample_checks':sum(r['documented_half_sample_checks'] for r in results),'probes':len(probes)},indent=2))
if __name__=='__main__':
 try:main()
 except Exception:
  (OUT/'event-check-first-failure.txt').write_text(traceback.format_exc(),encoding='utf8');raise
