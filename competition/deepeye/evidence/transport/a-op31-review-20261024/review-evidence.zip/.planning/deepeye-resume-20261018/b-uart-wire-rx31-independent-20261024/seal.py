import pathlib,json,datetime,sys
from acquire import OUT,ROOT,LOCAL,sha,save_json
manifest=OUT/'EVIDENCE_MANIFEST.json'
exclusions={'lease.private.json','EVIDENCE_MANIFEST.json','MANIFEST.sha256.txt','manifest-readback.json','native-complete.json'}
def rows():
 ans=[]
 for folder in [OUT,LOCAL]:
  for p in sorted(folder.rglob('*')):
   if not p.is_file() or (p.parent==OUT and p.name in exclusions):continue
   b=p.read_bytes();ans.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':sha(b)})
 return ans
if len(sys.argv)>1 and sys.argv[1]=='verify':
 obj=json.loads(manifest.read_bytes())
 for row in obj['files']:
  b=(ROOT/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
 assert rows()==obj['files'],'frozen file set changed'
 digest=sha(manifest.read_bytes());assert (OUT/'MANIFEST.sha256.txt').read_text().split()[0]==digest
 r={'status':'all_frozen_file_hashes_read_back','file_count':len(obj['files']),'manifest_sha256':digest,'report_sha256':sha((OUT/'report.md').read_bytes()),'result_sha256':sha((OUT/'result.json').read_bytes()),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 save_json(OUT/'manifest-readback.json',r);print(json.dumps(r,indent=2))
else:
 obj={'schema':1,'work_id':'A-B-UART-WIRE-RX31-INDEPENDENT-20261024-v1','scope':'All retained task-owned planning/local evidence, including original631MB raw bytes in local cache. This manifest is not a new package. Private token and post-seal completion/readback records excluded.','exclusions':sorted(exclusions),'files':rows()}
 save_json(manifest,obj);digest=sha(manifest.read_bytes());(OUT/'MANIFEST.sha256.txt').write_text(digest+'  EVIDENCE_MANIFEST.json\n',encoding='ascii')
 print(json.dumps({'file_count':len(obj['files']),'manifest_sha256':digest},indent=2))
