import json,pathlib,hashlib
from acquire import ROOT,OUT,LOCAL,sha,save_json
from check_events import parse,check,classify
s=json.loads((OUT/'SOURCE_HASH_MANIFEST.json').read_bytes());plan=json.loads((OUT/'oracle-freeze.json').read_bytes());frozen=json.loads((OUT/'oracle-freeze-hashes.json').read_bytes())
assert sha((OUT/'oracle-freeze.json').read_bytes())==frozen['oracle-freeze.json']
hashes={}
for row in s['files']:
 b=(LOCAL/'snapshot'/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob'];hashes[pathlib.Path(row['path']).name]=row['sha256']
hashes['tb_rx31.sv']=sha((LOCAL/'tb_rx31.sv').read_bytes());assert hashes['tb_rx31.sv']==s['own_TB']['sha256']
for n in [0,1]:assert sha((LOCAL/f'frame{n}.hex').read_bytes())==frozen[f'frame{n}.hex']
compile_inputs=json.loads((LOCAL/'focused-01/inputs-freeze.json').read_bytes())
for row in compile_inputs['files']:assert row['sha256']==hashes[pathlib.PureWindowsPath(row['path']).name]
total=0
for cfg in plan['configs']:
 p=LOCAL/'focused-01'/cfg['id'];assert classify((p/'vsim.stdout.bin').read_bytes()+(p/'vsim.stderr.bin').read_bytes(),cfg);r=check(parse(p/'rx-events.csv'),cfg);total+=r['actual_clocks']
assert total==15641<=25000
assert json.loads((OUT/'own-log-event-qualification.json').read_bytes())['all_expected']
cl=json.loads((OUT/'mapping-cleanup-focused-01.json').read_bytes());assert cl['mapping_absent_after'] and cl['logical_drive_absent_after']
hist=json.loads((OUT/'history-review.json').read_bytes());assert not hist['missing_references']
sel=json.loads((OUT/'ROOT_ARCHIVE_SELECTION.json').read_bytes())
for row in sel['files']:
 b=(ROOT/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
v={'status':'fresh_verification_passed','actual_new_clocks':total,'configs':2,'assertions':486,'actual_input_edges':540,'actual_public_input_sample_rows':15641,'normal_bytes_checked':94,'documented_half_sample_checks':942,'log_event_qualification_probes':20,'raw_members':1551,'source_blobs':21,'report_sha256':sha((OUT/'report.md').read_bytes()),'result_sha256':sha((OUT/'result.json').read_bytes())};save_json(OUT/'delivery-verification.json',v);print(json.dumps(v,indent=2))
