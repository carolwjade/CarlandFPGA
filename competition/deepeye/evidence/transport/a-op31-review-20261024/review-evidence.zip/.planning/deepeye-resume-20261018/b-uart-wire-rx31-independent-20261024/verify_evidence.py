import json,pathlib,concurrent.futures,tarfile,hashlib
from acquire import OUT,LOCAL,SNAP,HEAD,SOURCE,OP,blob,sha,save_json
mp=f'handoffs/b/{OP}/manifest.json';m=json.loads((SNAP/mp).read_bytes())
assert sha((SNAP/mp).read_bytes())=='06c386683a29d154a2fa954f3b3a7583637fe5b1710c81dc552b68928766547e'
rh=sha(json.dumps(m['request'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode());assert rh==m['request_hash']=='a0419132c5d6f88d15dd97e18e03e28daec1be3777765d253fac03187faa2570'
assert m['request']['code_commit']==SOURCE
pub=SNAP/'competition/deepeye/evidence/transport/uart-wire-rx-20261024-31/publication';binding=json.loads((pub/'SOURCE_BINDING.json').read_bytes());deps={p.replace('\\','/'):h for p,h in binding['dependencies'].items()}
paths=sorted(set(json.loads((OUT/'acquisition-index.json').read_bytes())['paths']+m['artifacts']+list(deps)))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(blob,paths))
for p,d in m['files'].items():b=(SNAP/p).read_bytes();assert sha(b)==d['sha256'] and len(b)==d['size']
assert set(m['files'])==set(m['artifacts'])
for p,h in {**binding['sources'],**deps}.items():assert sha((SNAP/p).read_bytes())==h
bundle=json.loads((pub/'BUNDLE_MANIFEST.json').read_bytes());assert sha((pub/bundle['archive']).read_bytes())==bundle['sha256'];assert sha((pub/bundle['index']).read_bytes())==bundle['index_sha256']
idx=json.loads((pub/bundle['index']).read_bytes())['files'];raw=LOCAL/'raw';raw.mkdir(exist_ok=True);members=[]
with tarfile.open(pub/bundle['archive'],'r:gz') as tf:
 for member in tf.getmembers():
  assert member.isfile();parts=pathlib.PurePosixPath(member.name.replace('\\','/')).parts;assert '..' not in parts and not member.name.startswith(('/', '\\')) and ':' not in member.name
  p=raw.joinpath(*parts);p.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256();size=0
  with tf.extractfile(member) as fi,p.open('wb') as fo:
   while True:
    b=fi.read(1048576)
    if not b:break
    h.update(b);size+=len(b);fo.write(b)
  d=idx[member.name];assert size==d['bytes'] and h.hexdigest()==d['sha256'];members.append({'path':member.name,'bytes':size,'sha256':h.hexdigest()})
assert len(members)==len(idx)==bundle['members']==1551 and set(idx)=={x['path'] for x in members}
save_json(OUT/'raw-members.json',members);save_json(OUT/'Git-blob-verification.json',rows)
save_json(OUT/'evidence-verification.json',{'operation_id':OP,'tested_head':HEAD,'source_commit':SOURCE,'request_hash':rh,'manifest_sha256':sha((SNAP/mp).read_bytes()),'selected_operation_dependency_blobs':len(rows),'raw_members':1551,'raw_bytes':sum(r['bytes'] for r in members),'archive_sha256':bundle['sha256'],'RAW_INDEX_sha256':bundle['index_sha256'],'dependencies':deps,'all_artifacts_and_source_binding_verified':True})
print(json.dumps({'selected_blobs':len(rows),'raw_members':1551,'raw_bytes':sum(r['bytes'] for r in members),'archive_sha256':bundle['sha256']},indent=2))
