`timescale 1ns/1ps
module tb_rx31;
 parameter integer CLOCK_HZ=16,BAUD=1,MAX_CLOCKS=8300;
 reg clk=0;always #5 clk=~clk;
 reg rst=0,cancel=0,rx_async=1,out_ready=0;
 wire out_valid,uart_busy,receiving,line_error_event,error_event;
 wire[7:0]out_type,out_epoch;wire[15:0]out_seq;wire[31:0]out_tick;wire[5:0]out_len;wire[255:0]out_payload;
 wire[2:0]line_error_bits;wire[1:0]error_code;
 wire[31:0]stat_uart_frames,stat_uart_retired,stat_uart_overruns,stat_uart_framing,stat_uart_false_starts,stat_uart_aborted;
 wire[31:0]stat_bytes,stat_frames,stat_retired,stat_version,stat_length,stat_crc,stat_aborted;
 deepeye_uart_wire_rx #(.CLOCK_HZ(CLOCK_HZ),.BAUD(BAUD),.STAT_W(32)) dut(.*);
 reg[7:0]f0[0:13],f1[0:14];integer fd,cycles=0,checks=0,phase=0,byte_id=-1,line_events=0,parser_errors=0;
 reg[2:0]last_line=0;reg[1:0]last_error=0;
 initial begin fd=$fopen("rx-events.csv","w");$fwrite(fd,"kind,time_ps,phase,byte_id,label,rx,busy,valid,line,error,uart_frames,frames,aborted\n");end
 task log_(input string kind_,input string label_);
  if(fd)$fwrite(fd,"%s,%0.0f,%0d,%0d,%s,%b,%b,%b,%0d,%0d,%0d,%0d,%0d\n",kind_,$realtime*1000,phase,byte_id,label_,rx_async,uart_busy,out_valid,line_error_bits,error_code,stat_uart_frames,stat_frames,stat_aborted);
 endtask
 always @(rx_async)log_("INPUT","rx_async");
 always @(uart_busy or out_valid or line_error_bits or error_code or stat_uart_frames or stat_frames or stat_aborted)log_("OUTPUT","public");
 always @(posedge clk)begin
  cycles=cycles+1;log_("CLOCK","clk10ns");
  if(cycles>=MAX_CLOCKS)$fatal(1,"RX31_FAIL finite clock budget");
  #0.001;log_("SAMPLE","public_rx_after_edge");
  if(line_error_event)begin line_events=line_events+1;last_line=line_error_bits;end
  if(error_event)begin parser_errors=parser_errors+1;last_error=error_code;end
 end
 task ck(input bit ok,input string label_);checks=checks+1;if(!ok)$fatal(1,"RX31_FAIL %s cycle=%0d",label_,cycles);endtask
 task step;@(posedge clk);#1;endtask
 task idle_(input integer n);repeat(n)step;endtask
 function integer boundary(input integer k);boundary=(k*CLOCK_HZ+BAUD-1)/BAUD;endfunction
 task send_byte(input reg[7:0]v,input bit good_stop);
  integer k,j,delta;
  @(negedge clk);byte_id=byte_id+1;rx_async=0;log_("BYTE",$sformatf("%02x_stop%0d",v,good_stop));
  for(k=1;k<=10;k=k+1)begin
   delta=boundary(k)-boundary(k-1);
   repeat(delta)@(negedge clk);
   if(k<=8)rx_async=v[k-1];else if(k==9)rx_async=good_stop;else rx_async=1;
  end
  log_("BYTE_END","complete_stimulus");idle_(2);
 endtask
 task packet(input integer n,input bit bad_crc);
  integer i;reg[7:0]b;
  for(i=0;i<n+14;i=i+1)begin b=n?f1[i]:f0[i];if(bad_crc&&i==n+13)b=b^8'h01;send_byte(b,1);end
 endtask
 task descriptor(input integer n);
  integer i;
  ck(out_valid&&out_type==8'hb2&&out_epoch==8'h17&&out_seq==16'h3da6&&out_tick==32'h8b5134c0&&out_len==n,"opaque descriptor endian");
  for(i=0;i<32;i=i+1)ck(out_payload[8*i+:8]===((n&&i==0)?8'he7:8'h00),"payload layout/zero tail");
 endtask
 initial begin
  $readmemh("frame0.hex",f0);$readmemh("frame1.hex",f1);
  @(negedge clk);rst=1;cancel=1;idle_(2);
  ck(!out_valid&&!uart_busy&&!receiving&&stat_uart_frames==0&&stat_frames==0,"reset priority");
  @(negedge clk);rst=0;cancel=0;idle_(6);
  phase=1;log_("MARK","GOOD0_BEGIN");packet(0,0);descriptor(0);
  repeat(4)begin step;descriptor(0);end
  @(negedge clk);out_ready=1;step;ck(!out_valid&&stat_retired==1,"candidate retire");
  @(negedge clk);out_ready=0;log_("MARK","GOOD0_END");$display("RX31_CASE good0 PASS");
  phase=2;send_byte(8'ha5,1);ck(receiving&&!out_valid,"partial A5 prefix");
  @(negedge clk);byte_id=byte_id+1;rx_async=0;log_("MARK","FALSE_START_BEGIN");
  @(negedge clk);rx_async=1;idle_(24);
  ck(line_events==1&&last_line==1&&stat_uart_false_starts==1&&!receiving&&!out_valid&&stat_aborted==1,"false start shared discard");
  $display("RX31_CASE false_start PASS");
  phase=3;log_("MARK","GOOD1_BEGIN");packet(1,0);descriptor(1);log_("MARK","GOOD1_PENDING");
  $display("RX31_CASE good1 PASS");
  phase=4;send_byte(8'h11,1);descriptor(1);ck(stat_uart_overruns==0,"first stalled UART slot");send_byte(8'h22,1);
  ck(line_events==2&&last_line==4&&stat_uart_overruns==1&&!out_valid&&!receiving&&stat_aborted==2,"overrun masks/discards pending candidate");
  $display("RX31_CASE overrun PASS");
  idle_(8);phase=5;packet(0,1);
  ck(parser_errors==1&&last_error==3&&stat_crc==1&&!out_valid&&line_events==2,"CRC parser reject without line cancel");
  $display("RX31_CASE bad_crc PASS");
  phase=6;send_byte(8'h33,0);idle_(8);
  ck(line_events==3&&last_line==2&&stat_uart_framing==1&&!out_valid&&!uart_busy,"bad stop shared discard");
  $display("RX31_CASE framing PASS");
  phase=7;@(negedge clk);rx_async=0;cancel=1;log_("MARK","CANCEL_LOW");idle_(3);
  @(negedge clk);cancel=0;idle_(10);ck(!uart_busy&&!out_valid&&!receiving,"low after cancel cannot qualify falling edge");
  @(negedge clk);rst=1;cancel=1;idle_(2);ck(stat_uart_frames==0&&stat_frames==0&&stat_aborted==0&&!uart_busy,"reset over held cancel");
  @(negedge clk);rst=0;cancel=0;idle_(10);ck(!uart_busy&&!out_valid,"low after reset cannot qualify");
  @(negedge clk);rx_async=1;idle_(8);ck(!uart_busy&&!out_valid,"high alone no frame");
  log_("MARK","FINISH");$fclose(fd);fd=0;
  $display("RX31_CASE cancel_reset_low PASS");
  $display("RX31_PASS clock=%0d baud=%0d checks=%0d cycles=%0d",CLOCK_HZ,BAUD,checks,cycles);$finish;
 end
endmodule
