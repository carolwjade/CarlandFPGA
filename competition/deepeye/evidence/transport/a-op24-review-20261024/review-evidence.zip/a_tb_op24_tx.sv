`timescale 1ns/1ps
module a_tb_op24_tx;
  parameter integer CLOCK_HZ=101, BAUD=7, STAT_W=3;
  localparam integer SW=(STAT_W>=2 && STAT_W<=32) ? STAT_W : 2;
  reg clk=0, rst=0, cancel=0, in_valid=0;
  reg [7:0] in_data=0;
  wire tx,busy,in_ready;
  wire [SW-1:0] stat_accepted,stat_completed,stat_aborted;
  deepeye_uart_tx #(.CLOCK_HZ(CLOCK_HZ),.BAUD(BAUD),.STAT_W(STAT_W)) dut(.*);
  always #5 clk=~clk;
  bit known=0, occupied=0, line_value=1;
  reg [7:0] byte_value;
  longint unsigned age=0, accepted=0, finished=0, killed=0, sat_limit;
  longint unsigned checks=0, edges=0, admissions_total=0, completions_total=0, aborts_total=0, reset_edges=0;
  reg [31:0] random_state=32'h46c90b13;
  integer i,k,j,bit_number;
  function automatic longint unsigned deadline(input integer boundary);
    deadline=(64'd1*boundary*CLOCK_HZ+BAUD-1)/BAUD;
  endfunction
  task automatic demand(input bit okay,input string field);
    begin checks=checks+1; if(!okay) begin
      $display("A_FAIL edge=%0d field=%s age=%0d",edges,field,age);
      $fatal(1,"A op24 public port mismatch");
    end end
  endtask
  task automatic tick(input bit r,input bit c,input bit v,input [7:0] d);
    begin
      @(negedge clk); rst=r; cancel=c; in_valid=v; in_data=d; #1;
      if(known) begin
        demand(tx===line_value,"registered_tx"); demand(busy===occupied,"registered_busy");
        demand(in_ready===(!r&&!c&&!occupied),"ready_before_edge");
      end
      @(posedge clk); edges=edges+1;
      if(r) begin
        known=1; occupied=0; line_value=1; age=0; accepted=0; finished=0; killed=0; reset_edges=reset_edges+1;
      end else if(c) begin
        if(occupied) begin if(killed<sat_limit) killed=killed+1; aborts_total=aborts_total+1; end
        occupied=0; line_value=1; age=0;
      end else if(occupied) begin
        age=age+1;
        if(age>=deadline(10)) begin
          occupied=0; line_value=1; if(finished<sat_limit) finished=finished+1; completions_total=completions_total+1;
        end else begin
          bit_number=0;
          for(integer b=1;b<=9;b=b+1) if(age>=deadline(b)) bit_number=b;
          if(bit_number==0) line_value=0;
          else if(bit_number==9) line_value=1;
          else line_value=byte_value[bit_number-1];
        end
      end else if(v) begin
        byte_value=d; occupied=1; line_value=0; age=0;
        if(accepted<sat_limit) accepted=accepted+1; admissions_total=admissions_total+1;
      end
      #1;
      demand(tx===line_value,"tx"); demand(busy===occupied,"busy");
      demand(in_ready===(!r&&!c&&!occupied),"ready_after_edge");
      demand(stat_accepted===accepted[SW-1:0],"stat_accepted");
      demand(stat_completed===finished[SW-1:0],"stat_completed");
      demand(stat_aborted===killed[SW-1:0],"stat_aborted");
    end
  endtask
  task automatic drain;
    begin while(occupied) tick(0,0,1,~byte_value); tick(0,0,0,0); end
  endtask
  initial begin
    sat_limit=(64'd1<<STAT_W)-1;
    $display("A_BEGIN clock=%0d baud=%0d stat=%0d",CLOCK_HZ,BAUD,STAT_W);
    tick(1,1,1,8'hff); tick(0,0,0,0);
    for(i=0;i<29;i=i+1) tick(0,0,0,i[7:0]);
    for(i=0;i<256;i=i+1) begin tick(0,0,1,i[7:0]); drain(); end
    // Interrupt at each would-be bit boundary; data is changed throughout.
    for(j=0;j<2;j=j+1) for(k=1;k<=10;k=k+1) begin
      tick(0,0,1,8'h96);
      while(age<deadline(k)-1) tick(0,0,1,8'h69);
      tick(j==1,1,1,8'hff); tick(j==1,1,1,0); tick(0,1,1,8'haa);
      tick(0,0,0,0); tick(0,0,1,8'h3c); drain();
    end
    // Independent xorshift stream has resets, cancels, valid holds and idle.
    for(i=0;i<4000;i=i+1) begin
      random_state=random_state^(random_state<<13);
      random_state=random_state^(random_state>>17);
      random_state=random_state^(random_state<<5);
      tick((i%769)==768,random_state[7:0]==8'hc7,random_state[1:0]!=0,random_state[23:16]);
    end
    drain();
    // Final real transfers saturate each small-width counter independently.
    tick(1,1,1,0); tick(0,0,0,0);
    for(i=0;i<20;i=i+1) begin tick(0,0,1,i[7:0]); drain(); end
    for(i=0;i<20;i=i+1) begin tick(0,0,1,i[7:0]); tick(0,1,1,8'hff); tick(0,1,0,0); tick(0,0,0,0); end
    $display("A_STATS edges=%0d checks=%0d admissions=%0d completions=%0d aborts=%0d resets=%0d",edges,checks,admissions_total,completions_total,aborts_total,reset_edges);
    $display("A_PASS"); $finish;
  end
  initial begin #100000000; $fatal(1,"A op24 watchdog"); end
endmodule
