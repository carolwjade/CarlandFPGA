from review_driver import OUT, run, write_json
import hashlib
import json
import pathlib
import re
import shutil
import ctypes
import os
import subprocess

TOOLS=pathlib.Path('C:/modeltech64_2020.4/win64')
RTL=OUT/'remote-snapshot/competition/deepeye/fpga/transport/deepeye_uart_tx.sv'
TB=OUT/'a_tb_op24_tx.sv'
assert hashlib.sha256(RTL.read_bytes()).hexdigest()=='5076286e4dd1598aeb2c78281bec83020c85d0711dcee9b985088ac707353c47'
run('a-v2-modelsim-vlog-version',[TOOLS/'vlog.exe','-version'])
run('a-v2-modelsim-vsim-version',[TOOLS/'vsim.exe','-version'])
used=ctypes.windll.kernel32.GetLogicalDrives()
drive=next(chr(n+65)+':' for n in range(25,3,-1) if not (used&(1<<n)))
run('a-v2-subst-create',['subst',drive,str(OUT)])
write_json('ascii-drive-mapping.json',{'drive':drive,'target':str(OUT),'reason':'ModelSim2020.4 SQLite cannot open non-ASCII working-directory paths','owned_target_only':True})
cases=[('fractional-101-7-3',101,7,3,None),('near-limit-17-8-2',17,8,2,None),('integer-max',2147483647,1073741823,32,None),
       ('clock-priority',1,0,1,'CLOCK_HZ'),('baud-priority',17,9,1,'BAUD'),('stat-guard',17,8,1,'STAT_W')]
results=[]
for name,clock,baud,stat,guard in cases:
    case=pathlib.Path(drive+'/')/'new-simulations-v2'/name
    case.mkdir(parents=True,exist_ok=False)
    shutil.copyfile(RTL,case/'dut.sv'); shutil.copyfile(TB,case/'a_tb.sv')
    (case/'temp').mkdir()
    os.environ['TEMP']=str(case/'temp'); os.environ['TMP']=str(case/'temp'); os.environ['TMPDIR']=str(case/'temp')
    run('a-v2-'+name+'-vlib',[TOOLS/'vlib.exe','work'],cwd=case)
    compiled=run('a-v2-'+name+'-vlog',[TOOLS/'vlog.exe','-sv','-work','work','dut.sv','a_tb.sv'],cwd=case)
    assert b'Errors: 0, Warnings: 0' in compiled.stdout
    assert not re.search(rb'\*\*\s*(Error|Fatal|Warning)',compiled.stdout+compiled.stderr)
    sim=run('a-v2-'+name+'-vsim',[TOOLS/'vsim.exe','-c','-onfinish','stop','work.a_tb_op24_tx',f'-gCLOCK_HZ={clock}',f'-gBAUD={baud}',f'-gSTAT_W={stat}','-do','run -all; quit -code 0'],cwd=case,allowed=(0,1,2,12))
    raw=sim.stdout+b'\n'+sim.stderr
    text=raw.decode('utf-8')
    rows=[line[2:] if line.startswith('# ') else line for line in text.splitlines()]
    if guard:
        fatals=[s for s in rows if '** Fatal:' in s]
        okay=fatals==['** Fatal: deepeye_uart_tx: '+guard+' out of range'] and 'A_PASS' not in rows and not any(re.search(r'\*\*\s*(Error|Warning)',s) for s in rows)
        stats=None
    else:
        m=[re.fullmatch(r'A_STATS edges=(\d+) checks=(\d+) admissions=(\d+) completions=(\d+) aborts=(\d+) resets=(\d+)',s) for s in rows if s.startswith('A_STATS')]
        stats=dict(zip(['edges','checks','admissions','completions','aborts','resets'],map(int,m[0].groups()))) if len(m)==1 and m[0] else None
        okay=sim.returncode==0 and rows.count('A_PASS')==1 and stats is not None and not re.search(r'A_FAIL|\*\*\s*(Error|Fatal|Warning)|watchdog',text)
        okay=okay and stats['checks']==9*stats['edges']-3 and stats['completions']>=296 and stats['aborts']>=30
    entry={'name':name,'parameters':{'CLOCK_HZ':clock,'BAUD':baud,'STAT_W':stat},'expected_guard':guard,'accepted':bool(okay),'actual_simulator_exit_code':sim.returncode,'stats':stats}
    write_json('new-simulations-v2/'+name+'/result.json',entry)
    results.append(entry)
write_json('new-simulations-v2/result.json',{'cases':results,'all_accepted':all(r['accepted'] for r in results),'scope':'new A public-port RTL simulations only','rtl_sha256':hashlib.sha256(RTL.read_bytes()).hexdigest(),'tb_sha256':hashlib.sha256(TB.read_bytes()).hexdigest()})
run('a-v2-subst-remove',['subst',drive,'/d'])
write_json('ascii-drive-mapping-cleanup.json',{'drive':drive,'removed':not bool(ctypes.windll.kernel32.GetLogicalDrives()&(1<<(ord(drive[0])-65)))})
print(json.dumps(results,indent=2))
raise SystemExit(0 if all(r['accepted'] for r in results) else 2)
