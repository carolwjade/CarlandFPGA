# B op24 独立审查

审查已完成，供 A/root 决定正式接收。证据支持的范围是指定提交上的内部单字节 8N1 TX RTL 仿真。未发现本次所测公开端口行为与其文档契约不一致；这不是产品卡、系统、板测或当前 PR30 最新 head 的通过结论。

## 固定身份与权限

- work_id：`A-B-OP24-INDEPENDENT-20261024-v1`；agent：`/root/b_op24_review`。
- task：`DEEPEYE-IMPLEMENTATION-20261014/v1`；native job：`child-8c2ac76e5c954556847b546bede164f6`，执行前已绑定 agent 并返回 `execution_allowed=true`。
- `tested_commit`：`b90fcbc58cdd7f3bf53fb6931dbdd47cd55afc8a`；source：`466457736bbe51d8e489880b4efb3bf87a3555d1`，已验证 source 是 head 的祖先；source 到 head 只新增该 handoff 的 README/input/manifest。
- operation：`B-DEEPEYE-UART-TX-20261023-24`。
- request SHA-256：`a111985fd1d0002c4a05da1b1c1e101d3e576b4898e565f5869cf0397f75d0e8`。
- manifest：`handoffs/b/B-DEEPEYE-UART-TX-20261023-24/manifest.json`，SHA-256 `a63e0a95373a814393e6b074f07ac400c8cf7342af49ca88c529cb4649af93f3`。
- 人类合同 `DEEPEYE-HUMAN-LOCK-20261014/revision1`，根目录和已检出 head 中的 requirements 均实算为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，H01–H15 全部保留；当前 activation 为 Gen3 / `01a16988-bdcb-70e1-ae10-1304b5cf7875`，本机 A / fpga-main。
- PR30 本轮只读查询 head 已前进至 `dfdb2b8120793ba816fd09cd8fc255953bbf73ac`，正文为后续 op25/op26。该新 head 不在本次测试范围。查询原文保存在 `logs/remote-pr30.stdout.txt`。

## 字节与保存证据

`identity-result.json` 和 `archive-member-identities.json` 保存逐文件结果。12 项交付文件的大小、SHA-256、检出字节及准确 head 的 Git blob 全部一致；SOURCE_BINDING 的 6 项源文件与 source commit 一致。manifest/request/input 关系及 head 合同已独立核验。

`raw-evidence.tar.gz` SHA-256 为 `482842d597d20df72c68cd52c7bdf92105dd89985a0edd3c8575f5c9bf8470d0`。归档 1,039 个成员、3,224,757 个原始字节逐项匹配 RAW_INDEX；无重复路径、越界路径或非普通文件，提取至本目录 `raw-archive/`。生产者明确省略的编译库/波形 scratch 未当作已交付成员。

仅审查保存字节，未重跑作者/旧系统组：45 个作者最终进程的返回码、超时/启动状态及原始双管道哈希一致；14 suites 保存检查一致；19 个 B main 运行的 95 个命令收据、源快照和双管道均已重哈希。7 个正例原日志合计 17,172,643 edges / 103,035,851 checks；9 个 guard 均为自身精确 fatal；3 个已编译 mutant 均有真实数值反例及唯一自身 fatal / Errors:1, Warnings:0。其原始 `accepted=false` 结果保留，后来 reclassification 没有伪装成新仿真。

旧作者 runner 实际运行哈希 `0c6a85df11b2f2301390d98880ac233c6a24782b4e2f16c353e8ead113f4dbea`，归档 `main/runner-repair/author_original.py` 字节已匹配。最终 runner `d675d43f58d8b06cfc82f11889eafb217ffe304e0bde874bc3b07a2f64098cb0` 的差异仅为 Git HEAD 门转为溯源信息；main runner 的差异仅为 mutant fatal tally 分类修正。两份 diff 和 `runner-provenance.json` 已保存。生产者 219 项 saved-audit 与 31 项 synthetic probe 的文件身份已核验，本次不重复计算该特有断言数，也不将它们算成 RTL 执行。

## 新增独立 A 侧仿真

工具：ModelSim SE-64 2020.4（vlog/vsim 2020.10 Oct 13 2020），Python 3.12.14。工具路径、可执行文件哈希和 version stdout 见 `local-modelsim-tool-identities.json`、`logs/a-v2-modelsim-*.stdout.txt`。新 `a_tb_op24_tx.sv` 使用逐边界绝对 deadline 与已锁存输入字节构造 oracle，只读公开端口，不读取内部相位、不 force。它在阅读 B 源码后独立编写，因此不声称盲审时间独立性。

| 配置 CLOCK_HZ / BAUD / STAT_W | 边沿 | 检查 | 结果 |
| --- | ---: | ---: | --- |
| 101 / 7 / 3 | 49,434 | 444,903 | passed |
| 17 / 8 / 2 | 11,551 | 103,956 | passed |
| 2147483647 / 1073741823 / 32 | 11,250 | 101,247 | passed |
| 1 / 0 / 1 | guard | CLOCK_HZ 优先 | passed |
| 17 / 9 / 1 | guard | BAUD 优先 | passed |
| 17 / 8 / 1 | guard | STAT_W | passed |

三个正常配置共 **72,235 边沿 / 650,106 检查**。覆盖 256 字节、非整除间隔、最短附近与整数上限、忙时变化数据/valid 保持、无同边沿完成接纳、每个边界 cancel、reset-over-cancel、取消保持/恢复、随机激励，以及小 STAT_W 的真实完成/取消饱和。三项 guard 只以自身精确 fatal 为预期；仿真器在脚本 `quit -code 0` 下实际返回 0，不能将 guard 的这个退出码解释为普通健康运行。

实际执行入口：`.local/venv/Scripts/python.exe -B -X utf8 .planning/deepeye-resume-20261018/b-op24-independent-20261024/run_new_simulations.py`，终态 exit 0。每例实际命令是 `vlib work`、`vlog -sv -work work dut.sv a_tb.sv`、`vsim -c -onfinish stop work.a_tb_op24_tx -gCLOCK_HZ=... -gBAUD=... -gSTAT_W=... -do "run -all; quit -code 0"`。正常例 compile/sim 均 exit 0，compile 与正常 sim 为 Errors:0 / Warnings:0。逐步 command JSON、原始 stdout/stderr 在 `logs/a-v2-*`；新测试源快照/工作目录在 `new-simulations-v2/`。现有输出目录禁止重放覆盖。

## 源码边界与集成缺项

RTL 的 admission/波特边界、LSB-first、停止位、phase 每字节重启、reset > cancel > busy > 新输入优先级、取消终止与三个饱和计数器符合本次源审和新增仿真。参数 guard 只在仿真启用；硬件构建仍须由其自身流程验证合法配置。

准确 head 的 FPGA 源码检索中，`deepeye_uart_tx` 仅出现在模块自身和说明文件，没有产品 RTL 实例化。该 transport 目录只有本 TX 与文档。因此本次不能关闭以下缺项：

- RX/异步输入同步与实际串口接收、波特率/时钟误差与物理 CDC。
- RS485 收发方向 setup/hold/guard、物理收发器/线缆/引脚/电气结果。
- 完整帧缓冲、CRC/序号/ACK/重传/丢弃后恢复、调度与共享带宽。取消会立即在下一个时钟将 TX 拉高，没有接收端重同步保证；调用方不能把一次字节 abort 当成完整帧撤销。
- 与既有队列、观测来源/BOOT/时效、真实板输出、PC AI/模拟器控制链及停止权限的集成。
- 综合、实现、时序、CDC/RDC、bit/HWH 同构建、上板、系统和完整产品卡。

op22 结论没有被继承；op25/op26 的能力未计入 op24。B04 / R03 / G03 / all29 / full_product / board / system 均保持 `not_run`。A/root 独占板卡；本子任务未操作板卡、服务、显示器、凭据/提供方或外部消息，没有评论 PR、合并或发布。

## 保留的失败与环境限制

1. 准备脚本第一次误假设 node_id 为 node-a，实际为 A；只修正该断言，记录于 `initial-attempt-1-failure.txt`。
2. Git 首次 checkout exit 0 但 stderr 报历史长路径文件无法创建；保存原 stderr/status。仅在隔离 checkout 以单命令 `core.longpaths=true` 重新物化同一 HEAD，之后 status 为空；未改全局设置或活动工作树。
3. 新仿真第一次 vlog exit 232：ModelSim 的 SQLite 无法打开含中文的工作路径，尚无有效 RTL 仿真结论；原 stdout/stderr 与源快照保留在 `new-simulations/`。第二次使用临时 Z: 映射指向本证据目录后成功，映射已移除且读回确认，见 cleanup JSON。
4. 冗余 GitHub contents 并行下载的 10 项成功，另 2 项长时间等待。准确 Git fetch 完成并全部核验后，只终止了这两项自身的只读 gh 子进程；exit 4294967295 与原始管道保留。最终身份依据完整 Git 对象/检出字节，不依赖该不完整重复下载。
5. 最终审计脚本第一次误把 source→head 的 handoff 增量限定为 input/manifest 两项，实际还有 README；原始 diff 显示共三项，已仅修正审计预期和报告，未改目标提交或源码。

正式接收、同 PR 反馈与 B 读回由 root 完成。本报告仅交付独立审查证据，不代替这些步骤。
