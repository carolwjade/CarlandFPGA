from pathlib import Path
import hashlib,json
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';E=W/'competition/deepeye/evidence/transport/wire-parser-20261024-29'
def walk(v):
 if isinstance(v,dict):
  yield v
  for x in v.values():yield from walk(x)
 elif isinstance(v,list):
  for x in v:yield from walk(x)
issues=[]
for v in walk(json.loads((E/'author/RUNNER_REPAIR2_RESULT.json').read_bytes())):
 if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
  p=W/v['path'];actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
  if not p.resolve().is_relative_to(W.resolve()) or actual!=v['sha256']:issues.append({'path':str(p),'exists':p.is_file(),'inside_repo':p.resolve().is_relative_to(R.resolve()),'expected_sha256':v['sha256'],'actual_sha256':actual})
(E/'main/final-audit-01/PATH_DIAGNOSIS.json').write_text(json.dumps(issues,indent=2)+'\n');print(json.dumps(issues))
