import pathlib,json,hashlib,re,difflib
from acquire import OUT,LOCAL,sha,save_json
SNAP=LOCAL/'snapshot'
review=[]
for n,name,auditname in [(28,'serializer','final-audit-01'),(29,'parser','final-audit-02')]:
    raw=LOCAL/f'raw-{n}'
    idx=json.loads((OUT/f'raw-members-{n}.json').read_bytes())
    byhash={}
    for row in idx:
        # Check Windows as well as POSIX path semantics before trusting extracted names.
        parts=pathlib.PurePosixPath(row['path'].replace('\\','/')).parts
        assert '..' not in parts and not row['path'].startswith(('/', '\\')) and ':' not in row['path']
        byhash.setdefault(row['sha256'],[]).append(row['path'])
    auditp=raw/f'main/{auditname}/RESULT.json';audit=json.loads(auditp.read_bytes())
    sources=[]
    for p,h in audit['final_sources'].items():
        p=p.replace('\\','/');assert sha((SNAP/p).read_bytes())==h
        sources.append({'path':p,'sha256':h})
    refchecks=[]
    for p,h in audit.get('author_referenced_file_hashes',{}).items():
        norm=p.replace('\\','/');prefix=f'competition/deepeye/evidence/transport/wire-{name}-20261024-{n}/'
        if norm.startswith(prefix):
            local=raw/norm[len(prefix):];assert sha(local.read_bytes())==h
            refchecks.append({'reference':p,'verified_archive_path':str(local.relative_to(raw)),'sha256':h,'mode':'path mapping'})
        else:
            assert h in byhash
            refchecks.append({'reference':p,'verified_archive_paths':byhash[h],'sha256':h,'mode':'archive content identity only; original B private path not accessed'})
    runs=[]
    for row in audit['main_runs']:
        rel=row['path'].replace('\\','/');p=raw/rel;data=p.read_bytes();assert sha(data)==row['sha256']
        result=json.loads(data)
        command_checks=0
        for cmd in result.get('commands',[]):
            for pipe in ['stdout','stderr']:
                fp=p.parent/(cmd['name']+'.'+pipe+'.bin')
                assert sha(fp.read_bytes())==cmd[pipe+'_sha256']
                command_checks+=1
        for file,h in result.get('inputs',{}).items():
            expected_hash=h['sha256'] if isinstance(h,dict) else h
            assert sha((p.parent/file).read_bytes())==expected_hash
        runs.append({'path':rel,'sha256':sha(data),'mode':result['mode'],'accepted_classifier_result':result['accepted'],'numeric_counterexamples':result['numeric_counterexamples'],'command_pipe_hashes_verified':command_checks,'dut_input_binding':result.get('inputs',{}).get('dut.sv')})
    # Original real mismatches and the repaired source diff remain separate evidence.
    originalp=raw/'main/vector32-01/RESULT.json';original=json.loads(originalp.read_bytes())
    assert not original['accepted'] and original['numeric_counterexamples']
    log=(raw/'main/vector32-01/vsim.stdout.bin').read_bytes()
    assert all(s.encode() in log for s in original['numeric_counterexamples'])
    old=(raw/'main/vector32-01/dut.sv').read_text(encoding='utf8')
    new=(SNAP/f'competition/deepeye/fpga/transport/deepeye_wire_{name}.sv').read_text(encoding='utf8')
    diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original-red',tofile='exact-head-final'))
    (OUT/f'status-repair-{n}.diff.txt').write_text(diff,encoding='utf8')
    probe_key='runner_probes' if n==28 else 'runner_main_probes'
    probes=audit[probe_key];assert all(p['accepted']==p['expected'] for p in probes)
    review.append({'primitive':name,'producer_final_audit_sha256':sha(auditp.read_bytes()),'final_sources_reverified':sources,'producer_reported_main_cycles':audit['main_cycles'],'producer_reported_main_port_checks':audit['main_port_checks'],'producer_reported_main_guards':audit['main_guards'],'producer_reported_compiled_mutants':audit['compiled_behavioral_mutants'],'producer_final_author_cases':audit['final_author_cases'],'producer_final_author_checks':audit['final_author_checks'],'producer_main_saved_runner_probes':len(probes),'saved_probes_match_expected':True,'referenced_file_checks':refchecks,'saved_main_runs':runs,'original_red_result_sha256':sha(originalp.read_bytes()),'original_red_numeric_counterexamples':original['numeric_counterexamples'],'original_red_stdout_sha256':sha(log),'repair_diff_path':f'status-repair-{n}.diff.txt','vendor_runs_by_this_history_review':0})
raw=LOCAL/'raw-29'
post=json.loads((raw/'author/runner-repair2/post_fix_qualification.json').read_bytes())
post_summary={}
for key in ['historical_feedback_negatives','current21_targeted_negatives','guard_targeted_negatives','positive_controls']:
    arr=post[key];expected=key=='positive_controls'
    assert all(x['accepted']==expected for x in arr)
    for row in arr:
        prefix='competition/deepeye/evidence/transport/wire-parser-20261024-29/'
        assert row['raw_path'].startswith(prefix)
        assert sha((raw/row['raw_path'][len(prefix):]).read_bytes())==row['raw_sha256']
    post_summary[key]={'count':len(arr),'all_expected':True}
failures=[]
for rel in ['main/final-audit-01/FAILURE.json','main/final-guards-mutants-01/FAILURE.json']:
    p=raw/rel;failures.append({'path':rel,'sha256':sha(p.read_bytes()),'content':json.loads(p.read_bytes())})
runnerrepair=json.loads((raw/'author/RUNNER_REPAIR2_RESULT.json').read_bytes())
save_json(OUT/'history-review.json',{'operations':review,'parser_author_postfix_qualification_saved_data':post_summary,'retained_main_fixture_and_path_failures':failures,'runner_repair2_source_pins':runnerrepair['source_pins'],'runner_repair2_prefixed_runner_prior_acceptance':{k:v for k,v in runnerrepair['pre_fix_reproduction'].items() if not isinstance(v,dict)},'producer_process_failure_qualification_claims':{k:v for k,v in runnerrepair['claims'].items() if 'nonzero' in k or 'timeout' in k},'scope':'saved evidence inspection/hash validation only; no producer code or tests executed; historical order/acceptance belongs to producer'})
print(json.dumps({'operations':[{'primitive':r['primitive'],'original_red':r['original_red_numeric_counterexamples'],'saved_runs_rehashed':len(r['saved_main_runs']),'runner_probes':r['producer_main_saved_runner_probes'],'referenced_file_checks':len(r['referenced_file_checks'])} for r in review],'parser_postfix_saved_qualification':post_summary,'retained_main_failures':failures},ensure_ascii=False,indent=2))
