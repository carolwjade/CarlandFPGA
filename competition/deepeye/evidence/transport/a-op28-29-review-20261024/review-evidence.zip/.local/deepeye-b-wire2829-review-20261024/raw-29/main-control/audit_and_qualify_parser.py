from pathlib import Path
import hashlib,importlib.util,json,re
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/wire-parser-20261024-29';D=E/'main/final-audit-01';D.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def walk(v):
 if isinstance(v,dict):
  yield v
  for x in v.values():yield from walk(x)
 elif isinstance(v,list):
  for x in v:yield from walk(x)
report=json.loads((E/'author/RUNNER_REPAIR2_RESULT.json').read_bytes());A=W/report['actual_modelsim_cli']['fresh_attempt']['attempt_path'];d=json.loads((A/'attempt.json').read_bytes());assert d['status']=='PASS'
files={};seen=[]
for c in d['commands']:
 assert c['actual_exit']==0 and not c['timed_out'];seen.append(c['name'])
 for tag in ('stdout','stderr'):
  p=A/c[tag+'_path'];assert p.resolve().is_relative_to(A.resolve()) and sha(p)==c[tag+'_sha256'];files[str(p.relative_to(E))]=sha(p)
references={}
for v in walk(report):
 if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
  p=W/v['path'];assert p.resolve().is_relative_to(W.resolve()) and sha(p)==v['sha256'];references[v['path']]=sha(p)
paths=[P/'fpga/transport/deepeye_wire_parser.sv',P/'fpga/transport/wire_parser_candidate.md',P/'fpga/transport/deepeye_crc16_byte.sv',P/'tests/rtl/transport/tb_wire_parser.sv',P/'tools/transport/run_wire_parser.py']
expected={p.name:sha(p) for p in paths};copies=[]
for v in d['records']['sources'].values():
 p=A/v['snapshot_path'];assert sha(p)==v['sha256']==expected[Path(v['source_path']).name];copies.append(str(p.relative_to(E)))
assert expected['deepeye_wire_parser.sv']=='7806c5d08785b96eae3708d9fd6d6002ef82faa4416a1f7244da73bece552649'
runner=P/'tools/transport/run_wire_parser.py';spec=importlib.util.spec_from_file_location('main_qualified_parser_runner',runner);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
normal_cmd=next(c for c in d['commands'] if c['name']=='vsim_main_directed');positive=(A/normal_cmd['stdout_path']).read_text(encoding='utf-8');lines=positive.splitlines();protocol=[x for x in lines if 'WIRE_PARSER_' in x];assert len(protocol)==3*len(m.EXPECTED_CASES)+2
tests={'positive':positive}
for i,row in enumerate(protocol):
 tests['remove_'+str(i)]=positive.replace(row+'\n','',1)
 tests['duplicate_'+str(i)]=positive.replace(row,row+'\n'+row,1)
 if i:tests['move_first_'+str(i)]=row+'\n'+positive.replace(row+'\n','',1)
 if '|CHECKS|' in row:raise AssertionError('unexpected marker spelling')
 if 'CASE_CHECKS|' in row:tests['wrong_count_'+str(i)]=positive.replace(row,row.rsplit('|',1)[0]+'|'+str(int(row.rsplit('|',1)[1])+1),1)
for name,t in {'earlier_error':'# ** Error: injected\n'+positive,'earlier_warning':'# ** Warning: injected\n'+positive,'earlier_tally':'# Errors: 8, Warnings: 0\n'+positive,'unknown_suffix':positive.replace(protocol[-1],protocol[-1]+' suffix'),'substring_pass':positive.replace(protocol[-1],'# NOT_WIRE_PARSER_ALL_PASS'),'contradictory_case':positive+'\n# WIRE_PARSER_CASE_END|1|reset_and_receiving|FAIL trailing\n','missing_tally':positive.replace('# Errors: 0, Warnings: 0',''),'after_tally':positive+'\n# unexpected work after finish\n'}.items():tests[name]=t
probes=[]
for name,text in tests.items():
 f=D/(name+'.log');f.write_bytes(text.encode());error=None
 try:parsed=m.parse_main_suite_log(text,m.EXPECTED_CASES);accepted=True
 except Exception as e:accepted=False;error=type(e).__name__+': '+str(e)
 probes.append({'name':name,'accepted':accepted,'expected':name=='positive','sha256':sha(f),'error':error});assert accepted==(name=='positive'),name
for c in [x for x in d['commands'] if x['name'].startswith('guard_')]:
 text=(A/c['stdout_path']).read_text(encoding='utf-8');m.parse_guard_log(text)
 for name,extra in [('extra_fatal','# ** Fatal: unrelated\n'),('extra_error','# ** Error: injected\n'),('extra_warning','# ** Warning: injected\n'),('extra_tally','# Errors: 1, Warnings: 0\n'),('success_marker','# WIRE_PARSER_ALL_PASS\n'),('suffix_fatal','# ** Fatal: deepeye_wire_parser: STAT_W out of range suffix\n')]:
  v=extra+text;f=D/(c['name']+'_'+name+'.log');f.write_bytes(v.encode())
  try:m.parse_guard_log(v);accepted=True
  except Exception:accepted=False
  probes.append({'name':c['name']+'_'+name,'accepted':accepted,'expected':False,'sha256':sha(f)});assert not accepted
mainruns=[];checks=0
for p in [E/f'main/final-vector{s}-01/RESULT.json' for s in (32,2)]+[E/f'main/final-guards-mutants-02/{n}/RESULT.json' for n in ('guard0','guard1','guard33','crc_bypass','prefix_reset','overwrite_pending')]:
 v=json.loads(p.read_bytes());assert v['accepted']
 for c in v['commands']:
  assert c['returncode']==0 and not c['timeout']
  for tag in ('stdout','stderr'):assert sha(p.parent/(c['name']+'.'+tag+'.bin'))==c[tag+'_sha256'];checks+=1
 for name,info in v['inputs'].items():assert sha(p.parent/name)==info['sha256'];checks+=1
 mainruns.append({'path':str(p.relative_to(E)),'sha256':sha(p),'mode':v['mode'],'commands':len(v['commands'])})
result={'accepted_bounded_parser':True,'final_author_cases':len(m.EXPECTED_CASES),'final_author_checks':sum(n for _,n in m.EXPECTED_CASES),'author_unique_processes':len(seen),'author_raw_pipes':files,'author_referenced_file_hashes':references,'source_copies_verified':copies,'final_sources':{str(p.relative_to(W)):sha(p) for p in paths},'main_cycles':63527+63491,'main_port_checks':2286972+2285676,'main_guards':3,'compiled_behavioral_mutants':3,'main_runs':mainruns,'main_raw_hash_checks':checks,'runner_main_probes':probes,'author_self_check_is_not_independent':True,'formal':'All29/B04/R03/fullproduct/synth/impl/timing/CDC_RDC/board/system not_run'}
(D/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':True,'author_cases':result['final_author_cases'],'author_checks':result['final_author_checks'],'author_commands':len(seen),'author_references':len(references),'main_independent_log_probes':len(probes),'main_raw_hash_checks':checks,'cycles':result['main_cycles'],'port_checks':result['main_port_checks']}))
