from pathlib import Path
import importlib.util,json,hashlib,sys
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';E=W/'competition/deepeye/evidence/transport/wire-parser-20261024-29';D=E/'main/runner-negative-01';D.mkdir(exist_ok=False)
src=E/'main/status-repair-01-original/run_wire_parser.py';s=importlib.util.spec_from_file_location('parser_original_qualification',src);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
meta=json.loads((E/'main/status-repair-01-original/RESULT.json').read_bytes());attempt=W/meta['final_attempt']['path']
choices=[p for p in attempt.rglob('*') if p.is_file() and 'stdout' in p.name and b'WIRE_PARSER_ALL_PASS' in p.read_bytes()];assert len(choices)==1,choices
raw=choices[0].read_bytes();text=raw.decode('utf-8');(D/'positive-original.bin').write_bytes(raw)
rows=text.splitlines();summary=next(x for x in rows if x.startswith('# WIRE_PARSER_SUMMARY|'));passed=next(x for x in rows if x=='# WIRE_PARSER_ALL_PASS')
mutations={'positive':text,'early_summary':'\n'.join([summary]+[x for x in rows if x!=summary])+'\n','early_pass':'\n'.join([passed]+[x for x in rows if x!=passed])+'\n','conflicting_malformed_summary':text+'\n# WIRE_PARSER_SUMMARY|18|1|0|PASS trailing\n','nonzero_earlier_tally':'# Errors: 9, Warnings: 0\n'+text,'earlier_error_diagnostic':'# ** Error: injected contradictory error\n'+text,'extra_case_malformed':text+'\n# WIRE_PARSER_CASE_END|1|reset_and_receiving|FAIL trailing\n'}
results=[]
for name,t in mutations.items():
 f=D/(name+'.log');f.write_bytes(t.encode());accepted=False;error=None
 try:m.Runner._parse_main_suite(None,t);accepted=True
 except Exception as e:error=type(e).__name__+': '+str(e)
 results.append({'name':name,'accepted':accepted,'synthetic':name!='positive','sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'error':error})
assert results[0]['accepted']
(D/'RESULT.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'positive_source':str(choices[0]),'probes':results,'scope':'parser-only raw-log qualification; no simulator execution'},indent=2)+'\n');print(json.dumps(results))
