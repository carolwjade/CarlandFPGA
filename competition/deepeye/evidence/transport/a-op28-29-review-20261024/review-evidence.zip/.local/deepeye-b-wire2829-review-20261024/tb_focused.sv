`timescale 1ns/1ps
module tb_serializer;
  reg clk=0; always #5 clk=~clk;
  reg rst=0,cancel=0,cfg_valid=0,p_valid=0,p_last=0,out_ready=0;
  reg [7:0] cfg_type=0,cfg_epoch=0,p_data=0;
  reg [15:0] cfg_seq=0;
  reg [31:0] cfg_tick=0;
  reg [5:0] cfg_len=0;
  wire cfg_ready,p_ready,out_valid,out_last,busy,receiving,faulted,fault_event;
  wire [7:0] out_data; wire [5:0] out_count; wire [1:0] fault_code;
  wire [31:0] stat_admitted,stat_sent,stat_aborted,stat_faults;
  deepeye_wire_serializer dut(.*);
  reg [7:0] f0[0:13],f1[0:14],f32[0:45];
  integer checks=0,cycles=0;
  always @(posedge clk) cycles=cycles+1;
  task ck(input bit ok,input string label_);
    checks=checks+1; if(!ok) $fatal(1,"INDEP_FAIL serializer %s cycle=%0d",label_,cycles);
  endtask
  task step; @(posedge clk); #1; endtask
  task reset_all;
    @(negedge clk); rst=1; cancel=1; cfg_valid=0;p_valid=0;out_ready=0;
    #1;ck(!cfg_ready&&!p_ready&&!out_valid,"reset gates");step;
    ck(!busy&&stat_admitted==0&&stat_sent==0&&stat_aborted==0&&stat_faults==0,"reset priority counters");
    @(negedge clk);rst=0;cancel=0;
  endtask
  task config_frame(input integer n);
    @(negedge clk);cfg_type=8'h96;cfg_epoch=8'h27;cfg_seq=16'h8b4d;cfg_tick=32'hc16a3902;cfg_len=n;cfg_valid=1;
    #1;ck(cfg_ready,"cfg available");step;
    ck(busy&&!cfg_ready,"single reservation");
    @(negedge clk);cfg_valid=0;cfg_type=0;cfg_epoch=0;cfg_seq=0;cfg_tick=0;cfg_len=63;
  endtask
  function [7:0] expected(input integer n,input integer i);
    if(n==0) expected=f0[i];else if(n==1) expected=f1[i];else expected=f32[i];
  endfunction
  task frame(input integer n);
    integer i,j;reg[7:0] saved;reg last_;
    config_frame(n);
    for(i=0;i<n;i=i+1) begin
      @(negedge clk);p_valid=1;p_data=(8'ha5+37*i)&255;p_last=(i==n-1);
      #1;ck(p_ready&&receiving&&!out_valid,"payload before seal");step;
      @(negedge clk);p_valid=0;p_data=0;p_last=0;
      step;
    end
    for(i=0;i<n+14;i=i+1) begin
      @(negedge clk);out_ready=0;cfg_valid=1;
      #1;ck(out_valid&&!cfg_ready&&out_count==n+14,"output reservation/count");
      ck(out_data===expected(n,i),"wire endian and CRC");ck(out_last===(i==n+13),"last marker");
      saved=out_data;last_=out_last;
      for(j=0;j<2+(i%3);j=j+1) begin
        step;ck(out_valid&&out_data===saved&&out_last===last_&&out_count==n+14,"backpressure stable");
      end
      @(negedge clk);out_ready=1;#1;ck(!cfg_ready,"no retirement-edge cfg credit");step;
    end
    ck(!busy&&!out_valid&&cfg_ready,"frame retired");
    @(negedge clk);cfg_valid=0;out_ready=0;
    $display("INDEP_CASE serializer frame%0d PASS",n);
  endtask
  task fault_abort(input bit use_reset,input bit illegal);
    integer old_admit,old_abort,old_fault;
    config_frame(illegal?33:1);
    if(!illegal) begin
      @(negedge clk);p_valid=1;p_last=0;p_data=8'h39;step;
      ck(faulted&&fault_code==2&&fault_event,"payload last fault");
    end else ck(faulted&&fault_code==1&&fault_event&&out_count==0,"illegal length fault");
    old_admit=stat_admitted;old_abort=stat_aborted;old_fault=stat_faults;
    if(!illegal) @(negedge clk);
    rst=use_reset;cancel=!use_reset;
    #1;ck(fault_event&&faulted,"registered fault not withdrawn asynchronously");
    ck(!cfg_ready&&!p_ready&&!out_valid,"abort immediate gate");
    ck(stat_admitted==old_admit&&stat_aborted==old_abort&&stat_faults==old_fault,"no preedge counter update");
    step;ck(!busy&&!fault_event&&!faulted&&fault_code==0,"synchronous fault clear");
    if(use_reset) ck(stat_admitted==0&&stat_aborted==0&&stat_faults==0,"reset counters");
    else begin
      ck(stat_aborted==old_abort+1,"one cancel abort");step;step;ck(stat_aborted==old_abort+1,"held cancel not recount");
    end
    @(negedge clk);rst=0;cancel=0;p_valid=0;p_last=0;
    $display("INDEP_CASE serializer fault_abort reset=%0d illegal=%0d PASS",use_reset,illegal);
  endtask
  initial begin
    $readmemh("frame0.hex",f0);$readmemh("frame1.hex",f1);$readmemh("frame32.hex",f32);
    reset_all;frame(0);frame(1);frame(32);
    ck(stat_sent==3&&stat_admitted==3&&stat_aborted==0&&stat_faults==0,"three clean frames counters");
    fault_abort(0,0);fault_abort(1,0);fault_abort(0,1);
    reset_all;
    repeat(256) begin step;ck(cfg_ready&&!busy&&!out_valid&&!fault_event,"idle stable");end
    $display("INDEP_PASS serializer checks=%0d cycles=%0d",checks,cycles);$finish;
  end
  initial begin #50000;$fatal(1,"INDEP_FAIL serializer timeout");end
endmodule

module tb_parser;
  reg clk=0;always #5 clk=~clk;
  reg rst=0,cancel=0,in_valid=0,out_ready=0;reg[7:0] in_data=0;
  wire in_ready,out_valid,receiving,error_event;wire[1:0] error_code;
  wire[7:0] out_type,out_epoch;wire[15:0] out_seq;wire[31:0] out_tick;
  wire[5:0] out_len;wire[255:0] out_payload;
  wire[31:0] stat_bytes,stat_frames,stat_retired,stat_version,stat_length,stat_crc,stat_aborted;
  deepeye_wire_parser dut(.*);
  reg[7:0] f0[0:13],f1[0:14],f32[0:45];
  integer checks=0,cycles=0;
  always @(posedge clk) cycles=cycles+1;
  task ck(input bit ok,input string label_);
    checks=checks+1;if(!ok)$fatal(1,"INDEP_FAIL parser %s cycle=%0d",label_,cycles);
  endtask
  task step;@(posedge clk);#1;endtask
  task reset_all;
    @(negedge clk);rst=1;cancel=1;in_valid=0;out_ready=0;
    #1;ck(!in_ready&&!out_valid,"reset gates");step;
    ck(!receiving&&!out_valid&&!error_event&&stat_bytes==0&&stat_frames==0&&stat_retired==0&&stat_version==0&&stat_length==0&&stat_crc==0&&stat_aborted==0,"reset clears/priority");
    @(negedge clk);rst=0;cancel=0;
  endtask
  task byte_in(input reg[7:0] b);
    @(negedge clk);in_valid=1;in_data=b;#1;ck(in_ready,"input available");step;
    @(negedge clk);in_valid=0;in_data=8'hff;
  endtask
  function[7:0] expected(input integer n,input integer i);
    if(n==0)expected=f0[i];else if(n==1)expected=f1[i];else expected=f32[i];
  endfunction
  task send_frame(input integer n,input bit corrupt);
    integer i;
    for(i=0;i<n+14;i=i+1)begin
      byte_in(expected(n,i)^((corrupt&&i==n+13)?8'h01:8'h00));
      if(i<n+13) begin step;ck(!out_valid&&!error_event,"no premature frame");end
    end
  endtask
  task good_frame(input integer n);
    integer i,j,old_bytes,old_retired;reg[255:0] saved;
    send_frame(n,0);
    ck(out_valid&&!receiving&&!in_ready,"complete slot");
    ck(out_type==8'h96&&out_epoch==8'h27&&out_seq==16'h8b4d&&out_tick==32'hc16a3902&&out_len==n,"metadata endian");
    for(i=0;i<32;i=i+1)ck(out_payload[8*i+:8]===((i<n)?((8'ha5+37*i)&255):8'h00),"payload byte/zero tail");
    saved=out_payload;old_bytes=stat_bytes;old_retired=stat_retired;
    for(j=0;j<5;j=j+1)begin
      @(negedge clk);in_valid=1;in_data=8'ha5;step;
      ck(out_valid&&!in_ready&&out_payload===saved&&stat_bytes==old_bytes,"pending output immutable");
    end
    @(negedge clk);out_ready=1;#1;ck(!in_ready,"no retirement edge input credit");step;
    ck(!out_valid&&in_ready&&stat_bytes==old_bytes&&stat_retired==old_retired+1&&!receiving,"retire no input bypass");
    @(negedge clk);in_valid=0;out_ready=0;
    $display("INDEP_CASE parser frame%0d PASS",n);
  endtask
  task diagnostic_abort(input integer code_,input bit use_reset);
    integer bytes_before,aborts_before;
    if(code_==1) begin byte_in(8'ha5);byte_in(8'h5a);byte_in(8'h04);end
    else if(code_==2)begin byte_in(8'ha5);byte_in(8'h5a);byte_in(8'h03);byte_in(8'h96);byte_in(8'h21);end
    else send_frame(1,1);
    ck(error_event&&error_code==code_&&!out_valid,"reject syntax with diagnostic");
    bytes_before=stat_bytes;aborts_before=stat_aborted;
    // byte_in returned at the falling edge immediately after the detection edge.
    rst=use_reset;cancel=!use_reset;#1;
    ck(error_event&&error_code==code_,"error diagnostic not asynchronously withdrawn");
    ck(!in_ready&&!out_valid&&stat_bytes==bytes_before&&stat_aborted==aborts_before,"error abort immediate gate only");
    step;ck(!error_event&&error_code==0&&!receiving,"error clears synchronously");
    if(use_reset)ck(stat_bytes==0&&stat_version==0&&stat_length==0&&stat_crc==0,"diagnostic reset counters");
    else ck(stat_aborted==aborts_before,"rejected candidate no abort");
    @(negedge clk);rst=0;cancel=0;
    $display("INDEP_CASE parser diagnostic code=%0d reset=%0d PASS",code_,use_reset);
  endtask
  task partial_abort(input bit use_reset);
    integer old_abort,old_bytes;
    byte_in(8'ha5);ck(receiving,"partial prefix registered");
    old_abort=stat_aborted;old_bytes=stat_bytes;rst=use_reset;cancel=!use_reset;#1;
    ck(receiving&&!in_ready&&!out_valid,"partial status retained under abort gate");
    ck(stat_aborted==old_abort&&stat_bytes==old_bytes,"partial counters before edge");
    step;ck(!receiving&&!error_event&&!out_valid,"partial synchronous clear");
    if(use_reset)ck(stat_aborted==0&&stat_bytes==0,"partial reset counters");
    else begin ck(stat_aborted==old_abort+1,"partial cancel counts");step;step;ck(stat_aborted==old_abort+1,"held partial cancel once");end
    @(negedge clk);rst=0;cancel=0;
    $display("INDEP_CASE parser partial reset=%0d PASS",use_reset);
  endtask
  initial begin
    $readmemh("frame0.hex",f0);$readmemh("frame1.hex",f1);$readmemh("frame32.hex",f32);
    reset_all;good_frame(32);good_frame(1);good_frame(0);
    ck(stat_frames==3&&stat_retired==3,"three clean frame counts");
    diagnostic_abort(1,0);diagnostic_abort(2,1);diagnostic_abort(3,0);
    partial_abort(0);partial_abort(1);
    send_frame(0,0);ck(out_valid,"completed cancel setup");
    cancel=1;#1;ck(!out_valid&&!in_ready,"completed cancel gates");step;
    ck(stat_aborted==1&&!out_valid,"completed cancel counts");step;ck(stat_aborted==1,"completed held cancel once");
    @(negedge clk);cancel=0;reset_all;
    repeat(256)begin step;ck(in_ready&&!out_valid&&!receiving&&!error_event,"idle stable");end
    $display("INDEP_PASS parser checks=%0d cycles=%0d",checks,cycles);$finish;
  end
  initial begin #50000;$fatal(1,"INDEP_FAIL parser timeout");end
endmodule
