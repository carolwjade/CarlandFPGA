onerror {quit -code 2 -f}
run -all
quit -code 0 -f
