from pathlib import Path
P=Path(__file__).parent
s=(P/'qualify_main_and_final.py').read_text(encoding='utf-8')
s=s.replace("D=E/'main/final-guards-mutants-01'","D=E/'main/final-guards-mutants-02'")
s=s.replace("old=runner.read_bytes();","old=(E/'main/final-guards-mutants-01/main_verify_wire.original.py').read_bytes();")
s=s.replace("m=mod('main_wire_before_qualification',runner)","m=mod('main_wire_before_qualification',D/'main_verify_wire.original.py')")
s=s.replace("guard+b'\\n# MAIN_BEGIN kind=wire_parser stat=1\\n'","guard+b'\\n# MAIN_BEGIN kind=wire_parser stat=1\\n# MAIN_BEGIN kind=wire_parser stat=1\\n'")
with (P/'qualify_main_and_final_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
