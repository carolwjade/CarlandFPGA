#!/usr/bin/env python3
"""Qualify the wire-parser log protocol classifier without running RTL."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, Dict, List, Sequence, Tuple


BASE = Path(__file__).resolve().parent
WORKTREE = BASE.parents[6]
INPUTS = BASE / "inputs"
MAIN_FEEDBACK = INPUTS / "main-runner-negative-01"
PRIOR_POSITIVES = INPUTS / "prior-positives"
MUTATIONS = BASE / "mutations"
PRODUCTION_RUNNER = WORKTREE / "competition/deepeye/tools/transport/run_wire_parser.py"
PRE_FIX_RUNNER = INPUTS / "pre_fix_runner_5d09.py"
ORIGINAL_RUNNER = INPUTS / "original_runner_a3ba.py"

CURRENT_CASES: List[Tuple[str, int]] = [
    ("reset_and_receiving", 37),
    ("lengths_0_32", 535),
    ("all_256_byte_values", 119),
    ("metadata_endian_and_maxima", 31),
    ("stdlib_crc_vectors", 697),
    ("noise_prefix_resync", 29),
    ("truncation_no_timeout", 26),
    ("corrupt_version", 28),
    ("corrupt_length", 26),
    ("corrupt_crc_no_rescan", 47),
    ("output_stall_input_hold", 85),
    ("retire_edge_no_credit", 28),
    ("zero_tail_reuse", 43),
    ("cancel_each_phase", 440),
    ("reset_each_phase", 616),
    ("small_stat_saturation", 35),
    ("error_pulse_and_recovery", 25),
    ("reset_cancel_priority", 36),
    ("sync_partial_abort_gates", 108),
    ("sync_error_abort_gates", 180),
    ("sync_output_abort_gates", 87),
]
HISTORICAL_CASES: List[Tuple[str, int]] = CURRENT_CASES[:18]

MAIN_NEGATIVE_NAMES = [
    "early_summary",
    "early_pass",
    "conflicting_malformed_summary",
    "nonzero_earlier_tally",
    "earlier_error_diagnostic",
    "extra_case_malformed",
]
CURRENT_TALLY = b"# Errors: 0, Warnings: 0"
GUARD_TALLY = b"# Errors: 1, Warnings: 0"
GUARD_FATAL = b"# ** Fatal: deepeye_wire_parser: STAT_W out of range"


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def sha256_payload(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_path(path: Path) -> str:
    return sha256_payload(path.read_bytes())


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8"))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load module: %s" % path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def legacy_parser(module, text: str) -> Dict[str, Any]:
    instance = object.__new__(module.Runner)
    return module.Runner._parse_main_suite(instance, text)


def legacy_guard(module, text: str) -> Dict[str, Any]:
    return module.Runner._parse_guard(text)


def outcome(callable_: Callable[[], Dict[str, Any]]) -> Dict[str, Any]:
    try:
        parsed = callable_()
    except Exception as failure:
        return {"accepted": False, "error_type": type(failure).__name__, "error": str(failure)}
    return {"accepted": True, "error_type": None, "error": None, "parsed": parsed}


def eol_for(raw: bytes) -> bytes:
    return b"\r\n" if b"\r\n" in raw[:4096] else b"\n"


def require_single(raw: bytes, needle: bytes) -> int:
    count = raw.count(needle)
    if count != 1:
        raise RuntimeError("expected one %r, found %d" % (needle, count))
    return raw.index(needle)


def remove_line(raw: bytes, needle: bytes) -> bytes:
    index = require_single(raw, needle)
    start = raw.rfind(b"\n", 0, index) + 1
    end = raw.find(b"\n", index) + 1
    if end <= 0:
        end = len(raw)
    return raw[:start] + raw[end:]


def replace_once(raw: bytes, old: bytes, new: bytes) -> bytes:
    require_single(raw, old)
    return raw.replace(old, new, 1)


def append_after(raw: bytes, extra: bytes) -> bytes:
    eol = eol_for(raw)
    body = raw if raw.endswith(eol) else raw + eol
    return body + eol + extra + eol


def prepend(raw: bytes, extra: bytes) -> bytes:
    return extra + eol_for(raw) + raw


def build_current_mutations(raw: bytes) -> Dict[str, bytes]:
    eol = eol_for(raw)
    summary = b"# WIRE_PARSER_SUMMARY|21|3258|0|PASS"
    all_pass = b"# WIRE_PARSER_ALL_PASS"
    first_begin = b"# WIRE_PARSER_CASE_BEGIN|1|reset_and_receiving"
    first_checks = b"# WIRE_PARSER_CASE_CHECKS|1|reset_and_receiving|37"
    first_end = b"# WIRE_PARSER_CASE_END|1|reset_and_receiving|PASS"
    second_begin = b"# WIRE_PARSER_CASE_BEGIN|2|lengths_0_32"
    second_end_marker = b"# WIRE_PARSER_CASE_END|2|lengths_0_32|PASS" + eol
    case_one_start = raw.index(first_begin)
    second_start = raw.index(second_begin)
    second_end = raw.index(second_end_marker) + len(second_end_marker)
    case_one = b"".join([first_begin + eol, first_checks + eol, first_end + eol])
    case_two = raw[second_start:second_end]
    return {
        "case_name_replacement": replace_once(raw, b"WIRE_PARSER_CASE_BEGIN|1|reset_and_receiving", b"WIRE_PARSER_CASE_BEGIN|1|reset_and_received"),
        "case_status_replacement": replace_once(raw, b"WIRE_PARSER_CASE_END|1|reset_and_receiving|PASS", b"WIRE_PARSER_CASE_END|1|reset_and_receiving|FAIL"),
        "case_checks_suffix": replace_once(raw, first_checks, first_checks + b" trailing"),
        "case_checks_count": replace_once(raw, first_checks, b"# WIRE_PARSER_CASE_CHECKS|1|reset_and_receiving|38"),
        "summary_suffix": replace_once(raw, summary, summary + b" trailing"),
        "summary_case_count": replace_once(raw, summary, b"# WIRE_PARSER_SUMMARY|20|3258|0|PASS"),
        "summary_check_count": replace_once(raw, summary, b"# WIRE_PARSER_SUMMARY|21|3259|0|PASS"),
        "duplicate_case_begin": replace_once(raw, first_begin + eol, first_begin + eol + first_begin + eol),
        "duplicate_summary": replace_once(raw, summary + eol, summary + eol + summary + eol),
        "duplicate_all_pass": replace_once(raw, all_pass + eol, all_pass + eol + all_pass + eol),
        "reordered_cases": raw[:case_one_start] + case_two + case_one + raw[second_end:],
        "missing_summary": remove_line(raw, summary),
        "missing_all_pass": remove_line(raw, all_pass),
        "unknown_marker": append_after(raw, b"# WIRE_PARSER_UNRECOGNIZED|value"),
        "marker_family_suffix": append_after(raw, b"# WIRE_PARSER_CASE_END|1|reset_and_receiving|FAIL trailing"),
        "early_summary": summary + eol + remove_line(raw, summary),
        "early_all_pass": all_pass + eol + remove_line(raw, all_pass),
        "early_nonzero_tally": prepend(raw, b"# Errors: 9, Warnings: 0"),
        "duplicate_zero_tally": prepend(raw, CURRENT_TALLY),
        "conflicting_later_tally": append_after(raw, GUARD_TALLY),
        "earlier_error_diagnostic": prepend(raw, b"# ** Error: injected contradictory error"),
        "warning_diagnostic": prepend(raw, b"# ** Warning: injected warning"),
        "fatal_diagnostic": prepend(raw, b"# ** Fatal: injected fatal"),
        "trailing_text_after_tally": raw + b"trailing ordinary text" + eol,
        "malformed_conflicting_summary": append_after(raw, b"# WIRE_PARSER_SUMMARY|21|1|0|PASS trailing"),
    }


def build_guard_mutations(raw: bytes) -> Dict[str, bytes]:
    eol = eol_for(raw)
    return {
        "guard_fatal_replacement": replace_once(raw, GUARD_FATAL, b"# ** Fatal: deepeye_wire_parser: STAT_W out of bounds"),
        "guard_fatal_suffix": replace_once(raw, GUARD_FATAL, GUARD_FATAL + b" trailing"),
        "guard_missing_fatal": remove_line(raw, GUARD_FATAL),
        "guard_duplicate_fatal": replace_once(raw, GUARD_FATAL + eol, GUARD_FATAL + eol + GUARD_FATAL + eol),
        "guard_other_fatal": prepend(raw, b"# ** Fatal: injected other fatal"),
        "guard_error_diagnostic": prepend(raw, b"# ** Error: injected contradictory error"),
        "guard_warning_diagnostic": prepend(raw, b"# ** Warning: injected warning"),
        "guard_duplicate_tally": prepend(raw, GUARD_TALLY),
        "guard_conflicting_earlier_tally": prepend(raw, CURRENT_TALLY),
        "guard_warning_count_nonzero": replace_once(raw, GUARD_TALLY, b"# Errors: 1, Warnings: 1"),
        "guard_error_count_conflicting": replace_once(raw, GUARD_TALLY, b"# Errors: 2, Warnings: 0"),
        "guard_fallback_marker": append_after(raw, b"# WIRE_PARSER_GUARD_NOT_TRIGGERED"),
        "guard_success_marker": append_after(raw, b"# WIRE_PARSER_ALL_PASS"),
        "guard_unknown_marker": append_after(raw, b"# WIRE_PARSER_GUARD_UNKNOWN|value"),
        "guard_trailing_text_after_tally": raw + b"trailing ordinary text" + eol,
    }


def save_bytes(path: Path, raw: bytes) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    return sha256_payload(raw)


def probe(name: str, raw: bytes, path: Path, callable_: Callable[[], Dict[str, Any]]) -> Dict[str, Any]:
    digest = save_bytes(path, raw)
    record = outcome(callable_)
    record.update({
        "name": name,
        "raw_sha256": digest,
        "raw_bytes": len(raw),
        "raw_path": path.relative_to(WORKTREE).as_posix(),
    })
    return record


def classify_legacy(module, raw: bytes, guard: bool = False) -> Dict[str, Any]:
    text = raw.decode("utf-8", errors="replace")
    if guard:
        return legacy_guard(module, text)
    return legacy_parser(module, text)


def classify_production(module, raw: bytes, cases: Sequence[Tuple[str, int]], guard: bool = False) -> Dict[str, Any]:
    text = raw.decode("utf-8", errors="replace")
    if guard:
        return module.parse_guard_log(text)
    return module.parse_main_suite_log(text, cases)


def run_pre_fix() -> int:
    original = load_module("wire_parser_original_a3ba", ORIGINAL_RUNNER)
    prefix = load_module("wire_parser_prefix_5d09", PRE_FIX_RUNNER)
    current_raw = (PRIOR_POSITIVES / "current21-positive.bin").read_bytes()
    historical_raw = (MAIN_FEEDBACK / "positive-original.bin").read_bytes()
    guard_raw = (PRIOR_POSITIVES / "guard1-positive.bin").read_bytes()
    current_mutations = build_current_mutations(current_raw)
    guard_mutations = build_guard_mutations(guard_raw)

    historical_positive = probe(
        "historical18_positive", historical_raw, MUTATIONS / "historical18_positive.bin",
        lambda: classify_legacy(original, historical_raw),
    )
    current_positive = probe(
        "current21_positive", current_raw, MUTATIONS / "current21_positive.bin",
        lambda: classify_legacy(prefix, current_raw),
    )
    main_negatives = []
    for name in MAIN_NEGATIVE_NAMES:
        raw = (MAIN_FEEDBACK / (name + ".log")).read_bytes()
        main_negatives.append(probe(
            name, raw, MUTATIONS / "main_feedback" / (name + ".bin"),
            lambda raw=raw: classify_legacy(original, raw),
        ))
    adapted = []
    for name, raw in current_mutations.items():
        adapted.append(probe(
            name, raw, MUTATIONS / "current21" / (name + ".bin"),
            lambda raw=raw: classify_legacy(prefix, raw),
        ))
    guards = []
    for name, raw in guard_mutations.items():
        guards.append(probe(
            name, raw, MUTATIONS / "guard1" / (name + ".bin"),
            lambda raw=raw: classify_legacy(prefix, raw, guard=True),
        ))

    six_names = set(MAIN_NEGATIVE_NAMES)
    six_all_accepted = all(item["accepted"] for item in main_negatives if item["name"] in six_names)
    adapted_six = {"early_summary", "early_all_pass", "malformed_conflicting_summary", "early_nonzero_tally", "earlier_error_diagnostic", "marker_family_suffix"}
    adapted_all_accepted = all(item["accepted"] for item in adapted if item["name"] in adapted_six)
    guard_known_red = {
        "guard_other_fatal", "guard_error_diagnostic", "guard_warning_diagnostic",
        "guard_duplicate_tally", "guard_conflicting_earlier_tally",
        "guard_success_marker", "guard_unknown_marker", "guard_trailing_text_after_tally",
    }
    guard_red_names = {item["name"] for item in guards if item["accepted"]}
    guard_red_reproduced = guard_known_red.issubset(guard_red_names)
    result = {
        "schema": 1,
        "result_type": "wire_parser_runner_qualification_pre_fix",
        "generated_utc": utc_now(),
        "phase": "pre_fix",
        "source": {
            "original_runner": {"path": ORIGINAL_RUNNER.relative_to(WORKTREE).as_posix(), "sha256": sha256_path(ORIGINAL_RUNNER)},
            "prefix_runner": {"path": PRE_FIX_RUNNER.relative_to(WORKTREE).as_posix(), "sha256": sha256_path(PRE_FIX_RUNNER)},
        },
        "inputs": {
            "historical18_positive": {"path": (MAIN_FEEDBACK / "positive-original.bin").relative_to(WORKTREE).as_posix(), "sha256": sha256_path(MAIN_FEEDBACK / "positive-original.bin")},
            "current21_positive": {"path": (PRIOR_POSITIVES / "current21-positive.bin").relative_to(WORKTREE).as_posix(), "sha256": sha256_path(PRIOR_POSITIVES / "current21-positive.bin")},
            "guard1_positive": {"path": (PRIOR_POSITIVES / "guard1-positive.bin").relative_to(WORKTREE).as_posix(), "sha256": sha256_path(PRIOR_POSITIVES / "guard1-positive.bin")},
        },
        "historical_positive": historical_positive,
        "current_positive": current_positive,
        "main_feedback_negatives": main_negatives,
        "current21_adapted_negatives": adapted,
        "guard_negative_probes": guards,
        "verdict": {
            "historical_original_accepts_positive": historical_positive["accepted"],
            "historical_original_accepts_all_six_negatives": six_all_accepted,
            "prefix_current_accepts_positive": current_positive["accepted"],
            "prefix_current_accepts_all_six_adapted_negatives": adapted_all_accepted,
            "prefix_guard_accepts_known_red_set": guard_red_reproduced,
        },
    }
    write_json(BASE / "pre_fix_qualification.json", result)
    return 0 if all(result["verdict"].values()) else 1


def run_post_fix() -> int:
    production = load_module("wire_parser_production", PRODUCTION_RUNNER)
    current_raw = (PRIOR_POSITIVES / "current21-positive.bin").read_bytes()
    historical_raw = (MAIN_FEEDBACK / "positive-original.bin").read_bytes()
    guard1_raw = (PRIOR_POSITIVES / "guard1-positive.bin").read_bytes()
    guard33_raw = (PRIOR_POSITIVES / "guard33-positive.bin").read_bytes()
    current_mutations = build_current_mutations(current_raw)
    guard_mutations = build_guard_mutations(guard1_raw)
    post_mutations = MUTATIONS / "post_fix"

    historical_positive = probe(
        "historical18_positive", historical_raw, post_mutations / "historical18_positive.bin",
        lambda: classify_production(production, historical_raw, HISTORICAL_CASES),
    )
    current_positive = probe(
        "current21_positive", current_raw, post_mutations / "current21_positive.bin",
        lambda: classify_production(production, current_raw, CURRENT_CASES),
    )
    guard1_positive = probe(
        "guard1_positive", guard1_raw, post_mutations / "guard1_positive.bin",
        lambda: classify_production(production, guard1_raw, CURRENT_CASES, guard=True),
    )
    guard33_positive = probe(
        "guard33_positive", guard33_raw, post_mutations / "guard33_positive.bin",
        lambda: classify_production(production, guard33_raw, CURRENT_CASES, guard=True),
    )
    main_negatives = []
    for name in MAIN_NEGATIVE_NAMES:
        raw = (MAIN_FEEDBACK / (name + ".log")).read_bytes()
        main_negatives.append(probe(
            name, raw, post_mutations / "historical18" / (name + ".bin"),
            lambda raw=raw: classify_production(production, raw, HISTORICAL_CASES),
        ))
    current_negatives = []
    for name, raw in current_mutations.items():
        stored = MUTATIONS / "current21" / (name + ".bin")
        if sha256_path(stored) != sha256_payload(raw):
            raise RuntimeError("preserved pre-fix mutation changed: %s" % name)
        current_negatives.append(probe(
            name, raw, post_mutations / "current21" / (name + ".bin"),
            lambda raw=raw: classify_production(production, raw, CURRENT_CASES),
        ))
    guard_negatives = []
    for name, raw in guard_mutations.items():
        stored = MUTATIONS / "guard1" / (name + ".bin")
        if sha256_path(stored) != sha256_payload(raw):
            raise RuntimeError("preserved pre-fix guard mutation changed: %s" % name)
        guard_negatives.append(probe(
            name, raw, post_mutations / "guard1" / (name + ".bin"),
            lambda raw=raw: classify_production(production, raw, CURRENT_CASES, guard=True),
        ))

    positive_checks = [
        historical_positive, current_positive, guard1_positive, guard33_positive,
    ]
    positives_accepted = all(item["accepted"] for item in positive_checks)
    counts_consistent = all(
        item["parsed"].get("case_count") == len(CURRENT_CASES)
        and item["parsed"].get("check_count") == sum(count for _, count in CURRENT_CASES)
        for item in (current_positive,)
    ) and (
        historical_positive["parsed"].get("case_count") == len(HISTORICAL_CASES)
        and historical_positive["parsed"].get("check_count") == sum(count for _, count in HISTORICAL_CASES)
    )
    all_main_rejected = all(not item["accepted"] for item in main_negatives)
    all_current_rejected = all(not item["accepted"] for item in current_negatives)
    all_guard_rejected = all(not item["accepted"] for item in guard_negatives)
    result = {
        "schema": 1,
        "result_type": "wire_parser_runner_qualification_post_fix",
        "generated_utc": utc_now(),
        "phase": "post_fix",
        "source": {
            "production_runner": {
                "path": PRODUCTION_RUNNER.relative_to(WORKTREE).as_posix(),
                "sha256": sha256_path(PRODUCTION_RUNNER),
            },
        },
        "expected_tables": {
            "historical18": {"case_count": len(HISTORICAL_CASES), "check_count": sum(count for _, count in HISTORICAL_CASES)},
            "current21": {"case_count": len(CURRENT_CASES), "check_count": sum(count for _, count in CURRENT_CASES)},
        },
        "positive_controls": positive_checks,
        "historical_feedback_negatives": main_negatives,
        "current21_targeted_negatives": current_negatives,
        "guard_targeted_negatives": guard_negatives,
        "verdict": {
            "positive_controls_accepted": positives_accepted,
            "positive_counts_sum_consistent": counts_consistent,
            "all_historical_feedback_negatives_rejected": all_main_rejected,
            "all_current21_targeted_negatives_rejected": all_current_rejected,
            "all_guard_targeted_negatives_rejected": all_guard_rejected,
        },
    }
    write_json(BASE / "post_fix_qualification.json", result)
    return 0 if all(result["verdict"].values()) else 1


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Qualify wire-parser runner log classification")
    parser.add_argument("phase", choices=["pre-fix", "post-fix"])
    arguments = parser.parse_args(argv)
    if arguments.phase == "pre-fix":
        return run_pre_fix()
    if arguments.phase == "post-fix":
        return run_post_fix()
    raise RuntimeError("unsupported phase: %s" % arguments.phase)


if __name__ == "__main__":
    raise SystemExit(main())
