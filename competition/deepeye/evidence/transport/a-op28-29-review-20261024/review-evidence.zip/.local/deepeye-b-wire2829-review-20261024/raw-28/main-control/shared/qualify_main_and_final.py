from pathlib import Path
import hashlib,importlib.util,json,subprocess
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/wire-parser-20261024-29';D=E/'main/final-guards-mutants-01';D.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
runner=P/'tools/transport/main_verify_wire.py';old=runner.read_bytes();(D/'main_verify_wire.original.py').write_bytes(old)
def mod(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=mod('main_wire_before_qualification',runner);f=json.loads((E/'main/vectors-stat32-01/FREEZE.json').read_bytes());guard=(E/'main/proposal-01/guard1/vsim.stdout.bin').read_bytes();gf=dict(f,stat=1)
red=guard+b'\n# MAIN_UNEXPECTED pass\n';(D/'accepted-guard-extra-marker.log').write_bytes(red);assert m.classify(red,0,gf,'guard')['accepted']
text=old.decode();needle="and not any('MAIN_PASS' in x or 'MAIN_STATS' in x or 'MAIN_MISMATCH' in x for x in lines)";assert text.count(needle)==1
text=text.replace(needle,"and marker in ([],[begin])");runner.write_text(text,encoding='utf-8',newline='\n');fixed=mod('main_wire_after_qualification',runner)
probes=[]
def probe(name,raw,expected,code=0,mode='positive',freeze=f):
 p=D/(name+'.log');p.write_bytes(raw);v=fixed.classify(raw,code,freeze,mode)['accepted'];probes.append({'name':name,'expected':expected,'accepted':v,'sha256':sha(raw)});assert v==expected,name
positive=(E/'main/final-vector32-01/vsim.stdout.bin').read_bytes()
probe('saved_positive',positive,True)
for name,raw in [('duplicate_pass',positive+b'\n# MAIN_PASS\n'),('pass_substring',positive.replace(b'# MAIN_PASS',b'# NOT_MAIN_PASS')),('wrong_cycles',positive.replace(b'cycles=63527',b'cycles=63528')),('wrong_checks',positive.replace(b'checks=2286972',b'checks=2286973')),('extra_tally',b'# Errors: 1, Warnings: 0\n'+positive),('warning',b'# ** Warning: injected\n'+positive),('early_pass',b'# MAIN_PASS\n'+positive.replace(b'# MAIN_PASS',b'')),('fatal',positive+b'\n# ** Fatal: injected\n')]:probe(name,raw,False)
probe('bad_exit',positive,False,code=1);probe('saved_guard',guard,True,mode='guard',freeze=gf);probe('guard_extra',red,False,mode='guard',freeze=gf);probe('guard_duplicate_begin',guard+b'\n# MAIN_BEGIN kind=wire_parser stat=1\n',False,mode='guard',freeze=gf)
saved=[]
for op in ('wire-serializer-20261024-28','wire-parser-20261024-29'):
 e=P/'evidence/transport'/op
 for label in ('vector32','vector2','guard0','guard1','guard33','wrong_seed','ignore_last','advance_stall','crc_bypass','prefix_reset','overwrite_pending'):
  p=e/'main/proposal-01'/label/'RESULT.json'
  if not p.exists():continue
  d=json.loads(p.read_bytes());ff=json.loads((p.parent/'FREEZE.json').read_bytes());ff['stat']=d['stat'];raw=(p.parent/'vsim.stdout.bin').read_bytes()+b'\n'+(p.parent/'vsim.stderr.bin').read_bytes();assert fixed.classify(raw,0,ff,d['mode'])['accepted'];saved.append({'path':str(p.relative_to(W)),'result_sha256':sha(p.read_bytes())})
put(D/'CLASSIFIER_QUALIFICATION.json',{'original_sha256':sha(old),'fixed_sha256':sha(runner.read_bytes()),'probes':probes,'saved_runs_reclassified':saved,'vendor_runs_in_this_qualification':0})
rtl=P/'fpga/transport/deepeye_wire_parser.sv';raw=rtl.read_text();assert sha(rtl.read_bytes())=='7806c5d08785b96eae3708d9fd6d6002ef82faa4416a1f7244da73bece552649';runs=[]
def run(label,src,stat,mode):
 argv=[str(R/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(runner),'--rtl',str(src),'--core',str(P/'fpga/transport/deepeye_crc16_byte.sv'),'--tb',str(P/'tests/rtl/transport/main_tb_wire_parser.sv'),'--vectors',str(E/'main/vectors-stat32-01'),'--out',str(D/label),'--mode',mode,'--stat',str(stat)]
 r=subprocess.run(argv,capture_output=True);(D/(label+'.stdout.bin')).write_bytes(r.stdout);(D/(label+'.stderr.bin')).write_bytes(r.stderr);d=json.loads((D/label/'RESULT.json').read_bytes());runs.append({'label':label,'exit':r.returncode,'accepted':d['accepted'],'result_sha256':sha((D/label/'RESULT.json').read_bytes())});put(D/'PROGRESS.json',runs);assert r.returncode==0 and d['accepted'];print(json.dumps(runs[-1]),flush=True)
for s in (0,1,33):run('guard'+str(s),rtl,s,'guard')
for name,a,b in [('crc_bypass','if (crc_q == {in_data, crc_lo_q})',"if (1'b1)"),('prefix_reset','else if (in_data != MAGIC_A5)',"else if (1'b1)"),('overwrite_pending','assign in_ready = !rst && !cancel && !completed_slot_q;','assign in_ready = !rst && !cancel;')]:
 assert raw.count(a)==1;p=D/(name+'.sv');p.write_text(raw.replace(a,b),encoding='utf-8',newline='\n');run(name,p,32,'mutant')
put(D/'RESULT.json',{'accepted':True,'runs':runs,'classifier_qualified':True,'RTL_sha256':sha(rtl.read_bytes()),'formal':'all29/B04/R03/fullproduct/synth/impl/timing/CDC_RDC/board/system not_run'})
