from pathlib import Path
P=Path(__file__).parent;s=(P/'audit_and_qualify_parser.py').read_text(encoding='utf-8')
s=s.replace("D=E/'main/final-audit-01'","D=E/'main/final-audit-02'")
s=s.replace("assert p.resolve().is_relative_to(W.resolve()) and sha(p)==v['sha256']","assert (p.resolve().is_relative_to(W.resolve()) or p.resolve() in {(R/'.local/deployment/node-b/evidence/wire-parser-20261024-29'/n).resolve() for n in ('SCOPE.md','REPAIR1.md','RUNNER_REPAIR2.md')}) and sha(p)==v['sha256']")
with (P/'audit_and_qualify_parser_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
