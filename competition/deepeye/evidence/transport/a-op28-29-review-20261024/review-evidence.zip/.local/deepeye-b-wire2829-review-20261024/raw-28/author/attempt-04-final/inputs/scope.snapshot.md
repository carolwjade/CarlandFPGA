# Operation28: opaque version3 frame serialization candidate

Task DEEPEYE-IMPLEMENTATION-20261014/v1; work B-WIRE-SERIALIZER-20261024-28-v1;
operation B-DEEPEYE-WIRE-SERIALIZER-20261024-28. Main
01a13b55-095b-7461-8dd5-5476a130bd82/turn01a16933-edc1-7022-8e5f-25b4561a4ea5.
Base local head dfdb2b8120793ba816fd09cd8fc255953bbf73ac. Prior author jobs
25/26/27 actually completed; no executor owns new paths. Separate parser job
may run concurrently. Main owns independent acceptance/publication.

Read full H01-H15 pinned DEEPEYE-HUMAN-LOCK-20261014/revision1 at
f5989cd5defce561f9ba98e6b18fc2682945f0a2. Verify requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Frozen design1011259415a0916054eb580687612580bc1e5f09 unchanged, A-only board.
Taskbook section7 supplies byte layout only; A owns final ABI/type/profile/
source/session policy. This candidate treats type/epoch/seq/tick as opaque and
never grants control, freshness, profile acceptance or motion authorization.

Read-only CRC primitive competition/deepeye/fpga/transport/deepeye_crc16_byte.sv
SHA2568594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f.
Main accepted locally after16777216pairs and3 compiled mutants; publication
pending. Do not change dependency. No UART or packet-RX source edits/imports.

Implement deepeye_wire_serializer, parameter STAT_W32 legal2..32 (safe width
clamp, own timezero fatal "deepeye_wire_serializer: STAT_W out of range").
Ports clk,rst,cancel; cfg_valid,cfg_ready,cfg_type[7:0],cfg_epoch[7:0],
cfg_seq[15:0],cfg_tick[31:0],cfg_len[5:0]; p_valid,p_ready,p_data[7:0],p_last;
out_valid,out_ready,out_data[7:0],out_last,out_count[5:0]; busy,receiving,
faulted,fault_event,fault_code[1:0]; stat_admitted,stat_sent,stat_aborted,
stat_faults (STAT_W each). No output-config handshake; out_count total bytes
len+14 for a legal length is stable while busy until retirement. Idle and
illegal-length fault out_count0 (never wrap63+14 into6bits).

Exactly one32byte payload buffer plus finite metadata. Config admitted only
idle, never simultaneous payload acceptance; capture all fields and reserve.
len0 seals immediately;1..32 collect payload. len33..63 poisoncode1. For each
payload handshake p_last iff index==len-1, else poisoncode2. Invalid frames
reserve busy until synchronous reset/cancel, expose no output. event pulses
onecycle, fault/code sticky. Metadata/payload changes while not accepted ignored.

After zero-length config or valid final payload edge, output becomes available
starting following cycle, with no same-edge bypass/retirement. Exact bytes:
A5 5A 03 type len epoch seq_lo seq_hi tick_lo tick_8 tick_16 tick_hi payload...
crc_lo crc_hi. CRC16/CCITT-FALSE seedFFFF, no reflection/xorout, covers03
through payload inclusive, excludes magic and CRC. Instantiate unchanged CRC
primitive once; update only accepted covered output bytes. No partial output
before complete input validation. out_last only finalCRC byte; valid/data/last/
count stable during stall. On final output handshake retire frame/sent++, then
idle; no same-edge new config credit. out_valid and cfg/pready gated rst/cancel.
Use bounded positions0..45, no 7th-bit wrap. out_count len+14 fits6bits.

Synchronous reset>cancel>ordinary. Reset clears all control/counters. Cancel
flushes reservation and pending byte, counts one aborted iff oldbusy; other
counters preserved; held cancel counts once. No out handshakes on abort. All
counters saturate. Before saturation absent reset: admitted=sent+aborted+busy.
Unknown inputs/physical CDC not claimed. A caller must discard partial output
after cancel; this module alone provides no packet/control authorization.

Root D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014.
Author owns ONLY competition/deepeye-relative fpga/transport/deepeye_wire_serializer.sv,
fpga/transport/wire_serializer_candidate.md, tests/rtl/transport/tb_wire_serializer.sv,
tools/transport/run_wire_serializer.py, evidence/transport/wire-serializer-20261024-28/author/.
Main owns main tests/oracles/evidence, handoff and private scope. Do not read
main tests/oracles/evidence. No commit/push/peer/group/service/config/credential/
SQL/queue/board actions. No edits to public A schema or prior modules.

Real ModelSim10.7 author tests: lengths0..32, all256bytes, max seq/tick/endian,
zero-length CRC, stalled metadata/output and randomized bubbles, payload faults,
cancel/reset each receive/header/payload/CRC/final phase, no-credit and small
counter saturation/guards. Main freezes struct.pack+binascii packet fixtures
and public-handshake oracle before source inspection, with compiled mutants.
Portable strict runner: exact unique ordered markers and consistent per-case/
summary counts, complete stats, real exits/timeouts/diagnostics. Scope absence
and Git HEAD context only; source snapshots and contract remain mandatory.
Fresh owned dirs, preserve failures/raw commands/toolversions/hashes; TEMP/TMP/
TMPDIR/caches/simulator cwd inside author ownership. Actual thread/turn and
author/RESULT.json required. All29/B04/R03/fullproduct/synth/impl/CDC_RDC/board/
system not_run. Concrete [需桌面回合]/[需本人操作] only to parent. No polling/READY.
