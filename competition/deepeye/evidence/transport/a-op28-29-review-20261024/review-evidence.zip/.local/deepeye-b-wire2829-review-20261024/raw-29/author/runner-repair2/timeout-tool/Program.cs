using System;
using System.IO;
using System.Threading;

internal static class Program
{
    private static int Main(string[] args)
    {
        if (args.Length == 1 && args[0] == "-version")
        {
            string tool = Path.GetFileNameWithoutExtension(Environment.GetCommandLineArgs()[0]);
            Console.WriteLine("Model Technology ModelSim SE-64 " + tool + " 10.7 Compiler 2017.12 Dec  7 2017");
            return 0;
        }

        Thread.Sleep(30000);
        return 0;
    }
}
