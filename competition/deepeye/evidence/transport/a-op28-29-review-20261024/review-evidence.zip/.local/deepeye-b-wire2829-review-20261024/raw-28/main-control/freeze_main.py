from pathlib import Path
import hashlib,json,datetime
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';E=W/'competition/deepeye'
files=[E/'tools/transport/main_generate_wire_vectors.py',E/'tools/transport/main_verify_wire.py']
for kind,op in [('wire_serializer','wire-serializer-20261024-28'),('wire_parser','wire-parser-20261024-29')]:
 files.append(E/f'tests/rtl/transport/main_tb_{kind}.sv')
 for s in (32,2):files.extend((E/f'evidence/transport/{op}/main/vectors-stat{s}-01'/n) for n in ('vectors.hex','FREEZE.json'))
receipt={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','main_turn':'01a16933-edc1-7022-8e5f-25b4561a4ea5','task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'author_RTL_or_tests_inspected':False,'files':{str(p.relative_to(W)).replace('\\','/'):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files}}
p=Path(__file__).parent/'MAIN_PREINSPECTION_FREEZE.json'
with p.open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2)
print(json.dumps({'frozen_files':len(files),'at_utc':receipt['at_utc'],'receipt':str(p)}))
