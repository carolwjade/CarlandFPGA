"""Root limited new wire simulation acceptance, with historical F01 left open."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,tarfile,zipfile
P=Path(__file__).resolve().parent;R=P.parents[2];O=P.parent;W=R/'.local/deepeye-implementation-a';A=O/'b-wire2829-independent-20261024';S=R/'.local/deepeye-b-wire2829-review-20261024'
BASE='53670b09f53a9907b9739b5521a71e313286b17f';GIT=r'C:\Users\CarlJade\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def git(*a):return subprocess.check_output([GIT,'--no-optional-locks','-C',str(W),*a])
assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--cached','--name-only').strip()
protected=read(O/'r03-mailbox-stop-main-review-20261020/application.json')['protected_files'];assert all(sha((W/n).read_bytes())==h for n,h in protected.items())
job=read(P/'wire2829-terminal.json')[0];assert job['status']=='completed' and job['terminal'] and not job['stale'];platform=job['result']['text']
for n in ['report.md','result.json','EVIDENCE_MANIFEST.json']:assert sha((A/n).read_bytes()) in platform
m=read(A/'EVIDENCE_MANIFEST.json');assert len(m['files'])==2173
members={}
for row in m['files']:
 path=(R/row['path']).resolve();assert path.is_relative_to(R.resolve());raw=path.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];members[row['path']]=raw
source=read(A/'SOURCE_HASH_MANIFEST.json');assert len(source['files'])==32 and source['tested_commit']=='0e3ffa8c19eec5361d4ed7912bf9204037f2ddf3' and source['source_commit']=='82d376dc3df9bf384407f733b9d8b8f2e3a848c2'
for row in source['files']:
 raw=(S/'snapshot'/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob']
ops=[('28','B-DEEPEYE-WIRE-SERIALIZER-20261024-28','6bba890baddd643e483789ce31f424b9889e4ec5fa44d78c27f37425560e38ad','efc554f023e1669a2d1239d4b08e83824452d17be5c5d8a607e2605b312e53a6',587),('29','B-DEEPEYE-WIRE-PARSER-20261024-29','3bb7f34ff2af44a03648ef6107b0b587cac28a77bc6b6131d5810ef86bc68612','4c9bea692eee47e43a044360b9183dc5b6b230676a7089336ae5fa81602d8a26',1238)]
for number,op,request,manifest,count in ops:
 path=S/'snapshot/handoffs/b'/op/'manifest.json';manifest_doc=read(path);assert sha(path.read_bytes())==manifest
 assert sha(json.dumps(manifest_doc['request'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==request
 for name,row in manifest_doc['files'].items():
  raw=(S/'snapshot'/name).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row.get('size',row.get('bytes'))
  if name.endswith('/raw-evidence.tar.gz'):
   with tarfile.open(S/'snapshot'/name,'r:gz') as tf:
    entries=tf.getmembers();assert len(entries)==count and all(e.isfile() for e in entries) and len(set(e.name for e in entries))==count
result=read(A/'result.json');focused=result['new_focused_simulation'];assert focused['passed'] and len(focused['results'])==2
all_raw=list((S/'focused-02').rglob('*'));raw_hashes={sha(p.read_bytes()):p for p in all_raw if p.is_file()}
for test in focused['results']:
 assert test['passed'] and test['exit']==0 and test['stdout_sha256'] in raw_hashes and test['stderr_sha256'] in raw_hashes
 log=raw_hashes[test['stdout_sha256']].read_text(encoding='utf-8');assert 'Errors: 0, Warnings: 0' in log and 'Warning:' not in log
assert sum(x['checks'] for x in focused['results'])==1479 and sum(x['cycles'] for x in focused['results'])==1168
qualification=read(A/'focused-log-qualification.json');assert qualification['all_expected'] and len(qualification['probes'])==20
finding=read(A/'finding-F01.json');assert len(result['unresolved_findings'])==1 and result['unresolved_findings'][0]['id']=='F01'
assert result['unresolved_findings'][0]['verified_counts']=={'path_mapped':148,'same_hash_archived_copies':5,'missing':2}
assert all(not x['canonical_handoff_artifact'] and not x['promised_RAW_INDEX_member'] for x in result['unresolved_findings'][0]['missing'])
decision={'schema':1,'utc':datetime.now(timezone.utc).isoformat(),'owner':'A/root 01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3','disposition':'ACCEPT_NEW_DIRECTED_SERIALIZER_PARSER_SYNTAX_SIMULATION_ONLY_WITH_OPEN_F01','tested_commit':source['tested_commit'],'source_commit':source['source_commit'],'bindings':[{'operation_id':op,'request_hash':req,'manifest_sha256':man,'saved_raw_members':count} for _,op,req,man,count in ops],'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','H01_H15_preserved':True,'root_selected_blobs_verified':32,'root_review_artifacts_verified':2173,'canonical_artifact_and_promised_raw_integrity':'verified','new_directed_configs':2,'new_clocks':1168,'new_checks':1479,'new_DUT_findings':[],'own_log_qualification_probes':20,'open_findings':result['unresolved_findings'],'producer_history_claim':'155-reference and historical pre-fix runner execution-origin audit NOT wholly closed; F01 remains unresolved','producer_full_qualification_accepted':False,'producer_old_groups_rerun':False,'full_top_checkout':False,'A_semantic_ABI_control_build_board_system_accepted':False,'B04':'not_run','G03':'not_run','R03':'not_run','all29':'not_run'}
dest=W/'competition/deepeye/evidence/transport/a-op28-29-review-20261024';assert not dest.exists();secret=read(A/'lease.private.json')['lease_token'].encode()
for n in ['report.md','result.json','EVIDENCE_MANIFEST.json','manifest-readback.json','MANIFEST.sha256.txt','native-complete.json']:members['review-final/'+n]=(A/n).read_bytes()
members['root/archive_wire2829_review.py']=Path(__file__).read_bytes();members['root/native-terminal.json']=(P/'wire2829-terminal.json').read_bytes()
assert all(secret not in raw for raw in members.values()) and all('lease.private' not in n for n in members)
dest.mkdir(parents=True);zp=dest/'review-evidence.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(members.items()):z.writestr(n,raw)
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None and len(z.namelist())==len(members)
 for n,raw in members.items():assert z.read(n)==raw
save(dest/'manifest.json',{'schema':1,'zip_sha256':sha(zp.read_bytes()),'zip_bytes':zp.stat().st_size,'member_count':len(members),'members':[{'path':n,'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(members.items())],'credentials_excluded':True})
save(dest/'decision.json',decision);save(dest/'F01.json',finding)
(dest/'README.md').write_text('Root accepts only new directed public-port serializer/parser syntax simulation:1168 clocks/1479 checks, at the exact B head. Canonical artifacts and1825 promised raw members are intact. F01 stays open:two old runner cache files are absent, so the historical155-reference/pre-fix execution-origin claim is not fully closed. No full producer qualification or A semantic/control/build/board/system acceptance is granted. Original failures, warning/classifier correction and new controls are retained. H01-H15 unchanged; B04/G03/R03/all29=not_run.\n',encoding='utf-8',newline='\n')
files={f.relative_to(W).as_posix():sha(f.read_bytes()) for f in dest.iterdir()};save(P/'wire2829-root-decision.json',decision);save(P/'wire2829-publication.json',{'expected_head':BASE,'message':'Archive directed wire28-29 review with historical provenance finding open','files':files})
assert all(sha((W/n).read_bytes())==h for n,h in protected.items())
print(json.dumps({'prepared_files':len(files),'archive_members':len(members),'open_F01':True,'root_selected_blobs':32,'C4_unchanged':True}))
