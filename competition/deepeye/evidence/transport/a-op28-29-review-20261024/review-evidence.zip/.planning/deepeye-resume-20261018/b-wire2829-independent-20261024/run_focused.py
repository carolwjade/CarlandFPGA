import subprocess,ctypes,pathlib,json,os,shutil,re,datetime,sys
from acquire import OUT,LOCAL,sha,save_json
BIN=pathlib.Path('C:/modeltech64_2020.4/win64')
attempt_name=sys.argv[1] if len(sys.argv)>1 else 'focused-02'
attempt=LOCAL/attempt_name;attempt.mkdir(exist_ok=False)
receipts=[]
def run(argv,name,cwd=attempt):
    r=subprocess.run(list(map(str,argv)),cwd=str(cwd),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
    (attempt/(name+'.stdout.bin')).write_bytes(r.stdout);(attempt/(name+'.stderr.bin')).write_bytes(r.stderr)
    row={'argv':list(map(str,argv)),'cwd':str(cwd),'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    receipts.append(row);save_json(attempt/(name+'.receipt.json'),row)
    return r
before=run(['subst'],'subst-before')
mask=ctypes.windll.kernel32.GetLogicalDrives()
drive=next(x for x in ['R','T','U','V','W','X'] if not mask&(1<<(ord(x)-65)))+':'
mapped=False
try:
    map_result=run(['subst',drive,str(LOCAL)],'subst-create')
    assert map_result.returncode==0
    mapped=True
    readback=run(['subst'],'subst-active')
    assert drive.encode() in readback.stdout
    sim=pathlib.Path(drive+'/'+attempt_name)
    for n in [0,1,32]:shutil.copyfile(LOCAL/f'frame{n}.hex',attempt/f'frame{n}.hex')
    rtl=pathlib.Path(drive+'/snapshot/competition/deepeye/fpga/transport')
    inputs=[rtl/'deepeye_crc16_byte.sv',rtl/'deepeye_wire_serializer.sv',rtl/'deepeye_wire_parser.sv',pathlib.Path(drive+'/tb_focused.sv')]
    save_json(attempt/'inputs-freeze.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[{'path':str(p),'sha256':sha(p.read_bytes())} for p in inputs],'oracle_freeze_sha256':sha((OUT/'oracle-freeze.json').read_bytes()),'configs':{'serializer':32,'parser':32},'no_author_testbench_or_reference_imported':True,'ASCII_mapping':{'drive':drive,'target':str(LOCAL),'preexisting':False}})
    for exe in ['vlog','vsim']:
        r=run([BIN/(exe+'.exe'),'-version'],exe+'-version',sim);assert r.returncode==0
    r=run([BIN/'vlib.exe','work'],'vlib',sim);assert r.returncode==0
    r=run([BIN/'vlog.exe','-sv',*inputs],'vlog',sim);assert r.returncode==0
    assert not re.search(rb'\*\* (?:Error|Warning|Fatal)',r.stdout+r.stderr)
    results=[]
    (attempt/'focused.do').write_text('onerror {quit -code 2 -f}\nrun -all\nquit -code 0 -f\n',encoding='ascii')
    for top in ['tb_serializer','tb_parser']:
        r=run([BIN/'vsim.exe','-c','-onfinish','stop','work.'+top,'-do','focused.do'],top,sim)
        combined=r.stdout+r.stderr
        passes=re.findall(rb'INDEP_PASS (serializer|parser) checks=(\d+) cycles=(\d+)',combined)
        diagnostics=re.search(rb'(?im)^[#\s]*(?:\*\*\s*)?(?:Error|Warning|Fatal)\s*:',combined)
        tally=re.findall(rb'Errors:\s*(\d+),\s*Warnings:\s*(\d+)',combined)
        passed=(r.returncode==0 and len(passes)==1 and b'INDEP_FAIL' not in combined and diagnostics is None and tally==[(b'0',b'0')])
        results.append({'top':top,'passed':passed,'exit':r.returncode,'checks':int(passes[0][1]) if len(passes)==1 else None,'cycles':int(passes[0][2]) if len(passes)==1 else None,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)})
        print(combined.decode(errors='replace'))
        if not passed:break
    save_json(OUT/('focused-result-'+attempt_name+'.json'),{'attempt':str(attempt.relative_to(LOCAL)),'results':results,'passed':len(results)==2 and all(r['passed'] for r in results),'scope':'one STAT_W=32 config per primitive; selected public-port directed controls only','RTL_unchanged':True})
finally:
    if mapped:
        removed=run(['subst',drive,'/d'],'subst-remove')
        after=run(['subst'],'subst-after')
        save_json(OUT/('mapping-cleanup-'+attempt_name+'.json'),{'drive':drive,'target':str(LOCAL),'remove_exit':removed.returncode,'mapping_absent_after':drive.encode() not in after.stdout,'logical_drive_absent_after':not (ctypes.windll.kernel32.GetLogicalDrives()&(1<<(ord(drive[0])-65))),'before_stdout_sha256':sha(before.stdout),'after_stdout_sha256':sha(after.stdout)})
        assert removed.returncode==0 and drive.encode() not in after.stdout
    save_json(OUT/('focused-command-index-'+attempt_name+'.json'),receipts)
