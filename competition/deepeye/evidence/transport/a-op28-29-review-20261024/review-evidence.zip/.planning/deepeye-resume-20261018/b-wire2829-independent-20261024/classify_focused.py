import re,json
from acquire import OUT,LOCAL,save_json,sha
CASES={
'serializer':['frame0 PASS','frame1 PASS','frame32 PASS','fault_abort reset=0 illegal=0 PASS','fault_abort reset=1 illegal=0 PASS','fault_abort reset=0 illegal=1 PASS'],
'parser':['frame32 PASS','frame1 PASS','frame0 PASS','diagnostic code=1 reset=0 PASS','diagnostic code=2 reset=1 PASS','diagnostic code=3 reset=0 PASS','partial reset=0 PASS','partial reset=1 PASS']}
COUNTS={'serializer':(852,650),'parser':(627,518)}
def classify(data,module,exit_code=0):
    if exit_code: return False,'nonzero exit'
    if re.search(rb'(?im)^[#\s]*(?:\*\*\s*)?(?:Error|Warning|Fatal)\s*:',data):return False,'diagnostic'
    if re.findall(rb'Errors:\s*(\d+),\s*Warnings:\s*(\d+)',data)!=[(b'0',b'0')]:return False,'tally'
    lines=[s.strip().lstrip(b'#').strip().decode('ascii',errors='replace') for s in data.splitlines() if b'INDEP_' in s]
    checks,cycles=COUNTS[module]
    expected=['INDEP_CASE '+module+' '+s for s in CASES[module]]+[f'INDEP_PASS {module} checks={checks} cycles={cycles}']
    if lines!=expected:return False,'ordered unique complete marker protocol'
    return True,'exact expected protocol and zero diagnostics'
def main():
    probes=[]
    for module in CASES:
        top='tb_'+module;data=(LOCAL/'focused-02'/(top+'.stdout.bin')).read_bytes()+(LOCAL/'focused-02'/(top+'.stderr.bin')).read_bytes()
        assert classify(data,module)[0]
        for name,mut,expected in [
            ('positive',data,True),
            ('plain_warning',data+b'\n# Warning: synthetic\n',False),
            ('fatal',data+b'\n# ** Fatal: synthetic\n',False),
            ('missing_case',data.replace(('INDEP_CASE '+module+' '+CASES[module][0]).encode(),b'IGNORED'),False),
            ('duplicate_case',data+('\n# INDEP_CASE '+module+' '+CASES[module][0]+'\n').encode(),False),
            ('unknown_marker',data+b'\n# INDEP_FALLBACK PASS\n',False),
            ('duplicate_pass',data+f'\n# INDEP_PASS {module} checks={COUNTS[module][0]} cycles={COUNTS[module][1]}\n'.encode(),False),
            ('conflicting_tally',data+b'\n# Errors: 1, Warnings: 0\n',False),
            ('wrong_module',data.replace(('INDEP_PASS '+module).encode(),b'INDEP_PASS other'),False)]:
            accepted,reason=classify(mut,module)
            assert accepted==expected,(module,name)
            probes.append({'module':module,'name':name,'synthetic':name!='positive','sha256':sha(mut),'accepted':accepted,'expected':expected,'reason':reason})
        old=(LOCAL/'focused-01'/(top+'.stdout.bin')).read_bytes()+(LOCAL/'focused-01'/(top+'.stderr.bin')).read_bytes()
        accepted,reason=classify(old,module)
        assert not accepted and reason=='diagnostic'
        probes.append({'module':module,'name':'first_real_attempt_with_Tcl_warning','synthetic':False,'sha256':sha(old),'accepted':False,'expected':False,'reason':reason})
    save_json(OUT/'focused-log-qualification.json',{'probes':probes,'all_expected':True,'simulator_runs_in_qualification':0,'first_attempt_original_pass_field_superseded':True,'reason':'Initial custom runner missed a plain Tcl Warning; original stdout/receipt/result retained. Macro .do invocation removes this warning in focused-02. All RTL assertions passed in both real attempts; only focused-02 is qualified.'})
    print(json.dumps({'qualification_probes':len(probes),'all_expected':True,'qualified_final_cycles':sum(v[1] for v in COUNTS.values()),'qualified_final_checks':sum(v[0] for v in COUNTS.values())}))
if __name__=='__main__':main()
