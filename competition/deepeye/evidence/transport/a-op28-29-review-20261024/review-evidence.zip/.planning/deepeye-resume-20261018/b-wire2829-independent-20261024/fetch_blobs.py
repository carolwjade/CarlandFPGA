import concurrent.futures, json, hashlib, base64, pathlib
from acquire import ROOT,OUT,LOCAL,META,HEAD,SOURCE,api,sha,save_json
tree=json.loads((META/'head-tree.json').read_bytes())
entries={e['path']:e for e in tree['tree'] if e['type']=='blob'}
src={e['path']:e for e in json.loads((META/'source-tree.json').read_bytes())['tree'] if e['type']=='blob'}
SNAP=LOCAL/'snapshot'; SNAP.mkdir(exist_ok=True)
def get(path):
    e=entries[path]; p=SNAP/path
    if p.exists(): b=p.read_bytes()
    else:
        obj=api('repos/carolwjade/CarlandFPGA/git/blobs/'+e['sha'],'blob-'+e['sha'])
        b=base64.b64decode(obj['content']);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    assert blob==e['sha'] and len(b)==e['size'],path
    return {'path':path,'bytes':len(b),'git_blob':blob,'sha256':sha(b),'same_blob_at_source':src.get(path,{}).get('sha')==blob}
paths=json.loads((OUT/'acquisition-index.json').read_bytes())['paths']
paths += [p for p in entries if 'crc32' in p.lower() and p.endswith('.sv')]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: results=list(ex.map(get,paths))
# Fetch any additional manifest artifact paths without importing or executing producer code.
extra=[]
for p in paths:
    if p.endswith('/manifest.json') and p.startswith('handoffs/'):
        m=json.loads((SNAP/p).read_bytes())
        arts=m.get('artifacts',[])
        for a in arts:
            path=a if isinstance(a,str) else a['path']
            if path not in paths: extra.append(path)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: results+=list(ex.map(get,sorted(set(extra))))
save_json(OUT/'git-blob-verification.json',{'tested_commit':HEAD,'source_commit':SOURCE,'whole_top_checkout':False,'selected_blob_count':len(results),'files':results})
print(json.dumps({'selected_blob_count':len(results),'crc_paths':[p for p in paths if 'crc32' in p.lower()]},indent=2))
