import pathlib,json,datetime,sys
from acquire import OUT,ROOT,LOCAL,sha,save_json
manifest=OUT/'EVIDENCE_MANIFEST.json'
exclusions={'lease.private.json','EVIDENCE_MANIFEST.json','MANIFEST.sha256.txt','manifest-readback.json','native-complete.json'}
def rows():
    ans=[]
    for folder in [OUT,LOCAL]:
        for p in sorted(folder.rglob('*')):
            if not p.is_file() or (p.parent==OUT and p.name in exclusions):continue
            b=p.read_bytes();ans.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':sha(b)})
    return ans
if len(sys.argv)>1 and sys.argv[1]=='verify':
    obj=json.loads(manifest.read_bytes())
    for row in obj['files']:
        p=ROOT/row['path'];b=p.read_bytes()
        assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
    assert rows()==obj['files'],'file set changed after freeze'
    digest=sha(manifest.read_bytes())
    assert (OUT/'MANIFEST.sha256.txt').read_text().split()[0]==digest
    result={'status':'all_frozen_file_hashes_read_back','file_count':len(obj['files']),'manifest_sha256':digest,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_sha256':sha((OUT/'report.md').read_bytes()),'result_sha256':sha((OUT/'result.json').read_bytes())}
    save_json(OUT/'manifest-readback.json',result);print(json.dumps(result,indent=2))
else:
    obj={'schema':1,'work_id':'A-B-WIRE2829-INDEPENDENT-20261024-v1','scope':'Only this task owned planning/local directories. Private lease token is excluded. Native completion receipt and readback record are created after sealing and excluded.','exclusions':sorted(exclusions),'files':rows()}
    save_json(manifest,obj)
    digest=sha(manifest.read_bytes());(OUT/'MANIFEST.sha256.txt').write_text(digest+'  EVIDENCE_MANIFEST.json\n',encoding='ascii')
    print(json.dumps({'file_count':len(obj['files']),'manifest_sha256':digest},indent=2))
