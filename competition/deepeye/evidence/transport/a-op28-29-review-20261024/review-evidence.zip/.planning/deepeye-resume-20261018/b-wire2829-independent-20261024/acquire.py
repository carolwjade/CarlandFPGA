import base64, hashlib, json, pathlib, subprocess, datetime, sys
ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = pathlib.Path(__file__).resolve().parent
LOCAL = ROOT / '.local/deepeye-b-wire2829-review-20261024'
LOCAL.mkdir(parents=True, exist_ok=True)
META = LOCAL/'metadata'; META.mkdir(exist_ok=True)
HEAD='0e3ffa8c19eec5361d4ed7912bf9204037f2ddf3'
SOURCE='82d376dc3df9bf384407f733b9d8b8f2e3a848c2'
GH=r'C:/Program Files/GitHub CLI/gh.exe'
def sha(b): return hashlib.sha256(b).hexdigest()
def save_json(p,o): p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def api(endpoint,name):
    p=META/(name+'.json')
    if p.exists(): return json.loads(p.read_bytes())
    argv=[GH,'api',endpoint]
    r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (META/(name+'.stderr.txt')).write_bytes(r.stderr)
    save_json(META/(name+'.command.json'),{'argv':argv,'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    if r.returncode: raise RuntimeError((name,r.returncode,r.stderr.decode(errors='replace')))
    p.write_bytes(r.stdout)
    return json.loads(r.stdout)
def main():
    scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_bytes())
    digest=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf8'))
    assert digest=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
    save_json(OUT/'scope-validation.json',{'contract':'DEEPEYE-HUMAN-LOCK-20261014/revision1','canonical_requirements_sha256':digest,'ids':[r['id'] for r in scope['requirements']],'director_generation':3,'physical_board_operator':'A/root only','native_agent_id':'/root/b_wire2829_review','execution_allowed':True})
    pr=api('repos/carolwjade/CarlandFPGA/pulls/30','pr30')
    hc=api('repos/carolwjade/CarlandFPGA/git/commits/'+HEAD,'head-commit')
    sc=api('repos/carolwjade/CarlandFPGA/git/commits/'+SOURCE,'source-commit')
    tr=api('repos/carolwjade/CarlandFPGA/git/trees/'+HEAD+'?recursive=1','head-tree')
    sr=api('repos/carolwjade/CarlandFPGA/git/trees/'+SOURCE+'?recursive=1','source-tree')
    assert not tr.get('truncated') and not sr.get('truncated')
    names=[x['path'] for x in tr['tree'] if x['type']=='blob' and ('wire' in x['path'].lower() or 'SERIALIZER-20261024-28' in x['path'] or 'PARSER-20261024-29' in x['path'])]
    save_json(OUT/'acquisition-index.json',{'pinned_head':HEAD,'pinned_source':SOURCE,'current_pr_head':pr['head']['sha'],'head_parent_shas':[p['sha'] for p in hc['parents']],'source_parent_shas':[p['sha'] for p in sc['parents']],'metadata_tree_complete':True,'snapshot_scope':'selected blobs only; no whole-top checkout claim','paths':names})
    print(json.dumps({'requirements_sha256':digest,'current_pr_head':pr['head']['sha'],'paths':names},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
