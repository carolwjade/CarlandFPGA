# B op28/29 限定独立复核

新 public-port 仿真控制通过；未发现新 DUT 断言失败。**保留一个未解决的历史证据 finding F01**，由 A Gen3/root 判断正式接受范围。本子代理没有进行正式验收。

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，work `A-B-WIRE2829-INDEPENDENT-20261024-v1`；租约 canonical agent `/root/b_wire2829_review` 返回 execution_allowed=true。A Gen3 主为 `01a16988-bdcb-70e1-ae10-1304b5cf7875`。H01–H15 保持，canonical requirements 实算为 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，A/root 唯一实板操作者。

## 精确输入与字节完整性

PR30 https://github.com/carolwjade/CarlandFPGA/pull/30 。实际 API 读回 head `0e3ffa8c19eec5361d4ed7912bf9204037f2ddf3`，其直接 parent 为 source `82d376dc3df9bf384407f733b9d8b8f2e3a848c2`。取得32个选定 Git blob，以 Git blob SHA1、文件 SHA256和长度重核；这不是 whole-top checkout 或完整系统源码审查。

| Operation | request SHA256 | manifest SHA256 | raw 成员 |
|---|---|---|---|
| B-DEEPEYE-WIRE-SERIALIZER-20261024-28 | 6bba890baddd643e483789ce31f424b9889e4ec5fa44d78c27f37425560e38ad | efc554f023e1669a2d1239d4b08e83824452d17be5c5d8a607e2605b312e53a6 | 587 |
| B-DEEPEYE-WIRE-PARSER-20261024-29 | 3bb7f34ff2af44a03648ef6107b0b587cac28a77bc6b6131d5810ef86bc68612 | 4c9bea692eee47e43a044360b9183dc5b6b230676a7089336ae5fa81602d8a26 | 1238 |

两份 request canonical hash、artifact 全集、source binding、bundle/index hash及1825个承诺 raw 成员全部相符。CRC dependency SHA256 `8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f`。完整记录在 evidence-verification.json、SOURCE_HASH_MANIFEST.json。

## 新独立控制

实际顺序：先读两项 public candidate 的语法/接口/生命周期文档和固定人类合同，冻结 own struct.pack/binascii 向量及断言，再首次阅读两项 RTL。下载过的 RTL 字节在 freeze 前没有被本代理检查。未导入或执行作者/main TB、向量发生器或参考 oracle。CRC 标准库结果另由自写多项式递推及123456789=29B1交叉核对；共享CRC算法定义并不构成独立CRC实现证明。候选只是 opaque version3 语法，不建立冻结的 A semantic ABI。

ModelSim SE-64 **2020.4**，每个原语仅一个 `STAT_W=32` config。合格的 focused-02：serializer **650 clocks/852 checks**，parser **518 clocks/627 checks**，共 **1168 clocks/1479 checks**；进程 exit0，最终 Errors0/Warnings0。检查长度0/1/32、精确端序/CRC、配置捕获、背压稳定、payload-last和length33拒绝、parser坏version/length/CRC、短payload零尾、pending slot无同沿输入credit、partial/error/fault在下降沿reset/cancel后的注册状态保持、立即握手门控、同步清除、held-cancel与reset优先级。

首次 focused-01 的同一断言也通过，但 Tcl onerror 直接命令产生 plain Warning，初版自用判定器漏检。保留原 raw/result；改用 .do 文件和严格marker/diagnostic判定后复验。20个保存日志正负probe全部符合预期，旧真实警告日志被拒绝。没有把初版 pass字段作为合格最终结果。ASCII R:在确认未占用后仅映射本任务.local目录，两次均finally移除并读回。

## 生产者历史证据层

未重跑原4configs/170633cycles/5881098portchecks、6guards/6mutants或作者组。对保存的9+8项main run重核RESULT、input和原stdout/stderr哈希；主14/236项runner probe的保存结论与expected一致；作者postfix保存6+25+15 negatives全部拒绝、4 positives接受，相关样本字节相符。历史“preinspection”顺序仍是生产者记录，本代理没有将其提升为自己观察到的原时过程。

原 serializer `pre_fault_event got0 expected1`、parser `pre_receiving got0 expected1` 失败日志完整保留，和最终RTL的修正diff单独保存。原失败与最终run的vectors SHA相同。还保存了producer guard duplicate-header错误fixture、scope路径边界错误、runner此前接受非法日志的记录及修复qualification。作者自证、B主旧验收与本轮A子代理控制分层。

## F01：155-reference审计未完全封闭

155引用中148按归档路径核验；5找到同SHA归档副本（3 private scope、2当前candidate/runner，后两项也与canonical blob相符）。以下2个缓存没有原字节，也没有归档同hash副本：

| 旧runner cache（author/runner-repair2/inputs/__pycache__/） | producer SHA256 |
|---|---|
| original_runner_a3ba.cpython-312.pyc | 254b5638f75b28f05d51c03465b5011a0394d195965c3bfb4ca93a33c6e61b24 |
| pre_fix_runner_5d09.cpython-312.pyc | 8d208266a1dad83a03eba4fbf7631596e8d273f8bfee7c2adbeefa8de20285c2 |

它们不是handoff canonical artifact，也不是RAW_INDEX1238承诺成员，故canonical打包完整性检查仍通过。对应原.py文件完整且hash匹配。然而 qualifier.py第82–87行采用importlib source loader，第240–241行载入这两源；归档不能确立原时是否消费缓存，不能独立重现完整155项字节审计或完全封闭该历史预修复runner执行来源。最终发布runner源码与新DUT控件不依赖这两缺失归档文件。此finding保持unresolved；没有重建pyc、重跑B旧组或修改B产品。详见 finding-F01.json。

本复核自身历史helper首次descriptor类型假设错误和第二次发现缺失reference的失败均保留；第一项仅有原工具trace与脚本，未伪称另存原二进制pipe。

## 边界

仅限opaque A55A/version3/payload0..32/端序/CRC/storage/handshake仿真证据。A type/profile/source/session/BOOT/clock/TTL/replay/control策略、UART composition、wall-time timeout、synth/impl/timing/CDC_RDC/build/board/system未验收。all29/B04/G03/R03仍not_run。没有产品编辑、stage/commit/reset、实板/串口/UI/服务动作或外部消息；当前A另一个子代理的7文件归属未触碰。正式PR反馈和接受由root负责。
