import subprocess,sys
from acquire import OUT,LOCAL,sha,save_json
argv=[sys.executable,'-B','-X','utf8',str(OUT/'review_history.py')]
r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
label='history-review-03'
(OUT/(label+'.stdout.bin')).write_bytes(r.stdout)
(OUT/(label+'.stderr.bin')).write_bytes(r.stderr)
save_json(OUT/(label+'-command.json'),{'argv':argv,'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)})
print(r.stdout.decode(errors='replace'));print(r.stderr.decode(errors='replace'))
sys.exit(r.returncode)
