import binascii,struct,json,datetime,hashlib
from acquire import OUT,LOCAL,save_json,sha
def crc_division(data):
    r=0xffff
    for byte in data:
        r ^= byte<<8
        for _ in range(8): r=((r<<1)^0x1021 if r&0x8000 else r<<1)&0xffff
    return r
assert binascii.crc_hqx(b'123456789',0xffff)==0x29b1==crc_division(b'123456789')
vectors=[]
for n in [0,1,32]:
    payload=bytes((0xa5+37*i)&255 for i in range(n))
    body=struct.pack('<BBBBHI',3,0x96,n,0x27,0x8b4d,0xc16a3902)+payload
    crc=binascii.crc_hqx(body,0xffff)
    assert crc_division(body)==crc
    wire=b'\xa5\x5a'+body+struct.pack('<H',crc)
    vectors.append({'length':n,'type':0x96,'epoch':0x27,'seq':0x8b4d,'tick':0xc16a3902,'payload_hex':payload.hex(),'wire_hex':wire.hex(),'crc':crc,'wire_count':len(wire)})
plan={
 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'inspection_order':'Before any RTL source or author/main testbench/oracle content inspection. Git bytes were downloaded but not inspected. Public candidate interface/lifecycle documents, handoff manifest and publication metadata were read.',
 'inputs':['wire_serializer_candidate.md','wire_parser_candidate.md','DEEPEYE-HUMAN-LOCK-20261014/revision1'],
 'oracle':'Own struct.pack little-endian frames + stdlib binascii.crc_hqx, cross-checked by own polynomial recurrence; no producer oracle imported.',
 'vectors':vectors,
 'serializer_controls':['length 0/1/32 exact byte output and CRC/endian','metadata and payload mutated after handshake must be captured','out_ready stalls preserve out_data/out_last/count','p_last mismatch produces sticky fault; fault_event remains at falling-edge reset/cancel; handshake gates immediate; clears at next rising edge','illegal length 33 emits fault code1 and zero count','cancel held counts one abort; reset priority and clears counters'],
 'parser_controls':['length 0/1/32 metadata and little-endian payload layout; zero tail','bad version1/bad length33/bad CRC produce codes1/2/3 and no output','partial receiving/error diagnostics retained across falling-edge reset/cancel, immediate handshake gating, synchronous clear','completed output stalls remain stable, no same-edge input credit','cancel partial or complete counts once; reset clears counters'],
 'configs':{'serializer':[32],'parser':[32]},
 'budget':'one config per primitive, directed few-thousand clocks total maximum; no producer suite rerun',
 'limits':['opaque syntax only','no A type/profile/source/session/BOOT/clock/TTL/replay/control acceptance','no synth/impl/timing/CDC_RDC/board/system/B04/G03/R03/all29']}
save_json(OUT/'oracle-freeze.json',plan)
files={}
for n,v in enumerate(vectors):
    p=LOCAL/('frame%d.hex'%v['length']);p.write_text('\n'.join(v['wire_hex'][i:i+2] for i in range(0,len(v['wire_hex']),2))+'\n',encoding='ascii');files[p.name]=sha(p.read_bytes())
files['oracle-freeze.json']=sha((OUT/'oracle-freeze.json').read_bytes())
files['freeze_oracle.py']=sha(__import__('pathlib').Path(__file__).read_bytes())
save_json(OUT/'oracle-freeze-hashes.json',files)
print(json.dumps({'frozen_before_RTL_inspection':True,'vectors':vectors,'hashes':files},indent=2))
