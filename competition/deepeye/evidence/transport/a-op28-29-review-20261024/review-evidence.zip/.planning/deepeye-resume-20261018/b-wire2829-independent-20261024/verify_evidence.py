import json,tarfile,pathlib,hashlib
from acquire import OUT,LOCAL,HEAD,SOURCE,sha,save_json
from fetch_blobs import get,SNAP,entries,src
crcpath='competition/deepeye/fpga/transport/deepeye_crc16_byte.sv'
crc=get(crcpath); assert crc['sha256']=='8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f'
ops=[('SERIALIZER',28,'6bba890baddd643e483789ce31f424b9889e4ec5fa44d78c27f37425560e38ad','efc554f023e1669a2d1239d4b08e83824452d17be5c5d8a607e2605b312e53a6',587),('PARSER',29,'3bb7f34ff2af44a03648ef6107b0b587cac28a77bc6b6131d5810ef86bc68612','4c9bea692eee47e43a044360b9183dc5b6b230676a7089336ae5fa81602d8a26',1238)]
report=[]
for typ,num,req,mhash,count in ops:
    op=f'B-DEEPEYE-WIRE-{typ}-20261024-{num}'
    p=SNAP/f'handoffs/b/{op}/manifest.json'; b=p.read_bytes();m=json.loads(b)
    assert sha(b)==mhash
    rh=sha(json.dumps(m['request'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
    assert rh==req==m['request_hash']
    assert m['request']['code_commit']==SOURCE
    artifacts=[]
    for path,desc in m['files'].items():
        data=(SNAP/path).read_bytes();assert sha(data)==desc['sha256'] and len(data)==desc['size']
        artifacts.append({'path':path,'sha256':sha(data),'bytes':len(data),'same_git_blob_at_source':src[path]['sha']==entries[path]['sha']})
    assert set(m['files'])==set(m['artifacts'])
    pub=SNAP/f'competition/deepeye/evidence/transport/wire-{typ.lower()}-20261024-{num}/publication'
    binding=json.loads((pub/'SOURCE_BINDING.json').read_bytes())
    for path,h in binding['sources'].items(): assert sha((SNAP/path).read_bytes())==h
    bundle=json.loads((pub/'BUNDLE_MANIFEST.json').read_bytes())
    assert sha((pub/bundle['archive']).read_bytes())==bundle['sha256']
    assert sha((pub/bundle['index']).read_bytes())==bundle['index_sha256']
    idx=json.loads((pub/bundle['index']).read_bytes())['files']
    extract=LOCAL/f'raw-{num}';extract.mkdir(exist_ok=True)
    members=[]
    with tarfile.open(pub/bundle['archive'],'r:gz') as tf:
        for member in tf.getmembers():
            assert member.isfile(),member.name
            rel=pathlib.PurePosixPath(member.name)
            assert not rel.is_absolute() and '..' not in rel.parts
            data=tf.extractfile(member).read()
            assert member.name in idx
            desc=idx[member.name]
            assert len(data)==desc['bytes'] and sha(data)==desc['sha256'],member.name
            target=extract.joinpath(*rel.parts);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
            members.append({'path':member.name,'bytes':len(data),'sha256':sha(data)})
    assert len(members)==len(idx)==count==bundle['members'] and set(idx)=={x['path'] for x in members}
    assert sum(x['bytes'] for x in members)==bundle['raw_bytes']
    save_json(OUT/f'raw-members-{num}.json',members)
    report.append({'operation_id':op,'request_hash':rh,'manifest_sha256':sha(b),'tested_commit':HEAD,'source_commit':SOURCE,'artifacts':artifacts,'archive_member_count':len(members),'archive_raw_bytes':sum(x['bytes'] for x in members),'source_binding_verified':True,'CRC_dependency':crc})
save_json(OUT/'evidence-verification.json',report)
print(json.dumps({'operations':[{k:r[k] for k in ('operation_id','request_hash','manifest_sha256','archive_member_count','archive_raw_bytes','source_binding_verified')} for r in report],'CRC_dependency_sha256':crc['sha256']},indent=2))
