`timescale 1ns/1ps
module tb_uart30;
 parameter integer CLOCK_HZ=23, BAUD=5, PRE_CYCLES=2, POST_CYCLES=3;
 reg clk=0;always #5 clk=~clk;
 reg rst=0,cancel=0,cfg_valid=0,p_valid=0,p_last=0;
 reg[7:0] cfg_type=0,cfg_epoch=0,p_data=0;reg[15:0] cfg_seq=0;
 reg[31:0] cfg_tick=0;reg[5:0] cfg_len=0;
 wire cfg_ready,p_ready,tx,de,busy,receiving,faulted,fault_event;wire[1:0]fault_code;
 wire[31:0]stat_admitted,stat_sent,stat_aborted;
 deepeye_wire_uart_tx #(.CLOCK_HZ(CLOCK_HZ),.BAUD(BAUD),.PRE_CYCLES(PRE_CYCLES),.POST_CYCLES(POST_CYCLES),.STAT_W(32)) dut(.*);
 integer fd,checks=0,cycles=0,frame_id=-99;
 initial begin fd=$fopen("pin-events.csv","w");$fwrite(fd,"kind,time_ps,frame_id,label,tx,de\n");end
 always @(posedge clk) begin
  cycles=cycles+1;
  if(fd) $fwrite(fd,"CLK,%0.0f,%0d,clk10ns,%b,%b\n",$realtime*1000,frame_id,tx,de);
 end
 always @(tx or de) if(fd) $fwrite(fd,"EDGE,%0.0f,%0d,pins,%b,%b\n",$realtime*1000,frame_id,tx,de);
 task mark(input string label_);
  $fwrite(fd,"MARK,%0.0f,%0d,%s,%b,%b\n",$realtime*1000,frame_id,label_,tx,de);
 endtask
 task ck(input bit ok,input string label_);
  checks=checks+1;if(!ok)$fatal(1,"UART30_FAIL %s cycle=%0d",label_,cycles);
 endtask
 task step;@(posedge clk);#1;endtask
 task reset_all;
  @(negedge clk);rst=1;cancel=1;cfg_valid=0;p_valid=0;#1;
  ck(!cfg_ready&&!p_ready,"reset handshake gates");step;
  ck(!busy&&!de&&tx&&!faulted&&stat_admitted==0&&stat_sent==0&&stat_aborted==0,"reset priority/all counters");
  @(negedge clk);rst=0;cancel=0;
 endtask
 task config_(input integer n);
  @(negedge clk);cfg_type=8'hb6;cfg_epoch=8'h49;cfg_seq=16'h92d7;cfg_tick=32'h8c16e503;cfg_len=n;cfg_valid=1;
  p_valid=1;p_data=8'hff;p_last=0;#1;
  ck(cfg_ready&&!p_ready,"config has no payload same-edge credit");step;
  ck(busy&&!cfg_ready,"reservation admitted");mark("CFG_ACCEPTED");
  @(negedge clk);cfg_valid=0;p_valid=0;cfg_type=0;cfg_epoch=0;cfg_seq=0;cfg_tick=0;cfg_len=33;
 endtask
 task payload_(input integer i,input bit last_);
  @(negedge clk);p_valid=1;p_data=(8'h53+53*i)&255;p_last=last_;
  #1;ck(p_ready&&receiving&&!de&&tx,"payload collection before UART launch");step;
  @(negedge clk);p_valid=0;p_last=0;p_data=0;
 endtask
 task full_frame(input integer n);
  integer i,j,old_admit,old_sent,timeout_;
  @(negedge clk);frame_id=n;mark("BEGIN");old_admit=stat_admitted;old_sent=stat_sent;
  config_(n);
  for(i=0;i<n;i=i+1) begin
   for(j=0;j<1+(i%3);j=j+1)begin step;ck(!de&&tx&&busy,"payload silence cannot launch partial frame");end
   payload_(i,i==n-1);
  end
  mark("PAYLOAD_SEALED");cfg_valid=1;
  timeout_=0;
  while(!de)begin step;ck(busy&&!cfg_ready&&!faulted,"pending full buffer reserved");timeout_=timeout_+1;ck(timeout_<100,"DE bounded launch");end
  ck(!p_ready,"payload stops after seal");mark("DE_OBSERVED");
  timeout_=0;
  while(de)begin
   ck(busy&&!cfg_ready&&!p_ready&&!faulted&&stat_admitted==old_admit+1&&stat_sent==old_sent,"UART drain reservation/backpressure");
   step;timeout_=timeout_+1;ck(timeout_<4000,"bounded UART drain");
  end
  ck(busy&&!cfg_ready&&stat_sent==old_sent,"top observes DE release next edge");mark("DE_FALL_OBSERVED");
  step;ck(!busy&&cfg_ready&&stat_sent==old_sent+1&&stat_admitted==old_admit+1,"drain retirement no cfg same-edge credit");
  @(negedge clk);cfg_valid=0;mark("END");
  $display("UART30_CASE frame%0d PASS",n);
 endtask
 task partial_cancel;
  integer a;
  @(negedge clk);frame_id=-1;mark("PARTIAL_BEGIN");config_(32);payload_(0,0);payload_(1,0);a=stat_aborted;
  @(negedge clk);cancel=1;#1;ck(!p_ready&&!cfg_ready&&busy&&!de&&tx,"partial cancel gating before edge");step;
  ck(!busy&&!de&&tx&&stat_aborted==a+1,"partial cancel release");step;step;ck(stat_aborted==a+1,"held partial cancel once");
  @(negedge clk);cancel=0;mark("PARTIAL_END");$display("UART30_CASE partial_cancel PASS");
 endtask
 task faulty(input bit bad_len);
  @(negedge clk);frame_id=bad_len?-2:-3;mark("FAULT_BEGIN");config_(bad_len?33:1);
  if(!bad_len)payload_(0,0);
  ck(faulted&&busy&&!de&&tx&&fault_code==(bad_len?1:2),"sticky fault no partial UART");
  repeat(5)begin step;ck(faulted&&!de&&tx&&!cfg_ready&&!p_ready,"poisoned reservation stays blocked");end
  @(negedge clk);cancel=1;step;ck(!busy&&!de&&tx&&!faulted,"fault recovery cancel");
  @(negedge clk);cancel=0;mark("FAULT_END");$display("UART30_CASE fault bad_len=%0d PASS",bad_len);
 endtask
 task uart_abort(input bit use_reset);
  integer timeout_,a;reg old_tx,old_de;
  @(negedge clk);frame_id=use_reset?-5:-4;mark("ABORT_BEGIN");config_(0);timeout_=0;
  while(!(de&&!tx))begin step;timeout_=timeout_+1;ck(timeout_<100,"abort start bounded");end
  step;@(negedge clk);a=stat_aborted;old_tx=tx;old_de=de;rst=use_reset;cancel=!use_reset;mark("ABORT_REQUEST");
  #1;ck(tx===old_tx&&de===old_de&&!cfg_ready&&!p_ready,"UART abort registered outputs before edge");step;
  ck(tx&&!de&&!busy,"UART abort synchronous pins flush");mark("ABORT_COMMITTED");
  if(use_reset)ck(stat_admitted==0&&stat_sent==0&&stat_aborted==0,"UART reset counters");
  else begin ck(stat_aborted==a+1,"UART cancel count");step;step;ck(stat_aborted==a+1,"held UART cancel once");end
  @(negedge clk);rst=0;cancel=0;mark("ABORT_END");$display("UART30_CASE uart_abort reset=%0d PASS",use_reset);
 endtask
 initial begin
  reset_all;full_frame(0);full_frame(1);full_frame(32);
  ck(stat_admitted==3&&stat_sent==3&&stat_aborted==0,"three complete reservations");
  partial_cancel;faulty(1);faulty(0);uart_abort(0);uart_abort(1);reset_all;
  repeat(64)begin step;ck(cfg_ready&&!busy&&!de&&tx,"idle no spontaneous UART");end
  mark("FINISH");$fclose(fd);fd=0;
  $display("UART30_PASS clock_hz=%0d baud=%0d pre=%0d post=%0d checks=%0d cycles=%0d",CLOCK_HZ,BAUD,PRE_CYCLES,POST_CYCLES,checks,cycles);$finish;
 end
 initial begin #200000;$fatal(1,"UART30_FAIL timeout");end
endmodule
