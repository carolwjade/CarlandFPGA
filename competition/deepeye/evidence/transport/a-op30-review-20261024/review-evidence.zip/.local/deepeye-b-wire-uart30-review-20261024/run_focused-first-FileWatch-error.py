import subprocess,ctypes,pathlib,json,shutil,re,datetime,os
from acquire import OUT,LOCAL,SNAP,sha,save_json
BIN=pathlib.Path('C:/modeltech64_2020.4/win64')
attempt=LOCAL/'focused-01';attempt.mkdir(exist_ok=False)
receipts=[]
env=os.environ.copy();tmp=attempt/'temp';tmp.mkdir()
for key in ['TEMP','TMP','TMPDIR','MODELSIM_TMPDIR','XDG_CACHE_HOME','PYTHONPYCACHEPREFIX']:env[key]=str(tmp)
def run(argv,name,cwd=attempt):
 r=subprocess.run([str(a) for a in argv],cwd=str(cwd),env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 p=pathlib.Path(cwd);(p/(name+'.stdout.bin')).write_bytes(r.stdout);(p/(name+'.stderr.bin')).write_bytes(r.stderr)
 row={'argv':[str(a) for a in argv],'cwd':str(cwd),'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};receipts.append(row);save_json(p/(name+'.receipt.json'),row)
 return r
def no_diagnostic(data):return not re.search(rb'(?im)^[#\s]*(?:\*\*\s*)?(?:Error|Warning|Fatal)\s*:',data)
before=run(['subst'],'subst-before');mask=ctypes.windll.kernel32.GetLogicalDrives()
drive=next(x for x in ['R','T','U','V','W','X'] if not mask&(1<<(ord(x)-65)))+':';mapped=False
configs=json.loads((OUT/'oracle-freeze.json').read_bytes())['configs'];results=[]
try:
 r=run(['subst',drive,str(LOCAL)],'subst-create');assert r.returncode==0;mapped=True
 active=run(['subst'],'subst-active');assert drive.encode() in active.stdout
 rtl=pathlib.Path(drive+'/snapshot/competition/deepeye/fpga/transport')
 inputs=[rtl/f for f in ['deepeye_crc16_byte.sv','deepeye_wire_serializer.sv','deepeye_uart_tx.sv','deepeye_uart_frame_tx.sv','deepeye_wire_uart_tx.sv']]+[pathlib.Path(drive+'/tb_uart30.sv')]
 save_json(attempt/'inputs-freeze.json',{'files':[{'path':str(p),'sha256':sha(p.read_bytes())} for p in inputs],'oracle_freeze_sha256':sha((OUT/'oracle-freeze.json').read_bytes()),'no_producer_TB_or_oracle_imported':True,'configs':configs,'environment_overrides':{k:env[k] for k in ['TEMP','TMP','TMPDIR','MODELSIM_TMPDIR','XDG_CACHE_HOME','PYTHONPYCACHEPREFIX']}})
 for name in ['vlog','vsim']:
  r=run([BIN/(name+'.exe'),'-version'],name+'-version');assert r.returncode==0
 for cfg in configs:
  local=attempt/cfg['id'];local.mkdir();sim=pathlib.Path(drive+'/focused-01/'+cfg['id'])
  (local/'focused.do').write_text('onerror {quit -code 2 -f}\nrun -all\nquit -code 0 -f\n',encoding='ascii')
  r=run([BIN/'vlib.exe','work'],'vlib',sim);assert r.returncode==0
  r=run([BIN/'vlog.exe','-sv',*inputs],'vlog',sim);assert r.returncode==0 and no_diagnostic(r.stdout+r.stderr)
  overrides=[f'-g{k}={cfg[k]}' for k in ['CLOCK_HZ','BAUD','PRE_CYCLES','POST_CYCLES']]
  r=run([BIN/'vsim.exe','-c','-onfinish','stop',*overrides,'work.tb_uart30','-do','focused.do'],'vsim',sim)
  data=r.stdout+r.stderr;passes=re.findall(rb'UART30_PASS clock_hz=(\d+) baud=(\d+) pre=(\d+) post=(\d+) checks=(\d+) cycles=(\d+)',data)
  passed=r.returncode==0 and no_diagnostic(data) and len(passes)==1 and b'UART30_FAIL' not in data and re.findall(rb'Errors:\s*(\d+),\s*Warnings:\s*(\d+)',data)==[(b'0',b'0')]
  row={'config':cfg,'passed':passed,'exit':r.returncode,'checks':int(passes[0][4]) if len(passes)==1 else None,'cycles':int(passes[0][5]) if len(passes)==1 else None,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'pin_events_sha256':sha((local/'pin-events.csv').read_bytes())};results.append(row)
  print(data.decode(errors='replace'))
  if not passed:break
 save_json(OUT/'focused-result.json',{'attempt':'focused-01','results':results,'passed':len(results)==2 and all(r['passed'] for r in results),'scope':'two small configs, own public ports and actual pin event logger; offline edge check separate'})
finally:
 if mapped:
  remove=run(['subst',drive,'/d'],'subst-remove');after=run(['subst'],'subst-after')
  clean={'drive':drive,'target':str(LOCAL),'remove_exit':remove.returncode,'mapping_absent_after':drive.encode() not in after.stdout,'logical_drive_absent_after':not(ctypes.windll.kernel32.GetLogicalDrives()&(1<<(ord(drive[0])-65)))}
  save_json(OUT/'mapping-cleanup.json',clean);assert remove.returncode==0 and clean['mapping_absent_after']
 save_json(OUT/'focused-command-index.json',receipts)
