# B UART30 限定独立复核

新增 same-clock opaque packet→UART 数字仿真控制通过，未发现新 DUT 断言或输出引脚时序失败。正式接受与同 PR 反馈由 A Gen3/root 决定。

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，work `A-B-WIRE-UART30-INDEPENDENT-20261024-v1`；新 job `child-469d5b3ba3214beb817cc0f89ea9e39a` 的 canonical `/root/b_wire2829_review` 验证 execution_allowed=true。Gen3 主 `01a16988-bdcb-70e1-ae10-1304b5cf7875`，H01–H15 canonical requirements 实算保持 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`。A/root 唯一实板操作者；前 op28/29 归档没有修改。

## 精确输入

PR30 https://github.com/carolwjade/CarlandFPGA/pull/30 ，固定 tested head `e9b447802dea14c077b2564102e560741ce5e2df`，直接 parent/source `a1428cfc82a8c789356389184bbf37aed3b261f4`。取得23个选定 Git blobs（16项operation材料、4依赖、3额外公开说明文档），逐一核 Git blob SHA1/长度/SHA256；未声称 whole-top checkout。

Operation `B-DEEPEYE-WIRE-UART-TX-20261024-30`；request `19cad739eaf13167500600b4b08b38603c3d371c2dd49beb0c5b0293286f78d6`；manifest `984bebbff3429a91c4552dc2e5d282c6fde58359f5b0677a46f66a23f8e7b41e`。canonical artifacts、source binding、4只读依赖与全部 **1442** 个承诺 raw 成员（235,478,446 B）字节一致。原tar SHA256 `44e7588f84020788dfd4eca5d8efafe7fec138e1b4a5786996645ff083d5dc88`；RAW_INDEX SHA256 `d8682a116ceb47b2e8a3eead26a96bfdc92b15599ff26ec1cd677719bca630f6`。

## 独立向量及实际引脚观测

先读 composition/frame/UART/serializer 公开语法与时序文档，冻结 fresh struct.pack+binascii 0/1/32-byte packet 和另写CRC递推，再首次阅读 UART30 wrapper。**serializer dependency 已在上一 op28/29 任务阅读过**；不声称整个组合RTL盲测。作者/main TB、向量发生器和oracle未导入或执行。详见 oracle-freeze.json 与 oracle-independence-disclosure.json。

ModelSim SE-64 **2020.4**，单一10 ns刺激时钟 `clk10ns`，两种小配置：

| CLOCK_HZ/BAUD | PRE/POST | qualified clocks | 断言checks |
|---|---|---:|---:|
| 23/5 | 2/3 | 3954 | 7648 |
| 20/5 | 0/0 | 3485 | 6714 |

合格 focused-02 共 **7439 clocks / 14362 checks**；两进程 exit0、Errors0/Warnings0。外部公开端口检查完整0/1/32包、捕获后metadata变化、payload间隙与seal前无发送、reservation背压、drain/DErelease之后一沿观察及无同沿新cfg credit、部分payload/错length/错last无串口启动、UART传输中cancel/reset同步清除、held cancel一次计数及reset优先级。

`always @(tx or de)` 原生事件回调记录实际输出跳变的 `$realtime`→ps，单独 `posedge clk` observer 记录实际刺激时钟时间。CSV由仿真器直接写入，非counter推测。独立Python checker核对 **856次实际TX/DE跳变**，六个完整包串行解码精确等于冻结packet bytes（含端序与CRC）；partial/fault没有引脚启动，4次中断清除发生在请求后的下一实际clock。

时间oracle明确以**观测到的DE上升**为锚，预测首start=`d+(PRE+1)T`，各位边界=`ceil(k*CLOCK_HZ/BAUD)`，字节间`B(10)+2`，末DE释放=`lastA+B(10)+POST+1`。没有用观测TXstart重新对齐，也不声称完整cfg→DE绝对延迟。例：23/5的32-byte payload包，实测DE上升15,925,000 ps，首TX下降15,955,000 ps，DE下降38,055,000 ps，均与独立预测相符。**这些是仿真时间，不是物理时钟、引脚或串口测量。**

21项自有保存日志/事件qualification全部符合预期，包括一clock提前/延后、缺失/离沿跳变等合成反例。它们不算新DUT运行。

## 保留的首次失败

focused-01 的fractional invocation有 Tcl `FileWatch(fileName)` error，缺PASS/tally；即使CSV到FINISH也判失败。完整raw pipes/receipt/CSV保留。仅将task-local temp/cache改为已核未占用的ASCII映射内，TB/RTL不变，作一次必要复验后再运行计划integer配置。所有新实际运行共11,393 clocks，未扩成原大组。两次映射均finally移除并读回。该调整后clean，不将其泛化为完整FileWatch根因证明。

## 生产者保存证据与发布对账

未重跑旧5,627,750cycles/135,066,000checks、4configs/11guards/4mutants或author16cases。重核保存19个run的RESULT、所有input和原stdout/stderr；223个main日志probe保存accepted与expected一致，样本hash存在。原7个runner警告/marker-order缺陷、修复后62项qualification（35positive/27guard）、作者vlib-version exit1例外和其它10个exit0、原relative-path/CRLF/main classifier失误及修正均保留。

123引用全部能解析：114原归档路径、8精确canonical Git blobs、1 private scope同hash归档副本。没有缺失引用或pyc引用；不因此把hash验证当作全部原时执行语义证明。历史preinspection顺序/旧接受结论仍属生产者记录。

对原PATCH仅做只读对账：本轮GET确认指定head及其source parent。旧“首次PATCH成功、立即GET陈旧、稍后GET对上、仅未尝试metadata PATCH执行一次”的完整变更次数和时序仍按生产者回述记录；选定canonical归档没有其原mutation receipts，本轮不声称独立证明历史PATCH次数，也未PATCH/POST/重放。原回执effects_allowed=false，generation2文字不覆盖Gen3 transfer。RX31失败/repair和B06均未触碰。

## 交接范围

235 MB原raw继续留独占.local，没有复制入产品或另打重复包。完整EVIDENCE_MANIFEST列所有留存字节；ROOT_ARCHIVE_SELECTION.json提供较小新控件/CSV/命令/源pins/旧审计与原upstream tar固定source/hash引用清单，明确该选择不内嵌235 MB全量。

本项无产品编辑、stage/commit/reset、board/串口/UI/服务/credentials动作、外部消息或再次派工。A ABI/type/profile/source/session/BOOT/TTL/replay/motion、physicalclock、CDC/synth/impl/timing/build/board/system未接受；G03/R03/all29/B04仍not_run。H01–H15不变。
