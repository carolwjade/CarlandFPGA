import json,pathlib,collections
from acquire import OUT,LOCAL,SNAP,ROOT,HEAD,SOURCE,sha,save_json
raw=LOCAL/'raw';members=json.loads((OUT/'raw-members.json').read_bytes());byhash={}
for row in members:byhash.setdefault(row['sha256'],[]).append(row['path'])
snapshot={sha(p.read_bytes()):p.relative_to(SNAP).as_posix() for p in SNAP.rglob('*') if p.is_file()}
prefix='competition/deepeye/evidence/transport/wire-uart-tx-20261024-30/'
def resolve(ref,h):
 norm=ref.replace('\\','/');pos=norm.find('competition/')
 if pos>=0:
  norm=norm[pos:]
  if norm.startswith(prefix):
   p=raw/norm[len(prefix):]
   if p.exists():assert sha(p.read_bytes())==h;return {'mode':'archive path mapping','local':str(p.relative_to(raw))}
  p=SNAP/norm
  if p.exists():assert sha(p.read_bytes())==h;return {'mode':'canonical Git blob','local':norm}
 if h in byhash:return {'mode':'same-hash archive content identity only; original B absolute path not accessed','local':byhash[h]}
 if h in snapshot:return {'mode':'same-hash canonical Git blob identity','local':snapshot[h]}
 return {'mode':'missing','local':None}
ap=raw/'main/final-audit-01/RESULT.json';audit=json.loads(ap.read_bytes())
refs=[]
for ref,h in audit['author_reference_hashes'].items():refs.append({'reference':ref,'sha256':h,**resolve(ref,h)})
missing=[r for r in refs if r['mode']=='missing']
sources=[]
for key,desc in audit['final_sources'].items():
 match=resolve(desc['path'],desc['sha256']);assert match['mode']!='missing';sources.append({'role':key,'sha256':desc['sha256'],'bytes':desc['bytes'],**match})
runs=[]
for r in audit['main_runs']:
 p=raw/r['path'];assert sha(p.read_bytes())==r['sha256'];res=json.loads(p.read_bytes());pipecount=0;inputcount=0
 for cmd in res['commands']:
  for pipe in ['stdout','stderr']:
   assert sha((p.parent/(cmd['name']+'.'+pipe+'.bin')).read_bytes())==cmd[pipe+'_sha256'];pipecount+=1
 for name,desc in res['inputs'].items():
  h=desc['sha256'] if isinstance(desc,dict) else desc
  assert sha((p.parent/name).read_bytes())==h;inputcount+=1
 log=(p.parent/'vsim.stdout.bin').read_bytes()
 for counter in res['numeric_counterexamples']:assert counter.encode() in log
 runs.append({'path':r['path'],'result_sha256':sha(p.read_bytes()),'mode':res['mode'],'producer_classification_accepted':res['accepted'],'numeric_counterexamples':res['numeric_counterexamples'],'saved_command_pipes_verified':pipecount,'saved_inputs_verified':inputcount,'parameters':res['parameters'],'DUT_binding':res['inputs']['dut.sv']})
assert len(runs)==19
probes=audit['runner_main_probes'];assert len(probes)==223
for row in probes:
 assert row['accepted']==row['expected'];assert row['sha256'] in byhash
rp=raw/'author/RUNNER_REPAIR1_RESULT.json';repair=json.loads(rp.read_bytes())
assert repair['red_baseline']['defect_count']==7 and repair['red_baseline']['all_seven_classes_accepted_by_original']
for row in repair['red_baseline']['probes']:
 assert row['defect_reproduced'] and row['observed']['accepted'] and resolve(row['path'],row['sha256'])['mode']!='missing'
qp=raw/'author/runner-repair1-qualification/qualification-01/QUALIFICATION_RESULT.json';qual=json.loads(qp.read_bytes())
for row in qual['checks']:
 assert row['passed'] and row['expected_acceptance']==row['observed']['accepted']
 assert resolve(row['path'],row['sha256'])['mode']!='missing'
classifier=json.loads((raw/'main/classifier-order-01/RESULT.json').read_bytes())
assert classifier['accepted'] and len(classifier['saved_runs_reclassified'])==19 and len(classifier['probes'])==7
for row in classifier['probes']:assert row['sha256'] in byhash
preserved={'main_first_log_path_failure':json.loads((raw/'main/runner-negative-01/FAILURE.json').read_bytes()),'main_CRLF_correction_history':json.loads((raw/'main/runner-order-negative-03/RESULT.json').read_bytes())['history'],'author_original_attempts':json.loads((raw/'author/RESULT.json').read_bytes())['attempt_history'],'repair_harness_failure':repair['preserved_originals']['path_harness_failure'],'repair_no_replay_note':'All old producer simulation and qualification results inspected as saved bytes only; no producer code imported or executed.'}
save_json(OUT/'history-review.json',{'producer_final_audit_sha256':sha(ap.read_bytes()),'reference_count':len(refs),'references':refs,'missing_references':missing,'reference_resolution_modes':dict(collections.Counter(x['mode'] for x in refs)),'pyc_references':[x for x in refs if '.pyc' in x['reference']],'final_sources':sources,'saved_main_runs':runs,'producer_reported_counts':{k:audit[k] for k in ['main_cycles','main_port_checks','main_guards','compiled_behavioral_mutants','final_author_cases','final_author_checks','author_unique_processes']},'saved_main_runner_probes':{'count':len(probes),'all_match_expected':True,'all_sample_hashes_in_archive':True},'saved_author_runner_repair':{'result_sha256':sha(rp.read_bytes()),'original_red_count':7,'red_classes':[p['name'] for p in repair['red_baseline']['probes']],'qualification_result_sha256':sha(qp.read_bytes()),'qualification_summary':qual['summary'],'actual_fresh_CLI':repair['fresh_cli'],'original_runner':repair['original_runner'],'loader_evidence':'qualify_strict_protocol.py49-53 and reproduce_original_reds.py35-39 use importlib source loaders; both set sys.dont_write_bytecode=True before main. File identities and saved process records do not by themselves prove all historical execution semantics.'},'saved_main_classifier_repair':classifier,'preserved_failures':preserved,'author_version_probe_exit_exception':audit['author_commands'][0],'new_vendor_runs_in_history_review':0})
receiptpath=ROOT/'.planning/deepeye-resume-20261018/gen3-live-integration-20261024/inbox-review/desk-0bf6b4049a10b7e3cdca9787290b5f8d100b80a3fec2b54de36eebcf2b190281/claim-cli.stdout.txt'
receipt=json.loads(receiptpath.read_bytes());pr=json.loads((LOCAL/'metadata/pr30.json').read_bytes())
hc=json.loads((LOCAL/'metadata/head-commit.json').read_bytes())
save_json(OUT/'publication-readonly-reconciliation.json',{'source_receipt_path':str(receiptpath.relative_to(ROOT)),'source_receipt_sha256':sha(receiptpath.read_bytes()),'envelope_sha256_recorded':receipt['envelope_sha256'],'effects_allowed':receipt['effects_allowed'],'reference_only':True,'historical_B_claim':'Ref PATCH succeeded once; immediate PR head read was stale, later read-only GET reconciled, only previously unattempted metadata PATCH executed once; no write replay.','own_GET_current_PR_head':pr['head']['sha'],'tested_head_fixed':HEAD,'tested_source_fixed':SOURCE,'head_direct_parent_shas':[p['sha'] for p in hc['parents']],'own_publication_facts_verified':'Read-only GET confirms specified head and selected byte identities. It does not independently prove the exact historical PATCH invocation count or chronology. Original mutation receipts are not in this selected canonical archive; no mutation requested or replayed by this agent.','all_own_remote_calls':'gh api GET only; no PATCH/POST/ref update/PR comment','RX31_and_B06':'out of scope; not inspected or replayed'})
print(json.dumps({'saved_main_runs':len(runs),'saved_probes':len(probes),'references':len(refs),'missing_references':missing,'reference_modes':dict(collections.Counter(x['mode'] for x in refs)),'author_saved_repair_qualification':qual['summary'],'publication_readonly_head':pr['head']['sha']},indent=2))
