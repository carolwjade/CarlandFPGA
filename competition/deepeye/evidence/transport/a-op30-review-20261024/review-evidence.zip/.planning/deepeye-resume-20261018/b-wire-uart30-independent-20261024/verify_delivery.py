import json,pathlib,hashlib,datetime
from acquire import OUT,LOCAL,ROOT,sha,save_json
from check_events import parse,check,classify
result=json.loads((OUT/'result.json').read_bytes());source=json.loads((OUT/'SOURCE_HASH_MANIFEST.json').read_bytes());plan=json.loads((OUT/'oracle-freeze.json').read_bytes())
assert result['tested_commit']=='e9b447802dea14c077b2564102e560741ce5e2df' and result['source_commit']=='a1428cfc82a8c789356389184bbf37aed3b261f4'
for row in source['files']:
 b=(LOCAL/'snapshot'/row['path']).read_bytes()
 assert len(b)==row['bytes'] and sha(b)==row['sha256']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob']
assert sha((LOCAL/'tb_uart30.sv').read_bytes())==source['own_TB']['sha256']
freeze=json.loads((OUT/'oracle-freeze-hashes.json').read_bytes());assert sha((OUT/'oracle-freeze.json').read_bytes())==freeze['oracle-freeze.json']
for n in [0,1,32]:assert sha((LOCAL/f'frame{n}.hex').read_bytes())==freeze[f'frame{n}.hex']
clocks=0;transitions=0
for cfg in plan['configs']:
 p=LOCAL/'focused-02'/cfg['id'];data=(p/'vsim.stdout.bin').read_bytes()+(p/'vsim.stderr.bin').read_bytes()
 assert classify(data,cfg);r=check(parse(p/'pin-events.csv'),cfg);clocks+=r['observed_clock_edges'];transitions+=r['pin_edges_checked']
first=parse(LOCAL/'focused-01/fractional/pin-events.csv');assert sum(r['kind']=='CLK' for r in first)==3954
firstdata=(LOCAL/'focused-01/fractional/vsim.stdout.bin').read_bytes()+(LOCAL/'focused-01/fractional/vsim.stderr.bin').read_bytes();assert not classify(firstdata,plan['configs'][0])
assert clocks==7439 and transitions==856
for p in [OUT/'mapping-cleanup-01.json',OUT/'mapping-cleanup-focused-02.json']:
 o=json.loads(p.read_bytes());assert o['mapping_absent_after'] and o['logical_drive_absent_after']
history=json.loads((OUT/'history-review.json').read_bytes());assert len(history['references'])==123 and not history['missing_references']
selection=json.loads((OUT/'ROOT_ARCHIVE_SELECTION.json').read_bytes())
for row in selection['files']:
 b=(ROOT/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
verified={'status':'fresh_verification_passed','observed_clocks_qualified':clocks,'actual_pin_transitions_checked':transitions,'total_new_observed_clocks_including_failed_first':clocks+3954,'selected_Git_blobs':len(source['files']),'upstream_raw_members':1442,'producer_references':123,'report_sha256':sha((OUT/'report.md').read_bytes()),'result_sha256':sha((OUT/'result.json').read_bytes())}
save_json(OUT/'delivery-verification.json',verified);print(json.dumps(verified,indent=2))
