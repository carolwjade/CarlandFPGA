import binascii,struct,datetime,json
from acquire import OUT,LOCAL,SNAP,sha,save_json
def own_crc(data):
 r=65535
 for b in data:
  r^=b<<8
  for _ in range(8):r=((r<<1)^0x1021 if r&0x8000 else r<<1)&65535
 return r
assert own_crc(b'123456789')==binascii.crc_hqx(b'123456789',65535)==0x29b1
frames=[]
for n in [0,1,32]:
 payload=bytes((0x53+53*i)&255 for i in range(n))
 body=struct.pack('<BBBBHI',3,0xb6,n,0x49,0x92d7,0x8c16e503)+payload
 crc=binascii.crc_hqx(body,65535);assert crc==own_crc(body)
 data=b'\xa5\x5a'+body+struct.pack('<H',crc)
 p=LOCAL/f'frame{n}.hex';p.write_text('\n'.join(f'{b:02x}' for b in data)+'\n',encoding='ascii')
 frames.append({'payload_len':n,'wire_hex':data.hex(),'crc':crc,'wire_bytes':len(data),'file_sha256':sha(p.read_bytes())})
inputs=[]
for name in ['wire_uart_tx_candidate.md','uart_frame_tx_candidate.md','uart_tx_candidate.md','wire_serializer_candidate.md']:
 p=SNAP/'competition/deepeye/fpga/transport'/name;inputs.append({'path':p.relative_to(SNAP).as_posix(),'sha256':sha(p.read_bytes())})
plan={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inspection_order':'Read only public UART composition/serializer/frame/UART candidate documents and publication metadata. No UART30 RTL, author/main TB or author/main oracle has yet been inspected/imported.','inputs':inputs,'frames':frames,'oracle':'Own struct.pack+binascii packet bytes plus separately written polynomial crosscheck. Own 8N1 LSB-first edge schedule using ceil(k*CLOCK_HZ/BAUD), reset phase for each byte. No author code imports.','configs':[{'id':'fractional','CLOCK_HZ':23,'BAUD':5,'PRE_CYCLES':2,'POST_CYCLES':3},{'id':'integer','CLOCK_HZ':20,'BAUD':5,'PRE_CYCLES':0,'POST_CYCLES':0}],'stimulus_clock':{'id':'clk10ns','period_ps':10000,'first_rising_ps':5000,'timeunit':'1ns','timeprecision':'1ps'},'observation':'always @(tx or de) emits actual simulation $realtime-derived picoseconds and both current output levels; a separate posedge clock observer logs stimulus edge times. Markers name full frame observation windows. Neither event timestamps nor pin transitions are inferred from counters.','time_oracle_anchor':'Actual observed DE rising time d is an explicit output anchor. Predict first TX start at d+(PRE_CYCLES+1)*period, all bit transitions from frozen expected bytes and B(k), per-byte A_next=A+B(10)+2, DE fall at final_A+B(10)+(POST_CYCLES+1)*period. TX start edges are not used to realign expected waveform. This supplements producer absolute-clock controls; it does not claim exact external-config-to-DE latency.','controls':['length0/1/32 exact serialized bytes via observed TX transitions, endian and CRC','DE cannot assert before full payload seals; payload gaps and metadata mutation after admission','busy blocks held config and payload while UART drains; no same-edge cfg retirement credit; top release one edge after DE fall','cancel partial payload: no DE/TX launch; held cancel once','reset/cancel mid UART data: outputs remain registered before edge, flush synchronously; no extra frame','illegal length33/p_last mismatch sticky fault, no partial UART launch; reset priority'], 'budget':'two small configs, total below20000 clocks; no producer suite rerun','scope':'same-clock opaque digital simulation only; no physical clock/UART measurement, ABI/control/BOOT/TTL/motion/CDC/synth/impl/build/board/system/formal cards'}
save_json(OUT/'oracle-freeze.json',plan)
save_json(OUT/'oracle-freeze-hashes.json',{'oracle-freeze.json':sha((OUT/'oracle-freeze.json').read_bytes()),'freeze_oracle.py':sha(__import__('pathlib').Path(__file__).read_bytes()),**{f'frame{f["payload_len"]}.hex':f['file_sha256'] for f in frames}})
print(json.dumps({'frozen_before_RTL':True,'frames':frames,'oracle_freeze_sha256':sha((OUT/'oracle-freeze.json').read_bytes())},indent=2))
