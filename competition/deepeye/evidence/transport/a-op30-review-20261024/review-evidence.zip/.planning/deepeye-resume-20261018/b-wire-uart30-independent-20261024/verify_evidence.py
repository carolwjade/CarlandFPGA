import json,pathlib,concurrent.futures,tarfile,hashlib
from acquire import OUT,LOCAL,SNAP,HEAD,SOURCE,OP,entries,blob,sha,save_json
m_path=f'handoffs/b/{OP}/manifest.json';m=json.loads((SNAP/m_path).read_bytes())
assert sha((SNAP/m_path).read_bytes())=='984bebbff3429a91c4552dc2e5d282c6fde58359f5b0677a46f66a23f8e7b41e'
rh=sha(json.dumps(m['request'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8'))
assert rh==m['request_hash']=='19cad739eaf13167500600b4b08b38603c3d371c2dd49beb0c5b0293286f78d6'
assert m['request']['code_commit']==SOURCE
pub=SNAP/'competition/deepeye/evidence/transport/wire-uart-tx-20261024-30/publication'
binding=json.loads((pub/'SOURCE_BINDING.json').read_bytes())
deps=['competition/deepeye/fpga/transport/'+pathlib.PureWindowsPath(d['path']).name for d in binding['dependencies'].values()]
paths=sorted(set(json.loads((OUT/'acquisition-index.json').read_bytes())['paths']+m['artifacts']+deps))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(blob,paths))
for path,desc in m['files'].items():
 b=(SNAP/path).read_bytes();assert sha(b)==desc['sha256'] and len(b)==desc['size']
assert set(m['files'])==set(m['artifacts'])
for path,h in binding['sources'].items():assert sha((SNAP/path).read_bytes())==h
for dep,d in binding['dependencies'].items():
 path='competition/deepeye/fpga/transport/'+pathlib.PureWindowsPath(d['path']).name
 b=(SNAP/path).read_bytes();assert sha(b)==d['sha256']==d['expected_sha256'] and len(b)==d['bytes']
bundle=json.loads((pub/'BUNDLE_MANIFEST.json').read_bytes())
assert sha((pub/bundle['archive']).read_bytes())==bundle['sha256']
assert sha((pub/bundle['index']).read_bytes())==bundle['index_sha256']
idx=json.loads((pub/bundle['index']).read_bytes())['files'];raw=LOCAL/'raw';raw.mkdir(exist_ok=True)
members=[]
with tarfile.open(pub/bundle['archive'],'r:gz') as tf:
 for member in tf.getmembers():
  assert member.isfile();parts=pathlib.PurePosixPath(member.name.replace('\\','/')).parts
  assert '..' not in parts and not member.name.startswith(('/', '\\')) and ':' not in member.name
  p=raw.joinpath(*parts);p.parent.mkdir(parents=True,exist_ok=True)
  h=hashlib.sha256();size=0
  with tf.extractfile(member) as fi,p.open('wb') as fo:
   while True:
    chunk=fi.read(1024*1024)
    if not chunk:break
    h.update(chunk);size+=len(chunk);fo.write(chunk)
  desc=idx[member.name];assert size==desc['bytes'] and h.hexdigest()==desc['sha256'],member.name
  members.append({'path':member.name,'bytes':size,'sha256':h.hexdigest()})
assert len(members)==len(idx)==bundle['members']==1442
assert set(idx)=={m['path'] for m in members}
assert sum(m['bytes'] for m in members)==bundle['raw_bytes']
save_json(OUT/'raw-members.json',members)
save_json(OUT/'Git-blob-verification.json',{'tested_commit':HEAD,'source_commit':SOURCE,'selected_blob_count':len(rows),'whole_top_checkout':False,'files':rows})
save_json(OUT/'evidence-verification.json',{'operation_id':OP,'request_hash':rh,'manifest_sha256':sha((SNAP/m_path).read_bytes()),'tested_commit':HEAD,'source_commit':SOURCE,'source_binding_verified':True,'dependencies_verified':binding['dependencies'],'canonical_artifacts_verified':m['artifacts'],'raw_members':len(members),'raw_bytes':sum(m['bytes'] for m in members),'archive_sha256':bundle['sha256'],'RAW_INDEX_sha256':bundle['index_sha256']})
print(json.dumps({'selected_Git_blobs':len(rows),'manifest_sha256':sha((SNAP/m_path).read_bytes()),'request_hash':rh,'raw_members':len(members),'raw_bytes':sum(m['bytes'] for m in members)},indent=2))
