import csv,json,pathlib,bisect,copy,re,traceback
from acquire import OUT,LOCAL,sha,save_json
PLAN=json.loads((OUT/'oracle-freeze.json').read_bytes());PERIOD=PLAN['stimulus_clock']['period_ps']
def parse(path):
 rows=list(csv.DictReader(path.open(encoding='ascii',newline='')))
 for row in rows:row['time_ps']=int(row['time_ps']);row['frame_id']=int(row['frame_id'])
 return rows
def ceildiv(a,b):return (a+b-1)//b
def check(rows,cfg):
 clocks=[r['time_ps'] for r in rows if r['kind']=='CLK']
 assert clocks==list(range(5000,clocks[-1]+1,PERIOD)),'clock observer timestamps do not match clk10ns stimulus'
 clockset=set(clocks);frames=[]
 for f in PLAN['frames']:
  n=f['payload_len'];part=[r for r in rows if r['frame_id']==n]
  marks={r['label']:r['time_ps'] for r in part if r['kind']=='MARK'}
  assert 'BEGIN' in marks and 'END' in marks
  actual=[(r['time_ps'],int(r['tx']),int(r['de'])) for r in part if r['kind']=='EDGE' and marks['BEGIN']<=r['time_ps']<=marks['END']]
  rises=[r for r in actual if r[2]==1 and (r==actual[0] or actual[actual.index(r)-1][2]==0)]
  assert len(rises)==1,'exactly one observed DE rising event required'
  d=rises[0][0];assert d in clockset and d>marks['PAYLOAD_SEALED'],'DE must follow complete payload seal'
  expected=[(d,1,1)];wire=bytes.fromhex(f['wire_hex']);level=1
  bit10=ceildiv(10*cfg['CLOCK_HZ'],cfg['BAUD']);first=d+(cfg['PRE_CYCLES']+1)*PERIOD
  starts=[]
  for i,b in enumerate(wire):
   a=first+i*(bit10+2)*PERIOD;starts.append(a)
   bits=[0]+[(b>>k)&1 for k in range(8)]+[1]
   for k,value in enumerate(bits):
    t=a+ceildiv(k*cfg['CLOCK_HZ'],cfg['BAUD'])*PERIOD
    if value!=level:expected.append((t,value,1));level=value
  release=starts[-1]+(bit10+cfg['POST_CYCLES']+1)*PERIOD
  expected.append((release,1,0))
  if actual!=expected:
   mismatch=next((i for i in range(min(len(actual),len(expected))) if actual[i]!=expected[i]),min(len(actual),len(expected)))
   raise AssertionError(f'{cfg["id"]}/len{n} observed pin mismatch at transition{mismatch}: actual={actual[mismatch:mismatch+1]} expected={expected[mismatch:mismatch+1]} counts{len(actual)}/{len(expected)}')
  assert all(t in clockset for t,_,_ in actual),'pin edge outside observed clock edges'
  times=[r[0] for r in actual];decoded=[]
  def level_at(t):
   idx=bisect.bisect_right(times,t)-1
   return actual[idx][1] if idx>=0 else 1
  for a in starts:
   value=0
   for k in range(8):
    lo=a+ceildiv((k+1)*cfg['CLOCK_HZ'],cfg['BAUD'])*PERIOD
    hi=a+ceildiv((k+2)*cfg['CLOCK_HZ'],cfg['BAUD'])*PERIOD
    value|=level_at((lo+hi)//2)<<k
   decoded.append(value)
  assert bytes(decoded)==wire,'observed serial byte decode'
  frames.append({'payload_len':n,'observed_DE_rise_ps':d,'observed_first_TX_fall_ps':next(t for t,x,en in actual if en and x==0),'predicted_first_TX_fall_ps':first,'observed_DE_fall_ps':actual[-1][0],'predicted_DE_fall_ps':release,'observed_transition_count':len(actual),'decoded_wire_hex':bytes(decoded).hex(),'observed_timestamps_are_simulation_ps':True,'prediction_anchor':'observed DE rise, not TX start or DUT counters','exact_edge_sequence_matches':True})
 for fid in [-1,-2,-3]:
  assert not [r for r in rows if r['frame_id']==fid and r['kind']=='EDGE'],'partial/fault frame launched pin transition'
 aborts=[]
 for fid in [-4,-5]:
  part=[r for r in rows if r['frame_id']==fid]
  req=next(r['time_ps'] for r in part if r['kind']=='MARK' and r['label']=='ABORT_REQUEST')
  commit=next(t for t in clocks if t>req)
  edges=[(r['time_ps'],r['tx'],r['de']) for r in part if r['kind']=='EDGE' and r['time_ps']>req]
  assert edges==[(commit,'1','0')],f'abort pins must clear only at next actual clock: {edges}'
  aborts.append({'frame_id':fid,'abort_request_ps':req,'observed_pin_clear_ps':edges[0][0],'next_observed_clock_ps':commit})
 return {'config':cfg,'observed_clock_edges':len(clocks),'frames':frames,'aborts':aborts,'pin_edges_checked':sum(f['observed_transition_count'] for f in frames)+len(aborts)}
CASES=['frame0 PASS','frame1 PASS','frame32 PASS','partial_cancel PASS','fault bad_len=1 PASS','fault bad_len=0 PASS','uart_abort reset=0 PASS','uart_abort reset=1 PASS']
def classify(data,cfg):
 if re.search(rb'(?im)^[#\s]*(?:\*\*\s*)?(?:Error|Warning|Fatal)\s*:',data):return False
 if re.findall(rb'Errors:\s*(\d+),\s*Warnings:\s*(\d+)',data)!=[(b'0',b'0')]:return False
 markers=[s.strip().lstrip(b'#').strip().decode('ascii',errors='replace') for s in data.splitlines() if b'UART30_' in s]
 if len(markers)!=9 or markers[:8]!=['UART30_CASE '+s for s in CASES]:return False
 expected=rf'UART30_PASS clock_hz={cfg["CLOCK_HZ"]} baud={cfg["BAUD"]} pre={cfg["PRE_CYCLES"]} post={cfg["POST_CYCLES"]} checks=[1-9][0-9]* cycles=[1-9][0-9]*'
 return re.fullmatch(expected,markers[-1]) is not None
def main():
 results=[];probes=[]
 for cfg in PLAN['configs']:
  p=LOCAL/'focused-02'/cfg['id'];rows=parse(p/'pin-events.csv');result=check(rows,cfg)
  result['event_file_sha256']=sha((p/'pin-events.csv').read_bytes());results.append(result)
  data=(p/'vsim.stdout.bin').read_bytes()+(p/'vsim.stderr.bin').read_bytes();assert classify(data,cfg)
  for label,mut,expected in [('positive',data,True),('plain_warning',data+b'\n# Warning: synthetic\n',False),('duplicate_case',data+b'\n# UART30_CASE frame0 PASS\n',False),('unknown_marker',data+b'\n# UART30_FALLBACK\n',False),('extra_tally',data+b'\n# Errors: 1, Warnings: 0\n',False),('missing_case',data.replace(b'UART30_CASE frame1 PASS',b'IGNORED'),False)]:
   accepted=classify(mut,cfg);assert accepted==expected
   probes.append({'config':cfg['id'],'kind':'log','name':label,'synthetic':label!='positive','accepted':accepted,'expected':expected,'sha256':sha(mut)})
  for label in ['first_tx_delayed_clock','de_release_early_clock','missing_transition','offclock_transition']:
   mutated=copy.deepcopy(rows)
   edges=[r for r in mutated if r['kind']=='EDGE' and r['frame_id']==32]
   if label=='first_tx_delayed_clock':next(r for r in edges if r['de']=='1' and r['tx']=='0')['time_ps']+=PERIOD
   elif label=='de_release_early_clock':edges[-1]['time_ps']-=PERIOD
   elif label=='missing_transition':mutated.remove(edges[3])
   else:edges[3]['time_ps']+=1000
   try:check(mutated,cfg);accepted=True
   except AssertionError:accepted=False
   assert not accepted,label
   probes.append({'config':cfg['id'],'kind':'synthetic_pin_event','name':label,'synthetic':True,'accepted':False,'expected':False,'data_sha256':sha(json.dumps(mutated,sort_keys=True).encode())})
 old=LOCAL/'focused-01/fractional';data=(old/'vsim.stdout.bin').read_bytes()+(old/'vsim.stderr.bin').read_bytes()
 assert not classify(data,PLAN['configs'][0]);probes.append({'kind':'log','name':'first_actual_FileWatch_error','synthetic':False,'accepted':False,'expected':False,'sha256':sha(data)})
 save_json(OUT/'pin-event-verification.json',{'results':results,'passed':True,'total_observed_clock_edges':sum(r['observed_clock_edges'] for r in results),'total_pin_edges_checked':sum(r['pin_edges_checked'] for r in results),'scope':'Actual output-event timestamps compared with independently generated byte/bit schedules anchored only to observed DE rise. No physical time or absolute config-to-DE claim.'})
 save_json(OUT/'own-log-event-qualification.json',{'all_expected':True,'probes':probes,'new_simulator_runs_in_qualification':0})
 print(json.dumps({'configs':len(results),'observed_clocks':sum(r['observed_clock_edges'] for r in results),'pin_edges_checked':sum(r['pin_edges_checked'] for r in results),'qualification_probes':len(probes),'frames':[(r['config']['id'],r['frames']) for r in results]},indent=2))
if __name__=='__main__':
 try:main()
 except Exception:
  (OUT/'pin-event-check-first-failure.txt').write_text(traceback.format_exc(),encoding='utf8');raise
