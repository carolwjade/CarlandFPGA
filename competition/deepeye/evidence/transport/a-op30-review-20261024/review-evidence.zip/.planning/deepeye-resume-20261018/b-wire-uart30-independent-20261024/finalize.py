import pathlib,json,hashlib,platform
from acquire import ROOT,OUT,LOCAL,SNAP,HEAD,SOURCE,OP,sha,save_json,entries
from check_events import parse,check,classify
plan=json.loads((OUT/'oracle-freeze.json').read_bytes());focused=json.loads((OUT/'focused-result-focused-02.json').read_bytes());pins=json.loads((OUT/'pin-event-verification.json').read_bytes());history=json.loads((OUT/'history-review.json').read_bytes());ev=json.loads((OUT/'evidence-verification.json').read_bytes())
assert focused['passed'] and pins['passed'] and not history['missing_references']
assert sum(r['cycles'] for r in focused['results'])==7439 and sum(r['checks'] for r in focused['results'])==14362
for cfg in plan['configs']:
 p=LOCAL/'focused-02'/cfg['id'];data=(p/'vsim.stdout.bin').read_bytes()+(p/'vsim.stderr.bin').read_bytes()
 assert classify(data,cfg);assert check(parse(p/'pin-events.csv'),cfg)['pin_edges_checked']>0
cleanup=json.loads((OUT/'mapping-cleanup-focused-02.json').read_bytes());assert cleanup['mapping_absent_after'] and cleanup['logical_drive_absent_after']
hc=json.loads((LOCAL/'metadata/head-commit.json').read_bytes());assert SOURCE in [p['sha'] for p in hc['parents']]
es=entries();src=entries('source');sources=[]
for p in sorted(SNAP.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(SNAP).as_posix();b=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert es[rel]['sha']==blob
 sources.append({'path':rel,'bytes':len(b),'sha256':sha(b),'git_blob':blob,'same_blob_at_source':src.get(rel,{}).get('sha')==blob})
assert len(sources)==23
toolhashes=[]
for exe in ['vlib.exe','vlog.exe','vsim.exe']:
 p=pathlib.Path('C:/modeltech64_2020.4/win64')/exe;toolhashes.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
save_json(OUT/'SOURCE_HASH_MANIFEST.json',{'tested_commit':HEAD,'source_commit':SOURCE,'selected_Git_blobs':23,'whole_top_snapshot':False,'files':sources,'own_TB':{'path':str((LOCAL/'tb_uart30.sv').relative_to(ROOT)),'sha256':sha((LOCAL/'tb_uart30.sv').read_bytes())},'tool_files':toolhashes,'python':platform.python_version(),'oracle_freeze_sha256':sha((OUT/'oracle-freeze.json').read_bytes())})
result={'schema':1,'work_id':'A-B-WIRE-UART30-INDEPENDENT-20261024-v1','job_id':'child-469d5b3ba3214beb817cc0f89ea9e39a','canonical_agent_id':'/root/b_wire2829_review','task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'director_generation':3,'status':'bounded_independent_digital_review_complete','formal_acceptance':'not_performed_by_child; A Gen3/root owns acceptance and PR feedback','operation_id':OP,'PR':'https://github.com/carolwjade/CarlandFPGA/pull/30','tested_commit':HEAD,'source_commit':SOURCE,'request_hash':ev['request_hash'],'manifest_sha256':ev['manifest_sha256'],'contract':'DEEPEYE-HUMAN-LOCK-20261014/revision1','requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','selected_Git_blobs':23,'whole_top_snapshot':False,'canonical_artifacts_and_1442_promised_raw_members':'verified','raw_bytes':ev['raw_bytes'],'new_qualified_simulation':{'configs':plan['configs'],'cycles':7439,'assertion_checks':14362,'actual_observed_pin_transitions_checked':856,'complete_packets_decoded':6,'clock_observer':'clk10ns; actual positive-edge realtime CSV','time_prediction_anchor':'observed DE rise; no TX-start realignment; no counter-as-timestamp substitution','qualified_attempt':'focused-02','all_actual_new_attempt_clocks':11393,'own_log_event_qualification_probes':21},'first_attempt':'failed qualification retained; FileWatch Tcl diagnostic and missing PASS/tally, despite full CSV; not accepted as success','new_DUT_findings':[],'producer_reference_audit':{'references':123,'archive_paths':114,'canonical_Git_blobs':8,'private_scope_same_hash_copy':1,'missing':0,'pyc_references':0},'saved_producer_review':'19 saved runs and223 probes+7original runner defects+62repair qualification checks inspected and hashed; no producer code imported/executed and no old simulation rerun','independence_qualification':'Fresh vectors frozen before UART30 wrapper source read; serializer dependency had been read in prior op28/29 task. No entire-stack blind-preinspection claim.','publication_reconciliation':'Own read-only GET confirms exact head and parent source. Historical PATCH count/chronology remains producer report, not independently proven; no mutations or replays.','new_actions_excluded':{'product_edits':False,'stage_commit_reset':False,'board_UI_serial_services_credentials':False,'external_messages':False,'new_delegation':False},'not_run':[ 'all29','B04','G03','R03','A_ABI_type_profile_source_session_BOOT_TTL_replay_motion','physical_clock_or_UART_measurement','CDC_RDC','synthesis','implementation','timing','build','board','system'],'raw_storage':'Existing original raw retained in task-exclusive .local; no235MB copy into product or new repeated package.','ASCII_mapping_cleanup_verified':True}
save_json(OUT/'result.json',result)
report=f'''# B UART30 限定独立复核

新增 same-clock opaque packet→UART 数字仿真控制通过，未发现新 DUT 断言或输出引脚时序失败。正式接受与同 PR 反馈由 A Gen3/root 决定。

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`，work `A-B-WIRE-UART30-INDEPENDENT-20261024-v1`；新 job `child-469d5b3ba3214beb817cc0f89ea9e39a` 的 canonical `/root/b_wire2829_review` 验证 execution_allowed=true。Gen3 主 `01a16988-bdcb-70e1-ae10-1304b5cf7875`，H01–H15 canonical requirements 实算保持 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`。A/root 唯一实板操作者；前 op28/29 归档没有修改。

## 精确输入

PR30 https://github.com/carolwjade/CarlandFPGA/pull/30 ，固定 tested head `{HEAD}`，直接 parent/source `{SOURCE}`。取得23个选定 Git blobs（16项operation材料、4依赖、3额外公开说明文档），逐一核 Git blob SHA1/长度/SHA256；未声称 whole-top checkout。

Operation `{OP}`；request `19cad739eaf13167500600b4b08b38603c3d371c2dd49beb0c5b0293286f78d6`；manifest `984bebbff3429a91c4552dc2e5d282c6fde58359f5b0677a46f66a23f8e7b41e`。canonical artifacts、source binding、4只读依赖与全部 **1442** 个承诺 raw 成员（235,478,446 B）字节一致。原tar SHA256 `44e7588f84020788dfd4eca5d8efafe7fec138e1b4a5786996645ff083d5dc88`；RAW_INDEX SHA256 `d8682a116ceb47b2e8a3eead26a96bfdc92b15599ff26ec1cd677719bca630f6`。

## 独立向量及实际引脚观测

先读 composition/frame/UART/serializer 公开语法与时序文档，冻结 fresh struct.pack+binascii 0/1/32-byte packet 和另写CRC递推，再首次阅读 UART30 wrapper。**serializer dependency 已在上一 op28/29 任务阅读过**；不声称整个组合RTL盲测。作者/main TB、向量发生器和oracle未导入或执行。详见 oracle-freeze.json 与 oracle-independence-disclosure.json。

ModelSim SE-64 **2020.4**，单一10 ns刺激时钟 `clk10ns`，两种小配置：

| CLOCK_HZ/BAUD | PRE/POST | qualified clocks | 断言checks |
|---|---|---:|---:|
| 23/5 | 2/3 | 3954 | 7648 |
| 20/5 | 0/0 | 3485 | 6714 |

合格 focused-02 共 **7439 clocks / 14362 checks**；两进程 exit0、Errors0/Warnings0。外部公开端口检查完整0/1/32包、捕获后metadata变化、payload间隙与seal前无发送、reservation背压、drain/DErelease之后一沿观察及无同沿新cfg credit、部分payload/错length/错last无串口启动、UART传输中cancel/reset同步清除、held cancel一次计数及reset优先级。

`always @(tx or de)` 原生事件回调记录实际输出跳变的 `$realtime`→ps，单独 `posedge clk` observer 记录实际刺激时钟时间。CSV由仿真器直接写入，非counter推测。独立Python checker核对 **856次实际TX/DE跳变**，六个完整包串行解码精确等于冻结packet bytes（含端序与CRC）；partial/fault没有引脚启动，4次中断清除发生在请求后的下一实际clock。

时间oracle明确以**观测到的DE上升**为锚，预测首start=`d+(PRE+1)T`，各位边界=`ceil(k*CLOCK_HZ/BAUD)`，字节间`B(10)+2`，末DE释放=`lastA+B(10)+POST+1`。没有用观测TXstart重新对齐，也不声称完整cfg→DE绝对延迟。例：23/5的32-byte payload包，实测DE上升15,925,000 ps，首TX下降15,955,000 ps，DE下降38,055,000 ps，均与独立预测相符。**这些是仿真时间，不是物理时钟、引脚或串口测量。**

21项自有保存日志/事件qualification全部符合预期，包括一clock提前/延后、缺失/离沿跳变等合成反例。它们不算新DUT运行。

## 保留的首次失败

focused-01 的fractional invocation有 Tcl `FileWatch(fileName)` error，缺PASS/tally；即使CSV到FINISH也判失败。完整raw pipes/receipt/CSV保留。仅将task-local temp/cache改为已核未占用的ASCII映射内，TB/RTL不变，作一次必要复验后再运行计划integer配置。所有新实际运行共11,393 clocks，未扩成原大组。两次映射均finally移除并读回。该调整后clean，不将其泛化为完整FileWatch根因证明。

## 生产者保存证据与发布对账

未重跑旧5,627,750cycles/135,066,000checks、4configs/11guards/4mutants或author16cases。重核保存19个run的RESULT、所有input和原stdout/stderr；223个main日志probe保存accepted与expected一致，样本hash存在。原7个runner警告/marker-order缺陷、修复后62项qualification（35positive/27guard）、作者vlib-version exit1例外和其它10个exit0、原relative-path/CRLF/main classifier失误及修正均保留。

123引用全部能解析：114原归档路径、8精确canonical Git blobs、1 private scope同hash归档副本。没有缺失引用或pyc引用；不因此把hash验证当作全部原时执行语义证明。历史preinspection顺序/旧接受结论仍属生产者记录。

对原PATCH仅做只读对账：本轮GET确认指定head及其source parent。旧“首次PATCH成功、立即GET陈旧、稍后GET对上、仅未尝试metadata PATCH执行一次”的完整变更次数和时序仍按生产者回述记录；选定canonical归档没有其原mutation receipts，本轮不声称独立证明历史PATCH次数，也未PATCH/POST/重放。原回执effects_allowed=false，generation2文字不覆盖Gen3 transfer。RX31失败/repair和B06均未触碰。

## 交接范围

235 MB原raw继续留独占.local，没有复制入产品或另打重复包。完整EVIDENCE_MANIFEST列所有留存字节；ROOT_ARCHIVE_SELECTION.json提供较小新控件/CSV/命令/源pins/旧审计与原upstream tar固定source/hash引用清单，明确该选择不内嵌235 MB全量。

本项无产品编辑、stage/commit/reset、board/串口/UI/服务/credentials动作、外部消息或再次派工。A ABI/type/profile/source/session/BOOT/TTL/replay/motion、physicalclock、CDC/synth/impl/timing/build/board/system未接受；G03/R03/all29/B04仍not_run。H01–H15不变。
'''
(OUT/'report.md').write_text(report,encoding='utf8')
# Small archive handoff: references the immutable upstream bundle rather than duplicating235MB.
small=[]
for p in sorted(OUT.glob('*')):
 if p.is_file() and p.name not in ['lease.private.json','EVIDENCE_MANIFEST.json','MANIFEST.sha256.txt','manifest-readback.json','native-complete.json','ROOT_ARCHIVE_SELECTION.json']:
  small.append(p)
for name in ['tb_uart30.sv','frame0.hex','frame1.hex','frame32.hex','run_focused-first-FileWatch-error.py']:small.append(LOCAL/name)
for folder in [LOCAL/'focused-01',LOCAL/'focused-02']:
 for p in folder.rglob('*'):
  if p.is_file() and ('work' not in p.relative_to(folder).parts) and (p.suffix in ['.bin','.json','.csv','.do'] or p.name=='transcript'):small.append(p)
for rel in ['main/final-audit-01/RESULT.json','main/classifier-order-01/RESULT.json','main/runner-negative-01/FAILURE.json','main/runner-negative-02/RESULT.json','main/runner-order-negative-03/RESULT.json','author/RESULT.json','author/RUNNER_REPAIR1_RESULT.json','author/runner-repair1-qualification/qualification-01/QUALIFICATION_RESULT.json']:small.append(LOCAL/'raw'/rel)
save_json(OUT/'ROOT_ARCHIVE_SELECTION.json',{'scope':'Suggested small canonical review archive. This is a selection descriptor, not a new package or whole235MB raw embed. Root owns final archive/publication.','files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(set(small))],'original_producer_bundle_reference':{'commit':HEAD,'source_commit':SOURCE,'path':'competition/deepeye/evidence/transport/wire-uart-tx-20261024-30/publication/raw-evidence.tar.gz','sha256':ev['archive_sha256'],'raw_members':1442,'raw_bytes':235478446,'inline_raw_members':False,'locally_retained':str((LOCAL/'raw').relative_to(ROOT))}})
print(json.dumps({'status':result['status'],'report_sha256':sha((OUT/'report.md').read_bytes()),'result_sha256':sha((OUT/'result.json').read_bytes()),'selected_Git_blobs':len(sources),'archive_selection_files':len(set(small))},indent=2))
