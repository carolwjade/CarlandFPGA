"""Root exact-head UART30 review; archive new controls, reference original raw."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import tarfile
import zipfile

P = Path(__file__).resolve().parent
R = P.parents[2]
O = P.parent
W = R / '.local/deepeye-implementation-a'
A = O / 'b-wire-uart30-independent-20261024'
S = R / '.local/deepeye-b-wire-uart30-review-20261024'
BASE = '17fe7a63652dac6003f3ff6c71abe90eb10c8c87'
GIT = r'C:\Users\CarlJade\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_bytes())


def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')


def root_path(name):
    path = (R / name).resolve()
    assert path.is_relative_to(R.resolve()) and path.is_file()
    return path


def git(*args):
    return subprocess.check_output([GIT, '--no-optional-locks', '-C', str(W), *args])


assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert not git('diff', '--cached', '--name-only').strip()
protected = read(O / 'r03-mailbox-stop-main-review-20261020/application.json')['protected_files']
assert all(sha((W / name).read_bytes()) == pin for name, pin in protected.items())
terminal = read(P / 'uart30-terminal.json')
if isinstance(terminal, dict) and 'content' in terminal:
    terminal = json.loads(next(x['text'] for x in terminal['content'] if x['type'] == 'text'))
job = terminal[0]
assert job['status'] == 'completed' and job['terminal'] and not job['stale']
for name in ['report.md', 'result.json', 'EVIDENCE_MANIFEST.json']:
    assert sha((A / name).read_bytes()) in job['result']['text']
manifest = read(A / 'EVIDENCE_MANIFEST.json')
assert len(manifest['files']) == 1746
for row in manifest['files']:
    raw = root_path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
source = read(A / 'SOURCE_HASH_MANIFEST.json')
assert source['tested_commit'] == 'e9b447802dea14c077b2564102e560741ce5e2df'
assert source['source_commit'] == 'a1428cfc82a8c789356389184bbf37aed3b261f4'
assert len(source['files']) == 23
for row in source['files']:
    raw = (S / 'snapshot' / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['git_blob']
operation = 'B-DEEPEYE-WIRE-UART-TX-20261024-30'
upstream = S / 'snapshot/handoffs/b' / operation / 'manifest.json'
doc = read(upstream)
assert sha(upstream.read_bytes()) == '984bebbff3429a91c4552dc2e5d282c6fde58359f5b0677a46f66a23f8e7b41e'
request = sha(json.dumps(doc['request'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
assert request == '19cad739eaf13167500600b4b08b38603c3d371c2dd49beb0c5b0293286f78d6'
for name, row in doc['files'].items():
    raw = (S / 'snapshot' / name).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row.get('size', row.get('bytes'))
    if name.endswith('/raw-evidence.tar.gz'):
        assert sha(raw) == '44e7588f84020788dfd4eca5d8efafe7fec138e1b4a5786996645ff083d5dc88'
        with tarfile.open(S / 'snapshot' / name, 'r:gz') as tf:
            entries = tf.getmembers()
            assert len(entries) == 1442 and all(x.isfile() for x in entries)
            assert len({x.name for x in entries}) == 1442
            assert sum(x.size for x in entries) == 235478446
focused = read(A / 'focused-result-focused-02.json')
assert focused['passed'] and len(focused['results']) == 2
for test in focused['results']:
    assert test['passed'] and test['exit'] == 0
    path = S / 'focused-02' / test['config']['id']
    log = (path / 'vsim.stdout.bin').read_bytes()
    assert sha(log) == test['stdout_sha256'] and sha((path / 'vsim.stderr.bin').read_bytes()) == test['stderr_sha256']
    assert b'Errors: 0, Warnings: 0' in log and b'Warning:' not in log
    assert sha((path / 'pin-events.csv').read_bytes()) == test['pin_events_sha256']
assert sum(x['cycles'] for x in focused['results']) == 7439
assert sum(x['checks'] for x in focused['results']) == 14362
pins = read(A / 'pin-event-verification.json')
assert sum(x['pin_edges_checked'] for x in pins['results']) == 856
assert all(f['exact_edge_sequence_matches'] for x in pins['results'] for f in x['frames'])
qualification = read(A / 'own-log-event-qualification.json')
assert qualification['all_expected'] and len(qualification['probes']) == 21
result = read(A / 'result.json')
assert result['producer_reference_audit'] == dict(references=123, archive_paths=114,
    canonical_Git_blobs=8, private_scope_same_hash_copy=1, missing=0, pyc_references=0)
selection = read(A / 'ROOT_ARCHIVE_SELECTION.json')
assert len(selection['files']) == 137
members = {}
for row in selection['files']:
    raw = root_path(row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    members[row['path']] = raw
for name in selection['post_seal_paths_to_include']:
    members[name] = root_path(name).read_bytes()
# Include all selected source/contract blobs except the immutable upstream bundle.
# The original bundle remains at its exact B commit and in the local cache.
for row in source['files']:
    if not row['path'].endswith('/raw-evidence.tar.gz'):
        members['upstream-selected/' + row['path']] = (S / 'snapshot' / row['path']).read_bytes()
members['root/native-terminal.json'] = (P / 'uart30-terminal.json').read_bytes()
members['root/archive_uart30_review.py'] = Path(__file__).read_bytes()
assert sum(map(len, members.values())) < 10 * 1024 * 1024
secret = read(A / 'lease.private.json')['lease_token'].encode()
assert all(secret not in raw for raw in members.values())
assert all('lease.private' not in name for name in members)
decision = dict(schema=1, utc=datetime.now(timezone.utc).isoformat(),
    owner='A/root 01a16988-bdcb-70e1-ae10-1304b5cf7875/generation3',
    disposition='ACCEPT_NEW_DIRECTED_OPAQUE_PACKET_UART_DIGITAL_SIMULATION_ONLY',
    operation_id=operation, request_hash=request, manifest_sha256=sha(upstream.read_bytes()),
    tested_commit=source['tested_commit'], source_commit=source['source_commit'],
    requirements_sha256='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
    H01_H15_preserved=True, root_frozen_files_verified=1746, selected_Git_blobs_verified=23,
    promised_raw_members_verified=1442, promised_raw_bytes_verified=235478446,
    new_qualified_configs=2, new_qualified_clocks=7439, new_qualified_checks=14362,
    actual_simulation_pin_transitions_checked=856, decoded_packets=6,
    timing_anchor='observed DE rise; no TX-start realignment; simulation time only',
    own_log_event_probes=21, new_DUT_findings=[],
    producer_old_groups_rerun=False, historical_PATCH_chronology='producer report only',
    independence='vectors frozen before wrapper read; serializer dependency read in earlier op28/29 task',
    first_FileWatch_failure_preserved=True,
    old_wire2829_F01='still OPEN; this review does not close the two missing historical cache files',
    original_producer_bundle_reference=selection['original_producer_bundle_reference'],
    archive_scope='selected new A controls and small saved audit; original235MB raw not embedded',
    full_producer_qualification_or_A_semantic_control_build_board_system_accepted=False,
    B04='not_run', G03='not_run', R03='not_run', all29='not_run')
dest = W / 'competition/deepeye/evidence/transport/a-op30-review-20261024'
dest.mkdir(parents=True, exist_ok=False)
zp = dest / 'review-evidence.zip'
with zipfile.ZipFile(zp, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(members.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None and len(z.namelist()) == len(members)
    assert all(z.read(name) == raw for name, raw in members.items())
save(dest / 'manifest.json', dict(schema=1, zip_sha256=sha(zp.read_bytes()), zip_bytes=zp.stat().st_size,
    member_count=len(members), original_raw_embedded=False, members=[dict(path=name,
    bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(members.items())], credentials_excluded=True))
save(dest / 'decision.json', decision)
(dest / 'README.md').write_text('Root accepts only the new directed opaque packet-to-UART digital simulation at the pinned B head: two configs,7439 clocks,14362 checks and856 observed simulation TX/DE transitions. Timing is anchored to observed DE rise; it is not physical pin timing or full cfg-to-DE latency. The original first FileWatch failure is retained. Prior serializer exposure and producer-only historical PATCH chronology remain explicit. This is a selected small archive with immutable upstream tar/hash references, not an embedded235MB producer bundle. Old op28/29 F01 remains OPEN. No A ABI/source/session/BOOT/TTL/motion/build/board/system acceptance. H01-H15 unchanged; B04/G03/R03/all29=not_run.\n', encoding='utf-8', newline='\n')
files = {path.relative_to(W).as_posix(): sha(path.read_bytes()) for path in dest.iterdir()}
save(P / 'uart30-root-decision.json', decision)
save(P / 'uart30-publication.json', dict(expected_head=BASE,
    message='Archive directed UART30 review with observed simulation pin events', files=files))
assert all(sha((W / name).read_bytes()) == pin for name, pin in protected.items())
print(json.dumps(dict(prepared_files=len(files), archive_members=len(members), zip_bytes=zp.stat().st_size,
    zip_sha256=sha(zp.read_bytes()), verified_frozen_files=1746, C4_unchanged=True)))
