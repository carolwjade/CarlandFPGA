# B UART RX / frame TX 独立证据复核

任务 `DEEPEYE-IMPLEMENTATION-20261014/v1`；工作 `A-B-UART2526-INDEPENDENT-20261024-v1`；子代理 `/root/b_uart2526_review`，租约 `child-0b134abb16914855866878c7858f9fe4`。已由 native_validate 允许执行。Gen3 director 为 `01a16988-bdcb-70e1-ae10-1304b5cf7875`，正式验收及同 PR 反馈由 root 决定。

本轮没有发现新增公开端口用例与 DUT 的分歧。结论只覆盖下面列出的独立数字仿真和保存证据复核，不是产品、实板或正式卡验收。

## 准确身份与取得方式

- PR30现场 head：`dfdb2b8120793ba816fd09cd8fc255953bbf73ac`，来源 `Morde-cloud/CarlandFPGA` 分支 `codex/b/deepeye-implementation-20261014`。
- 原代码提交：`63a7c23adaf23cea1eb679993a7c87a403c5f305`。GitHub commit API表明它是 head 的唯一直接父提交，head 仅更改4个 op25/26 handoff 元数据文件，24个交付文件字节均按不可变 head 获取。
- 原认证 Git clone 已建立在独占 `.local/deepeye-b-uart2526-review-20261024`；后续 fetch 无完成进展，精确终止了本次所属5进程并核对结束。改用原认证 `gh api ...contents/<path>?ref=<full-head>` 保存不可变字节。**这是准确 head 的交付字节快照，未形成完整 Git checkout**；不声称全树清洁或完整 top 的存在/缺失。失败记录见 `git-fetch-stop.json`。
- 人类合同 `DEEPEYE-HUMAN-LOCK-20261014/revision1`，requirements 数组经 UTF-8 / ensure_ascii=False / sort_keys=True / 紧凑分隔符实算 SHA256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`，H01–H15全部保留。A/root独占实板。

| 操作 | request_hash | manifest SHA256 | 身份复核 |
|---|---|---|---|
| B-DEEPEYE-UART-RX-20261023-25 | e95a13c451b3a8750928ad1f7ebe08fb76858556d5fa135c3c58ecc55c29febe | e6dce5a953c66a83dd0f8e9daaf6ed14cf88c360e02a9fb59c01facc4deec0b2 | 12文件 / 6源绑定 / 1736归档成员 / 4,717,903解压字节，全部匹配 |
| B-DEEPEYE-UART-FRAME-TX-20261023-26 | a214c2014390a3a68ca7a3f4f99f9e5a8f930e0580aa37b44ef8c4bb47ab98ee | 6cb1fcdf0244a90bb36a8fdc621bd746e84aaf0d6b9dddf0cca49fd65026fe4b | 12文件 / 6源绑定 / 1795归档成员 / 69,416,805解压字节，全部匹配 |

request_hash另按仓库 handoff.py 的 canonical request 算法实算。归档仅流式读取，全部文件名、长度、SHA256与RAW_INDEX以及bundle统计匹配，无未索引/重复文件。

## 本轮新增执行

实际工具为 `Model Technology ModelSim SE-64 vsim 2020.4 Simulator 2020.10 Oct 13 2020`，可执行文件路径/字节/SHA256在 `local-tool-identities.json`；版本原始管道在 `commands/modelsim-*-version/`。没有运行作者32套、旧op24、系统软件测试、求解或384次板基线。

两个TB均为本轮独立编写，只使用公开端口，不读取层次、不 force、不复用作者TB。已先阅读候选文档和RTL，**不是预先盲审oracle**。`frame-frac-guards`的guards指合法PRE/POST延迟，不是非法参数fatal测试。

| 用例 | CLOCK_HZ / BAUD | 其它参数 | 实际边沿 | 实际断言 | vsim退出码 |
|---|---|---|---:|---:|---:|
| rx-int | 160 / 10 | STAT_W=4 | 1,678 | 7,299 | 0 |
| rx-frac-sat | 97 / 5 | STAT_W=2 | 2,020 | 8,792 | 0 |
| frame-zero | 160 / 10 | PRE=0, POST=0, STAT_W=4 | 13,615 | 66,999 | 0 |
| frame-frac-guards | 97 / 5 | PRE=3, POST=5, STAT_W=4 | 16,438 | 81,102 | 0 |

四配置合计 **33,751边沿 / 164,192断言**，vlib/vlog/vsim共12个实际过程全部exit0，编译均 `Errors: 0, Warnings: 0`，仿真各有唯一PASS且无Error/Fatal/Warning。

RX覆盖：低电平跨reset/cancel不虚假起帧；固定字节/整数与分数分频；满槽稳定和新帧overrun丢弃；准确stop采样边沿旧字节退休同时新字节入槽；错误stop、长低、false start保留旧槽；活动帧+待取字节双对象cancel计数、held cancel不重计、reset优先；实际STAT_W=2饱和。

frame TX覆盖：8/9字节CRC载荷、64字节上界；source间断和configuration/sample互斥；从seal输入时刻推导全部字节admission，按ceil(k*CLOCK_HZ/BAUD)比较每个TX边沿、两拍字节间隔、DE上升和POST后释放；非法count 0/65、early/missing last为sticky fault且不发送部分帧；receive/pre/in-flight中止、准确retirement边沿cancel优先、held cancel和reset优先。未新增非法声明参数仿真。

外部Python解码器从本轮原始 `wire.csv` 读取 **162字节**，四个CRC载荷帧的CRC16/CCITT-FALSE与输入一致，六个完整帧的DE窗口准确。内存负控制分别翻转载荷bit和合并DE间隙，4个控制均拒绝。CRC只在独立harness生成/核验；DUT只透明传字节，**没有CRC生成/校验或公共packet ABI**。这里的negative controls是原始波形后处理，不是额外ModelSim执行。

完整命令、cwd、UTC、真实exit和stdout/stderr原始字节及hash在 `commands/<case>-vlib|vlog|vsim/receipt.json`、`stdout.bin`、`stderr.bin`。工作目录为本轮临时ASCII `Z:` 映射，目标仅此子代理隔离目录；`ascii-drive-mapping.json`与`ascii-drive-cleanup.json`记录原盘符可用及实际移除。真实输出保留在该目标目录的 `a-independent/attempt-1/<case>/`。

复核入口均相对本证据目录：`audit_identity.py`最终exit0；`audit_saved.py`最终exit0（仅保存字节审计）；`run_independent.py`exit0；`decode_wire.py`exit0。Python来自原 `.local/venv/Scripts/python.exe -X utf8`。

## 已保存证据的独立审计

| 项目 | RX | frame TX |
|---|---:|---:|
| 原作者套数（没有重跑） | 15 | 17 |
| 原作者过程收据/原始管道重哈希 | 48 | 55 |
| 其中实际exit0 | 47 | 55 |
| 原main成功分类记录 | 20 | 24 |
| 原main命令/管道重哈希（含原失败） | 105 | 125 |
| 原positive配置数，另有1个修正后legal确认 | 7 | 9 |
| 原positive边沿 | 17,267,015 | 17,988,225 |
| 原positive比较 | 241,738,210 | 323,788,050 |
| 原guard / 数值mutant反例 | 9 / 3 | 11 / 3 |

成功positive原始MAIN_STATS与RESULT一致，checks/cycles分别为14/18；guard原始唯一fatal与诊断一致；mutant均有got≠expected的数值反例和准确fatal。原始两次非法STAT_W fixture未通过记录仍在归档，各有5条命令收据。旧main的onerror控制台提示按原字节保留，不声称原控制台无warning。原作者RX工具身份查询 `vlib -version` exit1、stdout为Usage、stderr空，单列保留，未误称为仿真失败或全部48个exit0。

作者parser修复及synthetic qualification文件已核对归档成员身份；没有独立重执行作者99/110个人工negative分类，也不将旧日志重分类计成新vendor仿真。历史runner与最终交付runner不能仅因同名继承当前通过结论。

本地保存字节审计先后保留3次失败：第一次错误假定所有原过程exit0；第二次审计脚本缩进错误；第三次错误假定48为successful count。对应原脚本与失败记录均保留；依据原始记录修正为48 total/47 exit0/1诊断exit1后完成。没有修改产品，也没有重跑任何已通过仿真。

## 必须分开的缺项

本轮支持的是独立单时钟数字RX与单帧buffer/DE sequencer的列明行为。数字rx_async两级采样不构成物理CDC/亚稳态/晶振误差或真实UART/RS485电气验证；数字DE延迟不构成方向脚/收发器turnaround实测。中止可能截断线上字节；本地cancel并不保证对端帧重同步，已发完的字节也不能被撤销。

公共ABI及真正CRC parser、ACK/retry、slot scheduler/共享带宽、BOOT/源时钟/观测时效/动作授权、完整top/build及同次bit/HWH、综合/实现/时序/CDC_RDC、实际ADC与板端UART、PC AI/两条H12/模拟器联动仍需各自证据。本轮没有完整全树checkout，不能据交付快照声称整个产品已/未实例化模块。

`B04 / R03 / G03 / all29 / full_product / synthesis / implementation / timing / CDC_RDC / board / system = not_run`。无实板/服务/显示器/凭据/provider操作，无peer/群/PR评论，无派工。root负责正式验收、后续同PR反馈和B实际读回。

详细结果：`result.json`、`identity-result.json`、`saved-evidence-audit.json`、`simulations/result.json`、`wire-decode-result.json`及 `archives/*-members.json`。交付SHA256清单见 `SHA256SUMS.json`（排除租约私人文件和自身）。
