`timescale 1ns/1ps
module a_tb_frame;
parameter integer HZ=160,BAUD=10,PRE=0,POST=0;
reg clk=0;always #5 clk=~clk;
reg rst=1,cancel=0,cfg_valid=0,s_valid=0,s_last=0;reg [6:0] cfg_count=0;reg [7:0] s_data=0;
wire cfg_ready,s_ready,tx,de,busy,receiving,faulted,fault_event;wire [1:0] fault_code;
wire [3:0] stat_admitted,stat_sent,stat_aborted,stat_faults;
deepeye_uart_frame_tx #(.CLOCK_HZ(HZ),.BAUD(BAUD),.PRE_CYCLES(PRE),.POST_CYCLES(POST),.STAT_W(4)) dut(.*);
integer edge_no=0,checks=0,trace,eadm=0,esent=0,eabort=0,efault=0;reg[7:0] payload[0:63];
function integer B(input integer k);B=(k*HZ+BAUD-1)/BAUD;endfunction
task ck(input bit ok,input string msg);begin checks=checks+1;if(!ok)$fatal(1,"A_FRAME_FAIL edge=%0d %s",edge_no,msg);end endtask
always @(posedge clk)begin
 #1;edge_no=edge_no+1;
 ck(!$isunknown({cfg_ready,s_ready,tx,de,busy,receiving,faulted,fault_event,fault_code,stat_admitted,stat_sent,stat_aborted,stat_faults}),"known public ports");
 $fdisplay(trace,"%0d,%0d,%0d,%0d,%0d,%0d",edge_no,tx,de,busy,receiving,faulted);
end
task step(input integer n);repeat(n)begin @(posedge clk);#2;end endtask
task counts;
 begin ck(stat_admitted==eadm&&stat_sent==esent&&stat_aborted==eabort&&stat_faults==efault,"reservation accounting");end
endtask
task reserve(input integer n);
 begin
  ck(cfg_ready&&!s_ready,"idle configuration handshake only");cfg_count=n;cfg_valid=1;s_valid=1;s_last=1;s_data=8'hff;
  step(1);eadm=eadm+1;cfg_valid=0;s_valid=0;
  ck(stat_admitted==eadm&&busy&&!de&&tx,"reserved frame emits no partial data");
 end
endtask
task release_cancel;
 begin cancel=1;step(1);eabort=eabort+1;ck(!busy&&!de&&tx&&!faulted&&!fault_event&&!receiving,"cancel clears frame");counts();step(2);counts();cancel=0;step(1);end
endtask
task load_frame(input integer n);
 integer j;
 begin
  reserve(n);ck(receiving&&!faulted,"receiving after valid config");step(3);
  for(j=0;j<n;j=j+1)begin
   ck(s_ready&&!cfg_ready&&!de&&tx,"samples accepted before transmit");
   s_data=payload[j];s_last=(j==n-1);s_valid=1;step(1);s_valid=0;
   if(j!=n-1)begin step((j%3)+1);ck(!de&&tx,"source gaps never expose partial frame");end
  end
  ck(!de&&tx&&busy&&!receiving,"sealed edge before DE assertion");
 end
endtask
task verify_frame(input integer n,input bit abort_retire,input string label);
 integer seal,first,retire,lastedge,j,k,elapsed,part;reg expected_tx,expected_de;
 begin
  load_frame(n);seal=edge_no;first=seal+PRE+2;retire=first+(n-1)*(B(10)+2)+B(10)+POST+1;
  $write("A_FRAME_VECTOR label=%s n=%0d seal=%0d first=%0d retire=%0d bytes=",label,n,seal,first,retire);
  for(j=0;j<n;j=j+1)$write("%02x",payload[j]);$display("");
  cfg_valid=1;cfg_count=7'd64;s_valid=1;s_data=8'hff;s_last=1;
  while(edge_no<retire)begin
   if(abort_retire&&edge_no==retire-1)cancel=1;
   step(1);
   expected_tx=1;elapsed=edge_no-first;
   if(elapsed>=0)begin
    j=elapsed/(B(10)+2);part=elapsed%(B(10)+2);
    if(j<n&&part<B(10))begin
     if(part<B(1))expected_tx=0;
     else begin
      for(k=1;k<9;k=k+1)if(part>=B(k)&&part<B(k+1))expected_tx=payload[j][k-1];
     end
    end
   end
   expected_de=(edge_no>=seal+1&&edge_no<retire);
   ck(tx===expected_tx&&de===expected_de,"absolute frame bit and DE boundary");
   ck(busy===(edge_no<retire)&&!receiving&&!faulted&&!fault_event&&!s_ready,"public frame state");
   ck(cfg_ready===(edge_no==retire&&!cancel),"no same-edge retirement reconfiguration");
   if(edge_no==retire)begin if(abort_retire)eabort=eabort+1;else esent=esent+1;end
   counts();
  end
  cancel=0;cfg_valid=0;s_valid=0;step(2);counts();
 end
endtask
integer i;
initial begin
 trace=$fopen("wire.csv","w");step(3);rst=0;step(1);
 payload[0]=8'ha5;payload[1]=8'h5a;payload[2]=0;payload[3]=3;payload[4]=1;payload[5]=2;payload[6]=8'hb5;payload[7]=8'h86;
 verify_frame(8,0,"crc_a");
 payload[3]=4;payload[4]=8'h0a;payload[5]=8'h0d;payload[6]=8'hff;payload[7]=8'hde;payload[8]=8'h6c;
 verify_frame(9,0,"crc_b");
 for(i=0;i<64;i=i+1)payload[i]=(i*37+11)&255;
 verify_frame(64,0,"max64");
 reserve(0);efault=efault+1;ck(faulted&&fault_event&&fault_code==1&&!receiving,"zero count fault");step(5);ck(faulted&&!fault_event&&!cfg_ready&&!s_ready&&!de&&tx,"sticky poisoned reservation");release_cancel();
 reserve(65);efault=efault+1;ck(faulted&&fault_code==1,"oversize count fault");release_cancel();
 reserve(3);s_valid=1;s_last=1;s_data=8'h44;step(1);s_valid=0;efault=efault+1;ck(faulted&&fault_event&&fault_code==2&&!de&&tx,"early last prevents any transmit");release_cancel();
 reserve(1);s_valid=1;s_last=0;step(1);s_valid=0;efault=efault+1;ck(faulted&&fault_code==2&&!de&&tx,"missing last prevents any transmit");release_cancel();
 reserve(3);s_valid=1;s_last=0;step(1);s_valid=0;step(3);release_cancel();
 load_frame(1);step(1);ck(de&&tx,"DE pre-edge before first start");release_cancel();
 load_frame(1);step(PRE+5);ck(de&&busy,"in-flight frame before cancel");release_cancel();
 verify_frame(1,1,"cancel_on_retire");
 reserve(2);rst=1;cancel=1;step(1);eadm=0;esent=0;eabort=0;efault=0;counts();ck(!busy&&!de&&tx&&!faulted,"reset wins over cancel");rst=0;cancel=0;step(1);
 $display("A_FRAME_PASS hz=%0d baud=%0d pre=%0d post=%0d edges=%0d checks=%0d",HZ,BAUD,PRE,POST,edge_no,checks);$fclose(trace);$finish;
end
initial begin #4000000;$fatal(1,"A_FRAME_TIMEOUT");end
endmodule
