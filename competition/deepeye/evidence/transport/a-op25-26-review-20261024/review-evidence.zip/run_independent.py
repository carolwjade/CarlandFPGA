from review_driver import *
import ctypes,os,shutil,re
TOOLS=pathlib.Path('C:/modeltech64_2020.4/win64')
def ident(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
write_json('local-tool-identities.json',{n:ident(TOOLS/(n+'.exe')) for n in ['vlib','vlog','vsim']})
run('modelsim-vsim-version',[TOOLS/'vsim.exe','-version'])
run('modelsim-vlog-version',[TOOLS/'vlog.exe','-version'])
used=ctypes.windll.kernel32.GetLogicalDrives();drive=next(chr(n+65)+':' for n in range(25,3,-1) if not used&(1<<n))
run('subst-create',['subst',drive,str(CHECKOUT)])
write_json('ascii-drive-mapping.json',{'drive':drive,'target':str(CHECKOUT),'used_drives_before_bitmask':used,'owned_target_only':True})
cases=[('rx-int', 'rx',160,10,4,0,0),('rx-frac-sat','rx',97,5,2,0,0),('frame-zero','frame',160,10,4,0,0),('frame-frac-guards','frame',97,5,4,3,5)]
results=[]
try:
 for name,kind,hz,baud,w,pre,post in cases:
  case=pathlib.Path(drive+'/')/'a-independent'/'attempt-1'/name;case.mkdir(parents=True,exist_ok=False)
  rtlbase=CHECKOUT/'competition/deepeye/fpga/transport'
  rtl=[rtlbase/'deepeye_uart_rx.sv'] if kind=='rx' else [rtlbase/'deepeye_uart_tx.sv',rtlbase/'deepeye_uart_frame_tx.sv']
  for p in rtl:shutil.copyfile(p,case/p.name)
  shutil.copyfile(OUT/f'a_tb_{kind}.sv',case/'a_tb.sv')
  (case/'temp').mkdir();os.environ.update({x:str(case/'temp') for x in ['TEMP','TMP','TMPDIR']})
  run(name+'-vlib',[TOOLS/'vlib.exe','work'],cwd=case)
  c=run(name+'-vlog',[TOOLS/'vlog.exe','-sv','-work','work']+[p.name for p in rtl]+['a_tb.sv'],cwd=case)
  assert b'Errors: 0, Warnings: 0' in c.stdout
  generics=[f'-gHZ={hz}',f'-gBAUD={baud}']+([f'-gW={w}'] if kind=='rx' else [f'-gPRE={pre}',f'-gPOST={post}'])
  s=run(name+'-vsim',[TOOLS/'vsim.exe','-c','-onfinish','stop','work.a_tb_'+kind]+generics+['-do','run -all; quit -code 0'],cwd=case)
  raw=s.stdout+s.stderr;txt=raw.decode(errors='replace')
  marks=re.findall(r'A_'+('RX' if kind=='rx' else 'FRAME')+r'_PASS[^\r\n]*',txt)
  passed=len(marks)==1 and not re.search(r'\*\*\s*(Error|Fatal|Warning)|A_(?:RX|FRAME)_(?:FAIL|TIMEOUT)',txt)
  stats={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',marks[0])} if marks else {}
  entry={'name':name,'kind':kind,'parameters':{'CLOCK_HZ':hz,'BAUD':baud,'STAT_W':w,'PRE_CYCLES':pre,'POST_CYCLES':post},'passed':passed,'simulator_exit_code':s.returncode,'stats':stats,'source_files':{p.name:ident(case/p.name) for p in rtl},'testbench':ident(case/'a_tb.sv'),'relative_run_dir':str(case.relative_to(pathlib.Path(drive+'/'))),'pass_marker':marks}
  write_json('simulations/'+name+'-result.json',entry);results.append(entry)
finally:
 run('subst-remove',['subst',drive,'/d'])
 removed=not bool(ctypes.windll.kernel32.GetLogicalDrives()&(1<<(ord(drive[0])-65)))
 write_json('ascii-drive-cleanup.json',{'drive':drive,'removed':removed});assert removed
write_json('simulations/result.json',{'tested_commit':HEAD,'source_commit':SOURCE,'cases':results,'all_passed':all(x['passed'] for x in results),'oracle_pre_author_blind':False,'scope':'new A public-port standalone digital RTL cases; no hierarchy, force or author TB reused'})
print(json.dumps(results,indent=2));raise SystemExit(0 if all(x['passed'] for x in results) else 2)
