`timescale 1ns/1ps
module a_tb_rx;
parameter integer HZ=160, BAUD=10, W=4;
reg clk=0; always #5 clk=~clk;
reg rst=1,cancel=0,rx_async=0,out_ready=0;
wire out_valid,busy,framing_error_event,overrun_event,false_start_event;
wire [7:0] out_data;
wire [W-1:0] stat_frames,stat_retired,stat_overruns,stat_framing,stat_false_starts,stat_aborted;
deepeye_uart_rx #(.CLOCK_HZ(HZ),.BAUD(BAUD),.STAT_W(W)) dut(.*);
integer edge_no=0,checks=0,fe=0,oe=0,se=0; reg pv=0,pfe=0,poe=0,pse=0;reg [7:0] pd=0;
function integer B(input integer k); B=(k*HZ+BAUD-1)/BAUD;endfunction
function integer HB(input integer k); HB=(k*HZ+2*BAUD-1)/(2*BAUD);endfunction
task ck(input bit ok,input string msg);begin checks=checks+1;if(!ok)$fatal(1,"A_RX_FAIL edge=%0d %s",edge_no,msg);end endtask
always @(posedge clk) begin
 #1; edge_no=edge_no+1;
 ck(!$isunknown({out_valid,out_data,busy,framing_error_event,overrun_event,false_start_event,stat_frames,stat_retired,stat_overruns,stat_framing,stat_false_starts,stat_aborted}),"known public values");
 if(pv&&!out_ready&&!rst&&!cancel) ck(out_valid&&out_data===pd,"held output stable under backpressure");
 if(!rst&&!cancel) begin
  ck(!(pfe&&framing_error_event),"framing pulse width");ck(!(poe&&overrun_event),"overrun pulse width");ck(!(pse&&false_start_event),"false-start pulse width");
 end
 if(framing_error_event)fe=fe+1;if(overrun_event)oe=oe+1;if(false_start_event)se=se+1;
 pv=out_valid;pd=out_data;pfe=framing_error_event;poe=overrun_event;pse=false_start_event;
end
task step(input integer n); repeat(n) begin @(posedge clk);#2;end endtask
task send_frame(input [7:0] data,input bit stop_good,input bit refill);
 integer k,duration,to_stop_sample;reg level;
 begin
  for(k=0;k<10;k=k+1)begin
   if(k==0)level=0;else if(k==9)level=stop_good;else level=data[k-1];
   rx_async=level;duration=B(k+1)-B(k);
   if(k==9&&refill)begin
    to_stop_sample=3+HB(19)-B(9);
    step(to_stop_sample-1);out_ready=1;step(1);
    ck(out_valid&&out_data==data,"same-edge old retirement and new completion retains new byte");
    ck(stat_frames==3&&stat_retired==1&&stat_overruns==1,"refill accounting at exact stop sample");
    out_ready=0;step(duration-to_stop_sample);
   end else step(duration);
  end
 end
endtask
integer i;
initial begin
 step(5);rst=0;step(B(2));ck(!busy&&!out_valid&&stat_frames==0,"held-low reset does not qualify start");
 rx_async=1;step(8);
 send_frame(8'ha5,1,0);ck(out_valid&&out_data==8'ha5&&stat_frames==1,"first frame and slot");step(9);
 send_frame(8'h5a,1,0);ck(out_valid&&out_data==8'ha5&&stat_frames==2&&stat_overruns==1&&oe==1,"overrun drops new byte only");
 step(5);send_frame(8'hc3,1,1);ck(out_valid&&out_data==8'hc3,"new byte held after refill");step(6);
 send_frame(8'h00,0,0);step(B(2));ck(stat_framing==1&&fe==1&&out_valid&&out_data==8'hc3&&!busy,"bad stop, long low, prior byte retained");
 rx_async=1;step(B(1));rx_async=0;step(2);rx_async=1;step(B(1));ck(stat_false_starts==1&&se==1&&!busy,"short false start");
 rx_async=0;step(B(2));ck(busy&&out_valid,"active and pending objects before cancel");cancel=1;step(1);
 ck(!busy&&!out_valid&&stat_aborted==2,"cancel counts active frame and pending slot");step(3);ck(stat_aborted==2,"held cancel no recount");cancel=0;step(B(2));ck(!busy,"held low after cancel requires new high");
 rst=1;cancel=1;step(1);ck(stat_aborted==0&&stat_frames==0&&stat_framing==0,"reset overrides cancel");rst=0;cancel=0;rx_async=1;out_ready=1;step(8);
 for(i=0;i<5;i=i+1)begin send_frame(8'h31+i,1,0);step(6);end
 ck(stat_frames==((W==2)?3:5)&&stat_retired==((W==2)?3:5),"retirement and counter saturation");ck(stat_overruns==0&&stat_framing==0&&stat_false_starts==0,"reset clears prior errors");
 $display("A_RX_PASS hz=%0d baud=%0d w=%0d edges=%0d checks=%0d framing_pulses=%0d overrun_pulses=%0d false_pulses=%0d",HZ,BAUD,W,edge_no,checks,fe,oe,se);$finish;
end
initial begin #2000000;$fatal(1,"A_RX_TIMEOUT");end
endmodule
