from review_driver import *
import re,binascii
sim=json.loads((OUT/'simulations/result.json').read_bytes());results=[]
assert binascii.crc_hqx(b'123456789',65535)==0x29b1
for case in sim['cases']:
 if case['kind']!='frame':continue
 name=case['name'];hz=case['parameters']['CLOCK_HZ'];baud=case['parameters']['BAUD']
 B=lambda k:(k*hz+baud-1)//baud
 raw=(OUT/'commands'/f'{name}-vsim/stdout.bin').read_bytes().decode()
 vectors=[dict(zip(['label','n','seal','first','retire','hex'],m)) for m in re.findall(r'A_FRAME_VECTOR label=(\w+) n=(\d+) seal=(\d+) first=(\d+) retire=(\d+) bytes=([0-9a-f]+)',raw)]
 for v in vectors:
  for k in ['n','seal','first','retire']:v[k]=int(v[k])
 p=CHECKOUT/case['relative_run_dir']/'wire.csv'
 rows=[list(map(int,s.split(','))) for s in p.read_text().splitlines()]
 assert [r[0] for r in rows]==list(range(1,case['stats']['edges']+1))
 wire={r[0]:r[1] for r in rows};de={r[0]:r[2] for r in rows}
 def decode(v,values):
  data=[]
  for j in range(v['n']):
   a=v['first']+j*(B(10)+2);bits=[]
   for k in range(10):bits.append(values[a+B(k)+(B(k+1)-B(k))//2])
   assert bits[0]==0 and bits[9]==1
   data.append(sum(bits[k+1]<<k for k in range(8)))
  return bytes(data)
 decoded=[]
 for v in vectors[:3]:
  b=decode(v,wire);assert b.hex()==v['hex'] and len(b)==v['n']
  assert de[v['seal']]==0 and all(de[e]==1 for e in range(v['seal']+1,v['retire'])) and de[v['retire']]==0
  crc=None
  if v['label'].startswith('crc_'):
   crc=binascii.crc_hqx(b[:-2],65535);assert int.from_bytes(b[-2:],'big')==crc
  decoded.append({'label':v['label'],'bytes':len(b),'decoded_hex':b.hex(),'crc16_ccitt_false':crc,'de_rise':v['seal']+1,'de_fall':v['retire'],'exact_de_window':True})
 a=vectors[0];bad=dict(wire);byte_start=a['first']+4*(B(10)+2)
 for e in range(byte_start+B(1),byte_start+B(2)):bad[e]=1-bad[e]
 damaged=decode(a,bad);crc_negative=int.from_bytes(damaged[-2:],'big')!=binascii.crc_hqx(damaged[:-2],65535);assert crc_negative
 bad_de=dict(de)
 for e in range(vectors[0]['retire'],vectors[1]['seal']+1):bad_de[e]=1
 boundary_negative=not (bad_de[vectors[0]['retire']]==0 and bad_de[vectors[1]['seal']]==0);assert boundary_negative
 entry={'case':name,'wire_sha256':sha(p.read_bytes()),'wire_bytes':p.stat().st_size,'decoded':decoded,'decoded_bytes':sum(x['bytes'] for x in decoded),'negative_controls':{'single_data_bit_flip_rejected_by_external_crc':crc_negative,'merged_de_frame_boundary_rejected':boundary_negative},'limits':'CRC generated and checked only in the independent harness; DUT is an opaque byte-frame transmitter and provides no CRC generation/validation or public ABI'}
 results.append(entry)
write_json('wire-decode-result.json',{'cases':results,'all_passed':True,'decoded_bytes':sum(x['decoded_bytes'] for x in results),'crc_frames_checked':4,'negative_controls':4})
print('WIRE_DECODE_PASS bytes=162 crc_frames=4 negative_controls=4')
