import pathlib,json,datetime,sys
from acquire import ROOT,OUT,LOCAL,sha,save_json
mp=OUT/'EVIDENCE_MANIFEST.json';excluded={'lease.private.json','EVIDENCE_MANIFEST.json','MANIFEST.sha256.txt','manifest-readback.json','native-complete.json'}
def rows():
 a=[]
 for folder in [OUT,LOCAL]:
  for p in sorted(folder.rglob('*')):
   if p.is_file() and not(p.parent==OUT and p.name in excluded):
    b=p.read_bytes();a.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':sha(b)})
 return a
if len(sys.argv)>1 and sys.argv[1]=='verify':
 o=json.loads(mp.read_bytes());assert o['files']==rows();h=sha(mp.read_bytes());assert (OUT/'MANIFEST.sha256.txt').read_text().split()[0]==h
 for row in json.loads((OUT/'SOURCE_HASH_MANIFEST.json').read_bytes())['files']:
  p=LOCAL/'snapshot'/row['path'];assert sha(p.read_bytes())==row['sha256'] and p.stat().st_size==row['bytes']
 r={'status':'all_frozen_hashes_read_back','file_count':len(o['files']),'manifest_sha256':h,'report_sha256':sha((OUT/'report.md').read_bytes()),'result_sha256':sha((OUT/'result.json').read_bytes()),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};save_json(OUT/'manifest-readback.json',r);print(json.dumps(r,indent=2))
else:
 save_json(mp,{'schema':1,'work_id':'A-B-MINIMAL-PL-READINESS-20261024-v1','scope':'Read-onlyselectedGitmetadata/docs/source and own review artifacts; no rawarchive/DCP/board or execution results claimed.','exclusions':sorted(excluded),'files':rows()});h=sha(mp.read_bytes());(OUT/'MANIFEST.sha256.txt').write_text(h+'  EVIDENCE_MANIFEST.json\n',encoding='ascii');print(json.dumps({'file_count':len(rows()),'manifest_sha256':h}))
