import pathlib,json,hashlib
from acquire import ROOT,OUT,LOCAL,SNAP,HEAD,entries,sha,save_json
idx=json.loads((OUT/'acquisition-index.json').read_bytes());negative=json.loads((OUT/'minimal-delivery-negative-inventory.json').read_bytes());verification=json.loads((OUT/'handoff-readiness-verification.json').read_bytes())
assert idx['current_PR_head_at_GET']==HEAD and not idx['tracked_deepeye_bit_hwh_paths'] and not negative['board_constraint_paths_in_deepeye']
es=entries();files=[]
for p in sorted(SNAP.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(SNAP).as_posix();b=p.read_bytes();gid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert gid==es[rel]['sha']
 files.append({'path':rel,'bytes':len(b),'sha256':sha(b),'git_blob':gid})
for row in verification:
 op=row['operation'];p=SNAP/f'handoffs/b/{op}/manifest.json';m=json.loads(p.read_bytes())
 assert sha(json.dumps(m['request'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==m['request_hash']==row['request_hash']
 for path,desc in m['files'].items():
  f=SNAP/path
  if f.exists():assert sha(f.read_bytes())==desc['sha256'] and f.stat().st_size==desc['size']
 assert not row['indexed_bit_hwh']
for base in ['competition/deepeye/evidence/build/ooc-20261024-33/publication','competition/deepeye/evidence/transport/uart-link-fixture-20261024-34/publication']:
 binding=json.loads((SNAP/base/'SOURCE_BINDING.json').read_bytes())
 for path,h in binding['sources'].items():
  f=SNAP/path
  if f.exists():assert sha(f.read_bytes())==h
save_json(OUT/'SOURCE_HASH_MANIFEST.json',{'tested_head':HEAD,'selected_blob_count':len(files),'scope':'Only selected manifests/publication metadata/docs/Tcl and capture RTL. Raw archive bytes/DCPs/not-selected source were deliberately not fetched or independently accepted.','files':files})
availability=[
 {'item':'same-build implemented bit/HWH/build manifest','state':'not_delivered_at_tested_head','evidence':'No tracked DeepEye.bit/.hwh or source XDC; both33/34 RAW_INDEX contain0bit/HWH.33Tcl only synth_design -mode out_of_context and write_checkpoint.','missing':'Matched real bit/HWH and full implemented-build identity/top/IP/address/clock/reset/source binding for the chosen minimal path.'},
 {'item':'B33 OOC evidence','state':'new_published_component_synthesis_evidence_only','evidence':'Published selected reports/indices record19distinct DCP tops.Producer acceptance says19actual syntheses and4DCPreadbacks; this review does not rerun/reopen/independently accept them. Two actual10ns diagnostic WNS values -4.379/-4.349ns remain failed.','missing':'Combined minimal PL integration/implementation and matched overlay, not another component OOC report.'},
 {'item':'B34 digital pin link fixture','state':'new_test_only_fixture_evidence','evidence':'fixture.md explicitly test-only joins frozen TX/RX at testbench fault mux, no product RTL change, noBOOT/source/slot/motion authority.','missing':'Real integration and physical I/O path; fixture cannot provide bit/HWH or BOOT policy.'},
 {'item':'source4/topology2 plus BOOT/stopped and fresh triggered sample causality','state':'not_established_by_this_delivery','evidence':'Existing root task names source4/topology2 digital fixture as allowed first diagnostic; capture source only has rst/stop/rearm/tag/sample_strobe/channel/data/tick/quality and treats values opaque, no authenticatedBOOT/source/topology decoder or trigger-to-observation contract. B34 explicitly excludes these semantics.','missing':'Chosen minimal integrated path with original frozen source4/topology2 identities, stopped state/BOOT echo and one explicit trigger linked to a newly captured sample/sequence; no reuse of old buffered observation as new.'},
 {'item':'A bounded collect/stop script tied to that image','state':'not_in_op33_or34_delivery','evidence':'Handoff artifacts are OOC tooling/metadata and test fixture/runners; no board-side bounded acquisition/stop entrypoint, same-build HWH mapping or invocation recipe is supplied. Existing A receipt/BOOT components remain diagnostic software-only per root decisions.','missing':'Exact hash-pinned A-only collection/stop entrypoint/arguments and bounded-stop/failure behavior bound to the actual new overlay; no motion grant or automatic uncertain replay.'}
]
result={'schema':1,'work_id':'A-B-MINIMAL-PL-READINESS-20261024-v1','job_id':'child-fde4849208a046699f99351a805cce72','agent_id':'/root/b_wire2829_review','task':'DEEPEYE-IMPLEMENTATION-20261014/v1','director_generation':3,'status':'read_only_readiness_review_complete','minimum_PL_package_readiness':'not_delivered_or_ready_for_A_load_in_this_PR_head','tested_head':HEAD,'current_PR_head_at_GET':idx['current_PR_head_at_GET'],'selected_blob_count':len(files),'availability':availability,'evidence_limits':['Selected exact Git blobs/manifest request hashes/advertised raw-index identities verified only; no whole-top checkout, raw archive/member audit, DCP open or B33/B34 acceptance inheritance.','Absent at this PR/head does not prove B unpublished local work absent. B33 ACCEPTANCE explicitly calls operation35 separate/unpublished; no35handoff exists here.','Failed19-top timing does not itself prohibit a different narrowly chosen minimal raw diagnostic path; its full ADC/CNN/threePWM are not new prerequisites.','A standalone OS receipt/BOOT transcript readiness is separate from real overlay/BOOT/fresh sampling delivery.'],'execution':{'read_only_Git_GETs':True,'selected_source_static_read_only':True,'RTL_simulation_build_author_scripts':False,'board_serial_UI_services_config_queue_credentials':False,'product_C4_index_mutation':False,'messages_network_writes_delegation':False},'prior_F01':'OPEN untouched','contract':'DEEPEYE-HUMAN-LOCK-20261014/revision1','requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','G03':'not_run','R03':'not_run','all29':'not_run','acceptance_and_next_actual_action_owner':'A Gen3/root'}
save_json(OUT/'result.json',result)
report=f'''# B 最小 PL 交付准备度：尚未交付可供 A 加载的整包

只读核对 PR30 当前读回 head **`{HEAD}`**。新 B33/B34 提供了分立 OOC 综合与数字 pin-link 测试证据，**没有同次真实 `.bit/.hwh/build`，原 source4/topology2 的 BOOT/stopped＋新样本触发链也未建立为可交付集成路径**。这不是本代理授权构建或上板的结论；root选择下一实际动作。

新job `child-fde4849208a046699f99351a805cce72` canonical `/root/b_wire2829_review` 已execution_allowed=true；task `DEEPEYE-IMPLEMENTATION-20261014/v1`、A Gen3、H01–H15 canonical `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`重核。A唯一实板。旧lease未复用、F01保持OPEN。

## 此head新增已有证据

| 交付 | 精确身份 | 已有层级 | 不能提升为 |
|---|---|---|---|
|B-DEEPEYE-OOC-SYNTHESIS-20261024-33|source d4368116b00e5263afde591ab2059120abaf55b0；request2aad4c8a798e0e6fc60d30996e2420234cd64795f6aeac37a141f1fc691fcf23；manifest7f4ca35b90cd73775434e78a674418db8986f125367a2f96bef437cabb95d85e|427成员的已发布index列19个分立DCP；摘要称19个top完成OOC及4个DCP读回|整机实现、时序闭合、bit/HWH或板测|
|B-DEEPEYE-UART-LINK-FIXTURE-20261024-34|source1a92c37be6a2674b59950413f07d4a687942d434；request7a899983412e76e936c0ab817a2b4f8a45ebbcab4634579a4e951531e2dfd5ba；manifest7627dc1ced313a6a1d158b9f6b8e40f3285a61887a1f4a79b2b8d870796e0006|test-only ModelSim pin fixture；8原RTL不变、testbench fault mux|产品top、真实引脚、BOOT/source/控制语义|

这里只验证选定原始Git blobs、request/manifest与已发布index字节，不继承以上生产者“accepted”结论，未下载或再审数百MB raw包、未打开DCP、未运行任何仿真/综合/作者脚本。

B33 `ooc_qualification.tcl`实际包含 `synth_design -mode out_of_context`、后加诊断clock和`write_checkpoint`；无place/route/bitstream/HWH步骤。两个10ns诊断setup失败仍保留：block_encoder WNS **-4.379ns**、block_stream **-4.349ns**；I/O delays未知，CRC无虚构时钟，PS7/DSP warning未豁免，19top资源不能相加当整机。它是已有真实组件级综合记录，仍不是最小完整overlay。

元数据中没有DeepEye tracked `.bit/.hwh`；两份427/1184成员RAW_INDEX也均无`.bit/.hwh`。未发现本head的35handoff，B33 ACCEPTANCE还明示operation35独立未发布。这是已交付head范围的结论，不声称B本地未发布工作不存在。

## 仍缺的最小材料

1. **同次实际集成build与bit/HWH。** 需要选定最小top、精确source/build身份和真实匹配bit/HWH，必要IP/address/clock/reset绑定及实际实现报告。现有DCP和test-only mux不能替代。
2. **原source4/topology2＋BOOT/stopped＋fresh-trigger闭环。** 当前`sample_scan_capture`仅观察外部`sample_strobe`并保留opaque data/tick/quality/tag；它有`stop/rearm`清窗机制，但文档明确`out_valid`不保证fresh/live acquisition，ordinal不是public sample_id，也没有BOOT/source/topology协议状态。尚无交付集成top把原冻结身份、stopped/BOOT、一次新触发和之后的新采样/序列因果关联起来；不能拿旧buffer数据当新观测。B34明确不赋予这些语义。
3. **对应真实image的A受限采集/停止脚本与实参。** B33/34 artifact只含OOC工具/报告或fixture/runners，未交付绑定新HWH及build身份的A板端采集/停止入口、限量/超时/清理和失败记录。A现有OS receipt/BOOT transcript只证明诊断软件准备，root记录仍将真实board channel/BOOT与same-build PL package列pending，不能替代该脚本或真实新样本。

以上不把最终ADC、CNN或三路PWM捕获添加为最早source4/topology2数字fixture诊断的前置。也不要求先把所有19个组件的时序问题解决才允许root选择另一条更小的raw诊断设计；本次事实是该最小集成包尚未在此head交付。原B-LIVE-OBS-INTEGRATION任务及负责人保留，不重复派发或重放未知操作。

## 证据与边界

选定{len(files)}个小文件的Git blob SHA1/长度/SHA256见SOURCE_HASH_MANIFEST.json；metadata inventory仅用于定位B33/B34和检查bit/HWH/index，不是whole-source审计。必要源码只静态阅读sample collector和OOC Tcl，命令仅为不可信参考，没有执行。

全过程没有RTL/仿真/构建/旧组/作者脚本/board/串口/UI/服务/config/队列/credentials操作，没有消息或网络写，也未动product/C4/index。H01–H15不变，G03/R03/all29仍not_run。正式接受与下一实际动作由root负责。
'''
(OUT/'report.md').write_text(report,encoding='utf8')
print(json.dumps({'readiness':result['minimum_PL_package_readiness'],'selected_blobs':len(files),'report_sha256':sha((OUT/'report.md').read_bytes()),'result_sha256':sha((OUT/'result.json').read_bytes())},indent=2))
