import pathlib,json,subprocess,hashlib,base64,datetime
ROOT=pathlib.Path(__file__).resolve().parents[3];OUT=pathlib.Path(__file__).resolve().parent
LOCAL=ROOT/'.local/deepeye-b-minimal-pl-readiness-20261024';LOCAL.mkdir(parents=True,exist_ok=True)
META=LOCAL/'metadata';META.mkdir(exist_ok=True);SNAP=LOCAL/'snapshot';SNAP.mkdir(exist_ok=True)
HEAD='8ca3dd05cac4aea49c0afe53a6d9a12124aa12d2';GH='C:/Program Files/GitHub CLI/gh.exe'
def sha(b):return hashlib.sha256(b).hexdigest()
def save_json(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def api(path,name):
 p=META/(name+'.json')
 if p.exists():return json.loads(p.read_bytes())
 argv=[GH,'api',path];r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);p.write_bytes(r.stdout)
 (META/(name+'.stderr.bin')).write_bytes(r.stderr);save_json(META/(name+'.command.json'),{'argv':argv,'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 if r.returncode:raise RuntimeError(r.stderr.decode(errors='replace'))
 return json.loads(r.stdout)
def entries():return {x['path']:x for x in json.loads((META/'head-tree.json').read_bytes())['tree'] if x['type']=='blob'}
def blob(path):
 e=entries()[path];p=SNAP/path
 if p.exists():b=p.read_bytes()
 else:
  assert e['size']<=1000000,('selected blob too large; do not download blindly',path,e['size'])
  o=api('repos/carolwjade/CarlandFPGA/git/blobs/'+e['sha'],'blob-'+e['sha']);b=base64.b64decode(o['content']);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 h=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert h==e['sha'] and len(b)==e['size']
 return {'path':path,'bytes':len(b),'sha256':sha(b),'git_blob':h}
def main():
 scope=json.loads((ROOT/'docs/competition/deepeye-2026/immutable_scope.json').read_bytes());h=sha(json.dumps(scope['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode());assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
 save_json(OUT/'scope-validation.json',{'contract':'DEEPEYE-HUMAN-LOCK-20261014/revision1','requirements_sha256':h,'ids':[r['id'] for r in scope['requirements']],'A_Gen3_root_only_board_and_acceptance':True})
 pr=api('repos/carolwjade/CarlandFPGA/pulls/30','pr30');hc=api('repos/carolwjade/CarlandFPGA/git/commits/'+HEAD,'head-commit');tree=api('repos/carolwjade/CarlandFPGA/git/trees/'+HEAD+'?recursive=1','head-tree');assert not tree.get('truncated')
 paths=[]
 for p,e in entries().items():
  if p.startswith('handoffs/b/') and any(s in p for s in ['-20261024-32/','-20261024-33/','-20261024-34/']):paths.append(p)
 docs=[p for p in entries() if p.startswith('competition/deepeye/') and any(s in p.lower() for s in ['pinlink','ooc','minimal_pl','minimal-pl','live_observation','observation_top'])]
 bit_hwh=[{'path':p,'bytes':e['size'],'git_blob':e['sha']} for p,e in entries().items() if p.startswith('competition/deepeye/') and p.lower().endswith(('.bit','.hwh'))]
 save_json(OUT/'acquisition-index.json',{'tested_head':HEAD,'current_PR_head_at_GET':pr['head']['sha'],'direct_parent_shas':[p['sha'] for p in hc['parents']],'selected_handoff_paths':paths,'candidate_readiness_paths':docs,'tracked_deepeye_bit_hwh_paths':bit_hwh,'scope':'metadata inventory and selected small blobs only; no whole-top checkout, archive or build run'})
 initial=[p for p in paths if p.endswith(('.json','.md'))]
 rows=[blob(p) for p in initial];save_json(OUT/'initial-blobs.json',rows)
 print(json.dumps({'current_PR_head':pr['head']['sha'],'handoff_paths':paths,'readiness_paths':docs,'tracked_deepeye_bit_hwh':bit_hwh},indent=2))
if __name__=='__main__':main()
